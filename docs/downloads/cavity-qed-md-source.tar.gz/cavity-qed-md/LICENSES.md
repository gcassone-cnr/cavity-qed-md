# Licensing and attribution

The bundled eT source retains its original author notices and GNU General Public License, version 3. The license text is included at `vendor/eT-LICENSE` and inside the source archive. The eT modifications are distributed as source patches against the bundled snapshot.

i-PI, libcint, optional LibXC and the Python dependencies retain their upstream licenses. A separate license for the interface and workflow files is unspecified in this repository.

If you use Cavity-QED Molecular Dynamics in your work, please cite the accompanying arXiv article by Giuseppe Cassone (2026). https://arxiv.org/abs/2611.09667

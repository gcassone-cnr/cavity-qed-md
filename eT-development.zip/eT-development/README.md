i Prerequisites
1. [CMake](https://cmake.org/) (3.18 or newer)
2. Python 3 (3.6 or newer)
3. Recent GNU compilers (gfortran, gcc, g++ 10.4 or newer) or Intel compilers (ifx, icx, icpx 2024.0 or newer). We are currently only guaranteeing support for these compilers, but other compilers may also work.
4. BLAS and LAPACK libraries
5. Integral library. Currently [libint2](https://github.com/evaleev/libint), [libcint](https://github.com/sunqm/libcint), [PhasedInt](https://gitlab.com/andrea_bianchi/phasedint) are supported.
    - Libint has the dependencies [Eigen 3](http://eigen.tuxfamily.org/index.php?title=Main_Page) and [Boost](https://www.boost.org). To compile Libint, follow the instructions below or consult the [Libint Wiki](https://github.com/evaleev/libint/wiki).
6. [Ninja](https://ninja-build.org/)


## Installing Integral Library
Currently there are three options for integral libraries:
- [Libcint](https://github.com/sunqm/libcint)
- [Libint2](https://github.com/evaleev/libint)
- [PhasedInt](https://gitlab.com/andrea_bianchi/phasedint)

You need to have at least one of these installed. Follow the instructions below to install.
Currently libcint supports the most integrals, so should be used by default.
A detailed breakdown of supported integrals/methods for the different libraries can be found [here](https://etprogram.org/integral_libraries.html).

### Installing Libcint
Clone the libcint repository and enter:
```shell
git clone https://github.com/sunqm/libcint
cd libcint
```
Make build directory:
```shell
mkdir build
cd build
```
Setup, compile and install:
```shell
cmake .. -DBUILD_SHARED_LIBS=0 -DPYPZPX=1 -DMIN_EXPCUTOFF=0.0 -DCMAKE_INSTALL_PREFIX=/where/you/want/to/install/libcint/ -DCMAKE_C_COMPILER=[C compiler] -DCMAKE_C_FLAGS=[C compiler flags]
cmake --build . -j 4 --target install
```
CMake will attempt to install libcint in the directory specified by `-DCMAKE_INSTALL_PREFIX`.
Especially on clusters this is important,
since you normally won't have access to the default location, `/usr/local`.
Provide a path to a directory you want to install in and make sure you have write access.
The install directory cannot be in the source directory.


### Installing Libint
Download the [Libint library for eT](https://www.etprogram.org/libint/libint-2.7.0-beta.6.tgz).
Unpack the tar file:
```shell
tar -xvzf libint-2.7.0-beta.6.tgz
```
Enter the generated folder:
```shell
cd libint-2.7.0-beta.6
```
Compile (with 4 threads (-j flag), increase if more are available):
```shell
cmake . -DCMAKE_INSTALL_PREFIX=/where/you/want/to/install/libint/libint-2.7.0-beta.6 -DCMAKE_C_COMPILER=[C compiler] -DCMAKE_CXX_COMPILER=[C++ compiler] -DCMAKE_CXX_FLAGS=[C++ compiler flags]
cmake --build . -j 4
```
CMake will attempt to install Libint in the directory specified by `-DCMAKE_INSTALL_PREFIX`.
Especially on clusters this is important,
since you normally won't have access to the default location, `/usr/local`.
Provide a path to a directory you want to install in and make sure you have write access.
The install directory cannot be in the source directory.

Make sure the Libint configure step finds the correct compilers (as compiling Libint can take several hours). Compile and install:
```shell
cmake --build . --target install
```

On a cluster, compiling Libint will often take so long that you must (and want to) submit it as a job.
On the [wiki](https://gitlab.com/eT-program/eT/-/wikis/home),
we have an [example script](https://gitlab.com/eT-program/eT/-/wikis/Various-guides/Example-script-for-installing-Libint-on-cluster) to submit the compilation.
You will probably have to modify it for your system.

If you wish to download and run the Libint compiler yourself,
the standard configuration flags for eT are available [here](https://gitlab.com/eT-program/eT/-/wikis/Various-guides/Standard-configuration-for-Libint).


### Installing PhasedInt
Clone the phasedint repository and enter:
```shell
git clone https://gitlab.com/andrea_bianchi/phasedint
cd phasedint
```
Make build directory:
```shell
mkdir build
cd build
```
Setup, compile and install:
```shell
cmake ..
make -j4
```
This command will install the library in the build directory.


# Optional: Installing PCMSolver
If you want to use polarizable continuum models in eT,
you can link eT to the [PCMSolver](https://github.com/PCMSolver/pcmsolver) library.
PCMSolver can be cloned from [Github](https://github.com/PCMSolver) and must be compiled separately.

**Note:** PCMSolver requires [Zlib](https://www.zlib.net/) and [Boost](https://www.boost.org).

**Note:** eT requires PCMSolver v1.2.

To configure PCMSolver with 64bit integers, run
```shell
mkdir -p /where/you/want/to/install/pcmsolver/
./setup.py --omp --int64 --prefix=/where/you/want/to/install/pcmsolver/
```
and to compile and install PCMSolver, run
```shell
cd build
make -j 4
make install
```

CMake should locate PCMSolver when the PCMSolver_ROOT environment variable is set to the location of the installed library:
```shell
export PCMSolver_ROOT=/where/you/want/to/install/pcmsolver/
```

[Here](https://gitlab.com/eT-program/eT/-/wikis/Various%20guides/Example%20script%20for%20installing%20PCMSolver) you can find a script
that can be used to setup PCMSolver on most UNIX clusters.

## PCMSolver on Mac
A patched version of PCMSolver that works on Mac can be found [here](https://github.com/eirik-kjonstad/pcmsolver).
For Apple silicon users experiencing linking issues, the following options can be passed while running the `setup.py` script
`--extra-cxx-flags=-Wl,-ld_classic --static`.
To configure PCMSolver with 64bit integers, run
```shell
./setup.py --omp --int64 --prefix=/where/you/want/to/install/pcmsolver/ --extra-cxx-flags=-Wl,-ld_classic --static
```

# Optional: Installing LibXC
If you want to use Density Functional Theory in eT,
you can link eT to the [LibXC library](https://libxc.gitlab.io/).
We support version 5.1.3, so make sure to download the correct
version of the LibXC library [here](https://libxc.gitlab.io/download/previous/).
Other versions may work but we do not guarantee it.
Unpack the tar file:
```shell
tar -xvzf libxc-5.1.3.tar.gz
```
Enter the generated folder:
```shell
cd libxc-5.1.3
```
Compile:
```shell
cmake . -H. -Bbuild -DENABLE_FORTRAN=on -DENABLE_FORTRAN03=on -DCMAKE_Fortran_COMPILER=[Fortran Compiler] -DCMAKE_INSTALL_PREFIX=/where/you/want/to/install/libcxc/libxc-5.1.3 -DCMAKE_C_COMPILER=[C compiler] -DCMAKE_CXX_COMPILER=[C++ compiler] -DCMAKE_CXX_FLAGS=[C++ compiler flags]
cmake --build . -j 4
```
CMake will install LibXC in the directory specified by `-DCMAKE_INSTALL_PREFIX`.

Compile and install:
```shell
cd build
cmake --build . --target install
```

You can also follow the above steps by cloning from [source](https://gitlab.com/libxc/libxc).
If you do this, make sure to first checkout the supported version of LibXC:
```shell
git clone git@gitlab.com:libxc/libxc.git
cd libxc
git checkout 5.1.3
```

# Installing eT
## Getting the eT source
The source code can be downloaded as a tarball from the
[releases](https://gitlab.com/eT-program/eT/-/releases) page.
Click the  `source code` dropdown menu and choose your favourite archive format.
After downloading,
your archive manager will probably offer to handle it.
You can also use the command line.
```shell
unzip eT-vx.y.z.zip
tar -xvzf eT-vx.y.z.tar.gz
tar -xvjf eT-vx.y.z.tar.bz2
tar -xvf eT-vx.y.z.tar
```
Note that the archives do not include the
[runtest](https://runtest.readthedocs.io/en/latest/)
submodule required for testing
or the optional
[pFUnit](https://github.com/Goddard-Fortran-Ecosystem/pFUnit)
submodule to run unit tests.

You can also download eT by opening a terminal and cloning the repository:
```shell
git clone --recursive https://gitlab.com/eT-program/eT.git
```
or
```shell
git clone --recursive git@gitlab.com:eT-program/eT.git
```
The second option requires a user account on [Gitlab](https://gitlab.com/),
and that you have set up a public/private [keypair](https://docs.gitlab.com/ee/ssh/),
but is the most convenient if you intend to contribute.

**Note:**
`--recursive` is optional, but recommended.
It will automatically download the submodules
[runtest](https://runtest.readthedocs.io/en/latest/),
a python program used to run the test suite,
and
[pFUnit](https://github.com/Goddard-Fortran-Ecosystem/pFUnit),
to run unit tests.
Note that pFUnit required CMake version 3.12 or newer.
If you don't use `--recursive`,
but later change you mind,
you can get the submodule with the following commands.
```shell
git submodule init
git submodule update
```

## Installing and configuring Ninja

By default, eT uses the [Ninja](https://ninja-build.org/) build system with CMake but we
also support Unix Makefiles (make) (see `setup.py --help`).
On most systems Ninja is easily available through the system package manager as `ninja` or `ninja-build`.
Alternatively, Ninja can be installed from one of the github [releases](https://github.com/ninja-build/ninja/releases):

```shell
mkdir ninja-build
cd ninja-build
wget https://github.com/ninja-build/ninja/releases/download/v1.11.1/ninja-linux.zip
unzip ninja-linux.zip
```

The path of the `ninja-build` directory can then be added to the PATH environment variable.

## Configuration of eT
After downloading,
you will have a directory called `eT` or something like `eT-v1.0.1`,
depending on how you did it.
We will refer to it as `eT` from now on.
Go to this directory:
```shell
cd eT
```
Run the [setup.py](https://etprogram.org/setup.html) script to configure CMake:
```shell
./setup.py
```
Compilers and libraries identified by CMake will be printed to screen.
Take a look and see if it looks reasonable and error free.
Note that `setup.py` may take a long time on some clusters.

CMake will try to identify the compilers to use (Fortran, C, C++) and the location of libraries (such as BLAS, LAPACK, Libcint).
If CMake does not correctly locate and identify these,
you can try setting the associated environment variables.
In order to have these variables automatically exported when you open a new shell,
you can place the export commands in your `.bashrc` file.
Remember to update your current shell with `source .bashrc`.
Below are some examples:
```shell
export MATH_ROOT=/opt/intel/mkl # for MKL BLAS/LAPACK libraries
export LIBCINT_ROOT=/home/username/prog/libcint
export PHASEDINT_ROOT=/home/username/prog/phasedint
export LIBINT2_ROOT=/home/username/prog/libint
export LIBXC_ROOT=/home/username/prog/libxc-install-dir # for DFT
# Dependencies for Libint (Eigen, Boost)
# Boost is also needed for PCMSolver
export Eigen3_ROOT=/home/username/prog/eigen3/include/eigen3
export BOOST_INCLUDEDIR=/usr/include
```
If CMake does not find Eigen3, it can help to add `EIGEN3_INCLUDE_DIR` to
the `.bashrc` and also add it to the CMake prefix path:
```shell
export EIGEN3_INCLUDE_DIR=/usr/local/include/
export CMAKE_PREFIX_PATH="$CMAKE_PREFIX_PATH:$EIGEN3_INCLUDE_DIR"
```
Similarly, Boost can be added to the prefix path as well, if it cannot be found
```shell
export CMAKE_PREFIX_PATH="$CMAKE_PREFIX_PATH:$BOOST_INCLUDEDIR"
```


To configure which integral libaries to use specify the `-int-lib` flag in the setup script:
```shell
./setup.py -int-lib [libint/libcint/phasedint]
```

For help with `setup.py`,
run the script with the `--help` option.
```shell
./setup.py --help
```
This will list the various options,
a short description,
and the default values.
For more detailed description,
see the [website](https://etprogram.org/setup.html).

**Optional:**
To enable PCMSolver,
you must run `setup.py` with the `--pcm` option.

## Compilation of eT
If everything went well,
you should now have a directory in eT called build.
Go to this directory and compile.
```shell
cd build
cmake --build .
```
Note that either the `setup.py` or `autogenerate_files.py` script have to be run before
compiling, as the script generates necessary interfaces and files handling complex variables in eT.
Ninja compiles in parallel by default. To set the number of threads it is allowed to use, specify `cmake --build . -j n`.

If successful, the directory now contains the executable, `eT`, as well as a Python launch script
[eT_launch.py](https://etprogram.org/eT_launch.html).
If you downloaded runtest,
you can test your installation using ctest:
```shell
ctest
```

## Running eT
The launch script is the recommended way of running eT.
Similarly to `setup.py`,
it has a `--help` option
and a more detailed description is available
[here](https://etprogram.org/eT_launch.html).
To have `eT_launch.py` easily available,
you can add `build` to your `PATH` variable in `.bashrc`;
```shell
export PATH=$PATH:/path/to/eT/build
```
or copy the script to somewhere more convenient.

See the [website](https://etprogram.org)
for more help or look in `eT/tests` for inspiration when making your own input file.
For example,
`eT/tests/hf_energy/hf_energy.inp` is an input file for a Hartree-Fock calculation.

## Using eT as a CMake library
After compiling eT, install it to a prefix that other projects can find:
```shell
cmake --install build --prefix /path/to/eT-install
```

A CMake project can then import eT with:
```cmake
find_package(eT REQUIRED)
target_link_libraries(my_program PRIVATE eT::eT)
```

When configuring the project, point CMake to the eT installation:
```shell
cmake -S . -B build -DCMAKE_PREFIX_PATH=/path/to/eT-install
```
Alternatively, point directly to the eT package directory:
```shell
cmake -S . -B build -DeT_DIR=/path/to/eT-install/lib/cmake/eT
```

The project may also need access to the same dependency locations used when eT
was configured, such as `LIBCINT_ROOT`, `LIBINT2_ROOT`, `MATH_ROOT`, or
`LIBXC_ROOT`, depending on which optional libraries were enabled.

When using eT functionality from another program, initialize eT before creating
or using eT objects that depend on the global eT state, and finalize eT before
exiting. For scripting-style use with a configuration object, the pattern is:
```fortran
use eT_class, only: eT
use et_config_class, only: et_config

type(eT), allocatable :: eT_instance
class(et_config), pointer :: cfg

eT_instance = eT()
cfg => eT_instance%initialize_for_scripting()

call cfg%set_qm_geometry([character(len=200) :: &
                          'basis: cc-pvdz',     &
                          'H 0.74 0.00 0.00',   &
                          'H 0.00 0.00 0.00'])
call cfg%set('solver scf', 'residual threshold', 1.0d-11)

! Use eT functionality here.

call eT_instance%finalize()
```

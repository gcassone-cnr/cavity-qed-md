# AGENTS.md

## Preserve authorship when refactoring
When moving or editing routines, keep the original "Written by ..." in their documentation. If routines are moved and modified significantly, you may add the refactorer's name (e.g. "refactored by X, Year").

## Documentation header order
For routine/module docblocks, keep the eT order:
1. `!!`
2. `!! Written by ...`
3. `!!`
4. `!! Description...`
5. `!!`
Do not place the description before the authorship line.

## Pre-commit (required)
After making changes, run:

- `pre-commit run --all-files`

If it reports formatting issues (e.g., Black, trailing whitespace), apply the suggested fixes and re-run the command until it passes.

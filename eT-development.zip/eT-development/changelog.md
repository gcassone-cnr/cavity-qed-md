# eT v2.6.0
### Features
- DIIS for SAD guess generation. eT-program/eT!1652
- Adding a print of electron number estimated from plotting gird in density visualization. eT-program/eT!1665
- CCSD derivative coupling elements. eT-program/eT!1645

### Compilation
- Fix CMake Apple warnings. eT-program/eT!1657

# eT v2.5.1
### Bugfixes
- Fixed dft grid for cartesian functions and added test. eT-program/eT!1663

# eT v2.5.0
### Features
- Added an installable CMake package and exported `eT::eT` target for using eT as a library from external projects. eT-program/eT!1540
- MLCC2 and MLCCSD triplet excitation energies. eT-program/eT!1641
- Fixed rho integration for DFT in charged molecules and added test. eT-program/eT!1642
- Fixed incorrect logical condition in exchange/correlation check and added test. eT-program/eT!1650
- Fixed generation of z-matrices. Modified test. /eT!1656

### Cleanup
- Removed unused imported symbols in Fortran source files. eT-program/eT!1646
- Removed unused private type-bound procedures in Fortran source files. eT-program/eT!1647
- Apply Sable Fortran formatting to Fortran source files for consistent enforced style. eT-program/eT!1651, eT-program/eT!1653, eT-program/eT!1658
- Added Sable formatting in CI/CD and pre-commit setups. eT-program/eT!1654

# eT v2.4.1
### Bugfixes
- Fixed generation of z-matrices. Modified test. /eT!1653

# eT v2.4.0
### Features
- Added QED-CCSD ground state molecular gradients. eT-program/eT!1531
- MLCC2 and MLCCSD transition densities. eT-program/eT!1537
- Added input file checking, configuration object for scripting, and keyword default functionality. eT-program/eT!1621

### Other
- Added AGENTS.md file. eT-program/eT!1621

### Optimization
- Optimized memory footprint of ``construct_molecular_gradient_hf``. eT-program/eT!1474

# eT v2.3.1
### Cleanup
- Fixed 'oposite' typo in some CC routines. eT-program/eT!1632

# eT v2.3.0
### Compilers and setup
- Search system directories for libxc. eT-program/eT!1615

### Features
- Added 1e-density to QED-CCSD. eT-program/eT!1504
- Added 1e transition densities to QED-CCSD. eT-program/eT!1515
- TDDFT for LDA, GGA and global hybrid functional eT-program/eT!1552

### Cleanup
- Added replace_symbols.py to pre-commit tools to identify and replace all non-ASCII symbols. eT-program/eT!1624

### Autogeneration
- Fixed complexification bug in multi-line calls with optional parameters. eT-program/eT!1622

### Other
- Added CONTRIBUTING.md. eT-program/eT!1619

# eT v2.2.2
### Bugfixes
- Fixed reset of reduced space in non-linear Davidson updater. Added test. /eT!1627

# eT v2.2.1
### Bugfixes
- Modified the hard-coded year in the copyright tester and in autogenerate files. Updated developers names in eTdocs. /eT!1617

# eT v2.2.0
### Features
- Functionality for calculating different types of CC excitation energies, and calculating transition moments between these. eT-program/eT!1528

### Cleanup
- Remove unused compiler warnings when compiling with DFT library disabled. eT-program/eT/!1612
- Cleanup in MLCC orbitals (Cholesky, PAO) and print dominant doubles amplitudes in MLCC. eT-program/eT/!1610
- Introduce fallback for ES state guess when restart fails. eT-program/eT!1611

# eT v2.1.0
### Features
- Implemented restart for TDCC, elementary TD-EOM-CC, and diagonal TD-EOM-CC eT-program/eT/!1592
- Added SC-QED-HF linear response equations eT-program/eT/!1563
- Added input keyword `molecular gradient` to `cc response` section. eT-program/eT!1538
- Added occupation numbers from density matrix in CC. eT-program/eT!1579
- Added doubles starting guess for IP calculations (> CCS). Used when number of states exceeds number of occupied orbitals. eT-program/eT!1560

### Documentation
- Add documentation for basis conventions for coupled cluster code. eT-program/eT!1580

### Bugfixes
- Add dimensions to declarations and fix some wrong dimensions in eT-program/eT!1583

### Printing and output
- Add print for active space procedures, printing which type of HF orbital is being freezed. eT-program/eT!1581
- Add print to `export_release_info.py` for easier debug if release pipeline fails. eT-program/eT!1609

### Cleanup
- Make a density environment for post-HF embedding. eT-program/eT!1594

# eT v2.0.7
### Bugfixes
- Changing installation command for gcovr to fix coverage pipelines (third attempt). eT-program/eT!1604

# eT v2.0.6
### Bugfixes
- Fixing proper citations of LibXC and functionals used in DFT calculations. eT-program/eT!1603

# eT v2.0.5
### Bugfixes
- Changing installation command for gcovr to fix coverage pipelines (second attempt). eT-program/eT!1602

# eT v2.0.4
### Documentation
- Adding PCMSolver version limitation to README. eT-program/eT!1600

# eT v2.0.3
### Bugfixes
- Changing installation command for gcovr to fix coverage pipelines. eT-program/eT!1598

# eT v2.0.2
### Bugfixes
- Modifying filter thresholds for `plot_orbitals_mlccsd_cnto_es` that was failing with libint/-inan. eT-program/eT!1595

# eT v2.0.1
### Bugfixes
- Make davidson 'run' recursive, modifying the cc3_visualization_testthresholds, modify coverall pipeline. eT-program/eT!1589

# eT v2.0.0
### Features
- QED-CASCI ground and excited states with SC and QEDHF reference eT-program/!1529
- Transition moments for photon coordinate q and photon momentum p in TD-QED-HF  eT-program/eT!1524
- Fixed coupling self keyword and added test for qedhf coupling self and couplig biliner eT-program/eT!1525
- Population analysis (Mulliken and Loewdin) are implemented for HF. eT-program/eT!1219
- TD-QED-HF (RPA/Tamm-Dancoff) excitation energies implemented for QED-HF. eT-program/eT!1138
- Added transition dipole moments and oscillator strenghts for TDHF and TD-QED-HF
- Added iteration timer object that also prints the number of the iteration. eT-program/eT!1111
- CCSD triplet excitation energies (right vectors). eT-program/eT!1145, eT-program/eT!1159, eT-program/eT!1497, eT-program/eT!1558, eT-program/eT!1559
- Added script to rename or copy test directories and simplified `eT_launch`. eT-program/eT!1148
- Added SC-QED-HF. eT-program/eT!1187
- Generalized QED to bosons, renaming qed to photon and adding plasmon functionality. eT-program/eT!1191 eT-program/eT!1280
- Removed option to do diis with davidson preconvergence. eT-program/eT!1155
- Added asymmetric EOM polarizabilities. eT-program/eT!1135
- Replaced `sort_1234_to_XXXX` with `sort_to_XXXX`. eT-program/eT!1207
- Added ground and excited state (valence and CVS) analytical CCSD gradients. eT-program/eT!1213, eT-program/eT!1420, eT-program/eT!1423, eT-program/eT!1535
- Autogeneration of the complex reordering subroutines. eT-program/eT!1226
- Density Functional Theory. eT-program/eT!1196, eT-program/eT!1495
- Added DIIS as an option for triplet excited states. eT-program/eT!1228
- Added support for libcint. eT-program/eT!1167 eT-program/eT!1245
- Added input keyword to compute and print molecular gradient for hf. eT-program/eT!1176
- Added CASCI method. eT-program/eT!1258, eT-program/eT!1354, eT-program/eT!1361, eT-program/eT!1510
- Added fragmented optimization. eT-program/eT!1217
- Added adaptive time stepping integrators to the real-time CC framework. eT-program/eT!1193
- Added numerical gradients for methods without analytical gradients. eT-program/eT!1236, eT-program/eT!1277
- Added oscillator strengths in velocity and mixed gauge. eT-program/eT!1225
- Added rotatory strengths in length and **velocity** gauge both in atomic and cgs units. eT-program/eT!1225
- Added TD-EOM-CC in the elementary basis. eT-program/eT!1229 eT-program/eT!1432
- Orbital localization (Edmiston-Ruedenberg & Foster-Boys localization). eT-program/eT!1274, eT-program/eT!1472
- Added IPs for CC3. eT-program/eT!1260
- Added XPS for coupled cluster methods up to the CC3 level. eT-program/eT!1260
- CPHF shielding tensors are now available. eT-program/eT!1189, eT-program/eT!1281, eT-program/eT!1331, eT-program/eT!1473, eT-program/eT!1533
- Added damped response (CPP) solver. Used for CCSD/CCS damped polarizabilities. eT-program/eT!1430, eT-program/eT!1459
- Added dyson orbitals for coupled cluster methods up to the CC3 level. eT-program/eT!1263
- Added molecular gradient for QED-HF. eT-program/eT!1183
- Transition properties for fci. eT-program/eT!1300
- Enable restart from lowmem cc2 to CC2 and vice versa. eT-program/eT!1316, eT-program/eT!1319
- Added QED-CCSD ground state. eT-program/eT!1195, eT-program/eT!1384
- Added QED-FCI to calculate electron-photon correlation. eT-program/eT!1192, eT-program/eT!1359, eT-program/eT!1361
- Added numerical gradients for ground and excited state CC geometry optimizations. eT-program/eT!1275
- Added CCSDT ground state. eT-program/eT!1339, eT-program/eT!1517
- Added EOM/LR-CCSDT right excited states for valence, cvs, remove core, xps and ip excitations. eT-program/eT!1357, eT-program/eT!1374
- Added QED-CASCI method. eT-program/eT!1355
- Removed QED-CASCI tests and removed option to run such calculations. eT-program/eT!1476, eT-program/eT!1477
- Added CBO-HF, CBO-CC, CBO-CI ground, excited states and properties. eT-program/eT!1352, eT-program/eT!1376, eT-program/eT!1508
- Added support for the cpint integral library. eT-program/eT!1353, eT-program/eT!1372
- Added asymmetric band Lanczos algorithm for calculating excited EOM-CC states and transition properties. eT-program/eT!1251, eT-program/eT!1378
- Added QED-CCSD left excited state. eT-program/eT!1366
- Added option to include double excited amplitudes as start vectors for core-excited states. eT-program/eT!1373, eT-program/eT!1382
- Fixed dimension specification in the ``add_321_to_123`` routine. eT-program/eT!1380
- Added TD-EOM-CC in the diagonal basis. eT-program/eT!1370 eT-program/eT!1432
- Added simple restart for coupled cluster triplet excited states. eT-program/eT!1394
- Added print of .xyz for final optimized geometry. eT-program/eT!1424
- Added new Convergence criteria for geometry optimization. eT-program/eT!1276, eT-program/eT!1457
- Added multimodel Olsen algorithm for CC excited states. eT-program/eT!1421, eT-program/eT!1434
- Comments on section and keyword lines in the input file. eT-program/eT!1449, eT-program/eT!1450
- Added input keyword to compute and print ground state molecular gradient for cc. eT-program/eT!1375
- Added orbital diabatization (ensuring consistent orbitals and orbital signs across PES). eT-program/eT!1462
- Added QED-CCSD jacobian transformation. eT-program/eT!1469
- Added numerical molecular Hessian calculation (HF and CC), normal mode calculation/visualization, and Wigner sampling at T = 0 K. eT-program/eT!1422
- Added fix and tests for ci (fci, casci) in environments (non-polarizable, fq, pcm, cavity). eT-program/eT!1484
- Add debug flags in gfortran if -type Debug in setup.py and set -type Release as default. eT-program/eT!1509
- Added EA-EOM-CC. eT-program/eT!1496
- Added fix for updating QED-HF when the geometry changes, allowing for geometry optimization. eT-program/eT!1532
- Variational lagrangian energy for CC methods is now computed and printed by default when doing mean value. eT-program/eT!1478
- Added keyword ``variational energy`` to cc response to compute variational excitation energy in eom. eT-program/eT!1539
- Dipole velocity and rotatory strength for TDHF and TD-QED-HF (and TDA). eT-program/eT!1545
- Plotting of GS CC density in mean value calculation. eT-program/eT!1541, eT-program/eT!1549
- Added 1e-density to QED-CCSD. eT-program/eT!1504

### Structure
- Added trust-region solver and extended HF to be able to use it. eT-program/eT!1136, eT-program/eT!1271
- Added density storer to handle files associated with a cc density. eT-program/eT!1149
- Simplified density plotting in `cc_visualization_task`. eT-program/eT!1149
- Generalized `cc_es_diis_solver` and renamed to `eigen_diis_solver`. eT-program/eT!1155
- Added printer to constructor of `eigen_davidson_solver`. eT-program/eT!1155
- Added abstract vector getter as base class for rhs-getters and preconditioner getters. eT-program/eT!1161
- Linear and eigen davidson solvers now handle error stops if we do not converge. eT-program/eT!/1162
- Defined interface for integral libraries and moved libint out of `ao_tool`. eT-program/eT!1163
- Removed unused input keywords to set integral cutoffs and precision. eT-program/eT!1163
- Generalized the Cholesky decomposition to any AO-ERI getter class. eT-program/eT!1164
- Introduce wrapper to make the two-electron matrix used in TDHF variants. eT-program/eT!1157, eT-program/eT!1168
- Cleanup of the `approximate_double_excitation_vectors` routine in `ccs_class`. eT-program/eT!1175
- Generalized SCF solver. eT-program/eT!1180
- Renamed `solver_tools/functions` to `objective_functions`. eT-program/eT!1180
- Generalized `eigen_diis_solver` and `nonlinear_davidson_solver` into a common eigenvalue solver. eT-program/eT!1200
- Added a new wrapper to get one electron integrals. eT-program/eT!1202
- Added Jacobian CCSD intermediate struct. eT-program/eT!1227
- Restructured Jacobian transpose terms to reuse one-electron part in etaX. eT-program/eT!1201
- Added a cavity environment that is used for the CBO model. eT-program/eT!1231, eT-program/eT!1337
- Decouple QED-tool and QED-AO-ERI getter. eT-program/eT!1230 eT-program/eT!1283
- Remove the explicit dimension required by mem%dealloc and added build type selection in `setup.py`. eT-program/eT!1257
- Generalized real-time CC framework. eT-program/eT!1193 eT-program/eT!1431
- Added state descriptors to simplify handling of cvs and `rm_core` in CC3. eT-program/eT!1255
- Removed duplicate jacobian transformer classes in `solver_tools/amplitude_updaters`. eT-program/eT!1255
- Introduced assumed rank arrays in dealloc routines. eT-program/eT!1255
- Restructured input such that the sections store their keywords. eT-program/eT!1307, eT-program/eT!1322, eT-program/eT!1351
- Added excited state restart vector tool. eT-program/eT!1205
- Added a boson factory. eT-program/eT!1328
- Restructured input such that sections start with "- " and "end section" is not necessary. eT-program/eT!1324
- Pack triples vector in CCSDT. eT-program/eT!1356
- The qed section in the input file has been renamed as boson section. eT-program/eT!1365
- Simplified start guess routines for t, tbar and doubles excited state amplitudes. eT-program/eT!1373
- Modified QED-FCI initialization of the bosons to use `boson_tool` and `boson_factory` eT-program/eT!1379
- Reorganization of the Davidson solvers and related tools. eT-program/eT!1318, eT-program/eT!1414, eT-program/eT!1415, eT-program/eT!1456, eT-program/eT!1513, eT-program/eT!1517
- Renamed omega and gradient threshold to residual threshold and print orbitals to write orbitals. eT-program/eT!1428
- Environment classes now provide a fock matrix collecting all embedding contributions. eT-program/eT!1442
- Separated out reading and parsing of input file in the `input_file` (now reamed `input_tool`). eT-program/eT!1464
- Allowed wave function defined for HF engines. eT-program/eT!1547
- Make eT search for libcint.so in addition to libcint.a. eT-program/eT!1564

### Bugfixes
- Fixed eT interface to libint-2.7.1 and newer. eT-program/eT!1154
- Solvers print settings and headers again. eT-program/eT!1155
- Fixed gfortran warnings for -O0 when implicitly allocating strings or arrays. eT-program/eT!1157
- Fixed internal gfortran error when compiling `memory_tracker` with -O0. eT-program/eT!1159
- Raising error if the orbital index is not betwee 1 and `n_mo` when plotting MOs. eT-program/eT!1165
- Check number of iterations in the tests by default again. eT-program/eT!1166
- Fixed memory update in allocation for 2 dimensional integer arrays allocated from ranges. eT-program/eT!1169
- Fixed randomly failing `plot_orbitals_mlccsd_cnto_es` test by increasing the threshold for the `mo_information` file. eT-program/eT!1171
- Fixed print of number of states in `eigen_davidson_print_tool_class`. eT-program/eT!1177, eT-program/eT!1184
- Deactivated convergence check for `fci_energy_triplet_h2` because HF needs between 4 and 10 iterations. eT-program/eT!1178
- Fix print of total times in the output file. eT-program/eT!1197
- Fix uninitialized variables. eT-program/eT!1215 eT-program/eT!1218
- Changed the `error_msg` routine of the `output_file` to call the `error stop` intrinsic, and fixed ctest to handle failing unit test. eT-program/eT!1239
- Moved array initialization in `mem%alloc` after the error check. eT-program/eT!1215 eT-program/eT!1240
- Fixed intents in `get_vo_block_hf`. eT-program/eT!1252
- Fixed warnings from ifx compiler. eT-program/eT!1253
- Loosened `hf_orbital_files` test threshold to make pipeline pass for intel/libcint. eT-program/eT!1259
- Added sanity checks for multilevel inputs with non-existing atoms selected as active and/or "-" used instad of "," in the definition of a range. eT-program/eT!1243
- Fixed error message print in ao tool. eT-program/eT!1269
- Fixed temporary array allocation in plasmon tool. eT-program/eT!1278
- Workaround for false-positive recursive call error in MLHF with initial HF optimization. eT-program/eT!1290
- Fixed compilation with ifort 2021.9. eT-program/eT!1327
- Fixed reading of active space settings in hf. eT-program/eT!1341
- Fixed omp bug in fci where `n_threads` and `thread_n` need to be initialized in the routine not during declaration. eT-program/eT!1362
- Fixed bug where we could get 0 new trials in eigen davidson if
some roots were converged and others below the linear dependence threshold. eT-program/eT!1367
- Fixed memory estimate in `construct_cholesky_c1_ov`. eT-program/eT!1369
- Fixed management of the integral precision for libcint. eT-program/eT!1308
- Fixed uninitialized HF energy for MLCC CNTO construction. eT-program/eT!1395
- Fixed skipping of rohf for example when running fci afterwards. eT-program/eT!1398
- Fixed Cholesky memory leak (push-back). eT-program/eT!1407
- Fixing batching in nonlinear davidson and thresholds in restart_ccsd_skip_hf test. eT-program/eT!1414
- Fixed geometry optimization, by adding new convergence criteria. eT-program/eT!1276
- Fixed dimensions of some subroutine arrays and changed variable name to avoid name conflation in `eri_cd_class`. eT-program/eT!1463
- Fixed warnings caused by allocation of string arrays in input tool constructor. eT-program/eT!1485
- Fixed orbital enegies and coefficients after Newton-Raphson algorithm. eT-program/eT!1499
- Fixed uninitialized variable in UHF used in SAD construction. eT-program/eT!1503
- Fixed an incorrect AO-MO dimension in CCSD gradient code. eT_program/eT!1506
- Fixed qed polarizations reading. eT_program/eT!1514, eT_program/eT!1516
- Fixed the format of printed .cube files to be readable in Avogadro. eT_program/eT!1521
- Fixed `hf_magnetic_properties_solutions` file name being cut off. eT-program/eT!1546
- Fixed bug in CC2 where unallocated doubles multipliers were accessed. eT-program/eT!1553
- Fixed allocation length for strings passed to CC-ES amplitudes task constructor. eT-program/eT!1565
- Fixed dimensions of SC packed parameter dimensions. eT-program/eT!1566
- Fixed UHF and ROHF orbital energies and occupations for Molden files. eT-program/eT!1567
- Added missing Cholesky vector offload in `jacobian_lowmem_cc2`.  eT-program/eT!1568
- Updated PhasedInt (previously called cpint) interface. eT-program/eT!1536

### Tests
- Renamed all Lanczos spectrum files to `eT.*.out`. eT-program/eT!1148
- Renamed CC3 diis preconvergence test and removed `hf_file_check_tests`. eT-program/eT!1148
- Added --int32 to gfortran CI/CD test and fixed i32 bug in a unit test. eT-program/eT!1170
- Added test for EOM-CCSD and EOM-CC2 asymmetric polarizabilities. eT-program/eT!1135
- Removed keyword `name` from input and removed `name` from all tests. eT-program/eT!1211 eT-program/eT!1297
- Changed all permissions from 755 to 644. eT-program/eT!1262
- Removed `import os` from test scripts. eT-program/eT!1265
- Fixed libcint version checked out in the pipeline to v5.1.9. eT-program/eT!1267
- Updated code quality test in CI/CD to version 1.3.1. eT-program/eT!1270
- Updated libcint pipeline to use `-rcheck` flag. eT-program/eT!1270
- Made updates for GCC-11 compilers in Docker image. eT-program/eT!1287
- Added -g for gcov support in codecov uploader. eT-program/eT!1311
- Using pre-commit hooks to run black and check for trailing whitespace and empty lines at end of files. eT-program/eT!1329
- Trying to fix codecov uploading for development. eT-program/eT!1311, eT-program/eT!1332, eT-program/eT!1333, eT-program/eT!1334
- Separated `gitlab-ci.yml` into separate files and abstracted build and ctest jobs of eT. eT-program/eT!1345, eT-program/eT!1347,eT-program/eT!1387
- Enable scheduled pipelines testing different combinations of oei-lib and eri-lib in `gitlab-ci.yml`. eT-program/eT!1346, eT-program/eT!1348, eT-program/eT!1349
- Combine test of setup parameters (no-omp, rcheck, fbatch, int32) in single scheduled pipeline. eT-program/eT!1350
- Made fci and casci tests more robust. eT-program/eT!1361
- Updated Docker image, adding Libcint and cpint. eT-program/eT!1371
- Swapped from gcov for the coverage reports to gcovr and changed uploader to coveralls. eT-program/eT!1383, eT-program/eT!1385, eT-program/eT!1391, eT-program/eT!1455
- Change test for Edmiston-Ruedenberg orbital localization (molecular system and threshold). eT-program/eT!1406
- Changed Docker image and updated CMake/compilers for pipeline setup. eT-program/eT!1452, eT-program/eT!1483
- Tests for cc excited states and MM environments, eT-program/eT!1510
- Tests for dipole moments/excitation energies with CBO methods, eT-program/eT!1508
- Tests for dipole and quadrupole moments QED-HF. eT-program/eT!1522
- Test files have been named more consistently. eT-program/eT!1576
- Updated timing flags in TestseT.cmake. eT-program/eT!1571

### Printing and output
- Added a print of the spin symmetry in the es summary for CC. eT-program/eT!1182
- Added print settings routines to diis/davidson tools. eT-program/eT!1180
- Added error stop if triplet state ionization requested. eT-program/eT!1223
- Added error stop when unknown integrals are requested of the libint and libcint OEI tools. eT-program/eT!1269
- Added more timers to `davidson_tool_class`. eT-program/eT!1317
- Added an error stop if a running timer is turned on. eT-program/eT!1338
- Updated author list. eT-program/eT!1386
- `eT_launch` is now verbose by default and prints the pid of the subprocess it launches and flushes its prints. eT-program/eT!1392, eT-program/eT!1419
- Removed print of normalized dyson orbital because it is unstable for small norms. eT-program/eT!1405
- Left aligned element symbols in geometry print and aligned basis set print with element symbols. eT-program/eT!1418, eT-program/eT!1445
- Added banner for BFGS solver and Geoopt engine. eT-program/eT!1429
- Added error message if no atoms are specified in geometry section. eT-program/eT!1446
- Alingment of redundant internal coordinate print. eT-program/eT!1461
- Print of reduced space dimension in linear Davidson solver with multiple solutions. eT-program/eT!1468
- Print ES vectors for CC triplet states. eT-program/eT!1512
- Diagonal test for cholesky decomposition is now optional. eT-program/eT!1526
- Geometry optimizations now print the trajectory to an xyz file. eT-program/eT!1544
- Printing warning message about root duplication etc. in DIIS eigenvalue solver. eT-program/eT!1561
- Cleanup of rotatory strengths print TDHF and TD-QED-HF. eT-program/eT!1578
- Added error stops if left excitation is requested in CCSDT. eT-program/eT!1571
- Fix timestamp print. eT-program/eT!1573

### Cleanup
- Don't print python stack trace when something fails in `eT_launch.py` eT-program/eT!1556
- Replaced `d_d_4_m` with `d_d_4` in triplet Jacobian CCSD routine eT-program/eT!1208
- Implemented check for multiplicity keyword for UHF. eT-program/eT!1210
- Renamed variables 'side', 'transformation' and `r_or_l` to common variable name `left_or_right`. eT-program/eT!1214
- Section 'system' is no longer required in input. Default multiplicity is set to 1 and default charge to 0. eT-program/eT!1297, eT-program/eT!1325
- Clean-up of `frozen_orbitals_hf.F90`, and rename keyword `hf` in `frozen orbitals` to `localized`. eT-program/eT!1292
- Clean-up of `make_bath_orbital`. eT-program/eT!1304
- Clean-up of use statements in all the wavefunction classes and in the molecule folder. eT-program/eT!1313, eT-program/eT!1314, eT-program/eT!1343, eT-program/eT!1379
- Removed unused routine from `fci_eigenproblem_task_class`. eT-program/eT!1336
- Removed duplicate routine `generalized_diagonalization` from `array_utilities`. eT-program/eT!1342
- Moved `hf_energy` from wavefunction into ccs class and cleaned up cc initialization. eT-program/eT!1344
- Moved `oei 1der` subroutines into `abstract_oei_library_class`,  `eri first order giao` and `ri` subroutines into  `abstract_eri_library_class`. eT-program/eT!1360
- Renamed input sections from fci to ci and cleanup of use statements in fci. eT-program/eT!1361
- Moved `add_to_subblock` and `copy_subblock` routines to `reordering_r` and `array_initialization`. eT-program/eT!1377
- Removed unused subroutines in QED-FCI. eT-program/eT!1379
- Removed some unused routines and modules. eT-program/eT!1381
- Separated out determinant string utilities from FCI. eT-program/eT!1388, eT-program/eT!1400
- Changed intent(in) to intent(inout) in vector getters get-routines. eT-program/eT!1397
- Temporary files should now be removed by eT. eT-program/eT!1401
- Misc minor cleanup of comments and code. eT-program/eT!1411
- Abstract_vector_getter renamed to vector_getter. eT-program/eT!1413
- Removed unnecessary parantheses, e.g. around ``(wf%n_o)``. eT-program/eT!1417
- Changed names of integers in `redundant_internal_coordinates_class.F90` to avoid conflation with derived types. eT-program/eT!1444
- Moved ``frozen_core`` variable from ``wavefunction_class`` to ``hf_class``. eT-program/eT!1447
- Cleanup of derivative dipole integrals. eT-program/eT!1448
- Small restructure and cleanup of names in CCSD gradients. eT-program/eT!1458
- Removed unused variables hidden by `omp parallel` sections. eT-program/eT!1466
- Fixed some intents in `construct_es_2e_density_intermediates` and removed non-argument variables from interface of `calculate_spin_squared_qed_fci`. eT-program/eT!1467
- Add missing citation for CCSD gradients. eT-program/eT!1465
- Add missing ^2 to the qed_hf molecular gradient docs and make loop into dgemv. eT-program/eT!1470
- Initial run of ``fix_indent.py`` to fix code indentation. eT-program/eT!1480
- Initial run of ``fix_indent.py`` to fix comments indentation. eT-program/eT!1481
- ``fix_indent.py`` Now runs as pre-commit hook. eT-program/eT!1482
- Updated README description of LibXC installation. eT-program/eT!1490
- Updated README description of PCMSolver installation. eT-program/eT!1491
- Removed u_aibj from coupled cluster wavefunctions. eT-program/eT!1502
- Removed ``construct_right_transition_density_doubles``. eT-program/eT!1507
- Improve input keywords for (TD) HF response/es calculation to be consistent with CC and to allow for new keywords. eT-program/eT!1534, eT-program/eT!1542
- Removed unused variables from `magnetic_properties_hf.F90`. eT-program/eT!1546
- `setup.py` now returns non-zero exit code when configuration fails. eT-program/eT!1555
- Changed indices of states in transition moment table print. eT-program/eT!1575
- Restrict do section in the input file so that only one keyword pointing to an engine is allowed. eT-program/eT!1577

### Optimization
- Optimized CCSD Jacobian for triplet, dd7. eT-program/eT!/1209
- Intermediates for `d_d_8` and `d_d_9` for CCSD triplet Jacobians have been combined. eT-program/eT!1216
- Intermediates for d s 3, d s 4, d s 6 for CCSD triplets have been combined. eT-program/eT!1212
- Increased robustness of biorthogonalization subroutine. eT-program/eT!1220
- Memory optimization for OEI in MLHF. eT-program/eT!1221
- Added batching for FCI. eT-program/eT!1233 eT-program/eT!1335
- Optimized ``jacobian_transformation_doubles`` using contravariant doubles and cholesky vectors. eT-program/eT!1403
- Partially optimized ``jacobian_transpose_qed_ccsd`` to no longer need v^4 memory. eT-program/eT!1440 eT-program/eT!1454
- ``construct_ao_G_1der_hf`` now uses the G_builder, allowing for screening. eT-program/eT!1471
- Optimized interface to get nuclear_1der integrals using libcint. eT-program/eT!1475
- Optimized convergence SC-QED-HF by second order in eta parameters. eT-program/eT!1498
- Optimized ``get_eri_1der_libcint`` to remove redundancy in derivative integrals. eT-program/eT!1511
- Optimized low memory CC2 Jacobian by replacing c1 transformations of the integrals, by c1 transformations of the Cholesky vectors. eT-program/eT!1518, eT-program/eT!1519, eT-program/eT!1520
- Optimized cube file generator. eT-program/eT!1543
- SC-QED-HF convergence is more robust by projecting out eta redundancies. eT-program/eT!1557

### Documentation
- Updates to README. eT-program/eT!1247, eT-program/eT!1487
- Updated copyright year to 2023. eT-program/eT!1264, eT-program/eT!1302
- Added pipeline test to check copyright year. eT-program/eT!1302
- Fixed documentation in `ao_G_builder`. eT-program/eT!1266
- Remove routine names from routine banners. eT-program/eT!1340

## Compilers
- Removed support for deprecated Intel compilers. eT-program/eT!1268
- Fixed issues for gfortran-13 compilers. eT-program/eT!1364, eT-program/eT!1416 eT-program/eT!1451
- Added support for LLVM-based Intel compilers (icx, icpx, ifx). eT-program/eT!1399
- Fixed warning for gfortran-14 compilers. eT-program/eT!1440
- Make Boost dependency optional. eT-program/eT!1551
- Fix runtime error for gfortran-15 compiler. eT-program/eT!1562
- Add cmake policy for CMP0144, eT-program/eT!1569

## Development tools
- `update_copyright` now skips changelog.md. eT-program/eT!1305
- Added setup flag '-inan/--initialize-nan'. eT-program/eT!1393
- ``eT_launch.py`` now copies the ``fci_eigenvectors``. eT-program/eT!1398
- ``eT_launch.py`` can now save/load restart files to/from ``tar.gz`` archives. eT-program/eT!1402
- Added script testing that the website contains all the keywords our ``input_file.F90`` contains. eT-program/eT!1433 eT-program/eT!1453 eT-program/eT!1460
- Added script ``fix_indent.py`` which fixes the indentation level of code and comments. eT-program/eT!1480
- Fixed bug in ``fix_indent.py`` that crashed when variable names started with "type...". eT-program/eT!1530

# eT v1.9.13
### Bugfixes
- Revert eT-program/eT!1409, energy term FQ. eT-program/eT!1436

# eT v1.9.12
### Bugfixes
- Added missing energy term to FQ energy. eT-program/eT!1409

# eT v1.9.11
### Bugfixes
- Removed untested double batching in Davidson tool and unused routines. eT-program/eT!1309

# eT v1.9.10
### Bugfixes
- Fix: the `precision_threshold` in the `ao_G_builder_class` has been adjusted to align with the definition of integral precision, which is defined as the square of the `eri_cutoff`. eT-program/eT!1306

# eT v1.9.9
### Bugfixes
- Fixes error for batching in the `cholesky_eri_disk` class. Appeared only for the batching setup used in the `basis_transformation` of `abstract_eri_cholesky`. eT-program/eT!1296

# eT v1.9.8
### Tests
- Update runtest library to v2.3.3. eT-program/eT!1289
- The coefficients of all FCI states are now tested. eT-program/eT!1289

# eT v1.9.7
### Tests
- Make sure tests in master are run with GCC-8 Docker image. eT-program/eT!1286

# eT v1.9.6
### Bugfixes
- Fixed molden format such that molden files can be opened by avogadro. eT-program/eT!1272

# eT v1.9.5
### Bugfixes
- Fixed bug in FCI code when OpenMP is disabled. eT-program/eT!1249

# eT v1.9.4
### Bugfixes
- Fixed bug in G builder when OpenMP is disabled. eT-program/eT!1242

# eT v1.9.3
### Tests
- Updated pipeline to run the intel and gnu pipelines in parallel. eT-program/eT!1238

# eT v1.9.2
### Bugfixes
- Fixed large error in HF molecular gradient due to low presicion in libint integrals. eT-program/eT!1185

# eT v1.9.1
### Bugfixes
- Removed duplicate call to constructor or the `ao_eri_getter_tool` in `qed_hf_class.F90` to avoid memory issues. Change pointers to `ao_tool` and `qed_tool` from type to class. eT-program/eT!1173

# eT v1.9.0
### Features
- Added printing of orbital coefficients when orbitals are frozen or transformed to the MLCC basis. eT-program/eT!1102
- Added ploting of orbitals from CC wave functions. eT-program/eT!1102
- Added total and iteration timers to solvers. eT-program/eT!1109
- Added option to zero out arrays when allocating. eT-program/eT!1112
- Added option to to plot NTOs/CNTOs only for selected states. eT-program/eT!1126
- CCS triplet excitation energies. eT-program/eT!1046
- CC2 triplet excitation energies. eT-program/eT!1049
- Added option to set logical arrays to true/false when allocating. eT-program/eT!1128

### Structure
- Added separate engine for Lanczos and removed `cc_es_eigen_davidson_print_tool`. eT-program/eT!1095
- Removed unused routines in CCS and MLCCSD. eT-program/eT!1105
- Made all unformatted files stream files and removed unformatted sequential. eT-program/eT!1118, eT-program/eT!1132
- Restructured I/O classes moving more functionality into `abstract_file_class`. eT-program/eT!1118, eT-program/eT!1132
- Removed unused `abstract_hf_solver_class.F90`. eT-program/eT!1121
- Removed warnings from intel compilers. eT-program/eT!1128
- Response equations in CC theory are now solved using general Davidson solver. eT-program/eT!1133

### Tests
- Added checks for cube and auxiliary files to the time-dependent CC tests. eT-program/eT!1096
- Removed for loop over the inputs in the test scripts. eT-program/eT!1098
- Frozen HF tests with excitation energies and transition moments. eT-program/eT!1101
- Added unit test for z-matrix tool. eT-program/eT!1103
- Added restart test for CCS and 3-level MLCCSD tests. eT-program/eT!1105
- Simplified the use of keyword arguments in `filters.py`. eT-program/eT!1106

### Bugfixes
- Removed memory leaks in linked list class and main program. eT-program/eT!1139

### CI
- Updated version of `fortran-code-quality` to v1.3.0. eT-program/eT!1139
- CI now always runs python and fortran code-quality, but stops if one of these stages does not succeed. eT-program/eT!1140

# eT v1.8.10
### Features
- Reverted eT-program/eT!1127: Fixed eT interface to libint. eT-program/eT!1146

# eT v1.8.9
### Features
- Fixed eT interface to libint. eT-program/eT!1127

# eT v1.8.8
### Bugfixes
- Fixed bug where libint threw an error because of whitespace in the final lines of a basis set file by removing trailing whitespace from g94 files. eT-program/eT!1131

# eT v1.8.7
### Bugfixes
- Revert update of Libint library, as the eT compilation fails. eT-program/eT!1125
- Fixed debug print in `memory_tracker.F90` that crashed because it expected integers but received strings (eT-program/eT#586). eT-program/eT!1125
- Fixed segfault that appears in EOM properties with Intel 20.2.6 (eT-program/eT#586). eT-program/eT!1125

# eT v1.8.6
### Features
- Update of Libint library that ships with eT to include higher angular momentum. eT-program/eT!1119

# eT v1.8.5
### Bugfixes
- Fixed bug in the FCI linear transformation where $`E_{qp}`$ was applied instead of $`E_{pq}`$ . eT-program/eT!1115

# eT v1.8.4
### Bugfixes
- Fixed bug where visualizing the active hf density was giving a plot of the hf density. eT-program/eT!1113

# eT v1.8.3
### Bugfixes
- Fixed uninitialized `exists_frozen_fock_terms` in FCI. eT-program/eT!1110

# eT v1.8.2
### Bugfixes
- Fix construction of virtual Cholesky orbitals in 3-level MLCCSD. eT-program/eT!1107

# eT v1.8.1
### Bugfixes
- Fixes bug where keyword `coulomb exchange terms` was not read in MLHF. eT-program/eT!1104

# eT v1.8.0
### Features
- Added calculation of FCI densities and dipole and quadrupole tests. eT-program/eT!1087
- Frequency-dependent (and static) polarizabilities for HF. eT-program/eT!1054

### Structure
- Changed routines in parameters.F90 to increase covarage. eT-program/eT!1068
- Removed unused routines in stream\_file.F90. eT-program/eT!1069
- Removed unused routines in array\_utilities.F90. eT-program/eT!1071
- Restructured eT program and added factories for engines and wavefunctions. eT-program/eT!1074 and eT-program/eT!1080
- Remove frequency from transformation tool. Dummy frequencies removed from general linear and general eigen davidson solvers. eT-program/eT!1076
- Restructured eT program and added factories for engines and wavefunctions. eT-program/eT!1074
- `Transformation_tools` renamed to transformation. eT-program/eT!1054
- Davidson tool now counts the number of new trials. eT-program/eT!1089
- Introduced tools to build the G-matrix (two-electron contribution to Fock) or Coulomb and exchange matrices separately. eT-program/eT!870
- Restructured printing of mean values. eT-program/eT!1086
- Restructured FCI engine to use tasks. eT-program/eT!1087
- Restructured reference/HF engines to use task structure. eT-program/eT!1088
- Added factories for cc start vector and cc projection tools. eT-program/eT!1091
- Added storers that know how to store amplitudes. eT-program/eT!1092 eT-program/eT!1094

### Optimization
- Removed N^3 scaling from Fock construction visible for very large systems. eT-program/eT!870
- Linear exchange algorithm added (similar to LinK). eT-program/eT!870
- Non-scaling iterative Fock matrix construction and linear scaling non-iterative Fock matrix construction for MLHF. eT-program/eT!870

# eT v1.7.4
### Bugfixes
- Fixes problem with the use of bath orbitals when cc-in-hf (frozen hf) is used. Adding test with valence ionization and frozen hf. eT-program/eT!1084

# eT v1.7.3
### Bugfixes
- Fixed bug where python version 3.10 was wrongly recognized to be older than 3.6. eT-program/eT!1079

# eT v1.7.2
### Bugfixes
- Fixed bug in spin-multiplicities, where sum of squares was incorrectly assumed equal to square of sum. Happened only with -O0 flag. eT-program/eT!1072

# eT v1.7.1
### Bugfixes
- Fixed OpenMP bug where thread-integer was not private. Happened only with -O0 flag. eT-program/eT!1066

# eT v1.7.0
### Bugfixes
- QED keyword photons removed. eT-program/eT!1051

### Features
- Linear response now available at the CC2 level (polarizabilities and transition strengths). eT-program/eT!1039
- Restart for the Lanczos solver. eT-program/eT!1036
- FCI for ground and excited states of closed and open-shell systems. eT-program/eT!1060

### Tests
- Added unit tests for for untested routines in `tools/maps`. eT-program/eT!1035
- Added for plotting of the active hf density. eT-program/eT!1045

### Structure
- Cleanup of engines, by introducing tasks that are called from the engine. eT-program/eT!968, eT-program/eT!1040, eT-program/eT!1044
- Using the eigen_davidson_solver for the CC excited state equations instead of the cc_es_davidson_solver. The cc_es_davidson_solver is deleted. eT-program/eT!1038, eT-program/eT!1050
- Projection tools now ask CC wave functions to project out unwanted components. The projection vectors have been deleted. eT-program/eT!1048
- eT stops with error if there are no electrons. eT-program/eT!1061

# eT v1.6.4
### CI
- Updated black to version 22.3.0 because a dependency of black was updated making black 22.1.0 crash. eT-program/eT!1057

# eT v1.6.3
### Bugfixes
- Fixed integer overflow in `batch_setup`. The product of two `int32`
overflowed before being converted into `int64`. eT-program/eT!1053

# eT v1.6.2
### Bugfixes
- Fixed visualization with cartesian basis sets. eT-program/eT!1043

# eT v1.6.1
### README
- Updated README with information for libint and pcmsolver. eT-program/eT!1041

# eT v1.6.0
### Features
- Print tool for eigen and linear Davidson solvers. eT-program/eT!983
- Added timers for calculate energy. eT-program/eT!993
- Memory tracker now prints the batching tag and memory difference. eT-program/eT!1000
- References are now collected in eT_references.F90. eT-program/eT!1019
- Added timers for visualization. eT-program/eT!1024

### Optimization
- Coupled cluster Fock matrix construction is N^4 scaling. eT-program/eT!973
- Reduce memory usage for MLCC energy calculation (reusing CCS routine). eT-program/eT!974
- Optimized omega lowmemory CC2 using a similar algorithm as for CC3. eT-program/eT!986
- New Cholesky tools can now load blocks into memory to be used in e.g. integral construction. eT-program/eT!1015

### Structure
- New ERI and Cholesky vector tools. Autogeneration of complex tools. eT-program/eT!902
- Cleanup of use statements in solvers, molecule and observer. eT-program/eT!1012
- Fix typo in `construct_mo_basis_transformation`. eT-program/eT!1020
- Removed unused routines and added unit tests for `range_class` and `memory_manager`. eT-program/eT!1022
- Added abstract solver class. eT-program/eT!1018

### Tests
- Code quality pipeline now detects unexpected indentation level in Fortran source files. eT-program/eT!1017
- QED-HF tests are now run with default print level. eT-program/eT!1023

# eT v1.5.15
### Bugfixes
- Fixed bug where LR polarizabilities would be incorrect in cases where non-diagonal contributions are requested without the associated diagonal contributions. eT-program/eT!1025
### CI
- Now using Black version 22.1.0. eT-program/eT!1028

# eT v1.5.14
### Tests
- Intel CI stage (like GNU) split into two jobs: build and run. eT-program/eT!1014

# eT v1.5.13
### Tests
- Intel CI stage now runs in merge requests, and compressed the build and release stages. eT-program/eT!1009

# eT v1.5.12
### Tests
- Added stage to test Intel compilers (ifort/icpc) in Gitlab CI/CD. eT-program/eT!1004

# eT v1.5.11
### Bugfixes
- Fixed format in call to printf in `eri_cd_class.F90`. eT-program/eT!1001

# eT v1.5.10
### Bugfixes
- Fixed memory estimate in `construct_cholesky_t1_oo`. eT-program/eT!998

# eT v1.5.9
### Tests
- Fix gcov call for MKL-Ubuntu Docker image. eT-program/eT!996

# eT v1.5.8
### Tests
- Fix verification of codecov uploader for MKL-Ubuntu Docker image. eT-program/eT!995

# eT v1.5.7
### Tests
- Updated CI/CD setup to use MKL-Ubuntu Docker image and adapt to dedicated eT test machine. eT-program/eT!992

# eT v1.5.6
### License
- Updated Readme and added license to `index_invert`. eT-program/eT!990

# eT v1.5.5
### Copyright
- Updated copyright year to 2022. eT-program/eT!988

# eT v1.5.4
### Bugfixes
- Circumvented intel segmentation violation by removing use statements for types in submodules again. eT-program/eT!987

# eT v1.5.3
### Bugfixes
- Fixed bugs that appear at -O0 optimization level, and added -O0 to coverage pipelines. eT-program/eT!982

# eT v1.5.2
### Bugfixes
- Coverage files produced for codecov code coverage. eT-program/eT!979

# eT v1.5.1
### Bugfixes
- Update submodules again. eT-program/eT!977

# eT v1.5.0

### Bugfixes
- Two workarounds added to circumvent bugs in the Intel compiler (ifort). File destructors no longer check whether the file is open. Two OpenMP loops are incorrectly optimized with -O3 and have been modified to circumvent incorrect compiler optimization. eT-program/eT!936
- Disk storage default for davidson solver to obtain multipliers. eT-program/eT!942
- `max_dim_red` of excited state Davidson solvers is now set to `max(100,10*n_singlet_states)` after the number of singlet states have been read from input. eT-program/eT!932

### Features
- Using orthogonal AO (OAO) basis for HF/UHF gradient in Roothan-Hall SCF solver. eT-program/eT!914
- When the code is batching a tag will be printed now for verbose print level. eT-program/eT!919
- Now possible to specify start guesses for excited states as `state guesses: {i=1,a=2}, {i=1,a=3}, ...`. eT-program/eT!933
- Convergence testing now with tolerance of +-1, to avoid fails due to numerics. eT-program/eT!938
- Added CI pipeline that runs a simple program to parse the Fortran code and identify various code-issues. eT-program/eT!937
- Added check for close lying/overlapping atoms. eT-program/eT!943
- Added new reference method: QED Hartree-Fock (qed-hf). eT-program/eT!941
- Added basis sets ccX-nZ basis sets. eT-program/eT!955
- ROHF and CUHF. eT-program/eT!957
- Cartesian BFGS geometry optimization solver (for Hartree-Fock theory) replaced by a more robust BFGS solver that uses redundant internal coordinates. eT-program/eT!918
- Multimodel CCSD/CC2 is now available for the ground state amplitudes. eT-program/eT!950

### Structure
- Moved the SCF preparations for HF outside of SCF solver. eT-program/eT!908
- Merged the `abstract_convergence_tool` and the `convergence_tool` classes. eT-program/eT!909
- SAD handled in the sad\_tool\_class. eT-program/eT!926
- Removed unused routines in reordering. eT-program/eT!939
- Moved a Fock matrix term from CCSD Jacobian into doubles Jacobian. eT-program/eT!949
- G(D) definition changed to (2g\_wxyz - g\_wzyx)D\_yz.  eT-program/eT!964
- Cleanup of use statements in HF hierarchy. eT-program/eT!966
- Removed unused routine in abstract\_file\_class.F90. eT-program/eT!967
- Cleanup of use statements in CC hierarchy. eT-program/eT!969
- No module imports all reordering and array utilities anymore. eT-program/eT!970
- Added unit tests for angular momentum class. eT-program/eT!972

### Optimization
- One-electron and effective contributions to the CC-Fock matrix are now calculated once instead of multiple times per Fock construction. eT-program/eT!925
- Removed an unnecessary non-iterative o3v3 term (the G2-2 intermediate) as well as an iterative o3v3 term in CCSD Jacobian transpose G2. eT-program/eT!946
- Removed two o3v3 terms and an unnecessary g\_ovvv construction in CCSD Jacobian transpose G1. eT-program/eT!944
- Removed an o3v3 term in CCSD Jacobian transpose B2. eT-program/eT!945
- Removed an unnecessary o3v3 term in CCSD Jacobian transpose C2. eT-program/eT!946
- Removed an o3v3 term in Jacobian CCSD D2 and reduced integral costs in the term. eT-program/eT!951
- Replaced an o1v3nJ by an o2v2nJ contraction in Jacobian transpose doubles B1. eT-program/eT!948
- Removed an iterative and a non-iterative o3v3 term in CCSD Jacobian H2. eT-program/eT!958
- Pipeline runs every n-th test (n: number of threads) starting with test i (i: thread number). eT-program/eT!960
- Reduced size of Lanczos test for valence states. eT-program/eT!960
- Removed an o3v3 term in CCSD Jacobian I2. eT-program/eT!959

# eT v1.4.4
### Bugfixes
- Find substring in string also if it contains the last character. eT-program/eT!952

# eT v1.4.3
### Bugfixes
- Update list of authors. eT-program/eT!927

# eT v1.4.2
### Bugfixes
- Fixed bug that made it impossible to enable the forced batching expert option. eT-program/eT!916

# eT v1.4.1
### Bugfixes
- Changed warnings about wrong memory estimates to verbose prints. eT-program/eT!911

# eT v1.4.0

### Bugfixes
- Fixed some errors in memory handling that can occur for large systems and/or on machines with limited memory resources. eT-program/eT!852

### Features
- Timers for Fock matrix construction for coupled cluster. eT-program/eT!849
- `cc_propagation` and `complex_fft` file names are now starting with `output_name.*` and automatically copied to the output directory. eT-program/eT!854
- Added option to plot CNTOs and NTOs. eT-program/eT!816
- Runtime check for reading of non-existing keywords/sections. eT-program/eT!872
- Runtime check that keywords have been defined for sections. eT-program/eT!878
- TDHF (RPA/Tamm-Dancoff) excitation energies implemented for RHF. eT-program/eT!809
- Restart for TDHF (RPA/Tamm-Dancoff) excitation energies. eT-program/eT!883
- Added support for unit testing with pFUnit package. eT-program/eT!787
- Minor changes to memory-handling to improve testability of memory-batching. eT-program/eT!852
- New layout for timings.out file eT-program/eT!891
- Now possible to run linear response calculations at the CCSD level. eT-program/eT!890
- Default algorithm for ground state in CC3 changed to multimodel Newton. eT-program/eT!892
- Full and multimodel Newton-Raphson algorithm now available for ground state multipliers. The default algorithm for CC3 is changed from DIIS to multimodel Newton. eT-program/eT!895
- Jacobian transpose transformation for CCS with Cholesky vectors, scaling is N^4. eT-program/eT!897
- SAD can now run with charges on atoms. eT-program/eT!832

### Optimization
- Adding option for overlap screening to CC calculation of one electron integral. eT-program/eT!851
- Record storers now delete their file when finalized is called. eT-program/eT!893
- Optimization of E1 term in the CCSD Jacobian transpose transformation. eT-program/eT!896

### Structure
- Added block class using the range class. Facilitates the handling of multiple index ranges. eT-program/eT!823
- Angular momentum tools handle components of the angular momenta. eT-program/eT!864
- Generalized davidson solver for linear equations. eT-program/eT!901

# eT v1.3.9
### Bugfixes
- Updated Readme with `setup.py` and `eT_launch.py`. eT-program/eT!887

# eT v1.3.8
### Bugfixes
- Fix bug with pure gaussians. eT-program/eT!884

# eT v1.3.7
### Bugfixes
- Remove convergence check for cc2 test with davidson preconvergence. eT-program/eT!881

# eT v1.3.6
### Bugfixes
- Basis specification for atom subsets is now possible again. eT-program/eT!880

# eT v1.3.5
### Bugfixes
- Missing keyword (one-electron integral cutoff) added to the input file class. eT-program/eT!874

# eT v1.3.4
### Bugfixes
- Bug with reordering of atoms with both active spaces and several different basis sets was fixed. eT-program/eT!868

# eT v1.3.3
### Bugfixes
- Ordering of AOs for spherical gaussians fixed in the orbital files. eT-program/eT!857
- Molden file now contains correctly normalized orbital coefficients. eT-program/eT!857

# eT v1.3.2
### Bugfixes
- Read response vector tk for polarizabilities when needed for either diagonal or cross terms, to avoid cross terms from uninitialized array. eT-program/eT!856

# eT v1.3.1
### Bugfixes
- Newlines added in release script for correct formatting of release notes. eT-program/eT!846

# eT v1.3.0
### Bugfixes
- Removed option to accumulate and erase history in DIIS. These features were not working properly. eT-program/eT!800
- Keyword `pure gaussians` is now correctly read and enabled. eT-program/eT!810
- Added check for 'end geometry' in input file. eT-program/eT!825
- Added check for no calculation specified on input. eT-program/eT!831

### Features
- Added multimodel Newton-Raphson capability to ground state Newton-Raphson solver. Can be used to converge amplitudes in CC2 and CC3. eT-program/eT!759
- EOM polarizabilities are now available for CC2. eT-program/eT!761
- Consistent copying of all output files. They will now be copied to the same directory as output file. eT-program/eT!763
- Possible to specify output file, executable, savedir, loaddir, loadv1.0dir and pcm input file for each input file. eT-program/eT!763
- `eT_launch.py` now more tolerant of number of inputs and will use defaults or give a warning if they don't match the number of input files. eT-program/eT!763
- Changed `convert_v1_0_restart_files.py` script to not delete the old files and it can now be called from `eT_launch.py` using `--load-v1-0-restart-dir`. eT-program/eT!763
- `-i-err` changed to  `-i`. (`-i-err` retained for backwardness). eT-program/eT!763
- Possible to tell `eT_launch.py` to gracefully terminate eT using signals (`--signals`) or timeout (`--timeout`). eT-program/eT!763, eT-program/eT!820
- Z-matrix tool can convert between xyz coordinates and Z-matrix. eT-program/eT!619
- Davidson excited state solver can now handle cases where a requested root forms a complex pair with a higher root before convergence is reached (i.e., a false-positive complex pair); we thus avoid the commonly encountered "add one more root" error. eT-program/eT!772
- Biorthonormalization works for a set of close states as well. eT-program/eT!775
- Option to write a molden file containing HF data. eT-program/eT!788
- Added printing of implementation references, and the associated keyword `full references` in the `print` section. eT-program/eT!773
- Made autogenerate script compatible with Python 3.6 (UTF-8 encoding error). eT-program/eT!794
- Added `ghost` atoms. eT-program/eT!795
- Added `remove core` projection to CC3. eT-program/eT!804
- Excited state properties and oscillator strengths between excited states can be calculated. eT-program/eT!785
- Added timings for each iteration in the excited state solvers. eT-program/eT!834
- Renamed input files in tests the directories to agree with the name of the directory. eT-program/eT!833

### Optimization
- One-electron integrals with screening based on the overlap matrix. eT-program/eT!770

### Structure
- The test scripts now uses pathlib instead of os. eT-program/eT!756
- Changed names of `setup` and `eT_launch` to `setup.py` and `eT_launch.py` so they can be imported into python. eT-program/eT!763
- Changed output file names to all start with `eT.*` and `eT_launch.py` renames them to `output_name.*`. eT-program/eT!763
- Removed `check_alloc.py`. eT-program/eT!763
- Cholesky orbital tool now handles decomposition of densities to get orbitals. eT-program/eT!762
- Fixed warnings from intel compilers, renaming `autogenerated_complex_files` to `generated_complex_files`. eT-program/eT!786
- Replaced interval class with more general range class. eT-program/eT!817
- Updated Fortran version to 2018 standard. eT-program/eT!836

# eT v1.2.5
### Bugfixes
- The `req_single_batch` in `calculate_energy_ccs` is now passed as `req_single_batch` instead of `element_size`. eT-program/eT!835

# eT v1.2.4
### Bugfixes
- Engines are passed by reference in oei.cpp to avoid copy of engine for each call to the `construct_oei` routine (done for each shell pair).eT-program/eT!821
- Fixed memory required for a single batch in `omega_ccsd_a2`. eT-program/eT!818

# eT v1.2.3
### Bugfixes
- Reduced threshold in `xenon` test to 1.0d-9 due to instabilities. See merge request eT-program/eT!782

# eT v1.2.2
### Bugfixes
- Testing that the number of electrons is even for restricted closed calculations. See merge request eT-program/eT!777

# eT v1.2.1
### Bugfixes
- Reduced threshold in `uhf_energy_cs` to 1.0d-10 due to instabilities. See merge request eT-program/eT!766

# eT v1.2.0
### Bugfixes
- Added handling of zero length character prints. See merge request eT-program/eT!716

### Features
- printf accepts complex numbers and possible to repeat formats. See merge request eT-program/eT!674
- UHF spin contamination is computed and printed in all UHF calculations. See merge request eT-program/eT!675
- Tidied up Omega and Jacobian timings to make them more consistent. See merge request eT-program/eT!684
- SAD guess can be used for elements up to Dubnium. See merge request eT-program/eT!707
- Frozen core can be used for elements up to Dubnium. See merge request eT-program/eT!709
- `eT_launch` now returns the lanczos files. See merge request eT-program/eT!710
- Gaussian .cube format for density and orbital visualization. See merge request eT-program/eT!603
- Specific cores can now be removed (by projection) in CC valence excited states. See merge request eT-program/eT!713
- Default threshold to check for degenerate states reduced to 1.0d-3. See merge request eT-program/eT!724
- Parallel excited states are now removed from the wavefunction if found eT-program/eT!717
- Added keyword to control storage in micro iterations of Newton-Raphson ground state solver (`micro iterations storage`). See merge request eT-program/eT!651
- Non-linear davidson: minimal threshold in the microiterations set to half the residual threshold. See merge request eT-program/eT!738
- The conversion script removes `scf_restart_file` and `cc_restart_file` after it has been used. See merge request eT-program/eT!745

### Optimization
- Fock matrix construction at CC level, in terms of T1-transformed integrals, is now N^4 scaling. Only the necessary blocks for a given task are constructed. See merge request eT-program/eT!678
- Removed one construction of the Coulomb fock matrix per iteration. See merge request eT-program/eT!677
- CCS Jacobian is now N^4 scaling (Cholesky vector algorithm) See merge request eT-program/eT!592
- CCS energy is now N^4 scaling (Cholesky vector algorithm) See merge request eT-program/eT!715
- CC3 optimization using covariant/contravariant amplitudes and integrals are resorted on the fly. See merge request eT-program/eT!685
- Non-linear davidson now default solver for CC3 and low-mem CC2. See merge request eT-program/eT!724
- Only necessary (vv|vv) integrals computed in CCSD and transpose Jacobian transformation now uses the optimized v^4o^2 routine. See merge request eT-program/eT!711
- Some cleanup in C2 and D2 terms in CCSD. See merge request eT-program/eT!727
- ERI tools use xsyrk to compute symmetric integrals. See merge request eT-program/eT!730

### Structure
- Omega and Jacobian routines have separate in and out vectors and call the corresponding parent routines. See merge request eT-program/eT!684
- An AO tool is added that handles the basis set, AO integral construction, and  all communication with Libint; replaces the molecular system class
- The MM and PCM code is restructured in a hierarchy of embedding/environment classes. Wave function classes and embedding classes are more decoupled.
- Input file routines for keywords and sections have been shortened, with some additional cleanup of input variables/routines. See merge request eT-program/eT!705.
- Autogenerated directories and interfaces are now ignored by git. They are generated by the `setup` or the `autogenerate_files` script. See merge request eT-program/eT!706
- A single SCF solver now handles all SCF calculations, it can be used with different types of convergence acceleration (none, DIIS, CROP). See merge request eT-program/eT!654
- Removed some unused routines from reordering and array utilities. See merge request eT-program/eT!725
- Newton-Raphson solver for coupled cluster ground state is now handled by the same solver as the default DIIS solver. See merge request eT-program/eT!651
- Optimized the autogenerate script and added functionality to generate complex modules from real modules. See merge request eT-program/eT!735


# eT v1.1.3
### Structure
- Made Python script to update all test refences and updated the files. See merge request eT-program/eT!746


# eT v1.1.2
### Bugfixes
- Fixed incorrect memory estimate in Jacobian transpose ccsd. See merge request eT-program/eT!718


# eT v1.1.1
### Features
- Functionality added for skipping SCF if equations are solved.
  Restart between 1.0.x and 1.1 now possible with the conversion script. See merge request eT-program/eT!683
- Global restart keyword for `scf geoopt`. See merge request eT-program/eT!693

### Structure
- `mo_information_file` now part of `hf_class` as workaround for ifort segfault. See merge request eT-program/eT!681


# eT v1.1.0
### Bugfixes
- Fixed bug in EOM when $`n_o > n_v`$
- Fixed wrong allocation in expectation value engine
- Fixed wrong memory estimate for doubles A1 term, CCSD A2 term, and CCSD E1 (Jacobian transpose)
- File needed for restart in MLHF no longer deleted
- Threshold in biorthonormalization no longer squared
- Fixed the linear dependence threshold for all davidson solvers, the threshold is now 1.0d-11 or lower.
- Fixed wrong dimension of optwork in eigen\_davidson\_tool to comply with gfortran10
- If $`e^T`$ is compiled with 32bit integers, it will check that the number of MOs does not exceed 215
  so that $`n_{MO}^4`$ can be stored in an integer.
- Fixed the useage of 32bit integers in the batching setup.
- Fixed a bug with intel compilers where we could not use printf to print two chars returned by two different functions.
- Fixed bug where the linear dependence threshold could be larger than the residual threshold.
- The label in the print of the largest amplitudes was changed from 'r' to 'tbar' for the multipliers.
- Fixed basis of plotted CC density matrix (t1 to MO)
- Fixed batching estimate in Jacobian D1 doubles
- Moved opening of time-dependent CC files out of constructor
- Fixed copying of HF energy when initializing CC wavefunction
- Removed memory leak in visualization class
- Fixed diagonal scaling factor in CC3 (affects transition moments)
- Sanity checks in Davidson CC ES solver, and changed default for linear dependency threshold that could cause issues in rare cases
- Cluster amplitudes now stored to disk in each iteration of the Newton-Raphson ground state solver
- Fixed Gram-Schmidt biorthonormalization bug that may appear in rare cases for degenerate states (not observed in practice)
- Fixed memory leaks in visualization\_tool, some of which were intel-specific
- Fixed print for oscillator strenths, they are now unitless
- Fixed uninitialized variable field%separation when not specified in input
- Added missing frozen-core contributions to CC dipoles and quadrupoles

### Features
- Integral screening in MLHF for inactive density
- MLCCSD GS, right ES with NTO, CNTO, PAO and Cholesky orbitals and CVS
- Non-linear Davidson solver for CC2 and CC3
- Now possible to do only Cholesky decomposition
- Visualization of CC ground state density and transition densities
- Restart functionality was added to MLCCSD.
- Convention enforced that largest element of an eigenvector from LAPACK has a positive sign.
- Estimate for the maximum amount of memory used printed at the end of the execution.
- Added CMake command to CMake output
- Now possible to restart singles and doubles from singles, and vice versa (e.g. CCS from CCSD and vice versa)
- Now possible to do global restart instead of specifying restart for each individual solver
- Added restart left from right and vice vers with the correct transformation of the basis
- Now possible to run calculations beyond Calcium
- Changes to default thresholds to avoid overly tight thresholds unless requested
- Improved help messages from setup script and added documentation for fortran flags
- Sign of converged Hartree-Fock orbitals are deterministic.
- Minimal Python version is 3.6
- Added additional authors and a reference to the paper to the output
- Added compilation information to the beginning of the output
- Restart added for CNTO orbitals

### Optimization
- Removed unnecessary reordering in Jacobian doubles
- Batching functionality was added to the construction of CNTOs in multilevel coupled cluster.
- Added batching to CCS energy calculation to reduce memory requirement
- Introduced batching in DIIS and Davidson and record storers to minimize copy-operations
- Cholesky vectors are now stored according to occupied-virtual blocks to improve copy/write/read performance
- Reduced prefactor of CC2 and MLCC2 ground state and Jacobian transformation equations by use of the Cholesky vector expression rather than ERIs.
- Reduced prefactor of CC3 Jacobian transpose transformation equations by use of the Cholesky vector expression.
- Reduced prefactor of CCSD and MLCCSD ground state equations by use of the Cholesky vector expression rather than ERIs.
- Removed unnecessary reorderings from CCSD Jacobian transformation

### Structure
- Wavefunction constructors and init routines
- Implemented stream and direct stream files
- Input file read only once
- Removed direct access files
- Geometry now passed to libint in memory
- Record storers for records in memory or on file implemented and used in Davidson
- Improved error messages in memory manager
- The ground state engine now gives an error message if the selected algorithm is not recognized.
- Cleanup and generalization of the biorthogonalization routine
- The vector csiX in the eom/response modules was renamed to xiX according to the greek letter.
- Some improvements in how the autogenerate interfaces Python script recognizes submodules and deals with ampersand, and some restructuring of the script
- Removed direct\_file object
- Excited states are stored in separate stream files which are stored as an array of files in eT.
- Stream files are used for amplitudes and multipliers.
- Separated out convergence tests for solvers into convergence\_tool
- runtest now has a separate file that defines filters
- Python code follows the black code style
- Additional davidson timers

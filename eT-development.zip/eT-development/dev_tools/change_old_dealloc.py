#!/usr/bin/env python3
#
#  Simple script to change all the mem%dealloc(array, ....)
#  into mem%dealloc(array)
#
#  Written by Marco Scavino, 2022
#
#  Please, report me if any memory leaks raise after running the tests
#

import os
from pathlib import Path
from tempfile import TemporaryFile
import subprocess as sp
import sys
from typing import TextIO

from argparse import ArgumentParser

MAIN_DIRECTORY = Path(__file__).resolve().parents[1]


def parse_arguments():
    parser = ArgumentParser()
    parser.add_argument("files", nargs="*", help="File(s) to cleanup", default=[])
    parser.add_argument(
        "--directory", "-d", help="Directory to change", default=MAIN_DIRECTORY
    )
    parser.add_argument(
        "--force",
        "-f",
        help="Force to run (ignore git check of uncommited files)",
        action="store_true",
    )

    return parser.parse_args()


def check_if_all_commited() -> bool:
    """Chek if all recent change are commited.
    Return False if there are still file to be commited or staged
    """
    proc = sp.run(["git", "status", "src"], stdout=sp.PIPE, stderr=sp.PIPE)
    if proc.returncode == 0:
        return not (
            b"Changes not staged for commit" in proc.stdout
            or b"Changes to be committed" in proc.stdout
        )

    return False


def peek_line(f_in: TextIO) -> str:
    """
    Peek the next line.
    The cursor in file will be set to current line and next line will not be consumed
    """
    pos = f_in.tell()
    line = f_in.readline()
    f_in.seek(pos)
    return line


def gobble_breakline(f_in: TextIO, line: str):
    complete_line = []
    while True:
        if "&" not in line:
            complete_line.append(line)
            break
        idx_break = line.find("&")
        complete_line.append(line[:idx_break])

        line = f_in.readline()

    return "".join(complete_line)


def replace_deallocate(filename: Path):
    print(filename)
    with filename.open("r+") as f, TemporaryFile("w+") as f_tmp:
        with filename.open("r") as f:
            while True:
                line = f.readline()
                if not line:
                    break

                if not line.strip().startswith("!") and "mem%dealloc" in line:
                    line = gobble_breakline(f, line)
                    idx = line.find(",")
                    if idx != -1:
                        f_tmp.write(f"{line[:idx]})\n")
                    else:
                        f_tmp.write(line)

                else:
                    f_tmp.write(line)

        f_tmp.seek(0)
        # Overwrite the original file
        with filename.open("w") as f:
            f.write(f_tmp.read())


def main():
    os.chdir(MAIN_DIRECTORY)

    args = parse_arguments()

    if not args.force and not check_if_all_commited():
        print('\033[1;31mFound file(s) in "src" not commited!\033[0m')
        print(
            'Please commit all the file and re-launch the script or use the "-f,--force" flag.'
        )
        print(
            "It will change all the \033[1mmem%dealloc(array, m, ...)\033[0m to \033[1mmem%dealloc(array)\033[0m"
        )
        sys.exit(1)

    print("Changing all the mem%dealloc(array, n, ...) to mem%dealloc(array)")
    print(f'SRC: "{MAIN_DIRECTORY}/src"\n')
    print(
        f"\033[1;31mWARNING: It's possible that some memory leaks will appear.\033[0m"
    )
    print(
        "For example allocatable arrays that are reassigned with an array of different size\n\n"
        "   real(dp), allocatable, dimension(:) :: A, B\n"
        "   call mem%alloc(A, 20)\n"
        "   call mem%alloc(B, 10)\n"
        "   A = B(1:10)"
    )

    answer = input("\nAre you sure to continue? (y/n) ")
    if answer.lower() != "y":
        return

    files = list((MAIN_DIRECTORY / "src").rglob("**/*.F90"))

    if args.files:
        selected = set(f for f in args.files)

        files = [f for f in files if any(s in str(f) for s in selected)]

    for f in files:
        replace_deallocate(f)


if __name__ == "__main__":
    main()

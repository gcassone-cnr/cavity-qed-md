#
#
#  eT - a coupled cluster program
#  Copyright (C) 2016-2026 the authors of eT
#
#  eT is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  eT is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.
#

"""Unit tests for autogenerate_files.py"""

import sys
from pathlib import Path

# Add dev_tools to path for imports when running from project root
sys.path.insert(0, str(Path(__file__).resolve().parent))

from autogenerate_files import (
    complexify_line,
    create_complexify_state,
    replace_optional_parameter,
)


def test_complexify_line_batch_setup_multiline_closing_paren():
    """Multi-line batch_setup with ) on its own line: parameter added to batch_setup."""
    # Simulate the problematic pattern: batch_setup spans lines, ) on own line
    lines = [
        "      call mem%batch_setup(                   &\n",
        "         batch_i,                             &\n",
        "         batch_j,                             &\n",
        "         req0,                                &\n",
        "         req1_i,                              &\n",
        "         req1_j,                              &\n",
        "         req2,                                &\n",
        "         req_single_batch = req_single_batch, &\n",
        "         tag = 'calculate_energy_ccs 2'       &\n",
        "      )\n",
        "\n",
        "      do current_i_batch = 1, batch_i%num_batches\n",
        "\n",
        "         call batch_i%determine_limits(current_i_batch)\n",
    ]
    parameter_list = []
    state = create_complexify_state()
    output_lines = []
    for line in lines:
        out, state = complexify_line(line, parameter_list, state)
        output_lines.append(out)

    # batch_setup closing ) line should have element_size added
    closing_paren_line = output_lines[9]  # "      )\n"
    assert closing_paren_line.strip() == "), element_size=2*dp"

    # determine_limits line must NOT have element_size added
    # "         call batch_i%determine_limits..."
    determine_limits_line = output_lines[13]
    assert "element_size" not in determine_limits_line
    assert "call batch_i%determine_limits(current_i_batch)" in determine_limits_line


def test_complexify_line_batch_setup_single_line_adds_element_size():
    """Single-line batch_setup call should get element_size added on same line."""
    line = (
        "      call mem%batch_setup(batch_j, req0, req1_j, "
        "tag='construct_fock_ia_t1_ccs_3')\n"
    )

    output_line, state = complexify_line(line, [], create_complexify_state())

    assert state == {"active_call": None}
    assert "mem%batch_setup" in output_line
    assert "element_size=2*dp" in output_line


def test_replace_optional_parameter_does_not_modify_unrelated_call_line():
    """Continuation scanning should not attach parameter to unrelated call lines."""
    line = "         call batch_i%determine_limits(current_i_batch)\n"

    output_line, check_next = replace_optional_parameter(
        line, r"element_size\s*=\s*dp", "element_size=2*dp"
    )

    assert check_next is True
    assert output_line == line


def test_complexify_line_pending_element_size_does_not_modify_declaration():
    """Pending element_size scan must not alter subroutine declarations."""
    line = "   module subroutine prepare_for_multiplier_equation_ccs_complex(wf)\n"

    output_line, state = complexify_line(line, [], {"active_call": "batch_setup"})

    assert output_line == line
    assert state == {"active_call": None}


def test_complexify_line_ignores_comment_only_batch_setup_marker():
    """Comment lines with mem%batch_setup should not activate continuation state."""
    line = "      ! mem%batch_setup(batch_i)\n"

    output_line, state = complexify_line(line, [], create_complexify_state())

    assert output_line == line
    assert state == {"active_call": None}


def test_complexify_line_pending_element_size_still_complexifies_reordering_module():
    """Pending element_size scan should not block module-name complexification."""
    line = "      use reordering_r, only: add_132_to_123\n"

    output_line, state = complexify_line(line, [], {"active_call": "batch_setup"})

    assert output_line == "      use reordering_c, only: add_132_to_123\n"
    assert state == {"active_call": "batch_setup"}


def test_replace_optional_parameter_preserves_trailing_comment():
    """Standalone closing parenthesis with trailing comment should be updated."""
    line = "      ) ! closing batch setup\n"

    output_line, check_next = replace_optional_parameter(
        line, r"element_size\s*=\s*dp", "element_size=2*dp"
    )

    assert check_next is False
    assert output_line == "      ), element_size=2*dp ! closing batch setup\n"


def test_complexify_line_direct_stream_multiline_adds_word_size():
    """direct_stream_file continuation should still add word_size on closing line."""
    lines = [
        "      X_file = direct_stream_file(           &\n",
        "         'X_J_vo',                           &\n",
        "         n_records                           &\n",
        "      )\n",
    ]

    state = create_complexify_state()
    output_lines = []
    for line in lines:
        out, state = complexify_line(line, [], state)
        output_lines.append(out)

    assert "word_size=2*dp" in output_lines[3]


def test_complexify_line_multiple_reordering_imports_are_all_complexified():
    """All reordering imports should be complexified while continuation is active."""
    lines = [
        "      call mem%batch_setup(                  &\n",
        "         batch_i,                            &\n",
        "         req0,                               &\n",
        "      use reordering_r, only: sort_to_132\n",
        "      use reordering_r, only: add_132_to_123\n",
        "      use reordering_r, only: sort_to_321\n",
        "      )\n",
    ]

    state = create_complexify_state()
    output_lines = []
    for line in lines:
        out, state = complexify_line(line, [], state)
        output_lines.append(out)

    assert output_lines[3] == "      use reordering_c, only: sort_to_132\n"
    assert output_lines[4] == "      use reordering_c, only: add_132_to_123\n"
    assert output_lines[5] == "      use reordering_c, only: sort_to_321\n"
    assert output_lines[6].strip() == "), element_size=2*dp"
    assert state == {"active_call": None}


def test_complexify_line_resets_malformed_continuation_at_routine_boundary():
    """Malformed continuation must not leak across subroutine boundaries."""
    lines = [
        "      call mem%batch_setup(                  &\n",
        "         req0,                               &\n",
        "   end subroutine foo\n",
        "   module subroutine bar()\n",
        "      use reordering_r, only: sort_to_132\n",
    ]

    state = create_complexify_state()
    output_lines = []
    for line in lines:
        out, state = complexify_line(line, [], state)
        output_lines.append(out)

    assert output_lines[2] == "   end subroutine foo\n"
    assert output_lines[3] == "   module subroutine bar()\n"
    assert output_lines[4] == "      use reordering_c, only: sort_to_132\n"
    assert state == {"active_call": None}


def test_complexify_line_integration_interleaved_calls_and_imports():
    """Interleaved call continuations should still produce deterministic imports."""
    lines = [
        "      call mem%batch_setup(                  &\n",
        "         req0,                               &\n",
        "      use reordering_r, only: sort_to_132\n",
        "      )\n",
        "      X_file = direct_stream_file(          &\n",
        "         'tmp',                              &\n",
        "      use reordering_r, only: add_132_to_123\n",
        "      use reordering_r, only: sort_to_321\n",
        "      )\n",
    ]

    state = create_complexify_state()
    output_lines = []
    for line in lines:
        out, state = complexify_line(line, [], state)
        output_lines.append(out)

    assert output_lines[2] == "      use reordering_c, only: sort_to_132\n"
    assert output_lines[6] == "      use reordering_c, only: add_132_to_123\n"
    assert output_lines[7] == "      use reordering_c, only: sort_to_321\n"
    assert "element_size=2*dp" in output_lines[3]
    assert "word_size=2*dp" in output_lines[8]
    assert state == {"active_call": None}

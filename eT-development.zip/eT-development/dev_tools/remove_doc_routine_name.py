#!/usr/bin/env python3
#
#  Naïve script to remove all routine names from the routine
#  banner documentation
#
#  Written by Marco Scavino and Sarai D. Folkestad, 2022-2023
#
import re
from pathlib import Path
from tempfile import TemporaryFile
import subprocess as sp
import sys

from argparse import ArgumentParser

MAIN_DIRECTORY = Path(__file__).resolve().parents[1] / "src"


def parse_arguments():
    parser = ArgumentParser()

    parser.add_argument("--directory", "-d", help="Directory to change", default=None)

    parser.add_argument("--file", help="File to change", default=None)

    return parser.parse_args()


def check_if_all_commited(path_) -> bool:
    """Chek if all recent change are commited.
    Return False if there are still file to be commited or staged
    """
    proc = sp.run(["git", "status", path_], stdout=sp.PIPE, stderr=sp.PIPE)
    if proc.stdout != 0:
        return not (
            b"Changes not staged for commit" in proc.stdout
            or b"Changes to be committed" in proc.stdout
        )

    return False


def remove_routine_name_doc(filename: Path):
    print(filename)
    routine_type = ["subroutine", "function", "module subroutine", "module function"]
    routine_regex = re.compile(r"^\s+(module|)\s+(subroutine|function)\s+(\w+)")
    new_lines = []

    lines = filename.read_text().splitlines(keepends=True)
    lines = iter(lines)

    for line in lines:
        is_procedure = routine_regex.match(line) is not None

        new_lines.append(line)

        if not is_procedure:
            continue

        while line.strip().endswith("&"):  # Handle line continuation
            line = next(lines)
            new_lines.append(line)

        new_lines.append(next(lines))  # Empty comment line

        # This line should be the routine name doc line, we remove it
        line = next(lines)
        if line.strip().startswith("!!"):
            print(f"Removing: {line}")
        else:
            new_lines.append(line)

    filename.write_text("".join(new_lines))


def main():
    args = parse_arguments()

    path_ = MAIN_DIRECTORY
    if args.directory:
        path_ = Path(args.directory)

    if not check_if_all_commited(path_):
        print(f'\033[1;31mFound file(s) in "{path_}" not commited!\033[0m')
        print("Please commit all the file and re-launch the script.")
        sys.exit(1)

    if args.file:
        print("\nRemoving all the routine names from the routine documentation banner")
        print(f'"{args.file}"\n')
    else:
        print("\nRemoving all the routine names from the routine documentation banner")
        print(f'"{path_}"\n')

    print(
        f"\033[1;31mWARNING: It's possible that some errors will occur in automated removal.\n\033[0m"
        f"\033[1;31m         Never run this script twice on the same files or folders!\033[0m"
    )
    print(
        "\nThe routine banners will be changed from\n"
        "   !!\n"
        "   !!   Routine name\n"
        "   !!   Written by ...\n"
        "   !!\n"
        "to\n"
        "   !!\n"
        "   !!   Written by ...\n"
        "   !!\n"
    )

    answer = input("\nAre you sure to continue? (y/n) ")
    if answer.lower() != "y":
        return

    if args.file:
        remove_routine_name_doc(Path(args.file))
    else:
        files = list((path_).rglob("*.F90"))
        for f in files:
            remove_routine_name_doc(f)


if __name__ == "__main__":
    main()

#
#
#  eT - a coupled cluster program
#  Copyright (C) 2016-2026 the authors of eT
#
#  eT is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  eT is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.
#

"""
Script to replace non-ASCII characters in fortran files in eT.

Written by Federico Rossi 2026

usage:

To change all files:
    python3 replace_symbols.py

Any non-ASCII character not already included in SYMBOLS_MAP
will be detected when running the script.
These can either be manually removed or added to SYMBOLS_MAP.

"""

import os
import re
import unicodedata
from pathlib import Path


SYMBOLS_MAP = {
    # lowercase
    "α": "alpha",
    "β": "beta",
    "γ": "gamma",
    "δ": "delta",
    "ε": "epsilon",
    "ζ": "zeta",
    "η": "eta",
    "θ": "theta",
    "ι": "iota",
    "κ": "kappa",
    "λ": "lambda",
    "μ": "mu",
    "ν": "nu",
    "ξ": "xi",
    "ο": "omicron",
    "π": "pi",
    "ρ": "rho",
    "σ": "sigma",
    "τ": "tau",
    "υ": "upsilon",
    "φ": "phi",
    "ϕ": "phi",
    "χ": "chi",
    "ψ": "psi",
    "ω": "omega",
    # uppercase
    "Α": "A",
    "Β": "B",
    "Γ": "Gamma",
    "Δ": "Delta",
    "Ε": "E",
    "Ζ": "Z",
    "Η": "H",
    "Θ": "Theta",
    "Ι": "I",
    "Κ": "K",
    "Λ": "Lambda",
    "Μ": "M",
    "Ν": "N",
    "Ξ": "Xi",
    "Ο": "O",
    "Π": "Pi",
    "Ρ": "P",
    "Σ": "Sigma",
    "Τ": "T",
    "Υ": "Y",
    "Φ": "Phi",
    "Χ": "X",
    "Ψ": "Psi",
    "Ω": "Omega",
    # Subscripts / superscripts
    "ᵢⱼ": "_ij",
    "ᵢ": "_i",
    "ⱼ": "_j",
    "ₖ": "_k",
    "²": "**2",
    "³": "**3",
    "⁴": "**4",
    "¹ᐧ⁵": "**1.5",
    "ⁿ": "**n",
    "½": "0.5",
    "⁵": "**5",
    "⁶": "**6",
    "ᐧ": ".",
    "⁻¹": "**(-1)",
    # Math operators / symbols
    "∑": "sum",
    "√": "sqrt",
    "∂": "d",
    "∇": "grad",
    "∞": "inf",
    "∈": "in",
    "→": "->",
    "·": "*",
    "∏": "product",
    "±": "+/-",
    "×": "*",
    # Brackets / relations
    "⟨": "<",
    "⟩": ">",
    "≤": "<=",
    "≥": ">=",
    "−": "-",
    "∣": "|",
    "〈": "<",
    "–": "-",
    "≠": "!=",
    "〈": "<",
    # Letters
    "ń": "n'",
    "ö": "oe",
    "Â": "A",
    "Å": "A",
    "á": "a'",
    "æ": "ae",
    "ä": "a",
    "ø": "oe",
    "\u00A0": " ",
}

MAIN_DIRECTORY = Path(__file__).resolve().parents[1]

RE_PATTERN = re.compile("|".join(re.escape(k) for k in SYMBOLS_MAP))


def replace_and_report(text):
    # Contracting diaeresis
    text = unicodedata.normalize("NFC", text)

    # Apply known replacements
    updated = RE_PATTERN.sub(lambda m: SYMBOLS_MAP[m.group()], text)

    # Detect remaining non-ASCII
    remaining = sorted({ch for ch in updated if ord(ch) > 127})

    return updated, remaining


def fix_file(path: Path):
    """Replace symbols in a file using SYMBOLS_MAP."""

    original = path.read_text(encoding="utf-8", errors="replace")
    updated, remaining = replace_and_report(original)

    if updated != original:
        path.write_text(updated, encoding="utf-8")
        print(f"Updated: {path}")

    if remaining:
        print(f"Remaining non-ASCII in {path}:")
        for ch in remaining:
            print(f"  '{ch}' (U+{ord(ch):04X})")


def main():
    os.chdir(MAIN_DIRECTORY)

    files = list((MAIN_DIRECTORY / "src").rglob("**/*.F90"))
    files = [f for f in files if "interface" not in str(f)]

    for f in files:
        fix_file(f)


if __name__ == "__main__":
    main()

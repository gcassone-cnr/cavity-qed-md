#!/bin/bash

cd src

current_year=$(date +%Y)

search_result=$(grep -nRHI --include="*.F90" "Copyright (C) 2016\-[^$current_year]" *)
n_wrong_copyrights=$(grep -nRHI --include="*.F90" "Copyright (C) 2016\-[^$current_year]" | wc -l)

if [ $n_wrong_copyrights -gt 0 ]
then
   echo "Found $n_wrong_copyrights copyright errors:"
   echo $search_result
   exit 1
fi

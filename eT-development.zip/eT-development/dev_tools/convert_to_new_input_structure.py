#
#
#  eT - a coupled cluster program
#  Copyright (C) 2016-2026 the authors of eT
#
#  eT is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  eT is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.
#
"""
Utility to convert the inputs in the eT test directory from the old structure:
```
section_name
   keywords
end section_name
```
to the new structure
```
- section_name
   keywords
```

Written by Alexander C. Paul and Sara Angelico, April 2023
"""
from pathlib import Path
from argparse import ArgumentParser


def convert_input_lines(lines: list[str]) -> list[str]:
    """Get sections in input then convert to new format"""
    new_lines = []
    section_names = []

    for line in lines:
        if line.strip().startswith("end "):
            section_names.append(line.strip()[4:])
            continue
        new_lines.append(line)

    for n, line in enumerate(new_lines):
        line = line.strip()
        if line in section_names:
            new_lines[n] = f"- {line}"

    return new_lines


def convert_input_file(input_file: Path):
    lines = input_file.read_text().split("\n")
    new_lines = convert_input_lines(lines)
    input_file.write_text("\n".join(new_lines))


def get_paths():
    """If no arguments specified convert files in the tests directory of eT.
    If paths contains a directory convert all input file in that directory.
    If paths contains an input file convert that input file.
    """
    parser = ArgumentParser(
        description="Script to convert to the new input structure in eT v2.0."
    )
    parser.add_argument(
        "--paths",
        help="If present convert inputs at the given paths instead of the test directory of eT.",
        default=None,
        action="store",
        nargs="*",
    )

    arguments = parser.parse_args()

    if arguments.paths is None:
        eT_directory = Path(__file__).parents[1]
        tests_path = eT_directory / "tests"
        print(f"Converting input files in: {str(tests_path)}")
        paths = [f for f in tests_path.glob("**/*.inp")]
    else:
        paths = []
        for p in arguments.paths:
            path = Path(p)
            print(f"Converting input files in: {str(path)}")
            if path.is_dir():
                paths += [d for d in path.glob("*.inp")]
            else:
                paths.append(path)

    return paths


def main():
    paths = get_paths()

    for path in paths:
        convert_input_file(path)


if __name__ == "__main__":
    main()

#
#
#  eT - a coupled cluster program
#  Copyright (C) 2016-2026 the authors of eT
#
#  eT is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  eT is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.
#
"""
Utility to rename test directory (including input, output, test-file and cmake entry),
or to create a new test directory based on an existing test.

Written by Alexander C. Paul, September 2022
"""

from pathlib import Path
from argparse import ArgumentParser
from re import match, sub
from shutil import copytree


def count_inputs(test_dir: Path):
    input_files = [inp for inp in test_dir.glob("*.inp")]
    return len(input_files)


def get_restart_input_filenames(source_path: Path):
    """
    Get filenames of the restart input file and the input file to restart from.
    """
    restart_input = [inp for inp in source_path.glob("*restart*.inp")][0]
    input_file = [inp for inp in source_path.glob("*.inp") if inp != restart_input][0]
    return input_file, restart_input


def rename_test_files(source_path: Path, source_name: str, new_name: str):
    """
    Rename files in source-path to new name.
    """
    regexs = [
        f"{source_name}*.out",
        f"{source_name}*.plt",
        f"{source_name}*.cube",
        f"{source_name}*.molden",
        f"{source_name}*.inp",
    ]

    files = []
    for regex in regexs:
        files += [i for i in source_path.rglob(regex)]

    for file in files:
        file.rename(file.with_name(new_name + "".join(file.suffixes)))

    test_file = source_path / "test"
    lines = test_file.read_text()
    lines = lines.replace(f"{source_name}_restart_files", f"{new_name}_restart_files")
    test_file.write_text(lines.replace(f"{source_name}.inp", f"{new_name}.inp"))


def rename_cmake_entry(cmake_file: Path, old_name: str, new_name: str):
    """
    Find entry in cmake file belonging to the old test and rename to new test
    """
    lines = cmake_file.read_text()
    n_spaces = 60 - 15 - len(new_name)
    if n_spaces < 1:
        n_spaces = 1
    """
    lines in TestseT.cmake "add_eT_runtest(testname ... labels"
    labels start at column 60
    """
    cmake_file.write_text(
        sub(
            rf"(add_eT_runtest\(){old_name}\s+",
            rf"\1{new_name}{n_spaces*' '}",
            lines,
        )
    )


def add_cmake_entry(cmake_file: Path, source_name: str, new_name: str):
    """
    Copy line in cmake file containing the copied test and rename
    to the new test.
    """
    lines = cmake_file.read_text().split("\n")
    n_spaces = 60 - 15 - len(new_name)
    if n_spaces < 1:
        n_spaces = 1

    # Find line adding the source-test to the list of tests
    for n, line in enumerate(lines):
        match_object = match(rf"(add_eT_runtest\(){source_name}\s+", line)
        if match_object:
            break
    else:
        raise ValueError(f"Could not find {source_name} in {str(cmake_file)}")

    # insert line for the new test
    lines.insert(
        n + 1,
        sub(
            rf"(add_eT_runtest\(){source_name}\s+",
            rf"\1{new_name}{n_spaces*' '}",
            match_object.string,
        ),
    )

    cmake_file.write_text("\n".join(lines))


def copy_test(source_path: Path, new_path: Path, cmake_file: Path):
    """
    Copy test directory at source-path to new-path and rename the files
    accordingly and add the cmake entry
    """
    copytree(source_path, new_path)
    rename_test_files(new_path, source_path.name, new_path.name)
    add_cmake_entry(cmake_file, source_path.name, new_path.name)


def rename_test(source_path: Path, new_path: Path, cmake_file: Path):
    """
    Rename test at source_path to new_path
    """
    rename_test_files(source_path, source_path.name, new_path.name)
    source_path.rename(source_path.with_name(new_path.name))
    rename_cmake_entry(cmake_file, source_path.name, new_path.name)


def rename_restart_test(
    source_path: Path, new_path: Path, cmake_file: Path, input_name: str
):
    """
    Rename restart test at source_path to new_path
    """
    input_file, restart_file = get_restart_input_filenames(source_path)
    rename_test_files(source_path, source_path.name, new_path.name)
    rename_test_files(source_path, input_file.name.strip(".inp"), input_name)

    source_path.rename(source_path.with_name(new_path.name))
    rename_cmake_entry(cmake_file, source_path.name, new_path.name)


def copy_restart_test(
    source_path: Path, new_path: Path, cmake_file: Path, input_name: str
):
    """
    Copy restart test at source_path to new_path
    """
    copytree(source_path, new_path)
    input_file, restart_file = get_restart_input_filenames(new_path)

    rename_test_files(new_path, source_path.name, new_path.name)
    rename_test_files(new_path, input_file.name.strip(".inp"), input_name)

    add_cmake_entry(cmake_file, source_path.name, new_path.name)


def parse_arguments():
    parser = ArgumentParser(
        description="Script to rename or copy tests in eT.\n"
        + "Use 'tests' directory as default to look for tests."
    )
    parser.add_argument(
        "source",
        help="Path to or name of test to rename/copy",
        type=str,
    )
    parser.add_argument(
        "destination",
        help="Path or name of test after renaming/copying",
        type=str,
    )
    parser.add_argument(
        "--copy",
        help="If present copy test instead of renaming it",
        action="store_true",
    )
    parser.add_argument(
        "--name",
        help="Name of additional (*not* restart) input file when coyping/renaming restart tests.\n"
        + "Required for restart test",
        type=str,
        default=None,
    )

    return parser.parse_args()


def process_paths(args, eT_root: Path):
    """
    Process the input.
    If paths are entered use them directly
    If only names are given, create paths relative to the eT 'tests' directory
    """
    if "/" in args.source:
        source_path = Path(args.source).resolve()
    else:
        source_path = eT_root / "tests" / args.source

    if "/" in args.destination:
        new_path = Path(args.destination)
    else:
        new_path = source_path.with_name(args.destination)

    if not source_path.exists():
        raise FileNotFoundError(str(source_path))
    if not source_path.is_dir():
        raise NotADirectoryError(str(source_path))
    if new_path.exists():
        raise FileExistsError(str(new_path))

    return source_path, new_path


def main():
    args = parse_arguments()
    eT_root = Path(__file__).resolve().parents[1]
    cmake_file = eT_root / "cmake/TestseT.cmake"
    source_path, new_path = process_paths(args, eT_root)

    n_inputs = count_inputs(source_path)

    if n_inputs == 1:
        if args.copy:
            copy_test(source_path, new_path, cmake_file)
        else:
            rename_test(source_path, new_path, cmake_file)
    elif n_inputs == 2:
        if args.name is None:
            raise RuntimeError(
                "argument --name needs to be specified for tests containing 2 inputs."
            )
        if args.copy:
            copy_restart_test(source_path, new_path, cmake_file, args.name)
        else:
            rename_restart_test(source_path, new_path, cmake_file, args.name)
    else:
        raise ValueError(
            f"Expected 1 or 2 input files in {str(source_path)}, found {n_inputs}"
        )


if __name__ == "__main__":
    main()

#
#
#  eT - a coupled cluster program
#  Copyright (C) 2016-2026 the authors of eT
#
#  eT is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  eT is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.
#

"""
Script to format indentation of code and/or comments of the fortran files in eT.

Written by Marcus T. Lexander 2024

usage:

To change all files:
    python3 fix_indent.py [-comments] [-code]
To change specific files:
    python3 fix_indent.py [-comments] [-code] [list of specific file paths]

the -comments and -code specify whether the indentation of code or comments
will be performed. Both can be done together. If neither is specified, nothing
will happen.

"""

import os
import re
from pathlib import Path
from argparse import ArgumentParser

MAIN_DIRECTORY = Path(__file__).resolve().parents[1]

tab_width = 3
change_code_indent = False
change_comments = False


def strip_comment_contents(line):
    in_string = line.strip().startswith("&")
    string_char = '"'

    code_end = len(line)

    for i, c in enumerate(line):
        if not in_string and c in "'\"":
            in_string = True
            string_char = c
        elif in_string and c == string_char:
            in_string = False

        if not in_string and c == "!":
            code_end = i
            break

    return line[0:code_end]


def code_line_endswith(line, tokens):
    return strip_comment_contents(line).strip().endswith(tokens)


def code_ends_with_then(lines, i):
    if code_line_endswith(lines[i], "then"):
        return True
    elif code_line_endswith(lines[i], "&"):
        return code_ends_with_then(lines, i + 1)
    else:
        return False


def comment_leading_spaces(line):
    m = re.match(r"!+( +)", line.strip())
    if m is not None:
        return len(m.group(1))
    else:
        return 132


def adjust_comment_leading_spaces(line, n_remove):
    m = re.match(r"(!+)( +)(.+)", line.strip())
    if m is None:
        return line
    n_spaces_old = len(m.group(2))
    n_spaces_new = n_spaces_old - n_remove

    return m.group(1) + " " * n_spaces_new + m.group(3)


def n_leading_spaces(line):
    m = re.match(r"( *)", line)
    return len(m.group(1))


def is_implicit_function_definition(line):
    if line.startswith(("!", "end")):
        return False

    return re.match(r"(?:\w+(?:\(.+?\))? )+\b(function)\b", line) is not None


def is_start_of_code_line(lines, i):
    if len(strip_comment_contents(lines[i]).strip()) == 0:
        return False

    if i == 0:
        return True

    j = i - 1
    while j >= 0:
        s_line = strip_comment_contents(lines[j]).strip()
        if len(s_line) != 0:
            return not s_line.endswith("&")
        j -= 1

    return True


def is_end(line):
    s_line = strip_comment_contents(line).strip()

    if not s_line.startswith("end"):
        return False

    if s_line == "end" or s_line.startswith(("end ", "endif", "enddo")):
        return True

    return False


def is_labeled_do(line):
    return re.match(r"\w+?: +do", line) is not None


def startswith_keyword(line, keyword):
    if line == keyword:
        return True

    m = re.match(f"{keyword}(.+)", line)

    return m is not None and (m.group(1).startswith((" ", "(")) or m.group(1) == "")


def startswith_keywords(line, keywords):
    return any(startswith_keyword(line, keyword) for keyword in keywords)


def combine_split_lines(lines, i):
    line_segments = []

    in_string = False
    string_char = '"'

    j = i
    while True:
        contents = strip_comment_contents(lines[j]).strip()
        if len(contents) == 0:
            j += 1
            continue
        if in_string:
            contents = contents[1:]
        for c in contents:
            if not in_string and c in "'\"":
                in_string = True
                string_char = c
            elif in_string and c == string_char:
                in_string = False
        if contents.endswith("&"):
            line_segments.append(contents[0:-1])
            j += 1
        else:
            line_segments.append(contents)
            break

    combined = " ".join(line_segments)

    new_lines = []

    prev_start = 0

    in_string = False
    string_char = '"'

    for i, c in enumerate(combined):
        if not in_string and c in "'\"":
            in_string = True
            string_char = c
        elif in_string and c == string_char:
            in_string = False

        if not in_string and c == ";":
            new_lines.append(combined[prev_start:i])
            prev_start = i + 1

    new_lines.append(combined[prev_start:])

    return new_lines


def fix_file_contents(lines):
    new_lines = []

    tab_level = 0
    tab_stack = []

    in_comment_block = False
    comment_block_start = 0
    last_nonempty_comment_line = 0
    comment_block_min_leading_spaces = 0

    is_changing_indent = False
    change_indent_by = 0

    select_keyword = "case"

    for i, line in enumerate(lines):
        s_line_non_lower = line.strip()
        s_line = s_line_non_lower.lower()

        if s_line.startswith("!"):
            if not change_comments:
                new_lines.append(line)
                continue

            if not in_comment_block:
                in_comment_block = True
                comment_block_start = i
                comment_block_min_leading_spaces = 132
            if s_line != "!":
                last_nonempty_comment_line = i
                comment_block_min_leading_spaces = min(
                    comment_block_min_leading_spaces, comment_leading_spaces(s_line)
                )

        elif in_comment_block and not s_line.startswith("!"):
            in_comment_block = False

            found_nonempty_comment = False
            for j in range(comment_block_start, i):
                if lines[j].strip() != "!":
                    found_nonempty_comment = True
                if found_nonempty_comment and j <= last_nonempty_comment_line:
                    new_line = adjust_comment_leading_spaces(
                        lines[j].strip(), comment_block_min_leading_spaces - 1
                    )
                    new_lines.append(" " * (tab_width * tab_level) + new_line + "\n")
                else:
                    new_lines.append("\n")

        if is_changing_indent:
            n_lead = n_leading_spaces(line)
            n_spaces = n_lead + change_indent_by
            new_lines.append(" " * n_spaces + s_line_non_lower + "\n")
            if not strip_comment_contents(line).strip().endswith("&"):
                is_changing_indent = False
        elif not in_comment_block:
            expected_tab_level = tab_level
            if is_end(s_line):
                expected_tab_level = tab_level - tab_stack[-1]

            if (
                startswith_keywords(s_line, ("else", "elseif", "contains"))
                or (len(tab_stack) > 0 and tab_stack[-1] == 2)
                and startswith_keyword(s_line, select_keyword)
            ):
                expected_tab_level = tab_level - 1

            if (
                is_start_of_code_line(lines, i)
                and not s_line.startswith("#")
                and n_leading_spaces(line) != expected_tab_level * tab_width
            ):
                if change_code_indent:
                    print(f"\033[1;31mFixing indentation on line {i + 1}!\033[0m")
                    new_lines.append(
                        " " * (tab_width * expected_tab_level) + s_line_non_lower + "\n"
                    )
                    if strip_comment_contents(line).strip().endswith("&"):
                        is_changing_indent = True
                        change_indent_by = (
                            tab_width * expected_tab_level - n_leading_spaces(line)
                        )
                else:
                    print(
                        f"\033[1;31mLine number {i + 1} has seemingly wrong indentation!\033[0m"
                    )
                    new_lines.append(line)
            else:
                new_lines.append(line)

        # Change tab level:
        if is_start_of_code_line(lines, i):
            for other_line in combine_split_lines(lines, i):
                other_s_line = other_line.strip().lower()
                if (
                    startswith_keywords(
                        other_s_line,
                        (
                            "program",
                            "module",
                            "submodule",
                            "subroutine",
                            "interface",
                            "pure",
                            "elemental",
                            "function",
                            "recursive",
                            "abstract",
                            "do",
                            "associate",
                        ),
                    )
                    or (other_s_line.startswith("if") and other_s_line.endswith("then"))
                    or re.match(r"type *[^\(\w]", other_s_line) is not None
                    or is_implicit_function_definition(other_s_line)
                    or is_labeled_do(other_s_line)
                ):
                    tab_level += 1
                    tab_stack.append(1)
                elif startswith_keyword(other_s_line, "select"):
                    m = re.match(r"select +(\w+)", other_s_line)
                    select_keyword = m.group(1)
                    tab_level += 2
                    tab_stack.append(2)
                elif is_end(other_s_line):
                    tab_level -= tab_stack.pop()

    if len(tab_stack) != 0:
        raise Exception("Have tab levels left to exit!")

    return new_lines


def fix_file(file_path):
    print(f"Fixing {file_path}")
    with open(file_path) as file:
        lines = [line for line in file]
    new_lines = fix_file_contents(lines)
    with open(file_path, "w") as file:
        for line in new_lines:
            file.write(line)


def parse_arguments():
    parser = ArgumentParser()
    parser.add_argument("files", nargs="*", help="File(s) to cleanup", default=[])

    parser.add_argument(
        "--change-comments",
        "-comments",
        help="Change indentation of comments.",
        action="store_true",
    )

    parser.add_argument(
        "--change-code",
        "-code",
        help="Change indentation of code.",
        action="store_true",
    )

    return parser.parse_args()


def main():
    os.chdir(MAIN_DIRECTORY)

    args = parse_arguments()

    if args.change_code:
        global change_code_indent
        change_code_indent = True

    if args.change_comments:
        global change_comments
        change_comments = True

    files = list((MAIN_DIRECTORY / "src").rglob("**/*.F90"))

    if args.files:
        selected = set(f for f in args.files)

        files = [f for f in files if any(s in str(f) for s in selected)]

    files = [f for f in files if "interface" not in str(f)]

    for f in files:
        fix_file(f)


if __name__ == "__main__":
    main()

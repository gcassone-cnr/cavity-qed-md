import re
import sys
from pathlib import Path
from argparse import ArgumentParser
from autogenerate_files import create_code_to_line_map
from warnings import warn


def parse_command_line():
    parser = ArgumentParser(
        description="""Check that all keywords found in path-eT/src/io/input/input_structure.F90
        can also be found in the corresponding files in path-website/keyword_sections/*rst"""
    )

    parser.add_argument(
        "-path-eT",
        help="""Path to root directory of eT, where we look for
                path-eT/src/io/input/input_structure.F90""",
        default=str(Path(__file__).parents[1]),
        type=str,
    )

    parser.add_argument(
        "-path-website",
        help="""Path to root directory of the eT-website, where we look for the
                section files path-website/keyword_sections/*rst""",
        type=str,
    )

    return parser.parse_args()


def extract_section_keywords_from_constructor_arguments(
    arguments: str,
) -> dict[str, list[str]]:
    """Extract section name and its keywords from the arguments to
    the section constructor in the input file

    Supports unified keywords format: keywords = [keyword_descriptor('name'), ...]
    The method section needs to be extracted separately because the methods
    are contained in character arrays defined at the beginning of the input file.
    """

    section = {"name_": "", "keywords": []}

    # Extract section name from name_ = '...'
    name_match = re.search(r"name_\s*=\s*[\"']([\w()\s-]+)[\"']", arguments)
    if name_match:
        section["name_"] = name_match.group(1).strip()

    # Extract all keyword names from keyword_descriptor('name') or keyword_descriptor('name', ...)
    # Search the full arguments string to capture the entire keywords array
    keyword_names = re.findall(
        r"keyword_descriptor\s*\(\s*[\"']([^\"']+)[\"']", arguments
    )
    section["keywords"] = [k.strip().lower() for k in keyword_names]

    return section


def parse_input_structure(path: Path) -> dict[str, list[str]]:
    """Parse eT input_structure.F90 and extract section names
    and keywords for each section"""

    lines = iter(path.read_text().splitlines())
    # code lines do not contain comments and removes line continuation
    # by putting all the continued lines in a single string
    _, code_lines = create_code_to_line_map(lines)

    section_to_keywords = {}
    methods = []

    for line in code_lines:
        # look for arrays of wavefunction names in both class members
        # (this%rf_wfs) and local variables (rf_wfs)
        wfs = re.match(
            r"^allocate\(\s*(?:this%)?\w+wfs\s*,\s*source\s*=",
            line,
        )
        if wfs:
            # Extract all content in quotes which are the keyword names
            methods += [
                k.strip().lower() for k in re.findall(r"[\"\']([^\"\']+)[\"\']", line)
            ]

        # look for input_spec registration: call input_spec%add_section(section_name='...', required=.false., keywords=[...])
        # The input file uses keyword arguments, not positional
        if "call input_spec%add_section" in line:
            section_name_match = re.search(
                r"section_name\s*=\s*[\"']([^\"']+)[\"']", line
            )
            if section_name_match:
                section_name = section_name_match.group(1).strip()

                # Method section uses method_keywords variable (from rf_wfs, cc_wfs, ci_wfs)
                if "keywords=method_keywords" in line.replace(" ", ""):
                    continue

                # Extract keywords from inline array
                keywords_match = re.search(r"keywords\s*=\s*\[(.*)\]", line)
                if keywords_match:
                    keywords_str = keywords_match.group(1)
                    keyword_names = re.findall(
                        r"keyword_descriptor\s*\(\s*[\"']([^\"']+)[\"']",
                        keywords_str,
                    )
                    if section_name and keyword_names:
                        section_to_keywords[section_name] = [
                            k.strip().lower() for k in keyword_names
                        ]
            continue

    section_to_keywords["method"] = methods

    return section_to_keywords


def get_section_name(lines: list[str]) -> str:
    """Extract the section name from an .rst file

    In website/keyword_sections/*.rst the section name is always the first
    line (consisting of word characters and whitespace) followed by
    a line of punctuation characters (# or * or = or - or ^ or ")
    """
    for n, line in enumerate(lines):
        line = line.strip()
        section_name = re.fullmatch(r"(\w+\s*)+", line)
        if section_name is None:
            continue
        matches_header = re.fullmatch(r"(\#+|\*+|=+|-+|\^+|\"+)", lines[n + 1])
        if matches_header:
            return section_name.string.strip()
    return None


def replace_method_string_keywords(keyword, lines):
    """Takes a keyword, e.g. "[method string] basis" and the remaining lines
    of the rst file for that keyword to extract the valid "method strings".
    Assumes that the valid methods are listed in an unordered list
    Example of use is for the active_atoms section"""
    keywords = []
    for line in lines:
        line = line.strip()
        # Found next keyword so we stop here
        if line.startswith(".. container::"):
            break
        # we assume the methods are stored in an unorderd list and wrapped in ``
        if not line.startswith("- ``"):
            continue
        method = line.split("``")[1]
        keywords.append(keyword.replace("[method string]", method))
    return keywords


def extract_keywords_from_rst(lines: list[str]) -> list[str]:
    """Extract the section keywords from a .rst file

    Keywords are described in custom sphinx containers and start with the line
    '.. container:: sphinx-custom' followed by the keyword name
    and the type of value (if any) wrapped in ``

    For example a keyword definition usually looks like this:

    '''
    .. container:: sphinx-custom

        ``algorithm: [string]``
    '''

    """
    keywords = []
    for n in range(len(lines)):
        if not lines[n].startswith(".. container:: sphinx-custom"):
            continue

        # skip following empty lines
        for m in range(n + 1, len(lines)):
            if not lines[m].strip() == "":
                break

        line = lines[m].strip()
        if not (line.startswith("``") or line.endswith("``")):
            warn(
                f"Expected keyword but line does not start and end with ``: {line = }."
            )

        line = line.strip("`")
        # Keyword is either defined as "name: type" or just as name. Using the first
        # element after splitting at the colon will give us the keyword name
        keyword = line.split(":")[0].strip().lower()

        if keyword.startswith("[method string]"):
            keywords += replace_method_string_keywords(keyword, lines[m:])
        else:
            keywords.append(keyword)

    return keywords


def extract_methods_from_website(path: Path) -> list[str]:
    """Extract possible method keywords from methods.rst
    The methods are listed as unordered lists, where the method
    name is wrapped in ``method-name``
    """
    lines = path.read_text().splitlines()
    methods = []
    for line in lines:
        line = line.strip()
        if not line.startswith("- ``"):
            continue
        method = line.split("``")[1]
        methods.append(method)

    return methods


def parse_website_input_sections(path: Path) -> dict[str, str]:
    """Uses path to website/keyword_sections directory and extracts
    section names and corresponding inputs from the .rst files"""
    section_to_keywords = {}
    for rst in path.glob("*.rst"):
        lines = rst.read_text().splitlines()
        section = get_section_name(lines)
        if section is None:
            raise RuntimeError(f"Could not extract section name from {path}")

        section_to_keywords[section] = extract_keywords_from_rst(lines)

    section_to_keywords["method"] = extract_methods_from_website(path / "method.rst")

    return section_to_keywords


def compare_section_dictionaries(
    code_sections: dict[str, str],
    website_sections: dict[str, str],
) -> int:
    """Compare dictionaries relating section to keywords
    extracted from the code and the website.
    Differences are printed to stdout and an error integer
    different from 0 is returned if any differencces were found."""
    error_code = 0

    not_in_website = set(code_sections).difference(set(website_sections))
    not_in_website = sorted(not_in_website)

    not_in_code = set(website_sections).difference(set(code_sections))
    not_in_code = sorted(not_in_code)

    output = ""

    if not_in_code:
        output = "The following sections are missing in the code:\n"
        output += "\n".join(not_in_code)
        error_code -= 1

    if not_in_website:
        output += "\nThe following sections are missing on the website:\n"
        output += "\n".join(not_in_website)
        error_code -= 1
        for section in not_in_website:
            code_sections.pop(section)

    for section, keywords in code_sections.items():
        code = set(keywords)
        website = set(website_sections[section])
        not_in_website = sorted(set(code).difference(website))
        not_in_code = sorted(set(website).difference(code))

        if not_in_website or not_in_code:
            error_code -= 1
            output += f"\nSection {section}:\n" + (9 + len(section)) * "-" + "\n"

        if not_in_code:
            output += "Missing keywords in the code:\n"
            output += "\n".join([f"   {k}" for k in not_in_code]) + "\n"

        if not_in_website:
            output += f"Missing keywords on the website:\n"
            output += "\n".join([f"   {k}" for k in not_in_website]) + "\n"

    if output:
        print("There are differences in the source code and the website:\n" + output)

    return error_code


def main():
    args = parse_command_line()
    eT_root = Path(args.path_eT).resolve()
    website_root = Path(args.path_website).resolve()

    for path in [eT_root, website_root]:
        if not path.is_dir():
            raise NotADirectoryError(f"Path {str(path)} does not point to a directory.")

    eT_keywords = parse_input_structure(eT_root / "src/io/input/input_structure.F90")
    website_keywords = parse_website_input_sections(website_root / "keyword_sections/")

    """Account for additional special cases:
    1. The geometry section is not handled in input_structure.F90 and we need
       to remove it from the website dictionary
    2. Both 'solver fft electric field' and 'solver fft dipole moment' are described
       in a single 'solver fft' section in the website. We remove 'solver fft'
       and duplicate the keywords in the website dictionary.
    """
    website_keywords.pop("geometry")
    solver_fft = website_keywords.pop("solver fft")
    website_keywords["solver fft electric field"] = solver_fft
    website_keywords["solver fft dipole moment"] = solver_fft

    error_code = compare_section_dictionaries(eT_keywords, website_keywords)
    sys.exit(error_code)


if __name__ == "__main__":
    main()

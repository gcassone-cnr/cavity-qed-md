
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module lapack_wrappers

   !!
   !! LAPACK wrappers module
   !!

   use parameters

   implicit none

contains



   subroutine diagonalize_non_symmetric(dim, A, X, omega)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Aug 2018
      !!
      !!    A X_n = omega_n X_n,    n = 1, 2, ...
      !!
      use global_out, only: output
      use memory_manager_class, only: mem
      use timings_class, only: timings
      use array_utilities, only: get_n_lowest
      implicit none

      integer, intent(in) :: dim
      real(dp), dimension(dim, dim), intent(in) :: A
      real(dp), dimension(dim, dim), intent(out) :: X
      complex(dp), dimension(dim), intent(out) :: omega

      real(dp), dimension(:), allocatable :: work

      real(dp), dimension(:), allocatable :: omega_re_unsorted, omega_re
      real(dp), dimension(:), allocatable :: omega_im_unsorted
      real(dp), dimension(:, :), allocatable :: A_copy, X_copy
      integer, dimension(:), allocatable :: index_list

      integer :: info = 0, j = 0, i = 0, worksize
      real(dp) :: dummy = 0.0
      real(dp), dimension(1) :: optwork

      type(timings) :: timer

      timer = timings("LAPACK: solve non-symmetric eigenvalue problem", pl='v')

      call timer%turn_on()

      call mem%alloc(A_copy, dim, dim)
      call dcopy(dim**2, A, 1, A_copy, 1)

      call mem%alloc(X_copy, dim, dim)
      call dcopy(dim**2, X, 1, X_copy, 1)

      call mem%alloc(omega_re_unsorted, dim)
      call mem%alloc(omega_im_unsorted, dim)

      info = 0

      ! Find optimal work size, lwork = -1

      call dgeev('N', &
                 'V', &
                 dim, &
                 A_copy, &
                 dim, &
                 omega_re_unsorted, &
                 omega_im_unsorted, &
                 dummy, &
                 1, &
                 X_copy, &
                 dim, &
                 optwork, &
                 - 1, &
                 info)

      worksize = ceiling(optwork(1))
      call mem%alloc(work, worksize)

      call dgeev('N', &
                 'V', &
                 dim, &
                 A_copy, &
                 dim, &
                 omega_re_unsorted, &
                 omega_im_unsorted, &
                 dummy, &
                 1, &
                 X_copy, &
                 dim, &
                 work, &
                 worksize, &
                 info)

      if (info /= 0) call output%error_msg('could not diagonalize non-symmetric matrix!.')

      call mem%dealloc(A_copy)
      call mem%dealloc(work)

      ! Sort according to lowest eigenvalue
      call mem%alloc(omega_re, dim)
      call mem%alloc(index_list, dim)
      call get_n_lowest(dim, dim, omega_re_unsorted, omega_re, index_list)

      !$omp parallel do private (i,j)
      do j = 1, dim

         omega(j) = cmplx(omega_re(j), omega_im_unsorted(index_list(j)), kind=dp)

         do i = 1, dim

            X(i, j) = X_copy(i, index_list(j))

         end do
      end do
      !$omp end parallel do

      call mem%dealloc(X_copy)
      call mem%dealloc(omega_re)
      call mem%dealloc(index_list)
      call mem%dealloc(omega_re_unsorted)
      call mem%dealloc(omega_im_unsorted)

      call timer%turn_off()

   end subroutine diagonalize_non_symmetric


   subroutine diagonalize_symmetric_not_in_place(dim, A, X, omega)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      !! Diagonalizes A (dim x dim), where A = A^T, and
      !! places the eigenvectors of A in X and the eigenvalues of A
      !! in omega. Does not overwrite A (not in place)
      !!
      !! A X_k = omega_k X_k
      !!
      use global_out, only: output
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: dim

      real(dp), dimension(dim, dim), intent(in) :: A

      real(dp), dimension(dim, dim), intent(out) :: X  ! columns contain eigenvectors

      real(dp), dimension(dim), intent(out) :: omega

      integer :: info
      real(dp), dimension(1) :: worksize
      real(dp), dimension(:), allocatable :: work

      ! Ask how much memory is needed in 'work' array to
      ! perform diagonalization
      call dcopy(dim**2, A, 1, X, 1)

      call dsyev('V', &
                 'U', &
                 dim, &
                 X, &
                 dim, &
                 omega, &
                 worksize, &
                 - 1, &
                 info)

      if (info /= 0) call output%error_msg('could not perform DSYEV worksize query')

      call mem%alloc(work, ceiling(worksize(1)))

      ! Diagonalize matrix

      call dsyev('V', &
                 'U', &
                 dim, &
                 X, &  ! Stores eigenvectors on exit
                 dim, &
                 omega, &  ! Stores eigenvalues on exit
                 work, &
                 ceiling(worksize(1)), &
                 info)

      if (info /= 0) call output%error_msg('DSYEV finished with info: (i0)', ints=[info])

      call mem%dealloc(work)

   end subroutine diagonalize_symmetric_not_in_place


end module lapack_wrappers

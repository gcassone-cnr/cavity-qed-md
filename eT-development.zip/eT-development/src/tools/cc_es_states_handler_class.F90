! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_es_states_handler_class

   !!
   !! CC es states handler class module
   !! Written by Sarai D. Folkestad, Oct 2024
   !!

   use parameters, only: dp
   use state_descriptor_class, only: state_descriptor
   use cc_es_states_class, only: cc_es_states

   implicit none

   type :: cc_es_states_handler

      type(cc_es_states), dimension(:), allocatable, private :: es_states
      integer, public :: n_es_types, n_total
      character(len=200), public :: left_or_right

   contains

      procedure, public :: read_
      procedure, public :: save_
      procedure, public :: read_energies
      procedure, public :: read_energy
      procedure, public :: get_descriptor
      procedure, public :: get_n_amplitudes
      procedure, public :: is_
      procedure, public :: transform
      procedure, public :: add
      procedure, public :: get_states_of_es_type
      procedure, public :: remove_parallel_states
      procedure, private :: get_internal_state_index
      procedure, private :: get_es_type_index

      procedure, private :: get_max_parameters

   end type cc_es_states_handler

   interface cc_es_states_handler

      procedure :: new_cc_es_states_handler
      procedure :: new_cc_es_states_handler_descriptor
      procedure :: new_cc_es_states_handler_l_r

   end interface cc_es_states_handler

contains


   function new_cc_es_states_handler_l_r(left_or_right) result(this)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      type(cc_es_states_handler) :: this
      character(len=*), intent(in) :: left_or_right

      this%left_or_right = left_or_right
      this%n_total = 0
      this%n_es_types = 0

   end function new_cc_es_states_handler_l_r


   function new_cc_es_states_handler(n_es_types, es_states, left_or_right) result(this)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      type(cc_es_states_handler) :: this
      integer, intent(in) :: n_es_types
      type(cc_es_states), dimension(n_es_types), intent(in) :: es_states
      character(len=*), intent(in) :: left_or_right

      integer :: i, counter

      this%left_or_right = trim(left_or_right)

      ! Determine number of es_types with correct side = left_or_right
      ! and the total number of left_or_right states
      this%n_es_types = 0
      this%n_total = 0
      do i = 1, n_es_types

         if (es_states(i)%is_(left_or_right)) then

            this%n_es_types = this%n_es_types + 1
            this%n_total = this%n_total + es_states(i)%n_states

         end if

      end do

      ! Copy the es_states with correct type into handler
      allocate(this%es_states(this%n_es_types))

      counter = 0
      do i = 1, n_es_types

         if (.not. es_states(i)%is_(left_or_right)) cycle
         counter = counter + 1
         this%es_states(counter) = cc_es_states(es_states(i)%n_states, &
                                                es_states(i)%n_parameters, &
                                                es_states(i)%descriptor)

      end do

   end function new_cc_es_states_handler


   function new_cc_es_states_handler_descriptor(n_es_types, es_states, descriptor) result(this)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      use global_out, only: output
      implicit none

      type(cc_es_states_handler) :: this
      integer, intent(in) :: n_es_types
      type(cc_es_states), dimension(n_es_types), intent(in) :: es_states
      type(state_descriptor), intent(in) :: descriptor

      integer :: i

      ! Determine number of es_types with correct descriptor
      ! and the total number of left_or_right states

      this%left_or_right = trim(descriptor%get_left_or_right())

      this%n_es_types = 1
      this%n_total = 0

      allocate(this%es_states(this%n_es_types))

      do i = 1, n_es_types

         if (es_states(i)%is_(descriptor)) then

            this%es_states(1) = cc_es_states(es_states(i)%n_states, &
                                             es_states(i)%n_parameters, &
                                             es_states(i)%descriptor)

            this%n_total = es_states(i)%n_states

            return
         end if

      end do

      call output%error_msg('Did not find requested states for cc_es_states_handler!')

   end function new_cc_es_states_handler_descriptor


   subroutine read_energies(this, energies)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      class(cc_es_states_handler), intent(inout) :: this
      real(dp), dimension(this%n_total), intent(out) :: energies

      integer :: i, first, last

      first = 1
      do i = 1, this%n_es_types

         last = first + this%es_states(i)%n_states - 1
         call this%es_states(i)%read_energies(energies(first:last))

         first = last + 1
      end do

   end subroutine read_energies


   subroutine save_(this, state, X, energies)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      class(cc_es_states_handler), intent(inout) :: this
      integer, intent(in) :: state
      real(dp), dimension(*), intent(in) :: X
      real(dp), intent(in), optional :: energies

      integer :: es_type
      integer :: state_idx

      real(dp) :: local_energy

      es_type = this%get_es_type_index(state)
      state_idx = this%get_internal_state_index(state)

      call this%es_states(es_type)%es_storers(state_idx)%read_energy(local_energy)
      if (present(energies)) local_energy = energies

      call this%es_states(es_type)%es_storers(state_idx)%save_(X, local_energy)

   end subroutine save_


   subroutine read_(this, state, X, energies)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      class(cc_es_states_handler), intent(inout) :: this
      integer, intent(in) :: state
      real(dp), dimension(*), intent(out) :: X
      real(dp), intent(out), optional :: energies

      integer :: es_type
      integer :: state_idx

      real(dp) :: local_energy

      es_type = this%get_es_type_index(state)
      state_idx = this%get_internal_state_index(state)

      call this%es_states(es_type)%es_storers(state_idx)%read_(X, local_energy)
      if (present(energies)) energies = local_energy

   end subroutine read_


   function read_energy(this, state) result(energy)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      class(cc_es_states_handler), intent(inout) :: this
      integer, intent(in) :: state

      integer :: es_type
      integer :: state_idx

      real(dp) :: energy

      es_type = this%get_es_type_index(state)
      state_idx = this%get_internal_state_index(state)

      call this%es_states(es_type)%es_storers(state_idx)%read_energy(energy)

   end function read_energy


   function get_descriptor(this, state) result(descriptor)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      implicit none

      class(cc_es_states_handler), intent(in) :: this
      integer, intent(in) :: state

      type(state_descriptor) :: descriptor

      integer :: es_type

      es_type = this%get_es_type_index(state)

      descriptor = this%es_states(es_type)%descriptor

   end function get_descriptor


   function get_es_type_index(this, state) result(idx)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      use global_out, only: output
      implicit none

      class(cc_es_states_handler), intent(in) :: this
      integer, intent(in) :: state
      integer :: idx

      integer :: es_type_index

      integer :: n, i

      if (state > this%n_total) call output%error_msg('Requested non-existent excited state')
      if (state <= 0) call output%error_msg('Illegal index for excited state')

      es_type_index = 0

      n = 0
      do i = 1, this%n_es_types

         if ((n + this%es_states(i)%n_states) < state) then
            n = n + this%es_states(i)%n_states
            cycle
         else
            es_type_index = i
            exit

         end if

      end do

      idx = es_type_index

   end function get_es_type_index


   function get_internal_state_index(this, state) result(idx)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      use global_out, only: output
      implicit none

      class(cc_es_states_handler), intent(in) :: this
      integer, intent(in) :: state
      integer :: idx

      integer :: internal_state_index

      integer :: n, i

      if (state > this%n_total) call output%error_msg('Requested non-existent excited state')
      if (state <= 0) call output%error_msg('Illegal index for excited state')

      internal_state_index = 0

      n = 0
      do i = 1, this%n_es_types

         if ((n + this%es_states(i)%n_states) < state) then
            n = n + this%es_states(i)%n_states
            cycle
         else
            internal_state_index = state - n
            exit

         end if

      end do

      idx = internal_state_index

   end function get_internal_state_index


   function get_n_amplitudes(this, state) result(n_amplitudes)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      implicit none

      class(cc_es_states_handler), intent(in) :: this
      integer, intent(in) :: state

      integer :: n_amplitudes

      integer :: es_type

      es_type = this%get_es_type_index(state)

      n_amplitudes = this%es_states(es_type)%n_parameters

   end function get_n_amplitudes


   function is_(this, string, state) result(is)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      implicit none
      class(cc_es_states_handler), intent(in) :: this
      character(len=*), intent(in) :: string
      integer, intent(in) :: state

      logical is

      integer :: es_type

      es_type = this%get_es_type_index(state)

      is = this%es_states(es_type)%is_(string)

   end function is_


   pure function get_max_parameters(this) result(n)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      implicit none

      class(cc_es_states_handler), intent(in) :: this
      integer :: n

      integer :: i

      n = 0
      do i = 1, this%n_es_types

         if (n < this%es_states(i)%n_parameters) n = this%es_states(i)%n_parameters

      end do

   end function get_max_parameters


   subroutine transform(this, A, energies)
      !!
      !! Written by Alexander C. Paul, Sep 2020
      !!
      !! Performs
      !!
      !!    X_i = A_ij V_j
      !!
      !! where A is the transformation matrix and updates the energies
      !! for vectors of all types.
      !!
      use parameters
      use memory_manager_class, only: mem

      implicit none

      class(cc_es_states_handler), intent(inout) :: this

      real(dp), dimension(this%n_total, this%n_total), intent(in) :: A
      real(dp), dimension(this%n_total), intent(in) :: energies

      integer :: i, n_max_parameters
      real(dp), dimension(:, :), allocatable :: vectors, transformed_vectors

      n_max_parameters = this%get_max_parameters()
      call mem%alloc(vectors, n_max_parameters, this%n_total, set_zero=.true.)
      call mem%alloc(transformed_vectors, n_max_parameters, this%n_total, set_zero=.true.)

      do i = 1, this%n_total

         call this%read_(i, vectors(:, i))

      end do

      call dgemm('N', &
                 'N', &
                 n_max_parameters, &
                 this%n_total, &
                 this%n_total, &
                 one, &
                 vectors, &
                 n_max_parameters, &
                 A, &
                 this%n_total, &
                 zero, &
                 transformed_vectors, &
                 n_max_parameters)

      do i = 1, this%n_total

         call this%save_(i, vectors(:, i), energies(i))

      end do

      call mem%dealloc(vectors)
      call mem%dealloc(transformed_vectors)

   end subroutine transform


   subroutine add(this, descriptor, n_states, n_parameters)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      !! Add state of particular type
      !!

      use global_out, only: output

      implicit none

      class(cc_es_states_handler), intent(inout) :: this

      type(state_descriptor), intent(in) :: descriptor
      integer, intent(in) :: n_states, n_parameters

      type(cc_es_states), dimension(:), allocatable :: temp_es_states

      integer :: n, i

      if (trim(descriptor%get_left_or_right()) /= trim(this%left_or_right)) &
         call output%error_msg('Tried to add states with wrong sidedness to cc_es_states_handler!')

      if (.not. allocated(this%es_states)) then

         this%n_es_types = 1
         this%n_total = n_states
         allocate(this%es_states(1))
         this%es_states(1) = cc_es_states(n_states, n_parameters, descriptor)

      else

         this%n_es_types = this%n_es_types + 1
         this%n_total = this%n_total + n_states

         n = size(this%es_states)
         allocate(temp_es_states(n))

         do i = 1, n

            temp_es_states(i) = cc_es_states(this%es_states(i)%n_states, &
                                             this%es_states(i)%n_parameters, &
                                             this%es_states(i)%descriptor)

         end do

         deallocate(this%es_states)
         allocate(this%es_states(n + 1))

         do i = 1, n

            this%es_states(i) = cc_es_states(temp_es_states(i)%n_states, &
                                             temp_es_states(i)%n_parameters, &
                                             temp_es_states(i)%descriptor)

         end do

         this%es_states(n + 1) = cc_es_states(n_states, n_parameters, descriptor)
         deallocate(temp_es_states)

      end if

   end subroutine add


   function get_states_of_es_type(this, descriptor) result(states)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      !! Returns all states of a particular type
      !!

      use global_out, only: output

      implicit none

      class(cc_es_states_handler), intent(in) :: this
      type(cc_es_states_handler) :: states
      type(state_descriptor), intent(in) :: descriptor

      integer :: i

      states = cc_es_states_handler(trim(descriptor%get_left_or_right()))

      do i = 1, this%n_es_types

         if (this%es_states(i)%descriptor == descriptor) then

            states = cc_es_states_handler(trim(descriptor%get_left_or_right()))
            call states%add(descriptor, this%es_states(i)%n_states, this%es_states(i)%n_parameters)

            return

         end if
      end do

      call output%error_msg('Could not identify states of the requested type!')

   end function get_states_of_es_type


   subroutine remove_parallel_states(this, threshold)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!

      implicit none

      class(cc_es_states_handler), intent(inout) :: this
      real(dp), intent(in) :: threshold

      integer :: i

      this%n_total = 0

      do i = 1, this%n_es_types

         call this%es_states(i)%remove_parallel_states(threshold)
         this%n_total = this%n_total + this%es_states(i)%n_states

      end do

   end subroutine remove_parallel_states


end module cc_es_states_handler_class

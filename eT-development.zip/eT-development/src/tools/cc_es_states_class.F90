

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_es_states_class

   !!
   !! CC es storage tool class module
   !! Written by Sarai D. Folkestad, Feb 2022
   !!

   use parameters, only: dp
   use state_descriptor_class, only: state_descriptor
   use amplitude_file_storer_class, only: amplitude_file_storer

   implicit none

   type :: cc_es_states

      integer, public :: n_states, n_parameters
      type(state_descriptor), allocatable, public :: descriptor
      type(amplitude_file_storer), dimension(:), allocatable, public :: es_storers

   contains

      procedure, private :: initialize_storers

      generic, public :: is_ => is_string, is_of_type
      procedure, private :: is_string
      procedure, private :: is_of_type

      procedure, public :: read_energies

      procedure, public :: remove_parallel_states
      procedure, public :: transform
      procedure, private :: check_for_parallel_states
      procedure, private :: remove_parallel_states_from_file

   end type cc_es_states

   interface cc_es_states

      procedure :: new_cc_es_states

   end interface cc_es_states

contains

   function new_cc_es_states(n_states, n_parameters, descriptor) result(this)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      type(cc_es_states) :: this
      type(state_descriptor) :: descriptor
      integer, intent(in) :: n_parameters, n_states

      this%n_states = n_states
      this%n_parameters = n_parameters
      this%descriptor = descriptor

      call this%initialize_storers()

   end function new_cc_es_states


   subroutine initialize_storers(this)
      !!
      !! Written by Sarai D. Folkestad, 2024
      !!
      implicit none

      class(cc_es_states), intent(inout) :: this

      integer :: state

      allocate(this%es_storers(this%n_states))

      do state = 1, this%n_states

         this%es_storers(state) = amplitude_file_storer(this%descriptor%get_file_name(state), &
                                                        this%n_parameters)

      end do

   end subroutine initialize_storers


   function is_string(this, string) result(state_is)
      !!
      !! Written by Sarai D. Folkestad, 2024
      !!
      !! This routine can be used to check if state is
      !! 'left'/'right', or 'singlet'/'triplet'
      !!
      !!
      use global_out, only: output

      implicit none
      class(cc_es_states), intent(in) :: this
      character(len=*), intent(in) :: string

      logical :: state_is

      if (.not. (string == 'left' .or. string == 'right' .or. string == 'singlet' .or. string == 'triplet')) &
         call output%error_msg('Invalid descriptor string: ' // trim(string))

      state_is = &
         ((trim(this%descriptor%get_left_or_right()) == string) .or. &
         (trim(this%descriptor%get_spin_symmetry()) == string))

   end function is_string


   subroutine check_for_parallel_states(this, threshold, parallel_states)
      !!
      !! Written by Alexander C. Paul and Rolf H. Myhre, Oct 2019
      !!
      !! The solver might not ensure orthogonality of the states (e.g. in DIIS).
      !! Therefore, degenerate roots might be found where the eigenvectors
      !! are equal up to a sign (and within the convergence threshold)
      !!
      use array_utilities, only: check_for_parallel_vectors, get_equal_to_threshold
      use memory_manager_class, only: mem

      implicit none

      class(cc_es_states), intent(inout) :: this
      real(dp), intent(in) :: threshold
      logical, dimension(this%n_states), intent(out) :: parallel_states

      real(dp), dimension(:, :), allocatable :: vector
      real(dp), dimension(:), allocatable :: energies
      logical, dimension(:), allocatable :: parallel, degenerate, checked

      integer, dimension(:), allocatable :: degenerate_states
      integer :: current_state, p, counter
      integer :: n_degeneracy, reduced_degeneracy

      parallel_states = .false.

      call mem%alloc(degenerate, this%n_states)
      call mem%alloc(checked, this%n_states, set_to=.false.)

      call mem%alloc(energies, this%n_states)
      call this%read_energies(energies)

      do current_state = 1, this%n_states

         if (checked(current_state)) cycle

         degenerate = get_equal_to_threshold(energies, this%n_states, current_state, threshold)
         n_degeneracy = count(degenerate)
         if (n_degeneracy == 1) cycle

         call mem%alloc(vector, this%n_parameters, n_degeneracy)
         call mem%alloc(degenerate_states, n_degeneracy)

         counter = 0

         do p = current_state, this%n_states

            if (.not. degenerate(p)) cycle

            counter = counter + 1
            degenerate_states(counter) = p

            checked(p) = .true.
            call this%es_storers(p)%read_(vector(:, counter))

         end do

         call mem%alloc(parallel, n_degeneracy)

         call check_for_parallel_vectors(vector, &
                                         this%n_parameters, &
                                         n_degeneracy, &
                                         reduced_degeneracy, &
                                         threshold, &
                                         parallel)

         do p = 1, n_degeneracy

            if (parallel(p)) parallel_states(degenerate_states(p)) = .true.

         end do

         call mem%dealloc(degenerate_states)

         call mem%dealloc(parallel)
         call mem%dealloc(vector)


      end do

      call mem%dealloc(degenerate)
      call mem%dealloc(checked)
      call mem%dealloc(energies)

   end subroutine check_for_parallel_states


   subroutine remove_parallel_states(this, threshold)
      !!
      !! Written by Alexander C. Paul, Sep 2020
      !!
      use memory_manager_class, only: mem
      implicit none

      class(cc_es_states), intent(inout) :: this

      real(dp), intent(in) :: threshold

      logical, dimension(:), allocatable :: parallel

      call mem%alloc(parallel, this%n_states)
      call this%check_for_parallel_states(threshold, parallel)

      call this%remove_parallel_states_from_file(parallel)

      call mem%dealloc(parallel)

   end subroutine remove_parallel_states


   subroutine remove_parallel_states_from_file(this, parallel)
      !!
      !! Written by Alexander C. Paul, Sep 2020
      !!
      !! Send in vector of logicals determining which states are parallel.
      !! If a parallel states is found among the non-parallel ones,
      !! the file with the parallel state is overwritten with the following
      !! non-parallel states. Afterwards the last n_parallel files are deleted.
      !!
      use memory_manager_class, only: mem
      implicit none

      class(cc_es_states), intent(inout) :: this

      logical, dimension(this%n_states), intent(in) :: parallel

      real(dp), dimension(:), allocatable :: vector

      integer :: state, n_parallel
      real(dp) :: energy

      n_parallel = 0

      call mem%alloc(vector, this%n_parameters)

      do state = 1, this%n_states

         if (parallel(state)) then

            n_parallel = n_parallel + 1

            cycle

         else if (n_parallel > 0) then


            call this%es_storers(state)%read_(vector, energy)

            call this%es_storers(state - n_parallel)%save_(vector, energy)

         end if

      end do

      call mem%dealloc(vector)

      do state = this%n_states - n_parallel + 1, this%n_states

         call this%es_storers(state)%delete_file()

      end do

      deallocate(this%es_storers)

      this%n_states = this%n_states - n_parallel

      call this%initialize_storers()

   end subroutine remove_parallel_states_from_file


   subroutine read_energies(this, energies)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      class(cc_es_states), intent(inout) :: this
      real(dp), dimension(this%n_states), intent(out) :: energies

      integer :: i

      do i = 1, this%n_states
         call this%es_storers(i)%read_energy(energies(i))
      end do

   end subroutine read_energies


   pure function is_of_type(this, descriptor) result(is_)
      !!
      !! Written by Sarai D. Folkestad, 2024
      !!

      implicit none

      class(cc_es_states), intent(in) :: this
      type(state_descriptor), intent(in) :: descriptor

      logical :: is_

      is_ = (this%descriptor == descriptor)

   end function is_of_type


   subroutine transform(this, A, energies)
      !!
      !! Written by Alexander C. Paul, Sep 2020
      !!
      !! Performs
      !!
      !!    X_i = A_ij V_j
      !!
      !! where A is the transformation matrix and updates the energies
      !!
      use parameters
      use memory_manager_class, only: mem

      implicit none

      class(cc_es_states), intent(inout) :: this

      real(dp), dimension(this%n_states, this%n_states), intent(in) :: A
      real(dp), dimension(this%n_states), intent(in) :: energies

      real(dp), dimension(:, :), allocatable :: vectors_before, vectors_after

      integer :: i

      call mem%alloc(vectors_before, this%n_parameters, this%n_states)

      do i = 1, this%n_states

         call this%es_storers(i)%read_(vectors_before(:, i))

      end do

      call mem%alloc(vectors_after, this%n_parameters, this%n_states)

      call dgemm('n', &
                 'n', &
                 this%n_parameters, &
                 this%n_states, &
                 this%n_states, &
                 one, &
                 vectors_before, &
                 this%n_parameters, &
                 A, &
                 this%n_states, &
                 zero, &
                 vectors_after, &
                 this%n_parameters)

      do i = 1, this%n_states

         call this%es_storers(i)%save_(vectors_after(:, i), energies(i))

      end do

      call mem%dealloc(vectors_before)
      call mem%dealloc(vectors_after)

   end subroutine transform


end module cc_es_states_class

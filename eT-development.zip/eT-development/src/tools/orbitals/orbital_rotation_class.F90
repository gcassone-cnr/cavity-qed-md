

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module orbital_rotation_class
   !!
   !! Orbital rotation class
   !! Written by Sarai D. Folkestad, 2021-2022
   !!
   use parameters
   use memory_manager_class, only: mem

   implicit none

   type :: orbital_rotation

      real(dp), dimension(:, :), allocatable :: C
      real(dp), dimension(:, :), allocatable :: U

      integer :: n_ao, n_mo

   contains

      procedure, public :: initialize
      procedure, public :: cleanup
      procedure, public :: update_orbitals
      procedure, public :: get_orbitals

   end type orbital_rotation

   interface orbital_rotation

      procedure :: new_orbital_rotation

   end interface orbital_rotation

contains


   pure function new_orbital_rotation(n_mo, n_ao) result(this)
      !!
      !! New
      !! Written by Sarai D. Folkestad, 2021
      !!
      implicit none

      type(orbital_rotation) :: this

      integer, intent(in) :: n_ao, n_mo

      this%n_mo = n_mo
      this%n_ao = n_ao

   end function new_orbital_rotation


   subroutine update_orbitals(this, K)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, 2022-2023
      !!
      !! Update orbital coefficients with kappa according to
      !!      C = C exp(kappa)
      !!
      use array_utilities, only: unitary_from_exponential_of_antihermitian_matrix
      use reordering_r, only: squareup_anti

      implicit none

      class(orbital_rotation), intent(inout) :: this

      real(dp), dimension(this%n_mo * (this%n_mo - 1) / 2), intent(in) :: K
      real(dp), dimension(:, :), allocatable :: C_copy, K_square

      call mem%alloc(K_square, this%n_mo, this%n_mo)
      call squareup_anti(K, K_square, this%n_mo)

      call unitary_from_exponential_of_antihermitian_matrix(this%n_mo, K_square, this%U)

      call mem%alloc(C_copy, this%n_ao, this%n_mo)
      call dcopy(this%n_ao * this%n_mo, this%C, 1, C_copy, 1)

      call dgemm('N', &
                 'N', &
                 this%n_ao, &
                 this%n_mo, &
                 this%n_mo, &
                 one, &
                 C_copy, &
                 this%n_ao, &
                 this%U, &
                 this%n_mo, &
                 zero, &
                 this%C, &
                 this%n_ao)

      call mem%dealloc(C_copy)
      call mem%dealloc(K_square)

   end subroutine update_orbitals


   subroutine initialize(this, C)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, 2021
      !!
      use array_initialization, only: identity_array, copy_and_scale

      implicit none

      class(orbital_rotation), intent(inout) :: this

      real(dp), dimension(this%n_ao, this%n_mo), intent(in) :: C

      call mem%alloc(this%C, this%n_ao, this%n_mo)
      call copy_and_scale(one, C, this%C, this%n_ao * this%n_mo)

      call mem%alloc(this%U, this%n_mo, this%n_mo)
      call identity_array(this%U, this%n_mo)

   end subroutine initialize


   subroutine get_orbitals(this, C)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, 2021
      !!

      use array_initialization, only: copy_and_scale

      implicit none

      class(orbital_rotation), intent(in) :: this

      real(dp), dimension(this%n_ao, this%n_mo), intent(out) :: C

      call copy_and_scale(one, this%C, C, this%n_ao * this%n_mo)

   end subroutine get_orbitals


   subroutine cleanup(this)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, 2021
      !!
      implicit none

      class(orbital_rotation), intent(inout) :: this

      call mem%dealloc(this%C)
      call mem%dealloc(this%U)

   end subroutine cleanup


end module orbital_rotation_class

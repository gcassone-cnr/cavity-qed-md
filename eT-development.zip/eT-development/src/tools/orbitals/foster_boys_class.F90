

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module foster_boys_class
   !!
   !! Foster-Boys orbital localization class
   !! Written by Sarai D. Folkestad, 2021-2022
   !!
   !! Handles orbital localization using Foster-Boys approach
   !!
   !! See for instance Jansik et al., J. Chem. Phys. 134, 194104 (2011),
   !! https://doi.org/10.1063/1.3590361
   !!
   !! or Edmiston-Ruedenberg expressions in Folkestad et.al.,
   !! J. Chem. Theory Comput. 2022, 18, 4733-4744
   !!
   !! In Foster-Boys we minimize E_FB = (p|vec(r)|p)^2 and in Edmiston-Ruedenberg
   !! E_ER = (pp|pp), and therefore the gradient and Hessian have the same form
   !!
   use parameters
   use memory_manager_class, only: mem
   use global_out, only: output
   use orbital_rotation_class, only: orbital_rotation
   use abstract_orbital_localization_class, only: abstract_orbital_localization
   use ao_tool_class, only: ao_tool

   implicit none

   type, extends(abstract_orbital_localization) :: foster_boys

      integer, private :: n_ao

      real(dp), dimension(:, :, :), allocatable, private :: R_pq

      type(ao_tool), pointer, private :: ao

   contains

      procedure, public :: get_functional_value => get_functional_value_foster_boys
      procedure, public :: get_hessian_transformation => get_hessian_transformation_foster_boys
      procedure, public :: get_gradient => get_gradient_foster_boys
      procedure, public :: get_diagonal_hessian => get_diagonal_hessian_foster_boys
      procedure, public :: initialize => initialize_foster_boys
      procedure, public :: update_parameters => update_parameters_foster_boys

      procedure, private :: update_R
      procedure, private :: set_R_pq

      final :: cleanup

   end type foster_boys

   interface foster_boys

      procedure :: new_foster_boys

   end interface foster_boys

contains


   function new_foster_boys(ao, orbitals) result(this)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      implicit none

      type(foster_boys) :: this

      type(ao_tool), target :: ao
      type(orbital_rotation), target :: orbitals

      this%ao => ao
      this%orbitals => orbitals

      this%n_ao = this%orbitals%n_ao
      this%n_mo = this%orbitals%n_mo
      this%packed_gradient_dimension = this%orbitals%n_mo * (this%orbitals%n_mo - 1) / 2

      call output%printf('m', 'Foster-Boys orbital localization', fs='(/t3, a)')
      call output%print_separator('m', 40, '-', fs='(t3, a)')

   end function new_foster_boys


   function get_functional_value_foster_boys(this) result(E)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Calculates the Foster-Boys functional:
      !!
      !!    E = - sum_{k = x,y,z} <phi_p|k|phi_p>^2
      !!
      implicit none

      class(foster_boys), intent(in) :: this

      real(dp) :: E

      integer :: p, xyz

      E = zero
      do p = 1, this%n_mo
         do xyz = 1, 3

            E = E - this%R_pq(p, p, xyz)**2

         end do
      end do

   end function get_functional_value_foster_boys


   subroutine initialize_foster_boys(this)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      use omp_lib

      implicit none

      class(foster_boys), intent(inout) :: this

      call mem%alloc(this%R_pq, this%n_mo, this%n_mo, 3)
      call this%set_R_pq()

   end subroutine initialize_foster_boys


   subroutine get_gradient_foster_boys(this, gradient)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Calculates the Foster-Boys gradient:
      !!
      !!    g_pq = - 4 sum_{k = x,y,z} (R_pqk R_qqk - R_qpk R_qqk)
      !!
      !! where
      !!
      !!    R_pqk = <phi_p|k|phi_q>
      !!
      use omp_lib
      use array_initialization, only: zero_array

      implicit none

      class(foster_boys), intent(in) :: this

      real(dp), dimension(this%packed_gradient_dimension), intent(out) :: gradient

      integer :: p, q, pq, xyz

      call zero_array(gradient, this%packed_gradient_dimension)

      !$omp parallel do private(p, q, pq)
      do p = 2, this%n_mo
         do q = 1, p - 1

            pq = (p - 1) * ((p - 1) - 3) / 2 + p - 1 + q

            do xyz = 1, 3

               gradient(pq) = gradient(pq) &
                              - four &
                              * (this%R_pq(p, q, xyz) * this%R_pq(q, q, xyz) &
                              - this%R_pq(q, p, xyz) * this%R_pq(p, p, xyz))

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine get_gradient_foster_boys


   subroutine get_diagonal_hessian_foster_boys(this, diagonal_hessian)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Calculates the Foster-Boys diagonal Hessian:
      !!
      !!    H_pq,pq = sum_{k = x,y,z} (- 4 R_qqk R_ppk - 8 R_pqk^2
      !!                               + 2 R_ppk^2 + 2 R_qqk^2 )
      !!
      !! where
      !!
      !!    R_pqk = <phi_p|k|phi_q>
      !!
      use reordering_r, only: packin_anti
      use omp_lib

      implicit none

      class(foster_boys), intent(in) :: this

      real(dp), dimension(this%packed_gradient_dimension), intent(out) :: diagonal_hessian

      real(dp), dimension(:, :), allocatable :: diagonal_hessian_sq

      integer :: p, q, xyz

      call mem%alloc(diagonal_hessian_sq, this%n_mo, this%n_mo, set_zero=.true.)

      !$omp parallel do private(p, q, xyz)
      do q = 1, this%n_mo
         do p = 1, this%n_mo
            do xyz = 1, 3

               diagonal_hessian_sq(p, q) = diagonal_hessian_sq(p, q) &
                                           - four * this%R_pq(q, q, xyz) * this%R_pq(p, p, xyz) &
                                           - eight * this%R_pq(p, q, xyz)**2 + two * this%R_pq(p, p, xyz)**2 &
                                           + two * this%R_pq(q, q, xyz)**2

            end do
         end do
      end do
      !$omp end parallel do

      call packin_anti(diagonal_hessian, diagonal_hessian_sq, this%n_mo)
      call mem%dealloc(diagonal_hessian_sq)

   end subroutine get_diagonal_hessian_foster_boys


   subroutine get_hessian_transformation_foster_boys(this, b, rho)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Calculates the transformation by the Foster-Boys Hessian
      !!
      !!    rho_pq = X_pq - X_qp
      !!
      !! where
      !!
      !!    X_pq = sum_{k = x,y,z} (4 R_qrk R_ppk b_rp
      !!                           + 8 R_pqk R_rpk b_rp
      !!                           - 2 R_qrk R_rrk b_rp
      !!                           - 2 R_qrk R_qqk b_rp)
      !!
      use reordering_r, only: squareup_anti, packin_anti, sort_to_21
      use omp_lib

      implicit none

      class(foster_boys), intent(in) :: this

      real(dp), dimension(this%packed_gradient_dimension), intent(in) :: b
      real(dp), dimension(this%packed_gradient_dimension), intent(out) :: rho

      real(dp), dimension(:, :), allocatable :: b_square, X_pq, X_qp

      integer :: p, q, r, xyz

      call mem%alloc(b_square, this%n_mo, this%n_mo)
      call mem%alloc(X_pq, this%n_mo, this%n_mo, set_zero=.true.)

      call squareup_anti(b, b_square, this%n_mo)

      !$omp parallel do private (p, q, r)
      do q = 1, this%n_mo
         do p = 1, this%n_mo
            do r = 1, this%n_mo
               do xyz = 1, 3

                  X_pq(p, q) = X_pq(p, q) &
                               + four * this%R_pq(q, r, xyz) * this%R_pq(p, p, xyz) * b_square(r, p) &
                               + eight * this%R_pq(p, q, xyz) * this%R_pq(r, p, xyz) * b_square(r, p) &
                               - two * this%R_pq(q, r, xyz) * this%R_pq(r, r, xyz) * b_square(r, p) &
                               - two * this%R_pq(q, r, xyz) * this%R_pq(q, q, xyz) * b_square(r, p)

               end do
            end do
         end do
      end do
      !$omp end parallel do

      call mem%alloc(X_qp, this%n_mo, this%n_mo)
      call sort_to_21(X_pq, X_qp, this%n_mo, this%n_mo)

      call daxpy(this%n_mo**2, - one, X_qp, 1, X_pq, 1)
      call packin_anti(rho, X_pq, this%n_mo)

      call mem%dealloc(X_qp)
      call mem%dealloc(X_pq)
      call mem%dealloc(b_square)

   end subroutine get_hessian_transformation_foster_boys


   subroutine update_R(this)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      implicit none

      class(foster_boys), intent(inout) :: this

      real(dp), dimension(:, :), allocatable :: R_px, R_wx

      integer :: xyz

      call mem%alloc(R_px, this%n_mo, this%n_mo)
      call mem%alloc(R_wx, this%n_mo, this%n_mo)

      do xyz = 1, 3

         call dgemm('N', &
                    'N', &
                    this%n_mo, &
                    this%n_mo, &
                    this%n_mo, &
                    one, &
                    this%R_pq(:, :, xyz), &
                    this%n_mo, &
                    this%orbitals%U, &
                    this%n_mo, &
                    zero, &
                    R_px, &
                    this%n_mo)

         call dgemm('T', &
                    'N', &
                    this%n_mo, &
                    this%n_mo, &
                    this%n_mo, &
                    one, &
                    this%orbitals%U, &
                    this%n_mo, &
                    R_px, &
                    this%n_mo, &
                    zero, &
                    R_wx, &
                    this%n_mo)

         call dcopy(this%n_mo**2, R_wx, 1, this%R_pq(:, :, xyz), 1)

      end do

      call mem%dealloc(R_px)
      call mem%dealloc(R_wx)

   end subroutine update_R


   subroutine set_R_pq(this)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      use array_utilities, only: symmetric_sandwich
      implicit none

      class(foster_boys), intent(inout) :: this

      real(dp), dimension(:, :, :), allocatable :: mu_wxk

      integer :: component

      call mem%alloc(mu_wxk, this%ao%n, this%ao%n, 3)
      call this%ao%get_oei('dipole', mu_wxk)

      do component = 1, 3

         call symmetric_sandwich(this%R_pq(:, :, component), &
                                 mu_wxk(:, :, component), &
                                 this%orbitals%C, &
                                 this%n_ao, &
                                 this%n_mo)

      end do

      call mem%dealloc(mu_wxk)

   end subroutine set_R_pq


   subroutine update_parameters_foster_boys(this, X)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      implicit none

      class(foster_boys), intent(inout) :: this
      real(dp), dimension(this%n_mo * (this%n_mo - 1) / 2), intent(in) :: X

      call this%orbitals%update_orbitals(X)
      call this%update_R()

   end subroutine update_parameters_foster_boys


   subroutine cleanup(this)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      implicit none

      type(foster_boys), intent(inout) :: this

      if (allocated(this%R_pq)) call mem%dealloc(this%R_pq)

   end subroutine cleanup


end module foster_boys_class


! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module orbital_diabatizer_class
   !!
   !! Orbital diabatizer class
   !! Written by Eirik F. Kjoenstad, 2024
   !!
   !! Compares current (C) and previous (C^0) orbitals
   !! by considering the overlap matrix
   !!
   !!    A_pq = C_p,alpha^0 S_alpha,beta C_q,beta
   !!
   !! It will try to make A_pq as much as possible a
   !! diagonal matrix by
   !!
   !!    1. Exchanging orbitals if off-diagonal components
   !!       dominate
   !!
   !!    2. Swapping sign of orbital if diagonal element is
   !!       not positive
   !!
   !! Consistent orbitals is useful to maintain a consistent
   !! phase and orbital ordering for the post-HF coefficient,
   !! e.g. the cluster amplitudes.
   !!
   use parameters
   use memory_manager_class, only: mem
   use global_out, only: output

   implicit none

   type :: orbital_diabatizer

      integer, private :: n_ao, n_mo, n_o

   contains

      procedure, public :: diabatize

      procedure, private :: construct_overlap
      procedure, private :: correct_for_orbital_crossings
      procedure, private :: correct_for_orbital_sign_flips

   end type orbital_diabatizer


   interface orbital_diabatizer

      procedure :: new_orbital_diabatizer

   end interface orbital_diabatizer


contains


   function new_orbital_diabatizer(n_ao, n_mo, n_o) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      integer, intent(in) :: n_ao, n_mo, n_o

      type(orbital_diabatizer) :: this

      this%n_ao = n_ao
      this%n_mo = n_mo
      this%n_o = n_o

   end function new_orbital_diabatizer


   subroutine diabatize(this, &
                        C0, &
                        S, &
                        C, &
                        epsilon)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      use array_utilities, only: get_trace

      implicit none

      class(orbital_diabatizer), intent(in) :: this

      real(dp), dimension(this%n_ao, this%n_mo), intent(in) :: C0
      real(dp), dimension(this%n_ao, this%n_ao), intent(in) :: S
      real(dp), dimension(this%n_ao, this%n_mo), intent(inout) :: C
      real(dp), dimension(this%n_mo), intent(inout) :: epsilon

      real(dp) :: trace_before, trace_after

      real(dp), dimension(:, :), allocatable :: A

      call output%printf('n', '- Diabatizing orbitals', fs='(/t3,a/)')

      call output%printf('m', &
         'We change the order and signs of the current orbitals by consideration of the overlap matrix A_pq(x&
         &) = C_alpha,p(x0) S_alpha,beta(x) C_beta,q(x). In particular, if the diagonal is close to -1, the&
         & corresponding orbital sign is flipped, and if a 2x2 block of A is dominated by the off-diagonals,&
         & then the two corresponding orbitals are exchanged. This provides consistent orbital phases for&
         & nearby geometries, which can provide consistent restart guesses and consistent phases of the&
         & electronic states for different geometries on the potential energy surfaces.', &
         fs = '(t6,a)')

      call mem%alloc(A, this%n_mo, this%n_mo)

      call this%construct_overlap(A, C0, S, C)

      trace_before = get_trace(A, this%n_mo)

      call this%correct_for_orbital_crossings(A, C, epsilon)

      call this%construct_overlap(A, C0, S, C)

      call this%correct_for_orbital_sign_flips(A, C)

      call this%construct_overlap(A, C0, S, C)

      trace_after = get_trace(A, this%n_mo)

      call output%printf('m', 'Completed orbital diabatization!', fs='(/t6,a)')

      call output%printf('m', 'Number of molecular orbitals: (i0)', ints=[this%n_mo], fs='(/t6,a)')

      call output%printf('m', &
                         'Trace of original overlap matrix:   (f19.12)', &
                         reals=[trace_before], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Trace of diabatized overlap matrix: (f19.12)', &
                         reals=[trace_after], &
                         fs='(t6,a)')

      call mem%dealloc(A)

   end subroutine diabatize


   subroutine construct_overlap(this, A, C0, S, C)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      class(orbital_diabatizer), intent(in) :: this

      real(dp), dimension(this%n_mo, this%n_mo), intent(out) :: A

      real(dp), dimension(this%n_ao, this%n_mo), intent(in) :: C0
      real(dp), dimension(this%n_ao, this%n_ao), intent(in) :: S
      real(dp), dimension(this%n_ao, this%n_mo), intent(in) :: C

      real(dp), dimension(:, :), allocatable :: SC

      call mem%alloc(SC, this%n_ao, this%n_mo)

      call dgemm('N', &
                 'N', &
                 this%n_ao, &
                 this%n_mo, &
                 this%n_ao, &
                 one, &
                 S, &
                 this%n_ao, &
                 C, &
                 this%n_ao, &
                 zero, &
                 SC, &
                 this%n_ao)

      call dgemm('T', &
                 'N', &
                 this%n_mo, &
                 this%n_mo, &
                 this%n_ao, &
                 one, &
                 C0, &
                 this%n_ao, &
                 SC, &
                 this%n_ao, &
                 zero, &
                 A, &
                 this%n_mo)

      call mem%dealloc(SC)

   end subroutine construct_overlap


   subroutine correct_for_orbital_crossings(this, A, C, epsilon)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      class(orbital_diabatizer), intent(in) :: this

      real(dp), dimension(this%n_mo, this%n_mo), intent(inout) :: A
      real(dp), dimension(this%n_mo, this%n_mo), intent(inout) :: C
      real(dp), dimension(this%n_mo), intent(inout) :: epsilon

      integer :: i, j

      real(dp), dimension(:), allocatable :: temp_orbital, temp_A_column

      real(dp) :: temp_epsilon

      call output%printf('m', 'Checking for orbital crossings...', fs='(/t6,a)')

      call mem%alloc(temp_orbital, this%n_ao)
      call mem%alloc(temp_A_column, this%n_mo)

      do i = 1, this%n_mo
         do j = i + 1, this%n_mo

            ! We do not want to exchange an occupied with a
            ! virtual as this changes the Hartree-Fock solution!
            if (i <= this%n_o .and. j > this%n_o) cycle

            ! Check if off-diagonals in the ij block dominate
            if (abs(A(i, i)) + abs(A(j, j)) < abs(A(i, j)) + abs(A(j, i))) then

               call output%printf('m', 'Exchanging orbitals (i0) and (i0)', ints=[i, j], fs='(t9,a)')

               ! Swap orbitals
               temp_orbital = C(:, j)
               C(:, j) = C(:, i)
               C(:, i) = temp_orbital

               temp_epsilon = epsilon(j)
               epsilon(j) = epsilon(i)
               epsilon(i) = temp_epsilon

               ! Swap columns in A instead of recomputing A
               temp_A_column = A(:, j)
               A(:, j) = A(:, i)
               A(:, i) = temp_A_column

            end if

         end do
      end do

      call mem%dealloc(temp_A_column)
      call mem%dealloc(temp_orbital)

   end subroutine correct_for_orbital_crossings


   subroutine correct_for_orbital_sign_flips(this, A, C)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      class(orbital_diabatizer), intent(in) :: this

      real(dp), dimension(this%n_mo, this%n_mo), intent(in) :: A
      real(dp), dimension(this%n_mo, this%n_mo), intent(inout) :: C

      integer :: i

      call output%printf('m', 'Checking for orbital sign change...', fs='(t6,a)')

      do i = 1, this%n_mo

         if (A(i, i) < zero) then

            call output%printf('m', 'Flipping the sign of orbital (i0)', ints=[i], fs='(t9,a)')
            C(:, i) = - C(:, i)

         end if

      end do

   end subroutine correct_for_orbital_sign_flips



end module orbital_diabatizer_class

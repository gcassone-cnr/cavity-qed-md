

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_orbital_localization_class

   !!
   !! Abstract orbital localization class
   !! Written by Sarai D. Folkestad, 2021-2022
   !!

   use kinds, only: dp
   use orbital_rotation_class, only: orbital_rotation

   implicit none

   type, abstract :: abstract_orbital_localization

      integer :: n_mo, packed_gradient_dimension

      type(orbital_rotation), pointer :: orbitals

   contains

      procedure(initialize_abstract), deferred :: initialize
      procedure(get_functional_value_abstract), deferred :: get_functional_value
      procedure(get_diagonal_hessian_abstract), deferred :: get_diagonal_hessian
      procedure(get_hessian_transformation_abstract), deferred :: get_hessian_transformation
      procedure(get_gradient_abstract), deferred :: get_gradient
      procedure(update_parameters_abstract), deferred :: update_parameters

   end type abstract_orbital_localization

   abstract interface

      subroutine initialize_abstract(this)
         !!
         !! Written by Sarai D. Folkestad, 2021-2022
         !!
         import abstract_orbital_localization

         implicit none

         class(abstract_orbital_localization), intent(inout) :: this

      end subroutine initialize_abstract


      function get_functional_value_abstract(this) result(E)
         !!
         !! Written by Sarai D. Folkestad, 2021-2022
         !!
         import dp
         import abstract_orbital_localization

         implicit none

         class(abstract_orbital_localization), intent(in) :: this

         real(dp) :: E

      end function get_functional_value_abstract


      subroutine get_gradient_abstract(this, gradient)
         !!
         !! Written by Sarai D. Folkestad, 2021-2022
         !!
         import dp
         import abstract_orbital_localization

         implicit none

         class(abstract_orbital_localization), intent(in) :: this

         real(dp), dimension(this%packed_gradient_dimension), intent(out) :: gradient

      end subroutine get_gradient_abstract


      subroutine get_diagonal_hessian_abstract(this, diagonal_hessian)
         !!
         !! Written by Sarai D. Folkestad, 2021-2022
         !!
         import dp
         import abstract_orbital_localization

         implicit none

         class(abstract_orbital_localization), intent(in) :: this

         real(dp), dimension(this%packed_gradient_dimension), intent(out) :: diagonal_hessian

      end subroutine get_diagonal_hessian_abstract


      subroutine get_hessian_transformation_abstract(this, b, rho)
         !!
         !! Written by Sarai D. Folkestad, 2021-2022
         !!
         import dp
         import abstract_orbital_localization

         implicit none

         class(abstract_orbital_localization), intent(in) :: this

         real(dp), dimension(this%packed_gradient_dimension), intent(in) :: b
         real(dp), dimension(this%packed_gradient_dimension), intent(out) :: rho

      end subroutine get_hessian_transformation_abstract


      subroutine update_parameters_abstract(this, X)
         !!
         !! Written by Sarai D. Folkestad, 2021-2022
         !!
         import dp
         import abstract_orbital_localization

         implicit none

         class(abstract_orbital_localization), intent(inout) :: this
         real(dp), dimension(this%n_mo * (this%n_mo - 1) / 2), intent(in) :: X

      end subroutine update_parameters_abstract


   end interface


end module abstract_orbital_localization_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module edmiston_ruedenberg_class
   !!
   !! Edmiston-Ruedenberg orbital localization class
   !! Written by Sarai D. Folkestad, 2021-2022
   !!
   !! Handles ornital localization using Edmiston-Ruedenberg orbital
   !! localization function
   !!
   !! See Folkestad et al., J. Chem. Theory Comput. 2022, 18, 4733-4744
   !!
   use parameters
   use eri_cholesky_disk_class, only: eri_cholesky_disk
   use memory_manager_class, only: mem
   use global_out, only: output
   use orbital_rotation_class, only: orbital_rotation
   use abstract_orbital_localization_class, only: abstract_orbital_localization

   implicit none

   type, extends(abstract_orbital_localization) :: edmiston_ruedenberg

      integer :: n_ao

      type(eri_cholesky_disk), pointer :: L

      real(dp), dimension(:, :, :), allocatable :: L_pq, Z
      real(dp), dimension(:), allocatable :: diagonal_hessian

   contains

      procedure, public :: get_functional_value => get_functional_value_edmiston_ruedenberg
      procedure, public :: get_hessian_transformation => get_hessian_transformation_edmiston_ruedenberg
      procedure, public :: get_gradient => get_gradient_edmiston_ruedenberg
      procedure, public :: get_diagonal_hessian => get_diagonal_hessian_edmiston_ruedenberg
      procedure, public :: initialize => initialize_edmiston_ruedenberg
      procedure, public :: update_parameters => update_parameters_edmiston_ruedenberg

      procedure, private :: get_X
      procedure, private :: get_Y
      procedure, private :: set_Z
      procedure, private :: get_W
      procedure, private :: update_L
      procedure, private :: update_diagonal_hessian

      final :: cleanup

      procedure, private :: set_mo_cholesky

   end type edmiston_ruedenberg

   interface edmiston_ruedenberg

      procedure :: new_edmiston_ruedenberg

   end interface edmiston_ruedenberg

contains

   function new_edmiston_ruedenberg(L, orbitals) result(this)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      implicit none

      type(edmiston_ruedenberg) :: this

      type(eri_cholesky_disk), target :: L
      type(orbital_rotation), target :: orbitals

      this%L => L
      this%orbitals => orbitals

      this%packed_gradient_dimension = this%orbitals%n_mo * (this%orbitals%n_mo - 1) / 2
      this%n_ao = this%orbitals%n_ao
      this%n_mo = this%orbitals%n_mo

      call output%printf('m', 'Edmiston-Ruedenberg orbital localization', fs='(/t3, a)')
      call output%print_separator('m', 40, '-', fs='(t3, a)')

   end function new_edmiston_ruedenberg


   function get_functional_value_edmiston_ruedenberg(this) result(E)
      !!
      !! Written by sarai Dery Folkestad, 2021
      !!
      implicit none

      class(edmiston_ruedenberg), intent(in) :: this

      real(dp) :: E

      integer :: p, J

      E = zero
      do p = 1, this%n_mo
         do J = 1, this%L%n_J

            E = E - this%L_pq(J, p, p)**2

         end do
      end do

   end function get_functional_value_edmiston_ruedenberg


   subroutine initialize_edmiston_ruedenberg(this)
      !!
      !! Written by Sarai D. Folkestad, 2021-2022
      !!
      implicit none

      class(edmiston_ruedenberg), intent(inout) :: this

      call mem%alloc(this%L_pq, this%L%n_J, this%n_mo, this%n_mo)
      call mem%alloc(this%Z, this%n_mo, this%n_mo, this%n_mo)
      call mem%alloc(this%diagonal_hessian, this%packed_gradient_dimension)
      call this%set_mo_cholesky()
      call this%set_Z()
      call this%update_diagonal_hessian()

   end subroutine initialize_edmiston_ruedenberg


   subroutine get_gradient_edmiston_ruedenberg(this, gradient)
      !!
      !! Written by Sarai D. Folkestad, 2021-2022
      !!
      !! Computes the gradient
      !!    g_pq = -4[(pq|qq) - (qp|pp)]
      !!
      use omp_lib
      use array_initialization, only: zero_array

      implicit none

      class(edmiston_ruedenberg), intent(in) :: this

      real(dp), dimension(this%packed_gradient_dimension), intent(out) :: gradient

      integer :: p, q, pq, J

      call zero_array(gradient, this%packed_gradient_dimension)

      !$omp parallel do private(p, q, pq, J)
      do p = 2, this%n_mo
         do q = 1, p - 1

            pq = (p - 1) * ((p - 1) - 3) / 2 + p - 1 + q

            do J = 1, this%L%n_J

               gradient(pq) = gradient(pq) &
                              - four &
                              * (this%L_pq(J, p, q) * this%L_pq(J, q, q) &
                              - this%L_pq(J, q, p) * this%L_pq(J, p, p))

            end do

         end do
      end do
      !$omp end parallel do

   end subroutine get_gradient_edmiston_ruedenberg


   subroutine get_diagonal_hessian_edmiston_ruedenberg(this, diagonal_hessian)
      !!
      !! Written by Sarai D. Folkestad, 2021-2022
      !!
      implicit none

      class(edmiston_ruedenberg), intent(in) :: this

      real(dp), dimension(this%packed_gradient_dimension), intent(out) :: diagonal_hessian

      call dcopy(this%packed_gradient_dimension, this%diagonal_hessian, 1, diagonal_hessian, 1)

   end subroutine get_diagonal_hessian_edmiston_ruedenberg


   subroutine update_diagonal_hessian(this)
      !!
      !! Written by Sarai D. Folkestad, 2021-2022
      !!
      use reordering_r, only: packin_anti
      use omp_lib

      implicit none

      class(edmiston_ruedenberg), intent(inout) :: this

      real(dp), dimension(:, :), allocatable :: diagonal_hessian_sq
      real(dp), dimension(:, :), allocatable :: X

      integer :: p, q, J

      call mem%alloc(X, this%L%n_J, this%n_mo)
      call this%get_X(X, this%L_pq)

      call mem%alloc(diagonal_hessian_sq, this%n_mo, this%n_mo, set_zero=.true.)

      !$omp parallel do private(p, q, J)
      do q = 1, this%n_mo
         do p = 1, this%n_mo
            do J = 1, this%L%n_J

               diagonal_hessian_sq(p, q) = diagonal_hessian_sq(p, q) - four * X(J, p) * X(J, q) &
                                           - eight * this%L_pq(J, p, q)**2 + two * X(J, p)**2 &
                                           + two * X(J, q)**2

            end do
         end do
      end do
      !$omp end parallel do

      call mem%dealloc(X)

      call packin_anti(this%diagonal_hessian, diagonal_hessian_sq, this%n_mo)
      call mem%dealloc(diagonal_hessian_sq)


   end subroutine update_diagonal_hessian


   subroutine set_mo_cholesky(this)
      !!
      !! Written by Sarai D. Folkestad, 2021-2022
      !!
      implicit none

      class(edmiston_ruedenberg), intent(inout) :: this

      call this%L%get(this%L_pq, 1, this%n_mo, 1, this%n_mo)

   end subroutine set_mo_cholesky


   subroutine get_X(this, X, L_Jpq)
      !!
      !! Written by Sarai D. Folkestad, 2021-2022
      !!
      !! X^J_p = L^J_pp
      !! (see eq 31 in J. Chem. Theory Comput. 2022, 18, 4733-4744)
      !!
      implicit none

      class(edmiston_ruedenberg), intent(in) :: this
      real(dp), dimension(this%L%n_J, this%n_mo), intent(out) :: X
      real(dp), dimension(this%L%n_J, this%n_mo, this%n_mo), intent(in) :: L_Jpq

      integer :: p, J

      !$omp parallel do private (p, J)
      do p = 1, this%n_mo
         do J = 1, this%L%n_J

            X(J, p) = L_Jpq(J, p, p)

         end do
      end do
      !$omp end parallel do


   end subroutine get_X


   subroutine get_Y(this, Y, L_Jpq, K)
      !!
      !! Written by Sarai D. Folkestad, 2021-2022
      !!
      !! Y_q^J = sum_p L_pq^J k_pq
      !! (see eq 32 in J. Chem. Theory Comput. 2022, 18, 4733-4744)
      !!
      use array_initialization, only: zero_array

      implicit none

      class(edmiston_ruedenberg), intent(in) :: this
      real(dp), dimension(this%L%n_J, this%n_mo), intent(out) :: Y
      real(dp), dimension(this%L%n_J, this%n_mo, this%n_mo), intent(in) :: L_Jpq
      real(dp), dimension(this%n_mo, this%n_mo), intent(in) :: K

      integer :: p, q, J

      call zero_array(Y, this%L%n_J * this%n_mo)

      !$omp parallel do private (J, q, p)
      do q = 1, this%n_mo
         do p = 1, this%n_mo
            do J = 1, this%L%n_J

               Y(J, q) = Y(J, q) + L_Jpq(J, p, q) * K(p, q)

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine get_Y


   subroutine set_Z(this)
      !!
      !! Written by Sarai D. Folkestad, 2021-2022
      !!
      !! Z_pqr = sum_J L_pq^J X_r^J
      !! (see eq 33 in J. Chem. Theory Comput. 2022, 18, 4733-4744)
      !!
      implicit none

      class(edmiston_ruedenberg), intent(in) :: this
      real(dp), dimension(:, :), allocatable :: X

      call mem%alloc(X, this%L%n_J, this%n_mo)
      call this%get_X(X, this%L_pq)

      call dgemm('T', &
                 'N', &
                 this%n_mo**2, &
                 this%n_mo, &
                 this%L%n_J, &
                 one, &
                 this%L_pq, &
                 this%L%n_J, &
                 X, &
                 this%L%n_J, &
                 zero, &
                 this%Z, &
                 this%n_mo**2)

      call mem%dealloc(X)

   end subroutine set_Z


   subroutine get_W(this, W, L_Jpq, X)
      !!
      !! Written by Sarai D. Folkestad, 2021-2022
      !!
      !! W_pq = sum_J L_pq^J X_p^J
      !! (see eq 34 in J. Chem. Theory Comput. 2022, 18, 4733-4744)
      !!
      use array_initialization, only: zero_array
      implicit none

      class(edmiston_ruedenberg), intent(in) :: this
      real(dp), dimension(this%n_mo, this%n_mo), intent(out) :: W
      real(dp), dimension(this%L%n_J, this%n_mo, this%n_mo), intent(in) :: L_Jpq
      real(dp), dimension(this%L%n_J, this%n_mo), intent(in) :: X

      integer :: p, q, J

      call zero_array(W, this%n_mo**2)

      !$omp parallel do private (p, J, q)
      do q = 1, this%n_mo
         do p = 1, this%n_mo
            do J = 1, this%L%n_J

               W(p, q) = W(p, q) + L_Jpq(J, p, q) * X(J, p)

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine get_W


   subroutine get_hessian_transformation_edmiston_ruedenberg(this, b, rho)
      !!
      !! Written by Sarai D. Folkestad, 2021-2022
      !!
      !! Computes Hessian transformation sigma_pq by a vector according to
      !! sigma_pq = 4 sum_r Z_rpq k_rq + 8 sum_J Y_q^J L_pq^J
      !!          + 2 sum_r (k_rp W_rq + W_pr k_qr)
      !! See eq 37 in J. Chem. Theory Comput. 2022, 18, 4733-4744
      !!
      use reordering_r, only: squareup_anti, packin_anti, sort_to_21
      use omp_lib

      implicit none

      class(edmiston_ruedenberg), intent(in) :: this

      real(dp), dimension(this%packed_gradient_dimension), intent(in) :: b
      real(dp), dimension(this%packed_gradient_dimension), intent(out) :: rho

      real(dp), dimension(:, :), allocatable :: b_sq, rho_sq, rho_sq_2
      real(dp), dimension(:, :), allocatable :: X, Y, W

      integer :: p, q, r, J

      call mem%alloc(b_sq, this%n_mo, this%n_mo)
      call mem%alloc(rho_sq, this%n_mo, this%n_mo, set_zero=.true.)

      call squareup_anti(b, b_sq, this%n_mo)

      call mem%alloc(X, this%L%n_J, this%n_mo)
      call mem%alloc(Y, this%L%n_J, this%n_mo)
      call mem%alloc(W, this%n_mo, this%n_mo)

      call this%get_X(X, this%L_pq)
      call this%get_W(W, this%L_pq, X)

      call mem%dealloc(X)

      call this%get_Y(Y, this%L_pq, b_sq)

      !$omp parallel do private (p, q, r)
      do q = 1, this%n_mo
         do p = 1, this%n_mo
            do r = 1, this%n_mo

               rho_sq(p, q) = rho_sq(p, q) - four * this%Z(r, p, q) * b_sq(r, q)

            end do
         end do
      end do
      !$omp end parallel do

      !$omp parallel do private(p, q, J)
      do q = 1, this%n_mo
         do p = 1, this%n_mo
            do J = 1, this%L%n_J

               rho_sq(p, q) = rho_sq(p, q) - eight * Y(J, q) * this%L_pq(J, p, q)

            end do
         end do
      end do
      !$omp end parallel do

      !$omp parallel do private(p, q, r)
      do q = 1, this%n_mo
         do p = 1, this%n_mo
            do r = 1, this%n_mo

               rho_sq(p, q) = rho_sq(p, q) - two * b_sq(r, p) * W(r, q) - two * b_sq(q, r) * W(p, r)

            end do
         end do
      end do
      !$omp end parallel do

      call mem%dealloc(Y)
      call mem%dealloc(W)

      call mem%alloc(rho_sq_2, this%n_mo, this%n_mo)
      call sort_to_21(rho_sq, rho_sq_2, this%n_mo, this%n_mo)

      call daxpy(this%n_mo**2, - one, rho_sq_2, 1, rho_sq, 1)
      call packin_anti(rho, rho_sq, this%n_mo)

      call mem%dealloc(rho_sq_2)
      call mem%dealloc(rho_sq)
      call mem%dealloc(b_sq)

   end subroutine get_hessian_transformation_edmiston_ruedenberg


   subroutine cleanup(this)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      implicit none

      type(edmiston_ruedenberg), intent(inout) :: this

      if (allocated(this%L_pq)) call mem%dealloc(this%L_pq)
      if (allocated(this%Z)) call mem%dealloc(this%Z)
      if (allocated(this%diagonal_hessian)) call mem%dealloc(this%diagonal_hessian)

   end subroutine cleanup


   subroutine update_L(this)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Updates the Cholesky vectors to the new MO basis.
      !!
      use reordering_r, only: sort_to_132

      implicit none

      class(edmiston_ruedenberg), intent(inout) :: this

      real(dp), dimension(:, :, :), allocatable :: L_Jpx, L_Jxp

      call mem%alloc(L_Jpx, this%L%n_J, this%n_mo, this%n_mo)

      call dgemm('N', &
                 'N', &
                 this%L%n_J * this%n_mo, &
                 this%n_mo, &
                 this%n_mo, &
                 one, &
                 this%L_pq, &
                 this%L%n_J * this%n_mo, &
                 this%orbitals%U, &
                 this%n_mo, &
                 zero, &
                 L_Jpx, &
                 this%L%n_J * this%n_mo)

      call mem%alloc(L_Jxp, this%L%n_J, this%n_mo, this%n_mo)
      call sort_to_132(L_Jpx, L_Jxp, this%L%n_J, this%n_mo, this%n_mo)
      call mem%dealloc(L_Jpx)

      call dgemm('N', &
                 'N', &
                 this%L%n_J * this%n_mo, &
                 this%n_mo, &
                 this%n_mo, &
                 one, &
                 L_Jxp, &
                 this%L%n_J * this%n_mo, &
                 this%orbitals%U, &
                 this%n_mo, &
                 zero, &
                 this%L_pq, &
                 this%L%n_J * this%n_mo)

      call mem%dealloc(L_Jxp)


   end subroutine update_L


   subroutine update_parameters_edmiston_ruedenberg(this, X)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      implicit none

      class(edmiston_ruedenberg), intent(inout) :: this
      real(dp), dimension(this%n_mo * (this%n_mo - 1) / 2), intent(in) :: X

      call this%orbitals%update_orbitals(X)
      call this%update_L()
      call this%set_Z()
      call this%update_diagonal_hessian()

   end subroutine update_parameters_edmiston_ruedenberg


end module edmiston_ruedenberg_class

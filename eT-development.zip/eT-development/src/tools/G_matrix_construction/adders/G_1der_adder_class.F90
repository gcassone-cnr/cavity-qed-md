

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.

module G_1der_adder_class
   !!
   !! G derivative adder class
   !! Written by Marcus T. Lexander, 2024
   !!
   use parameters
   use ao_tool_class, only: ao_tool
   use abstract_G_adder_class, only: abstract_G_adder
   use G_adder_class, only: G_adder

   implicit none

   type, extends(abstract_G_adder) :: G_1der_adder

   contains

      procedure :: add => add_G_1der_adder

   end type G_1der_adder

   interface G_1der_adder

      procedure :: new_G_1der_adder

   end interface G_1der_adder

contains


   function new_G_1der_adder(n_components) result(this)
      !!
      !! Written by Marcus T. Lexander, 2024
      !!
      implicit none

      type(G_1der_adder) :: this

      integer, intent(in) :: n_components

      this%n_components = n_components

   end function new_G_1der_adder


   subroutine add_G_1der_adder(this, ao, D, G, eri, s1, s2, s3, s4, degeneracy)
      !!
      !! Written by Marcus T. Lexander, 2024
      !!
      implicit none

      class(G_1der_adder), intent(in) :: this

      class(ao_tool), intent(in) :: ao
      real(dp), dimension(ao%n, ao%n, this%n_components), intent(inout) :: G
      real(dp), dimension(ao%n, ao%n), intent(in) :: D
      real(dp), dimension(ao%max_sh_size**4 * 12), intent(inout), target :: eri
      real(dp), intent(in) :: degeneracy

      integer, intent(in) :: s1, s2, s3, s4

      real(dp), dimension(:, :, :, :, :, :), pointer :: eri_p
      integer, dimension(4) :: atoms
      integer :: q, k, qk, eri_dim

      type(G_adder) :: small_adder

      small_adder = G_adder()

      atoms = [ao%shell_to_center(s1), ao%shell_to_center(s2), ao%shell_to_center(s3), ao%shell_to_center(s4)]

      eri_dim = ao%shells(s1)%length &
                * ao%shells(s2)%length * ao%shells(s3)%length * ao%shells(s4)%length * 3 * 4

      eri_p(1:ao%shells(s1)%length, &
            1:ao%shells(s2)%length, &
            1:ao%shells(s3)%length, &
            1:ao%shells(s4)%length, &
            1:3, &
            1:4) => eri(1:eri_dim)

      do k = 1, 4
         do q = 1, 3

            qk = 3 * (atoms(k) - 1) + q

            call small_adder%add(ao, &
                                 D, &
                                 G(:, :, qk), &
                                 eri_p(:, :, :, :, q, k), &
                                 s1, &
                                 s2, &
                                 s3, &
                                 s4, &
                                 degeneracy)

         end do
      end do

   end subroutine add_G_1der_adder


end module G_1der_adder_class

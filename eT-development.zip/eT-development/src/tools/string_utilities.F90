

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module string_utilities

   !!
   !! String utilities module
   !!
   !! Routines that manipulate and analyze strings.
   !!

   use kinds

   implicit none

   interface read_comma_separated_list
      procedure :: read_comma_separated_integers, read_comma_separated_reals, read_comma_separated_strings
   end interface read_comma_separated_list

contains


   function last_index_of_substring(string, substring, reverse) result(cursor)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, 2020-2023
      !!
      !! Returns position of the last character of the first occurrence
      !! of the substring in the string.
      !!
      !! reverse: Search from the end of string instead of the beginning
      !!
      implicit none

      character(len=*), intent(in) :: string
      character(len=*), intent(in) :: substring
      logical, intent(in), optional :: reverse

      integer :: cursor, substring_length

      substring_length = len_trim(substring)

      cursor = index(string, substring, back=reverse)
      cursor = cursor + substring_length - 1

      if (cursor == substring_length - 1) error stop "Error in last_index_of_substring"

   end function last_index_of_substring


   function first_index_of_substring(string, substring, reverse) result(cursor)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, 2020-2023
      !!
      implicit none

      character(len=*), intent(in) :: string
      character(len=*), intent(in) :: substring
      logical, intent(in), optional :: reverse

      integer :: cursor

      cursor = index(string, substring, back=reverse)
      if (cursor == 0) error stop "Error in first_index_of_substring"

   end function first_index_of_substring


   pure function n_instances_of_character(string, char) result(n)
      !!
      !! Number of instances of character
      !! Written by Sarai D. Folkestad and Alexander C. Paul, 2021-2023
      !!
      implicit none

      character(len=*), intent(in) :: string

      character(len=1), intent(in) :: char

      integer :: n, cursor, first_instance

      first_instance = index(string, char)
      n = 0
      if (first_instance == 0) return

      do cursor = first_instance, len(string)

         if (string(cursor:cursor) == char) n = n + 1

      end do

   end function n_instances_of_character


   subroutine convert_to_lowercase(string)
      !!
      !! Written by Eirik F. Kjoenstad, Mar 2019
      !!
      !! Adapted from routines posted on the Stack-exchange.
      !!
      !! Assumes ASCII table for representing characters as integers,
      !! where the lowercase letter is +32 relative to the uppercase letters.
      !!
      !! Note: uppercase (65-90) and lowercase (97-122).
      !!
      implicit none

      character(len=*), intent(inout) :: string

      integer :: character_, current_character

      do character_ = 1, len(string)

         ! Represent character_ as ASCII integer

         current_character = iachar(string(character_:character_))

         ! Convert if character_ is in the range of uppercase characters

         if (current_character >= 65 .and. current_character <= 90) then  ! Between A and Z

            current_character = current_character + 32
            string(character_:character_) = char(current_character)

         end if

      end do

   end subroutine convert_to_lowercase


   function convert_character_to_uppercase(char_) result(char_out)
      !!
      !! Written by Eirik F. Kjoenstad, Mar 2019
      !!
      !! Adapted from routines posted on the Stack-exchange.
      !!
      !! Assumes ASCII table for representing characters as integers,
      !! where the lowercase letter is +32 relative to the uppercase letters.
      !!
      !! Note: uppercase (65-90) and lowercase (97-122).
      !!
      implicit none

      character, intent(in) :: char_
      character :: char_out

      integer :: char_int

      ! Represent character as integer

      char_int = iachar(char_)

      ! Convert if character is in the range of uppercase characters

      if (char_int >= 97 .and. char_int <= 122) then  ! Between a and z

         char_int = char_int - 32

      end if

      ! Replace the character by the (possibly) uppercased letter

      char_out = char(char_int)

   end function convert_character_to_uppercase


   function convert_to_uppercase(string) result(string_out)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Adapted from routines posted on the Stack-exchange.
      !!
      !! Assumes ASCII table for representing characters as integers,
      !! where the lowercase letter is +32 relative to the uppercase letters.
      !!
      !! Note: uppercase (65-90) and lowercase (97-122).
      !!
      implicit none

      character(len=*), intent(in) :: string
      character(len=500) :: string_out

      integer :: cursor, character_integer

      if (len(string) > 500) error stop 'Error: string is too long to convert.'

      string_out = repeat(' ', 500)

      do cursor = 1, len(string)

         ! Represent character as ASCII integer

         character_integer = iachar(string(cursor:cursor))

         ! Convert if character is in the range of uppercase characters

         if (character_integer >= 97 .and. character_integer <= 122) then  ! Between a and z

            character_integer = character_integer - 32

         end if

         string_out(cursor:cursor) = achar(character_integer)

      end do

   end function convert_to_uppercase


   subroutine index_of_unique_strings(indices, n_strings, strings)
      !!
      !! Written by Tor S. Haugland, Oct 2019
      !!
      !! Find index of unique strings in an array of strings.
      !!
      !! indices:    on input an array of size n_strings.
      !!                on output the index of unique elements in strings. 0 elsewhere.
      !!                n_unique = count( indices /= 0 )
      !! n_strings:  check first `n_strings` values of strings
      !! strings:    array of strings to check for unique.
      !!
      !! Example: strings = ['a', 'b', 'a', 'c'], n_strings = 4
      !!          will return indices = [1, 2, 4, 0]
      !!
      implicit none

      integer, intent(in) :: n_strings
      integer, dimension(n_strings), intent(out) :: indices
      character(len=*), dimension(n_strings), intent(in) :: strings

      character(len=len(strings(1))), dimension(n_strings) :: unique_strings
      integer :: i, n_unique

      n_unique = 0

      indices(:) = 0

      do i = 1, n_strings

         ! Try to add string to unique_strings. if failed: check next

         if (.not. any(unique_strings(1:n_unique) == strings(i))) then

            n_unique = n_unique + 1

            unique_strings(n_unique) = strings(i)
            indices(n_unique) = i

         end if

      end do

   end subroutine index_of_unique_strings


   function is_substring_in_string(string, substring) result(substring_found)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, 2021-2023
      !!
      implicit none

      character(len=*), intent(in) :: string
      character(len=*), intent(in) :: substring

      logical :: substring_found

      substring_found = .false.

      if (index(string, substring) > 0) substring_found = .true.

   end function is_substring_in_string


   subroutine split_at_first_instance(string, array_of_strings, delimiter)
      !!
      !! Written by Sarai D. Folkestad 2024
      !!
      implicit none

      character(len=*), intent(in) :: string
      character(len=len(string)), dimension(2), intent(out) :: array_of_strings
      character, intent(in) :: delimiter

      integer :: position

      position = index(string, delimiter)

      array_of_strings(1) = string(:position - 1)
      array_of_strings(2) = string(position + 1:)

   end subroutine split_at_first_instance


   subroutine split_at_delimiter(string, n_delimiters, array_of_strings, delimiter)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, 2021-2023
      !!
      implicit none

      character(len=*), intent(in) :: string

      integer, intent(in) :: n_delimiters

      character(len=200), dimension(n_delimiters + 1), intent(out) :: array_of_strings

      character, intent(in) :: delimiter

      integer :: string_length, n_delimiters_found, relative_comma_index, first, last, i

      string_length = len_trim(string)

      first = 1
      n_delimiters_found = 0

      do i = 1, n_delimiters

         relative_comma_index = index(string(first:string_length), delimiter) - 1
         last = first + relative_comma_index - 1

         if (last == 0) then
            array_of_strings(i) = ""
         else
            array_of_strings(i) = string(first:last)
         end if

         first = first + relative_comma_index + 1
         n_delimiters_found = n_delimiters_found + 1

      end do

      if (n_delimiters_found /= n_delimiters) &
         error stop 'Mismatch in number of delimiters expected and found in "split_at_delimiter".'

      ! Add last part of the string
      if (first <= string_length) array_of_strings(n_delimiters + 1) = string(first:string_length)

   end subroutine split_at_delimiter


   subroutine remove_delimiter_from_string(string, delimiter)
      !!
      !! Written by Enrico Ronca, 2022
      !!
      implicit none

      character(len=*), intent(inout) :: string

      character, intent(in) :: delimiter

      integer :: i, n

      n = 1
      do i = 1, len(string)

         if (string(i:i) /= delimiter) then
            string(n:n) = string(i:i)
            n = n + 1
         end if

      end do
      string(n:) = ''

   end subroutine remove_delimiter_from_string


   pure function string_starts_with(string, substring) result(starts_with)
      !!
      !! string starts with
      !! Written by Alexander C. Paul, Mar 2023
      !!
      implicit none

      character(len=*), intent(in) :: string
      character(len=*), intent(in) :: substring

      logical :: starts_with

      starts_with = .false.
      if (index(string, substring) == 1) starts_with = .true.

   end function string_starts_with


   pure function string_ends_with(string, substring) result(ends_with)
      !!
      !! string ends with
      !! Written by Alexander C. Paul, Mar 2023
      !!
      implicit none

      character(len=*), intent(in) :: string
      character(len=*), intent(in) :: substring

      logical :: ends_with

      ends_with = .false.
      if (index(string, substring, back=.true.) == len(string)) ends_with = .true.

   end function string_ends_with


   pure function is_empty(string) result(empty)
      !!
      !! is empty
      !! Written by Alexander C. Paul, Mar 2023
      !!
      implicit none

      character(len=*), intent(in) :: string
      logical :: empty

      empty = (trim(string) == "")

   end function is_empty


   subroutine read_comma_separated_reals(string, array_, n)
      !!
      !! Written by Alexander C. Paul, Mar 2023
      !!
      implicit none

      character(len=*), intent(in) :: string
      integer, intent(in) :: n
      real(dp), dimension(n), intent(out) :: array_

      character(len=200), dimension(n) :: character_array
      integer :: i

      call split_at_delimiter(string, n - 1, character_array, ',')

      do i = 1, n
         read(character_array(i), *) array_(i)
      end do

   end subroutine read_comma_separated_reals


   subroutine read_comma_separated_integers(string, array_, n)
      !!
      !! Written by Alexander C. Paul, Mar 2023
      !!
      implicit none

      character(len=*), intent(in) :: string
      integer, intent(in) :: n
      integer, dimension(n), intent(out) :: array_

      character(len=200), dimension(n) :: character_array
      integer :: i

      call split_at_delimiter(string, n - 1, character_array, ',')

      do i = 1, n
         read(character_array(i), *) array_(i)
      end do

   end subroutine read_comma_separated_integers


   subroutine read_comma_separated_strings(string, array_)
      !!
      !! Written by Alexander C. Paul, Mar 2023
      !!
      implicit none

      character(len=*), intent(in) :: string
      integer :: n
      character(len=40), dimension(:), allocatable :: array_
      character(len=200), dimension(:), allocatable :: character_array

      integer :: i

      n = n_instances_of_character(string, ',') + 1
      allocate(character_array(n))
      allocate(array_(n))

      call split_at_delimiter(string, n - 1, character_array, ',')

      do i = 1, n
         array_(i) = trim(adjustl(character_array(i)))
      end do

      deallocate(character_array)

   end subroutine read_comma_separated_strings


   function string_in_comma_separated_list(comma_separated_list, string) result(present)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, 2019-2023
      !!
      !! Is "string" an element of the comma_separated_list of strings?
      !!
      implicit none

      character(len=*), intent(in) :: comma_separated_list, string
      logical :: present

      character(len=200), dimension(:), allocatable :: string_array

      integer :: i, n_elements, n_commas

      present = .false.

      n_commas = n_instances_of_character(comma_separated_list, ',')
      n_elements = n_commas + 1
      allocate(string_array(n_elements))

      call split_at_delimiter(comma_separated_list, n_commas, string_array, ',')

      do i = 1, n_elements

         if (trim(adjustl(string_array(i))) == string) then
            present = .true.
            exit
         end if

      end do

      deallocate(string_array)

   end function string_in_comma_separated_list


   function remove_substring_after_symbol(string, symbol) result(stripped_string)
      !!
      !! Written by Sarai D. Folkestad
      !!
      !! Removes from string everything after the symbol
      !! (including the symbol itself)
      !!
      implicit none

      character(len=*), intent(in) :: string
      character(len=1), intent(in) :: symbol
      character(len=:), allocatable :: stripped_string

      character(len=len(string)), dimension(2) :: split_line

      stripped_string = string

      if (is_substring_in_string(string, symbol)) then
         call split_at_first_instance(string, split_line, symbol)
         stripped_string = split_line(1)
      end if

   end function remove_substring_after_symbol


   function flip_left_or_right(left_or_right) result(flipped_left_or_right)

      implicit none

      character(len=*), intent(in) :: left_or_right
      character(len=10) :: flipped_left_or_right


      flipped_left_or_right = ''
      if (trim(left_or_right) == 'right') then
         flipped_left_or_right = 'left'
      else if (trim(left_or_right) == 'left') then
         flipped_left_or_right = 'right'
      end if

   end function


end module string_utilities

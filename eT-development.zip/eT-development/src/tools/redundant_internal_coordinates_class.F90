

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module redundant_internal_coordinates_class

   !!
   !! Redundant internal coordinates class
   !! Written by Eirik F. Kjoenstad, and Jan Haakon M. Trabski, 2021-2023
   !!
   !! Git repository GeomeTRIC: https://github.com/pyg-team/pytorch_geometric
   !!
   !! Wang, L.-P.; Song, C.C. (2016)
   !! Geometry optimization made simple with translation and rotation coordinates,
   !! J. Chem. Phys. 144, 214108.
   !!

   use parameters
   use memory_manager_class, only: mem
   use global_out, only: output
   use math_utilities, only: cross_product_R3, dot_R3, norm_R3
   use array_initialization, only: zero_array

   implicit none

   ! Covalennt radii for elements 1-36
   ! From Dalton Trans., 2008, 2832-2838, given in Angstrom

   real(dp), dimension(36) :: covalent_radius = &
      [0.31d0, 0.28d0, 1.28d0, 0.96d0, 0.84d0, 0.73d0, 0.71d0, 0.66d0, 0.57d0, 0.58d0, 1.66d0, 1.41d0, &
      1.21d0, 1.11d0, 1.07d0, 1.05d0, 1.02d0, 1.06d0, 2.03d0, 1.76d0, 1.70d0, 1.60d0, 1.53d0, 1.39d0, &
      1.39d0, 1.32d0, 1.26d0, 1.24d0, 1.32d0, 1.22d0, 1.22d0, 1.20d0, 1.19d0, 1.20d0, 1.20d0, 1.16d0] &
      * angstrom_to_bohr

   type :: bond

      integer, dimension(2) :: atoms
      real(dp) :: length

   end type bond

   type :: angle

      real(dp) :: theta
      integer, dimension(3) :: atoms

   end type angle

   type :: dihedral

      real(dp) :: theta
      integer, dimension(4) :: atoms

   end type dihedral

   type :: rotation

      real(dp), dimension(3) :: theta

   end type rotation

   type :: translation

      real(dp), dimension(3) :: position

   end type translation

   type :: fragment

      integer :: fragment_id
      real(dp), dimension(3) :: centered_coordinates
      real(dp), dimension(3) :: reference_molecule

   end type fragment

   type :: redundant_internal_coords

      integer, private :: n_atoms, n_bonds, n_angles, n_dihedrals, n_internal
      integer, private :: n_cartesian, n_fragments, n_translations, n_rotations

      type(bond), dimension(:), allocatable, private :: bonds
      integer, dimension(:, :), allocatable, private :: bond_matrix

      type(angle), dimension(:), allocatable, private :: angles
      type(dihedral), dimension(:), allocatable, private :: dihedrals
      type(fragment), dimension(:), allocatable, private :: fragments
      type(rotation), dimension(:), allocatable, private :: rotations
      type(translation), dimension(:), allocatable, private :: translations

      integer, dimension(:), allocatable, private :: Z  ! atomic charges, [n_atoms]
      real(dp), dimension(:, :), allocatable, private :: R  ! atomic positions, [3, n_atoms]

      ! B_ij = dq_i/dx_j (q = internals, x = cartesian)
      real(dp), dimension(:, :), allocatable, private :: B

      ! Pseudoinverse of B
      real(dp), dimension(:, :), allocatable, private :: B_inverse

      ! Projection matrix: P = G G_inv, where G = B B^T
      ! A general change in internals (dq) does not necessarily correspond to some dx
      ! (but dq' = P*dq always corresponds to a dx)
      real(dp), dimension(:, :), allocatable, private :: P

      real(dp), private :: pseudoinverse_threshold
      real(dp), private :: dihedral_skip_threshold

      real(dp), private :: internal_to_cartesian_threshold
      integer, private :: internal_to_cartesian_max_iterations

      real(dp), dimension(:), allocatable, private :: q, prev_q

      ! items used for quaternions.
      integer, dimension(:), allocatable, private :: atoms_in_fragments

      real(dp), dimension(:), allocatable, private :: gyro_ratio
      real(dp), dimension(:, :), allocatable, private :: eigenvalues
      real(dp), dimension(:, :, :), allocatable, private :: correlation_matrix
      real(dp), dimension(:, :, :), allocatable, private :: F_matrix
      real(dp), dimension(:, :, :), allocatable, private :: F_matrix_eigenvectors

   contains

      procedure, public :: initialize
      procedure, private :: set_geometry

      procedure, public :: get_n_internal
      procedure, public :: get_approximate_diagonal_Hessian

      procedure, public :: Wilson_project_vector
      procedure, public :: Wilson_project_matrix

      procedure, public :: calculate_internal_gradient

      procedure, public :: compute_next_geometry

      procedure, public :: print_geometry

      procedure, private :: identify_internal_coordinates

      procedure, private :: identify_bonds
      procedure, private :: identify_bond_angles
      procedure, private :: identify_dihedral_angles
      procedure, private :: identify_fragments
      procedure, private :: find_closest_atom

      procedure, private :: identify_rotation

      procedure, private :: calculate_internal_coordinates

      procedure, private :: calculate_bond_lengths
      procedure, private :: calculate_bond_angles
      procedure, private :: calculate_dihedral_angles
      procedure, private :: calculate_rotation
      procedure, private :: calculate_translation

      procedure, public :: get_internals
      procedure, public :: get_internals_difference

      procedure, private :: add_dihedral
      procedure, private :: pseudoinvert_Wilson_B_and_construct_P

      procedure, private :: construct_Wilson_B

      procedure, private :: construct_Wilson_B_bonds
      procedure, private :: construct_Wilson_B_bond_angles
      procedure, private :: construct_Wilson_B_dihedral_angles
      procedure, private :: construct_Wilson_B_rotation
      procedure, private :: construct_Wilson_B_translation

      procedure, private :: perform_cartesian_step
      procedure, private :: remove_multiples_of_360

      procedure, private :: center_molecule
      procedure, private :: update_reference
      procedure, private :: calculate_gyro_ratio
      procedure, private :: construct_derivative_F_matrix
      procedure, private :: construct_pseudo_inverse_F_matrix
      procedure, private :: construct_quaternion_derivative
      procedure, private :: construct_wilson_B_rotation_singular
      procedure, private :: construct_wilson_B_rotation_nonsingular
      procedure, private :: fragment_with_single_atom

      procedure, private, nopass :: construct_quaternion_fitting_matrix

      final :: destructor

   end type redundant_internal_coords

   interface redundant_internal_coords

      procedure :: new_redundant_internal_coords

   end interface redundant_internal_coords

contains


   function new_redundant_internal_coords(n_cartesian) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      type(redundant_internal_coords) :: this

      integer :: n_cartesian

      this%n_atoms = n_cartesian / 3
      this%n_cartesian = n_cartesian

      this%pseudoinverse_threshold = 1.0d-4

      this%dihedral_skip_threshold = 1.0d-10

      this%internal_to_cartesian_threshold = 1.0d-6
      this%internal_to_cartesian_max_iterations = 25

   end function new_redundant_internal_coords


   subroutine initialize(this, R, Z)
      !!
      !! Written by Eirik F. Kjoenstad and Jan Haakon M. Trabski, 2021-2022
      !!
      !! Makes allocations and sets the geometry and atomic charges.
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      integer, dimension(this%n_atoms) :: Z
      real(dp), dimension(3, this%n_atoms) :: R
      integer :: fragment_id

      call mem%alloc(this%R, 3, this%n_atoms)
      call mem%alloc(this%Z, this%n_atoms)

      call dcopy(3 * this%n_atoms, R, 1, this%R, 1)

      this%Z = Z

      call mem%alloc(this%bond_matrix, this%n_atoms, this%n_atoms, set_zero=.true.)

      call this%identify_internal_coordinates()

      call mem%alloc(this%Gyro_ratio, this%n_fragments)
      call mem%alloc(this%F_matrix, 4, 4, this%n_fragments)
      call mem%alloc(this%F_matrix_eigenvectors, 4, 4, this%n_fragments)
      call mem%alloc(this%correlation_matrix, 3, 3, this%n_fragments)
      call mem%alloc(this%eigenvalues, 4, this%n_fragments)

      do fragment_id = 1, this%n_fragments

         call this%center_molecule(fragment_id)
         call this%calculate_gyro_ratio(fragment_id)
         call this%update_reference(fragment_id)

      end do

      call mem%alloc(this%B, this%n_internal, this%n_cartesian, set_zero=.true.)
      call mem%alloc(this%B_inverse, this%n_cartesian, this%n_internal)
      call mem%alloc(this%P, this%n_internal, this%n_internal)

      call mem%alloc(this%q, this%n_internal)
      call mem%alloc(this%prev_q, this%n_internal, set_zero=.true.)

      call this%set_geometry(R)

      call this%print_geometry()

      call this%get_internals(this%q)

   end subroutine initialize


   subroutine set_geometry(this, R)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! Sets the coordinates R and updates all the quantities that depend on R
      !! (internal coordinates, Wilson, Wilson-inverse, projection, etc.)
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      real(dp), dimension(this%n_cartesian), intent(in) :: R

      call dcopy(this%n_cartesian, R, 1, this%R, 1)

      call this%calculate_internal_coordinates()

      call this%construct_Wilson_B()
      call this%pseudoinvert_Wilson_B_and_construct_P()

   end subroutine set_geometry


   subroutine get_internals_difference(this, dq)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(redundant_internal_coords) :: this

      real(dp), dimension(this%n_internal) :: dq

      dq = this%q - this%prev_q

      call this%remove_multiples_of_360(dq)
      call this%Wilson_project_vector(dq)

   end subroutine get_internals_difference


   subroutine find_closest_atom(this, isolated_atom, closetst_atom)
      !!
      !! Written by Jan Haakon M. Trabski, 2023
      !!
      !! Finds the closest atom to the isolated atom and adjust
      !! the amount of internal coordinates accordingly
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      integer :: isolated_atom, closetst_atom, A, B, q
      real(dp) :: smallest_bond_lenght

      real(dp), dimension(3) :: R
      real(dp), dimension(this%n_atoms) :: bond_lenghts

      bond_lenghts = zero

      do A = 1, this%n_atoms

         if (isolated_atom == A) cycle

         do q = 1, 3

            R(q) = this%R(q, isolated_atom) - this%R(q, A)

         end do

         bond_lenghts(A) = (norm_R3(R))

      end do

      smallest_bond_lenght = bond_lenghts(1)
      closetst_atom = 1

      ! used if the single atom is in the first index

      if (closetst_atom == isolated_atom) then

         smallest_bond_lenght = bond_lenghts(2)
         closetst_atom = 2

      end if

      do B = 1, this%n_atoms

         if (B == isolated_atom) cycle

         if (smallest_bond_lenght > bond_lenghts(B)) then

            smallest_bond_lenght = bond_lenghts(B)
            closetst_atom = B

         end if
      end do

   end subroutine find_closest_atom


   subroutine identify_internal_coordinates(this)
      !!
      !! Written by Eirik F. Kjoenstad and Jan Haakon M. Trabski, 2021-2022
      !!
      !! Identifies the atoms involved in bonds (A-B),
      !! as well as the bond angles (A-B-C), dihedral angles (A-B-C-D)
      !! rotation and translation (per fragment).
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      ! Count number of bonds and then allocate and set them
      ! (same with angles, dihedrals rotations and translations)

      call this%identify_bonds(set_bonds=.false.)
      allocate(this%bonds(this%n_bonds))
      call this%identify_bonds(set_bonds=.true.)

      call this%identify_bond_angles(set_angles=.false.)
      allocate(this%angles(this%n_angles))
      call this%identify_bond_angles(set_angles=.true.)

      call this%identify_dihedral_angles(set_angles=.false.)
      allocate(this%dihedrals(this%n_dihedrals))
      call this%identify_dihedral_angles(set_angles=.true.)

      call this%identify_fragments(set_fragments=.false.)
      allocate(this%fragments(this%n_atoms))
      allocate(this%atoms_in_fragments(this%n_fragments))
      call this%identify_fragments(set_fragments=.true.)

      allocate(this%rotations(this%n_fragments))
      allocate(this%translations(this%n_fragments))

      this%n_translations = 3 * this%n_fragments
      this%n_rotations = 3 * this%n_fragments

      this%n_internal = &
                        this%n_bonds + this%n_angles + this%n_dihedrals + this%n_translations &
                        + this%n_rotations

      if (this%n_atoms == 1) then
         call output%error_msg('You cannot preform a geometry optimization with only one atom.')

      end if

   end subroutine identify_internal_coordinates


   subroutine identify_bonds(this, set_bonds)
      !!
      !! Written by Eirik F. Kjoenstad and Jan Haakon M. Trabski, 2021-2023
      !!
      !! Counts number of bonds, fictive bonds, and sets bond matrix array.
      !!
      !! If set_bonds = .true., this%bonds is assumed to be allocated
      !! and is set by the routine
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      logical, intent(in) :: set_bonds

      integer :: bond_index, A, A_bond, B, Z_A, Z_B, closest_atoms, C

      real(dp), dimension(3) :: R

      integer :: q, no_bonds

      logical :: bonded

      bond_index = 0

      this%bond_matrix = zero

      do A = 1, this%n_atoms

         no_bonds = 1

         closest_atoms = 0

         A_bond = 0

         do B = 1, this%n_atoms

            if (A == B) cycle

            Z_A = this%Z(A)
            Z_B = this%Z(B)

            do q = 1, 3

               R(q) = this%R(q, A) - this%R(q, B)

            end do

            bonded = norm_R3(R) < 1.3d0 * (covalent_radius(Z_A) + covalent_radius(Z_B))

            if (bonded) then

               A_bond = A_bond + 1
               this%bond_matrix(A, A_bond) = B

               if (A < B) cycle

               bond_index = bond_index + 1

               if (set_bonds) this%bonds(bond_index)%atoms = [A, B]

            end if
         end do

         ! Will find atoms who are not bonded with anything

         if (this%bond_matrix(A, 1) == 0) then

            call this%find_closest_atom(A, closest_atoms)

            A_bond = A_bond + 1
            this%bond_matrix(A, A_bond) = closest_atoms

            do C = 1, this%n_atoms
               if (this%bond_matrix(closest_atoms, C) == 0) then

                  this%bond_matrix(closest_atoms, C) = A

                  exit
               end if
            end do

            bond_index = bond_index + 1

            if (A > closest_atoms) then

               if (set_bonds) this%bonds(bond_index)%atoms = [A, closest_atoms]

            else

               if (set_bonds) this%bonds(bond_index)%atoms = [closest_atoms, A]

            end if

         end if
      end do

      this%n_bonds = bond_index

   end subroutine identify_bonds


   subroutine identify_bond_angles(this, set_angles)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! Counts number of bond angles.
      !!
      !! If set_angles = .true., this%angles is assumed to be allocated
      !! and is set by the routine
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      logical, intent(in) :: set_angles

      integer :: angle_index, B, A, A_red, C_red, C

      angle_index = 0

      do B = 1, this%n_atoms

         A_red = 1

         do while (this%bond_matrix(B, A_red) > 0)

            A = this%bond_matrix(B, A_red)

            C_red = 1

            do while (this%bond_matrix(B, C_red) > 0)

               C = this%bond_matrix(B, C_red)

               if (A < C) then  ! Avoid double counting

                  angle_index = angle_index + 1

                  if (set_angles) this%angles(angle_index)%atoms = [A, B, C]

               end if

               C_red = C_red + 1

            end do

            A_red = A_red + 1

         end do

      end do

      this%n_angles = angle_index

   end subroutine identify_bond_angles


   subroutine identify_dihedral_angles(this, set_angles)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! Counts number of dihedral angles.
      !!
      !! If set_angles = .true., this%dihedrals is assumed to be allocated
      !! and is set by the routine
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      logical, intent(in) :: set_angles

      integer :: dihedral_index, angle1, angle2, A, B, C, D

      dihedral_index = 0

      do angle1 = 1, this%n_angles
         do angle2 = angle1 + 1, this%n_angles

            ! For the angles to define a dihedral, two of the atoms must coincide,
            ! and the end-points must be different

            if (this%angles(angle1)%atoms(2) == this%angles(angle2)%atoms(3) .and. &
                this%angles(angle1)%atoms(3) == this%angles(angle2)%atoms(2) .and. &
                this%angles(angle1)%atoms(1) /= this%angles(angle2)%atoms(1)) then

               A = this%angles(angle1)%atoms(1)
               B = this%angles(angle1)%atoms(2)
               C = this%angles(angle1)%atoms(3)
               D = this%angles(angle2)%atoms(1)

               call this%add_dihedral(A, B, C, D, dihedral_index, set_angles)

            else if (this%angles(angle1)%atoms(2) == this%angles(angle2)%atoms(1) .and. &
                     this%angles(angle1)%atoms(3) == this%angles(angle2)%atoms(2) .and. &
                     this%angles(angle1)%atoms(1) /= this%angles(angle2)%atoms(3)) then

               A = this%angles(angle1)%atoms(1)
               B = this%angles(angle1)%atoms(2)
               C = this%angles(angle1)%atoms(3)
               D = this%angles(angle2)%atoms(3)

               call this%add_dihedral(A, B, C, D, dihedral_index, set_angles)

            else if (this%angles(angle1)%atoms(1) == this%angles(angle2)%atoms(2) .and. &
                     this%angles(angle1)%atoms(2) == this%angles(angle2)%atoms(1) .and. &
                     this%angles(angle1)%atoms(3) /= this%angles(angle2)%atoms(3)) then

               A = this%angles(angle2)%atoms(3)
               B = this%angles(angle2)%atoms(2)
               C = this%angles(angle2)%atoms(1)
               D = this%angles(angle1)%atoms(3)

               call this%add_dihedral(A, B, C, D, dihedral_index, set_angles)

            else if (this%angles(angle1)%atoms(1) == this%angles(angle2)%atoms(2) .and. &
                     this%angles(angle1)%atoms(2) == this%angles(angle2)%atoms(3) .and. &
                     this%angles(angle1)%atoms(3) /= this%angles(angle2)%atoms(1)) then

               A = this%angles(angle2)%atoms(1)
               B = this%angles(angle2)%atoms(2)
               C = this%angles(angle2)%atoms(3)
               D = this%angles(angle1)%atoms(3)

               call this%add_dihedral(A, B, C, D, dihedral_index, set_angles)

            end if

         end do
      end do

      this%n_dihedrals = dihedral_index

   end subroutine identify_dihedral_angles


   subroutine identify_fragments(this, set_fragments)
      !!
      !! Written by Jan Haakon M. Trabski, 2022
      !!
      !! Identify fragments in the total system, by naive Breadth First Seach algorithm
      !!
      use array_initialization, only: set_logicals

      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      integer :: atom, atom_bonded_to_A, bond_index, n_fragments, n_atoms_in_fragment

      logical, dimension(this%n_atoms) :: atom_in_current_fragment, atom_assigned_to_fragment, &
                                          last_atom_in_current_fragment

      logical :: done, set_fragments, identified_fragment

      last_atom_in_current_fragment = .false.
      atom_in_current_fragment = .false.
      atom_in_current_fragment(1) = .true.

      ! Tracking if atom is assigned to any fragment

      atom_assigned_to_fragment = .false.
      atom_assigned_to_fragment(1) = .true.

      n_fragments = 0
      n_atoms_in_fragment = 0

      done = .false.

      do while (.not. done)

         identified_fragment = .false.

         do while (.not. identified_fragment)

            if (all(last_atom_in_current_fragment .eqv. atom_in_current_fragment)) then

               identified_fragment = .true.

            else

               last_atom_in_current_fragment = atom_in_current_fragment

               do atom = 1, this%n_atoms

                  if (.not. atom_in_current_fragment(atom)) cycle

                  do bond_index = 1, this%n_atoms

                     if (this%bond_matrix(atom, bond_index) == 0) exit

                     atom_bonded_to_A = this%bond_matrix(atom, bond_index)

                     atom_in_current_fragment(atom_bonded_to_A) = .true.
                     atom_assigned_to_fragment(atom_bonded_to_A) = .true.


                  end do
               end do
            end if
         end do

         n_fragments = n_fragments + 1

         if (set_fragments) then

            do atom = 1, this%n_atoms
               if (atom_in_current_fragment(atom)) then

                  n_atoms_in_fragment = n_atoms_in_fragment + 1
                  this%fragments(atom)%fragment_id = n_fragments

               end if
            end do

            this%atoms_in_fragments(n_fragments) = n_atoms_in_fragment

         end if

         n_atoms_in_fragment = 0
         call set_logicals(atom_in_current_fragment, this%n_atoms, .false.)

         ! Find next unassigned atom

         do atom = 1, this%n_atoms
            if (.not. atom_assigned_to_fragment(atom)) then

               atom_in_current_fragment(atom) = .true.
               atom_assigned_to_fragment(atom) = .true.
               exit

            end if
         end do

         if (all(atom_assigned_to_fragment)) then

            this%n_fragments = n_fragments
            done = .true.

         end if
      end do

   end subroutine identify_fragments


   subroutine identify_rotation(this, fragment_id)
      !!
      !! Find the rotational internal coordinates for each fragment
      !! Written by Jan Haakon M. Trabski, 2022
      !!
      use array_utilities, only: diagonalize_symmetric

      implicit none

      class(redundant_internal_coords), intent(inout) :: this
      integer, intent(in) :: fragment_id

      integer :: i, j, k

      ! Construct correlation matrix, first index is updated atoms, second is reference atoms
      ! R_ij = Sum^N_n = 1 x_nj*y_ni
      ! where y is reference geometry, x is current geometry, N atoms, i,j are cartesian coordinates

      call this%center_molecule(fragment_id)

      call zero_array(this%correlation_matrix(:, :, fragment_id), 9)

      do i = 1, this%n_atoms
         if (this%fragments(i)%fragment_id == fragment_id) then
            do j = 1, 3
               do k = 1, 3

                  this%correlation_matrix(j, k, fragment_id) = this%fragments(i)%centered_coordinates(j) &
                                                               * this%fragments(i)%reference_molecule(k) &
                                                               + this%correlation_matrix(j, k, fragment_id)

               end do
            end do
         end if
      end do

      ! Construct F-matrix, which is used to calculate proper and improper rotation from the eigenvectors of the F-matrix.
      ! F-matrix is a four by four symmetric matrix, such that each entries is defined by a sum of correlation elements

      call this%construct_quaternion_fitting_matrix(this%correlation_matrix(:, :, fragment_id), &
                                                    this%F_matrix(:, :, fragment_id))

      ! The dyyev changes the matrix, thus this stores the old matrix.

      call dcopy(16, this%F_matrix(:, :, fragment_id), 1, this%F_matrix_eigenvectors(:, :, fragment_id), 1)

      call diagonalize_symmetric(this%F_matrix_eigenvectors(:, :, fragment_id), &
                                 4, &
                                 this%eigenvalues(:, fragment_id))

      ! Checks if molecule is linear

      if (this%eigenvalues(1, fragment_id) / this%eigenvalues(2, fragment_id) < 1.01) then

         ! Removes rotational degeneracy by adding a small pertubation when near equlibrium

         this%F_matrix(1, 1, fragment_id) = this%F_matrix(1, 1, fragment_id) + one &
                                            - this%eigenvalues(1, fragment_id)

         call dcopy(16, this%F_matrix(:, :, fragment_id), 1, this%F_matrix_eigenvectors(:, :, fragment_id), 1)

         call diagonalize_symmetric(this%F_matrix_eigenvectors(:, :, fragment_id), 4)

      end if

   end subroutine identify_rotation


   subroutine print_geometry(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(redundant_internal_coords) :: this

      integer :: bond_index, angle_index, dihedral_index

      call output%printf('m', 'Molecular geometry (in redundant internal coordinates):', fs='(/t6,a)')
      call output%print_separator('n', 55, '-', fs='(t6,a)')

      do bond_index = 1, this%n_bonds

         call output%printf('m', &
                            'R((i3),(i3))          (f19.12)', &
                            ints=[this%bonds(bond_index)%atoms(1), this%bonds(bond_index)%atoms(2)], &
                            reals=[this%bonds(bond_index)%length], &
                            fs='(t6,a)')

      end do

      do angle_index = 1, this%n_angles

         call output%printf('m', &
                            'A((i3),(i3),(i3))      (f19.12)', &
                            ints=[this%angles(angle_index)%atoms(:)], &
                            reals=[this%angles(angle_index)%theta], &
                            fs='(t6,a)')

      end do

      do dihedral_index = 1, this%n_dihedrals

         call output%printf('m', &
                            'D((i3),(i3),(i3),(i3))  (f19.12)', &
                            ints=[this%dihedrals(dihedral_index)%atoms(:)], &
                            reals=[this%dihedrals(dihedral_index)%theta], &
                            fs='(t6,a)')

      end do

      call output%print_separator('n', 55, '-', fs='(t6,a)')

   end subroutine print_geometry


   subroutine add_dihedral(this, A, B, C, D, dihedral_index, set_angles)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! Adds a dihedral for the quartet A-B-C-D provided it satisfies the 180 degree criterion.
      !!
      !! The routine increments dihedral by 1 if the quartet passes the test and is actually added as a dihedral.
      !!
      implicit none

      class(redundant_internal_coords) :: this

      integer, intent(in) :: A, B, C, D

      logical, intent(in) :: set_angles

      integer, intent(inout) :: dihedral_index

      real(dp), dimension(3) :: AB, BC, CD, ABxBC, BCxCD

      real(dp) :: norm_AB, norm_BC, norm_CD, theta_ABC, theta_BCD

      integer :: q

      do q = 1, 3

         AB(q) = this%R(q, A) - this%R(q, B)
         BC(q) = this%R(q, B) - this%R(q, C)
         CD(q) = this%R(q, C) - this%R(q, D)

      end do

      norm_AB = norm_R3(AB)
      norm_BC = norm_R3(BC)
      norm_CD = norm_R3(CD)

      ABxBC = cross_product_R3(AB, BC)
      BCxCD = cross_product_R3(BC, CD)

      theta_ABC = acos(dot_R3(AB, BC) / (norm_AB * norm_BC))
      theta_BCD = acos(dot_R3(BC, CD) / (norm_BC * norm_CD))

      if ((abs(theta_ABC - pi) < this%dihedral_skip_threshold) .or. &
          (abs(theta_BCD - pi) < this%dihedral_skip_threshold)) then

         call output%printf('v', 'Skipping dihedral between (i0), (i0), (i0), and (i0)', ints=[A, B, C, D])

         call output%printf('v', 'theta_ABC: (e9.2), theta_BCD: (e9.2)', reals=[theta_ABC, theta_BCD])

      else

         dihedral_index = dihedral_index + 1

         if (set_angles) this%dihedrals(dihedral_index)%atoms = [A, B, C, D]

      end if

   end subroutine add_dihedral


   pure function get_n_internal(this) result(n_internal)
      !!
      !! Get n internal
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(redundant_internal_coords), intent(in) :: this

      integer :: n_internal

      n_internal = this%n_internal

   end function get_n_internal


   subroutine get_internals(this, q)
      !!
      !! Written by Eirik F. Kjoenstad and Jan Haakon M. Trabski, 2021-2022
      !!
      !! Returns q = [q_bonds, q_angles, q_dihedrals, q_rotations, q_translations]
      !!
      implicit none

      class(redundant_internal_coords), intent(in) :: this

      real(dp), dimension(this%n_internal), intent(out) :: q

      integer :: bond_index, angle_index, dihedral_index, fragments, cartesian

      do bond_index = 1, this%n_bonds

         q(bond_index) = this%bonds(bond_index)%length

      end do

      do angle_index = 1, this%n_angles

         q(this%n_bonds + angle_index) = this%angles(angle_index)%theta

      end do

      do dihedral_index = 1, this%n_dihedrals

         q(this%n_bonds + this%n_angles + dihedral_index) = this%dihedrals(dihedral_index)%theta

      end do

      do fragments = 1, this%n_fragments

         do cartesian = 1, 3

            q(this%n_internal - 3 * fragments + cartesian) = this%rotations(fragments)%theta(cartesian)

         end do
      end do

      do fragments = 1, this%n_fragments

         do cartesian = 1, 3

            q(this%n_internal - 3 * fragments - this%n_translations + cartesian) = &
               this%translations(fragments)%position(cartesian)

         end do
      end do

   end subroutine get_internals


   subroutine calculate_internal_coordinates(this)
      !!
      !! Written by Eirik F. Kjoenstad and Jan Haakon M. Trabski, 2021-2022
      !!
      !! q = q(R), internal coordinates corresponding to the cartesian coordinate R
      !!
      !! The different logicals are set, to remove to rotational internal coordinates
      !! for a single atom.
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      integer :: fragment_id

      call this%calculate_bond_lengths()
      call this%calculate_bond_angles()
      call this%calculate_dihedral_angles()

      do fragment_id = 1, this%n_fragments

         call this%identify_rotation(fragment_id)
         call this%calculate_rotation(fragment_id)
         call this%calculate_translation(fragment_id)

      end do

   end subroutine calculate_internal_coordinates


   subroutine calculate_bond_lengths(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      integer :: bond_index

      integer :: A, B

      real(dp), dimension(3) :: AB

      integer :: q

      do bond_index = 1, this%n_bonds

         A = this%bonds(bond_index)%atoms(1)
         B = this%bonds(bond_index)%atoms(2)

         do q = 1, 3

            AB(q) = this%R(q, A) - this%R(q, B)

         end do

         this%bonds(bond_index)%length = norm_R3(AB)

      end do

   end subroutine calculate_bond_lengths


   subroutine calculate_bond_angles(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      integer :: angle_index

      integer :: A, B, C

      real(dp), dimension(3) :: AB, CB

      integer :: q

      do angle_index = 1, this%n_angles

         A = this%angles(angle_index)%atoms(1)
         B = this%angles(angle_index)%atoms(2)
         C = this%angles(angle_index)%atoms(3)

         do q = 1, 3

            AB(q) = this%R(q, A) - this%R(q, B)
            CB(q) = this%R(q, C) - this%R(q, B)

         end do

         this%angles(angle_index)%theta = acos(dot_R3(AB, CB) / (norm_R3(AB) * norm_R3(CB)))

      end do

   end subroutine calculate_bond_angles


   subroutine calculate_dihedral_angles(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      integer :: dihedral_index

      integer :: A, B, C, D

      real(dp), dimension(3) :: AB, BC, CD, ABxBC, BCxCD

      real(dp) :: norm_BC, y, x

      integer :: q

      do dihedral_index = 1, this%n_dihedrals

         A = this%dihedrals(dihedral_index)%atoms(1)
         B = this%dihedrals(dihedral_index)%atoms(2)
         C = this%dihedrals(dihedral_index)%atoms(3)
         D = this%dihedrals(dihedral_index)%atoms(4)

         do q = 1, 3

            AB(q) = this%R(q, A) - this%R(q, B)
            BC(q) = this%R(q, B) - this%R(q, C)
            CD(q) = this%R(q, C) - this%R(q, D)

         end do

         norm_BC = norm_R3(BC)

         ABxBC = cross_product_R3(AB, BC)
         BCxCD = cross_product_R3(BC, CD)

         y = dot_R3(norm_BC * AB, BCxCD)
         x = dot_R3(ABxBC, BCxCD)

         this%dihedrals(dihedral_index)%theta = - atan2(y, x)

      end do

   end subroutine calculate_dihedral_angles


   subroutine calculate_rotation(this, fragment_id)
      !!
      !! Written by Jan Haakon M. Trabski, 2022
      !!
      !! Calculates the rotational internal coordinate with respect to a reference molecule
      !!
      implicit none

      class(redundant_internal_coords) :: this

      integer :: i, fragment_id

      ! Helps us standardize the rotation.

      if (this%F_matrix_eigenvectors(1, 4, fragment_id) <= zero) then

         call dscal(4, - one, this%F_matrix_eigenvectors(:, 4, fragment_id), 1)

      end if

      if (abs(this%F_matrix_eigenvectors(1, 4, fragment_id) - one) < 1d-8) then
         do i = 1, 3

            this%rotations(fragment_id)%theta(i) = this%Gyro_ratio(fragment_id) &
                                                   * ((two &
                                                   * this%F_matrix_eigenvectors(i + 1, 4, fragment_id)) &
                                                   - two * this%F_matrix_eigenvectors(i + 1, 4, fragment_id) &
                                                   * (this%F_matrix_eigenvectors(1, 4, fragment_id) - one) / &
                                                   three)

         end do
      else
         do i = 1, 3

            this%rotations(fragment_id)%theta(i) = this%Gyro_ratio(fragment_id) &
                                                   * two * this%F_matrix_eigenvectors(i + 1, 4, fragment_id) &
                                                   * acos(this%F_matrix_eigenvectors(1, 4, fragment_id)) / &
                                                   (sqrt(one &
                                                   - this%F_matrix_eigenvectors(1, 4, fragment_id)**2))

         end do
      end if

   end subroutine calculate_rotation


   subroutine calculate_translation(this, fragment_id)
      !!
      !! Written by Jan Haakon M. Trabski, 2022
      !!
      !! Calculates the translational internal coordinates defined as
      !! the sum over each atom devided by the amount of atoms in fragment
      !!
      implicit none

      class(redundant_internal_coords) :: this

      integer :: i, j, fragment_id

      this%translations(fragment_id)%position(:) = zero

      do i = 1, this%n_atoms
         if (this%fragments(i)%fragment_id == fragment_id) then
            do j = 1, 3

               this%translations(fragment_id)%position(j) = &
                                                            (this%R(j, i)) / &
                                                            this%atoms_in_fragments(fragment_id) &
                                                            + this%translations(fragment_id)%position(j)

            end do
         end if
      end do

   end subroutine calculate_translation


   subroutine construct_Wilson_B(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! Constructs the Wilson B matrix, given by
      !!
      !!    B_ij = dq_i/dx_j
      !!
      !! where q_i are the internal coordinates and x_j are the Cartesian coordinates.
      !!
      !! The different logicals are set, to remove rotational internal coordinates
      !! for a single atom.
      !!
      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      integer :: fragment_id

      call this%construct_Wilson_B_bonds()
      call this%construct_Wilson_B_bond_angles()
      call this%construct_Wilson_B_dihedral_angles()

      do fragment_id = 1, this%n_fragments

         call this%construct_Wilson_B_rotation(fragment_id)
         call this%construct_Wilson_B_translation(fragment_id)

      end do

      call output%print_matrix('v', &
                               'Wilson B', &
                               this%B, &
                               this%n_internal, &
                               this%n_cartesian, &
                               fs='(f19.12)')

   end subroutine construct_Wilson_B


   subroutine construct_Wilson_B_bonds(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      use math_utilities, only: delta

      implicit none

      class(redundant_internal_coords), intent(inout), target :: this

      real(dp), dimension(:, :, :), pointer :: B_p

      integer :: m, n, bond_index, a, i

      real(dp) :: norm_u

      real(dp), dimension(3) :: u

      integer :: q

      B_p(1:this%n_internal, 1:3, 1:this%n_atoms) => this%B

      do bond_index = 1, this%n_bonds

         m = this%bonds(bond_index)%atoms(1)
         n = this%bonds(bond_index)%atoms(2)

         do q = 1, 3

            u(q) = this%R(q, m) - this%R(q, n)

         end do

         norm_u = norm_R3(u)

         u = u / norm_u

         do a = 1, this%n_atoms
            do i = 1, 3

               B_p(bond_index, i, a) = (delta(a, m) - delta(a, n)) * u(i)

            end do
         end do

      end do

   end subroutine construct_Wilson_B_bonds


   subroutine construct_Wilson_B_bond_angles(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      use math_utilities, only: delta

      implicit none

      class(redundant_internal_coords), intent(inout), target :: this

      real(dp), dimension(:, :, :), pointer :: B_p

      real(dp), dimension(3) :: v1, v2, u, v, w, uxw, wxv

      integer :: m, o, n, angle_index, a, i

      real(dp) :: norm_u, norm_v, norm_w

      integer :: q

      B_p(1:this%n_internal, 1:3, 1:this%n_atoms) => this%B

      v1 = [one, - one, one]
      v2 = [- one, one, one]

      do angle_index = 1, this%n_angles

         m = this%angles(angle_index)%atoms(1)
         o = this%angles(angle_index)%atoms(2)
         n = this%angles(angle_index)%atoms(3)

         do q = 1, 3

            u(q) = this%R(q, m) - this%R(q, o)
            v(q) = this%R(q, n) - this%R(q, o)

         end do

         norm_u = norm_R3(u)
         norm_v = norm_R3(v)

         u = u / norm_u
         v = v / norm_v

         if (dot_R3(u, v) /= one) then  ! u not parallel with v

            w = cross_product_R3(u, v)

         elseif (dot_R3(u, v1) /= norm_R3(v1)) then  ! u not parallel with v1

            w = cross_product_R3(u, v1)

         else  ! u parallel with v1; cross with v2

            w = cross_product_R3(u, v2)

         end if

         norm_w = norm_R3(w)
         w = w / norm_w

         uxw = cross_product_R3(u, w)
         wxv = cross_product_R3(w, v)

         do a = 1, this%n_atoms
            do i = 1, 3

               B_p(this%n_bonds + angle_index, i, a) = &
                                                       (delta(a, m) - delta(a, o)) * uxw(i) / norm_u &
                                                       + (delta(a, n) - delta(a, o)) * wxv(i) / norm_v

            end do
         end do

      end do

   end subroutine construct_Wilson_B_bond_angles


   subroutine construct_Wilson_B_dihedral_angles(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      use math_utilities, only: delta

      implicit none

      class(redundant_internal_coords), intent(inout), target :: this

      real(dp), dimension(:, :, :), pointer :: B_p

      integer :: dihedral_index, m, o, p, n, a, i

      real(dp), dimension(3) :: u, v, w, uxw, vxw

      real(dp) :: norm_u, norm_v, norm_w, cos_phiu, cos_phiv, sin_phiu, sin_phiv

      integer :: q

      B_p(1:this%n_internal, 1:3, 1:this%n_atoms) => this%B

      do dihedral_index = 1, this%n_dihedrals

         m = this%dihedrals(dihedral_index)%atoms(1)
         o = this%dihedrals(dihedral_index)%atoms(2)
         p = this%dihedrals(dihedral_index)%atoms(3)
         n = this%dihedrals(dihedral_index)%atoms(4)

         do q = 1, 3

            u(q) = this%R(q, m) - this%R(q, o)
            v(q) = this%R(q, n) - this%R(q, p)
            w(q) = this%R(q, p) - this%R(q, o)

         end do

         norm_u = norm_R3(u)
         norm_v = norm_R3(v)
         norm_w = norm_R3(w)

         u = u / norm_u
         v = v / norm_v
         w = w / norm_w

         uxw = cross_product_R3(w, u)
         vxw = cross_product_R3(v, w)

         cos_phiu = dot_R3(u, w)
         sin_phiu = sqrt(one - cos_phiu**2)

         cos_phiv = - dot_R3(v, w)
         sin_phiv = sqrt(one - cos_phiv**2)

         do a = 1, this%n_atoms
            do i = 1, 3

               B_p(this%n_bonds + this%n_angles + dihedral_index, i, a) &
                  = - (+ (delta(a, m) - delta(a, o)) * uxw(i) / (norm_u * sin_phiu**2) &
                  - (delta(a, p) - delta(a, n)) * vxw(i) / (norm_v * sin_phiv**2) &
                  + (delta(a, o) - delta(a, p)) &
                  * (uxw(i) * cos_phiu / (norm_w * sin_phiu**2) &
                  - vxw(i) * cos_phiv / (norm_w * sin_phiv**2)))

            end do
         end do

      end do

   end subroutine construct_Wilson_B_dihedral_angles


   subroutine construct_Wilson_B_rotation(this, fragment_id)
      !!
      !! Written by Jan Haakon M. Trabski, 2022
      !!
      !! Wang, L.-P.; Song, C.C. (2016)
      !! Geometry optimization made simple with translation and rotation coordinates,
      !! J. Chem. Phys. 144, 214108.
      !!
      !! Gives the wilson_B_elements of the quaternions dq_i/dx_j,
      !! where dq is the derivative of the internal coordinates which are quaternions
      !!
      !! We need to evaluate the derivatve of the SO(3) group with respect to
      !!
      !! dv_i/dx_nj = sum_k^4*(dv_i/dq_k)*(dq_k/dx_nj)
      !!
      !! We want to find dq_i/dx_nj = Psudo-inv[lambda_max-F]* dF/dx_jn*q
      !!

      implicit none

      class(redundant_internal_coords), intent(inout), target :: this

      integer, intent(in) :: fragment_id

      real(dp), dimension(this%n_atoms, 3, 4) :: dq

      call this%construct_quaternion_derivative(fragment_id, dq)

      if (this%atoms_in_fragments(fragment_id) == 1) then

         call this%fragment_with_single_atom(fragment_id)

      elseif (abs(this%F_matrix_eigenvectors(1, 4, fragment_id) - 1) < 1d-8) then

         call this%construct_wilson_B_rotation_singular(fragment_id, dq)

      else

         call this%construct_wilson_B_rotation_nonsingular(fragment_id, dq)

      end if

   end subroutine construct_Wilson_B_rotation


   subroutine construct_Wilson_B_translation(this, fragment_id)
      !!
      !! Written by Jan Haakon M. Trabski, 2022
      !!
      !! Wang, L.-P.; Song, C.C. (2016)
      !! Geometry optimization made simple with translation and rotation coordinates,
      !! J. Chem. Phys. 144, 214108.
      !!
      !! Gives the wilson_B_elements of the translation, defined as the derivative over the mean of x_i/atoms, i = 1,2,3
      !!
      use math_utilities, only: delta

      implicit none

      class(redundant_internal_coords), intent(inout), target :: this

      real(dp), dimension(:, :, :), pointer :: B_p

      integer :: i, j, n, fragment_id, index

      B_p(1:this%n_internal, 1:3, 1:this%n_atoms) => this%B

      do n = 1, this%n_atoms

         if (this%fragments(n)%fragment_id == fragment_id) then

            do i = 1, 3

               do j = 1, 3

                  index = this%n_internal - this%n_rotations - fragment_id * 3 + j

                  B_p(index, i, n) = delta(j, i) / this%atoms_in_fragments(fragment_id)

               end do
            end do
         end if
      end do

   end subroutine construct_Wilson_B_translation


   subroutine construct_quaternion_fitting_matrix(X, Y)
      !!
      !! Written by Alexander C. Paul and Jan Haakon M. Trabski, 2023
      !!
      implicit none

      real(dp), dimension(3, 3), intent(in) :: X
      real(dp), dimension(4, 4), intent(out) :: Y

      Y(1, 1) = X(1, 1) + X(2, 2) + X(3, 3)
      Y(1, 2) = X(2, 3) - X(3, 2)
      Y(1, 3) = X(3, 1) - X(1, 3)
      Y(1, 4) = X(1, 2) - X(2, 1)

      Y(2, 1) = X(2, 3) - X(3, 2)
      Y(2, 2) = X(1, 1) - X(2, 2) - X(3, 3)
      Y(2, 3) = X(1, 2) + X(2, 1)
      Y(2, 4) = X(1, 3) + X(3, 1)

      Y(3, 1) = X(3, 1) - X(1, 3)
      Y(3, 2) = X(1, 2) + X(2, 1)
      Y(3, 3) = - X(1, 1) + X(2, 2) - X(3, 3)
      Y(3, 4) = X(2, 3) + X(3, 2)

      Y(4, 1) = X(1, 2) - X(2, 1)
      Y(4, 2) = X(1, 3) + X(3, 1)
      Y(4, 3) = X(2, 3) + X(3, 2)
      Y(4, 4) = - X(1, 1) - X(2, 2) + X(3, 3)

   end subroutine construct_quaternion_fitting_matrix


   subroutine construct_derivative_F_matrix(this, fragment_id, dF)
      !!
      !! Written by Alexander C. Paul and Jan Haakon M. Trabski, 2023
      !!
      !! Evaluates dF_ij/dx_kn constructed as a linear combination of
      !! derivatives of the correlation matrix:
      !!
      !!    dR_ij/dx_kn = delta_ik * y_jn
      !!
      !! where y_jn is reference cartesian coordinate j of atom n
      !! and x_kn is the cartesian coordinate k of atom n
      !!
      !! See equations 6, 13 and 14 of Wang, Song, J. Chem. Phys. 2016, 144, 214108
      !!
      use math_utilities, only: delta
      use reordering_r, only: sort_to_4312

      implicit none

      class(redundant_internal_coords), intent(in) :: this

      integer, intent(in) :: fragment_id
      ! (n_atoms, cartesian_coord, row_F, column_F)
      real(dp), dimension(this%n_atoms, 3, 4, 4), intent(out) :: dF

      real(dp), dimension(:, :, :, :), allocatable :: dR  ! (n_atoms, cartesian_coord, row_R, column_R)
      real(dp), dimension(:, :, :, :), allocatable :: dF_tmp

      integer :: n, i, j, k

      call mem%alloc(dR, 3, 3, 3, this%n_atoms, set_zero=.true.)
      call mem%alloc(dF_tmp, 4, 4, 3, this%n_atoms)

      do n = 1, this%n_atoms

         if (this%fragments(n)%fragment_id == fragment_id) then

            do k = 1, 3
               do j = 1, 3
                  do i = 1, 3


                     dR(i, j, k, n) = delta(i, k) * this%fragments(n)%reference_molecule(j)

                  end do
               end do
            end do
         end if
      end do

      do n = 1, this%n_atoms
         do i = 1, 3

            call this%construct_quaternion_fitting_matrix(dR(:, :, i, n), dF_tmp(:, :, i, n))

         end do
      end do

      call mem%dealloc(dR)
      call sort_to_4312(dF_tmp, dF, 4, 4, 3, this%n_atoms)
      call mem%dealloc(dF_tmp)

   end subroutine construct_derivative_F_matrix


   subroutine construct_pseudo_inverse_F_matrix(this, fragment_id, pseudo_F)
      !!
      !! Written by Alexander C. Paul and Jan Haakon M. Trabski, 2023
      !!
      !! Constructs the pseudo-inverse of M = (Lambda I - F)
      !!
      use array_utilities, only: calculate_pseudoinverse
      use array_initialization, only: identity_array

      implicit none

      class(redundant_internal_coords), intent(in) :: this
      integer, intent(in) :: fragment_id
      real(dp), dimension(4, 4), intent(out) :: pseudo_F

      real(dp), dimension(4, 4) :: eigenvalue_minus_F

      call identity_array(eigenvalue_minus_F, 4)
      call dscal(16, this%eigenvalues(4, fragment_id), eigenvalue_minus_F, 1)
      call daxpy(16, - one, this%F_matrix(:, :, fragment_id), 1, eigenvalue_minus_F, 1)

      call calculate_pseudoinverse(pseudo_F, &
                                   eigenvalue_minus_F, &
                                   4, &
                                   4, &
                                   this%pseudoinverse_threshold)

   end subroutine construct_pseudo_inverse_F_matrix


   subroutine construct_quaternion_derivative(this, fragment_id, dq)
      !!
      !! Written by Alexander C. Paul and Jan Haakon M. Trabski, 2023
      !!
      !! Implements equation 12 of Wang, Song, J. Chem. Phys. 2016, 144, 214108
      !!
      !! dq/dx_jn = (Lambda I - F)^-1 * dF/dx_in * q
      !!
      !! Where Lambda: largest eigenvalue of F
      !!       q:      Optimal rotation quternion (eigenvector corresponding to Lambda)
      !!       x_jn:   cartesian (j) coordinates of atom n
      !!
      implicit none

      class(redundant_internal_coords) :: this

      integer, intent(in) :: fragment_id
      real(dp), dimension(this%n_atoms, 3, 4), intent(out) :: dq

      real(dp), dimension(:, :, :, :), allocatable :: dF  ! (n_atoms, cartesian_coord, row_F, column_F)
      real(dp), dimension(:, :, :), allocatable :: intermediate  ! (n_atoms, cartesian_coord, 4)
      real(dp), dimension(4, 4) :: pseudo_F

      call mem%alloc(dF, this%n_atoms, 3, 4, 4)

      call this%construct_derivative_F_matrix(fragment_id, dF)

      call mem%alloc(intermediate, this%n_atoms, 3, 4)

      call this%construct_pseudo_inverse_F_matrix(fragment_id, pseudo_F)

      ! dq(n,i,j) = pseudo_F(j,a) * dF(n,i,a,b) * q(b)

      call dgemv('N', &
                 this%n_atoms * 3 * 4, &
                 4, &
                 one, &
                 dF, &  ! n,i,a, b
                 this%n_atoms * 3 * 4, &
                 this%F_matrix_eigenvectors(:, 4, fragment_id), &  ! b
                 1, &
                 zero, &
                 intermediate, &
                 1)  ! n,i,a

      call dgemm('N', &
                 'T', &
                 this%n_atoms * 3, &
                 4, &
                 4, &
                 one, &
                 intermediate, &  ! n,i,a
                 this%n_atoms * 3, &
                 pseudo_F, &  ! pseudo_F(j,a)
                 4, &
                 zero, &
                 dq, &  ! n,i,j
                 this%n_atoms * 3)

      call mem%dealloc(dF)
      call mem%dealloc(intermediate)

   end subroutine construct_quaternion_derivative


   subroutine construct_wilson_B_rotation_singular(this, fragment_id, dq)
      !!
      !! Written by Alexander C. Paul and Jan Haakon M. Trabski, 2023
      !!
      !! Due to singularities around 0 in the analytical expresstion,
      !! we taylor expanded around 0, and keep only the first two terms in the series.
      !!
      implicit none

      class(redundant_internal_coords), intent(inout), target :: this

      real(dp), dimension(this%n_atoms, 3, 4), intent(in) :: dq

      integer, intent(in) :: fragment_id

      real(dp), dimension(:, :, :), pointer :: B_p
      integer :: n, i, j, index

      B_p(1:this%n_internal, 1:3, 1:this%n_atoms) => this%B

      do n = 1, this%n_atoms

         if (.not. this%fragments(n)%fragment_id == fragment_id) cycle
         do i = 1, 3

            do j = 1, 3


               index = this%n_internal - fragment_id * 3 + j

               B_p(index, i, n) = &
                                  two / three * this%Gyro_ratio(fragment_id) &
                                  * ((- this%F_matrix_eigenvectors(j + 1, 4, fragment_id) * dq(n, i, 1)) &
                                  + (four - this%F_matrix_eigenvectors(1, 4, fragment_id)) &
                                  * dq(n, i, j + 1))

            end do
         end do
      end do

   end subroutine construct_wilson_B_rotation_singular


   subroutine construct_Wilson_B_rotation_nonsingular(this, fragment_id, dq)
      !!
      !! Written by Alexander C. Paul and Jan Haakon M. Trabski, 2023
      !!
      implicit none

      class(redundant_internal_coords), intent(inout), target :: this

      integer, intent(in) :: fragment_id
      real(dp), dimension(this%n_atoms, 3, 4), intent(in) :: dq

      real(dp), dimension(:, :, :), pointer :: B_p

      real(dp) :: common_factor_1, common_factor_2
      integer :: n, i, j, index

      B_p(1:this%n_internal, 1:3, 1:this%n_atoms) => this%B

      common_factor_1 = &
                        two &
                        * (this%F_matrix_eigenvectors(1, 4, fragment_id) &
                        * acos(this%F_matrix_eigenvectors(1, 4, fragment_id)) / &
                        sqrt((one - this%F_matrix_eigenvectors(1, 4, fragment_id)**2))**3 &
                        - one / (one - this%F_matrix_eigenvectors(1, 4, fragment_id)**2))

      common_factor_2 = two * acos(this%F_matrix_eigenvectors(1, 4, fragment_id)) / &
                        sqrt(one - this%F_matrix_eigenvectors(1, 4, fragment_id)**2)

      do n = 1, this%n_atoms

         do i = 1, 3

            do j = 1, 3

               if (this%fragments(n)%fragment_id == fragment_id) then
                  if (this%atoms_in_fragments(fragment_id) == 1) cycle

                  index = this%n_internal - fragment_id * 3 + j

                  B_p(index, i, n) = &
                                     (this%F_matrix_eigenvectors(j + 1, 4, fragment_id) * common_factor_1 &
                                     * dq(n, i, 1) + common_factor_2 * dq(n, i, j + 1)) &
                                     * this%Gyro_ratio(fragment_id)

               end if
            end do
         end do
      end do

   end subroutine construct_Wilson_B_rotation_nonsingular


   subroutine fragment_with_single_atom(this, fragment_id)
      !!
      !! Written Jan Haakon M. Trabski, 2023
      !!
      implicit none

      class(redundant_internal_coords), intent(inout), target :: this

      real(dp), dimension(:, :, :), pointer :: B_p

      integer :: i, j, n, index, fragment_id

      B_p(1:this%n_internal, 1:3, 1:this%n_atoms) => this%B

      do n = 1, this%n_atoms

         do i = 1, 3

            do j = 1, 3

               if (this%fragments(n)%fragment_id == fragment_id) then

                  index = this%n_internal - fragment_id * 3 + j

                  B_p(index, i, n) = zero

               end if
            end do
         end do
      end do

   end subroutine fragment_with_single_atom


   subroutine pseudoinvert_Wilson_B_and_construct_P(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! Constructs the pseudoinverse of B and P = G G_inv,
      !! where G = B B^T and G_inv is the pseudoinverse of G
      !!
      use array_utilities, only: calculate_pseudoinverse

      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      real(dp), dimension(this%n_internal, this%n_internal) :: G
      real(dp), dimension(this%n_internal, this%n_internal) :: G_inv

      call dgemm('N', &
                 'T', &
                 this%n_internal, &
                 this%n_internal, &
                 this%n_cartesian, &
                 one, &
                 this%B, &
                 this%n_internal, &
                 this%B, &
                 this%n_internal, &
                 zero, &
                 G, &
                 this%n_internal)

      call calculate_pseudoinverse(G_inv, &
                                   G, &
                                   this%n_internal, &
                                   this%n_internal, &
                                   this%pseudoinverse_threshold)

      call dgemm('N', &
                 'N', &
                 this%n_internal, &
                 this%n_internal, &
                 this%n_internal, &
                 one, &
                 G, &
                 this%n_internal, &
                 G_inv, &
                 this%n_internal, &
                 zero, &
                 this%P, &
                 this%n_internal)

      call output%print_matrix('v', 'Wilson P', this%P, this%n_internal, this%n_internal)

      call dgemm('T', &
                 'N', &
                 this%n_cartesian, &
                 this%n_internal, &
                 this%n_internal, &
                 one, &
                 this%B, &
                 this%n_internal, &
                 G_inv, &
                 this%n_internal, &
                 zero, &
                 this%B_inverse, &
                 this%n_cartesian)

      call output%print_matrix('v', &
                               'Wilson B_inv', &
                               this%B_inverse, &
                               this%n_cartesian, &
                               this%n_internal, &
                               fs='(f19.12)')

   end subroutine pseudoinvert_Wilson_B_and_construct_P


   subroutine get_approximate_diagonal_Hessian(this, H_diagonal)
      !!
      !! Written by Eirik F. Kjoenstad and Jan Haakon M. Trabski, 2021-2022
      !!
      !! Returns the "simple" Hessian diagonal estimate from Bakken and Helgaker (2002).
      !!
      implicit none

      class(redundant_internal_coords), intent(in) :: this

      real(dp), dimension(this%n_internal), intent(out) :: H_diagonal

      integer :: k

      do k = 1, this%n_bonds

         H_diagonal(k) = 0.5d0

      end do

      do k = this%n_bonds + 1, this%n_bonds + this%n_angles

         H_diagonal(k) = 0.2d0

      end do

      do k = this%n_bonds + this%n_angles + 1, this%n_internal

         H_diagonal(k) = 0.1d0

      end do

      do k = this%n_bonds + this%n_angles + this%n_dihedrals + 1, this%n_internal

         H_diagonal(k) = 0.5d0

      end do

   end subroutine get_approximate_diagonal_Hessian


   subroutine destructor(this)
      !!
      !! Written by Eirik F. Kjoenstad and Jan Haakon M. Trabski, 2021-2022
      !!
      implicit none

      type(redundant_internal_coords) :: this

      if (allocated(this%R)) call mem%dealloc(this%R)
      if (allocated(this%Z)) call mem%dealloc(this%Z)

      if (allocated(this%B)) call mem%dealloc(this%B)
      if (allocated(this%B_inverse)) call mem%dealloc(this%B_inverse)

      if (allocated(this%P)) call mem%dealloc(this%P)

      if (allocated(this%q)) call mem%dealloc(this%q)
      if (allocated(this%prev_q)) call mem%dealloc(this%prev_q)

      if (allocated(this%bond_matrix)) call mem%dealloc(this%bond_matrix)

      if (allocated(this%Gyro_ratio)) call mem%dealloc(this%Gyro_ratio)
      if (allocated(this%F_matrix)) call mem%dealloc(this%F_matrix)

      if (allocated(this%F_matrix_eigenvectors)) call mem%dealloc(this%F_matrix_eigenvectors)
      if (allocated(this%correlation_matrix)) call mem%dealloc(this%correlation_matrix)
      if (allocated(this%eigenvalues)) call mem%dealloc(this%eigenvalues)

   end subroutine destructor


   subroutine Wilson_project_vector(this, q)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! q = P q
      !!
      implicit none

      class(redundant_internal_coords), intent(in) :: this

      real(dp), dimension(this%n_internal), intent(inout) :: q

      real(dp), dimension(this%n_internal) :: q0

      q0 = q

      call dgemm('N', &
                 'N', &
                 this%n_internal, &
                 1, &
                 this%n_internal, &
                 one, &
                 this%P, &
                 this%n_internal, &
                 q0, &
                 this%n_internal, &
                 zero, &
                 q, &
                 this%n_internal)

   end subroutine Wilson_project_vector


   subroutine Wilson_project_matrix(this, H)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! H = P H P
      !!
      implicit none

      class(redundant_internal_coords), intent(in) :: this

      real(dp), dimension(this%n_internal, this%n_internal), intent(inout) :: H

      real(dp), dimension(this%n_internal, this%n_internal) :: H0, H0P

      H0 = H

      call dgemm('N', &
                 'N', &
                 this%n_internal, &
                 this%n_internal, &
                 this%n_internal, &
                 one, &
                 H0, &
                 this%n_internal, &
                 this%P, &
                 this%n_internal, &
                 zero, &
                 H0P, &
                 this%n_internal)

      call dgemm('N', &
                 'N', &
                 this%n_internal, &
                 this%n_internal, &
                 this%n_internal, &
                 one, &
                 this%P, &
                 this%n_internal, &
                 H0P, &
                 this%n_internal, &
                 zero, &
                 H, &
                 this%n_internal)

   end subroutine Wilson_project_matrix


   subroutine calculate_internal_gradient(this, g_x, g_q)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! g_q = (B_inv)^T g_x
      !!
      implicit none

      class(redundant_internal_coords), intent(in) :: this

      real(dp), dimension(this%n_cartesian), intent(in) :: g_x
      real(dp), dimension(this%n_internal), intent(out) :: g_q

      call dgemm('T', &
                 'N', &
                 this%n_internal, &
                 1, &
                 this%n_cartesian, &
                 one, &
                 this%B_inverse, &
                 this%n_cartesian, &
                 g_x, &
                 this%n_cartesian, &
                 zero, &
                 g_q, &
                 this%n_internal)

   end subroutine calculate_internal_gradient


   subroutine compute_next_geometry(this, x, s_q)
      !!
      !! Written by Eirik F. Kjoenstad and Anna-Kristina Schnack-Petersen, 2021
      !!
      !! Updates the cartesian geometry x with the internal coordinate step s_q by
      !! performing a back-transformation through an iterative procedure due to
      !! Bakken and Helgaker (2002).
      !!
      use array_utilities, only: get_root_mean_square

      implicit none

      class(redundant_internal_coords), intent(inout) :: this

      real(dp), dimension(this%n_cartesian), intent(inout) :: x

      real(dp), dimension(this%n_internal), intent(in) :: s_q

      real(dp), dimension(this%n_cartesian) :: xk_minus_1, xk, dx
      real(dp), dimension(this%n_internal) :: q_original, qk, ddq, dq, s_q_proj

      integer :: iteration
      real(dp) :: norm_dx
      logical :: converged

      call this%get_internals(this%prev_q)  ! Save current internals as previous internals

      call output%printf('m', 'Converting internal step to cartesian step:', fs='(/t6,a/)')

      call this%get_internals(q_original)

      s_q_proj = s_q

      call this%Wilson_project_vector(s_q_proj)
      call this%remove_multiples_of_360(s_q_proj)

      ! Start guess
      ddq = s_q
      xk_minus_1 = x

      call output%printf('m', 'Iteration     RMS (cartesian)', fs='(t6,a)')
      call output%print_separator('n', 29, '-', fs='(t6,a)')

      iteration = 1
      converged = .false.
      do while (.not. converged .and. iteration <= this%internal_to_cartesian_max_iterations)

         call this%perform_cartesian_step(xk, xk_minus_1, ddq)
         call this%set_geometry(xk)

         dx = xk - xk_minus_1

         norm_dx = get_root_mean_square(dx, this%n_cartesian)

         call output%printf('m', &
                            '(i4)          (e11.5)', &
                            ints=[iteration], &
                            reals=[norm_dx], &
                            fs='(t6,a)')

         converged = norm_dx < this%internal_to_cartesian_threshold
         if (converged) exit

         call this%get_internals(qk)

         dq = qk - q_original
         call this%remove_multiples_of_360(dq)
         ddq = s_q_proj - dq

         iteration = iteration + 1
         xk_minus_1 = xk

      end do

      call output%print_separator('n', 29, '-', fs='(t6,a)')

      if (converged) then

         call output%printf('m', 'Converged in (i0) iterations!', ints=[iteration], fs='(t6,a)')

      else

         call output%printf('m', &
                            'Could not find cartesian step from internal coordinate step!  Using initial&
                            & guess instead.')

         xk_minus_1 = x

         call this%set_geometry(xk_minus_1)
         call this%perform_cartesian_step(xk, xk_minus_1, s_q)
         call this%set_geometry(xk)

      end if

      x = xk

      call this%get_internals(this%q)  ! Save new current internals

   end subroutine compute_next_geometry


   subroutine perform_cartesian_step(this, x1, x0, q)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! x1 = x0 + B_inverse q
      !!
      implicit none

      class(redundant_internal_coords), intent(in) :: this

      real(dp), dimension(this%n_cartesian), intent(out) :: x1
      real(dp), dimension(this%n_cartesian), intent(in) :: x0
      real(dp), dimension(this%n_internal), intent(in) :: q

      real(dp), dimension(this%n_cartesian) :: dx

      x1 = x0

      call dgemm('N', &
                 'N', &
                 this%n_cartesian, &
                 1, &
                 this%n_internal, &
                 one, &
                 this%B_inverse, &
                 this%n_cartesian, &
                 q, &
                 this%n_internal, &
                 zero, &
                 dx, &
                 this%n_cartesian)

      x1 = x0 + dx

   end subroutine perform_cartesian_step


   subroutine remove_multiples_of_360(this, dq)
      !!
      !! Written by Eirik F. Kjoenstad, and Jan Haakon M. Trabski, 2021-2022
      !!
      !! Avoid redundancy in angles by restricting them to [-pi, pi].
      !!
      implicit none

      class(redundant_internal_coords), intent(in) :: this

      real(dp), dimension(this%n_internal), intent(inout) :: dq

      integer :: k

      do k = this%n_bonds + 1, this%n_internal - this%n_translations - this%n_rotations

         if (dq(k) < - pi) then

            ! -pi .q_1.. 0 ...q. pi

            dq(k) = dq(k) + two * pi

            call output%printf('v', 'Angle less than -pi: (f19.12). Will add 2*pi.', reals=[dq(k)])

         elseif (dq(k) > pi) then

            ! -pi .q.. 0 ...q_1. pi

            dq(k) = dq(k) - two * pi

            call output%printf('v', 'Angle greater than pi: (f19.12). Will subtract 2*pi.', reals=[dq(k)])

         end if

      end do

   end subroutine remove_multiples_of_360


   subroutine center_molecule(this, fragment_id)
      !!
      !! Written by Jan Haakon M. Trabski, 2022
      !!
      !! Procedure to center the geometry around its geometric center
      !!
      implicit none

      class(redundant_internal_coords) :: this

      real(dp), dimension(3) :: centroid
      integer :: i, atoms, fragment_id

      call zero_array(centroid, 3)
      atoms = 0

      do i = 1, this%n_atoms
         if (this%fragments(i)%fragment_id == fragment_id) then

            atoms = atoms + 1
            centroid = (this%R(:, i)) + centroid

         end if
      end do

      centroid = centroid / this%atoms_in_fragments(fragment_id)

      do i = 1, this%n_atoms
         if (this%fragments(i)%fragment_id == fragment_id) then

            this%fragments(i)%centered_coordinates = this%R(:, i) - centroid

         end if
      end do

   end subroutine center_molecule


   subroutine calculate_gyro_ratio(this, fragment_id)
      !!
      !! Written by Jan Haakon M. Trabski, 2022
      !!
      implicit none

      class(redundant_internal_coords) :: this

      integer :: i, atoms, fragment_id

      this%Gyro_ratio(fragment_id) = zero
      atoms = 0

      do i = 1, this%n_atoms
         if (this%fragments(i)%fragment_id == fragment_id) then

            atoms = atoms + 1

            this%Gyro_ratio(fragment_id) = norm_R3(this%fragments(i)%centered_coordinates(:))**2 &
                                           + this%Gyro_ratio(fragment_id)

         end if
      end do

      this%Gyro_ratio(fragment_id) = sqrt(this%Gyro_ratio(fragment_id) / atoms)

   end subroutine calculate_gyro_ratio


   subroutine update_reference(this, fragment_id)
      !!
      !! Written by Jan Haakon M. Trabski, 2022
      !!
      !! Procedure that updates and calculates reference molecule
      !!
      implicit none

      class(redundant_internal_coords) :: this

      integer :: atom, fragment_id

      do atom = 1, this%n_atoms
         if (this%fragments(atom)%fragment_id == fragment_id) then

            call dcopy(3, &
                       this%fragments(atom)%centered_coordinates, &
                       1, &
                       this%fragments(atom)%reference_molecule, &
                       1)

         end if
      end do

   end subroutine update_reference

end module redundant_internal_coordinates_class

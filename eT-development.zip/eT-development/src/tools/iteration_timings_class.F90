

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module iteration_timings_class

   !!
   !! Iteration timings class module
   !! Written by Alexander C. Paul, Aug 2022
   !!
   !! Class to handle timings of iterations.
   !! Usage is the same as for the timings class,
   !! but it keeps track of the number of times turn_on is called
   !! and it automatically resets the timer when turn_off is called.
   !!

   use parameters
   use timings_class, only: timings


   implicit none

   type, extends(timings) :: iteration_timings

      integer, private :: iteration
      character(len=95), private :: base_name

   contains

      procedure :: turn_on => turn_on_iteration_timings
      procedure :: turn_off => turn_off_iteration_timings

   end type iteration_timings

   interface iteration_timings

      procedure :: new_iteration_timer

   end interface iteration_timings

contains


   function new_iteration_timer(name_, pl) result(timer)
      !!
      !! Written by Alexander C. Paul
      !!
      implicit none

      type(iteration_timings) :: timer

      character(len=*), intent(in) :: name_
      character(len=*), intent(in), optional :: pl  ! print level

      timer%base_name = trim(name_)
      timer%name_ = trim(name_)
      timer%iteration = 0

      if (present(pl)) then

         timer%pl = trim(pl)

      else

         timer%pl = 'normal'

      end if

      call timer%reset()  ! Set times to zero

   end function new_iteration_timer


   subroutine turn_on_iteration_timings(timer)
      !!
      !! Written by Alexander C. Paul, Aug 2022
      !!
      !! Turns on the wall and CPU clocks.
      !!
      implicit none

      class(iteration_timings) :: timer
      integer :: counter, c_rate

      timer%iteration = timer%iteration + 1
      write(timer%name_, '(a,1x,i0)') trim(timer%base_name), timer%iteration

      call cpu_time(timer%cpu_time_start)
      call system_clock(count=counter, count_rate=c_rate)
      timer%wall_time_start = real(counter, dp) / c_rate

      timer%on = .true.

   end subroutine turn_on_iteration_timings


   subroutine turn_off_iteration_timings(timer)
      !!
      !! Written by Alexander C. Paul, Aug 2022
      !!
      !! Prints the wall and CPU times to the timing file, stopps, and resets the clock.
      !!
      implicit none

      class(iteration_timings), intent(inout) :: timer

      if (timer%on) call timer%freeze()
      call timer%print_times()
      call timer%reset()

   end subroutine turn_off_iteration_timings


end module iteration_timings_class


! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module array_utilities

   !!
   !! Array utilities module
   !!
   !! Routines that perform various operations on arrays.
   !! Reordering routines are gathered in a separate module (see reordering.F90).
   !!

   use parameters
   use global_out, only: output

   implicit none

   interface transpose_
      procedure :: transpose_with_copy, transpose_in_place
   end interface transpose_

   interface sandwich
      procedure :: sandwich_real, sandwich_complex
   end interface sandwich

   interface symmetric_sandwich
      procedure :: symmetric_sandwich, symmetric_sandwich_replace
   end interface symmetric_sandwich

   interface symmetric_sandwich_right_transposition
      procedure :: symmetric_sandwich_right_transposition_real, &
         symmetric_sandwich_right_transposition_complex_between_real, &
         symmetric_sandwich_right_transposition_replace
   end interface symmetric_sandwich_right_transposition

   interface scale_diagonal
      procedure :: scale_real_diagonal_by_real, scale_real_4_diagonal_by_real, &
         scale_real_4_diagonal_by_real_1324, scale_complex_4_diagonal_by_real_1324, &
         scale_complex_4_diagonal_by_complex_1324, scale_real_packed_4_diagonal_by_real, &
         scale_complex_packed_4_diagonal_by_real, scale_complex_packed_4_diagonal_by_complex
   end interface scale_diagonal

   interface dsfrk_
      procedure :: dsfrk_r, dsfrk_c
   end interface dsfrk_

contains

   subroutine dsfrk_r(n, k, alpha, A, beta, C)
      !!
      !! Written by Sarai D. Folkestad
      !!
      !! Wrapper for lapack dsfrk
      !!
      !!    C = alpha*A**T*A + beta*C,
      !!
      !! where C is returned in upper rectangular
      !! full packed format.
      !!
      implicit none

      integer :: n, k
      real(dp) :: alpha, beta
      real(dp), dimension(k, n) :: A
      real(dp), dimension((n + mod(n + 1, 2)), n * (n + 1) / 2) :: C

      call dsfrk('n', 'U', 'T', n, k, alpha, A, k, beta, C)

   end subroutine dsfrk_r


   subroutine dsfrk_c(n, k, alpha, A, beta, C)
      !!
      !! Written by Rolf H. Myhre
      !!
      !! lapack dsfrk
      !!
      !!    C = alpha*A**T*A + beta*C,
      !!
      !! does not exist for complex A and C. In stead
      !! must make two calls to dsyrk and one call to dgemm.
      !!
      !! C is returned in upper rectangular
      !! full packed format.
      !!
      implicit none

      integer :: n, k
      complex(dp) :: alpha, beta
      complex(dp), dimension(k, n) :: A
      complex(dp), dimension((n + mod(n + 1, 2)), n * (n + 1) / 2) :: C

      integer :: n1, n2, off

      n1 = n / 2
      n2 = n - n1
      off = mod(n + 1, 2)

      call zsyrk('L', &
                 'T', &
                 n1, &
                 k, &
                 alpha, &
                 A, &
                 k, &
                 beta, &
                 C(n2 + 1 + off, 1), &
                 n + off)

      call zsyrk('U', &
                 'T', &
                 n2, &
                 k, &
                 alpha, &
                 A(1, n2 + off), &
                 k, &
                 beta, &
                 C(n1 + 1, 1), &
                 n + off)

      call zgemm('T', &
                 'n', &
                 n1, &
                 n2, &
                 k, &
                 alpha, &
                 A, &
                 k, &
                 A(1, n2 + off), &
                 k, &
                 beta, &
                 C, &
                 n + off)

   end subroutine dsfrk_c


   pure function is_significant(x, n, threshold, screening) result(is_significant_)
      !!
      !! Is significant
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkstad, June 2018
      !!
      !! Returns true if one element of x (of length n) is greater, in absolute value,
      !! than "threshold": abs(x(i)) > threshold.
      !!
      !! screening (optional): if a screening vector is passed to the routine,
      !! then the testing criterion is abs(x(i)*screening(i)) > threshold.
      !!
      implicit none

      integer, intent(in) :: n

      real(dp), dimension(n), intent(in) :: x
      real(dp), dimension(n), intent(in), optional :: screening

      real(dp), intent(in) :: threshold

      integer :: i

      logical :: is_significant_

      is_significant_ = .false.

      if (present(screening)) then

         do i = 1, n

            if (abs(x(i) * screening(i)) > threshold) then

               is_significant_ = .true.
               return

            end if

         end do

      else

         do i = 1, n

            if (abs(x(i)) > threshold) then

               is_significant_ = .true.
               return

            end if

         end do
      end if

   end function is_significant


   subroutine reduce_vector(vec, vec_reduced, block_firsts, block_significant, n_blocks, dim_, dim_reduced)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      !! Cuts the significant blocks out of a vector and places them in a reduced size vector
      !!
      !! vec:  vector to cut out blocks from
      !! dim_: dimension of vec
      !!
      !! vec_reduced: vector to place the cut-out blocks into (intent: out)
      !! dim_reduced: dimension of vec_reduced
      !!
      !! n_blocks:          total number of blocks
      !! block_significant: a logical array, block_significant(i) == .true. means that i is a significant block
      !! block_firsts:      an integer array, of dimension n_blocks + 1, containing the first index of each significant block;
      !!                    the (n_blocks)+1-th element equals (last element of the final block) + 1.
      !!
      implicit none

      integer, intent(in) :: dim_, dim_reduced, n_blocks

      logical, dimension(n_blocks), intent(in) :: block_significant
      integer, dimension(n_blocks + 1), intent(in) :: block_firsts

      real(dp), dimension(dim_), intent(in) :: vec
      real(dp), dimension(dim_reduced), intent(out) :: vec_reduced

      integer :: block_, current_pos, first, last, size_

      current_pos = 1

      do block_ = 1, n_blocks

         if (block_significant(block_)) then

            first = block_firsts(block_)
            last = block_firsts(block_ + 1) - 1
            size_ = last - first + 1

            vec_reduced(current_pos:current_pos + size_ - 1) = vec(first:last)
            current_pos = current_pos + size_

         end if

      end do

   end subroutine reduce_vector


   subroutine reduce_array(array, &
                           array_reduced, &
                           block_firsts, &
                           block_significant, &
                           n_blocks, &
                           dim_, &
                           dim_reduced, &
                           columns)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      !! Cuts the significant row blocks out of a array and places them in a reduced size array
      !!
      !! array:   array to cut out blocks from
      !! dim_:    number of rows in array
      !!
      !! array_reduced: array to place the cut-out blocks into (intent: out)
      !! dim_reduced:   number of rows in array_reduced
      !!
      !! columns: number of columns in array and array_reduced
      !!
      !! n_blocks:          total number of blocks
      !! block_significant: a logical array, block_significant(i) == .true. means that i is a significant block
      !! block_firsts:      an integer array, of dimension n_blocks + 1, containing the first index of each significant block;
      !!                    the (n_blocks)+1-th element equals (last element of the final block) + 1.
      !!
      implicit none

      integer, intent(in) :: dim_, dim_reduced, n_blocks, columns

      logical, dimension(n_blocks), intent(in) :: block_significant
      integer, dimension(n_blocks + 1), intent(in) :: block_firsts

      real(dp), dimension(dim_, columns), intent(in) :: array
      real(dp), dimension(dim_reduced, columns), intent(out) :: array_reduced

      integer :: block_, current_pos, first, last, size_, I

      !$omp parallel do schedule(static) private(I, current_pos, block_, first, last, size_)
      do I = 1, columns

         current_pos = 1

         do block_ = 1, n_blocks

            if (block_significant(block_)) then

               first = block_firsts(block_)
               last = block_firsts(block_ + 1) - 1
               size_ = last - first + 1

               array_reduced(current_pos:current_pos + size_ - 1, I) = array(first:last, I)

               current_pos = current_pos + size_

            end if

         end do
      end do
      !$omp end parallel do

   end subroutine reduce_array


   subroutine reduce_array_int(array, &
                               array_reduced, &
                               block_firsts, &
                               block_significant, &
                               n_blocks, &
                               dim_, &
                               dim_reduced, &
                               columns)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      !! Cuts the significant row blocks out of a array and places them in a reduced size array
      !!
      !! array:   array to cut out blocks from
      !! dim_:    number of rows in array
      !!
      !! array_reduced: array to place the cut-out blocks into (intent: out)
      !! dim_reduced:   number of rows in array_reduced
      !!
      !! columns: number of columns in array and array_reduced
      !!
      !! n_blocks:          total number of blocks
      !! block_significant: a logical array, block_significant(i) == .true. means that i is a significant block
      !! block_firsts:      an integer array, of dimension n_blocks + 1, containing the first index of each significant block;
      !!                    the (n_blocks)+1-th element equals (last element of the final block) + 1.
      !!
      implicit none

      integer, intent(in) :: dim_, dim_reduced, n_blocks, columns

      logical, dimension(n_blocks), intent(in) :: block_significant
      integer, dimension(n_blocks + 1), intent(in) :: block_firsts

      integer, dimension(dim_, columns), intent(in) :: array
      integer, dimension(dim_reduced, columns), intent(out) :: array_reduced

      integer :: block_, current_pos, first, last, size_, I

      !$omp parallel do schedule(static) private(I, current_pos, block_, first, last, size_)
      do I = 1, columns

         current_pos = 1

         do block_ = 1, n_blocks

            if (block_significant(block_)) then

               first = block_firsts(block_)
               last = block_firsts(block_ + 1) - 1
               size_ = last - first + 1

               array_reduced(current_pos:(current_pos + size_ - 1), I) = array(first:last, I)

               current_pos = current_pos + size_

            end if

         end do
      end do
      !$omp end parallel do

   end subroutine reduce_array_int


   subroutine full_cholesky_decomposition(matrix, &
                                          cholesky_vectors, &
                                          dim_, &
                                          n_vectors, &
                                          threshold, &
                                          used_diag)
      !!
      !! Written by Sarai Dery Folkestad, June 2017.
      !!
      !! Wrapper for Lapack decomposition routine dpstrf.
      !!
      !! matrix:                          matrix M we want to decompose, P^T M P = L L^T
      !! cholesky_vectors (intent: out):  L
      !! dim_:                            M and L are (dim) x (dim) arrays
      !!
      !! used_diag (intent: out):         Vector (of dimension dim) containing the information in P:
      !!                                  P(used_diag(j), j) = one. Other elements of P are zero.
      !!
      !! threshold:                       Threshold to use in the Cholesky decomposition.
      !!
      !! n_vectors:                       Number of Cholesky vectors
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: dim_
      integer, intent(out) :: n_vectors

      real(dp), intent(in) :: threshold

      real(dp), dimension(dim_, dim_), intent(in) :: matrix
      real(dp), dimension(dim_, dim_), intent(out) :: cholesky_vectors

      integer, dimension(dim_) :: used_diag

      real(dp), dimension(:), allocatable :: work  ! work array for LAPACK

      integer :: info
      integer :: I, J

      call dcopy(dim_**2, matrix, 1, cholesky_vectors, 1)

      call mem%alloc(work, (2 * dim_))

      ! DPSTRF computes the Cholesky factorization with complete pivoting
      ! of a real symmetric positive semidefinite matrix.

      call dpstrf('L', &
                  dim_, &
                  cholesky_vectors, &
                  dim_, &
                  used_diag, &
                  n_vectors, &
                  threshold, &
                  work, &
                  info)

      call mem%dealloc(work)

      do I = 1, dim_  ! Zero upper unreferenced triangle
         do J = 1, I - 1

            cholesky_vectors(J, I) = zero

         end do
      end do

      if (info < 0) then
         call output%error_msg('Cholesky decomposition failed! Something wrong in call to dpstrf')
      end if

   end subroutine full_cholesky_decomposition


   subroutine invert(Ainv, A, n)
      !!
      !! Written by Sarai D. Folkestad, 2018
      !!
      !! Inverts n x n - matrix A and places the result in Ainv.
      !!
      implicit none

      integer, intent(in) :: n

      real(dp), dimension(n, n), intent(in) :: A
      real(dp), dimension(n, n), intent(inout) :: Ainv

      ! Store A in Ainv to prevent it from being overwritten by LAPACK
      call dcopy(n**2, A, 1, Ainv, 1)

      call invert_in_place(Ainv, n)

   end subroutine invert


   subroutine invert_in_place(A, n)
      !!
      !! Written by Sarai D. Folkestad, 2018
      !!
      !! Inverts n x n - matrix A and places the result in A.
      !!
      implicit none

      integer, intent(in) :: n

      real(dp), dimension(n, n), intent(inout) :: A

      real(dp), dimension(n) :: work  ! work array for LAPACK
      integer, dimension(n) :: ipiv  ! pivot indices
      integer :: info

      ! DGETRF computes an LU factorization of a general M-by-N matrix A
      ! using partial pivoting with row interchanges.

      call dgetrf(n, n, A, n, ipiv, info)

      if (info /= 0) &
         call output%error_msg('Matrix is numerically singular! dgetrf error integer: (i0)', ints=[info])

      ! DGETRI computes the inverse of a matrix using the LU factorization
      ! computed by DGETRF.

      call dgetri(n, A, n, ipiv, work, n, info)

      if (info /= 0) call output%error_msg('Matrix inversion failed! dgetri error integer: (i0)', ints=[info])

   end subroutine invert_in_place


   pure real(dp) function get_abs_max(X, n)
      !!
      !! Get absolute maximum value of vector
      !! Written by Eirik F. Kjoenstad, 2018
      !!
      !! Returns the largest element, in absolute valute value, of X (length: n)
      !!
      implicit none

      integer, intent(in) :: n

      real(dp), dimension(n), intent(in) :: X

      integer :: i

      get_abs_max = zero

      do i = 1, n

         if (abs(X(i)) > get_abs_max) get_abs_max = abs(X(i))

      end do

   end function get_abs_max


   subroutine get_abs_max_w_index(X, n, abs_max, index_)
      !!
      !! Written by Sarai D. Folkestad, Sep 2019
      !!
      !! Computes the largest element, in absolute valute value, of X (length: n),
      !! and the index of X associated with that value.
      !!
      !! The routine is a copy of the function get_abs_max
      !! written by Eirik F. Kjoenstad. S.D.F added the
      !! index_ stuff.
      !!
      implicit none

      integer, intent(in) :: n

      real(dp), dimension(n), intent(in) :: X

      real(dp) :: abs_max

      integer :: index_

      integer :: i

      abs_max = zero
      index_ = 0

      do i = 1, n

         if (abs(X(i)) > abs_max) then
            abs_max = abs(X(i))
            index_ = i
         end if

      end do

   end subroutine get_abs_max_w_index


   subroutine sandwich_real(X, A, B, n, transpose_left)
      !!
      !! Written by Eirik F. Kjoenstad, 2018
      !!
      !! Overwrites the n-by-n matrix X with a sandwich-ed X:
      !!
      !!    X <- A^T X B
      !!
      !! All matrices are n x n.
      !!
      !! left (optional): if true, transpose the left factor, A (standard);
      !! if false, tranpose the right factor, B.
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: n

      real(dp), dimension(n, n), intent(in) :: A
      real(dp), dimension(n, n), intent(in) :: B

      real(dp), dimension(n, n) :: X

      logical, intent(in) :: transpose_left

      real(dp), dimension(:, :), allocatable :: tmp

      call mem%alloc(tmp, n, n)

      if (transpose_left) then  ! Transpose the left factor, X <- A^T X B

         call dgemm('N', &
                    'N', &
                    n, &
                    n, &
                    n, &
                    one, &
                    X, &
                    n, &
                    B, &
                    n, &
                    zero, &
                    tmp, &  ! tmp = X B
                    n)

         call dgemm('T', &
                    'N', &
                    n, &
                    n, &
                    n, &
                    one, &
                    A, &
                    n, &
                    tmp, &
                    n, &
                    zero, &
                    X, &  ! X = A^T tmp = A^T X B
                    n)

      else  ! Transpose the right factor, X <- A X B^T

         call dgemm('N', &
                    'T', &
                    n, &
                    n, &
                    n, &
                    one, &
                    X, &
                    n, &
                    B, &
                    n, &
                    zero, &
                    tmp, &  ! tmp = X B^T
                    n)

         call dgemm('N', &
                    'N', &
                    n, &
                    n, &
                    n, &
                    one, &
                    A, &
                    n, &
                    tmp, &
                    n, &
                    zero, &
                    X, &  ! X = A tmp = A X B^T
                    n)

      end if

      call mem%dealloc(tmp)

   end subroutine sandwich_real


   subroutine sandwich_complex(X, A, B, n, transpose_left)
      !!
      !! Written by Andreas Skeidsvoll, Jan 2020
      !!
      !! Overwrites the n-by-n matrix X with a sandwich-ed X:
      !!
      !!    X <- A^T X B
      !!
      !! All matrices are n x n.
      !!
      !! left (optional): if true, transpose the left factor, A (standard);
      !! if false, tranpose the right factor, B.
      !!
      !! Based on sandwich_real by Eirik F. Kjoenstad, 2018
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: n

      complex(dp), dimension(n, n), intent(in) :: A
      complex(dp), dimension(n, n), intent(in) :: B

      complex(dp), dimension(n, n) :: X

      logical, intent(in), optional :: transpose_left

      complex(dp), dimension(:, :), allocatable :: tmp

      call mem%alloc(tmp, n, n)

      if (transpose_left) then  ! Transpose the left factor, X <- A^T X B

         call zgemm('N', &
                    'N', &
                    n, &
                    n, &
                    n, &
                    one_complex, &
                    X, &
                    n, &
                    B, &
                    n, &
                    zero_complex, &
                    tmp, &  ! tmp = X B
                    n)

         call zgemm('T', &
                    'N', &
                    n, &
                    n, &
                    n, &
                    one_complex, &
                    A, &
                    n, &
                    tmp, &
                    n, &
                    zero_complex, &
                    X, &  ! X = A^T tmp = A^T X B
                    n)

      else  ! Transpose the right factor, X <- A X B^T

         call zgemm('N', &
                    'T', &
                    n, &
                    n, &
                    n, &
                    one_complex, &
                    X, &
                    n, &
                    B, &
                    n, &
                    zero_complex, &
                    tmp, &  ! tmp = X B^T
                    n)

         call zgemm('N', &
                    'N', &
                    n, &
                    n, &
                    n, &
                    one_complex, &
                    A, &
                    n, &
                    tmp, &
                    n, &
                    zero_complex, &
                    X, &  ! X = A tmp = A X B^T
                    n)

      end if

      call mem%dealloc(tmp)

   end subroutine sandwich_complex


   subroutine symmetric_sandwich(Xr, X, A, m, n)
      !!
      !! Written by Eirik F. Kjoenstad, 2018
      !!
      !! Constructs the similary transformed matrix X_r
      !!
      !!    Xr = A^T X A
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: m, n

      real(dp), dimension(m, n), intent(in) :: A

      real(dp), dimension(m, m) :: X
      real(dp), dimension(n, n) :: Xr

      real(dp), dimension(:, :), allocatable :: tmp

      call mem%alloc(tmp, m, n)

      call dgemm('N', &
                 'N', &
                 m, &
                 n, &
                 m, &
                 one, &
                 X, &
                 m, &
                 A, &
                 m, &
                 zero, &
                 tmp, &  ! tmp = X A
                 m)

      call dgemm('T', &
                 'N', &
                 n, &
                 n, &
                 m, &
                 one, &
                 A, &
                 m, &
                 tmp, &
                 m, &
                 zero, &
                 Xr, &  ! X = A^T tmp = A^T X B
                 n)

      call mem%dealloc(tmp)

   end subroutine symmetric_sandwich


   subroutine symmetric_sandwich_replace(X, A, m)
      !!
      !! Written by Eirik F. Kjoenstad, 2018
      !!
      !! Constructs the similary transformed matrix X
      !!
      !!    X = A^T X A
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: m

      real(dp), dimension(m, m), intent(in) :: A

      real(dp), dimension(m, m) :: X

      real(dp), dimension(:, :), allocatable :: tmp

      call mem%alloc(tmp, m, m)

      call dgemm('N', &
                 'N', &
                 m, &
                 m, &
                 m, &
                 one, &
                 X, &
                 m, &
                 A, &
                 m, &
                 zero, &
                 tmp, &  ! tmp = X A
                 m)

      call dgemm('T', &
                 'N', &
                 m, &
                 m, &
                 m, &
                 one, &
                 A, &
                 m, &
                 tmp, &
                 m, &
                 zero, &
                 X, &  ! X = A^T tmp = A^T X B
                 m)

      call mem%dealloc(tmp)

   end subroutine symmetric_sandwich_replace


   subroutine symmetric_sandwich_right_transposition_real(Xr, X, A, m, n)
      !!
      !! Written by Eirik F. Kjoenstad, 2018
      !!
      !! Constructs the similarity transformation
      !! wrt the matrix A^T
      !!
      !!    Xr = A X A^T
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: m, n

      real(dp), dimension(m, n), intent(in) :: A
      real(dp), dimension(n, n), intent(in) :: X
      real(dp), dimension(m, m), intent(out) :: Xr

      real(dp), dimension(:, :), allocatable :: tmp

      call mem%alloc(tmp, n, m)

      call dgemm('N', &
                 'T', &
                 n, &
                 m, &
                 n, &
                 one, &
                 X, &
                 n, &
                 A, &
                 m, &
                 zero, &
                 tmp, &  ! tmp = X A^T
                 n)

      call dgemm('N', &
                 'N', &
                 m, &
                 m, &
                 n, &
                 one, &
                 A, &
                 m, &
                 tmp, &
                 n, &
                 zero, &
                 Xr, &  ! X = A tmp = A X A^T
                 m)

      call mem%dealloc(tmp)

   end subroutine symmetric_sandwich_right_transposition_real


   subroutine symmetric_sandwich_right_transposition_complex_between_real(Xr, X, A, m, n)
      !!
      !! Written by Eirik F. Kjoenstad, 2018
      !!
      !! Constructs the similarity transformation
      !! wrt the matrix A^T
      !!
      !!    Xr = A X A^T
      !!
      !! Modified by Andreas S. Skeidsvoll, Jul 2020
      !! To be used with real A and complex X matrices.
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: m, n

      real(dp), dimension(m, n), intent(in) :: A
      complex(dp), dimension(n, n), intent(in) :: X
      complex(dp), dimension(m, m), intent(out) :: Xr

      complex(dp), dimension(:, :), allocatable :: tmp

      call mem%alloc(tmp, n, m)

      call zgemm('N', &
                 'T', &
                 n, &
                 m, &
                 n, &
                 one_complex, &
                 X, &
                 n, &
                 cmplx(A, zero, dp), &
                 m, &
                 zero_complex, &
                 tmp, &  ! tmp = X A^T
                 n)

      call zgemm('N', &
                 'N', &
                 m, &
                 m, &
                 n, &
                 one_complex, &
                 cmplx(A, zero, dp), &
                 m, &
                 tmp, &
                 n, &
                 zero_complex, &
                 Xr, &  ! X = A tmp = A X A^T
                 m)

      call mem%dealloc(tmp)

   end subroutine symmetric_sandwich_right_transposition_complex_between_real


   subroutine symmetric_sandwich_right_transposition_replace(X, A, m)
      !!
      !! Written by Eirik F. Kjoenstad, 2018
      !!
      !! Overwrites the n-by-n matrix X with a sandwich-ed X:
      !!
      !!    X <- A X A^T
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: m

      real(dp), dimension(m, m), intent(in) :: A

      real(dp), dimension(m, m), intent(inout) :: X

      real(dp), dimension(:, :), allocatable :: tmp

      call mem%alloc(tmp, m, m)

      call dgemm('N', &
                 'T', &
                 m, &
                 m, &
                 m, &
                 one, &
                 X, &
                 m, &
                 A, &
                 m, &
                 zero, &
                 tmp, &  ! tmp = X A^T
                 m)

      call dgemm('N', &
                 'N', &
                 m, &
                 m, &
                 m, &
                 one, &
                 A, &
                 m, &
                 tmp, &
                 m, &
                 zero, &
                 X, &  ! X = A tmp = A X A^T
                 m)

      call mem%dealloc(tmp)

   end subroutine symmetric_sandwich_right_transposition_replace


   subroutine l2_normalize(X, n)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Returns the L^2 normalized vector
      !!
      implicit none

      integer, intent(in) :: n

      real(dp), dimension(n), intent(inout) :: X

      real(dp) :: norm

      norm = get_l2_norm(X, n)
      call dscal(n, one / norm, X, 1)

   end subroutine l2_normalize


   real(dp) function get_l2_norm(X, n)
      !!
      !! Get L^2 norm
      !! Written by Eirik F. Kjoenstad, Aug 2018
      !!
      !! Returns the L^2 norm of the real n-dimensional vector X:
      !!
      !!    sqrt( sum_i=1^n X_i^2 )
      !!
      implicit none

      integer, intent(in) :: n

      real(dp), dimension(n), intent(in) :: X

      real(dp) :: ddot

      get_l2_norm = sqrt(ddot(n, X, 1, X, 1))

   end function get_l2_norm


   real(dp) function get_l2_norm_complex(X, n)
      !!
      !! Get L^2 norm
      !! Written by Eirik F. Kjoenstad, Andreas S. Skeidsvoll, 2018-2022
      !!
      !! Returns the L^2 norm of the complex n-dimensional vector X:
      !!
      !!    sqrt( sum_i=1^n |X_i|^2 )
      !!
      implicit none

      integer, intent(in) :: n

      complex(dp), dimension(n), intent(in) :: X

      get_l2_norm_complex = sqrt(real(zdotc_(n, X, 1, X, 1), dp))

   end function get_l2_norm_complex


   function get_root_mean_square(X, n) result(rms)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! Get root-mean-square, RMS = sqrt(X^T X / n)
      !!
      implicit none

      integer, intent(in) :: n
      real(dp), dimension(n), intent(in) :: X

      real(dp) :: ddot, rms

      rms = ddot(n, X, 1, X, 1) / real(n, kind=dp)

      rms = sqrt(rms)

   end function get_root_mean_square


   subroutine transpose_with_copy(A, A_trans, dim_)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Sep 2018
      !!
      !! Saves the transpose of A in A_trans. The matrices are assumed to
      !! be dim_ x dim_.
      !!
      implicit none

      integer :: dim_, n, m

      real(dp), dimension(dim_, dim_), intent(in) :: A
      real(dp), dimension(dim_, dim_), intent(out) :: A_trans

      !$omp parallel do private(m, n) shared(A, A_trans)
      do m = 1, dim_
         do n = 1, dim_

            A_trans(n, m) = A(m, n)

         end do
      end do
      !$omp end parallel do

   end subroutine transpose_with_copy


   subroutine transpose_in_place(A, dim_)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Sep 2018
      !!
      !! Saves the transpose of A in A. The matrices are assumed to
      !! be dim_ x dim_.
      !!
      implicit none

      integer :: dim_, n, m

      real(dp), dimension(dim_, dim_), intent(inout) :: A

      real(dp) :: element_mn

      !$omp parallel do private(m, n, element_mn) shared(A)
      do m = 1, dim_
         do n = 1, m - 1

            element_mn = A(m, n)
            A(m, n) = A(n, m)
            A(n, m) = element_mn

         end do
      end do
      !$omp end parallel do

   end subroutine transpose_in_place


   subroutine get_n_lowest(n, size, vec, sorted_short_vec, index_list)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, May 2017
      !!
      !! Finds the n lowest values of "vec" (of length "size"), sorts them, and returns them
      !! in "sorted_short_vec", together with an index list (of length "n") refering to the
      !! indices of the lowest elements in the original vector "vec".
      !!
      implicit none

      integer :: n  ! Number of elements wanted
      integer :: size  ! Size of original vector

      real(dp), dimension(size) :: vec
      real(dp), dimension(n) :: sorted_short_vec

      integer, dimension(n) :: index_list

      ! Variables for sorting

      real(dp) :: max
      integer :: max_pos

      real(dp) :: swap = zero
      integer :: swap_int = 0

      integer :: i = 0, j = 0

      ! Placing the n first elements of vec into sorted_short_vec

      sorted_short_vec(1) = vec(1)
      index_list(1) = 1

      max = sorted_short_vec(1)
      max_pos = 1

      do i = 2, n

         sorted_short_vec(i) = vec(i)
         index_list(i) = i

         if (sorted_short_vec(i) >= max) then

            max = sorted_short_vec(i)
            max_pos = i

         end if
      end do

      ! Looping through the rest of vec to find lowest values

      do i = n + 1, size
         if (vec(i) < max) then

            sorted_short_vec(max_pos) = vec(i)
            index_list(max_pos) = i
            max = vec(i)

            do j = 1, n
               if (sorted_short_vec(j) > max) then

                  max = sorted_short_vec(j)
                  max_pos = j

               end if
            end do
         end if
      end do

      ! Sorting sorted_short_vec

      do i = 1, n
         do j = 1, n - 1
            if (sorted_short_vec(j) > sorted_short_vec(j + 1)) then

               swap = sorted_short_vec(j)
               sorted_short_vec(j) = sorted_short_vec(j + 1)
               sorted_short_vec(j + 1) = swap

               swap_int = index_list(j)
               index_list(j) = index_list(j + 1)
               index_list(j + 1) = swap_int

            end if
         end do
      end do

   end subroutine get_n_lowest


   subroutine get_n_highest(n, size, vec, sorted_short_vec, index_list)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, May 2017
      !!
      !! Finds the n highest values of "vec" (of length "size"), sorts them, and returns them
      !! in "sorted_short_vec", together with an index list (of length "n") refering to the
      !! indices of the lowest elements in the original vector "vec".
      !!
      implicit none

      integer :: n  ! Number of elements wanted
      integer :: size  ! Size of original vector

      real(dp), dimension(size) :: vec
      real(dp), dimension(n) :: sorted_short_vec

      integer, dimension(n) :: index_list

      ! Variables for sorting

      real(dp) :: min
      integer :: min_pos

      real(dp) :: swap = zero
      integer :: swap_int = 0

      integer :: i = 0, j = 0

      ! Placing the n first elements of vec into sorted_short_vec

      sorted_short_vec = zero
      sorted_short_vec(1) = vec(1)
      index_list(1) = 1

      min = sorted_short_vec(1)
      min_pos = 1

      do i = 2, n

         sorted_short_vec(i) = vec(i)
         index_list(i) = i

         if (sorted_short_vec(i) <= min) then

            min = sorted_short_vec(i)
            min_pos = i

         end if
      end do

      ! Looping through the rest of vec to find lowest values

      do i = n + 1, size
         if (vec(i) > min) then

            sorted_short_vec(min_pos) = vec(i)
            index_list(min_pos) = i
            min = vec(i)

            do j = 1, n
               if (sorted_short_vec(j) < min) then

                  min = sorted_short_vec(j)
                  min_pos = j

               end if
            end do
         end if
      end do

      ! Sorting sorted_short_vec

      do i = 1, n
         do j = 1, n - 1
            if (sorted_short_vec(j) < sorted_short_vec(j + 1)) then

               swap = sorted_short_vec(j)
               sorted_short_vec(j) = sorted_short_vec(j + 1)
               sorted_short_vec(j + 1) = swap

               swap_int = index_list(j)
               index_list(j) = index_list(j + 1)
               index_list(j + 1) = swap_int

            end if
         end do
      end do

   end subroutine get_n_highest


   recursive subroutine quicksort_recursive_int(vec, first, last)
      !!
      !! Recursive implementation of quicksort (descending order)
      !!
      !! Adapted from quicksort.f by "t-nissie" (https://gist.github.com/t-nissie/479f0f16966925fa29ea)
      !! licensed under GPLv3.
      !!
      !! Modified by Sarai D. Folkestad, 6. Aug. 2018
      !!
      !! - Variable x renamed to pivot
      !! - Variable t renamed to temp
      !! - Added index_list
      !!
      !! Modified by Andreas Skeidsvoll, 26. Feb. 2019
      !!
      !! - Type real*8 changed to integer
      !!
      !  quicksort.f -*-f90-*-
      !  Author: t-nissie
      !  License: GPLv3
      !  Gist: https://gist.github.com/t-nissie/479f0f16966925fa29ea

      implicit none

      integer, dimension(:), intent(inout) :: vec
      integer, intent(in) :: first, last

      integer :: pivot, temp
      integer :: i, j

      pivot = vec((first + last) / 2)

      i = first
      j = last

      do

         do while (vec(i) > pivot)

            i = i + 1

         end do

         do while (pivot > vec(j))

            j = j - 1

         end do

         if (i >= j) exit

         temp = vec(i)
         vec(i) = vec(j)
         vec(j) = temp

         i = i + 1
         j = j - 1

      end do

      if (first < i - 1) call quicksort_recursive_int(vec, first, i - 1)
      if (j + 1 < last) call quicksort_recursive_int(vec, j + 1, last)

   end subroutine quicksort_recursive_int


   recursive subroutine quicksort_recursive(vec, first, last)
      !!
      !! Recursive implementation of quicksort (descending order)
      !!
      !! Adapted from quicksort.f by "t-nissie" (https://gist.github.com/t-nissie/479f0f16966925fa29ea)
      !! licensed under GPLv3.
      !!
      !! Modified by Sarai D. Folkestad, 6. Aug. 2018
      !!
      !! - Type real*8 changed to real(dp)
      !! - Variable x renamed to pivot
      !! - Variable t renamed to temp
      !!
      !  quicksort.f -*-f90-*-
      !  Author: t-nissie
      !  License: GPLv3
      !  Gist: https://gist.github.com/t-nissie/479f0f16966925fa29ea

      implicit none

      real(dp), dimension(:), intent(inout) :: vec
      integer, intent(in) :: first, last

      real(dp) :: pivot, temp
      integer :: i, j

      pivot = vec((first + last) / 2)

      i = first
      j = last

      do

         do while (vec(i) > pivot)

            i = i + 1

         end do

         do while (pivot > vec(j))

            j = j - 1

         end do

         if (i >= j) exit

         temp = vec(i)
         vec(i) = vec(j)
         vec(j) = temp

         i = i + 1
         j = j - 1

      end do

      if (first < i - 1) call quicksort_recursive(vec, first, i - 1)
      if (j + 1 < last) call quicksort_recursive(vec, j + 1, last)

   end subroutine quicksort_recursive


   recursive subroutine quicksort_with_index_recursive(vec, index_list, first, last)
      !!
      !! Recursive implementation of quicksort with index list (descending order)
      !!
      !! Adapted from quicksort.f by "t-nissie" (https://gist.github.com/t-nissie/479f0f16966925fa29ea)
      !! licensed under GPLv3.
      !!
      !! "index_list" : integer array which stores the original index of ordered elements
      !!                e.g., in index_list(1) is the original index of the largest element
      !!
      !!
      !! Modified by Sarai D. Folkestad, 11. Nov. 2018
      !!
      !! - Type real*8 changed to real(dp)
      !! - Variable x renamed to pivot
      !! - Variable t renamed to temp
      !! - Added index_list
      !!
      !  quicksort.f -*-f90-*-
      !  Author: t-nissie
      !  License: GPLv3
      !  Gist: https://gist.github.com/t-nissie/479f0f16966925fa29ea

      implicit none

      real(dp), dimension(:), intent(inout) :: vec
      integer, dimension(:), intent(inout) :: index_list
      integer, intent(in) :: first, last

      real(dp) :: pivot, temp
      integer :: temp_index
      integer :: i, j

      pivot = vec((first + last) / 2)

      i = first
      j = last

      do

         do while (vec(i) > pivot)

            i = i + 1

         end do

         do while (pivot > vec(j))

            j = j - 1

         end do

         if (i >= j) exit

         temp = vec(i)
         temp_index = index_list(i)

         vec(i) = vec(j)
         vec(j) = temp

         index_list(i) = index_list(j)
         index_list(j) = temp_index

         i = i + 1
         j = j - 1

      end do

      if (first < i - 1) call quicksort_with_index_recursive(vec, index_list, first, i - 1)
      if (j + 1 < last) call quicksort_with_index_recursive(vec, index_list, j + 1, last)

   end subroutine quicksort_with_index_recursive


   subroutine quicksort_with_index_descending(vec, index_list, dim_)
      !!
      !!
      implicit none

      integer, intent(in) :: dim_
      real(dp), dimension(dim_), intent(inout) :: vec
      integer, dimension(dim_), intent(out) :: index_list

      integer :: i

      do i = 1, dim_
         index_list(i) = i
      end do

      call quicksort_with_index_recursive(vec, index_list, 1, dim_)

   end subroutine quicksort_with_index_descending


   subroutine quicksort_with_index_ascending(vec, index_list, dim_)
      !!
      !!
      implicit none

      integer, intent(in) :: dim_
      real(dp), dimension(dim_), intent(inout) :: vec
      integer, dimension(dim_), intent(out) :: index_list

      call dscal(dim_, - one, vec, 1)

      call quicksort_with_index_descending(vec, index_list, dim_)

      call dscal(dim_, - one, vec, 1)

   end subroutine quicksort_with_index_ascending


   recursive subroutine quicksort_with_index_recursive_int(vec, index_list, first, last)
      !!
      !! Recursive implementation of quicksort with index list (descending order)
      !!
      !! Adapted from quicksort.f by "t-nissie" (https://gist.github.com/t-nissie/479f0f16966925fa29ea)
      !! licensed under GPLv3.
      !!
      !! "index_list" : integer array which stores the original index of ordered elements
      !!                e.g., in index_list(1) is the original index of the largest element
      !!
      !!
      !! Modified by Sarai D. Folkestad, 11. Nov. 2018
      !!
      !! - Variable x renamed to pivot
      !! - Variable t renamed to temp
      !! - Added index_list
      !!
      !! Modified by Andreas Skeidsvoll, 26. Feb. 2019
      !!
      !! - Type real*8 changed to integer
      !!
      !  quicksort.f -*-f90-*-
      !  Author: t-nissie
      !  License: GPLv3
      !  Gist: https://gist.github.com/t-nissie/479f0f16966925fa29ea

      implicit none

      integer, dimension(:), intent(inout) :: vec
      integer, dimension(:), intent(inout) :: index_list
      integer, intent(in) :: first, last

      integer :: pivot, temp
      integer :: temp_index
      integer :: i, j

      pivot = vec((first + last) / 2)

      i = first
      j = last

      do

         do while (vec(i) > pivot)

            i = i + 1

         end do

         do while (pivot > vec(j))

            j = j - 1

         end do

         if (i >= j) exit

         temp = vec(i)
         temp_index = index_list(i)

         vec(i) = vec(j)
         vec(j) = temp

         index_list(i) = index_list(j)
         index_list(j) = temp_index

         i = i + 1
         j = j - 1

      end do

      if (first < i - 1) call quicksort_with_index_recursive_int(vec, index_list, first, i - 1)
      if (j + 1 < last) call quicksort_with_index_recursive_int(vec, index_list, j + 1, last)

   end subroutine quicksort_with_index_recursive_int


   subroutine quicksort_descending_int(vec, dim_)
      !!
      !!
      implicit none

      integer, intent(in) :: dim_
      integer, dimension(dim_), intent(inout) :: vec

      call quicksort_recursive_int(vec, 1, dim_)

   end subroutine quicksort_descending_int


   subroutine quicksort_ascending_int(vec, dim_)
      !!
      !!
      implicit none

      integer, intent(in) :: dim_
      integer, dimension(dim_), intent(inout) :: vec

      vec = - 1 * vec

      call quicksort_recursive_int(vec, 1, dim_)

      vec = - 1 * vec

   end subroutine quicksort_ascending_int


   subroutine quicksort_with_index_descending_int(vec, index_list, dim_)
      !!
      !!
      implicit none

      integer, intent(in) :: dim_
      integer, dimension(dim_), intent(inout) :: vec
      integer, dimension(dim_), intent(inout) :: index_list

      integer :: i

      do i = 1, dim_
         index_list(i) = i
      end do

      call quicksort_with_index_recursive_int(vec, index_list, 1, dim_)

   end subroutine quicksort_with_index_descending_int


   subroutine quicksort_with_index_ascending_int(vec, index_list, dim_)
      !!
      !!
      implicit none

      integer, intent(in) :: dim_
      integer, dimension(dim_), intent(inout) :: vec
      integer, dimension(dim_), intent(inout) :: index_list

      vec = - 1 * vec

      call quicksort_with_index_descending_int(vec, index_list, dim_)

      vec = - 1 * vec

   end subroutine quicksort_with_index_ascending_int


   function count_n_true(dim_, logical_list) result(n_true)
      !!
      !! Written by Sarai D. Folkestad, Oct 2018
      !!
      !! Counts the number of .true.
      !! in the list of logicals ('logical_list')
      !! with dimension 'dim_'
      !!
      implicit none

      integer, intent(in) :: dim_
      logical, dimension(dim_), intent(in) :: logical_list

      integer :: n_true

      integer :: I

      n_true = 0

      do I = 1, dim_

         if (logical_list(I)) n_true = n_true + 1

      end do

   end function count_n_true


   subroutine extract_columns(n, m, A, keep)
      !!
      !! Written by Sarai D. Folkestad, Oct 2019
      !!
      implicit none

      integer, intent(in) :: n, m

      real(dp), dimension(n, m), intent(inout) :: A
      logical, dimension(m), intent(in) :: keep

      integer :: i, j

      j = 1
      do i = 1, m

         if (keep(i)) then

            if (i > j) call dcopy(n, A(:, i), 1, A(:, j), 1)
            j = j + 1

         end if

      end do


   end subroutine extract_columns


   subroutine extract_columns_of_matrix(n_extract, n_rows, n_columns, M, M_extracted, extract)
      !!
      !! Written by Ida-Marie Hoeyvik and Sarai D. Folkestad, Oct 2019
      !!
      !! Extracts columns of a matrix, based on the logical list
      !! 'extract' where extract(I)=.true. defines the instruction
      !! to extract. The number of elements to extract
      !! 'n_extract' must already be determined and passed to the routine.
      !!
      implicit none

      integer, intent(in) :: n_extract, n_rows, n_columns

      real(dp), dimension(n_rows, n_columns), intent(in) :: M
      real(dp), dimension(n_rows, n_extract), intent(out) :: M_extracted
      logical, dimension(n_columns), intent(in) :: extract

      integer :: counter, I

      if (n_extract > n_columns) &
         call output%error_msg('Cannot extract more columns than the original matrix contains: ' // &
            'mismatch beween n_extract and number of true in the extract list')

      counter = 0

      do I = 1, n_columns

         if (extract(I)) then

            counter = counter + 1

            if (counter > n_extract) call output%error_msg('Tried to extract non-existent column from matrix')

            call dcopy(n_rows, M(1, I), 1, M_extracted(1, counter), 1)

         end if

      end do

   end subroutine extract_columns_of_matrix


   function are_vectors_parallel(x, y, dim_, threshold) result(parallel)
      !!
      !! Written by Alexander C. Paul and Rolf H. Myhre, Oct 2019
      !!
      !! Checks if 2 vectors are parallel within a given threshold.
      !! For 2 parallel vectors x and y = a*x
      !!       sqrt(x*x * y*y) = |x*y|
      !!
      implicit none

      logical :: parallel

      integer, intent(in) :: dim_

      real(dp), dimension(dim_), intent(in) :: x, y

      real(dp), intent(in) :: threshold

      real(dp) :: ddot, x_dot_x, y_dot_y, x_dot_y

      x_dot_x = ddot(dim_, x, 1, x, 1)

      y_dot_y = ddot(dim_, y, 1, y, 1)

      x_dot_y = ddot(dim_, x, 1, y, 1)

      if (abs(sqrt(x_dot_x * y_dot_y) - abs(x_dot_y)) > threshold) then

         parallel = .false.

      else

         parallel = .true.

      end if

   end function are_vectors_parallel


   subroutine check_for_parallel_vectors(vectors, &
                                         dim_, &
                                         n_vectors, &
                                         n_non_parallel_vectors, &
                                         threshold, &
                                         parallel)
      !!
      !! written by Alexander Paul, Oct 2019
      !!
      !! Checks for parallel vectors in a given array of vectors
      !! returns the number of not parallel vectors and which vectors parallel
      !!
      !! vectors:  array of vectors to be checked
      !! parallel: parallel(p) will be true on out if vector p is parallel to a
      !!           previous vector for example, if there are three vectors and they
      !!           are all parallel, parallel will be [.false., .true., .true.] on output
      !!
      implicit none

      integer, intent(in) :: n_vectors
      integer, intent(out) :: n_non_parallel_vectors

      integer, intent(in) :: dim_

      real(dp), dimension(dim_, n_vectors), intent(in) :: vectors

      real(dp), intent(in) :: threshold

      logical, dimension(n_vectors), intent(out), optional :: parallel

      logical, dimension(n_vectors) :: parallel_temp

      integer :: p, q

      n_non_parallel_vectors = n_vectors

      do p = 1, n_vectors

         parallel_temp(p) = .false.

         do q = 1, p - 1

            ! Skip if the vector q was already parallel to another p

            if (parallel_temp(q)) cycle

            if (are_vectors_parallel(vectors(:, p), vectors(:, q), dim_, threshold)) then

               parallel_temp(p) = .true.

               n_non_parallel_vectors = n_non_parallel_vectors - 1

            end if

         end do
      end do

      if (present(parallel)) then
         parallel = parallel_temp
      end if

   end subroutine check_for_parallel_vectors


   subroutine scale_real_diagonal_by_real(alpha, X, dim_)
      !!
      !! Written by Anders Hutcheson, Oct 2019
      !!
      !! X is of dimension dim_^2 and we scale every
      !! dim_+1 element(diagonal) by alpha,
      !! because we only scale the diagonal elements
      !! the first argument is dim_
      !!

      implicit none

      real(dp), intent(in) :: alpha

      integer, intent(in) :: dim_

      real(dp), dimension(dim_, dim_), intent(inout) :: X

      call dscal(dim_, alpha, X, dim_ + 1)

   end subroutine scale_real_diagonal_by_real


   subroutine scale_real_4_diagonal_by_real(alpha, X, dim_)
      !!
      !! Written by Anders Hutcheson, Oct 2019
      !!
      !! The matrix has to have the following dimensions,
      !! X(dim_1,dim_2,dim_1,dim_2) and
      !! dim_ is then given by dim_1*dim_2
      !!
      implicit none

      real(dp), intent(in) :: alpha

      real(dp), dimension(:, :, :, :), intent(inout) :: X

      integer, intent(in) :: dim_

      call scale_real_diagonal_by_real(alpha, X, dim_)

   end subroutine scale_real_4_diagonal_by_real


   subroutine scale_real_4_diagonal_by_real_1324(alpha, X, dim_p, dim_q)
      !!
      !! Written by Anders Hutcheson, Oct 2019
      !!
      !! The matrix has to have the following dimensions,
      !! X(dim_p, dim_p, dim_q, dim_q)
      !!
      implicit none

      real(dp), intent(in) :: alpha

      integer, intent(in) :: dim_p, dim_q

      real(dp), dimension(dim_p, dim_p, dim_q, dim_q), intent(inout) :: X

      integer :: p, q

      !$omp parallel do schedule(static) private(p, q)
      do q = 1, dim_q
         do p = 1, dim_p

            X(p, p, q, q) = alpha * X(p, p, q, q)

         end do
      end do
      !$omp end parallel do

   end subroutine scale_real_4_diagonal_by_real_1324


   subroutine scale_complex_4_diagonal_by_real_1324(alpha, X, dim_p, dim_q)
      !!
      !! Written by Anders Hutcheson, Oct 2019
      !!
      !! The matrix has to have the following dimensions,
      !! X(dim_p, dim_p, dim_q, dim_q)
      !!
      implicit none

      real(dp), intent(in) :: alpha

      integer, intent(in) :: dim_p, dim_q

      complex(dp), dimension(dim_p, dim_p, dim_q, dim_q), intent(inout) :: X

      integer :: p, q

      !$omp parallel do schedule(static) private(p, q)
      do q = 1, dim_q
         do p = 1, dim_p

            X(p, p, q, q) = alpha * X(p, p, q, q)

         end do
      end do
      !$omp end parallel do

   end subroutine scale_complex_4_diagonal_by_real_1324


   subroutine scale_complex_4_diagonal_by_complex_1324(alpha, X, dim_p, dim_q)
      !!
      !! Written by Anders Hutcheson, Oct 2019
      !!
      !! The matrix has to have the following dimensions,
      !! X(dim_p, dim_p, dim_q, dim_q)
      !!
      implicit none

      complex(dp), intent(in) :: alpha

      integer, intent(in) :: dim_p, dim_q

      complex(dp), dimension(dim_p, dim_p, dim_q, dim_q), intent(inout) :: X

      integer :: p, q

      !$omp parallel do schedule(static) private(p, q)
      do q = 1, dim_q
         do p = 1, dim_p

            X(p, p, q, q) = alpha * X(p, p, q, q)

         end do
      end do
      !$omp end parallel do

   end subroutine scale_complex_4_diagonal_by_complex_1324


   subroutine scale_real_packed_4_diagonal_by_real(alpha, X, dim_pq)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2019
      !!
      !! Scales the diagonal of a real packed 4-dimensional matrix by a real scalar alpha. The
      !! unpacked matrix is symmetric under the exchange of the two first and last dimensions, and has
      !! been packed as
      !!
      !! X(dim_p, dim_q, dim_p, dim_q) -> X(dim_pq*(dim_pq+1)/2)
      !!
      !! where dim_pq = dim_p*dim_q
      !!
      implicit none

      real(dp), intent(in) :: alpha

      integer :: dim_pq

      real(dp), dimension(dim_pq * (dim_pq + 1) / 2), intent(inout) :: X

      integer :: pq, pqpq

      !$omp parallel do private(pq,pqpq)
      do pq = 1, dim_pq

         pqpq = pq * (pq + 1) / 2

         X(pqpq) = alpha * X(pqpq)

      end do
      !$omp end parallel do

   end subroutine scale_real_packed_4_diagonal_by_real


   subroutine scale_complex_packed_4_diagonal_by_real(alpha, X, dim_pq)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2019
      !!
      !! Scales the diagonal of a complex packed 4-dimensional matrix by a real scalar alpha. The
      !! unpacked matrix is symmetric under the exchange of the two first and last dimensions, and has
      !! been packed as
      !!
      !! X(dim_p, dim_q, dim_p, dim_q) -> X(dim_pq*(dim_pq+1)/2)
      !!
      !! where dim_pq = dim_p*dim_q
      !!
      implicit none

      real(dp), intent(in) :: alpha

      integer :: dim_pq

      complex(dp), dimension(dim_pq * (dim_pq + 1) / 2), intent(inout) :: X

      integer :: pq, pqpq

      complex(dp) :: alpha_complex

      alpha_complex = cmplx(alpha, zero, dp)

      !$omp parallel do private(pq,pqpq)
      do pq = 1, dim_pq

         pqpq = pq * (pq + 1) / 2

         X(pqpq) = alpha_complex * X(pqpq)

      end do
      !$omp end parallel do

   end subroutine scale_complex_packed_4_diagonal_by_real


   subroutine scale_complex_packed_4_diagonal_by_complex(alpha, X, dim_pq)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2019
      !!
      !! Scales the diagonal of a complex packed 4-dimensional matrix by a complex scalar alpha. The
      !! unpacked matrix is symmetric under the exchange of the two first and last dimensions, and has
      !! been packed as
      !!
      !! X(dim_p, dim_q, dim_p, dim_q) -> X(dim_pq*(dim_pq+1)/2)
      !!
      !! where dim_pq = dim_p*dim_q
      !!
      implicit none

      complex(dp), intent(in) :: alpha

      integer :: dim_pq

      complex(dp), dimension(dim_pq * (dim_pq + 1) / 2), intent(inout) :: X

      integer :: pq, pqpq

      !$omp parallel do private(pq,pqpq)
      do pq = 1, dim_pq

         pqpq = pq * (pq + 1) / 2

         X(pqpq) = alpha * X(pqpq)

      end do
      !$omp end parallel do

   end subroutine scale_complex_packed_4_diagonal_by_complex


   function zdotu_(n, zx, incx, zy, incy) result(dot)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2019
      !!
      !! A custom zdotu routine, to make zdotu work on Macs
      !!
      implicit none

      integer :: incx, incy, n

      complex(dp) :: zx(*), zy(*)
      complex(dp) :: dot

      integer :: i

      if ((incx /= 0) .and. (incy /= 0)) continue

      dot = zero_complex

      !$omp parallel do schedule(static) private(i) reduction(+:dot)
      do i = 1, n

         dot = dot + zx(i) * zy(i)

      end do
      !$omp end parallel do

   end function zdotu_


   function zdotc_(n, zx, incx, zy, incy) result(dot)
      !!
      !! Written by Andreas Skeidsvoll, Jan 2023
      !!
      !! A custom zdotc routine, to make zdotc work on Macs
      !!
      implicit none

      integer :: incx, incy, n

      complex(dp) :: zx(*), zy(*)
      complex(dp) :: dot

      integer :: i

      if ((incx /= 0) .and. (incy /= 0)) continue

      dot = zero_complex

      !$omp parallel do schedule(static) private(i) reduction(+:dot)
      do i = 1, n

         dot = dot + conjg(zx(i)) * zy(i)

      end do
      !$omp end parallel do

   end function zdotc_


   subroutine block_diagonalize_symmetric(A, n_total, n_blocks, block_dim, diagonal, flip_vectors)
      !!
      !! Written by Sarai D. Folkestad, Mar 2020
      !!
      !! Block diagonalizes the symmetric matrix A (an n_total x n_total matrix)
      !!
      !! n_blocks : The number of blocks
      !!
      !! block_dim : array of dimensions for the blocks
      !!             Elements sum up to n_total
      !!
      !! doagonal : Contains the diagonal elements of the
      !!            matrix A after block diagonalization
      !!
      !! This routine uses the convention that eigenvectors are flipped
      !! such that the largest element of the eigenvectors are positive.
      !!
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: n_total, n_blocks
      integer, dimension(n_blocks), intent(in) :: block_dim

      real(dp), dimension(n_total, n_total), intent(inout) :: A
      real(dp), dimension(n_total), intent(out) :: diagonal

      logical, intent(in), optional :: flip_vectors

      real(dp), dimension(:), allocatable :: work

      real(dp), dimension(:), allocatable :: eigenvalues

      integer :: info, i, block_, offset, index_max, mu
      real(dp), dimension(1) :: worksize
      logical :: local_flip_vectors

      local_flip_vectors = .true.
      if (present(flip_vectors)) local_flip_vectors = flip_vectors

      offset = 1

      do block_ = 1, n_blocks

         if (block_dim(block_) > 0) then

            call mem%alloc(eigenvalues, block_dim(block_))

            ! Work size query

            call dsyev('V', &
                       'U', &
                       block_dim(block_), &
                       A(offset, offset), &
                       n_total, &
                       eigenvalues, &
                       worksize, &
                       - 1, &
                       info)

            if (info /= 0) call output%error_msg('could not perform DSYEV worksize query')

            ! Diagonalize block

            call mem%alloc(work, ceiling(worksize(1)))

            call dsyev('V', &
                       'U', &
                       block_dim(block_), &
                       A(offset, offset), &
                       n_total, &
                       eigenvalues, &
                       work, &
                       ceiling(worksize(1)), &
                       info)

            if (info /= 0) then

               call output%error_msg( &
                       'Diagonalization of block failed.' // ' "Dsyev" finished with info: (i0)', &
                       ints=[info] &
                    )

            end if

            call mem%dealloc(work)

            ! Convention for eigenvectors of block, maximum element is positive

            if (local_flip_vectors) then

               do i = offset, offset + block_dim(block_) - 1

                  index_max = maxloc(abs(A(offset:offset + block_dim(block_) - 1, i)), dim=1)
                  index_max = index_max + offset - 1

                  ! Two elements may be equally large due to symmetry
                  ! Make sure to pick the first element to avoid non-deterministic
                  ! outcome (maxloc might pick one or the other randomly)
                  do mu = offset, index_max - 1
                     if (abs(A(index_max, i)) - abs(A(mu, i)) < 1.0d-8) then

                        index_max = mu
                        exit

                     end if
                  end do

                  if (A(index_max, i) < zero) &
                     call dscal(block_dim(block_), - one, A(offset:offset + block_dim(block_) - 1, i), 1)

               end do

            end if

            ! Setting diagonal

            do i = 1, block_dim(block_)

               diagonal(i + offset - 1) = eigenvalues(i)

            end do

            call mem%dealloc(eigenvalues)

         elseif (block_dim(block_) < 0) then

            call output%error_msg('block diagonalization attempted with negative dimension.')

         end if

         offset = offset + block_dim(block_)

      end do

      if ((offset - 1) /= n_total) &
         call output%error_msg('dimensions do not add to n_total in block diagonalization')

   end subroutine block_diagonalize_symmetric


   subroutine gram_schmidt_biorthonormalization(L, R, dim_, n_vectors, threshold)
      !!
      !! Written by Alexander C. Paul, Oct 2019
      !!
      !! Routine to biorthonormalize two linear independent sets of vectors L and
      !! R following Kohaupt, L., Rocky Mountain J. Math., 44, 1265, (2014)
      !!
      !! NB: Order of the R vectors can change from input to output
      !!     The R vectors are ordered such that the corresponding L vector
      !!     with non-zero overlap are at the same position
      !!
      !! The p-th vector is determined in terms of the previously biorthogonalized
      !! vectors q
      !!
      !! Biorthogonal:  L'_p = L_p - sum_q < L_p, R"_q>  L"_q
      !! Biorthonormal: L"_p = < L'_p, R_p >^(-1)  L'_p = < L'_p, R"_p >^(-1)  L'_p
      !!
      !! Biorthonormal: R"_p = R_p - sum_q < R_p, L"_q >  R"_q
      !!
      !! Modified by Andreas S. Skeidsvoll, Nov 2020
      !! Biorthogonalization against previous vectors is now done irrespectively
      !! of the number of zero overlaps with the following vectors (unless all
      !! overlaps are zero).
      !!
      implicit none

      integer, intent(in) :: dim_, n_vectors
      real(dp), dimension(dim_, n_vectors), intent(inout) :: L, R
      real(dp), intent(in) :: threshold

      real(dp) :: overlap, max_overlap, temp

      integer :: p, q, index_max_overlap

      real(dp), external :: ddot

      do p = 1, n_vectors  ! looping through the left vectors

         ! :: Biorthogonalize left vector against previous right vectors ::
         ! ----------------------------------------------------------------

         do q = 1, p - 1

            ! Construct biorthogonal left vector:
            !    L'_p = L_p - sum_q < L_p, R"_q>  L"_q

            overlap = ddot(dim_, &
                           L(:, p), &
                           1, &
                           R(:, q), &
                           1)

            call daxpy(dim_, &
                       - overlap, &
                       L(:, q), &
                       1, &
                       L(:, p), &
                       1)

         end do

         ! Look for the right vector with the maximum overlap with L_p. Start at
         ! q = p, as the overlaps with the first (p-1) vectors are zero.

         index_max_overlap = p
         max_overlap = zero

         do q = p, n_vectors  ! right vectors

            overlap = ddot(dim_, &
                           L(:, p), &
                           1, &
                           R(:, q), &
                           1)

            if (abs(overlap) > abs(max_overlap)) then

               index_max_overlap = q
               max_overlap = overlap

            end if

         end do

         if (abs(max_overlap) < threshold) then

            call output%printf('m', &
                               'Overlaps between left vector with index (i0) and right vectors are less than&
                               & threshold: (e8.3).', &
                               reals=[threshold], &
                               ints=[p])

            call output%error_msg('Trying to binormalize nonoverlapping vectors.')

         end if

         ! :: Biorthonormalization ::
         ! --------------------------

         ! L"_p = < L'_p, R_p >^(-1)  L'_p

         call dscal(dim_, one / max_overlap, L(:, p), 1)

         do q = 1, p - 1

            ! Construct biorthonormal right vector:
            !    R"_p = R_p - sum_q < R_p, L"_q >  R"_q

            overlap = ddot(dim_, &
                           R(:, index_max_overlap), &
                           1, &
                           L(:, q), &
                           1)

            call daxpy(dim_, &
                       - overlap, &
                       R(:, q), &
                       1, &
                       R(:, index_max_overlap), &
                       1)

         end do

         ! Exchange R_p and R_index_max_overlap to achieve the correct ordering

         if (p /= index_max_overlap) then

            !$omp parallel do private(temp, q)
            do q = 1, dim_

               temp = R(q, p)
               R(q, p) = R(q, index_max_overlap)
               R(q, index_max_overlap) = temp

            end do
            !$omp end parallel do

         end if

      end do  ! Loop over p (left vectors)

   end subroutine gram_schmidt_biorthonormalization


   function get_trace(x, n) result(trace)
      !!
      !! Written by Alexander C. Paul, Apr 2020
      !!
      !! Computes trace of a quadratic (n x n) array x.
      !!
      implicit none

      integer, intent(in) :: n

      real(dp), dimension(n, n), intent(in) :: x

      real(dp) :: trace
      integer :: p

      trace = zero

      !$omp parallel do private(p) schedule(static) reduction(+:trace)
      do p = 1, n

         trace = trace + x(p, p)

      end do
      !$omp end parallel do

   end function get_trace


   subroutine diagonalize_symmetric(A, dim_, diagonal)
      !!
      !! Written by Sarai D. Folkestad, Jun 2020
      !!
      !! Diagonalizes the symmetric matrix A (an dim_ x dim_ matrix)
      !!
      !! diagonal : Contains the diagonal elements of the
      !!            matrix A after block diagonalization
      !!
      !! This routine uses the convention that eigenvectors are flipped
      !! such that the largest element of the eigenvectors are positive.
      !!
      !! This is a wrapper using the block_diagonalization routine
      !! which in turn uses the lapack dsyeev routine
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: dim_

      real(dp), dimension(dim_, dim_), intent(inout) :: A
      real(dp), dimension(dim_), intent(out), optional :: diagonal

      real(dp), dimension(:), allocatable :: eigenvalues


      if (present(diagonal)) then

         call block_diagonalize_symmetric(A, dim_, 1, [dim_], diagonal)

      else

         call mem%alloc(eigenvalues, dim_)
         call block_diagonalize_symmetric(A, dim_, 1, [dim_], eigenvalues)
         call mem%dealloc(eigenvalues)

      end if

   end subroutine diagonalize_symmetric


   subroutine generalized_diagonalization_symmetric(A, S, dim_, e, flip_vectors)
      !!
      !! Written by Sarai D. Folkestad,  2020
      !!
      !! Solves the linear equation
      !!
      !!    A X = S X e.
      !!
      !! On exit the vectors (X) are stored in A
      !! On exit S is overwritten
      !!
      !! This routine uses the convention that eigenvectors are flipped
      !! such that the largest element of the eigenvectors are positive.
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: dim_

      real(dp), dimension(dim_, dim_), intent(inout) :: A
      real(dp), dimension(dim_, dim_), intent(inout) :: S
      real(dp), dimension(dim_), intent(out), optional :: e
      logical, intent(in), optional :: flip_vectors

      real(dp), dimension(:), allocatable :: work, eigenvalues
      integer :: info, lwork, i, index_max
      logical :: local_flip_vectors

      local_flip_vectors = .true.
      if (present(flip_vectors)) local_flip_vectors = flip_vectors

      info = 0
      lwork = - 1

      ! Work space inquiry

      call mem%alloc(work, 1)
      call mem%alloc(eigenvalues, dim_)

      call dsygv(1, &
                 'V', &
                 'L', &
                 dim_, &
                 A, &
                 dim_, &
                 S, &
                 dim_, &
                 eigenvalues, &
                 work, &
                 lwork, &
                 info)

      lwork = ceiling(work(1))
      call mem%dealloc(work)

      ! Diagonalization

      call mem%alloc(work, lwork)

      call dsygv(1, &
                 'V', &
                 'L', &
                 dim_, &
                 A, &
                 dim_, &
                 S, &
                 dim_, &
                 eigenvalues, &
                 work, &
                 lwork, &
                 info)

      call mem%dealloc(work)

      if (info /= 0) call output%error_msg('in generalized_diagonalization_symmetric.')

      ! Convention for eigenvectors of block, maximum element is positive

      if (local_flip_vectors) then

         do i = 1, dim_

            index_max = maxloc(abs(A(:, i)), dim=1)

            if (A(index_max, i) < zero) call dscal(dim_, - one, A(:, i), 1)

         end do

      end if

      if (present(e)) call dcopy(dim_, eigenvalues, 1, e, 1)

      call mem%dealloc(eigenvalues)

   end subroutine generalized_diagonalization_symmetric


   subroutine generalized_diagonalization_asymmetric(A, &
                                                     S, &
                                                     dim_, &
                                                     eigenvalues_real, &
                                                     eigenvalues_imag, &
                                                     left_eigenvectors, &
                                                     right_eigenvectors)
      !!
      !! Written by Andreas S. Skeidsvoll, 2020-2023
      !!
      !! Solves the linear equation
      !!
      !!    A X = S X e
      !!
      !! for asymmetric matrices.
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: dim_

      real(dp), dimension(dim_, dim_), intent(inout) :: A
      real(dp), dimension(dim_, dim_), intent(inout) :: S
      real(dp), dimension(dim_), intent(out) :: eigenvalues_real
      real(dp), dimension(dim_), intent(out) :: eigenvalues_imag
      real(dp), dimension(dim_, dim_), intent(out) :: left_eigenvectors
      real(dp), dimension(dim_, dim_), intent(out) :: right_eigenvectors

      real(dp), dimension(:, :), allocatable :: left_eigenvectors_unsorted, right_eigenvectors_unsorted
      real(dp), dimension(:), allocatable :: alpha_real, alpha_imag, beta, work

      integer, dimension(:), allocatable :: index_list
      integer :: info, lwork, i, j

      info = 0
      lwork = - 1

      ! Work space inquiry

      call mem%alloc(work, 1)
      call mem%alloc(alpha_real, dim_)
      call mem%alloc(alpha_imag, dim_)
      call mem%alloc(beta, dim_)
      call mem%alloc(left_eigenvectors_unsorted, dim_, dim_)
      call mem%alloc(right_eigenvectors_unsorted, dim_, dim_)

      call dggev('V', &
                 'V', &
                 dim_, &
                 A, &
                 dim_, &
                 S, &
                 dim_, &
                 alpha_real, &
                 alpha_imag, &
                 beta, &
                 left_eigenvectors_unsorted, &
                 dim_, &
                 right_eigenvectors_unsorted, &
                 dim_, &
                 work, &
                 lwork, &
                 info)

      if (info /= 0) call output%error_msg('in generalized_diagonalization_asymmetric.')

      lwork = ceiling(work(1))
      call mem%dealloc(work)

      ! Diagonalization

      call mem%alloc(work, lwork)

      call dggev('V', &
                 'V', &
                 dim_, &
                 A, &
                 dim_, &
                 S, &
                 dim_, &
                 alpha_real, &
                 alpha_imag, &
                 beta, &
                 left_eigenvectors_unsorted, &
                 dim_, &
                 right_eigenvectors_unsorted, &
                 dim_, &
                 work, &
                 lwork, &
                 info)

      call mem%dealloc(work)

      if (info /= 0) call output%error_msg('in generalized_diagonalization_asymmetric.')

      ! Create real part of eigenvalues from alpha and beta

      !$omp parallel do private(i)
      do i = 1, dim_

         eigenvalues_real(i) = alpha_real(i) / beta(i)

      end do
      !$omp end parallel do

      call mem%dealloc(alpha_real)

      ! Sort real part of eigenvalues

      call mem%alloc(index_list, dim_)
      call quicksort_with_index_ascending(eigenvalues_real, index_list, dim_)

      ! Create imaginary part of sorted eigenvalues from alpha and beta

      !$omp parallel do private(i)
      do i = 1, dim_

         eigenvalues_imag(i) = alpha_imag(index_list(i)) / beta(index_list(i))

      end do
      !$omp end parallel do

      call mem%dealloc(alpha_imag)
      call mem%dealloc(beta)

      ! Sort eigenvectors

      !$omp parallel do private(i, j)
      do i = 1, dim_
         do j = i, dim_

            left_eigenvectors(i, j) = left_eigenvectors_unsorted(i, index_list(j))
            right_eigenvectors(i, j) = right_eigenvectors_unsorted(i, index_list(j))

         end do
      end do
      !$omp end parallel do

      call mem%dealloc(left_eigenvectors_unsorted)
      call mem%dealloc(right_eigenvectors_unsorted)
      call mem%dealloc(index_list)

   end subroutine generalized_diagonalization_asymmetric


   subroutine calculate_pseudoinverse(Ainv, A, m, n, tau)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! The pseudoinverse is computed via an SVD:
      !!
      !!    A    = U S V^T
      !!    Ainv = V S-1 U^T
      !!
      !! In S-1, diagonals with singular values (S) below tau*max(S) are set to zero.
      !!
      use memory_manager_class, only: mem
      use array_initialization, only: zero_array, copy_and_scale

      implicit none

      integer, intent(in) :: m, n

      real(dp), dimension(m, n), intent(in) :: A
      real(dp), dimension(n, m), intent(out) :: Ainv

      real(dp), intent(in) :: tau

      real(dp), dimension(:), allocatable :: S, Sinv
      real(dp), dimension(:, :), allocatable :: U, VT, Acopy

      real(dp), dimension(:), allocatable :: work
      integer :: lwork

      integer :: error_integer, k, l, j, min_mn

      real(dp) :: max_singular

      min_mn = min(m, n)

      call mem%alloc(Acopy, m, n)
      call copy_and_scale(one, A, Acopy, m * n)

      lwork = 2000 * min_mn
      call mem%alloc(work, lwork)

      call mem%alloc(S, min_mn)
      call mem%alloc(U, m, min_mn)
      call mem%alloc(VT, min_mn, n)

      error_integer = 0

      call dgesvd('S', &
                  'S', &
                  m, &
                  n, &
                  Acopy, &
                  m, &
                  S, &
                  U, &
                  m, &
                  VT, &
                  min_mn, &
                  work, &
                  lwork, &
                  error_integer)

      call mem%dealloc(work)
      call mem%dealloc(Acopy)

      if (error_integer /= 0) call output%error_msg('SVD failed in pseudoinverse: (i0)', ints=[error_integer])

      max_singular = maxval(S, min_mn)

      call mem%alloc(Sinv, min_mn)

      do k = 1, min_mn

         if (S(k) < tau * max_singular) then

            Sinv(k) = zero

         else

            Sinv(k) = one / S(k)

         end if

      end do

      call mem%dealloc(S)

      ! (Ainv)_kl = V_kj S-1_j U^T_jl

      call zero_array(Ainv, m * n)

      !$omp parallel do schedule(static) private(k,l,j)
      do k = 1, n
         do l = 1, m
            do j = 1, min_mn

               Ainv(k, l) = Ainv(k, l) + VT(j, k) * Sinv(j) * U(l, j)

            end do
         end do
      end do
      !$omp end parallel do

      call mem%dealloc(U)
      call mem%dealloc(Sinv)
      call mem%dealloc(VT)

   end subroutine calculate_pseudoinverse


   function get_euclidean_distance(point1, point2, N) result(distance)
      !!
      !! Written by Alexander C. Paul, Nov 2021
      !!
      implicit none

      integer, intent(in) :: n
      real(dp), dimension(n), intent(in) :: point1, point2

      real(dp) :: distance

      integer :: i

      distance = zero

      do i = 1, n
         distance = distance + (point1(i) - point2(i))**2
      end do

      distance = sqrt(distance)

   end function get_euclidean_distance


   function find_location(array, value_, n) result(index)
      !!
      !! Written by Alexander C. Paul, Jan 2022
      !!
      !! Returns index of element of array equal to value_
      !! If no identical element is found the result will be 0.
      !!
      !! Required because GCC 8 does not know findloc
      !!
      implicit none

      integer, intent(in) :: n
      character(len=*), dimension(n), intent(in) :: array
      character(len=*), intent(in) :: value_

      integer :: index

      do index = 1, n
         if (value_ == array(index)) return
      end do

      index = 0

   end function find_location


   subroutine remove_trace(M)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! The assumption here is that M is a 2-tensor ordered as xx, xy, xz, yy, yz, and zz,
      !! where the other elements of the tensor are given by symmetry, such as for the quadrupole
      !! moment. Thus, this routine can be called after a call to "calculate quadrupole moment"
      !! to make the moment trace-free.
      !!
      implicit none

      real(dp), dimension(6), intent(inout) :: M

      real(dp) :: trace_

      trace_ = M(1) + M(4) + M(6)

      M(1) = (three * M(1) - trace_) / two
      M(4) = (three * M(4) - trace_) / two
      M(6) = (three * M(6) - trace_) / two

      M(2) = (three * M(2)) / two
      M(3) = (three * M(3)) / two
      M(5) = (three * M(5)) / two

   end subroutine remove_trace


   subroutine row_wise_dot_product(m, n, A, B, v)
      !!
      !! Written by Marco Scavino, April 2021
      !!
      !! Row-wise dot of two matrices
      !!
      implicit none

      integer, intent(in) :: m, n
      real(dp), dimension(m, n), intent(in) :: A, B

      real(dp), dimension(m), intent(out) :: v

      integer :: i, j

      !$omp parallel do private(i, j) default(shared)
      do i = 1, m

         do j = 1, n

            v(i) = v(i) + A(i, j) * B(i, j)

         end do

      end do
      !$omp end parallel do

   end subroutine row_wise_dot_product


   subroutine diagonal_matrix_matrix(C, A, B, n, m, alpha, beta)
      !!
      !! Written by Regina Matveeva and Alexander C. Paul, Sep 2021
      !! Based on mat_dense_dmul routine in LSDalton
      !!
      !! Takes a diagonal matrix (A) in form of a vector
      !! Performs matrix matrix multiplication according to
      !! C = alpha * diag(A) * B + beta * C
      !!
      use array_initialization, only: zero_array

      implicit none

      integer, intent(in) :: n
      integer, intent(in) :: m

      real(dp), intent(in) :: alpha
      real(dp), intent(in) :: beta

      real(dp), dimension(n), intent(in) :: A
      real(dp), dimension(n, m), intent(in) :: B
      real(dp), dimension(n, m), intent(inout) :: C

      integer :: i, j

      if (abs(beta) < 1.0E-12) then

         call zero_array(C, m * n)

      else if (abs(beta - one) > zero) then

         call dscal(m * n, beta, C, 1)

      end if

      !$omp parallel do private(i,j) shared(A,B,C,alpha)
      do j = 1, m
         do i = 1, n

            C(i, j) = C(i, j) + alpha * A(i) * B(i, j)

         end do
      end do
      !$omp end parallel do

   end subroutine diagonal_matrix_matrix


   subroutine unitary_from_exponential_of_antihermitian_matrix(n, K, U)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Computing orthogonal matrix from exponential of antisymmetric matrix:
      !! See MEST 3.1.2 & 3.1.3 pp. 81-83
      !!
      !!    K contains the imaginary part of an antihermitian matrix;
      !!    iK is hermitian, eigenvalues are real
      !!    V^dagger lambda V = iK
      !!    exp(-K) = exp(i V^dagger lambda V) = V^dagger exp(i lambda) V
      !!    [exp(i lambda)]_p = exp(i lambda_p) using the Euler's formula
      !!    exp(i lambda_p) = cos(lambda_p) - i sin(lambda_p)
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: n

      real(dp), dimension(n, n), intent(in) :: K
      real(dp), dimension(n, n), intent(out) :: U

      real(dp), dimension(:), allocatable :: lambda

      complex(dp), dimension(:, :), allocatable :: X, U_cmplx, K_cmplx
      complex(dp) :: exp_lambda

      integer :: p, q

      call mem%alloc(K_cmplx, n, n)
      call mem%alloc(U_cmplx, n, n)
      call mem%alloc(lambda, n)

      !$omp parallel do private(p,q)
      do p = 1, n
         do q = 1, n
            K_cmplx(p, q) = cmplx(zero, K(p, q), kind=dp)
         end do
      end do
      !$omp end parallel do

      call diagonalize_hermitian(n, K_cmplx, lambda)

      call mem%alloc(X, n, n)
      call zcopy(n**2, K_cmplx, 1, X, 1)

      do p = 1, n

         exp_lambda = cmplx(cos(lambda(p)), - sin(lambda(p)), kind=dp)

         call zscal(n, exp_lambda, X(:, p), 1)

      end do

      call zgemm('N', &
                 'c', &
                 n, &
                 n, &
                 n, &
                 one_complex, &
                 X, &
                 n, &
                 K_cmplx, &
                 n, &
                 zero_complex, &
                 U_cmplx, &
                 n)

      !$omp parallel do private(p,q)
      do p = 1, n
         do q = 1, n

            U(p, q) = real(U_cmplx(p, q))

         end do
      end do
      !$omp end parallel do

      call mem%dealloc(X)
      call mem%dealloc(K_cmplx)
      call mem%dealloc(U_cmplx)
      call mem%dealloc(lambda)

   end subroutine unitary_from_exponential_of_antihermitian_matrix


   subroutine diagonalize_hermitian(n, A, lambda)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! A contains the eigenvectors on exit, lambda are the eigenvalues
      !!
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: n

      complex(dp), dimension(n, n), intent(inout) :: A
      real(dp), dimension(n), intent(inout) :: lambda

      integer :: info

      real(dp), dimension(:), allocatable :: rwork
      complex(dp), dimension(:), allocatable :: work

      call mem%alloc(work, 2 * N - 1)
      call mem%alloc(rwork, 3 * N - 2)

      call zheev('V', 'L', N, A, N, lambda, work, 2 * N - 1, rwork, INFO)

      call mem%dealloc(work)
      call mem%dealloc(rwork)

   end subroutine diagonalize_hermitian


   function is_diagonal(n, A) result(diagonal)
      !!
      !! Written by Rosario R. Riso, 2023
      !!
      !! On exit returns true if A is diagonal
      !! or false ortherwise
      !!
      implicit none

      integer, intent(in) :: n

      real(dp), dimension(n, n), intent(in) :: A

      integer :: i, j

      logical :: diagonal

      diagonal = .true.

      do i = 1, n

         do j = i + 1, n

            if (A(i, j) > Ten**(- 10)) then

               diagonal = .false.

               exit

            end if

         end do

      end do

   end function is_diagonal


   pure function get_equal_to_threshold(vector, dim, idx, threshold) result(equal)
      !!
      !! Written by Sarai D. Folkestad, 2025
      !!
      !! Identifies elements of vector that are equal, up to a threshold,
      !! to the idx'th element of the same vector
      !!
      implicit none

      integer, intent(in) :: dim, idx

      real(dp), dimension(dim), intent(in) :: vector
      real(dp), intent(in) :: threshold

      logical, dimension(dim) :: equal
      integer :: i

      equal = .false.
      do i = 1, dim
         if (abs(vector(i) - vector(idx)) < threshold) equal(i) = .true.
      end do

   end function get_equal_to_threshold

end module array_utilities

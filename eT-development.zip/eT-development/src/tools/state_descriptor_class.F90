

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module state_descriptor_class

   !!
   !! State descriptor class
   !! Written by Alexander C. Paul, Mar 2022
   !!


   implicit none

   type :: es_type

      logical :: ip, cvs, rm_core, ea

   end type es_type

   interface es_type

      procedure :: new_es_type
      procedure :: new_es_type_none

   end interface es_type

   type :: state_descriptor

      type(es_type), private :: type_

      character(len=:), allocatable, private :: left_or_right
      character(len=:), allocatable, private :: spin_symmetry

   contains

      procedure :: is_ionized
      procedure :: is_cvs
      procedure :: is_core_removed
      procedure :: is_electron_attached
      procedure :: get_left_or_right
      procedure :: get_spin_symmetry
      procedure :: get_es_type
      procedure, private :: get_suffix
      procedure, public :: get_file_name


      procedure, private :: is_equal
      generic, public :: operator(==) => is_equal

   end type state_descriptor


   interface state_descriptor

      procedure :: new_state_descriptor
      procedure :: new_state_descriptor_type
      procedure :: new_state_descriptor_gs

   end interface state_descriptor


contains

   function new_es_type(cvs, rm_core, ip, ea) result(this)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      type(es_type) :: this

      logical, intent(in) :: cvs, ip, rm_core, ea

      this%ip = ip
      this%cvs = cvs
      this%rm_core = rm_core
      this%ea = ea

   end function new_es_type


   function new_es_type_none() result(this)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      type(es_type) :: this

      this%ip = .false.
      this%cvs = .false.
      this%rm_core = .false.
      this%ea = .false.

   end function new_es_type_none


   function new_state_descriptor_gs(left_or_right) result(this)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      type(state_descriptor) :: this

      character(len=*), intent(in) :: left_or_right

      this%left_or_right = left_or_right
      this%spin_symmetry = 'singlet'

      this%type_ = es_type()

   end function new_state_descriptor_gs


   function new_state_descriptor_type(left_or_right, type_, spin_symmetry) result(this)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      type(state_descriptor) :: this

      type(es_type), intent(in) :: type_

      character(len=*), intent(in) :: left_or_right
      character(len=*), intent(in) :: spin_symmetry

      this%left_or_right = left_or_right
      this%spin_symmetry = spin_symmetry
      this%type_ = type_

   end function new_state_descriptor_type


   function new_state_descriptor(left_or_right, cvs, ip, rm_core, ea, spin_symmetry) result(this)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      type(state_descriptor) :: this

      logical, intent(in) :: cvs, ip, rm_core, ea

      character(len=*), intent(in) :: left_or_right
      character(len=*), intent(in), optional :: spin_symmetry

      this%left_or_right = left_or_right
      this%spin_symmetry = spin_symmetry
      this%type_ = es_type(cvs, rm_core, ip, ea)

   end function new_state_descriptor


   pure function is_electron_attached(this) result(electron_attached)
      !!
      !! Is electron_attached
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      class(state_descriptor), intent(in) :: this
      logical :: electron_attached

      electron_attached = this%type_%ea

   end function is_electron_attached


   pure function is_ionized(this) result(ionized)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      class(state_descriptor), intent(in) :: this
      logical :: ionized

      ionized = this%type_%ip

   end function is_ionized


   pure function is_cvs(this) result(cvs)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      class(state_descriptor), intent(in) :: this
      logical :: cvs

      cvs = this%type_%cvs

   end function is_cvs


   pure function is_core_removed(this) result(rm_core)
      !!
      !! Is core removed
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      class(state_descriptor), intent(in) :: this
      logical :: rm_core

      rm_core = this%type_%rm_core

   end function is_core_removed


   pure function get_left_or_right(this) result(left_or_right)
      !!
      !! Written by Alexander C. Paul, Dec 2022
      !!
      implicit none

      class(state_descriptor), intent(in) :: this
      character(len=:), allocatable :: left_or_right

      left_or_right = this%left_or_right

   end function get_left_or_right


   pure function get_spin_symmetry(this) result(spin_symmetry)
      !!
      !! Written by Sarai D. Folkestad,  2024
      !!
      implicit none

      class(state_descriptor), intent(in) :: this
      character(len=:), allocatable :: spin_symmetry

      spin_symmetry = this%spin_symmetry

   end function get_spin_symmetry


   function get_es_type(this) result(es_type)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      implicit none

      class(state_descriptor), intent(in) :: this
      character(len=40) :: es_type

      if (this%type_%rm_core) then
         es_type = 'remove core'
      else if (this%type_%cvs .and. this%type_%ip) then
         es_type = 'core ionize'
      else if (this%type_%cvs) then
         es_type = 'core'
      else if (this%type_%ip) then
         es_type = 'ionize'
      else if (this%type_%ea) then
         es_type = 'electron attachment'
      else
         es_type = 'valence'
      end if

   end function get_es_type


   function get_suffix(this) result(suffix)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      implicit none

      class(state_descriptor), intent(in) :: this
      character(len=15) :: suffix

      if (this%type_%rm_core) then
         suffix = '_rm_core'
      else if (this%type_%cvs .and. this%type_%ip) then
         suffix = '_cvs_ip'
      else if (this%type_%cvs) then
         suffix = '_cvs'
      else if (this%type_%ip) then
         suffix = '_ip'
      else if (this%type_%ea) then
         suffix = '_ea'
      else
         suffix = ''
      end if

   end function get_suffix


   elemental function is_equal(this, that) result(is_equal_)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      implicit none

      class(state_descriptor), intent(in) :: this
      class(state_descriptor), intent(in) :: that

      logical :: is_equal_

      is_equal_ = (trim(this%left_or_right) == trim(that%left_or_right)) .and. &
                  (trim(this%spin_symmetry) == trim(that%spin_symmetry)) .and. &
                  (this%type_%cvs .eqv. that%type_%cvs) .and. (this%type_%ip .eqv. that%type_%ip) .and. &
                  (this%type_%rm_core .eqv. that%type_%rm_core) .and. (this%type_%ea .eqv. that%type_%ea)

   end function is_equal


   function get_file_name(this, i) result(file_name)
      !!
      !! Written by Sarai D. Folkestad, Oct 2024
      !!
      implicit none
      class(state_descriptor), intent(in) :: this
      integer, intent(in) :: i

      character(len=200) :: file_name

      write(file_name, '(a, i3.3, a)') this%left_or_right(1:1) // "_" // trim(this%spin_symmetry) // "_", i, &
         this%get_suffix()

   end function get_file_name

end module state_descriptor_class

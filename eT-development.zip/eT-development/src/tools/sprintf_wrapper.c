#include <stdio.h>

int sprintf_real_(char *buf, char *fmt, double *x) {
    return sprintf(buf, fmt, *x);
}

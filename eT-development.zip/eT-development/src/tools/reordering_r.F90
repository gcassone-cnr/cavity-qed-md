

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module reordering_r

   !!
   !! Reordering module
   !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, June 2018
   !!
   !! Here are all routines that are used to re-sort arrays and (e.g., sort_to_132)
   !! performing re-sort-addition (add_132_to_123), along with routines that both squareup
   !! (e.g., t2am -> t_ai_bj) and re-sort (t_ai_bj -> t_aj_bi) in a single step; also included
   !! are routines that squareup (t_aibj -> t_ai_bj) and packin (t_ai_bj -> t_aibj) and
   !! related routines.
   !!

   use parameters

   implicit none

   interface sort_to_21
      procedure :: sort_to_21_rank_1, sort_to_21_rank_2
   end interface sort_to_21

   interface symmetric_sum
      procedure :: symmetric_sum_rank_2, symmetric_sum_rank_4
   end interface

   interface symmetrize_and_add_to_packed
      procedure :: symmetrize_and_add_rank_2_to_packed, symmetrize_and_add_rank_4_to_packed
   end interface symmetrize_and_add_to_packed

   interface add_to_subblock
      procedure :: add_to_subblock_rank_2, add_to_subblock_rank_4
   end interface add_to_subblock

   interface add_from_subblock
      procedure :: add_from_subblock_rank_4
   end interface add_from_subblock

   interface squareup
      procedure :: squareup_rank_1, squareup_rank_2, squareup_rank_4
   end interface squareup

   interface sort_and_extract_subblock
      procedure :: sort_and_extract_subblock_full, sort_and_extract_subblock_from_packed
   end interface sort_and_extract_subblock

   interface packin
      procedure :: packin_rank_2, packin_rank_4, packin_rank_4_from_1324_order
   end interface packin

   interface squareup_cube
      procedure :: squareup_cube_rank_3, squareup_cube_rank_6
   end interface squareup_cube

   interface packin_cube
      procedure :: packin_cube_rank_3, packin_cube_rank_6
   end interface packin_cube

   interface construct_contravariant
      procedure :: construct_contravariant_rank4_from_full, construct_contravariant_rank4_from_packed
   end interface construct_contravariant


contains

   ! -::- Two-index re-sort and re-sort-add routines -::-
   ! ----------------------------------------------------

   subroutine sort_to_21_rank_1(x_pq, x_qp, dim_p, dim_q)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_p_q to x_q_p (i.e., 12 to 21).
      !!
      !! The unordered array x_pq_rs is assumed allocated as dim_p*dim_q x dim_r*dim_s.
      !! The ordered array x_sp_rq is assumed allocated as dim_s*dim_p x dim_r*dim_q.
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q

      real(dp), dimension(dim_p, dim_q), intent(in) :: x_pq
      real(dp), dimension(dim_q, dim_p), intent(out) :: x_qp

      integer :: p, q

      !$omp parallel do schedule(static) private(p,q)
      do p = 1, dim_p
         do q = 1, dim_q

            x_qp(q, p) = x_pq(p, q)

         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_21_rank_1


   subroutine sort_to_21_rank_2(x_pq, x_qp, dim_p, dim_q)
      !!
      !! Written by Alexander C. Paul, May 2021
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q

      real(dp), dimension(dim_p * dim_q), intent(in) :: x_pq
      real(dp), dimension(dim_q, dim_p), intent(out) :: x_qp

      call sort_to_21_rank_1(x_pq, x_qp, dim_p, dim_q)

   end subroutine sort_to_21_rank_2


   subroutine sort_to_21_from_subblock(x_pq, y_qp, p_range, q_range)
      !!
      !! Written by Marcus T. Lexander 2023
      !!
      !! Reorders the array x_p_q to a subblock of x_q_p (i.e., 12 to 21).
      !!
      use range_class

      implicit none
      real(dp), dimension(:, :), intent(out) :: y_qp
      real(dp), dimension(:, :), intent(in) :: x_pq
      class(range_), intent(in), optional :: p_range, q_range

      integer :: p, q, pp, qq, dim_p, dim_q
      integer :: local_first_p, local_first_q

      dim_q = size(y_qp, 1)
      dim_p = size(y_qp, 2)

      local_first_p = 1
      local_first_q = 1
      if (present(p_range)) local_first_p = p_range%first
      if (present(q_range)) local_first_q = q_range%first

      !$omp parallel do schedule(static) private(p,q,pp,qq) collapse(2)
      do p = 1, dim_p
         do q = 1, dim_q

            pp = p + local_first_p - 1
            qq = q + local_first_q - 1

            y_qp(q, p) = x_pq(pp, qq)

         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_21_from_subblock


   subroutine add_21_to_12(scalar, x, y_p_q, dim_p, dim_q)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_p_q(p,q) = y_p_q(p,q) + scalar*x(q,p)
      !!
      !! The unordered array y_p_q is assumed allocated as dim_p x dim_q,
      !! and x accordingly.
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q

      real(dp), dimension(dim_p, dim_q), intent(inout) :: y_p_q
      real(dp), dimension(dim_q, dim_p), intent(in) :: x

      integer :: p, q

      !$omp parallel do schedule(static) private(p, q)
      do q = 1, dim_q
         do p = 1, dim_p

            y_p_q(p, q) = y_p_q(p, q) + scalar * x(q, p)

         end do
      end do
      !$omp end parallel do

   end subroutine add_21_to_12


   subroutine symmetric_sum_rank_2(x, dim_)
      !!
      !! Written by Eirik F. Kjoenstad, Dec 2017
      !!
      !! Performs the action
      !!
      !!    x(p,q) = x(p,q) + x(q,p)
      !!
      !! without making a separate copy of x.
      !!
      !! Note: the effect is equal to the routine "add_21_to_12" with scalar = 1,
      !!       where a second copy of x is not needed.
      !!
      implicit none

      integer, intent(in) :: dim_

      real(dp), dimension(dim_, dim_), intent(inout) :: x

      integer :: p, q

      ! Overwrite the lower triangular part of the matrix

      !$omp parallel do private(p, q)
      do q = 1, dim_
         do p = q, dim_

            x(p, q) = x(p, q) + x(q, p)

         end do
      end do
      !$omp end parallel do

      ! Copy the lower triangular part to the upper triangular part

      !$omp parallel do private(p, q)
      do p = 1, dim_
         do q = p + 1, dim_

            x(p, q) = x(q, p)

         end do
      end do
      !$omp end parallel do

   end subroutine symmetric_sum_rank_2


   subroutine symmetric_sum_rank_4(x, dim_)
      !!
      !! Written by Andreas Skeidsvoll, Sep 2019
      !!
      !! Performs the action
      !!
      !!    x(p,q) = x(p,q) + x(q,p)
      !!
      !!
      implicit none

      integer, intent(in) :: dim_

      real(dp), dimension(:, :, :, :), intent(inout) :: x

      call symmetric_sum_rank_2(x, dim_)

   end subroutine symmetric_sum_rank_4


   subroutine symmetrize_12_and_34(x, dim_p, dim_r)
      !!
      !! Written by Rolf H. Myhre, May 2019
      !!
      !! Performs the action
      !!
      !!    x(p,q,r,s) = x(p,q,r,s) + x(q,p,s,r)
      !!
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_r

      real(dp), dimension(dim_p, dim_p, dim_r, dim_r), intent(inout) :: x

      integer :: p, q, r, s, p_lim

      ! Lower triangles first

      !$omp parallel do private(p, q, r, s, p_lim)
      do s = 1, dim_r
         do r = s, dim_r
            do q = 1, dim_p

               if (r /= s) then
                  p_lim = 1
               else
                  p_lim = q
               end if

               do p = p_lim, dim_p

                  x(p, q, r, s) = x(p, q, r, s) + x(q, p, s, r)

               end do
            end do
         end do
      end do
      !$omp end parallel do

      ! And the upper triangles

      !$omp parallel do private(p, q, r, s, p_lim)
      do s = 1, dim_r
         do r = 1, s
            do q = 1, dim_p

               if (r /= s) then
                  p_lim = dim_p
               else
                  p_lim = q - 1
               end if

               do p = 1, p_lim

                  x(p, q, r, s) = x(q, p, s, r)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine symmetrize_12_and_34


   ! -::- Three-index re-sort and re-sort-add routines -::-
   ! ------------------------------------------------------

   subroutine sort_to_312(x_pqr, x_rpq, dim_p, dim_q, dim_r)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    x_rpq(r,p,q) = x_pqr(p,q,r)
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r

      real(dp), dimension(dim_p, dim_q, dim_r), intent(in) :: x_pqr
      real(dp), dimension(dim_r, dim_p, dim_q), intent(out) :: x_rpq

      integer :: r, q, p

      !$omp parallel do schedule(static) private(r,q,p)
      do q = 1, dim_q
         do p = 1, dim_p
            do r = 1, dim_r

               x_rpq(r, p, q) = x_pqr(p, q, r)

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_312


   subroutine sort_to_231(x_pqr, x_qrp, dim_p, dim_q, dim_r)
      !!
      !! Written by Rolf H. Myhre, April 2019
      !!
      !! Performs:
      !!
      !!    x_qrp(q,r,p) = x_pqr(p,q,r)
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r

      real(dp), dimension(dim_p, dim_q, dim_r), intent(in) :: x_pqr
      real(dp), dimension(dim_q, dim_r, dim_p), intent(out) :: x_qrp

      integer :: r, q, p

      !$omp parallel do schedule(static) private(r,q,p)
      do p = 1, dim_p
         do r = 1, dim_r
            do q = 1, dim_q

               x_qrp(q, r, p) = x_pqr(p, q, r)

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_231


   subroutine add_312_to_123(scalar, x_rpq, x_pqr, dim_p, dim_q, dim_r)
      !!
      !! Written by Andreas Skeidsvoll, Sep 2019
      !!
      !! Performs:
      !!
      !!    x_pqr(p,q,r) = x_pqr(p,q,r) + scalar*x_rpq(r,p,q)
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r

      real(dp), intent(in) :: scalar

      real(dp), dimension(dim_r, dim_p, dim_q), intent(in) :: x_rpq
      real(dp), dimension(dim_p, dim_q, dim_r), intent(inout) :: x_pqr

      integer :: r, q, p

      !$omp parallel do schedule(static) private(r,q,p)
      do q = 1, dim_q
         do p = 1, dim_p
            do r = 1, dim_r

               x_pqr(p, q, r) = x_pqr(p, q, r) + scalar * x_rpq(r, p, q)

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_312_to_123


   subroutine sort_to_132(x_pqr, x_prq, dim_p, dim_q, dim_r)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    x_prq(p,r,q) = x_pqr(p,q,r)
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r

      real(dp), dimension(dim_p, dim_q, dim_r), intent(in) :: x_pqr
      real(dp), dimension(dim_p, dim_r, dim_q), intent(out) :: x_prq

      integer :: r, q, p

      !$omp parallel do schedule(static) private(r,q,p)
      do q = 1, dim_q
         do r = 1, dim_r
            do p = 1, dim_p

               x_prq(p, r, q) = x_pqr(p, q, r)

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_132


   subroutine sort_to_213(x_pqr, x_qpr, dim_p, dim_q, dim_r)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    x_qpr(q,p,r) = x_pqr(p,q,r)
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r

      real(dp), dimension(dim_p, dim_q, dim_r), intent(in) :: x_pqr
      real(dp), dimension(dim_q, dim_p, dim_r), intent(out) :: x_qpr

      integer :: p, q, r

      !$omp parallel do schedule(static) private(p, q, r)
      do r = 1, dim_r
         do p = 1, dim_p
            do q = 1, dim_q

               x_qpr(q, p, r) = x_pqr(p, q, r)

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_213


   subroutine add_231_to_123(scalar, x_qrp, y_pqr, dim_p, dim_q, dim_r)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqr(pqr) = y_pqr(pqr) + scalar*x(qrp)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r

      real(dp), dimension(dim_p, dim_q, dim_r) :: y_pqr
      real(dp), dimension(dim_q, dim_r, dim_p), intent(in) :: x_qrp

      integer :: r, q, p

      !$omp parallel do schedule(static) private(r,q,p)
      do r = 1, dim_r
         do q = 1, dim_q
            do p = 1, dim_p

               y_pqr(p, q, r) = y_pqr(p, q, r) + scalar * x_qrp(q, r, p)

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_231_to_123


   subroutine add_213_to_123(scalar, x_qpr, y_pqr, dim_p, dim_q, dim_r)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqr(pqr) = y_pqr(pqr) + scalar*x(qpr)
      !!
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r

      real(dp), dimension(dim_p, dim_q, dim_r) :: y_pqr
      real(dp), dimension(dim_q, dim_p, dim_r), intent(in) :: x_qpr

      integer :: r, q, p

      !$omp parallel do schedule(static) private(r,q,p)
      do r = 1, dim_r
         do q = 1, dim_q
            do p = 1, dim_p

               y_pqr(p, q, r) = y_pqr(p, q, r) + scalar * x_qpr(q, p, r)

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_213_to_123


   subroutine add_321_to_123(scalar, x_rqp, y_pqr, dim_p, dim_q, dim_r)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqr(pqr) = y_pqr(pqr) + scalar*x(rqp)
      !!
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r

      real(dp), dimension(dim_p, dim_q, dim_r) :: y_pqr
      real(dp), dimension(dim_r, dim_q, dim_p), intent(in) :: x_rqp

      integer :: r, q, p

      !$omp parallel do schedule(static) private(r,q,p)
      do r = 1, dim_r
         do q = 1, dim_q
            do p = 1, dim_p

               y_pqr(p, q, r) = y_pqr(p, q, r) + scalar * x_rqp(r, q, p)

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_321_to_123


   subroutine add_132_to_123(scalar, x_prq, y_pqr, dim_p, dim_q, dim_r)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqr(p,q,r) = y_pqr(p,q,r) + scalar * x_prq(p,r,q)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r

      real(dp), dimension(dim_p, dim_q, dim_r) :: y_pqr
      real(dp), dimension(dim_p, dim_r, dim_q), intent(in) :: x_prq

      integer :: p, q, r

      !$omp parallel do schedule(static) private(r,q,p)
      do r = 1, dim_r
         do q = 1, dim_q
            do p = 1, dim_p

               y_pqr(p, q, r) = y_pqr(p, q, r) + scalar * x_prq(p, r, q)

            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_132_to_123

   ! -::- Four-index re-sort and re-sort-add routines -::-
   ! -----------------------------------------------------

   subroutine add_3124_to_1234(scalar, x_rpqs, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_rpqs(r,p,q,s)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_r, dim_p, dim_q, dim_s), intent(in) :: x_rpqs

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_rpqs(r, p, q, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_3124_to_1234


   subroutine sort_to_3412(x_pqrs, x_rspq, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_rspq (i.e., 1234 to 3412).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_r, dim_s, dim_p, dim_q), intent(out) :: x_rspq

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do q = 1, dim_q
         do p = 1, dim_p
            do s = 1, dim_s
               do r = 1, dim_r

                  x_rspq(r, s, p, q) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_3412


   subroutine sort_to_4132(x_pqrs, x_sprq, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_sprq (i.e., 1234 to 4132).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_s, dim_p, dim_r, dim_q), intent(out) :: x_sprq

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do q = 1, dim_q
         do r = 1, dim_r
            do p = 1, dim_p
               do s = 1, dim_s

                  x_sprq(s, p, r, q) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_4132


   subroutine sort_to_4123(x_pqrs, x_spqr, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad, Rolf H. Myhre and Andreas Skeidsvoll, 2018
      !!
      !! Reorders the array x_pqrs to x_spqr (i.e., 1234 to 4123).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_s, dim_p, dim_q, dim_r), intent(out) :: x_spqr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do q = 1, dim_q
         do r = 1, dim_r
            do p = 1, dim_p
               do s = 1, dim_s

                  x_spqr(s, p, q, r) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_4123


   subroutine sort_to_3124(x_pqrs, x_rpqs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_rpqs (i.e., 1234 to 3124).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_r, dim_p, dim_q, dim_s), intent(out) :: x_rpqs

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do q = 1, dim_q
            do p = 1, dim_p
               do r = 1, dim_r

                  x_rpqs(r, p, q, s) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_3124


   subroutine sort_to_3142(x_pqrs, x_rpsq, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad, Rolf H. Myhre and
      !! Sarai D. Folkestad, 2018
      !!
      !! Reorders the array x_pqrs to x_rpsq (i.e., 1234 to 3142).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_r, dim_p, dim_s, dim_q), intent(out) :: x_rpsq

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do q = 1, dim_q
         do s = 1, dim_s
            do p = 1, dim_p
               do r = 1, dim_r

                  x_rpsq(r, p, s, q) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_3142


   subroutine squareup_and_sort_to_2413(x_pqrs, x_qspr, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Square up and reorder the array x_pqrs to x_qspr (i.e., 1234 to 2413).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(((dim_p * dim_q + 1) * dim_r * dim_s) / 2), intent(in) :: x_pqrs
      real(dp), dimension(dim_q, dim_s, dim_p, dim_r), intent(out) :: x_qspr

      integer :: p, q, r, s, rs, pq, pqrs

      !$omp parallel do schedule(static) private(s,r,q,p,pq,rs,pqrs)
      do r = 1, dim_r
         do p = 1, dim_p
            do s = 1, dim_s

               rs = dim_r * (s - 1) + r

               do q = 1, dim_q

                  pq = dim_p * (q - 1) + p
                  pqrs = (max(pq, rs) * (max(pq, rs) - 3) / 2) + pq + rs

                  x_qspr(q, s, p, r) = x_pqrs(pqrs)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine squareup_and_sort_to_2413


   subroutine squareup_and_sort_to_2314(x_pqrs, x_qrps, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Square up and reorder the array x_pqrs to x_qspr (i.e., 1234 to 2314).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(((dim_p * dim_q + 1) * dim_r * dim_s) / 2), intent(in) :: x_pqrs
      real(dp), dimension(dim_q, dim_r, dim_p, dim_s), intent(out) :: x_qrps

      integer :: p, q, r, s, rs, pq, pqrs

      !$omp parallel do schedule(static) private(s,r,q,p,pq,rs,pqrs)
      do s = 1, dim_s
         do p = 1, dim_p
            do r = 1, dim_r

               rs = dim_r * (s - 1) + r

               do q = 1, dim_q

                  pq = dim_p * (q - 1) + p
                  pqrs = (max(pq, rs) * (max(pq, rs) - 3) / 2) + pq + rs

                  x_qrps(q, r, p, s) = x_pqrs(pqrs)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine squareup_and_sort_to_2314


   subroutine sort_to_2314(x_pqrs, x_qrps, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_qrps (i.e., 1234 to 2314).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_q, dim_r, dim_p, dim_s), intent(out) :: x_qrps

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do p = 1, dim_p
            do r = 1, dim_r
               do q = 1, dim_q

                  x_qrps(q, r, p, s) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_2314


   subroutine sort_to_2134(x_pqrs, x_qprs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Sarai D. Folkestad,
      !! Eirik F. Kjoenstad and Rolf H. Myhre, 2018
      !!
      !! Reorders the array x_pqrs to x_qprs (i.e., 1234 to 2134).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_q, dim_p, dim_r, dim_s), intent(out) :: x_qprs

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do p = 1, dim_p
               do q = 1, dim_q

                  x_qprs(q, p, r, s) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_2134


   subroutine sort_to_2143(x_pqrs, x_qpsr, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Sarai D. Folkestad,
      !! Eirik F. Kjoenstad and Rolf H. Myhre, 2018
      !!
      !! Reorders the array x_pqrs to x_qpsr (i.e., 1234 to 2143).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_q, dim_p, dim_s, dim_r), intent(out) :: x_qpsr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do r = 1, dim_r
         do s = 1, dim_s
            do p = 1, dim_p
               do q = 1, dim_q

                  x_qpsr(q, p, s, r) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_2143


   subroutine sort_to_2143_subblock(x_pqrs, x_qpsr, p_range, q_range, r_range, s_range)
      !!
      !! Written by Marcus T. Lexander 2023
      !!
      !! Reorders the array x_pqrs to a subblock of x_qpsr (i.e., 1234 to 2143).
      !!
      use range_class

      implicit none

      class(range_), intent(in) :: p_range, q_range, r_range, s_range

      real(dp), dimension(p_range%length, q_range%length, r_range%length, s_range%length), intent(in) :: &
         x_pqrs
      real(dp), dimension(:, :, :, :), intent(out) :: x_qpsr

      integer :: p, q, r, s, pp, qq, rr, ss

      !$omp parallel do schedule(static) private(p, q, r, s, pp, qq, rr, ss)
      do s = 1, s_range%length
         ss = s_range%first + (s - 1) * s_range%step

         do r = 1, r_range%length
            rr = r_range%first + (r - 1) * r_range%step

            do q = 1, q_range%length
               qq = q_range%first + (q - 1) * q_range%step

               do p = 1, p_range%length
                  pp = p_range%first + (p - 1) * p_range%step

                  x_qpsr(qq, pp, ss, rr) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_2143_subblock


   subroutine sort_to_2413(x_pqrs, x_qspr, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Sarai D. Folkestad,
      !! Eirik F. Kjoenstad and Rolf H. Myhre, 2018
      !!
      !! Reorders the array x_pqrs to x_qspr (i.e., 1234 to 2413).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_q, dim_s, dim_p, dim_r), intent(out) :: x_qspr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do r = 1, dim_r
         do p = 1, dim_p
            do s = 1, dim_s
               do q = 1, dim_q

                  x_qspr(q, s, p, r) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_2413


   subroutine sort_to_2431(x_pqrs, x_qsrp, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Sarai D. Folkestad,
      !! Eirik F. Kjoenstad and Rolf H. Myhre, 2018
      !!
      !! Reorders the array x_pqrs to x_qsrp (i.e., 1234 to 2431).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_q, dim_s, dim_r, dim_p) :: x_qsrp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(p,q,r,s)
      do p = 1, dim_p
         do r = 1, dim_r
            do s = 1, dim_s
               do q = 1, dim_q

                  x_qsrp(q, s, r, p) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_2431


   subroutine sort_to_3421(x_pqrs, x_rsqp, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Sarai D. Folkestad,
      !! Eirik F. Kjoenstad and Rolf H. Myhre, 2018
      !!
      !! Reorders the array x_pqrs to x_rsqp (i.e., 1234 to 3421).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_r, dim_s, dim_q, dim_p) :: x_rsqp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(p,q,r,s)
      do p = 1, dim_p
         do q = 1, dim_q
            do s = 1, dim_s
               do r = 1, dim_r

                  x_rsqp(r, s, q, p) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_3421


   subroutine sort_to_1324(x_pqrs, x_prqs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pq_rs to x_pr_qs (i.e., 1234 to 1324).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_p, dim_r, dim_q, dim_s), intent(out) :: x_prqs

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do q = 1, dim_q
            do r = 1, dim_r
               do p = 1, dim_p

                  x_prqs(p, r, q, s) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_1324


   subroutine squareup_and_sort_to_1324(x_pqrs, x_prqs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pq_rs to x_pr_qs (i.e., 1234 to 1324).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(((dim_p * dim_q + 1) * (dim_r * dim_s) / 2)), intent(in) :: x_pqrs
      real(dp), dimension(dim_p, dim_r, dim_q, dim_s), intent(out) :: x_prqs

      integer :: p, q, r, s, pq, rs, pqrs

      !$omp parallel do schedule(static) private(s,r,q,p,pq,rs,pqrs)
      do s = 1, dim_s
         do q = 1, dim_q
            do r = 1, dim_r

               rs = dim_r * (s - 1) + r

               do p = 1, dim_p

                  pq = dim_p * (q - 1) + p
                  pqrs = (max(pq, rs) * (max(pq, rs) - 3) / 2) + pq + rs

                  x_prqs(p, r, q, s) = x_pqrs(pqrs)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine squareup_and_sort_to_1324


   subroutine sort_to_2341(x_pqrs, x_qrsp, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_qrsp (i.e., 1234 to 2341).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_q, dim_r, dim_s, dim_p), intent(out) :: x_qrsp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  x_qrsp(q, r, s, p) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_2341


   subroutine sort_to_1342(x_pqrs, x_prsq, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_prsq (i.e., 1234 to 1342).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_p, dim_r, dim_s, dim_q), intent(out) :: x_prsq

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do q = 1, dim_q
         do s = 1, dim_s
            do r = 1, dim_r
               do p = 1, dim_p

                  x_prsq(p, r, s, q) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_1342


   subroutine sort_to_1432(x_pqrs, x_psrq, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_psrq (i.e., 1234 to 1432).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_p, dim_s, dim_r, dim_q), intent(out) :: x_psrq

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do q = 1, dim_q
         do r = 1, dim_r
            do s = 1, dim_s
               do p = 1, dim_p

                  x_psrq(p, s, r, q) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_1432


   subroutine sort_to_4312(x_pqrs, x_srpq, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_srpq (i.e., 1234 to 4312).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_s, dim_r, dim_p, dim_q), intent(out) :: x_srpq

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(p,q,r,s)
      do q = 1, dim_q
         do p = 1, dim_p
            do r = 1, dim_r
               do s = 1, dim_s

                  x_srpq(s, r, p, q) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_4312


   subroutine sort_to_1423(x_pqrs, x_psqr, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_psqr (i.e., 1234 to 1423).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_p, dim_s, dim_q, dim_r), intent(out) :: x_psqr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do r = 1, dim_r
         do q = 1, dim_q
            do s = 1, dim_s
               do p = 1, dim_p

                  x_psqr(p, s, q, r) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_1423


   subroutine add_1423_to_1234(scalar, x_psqr, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad, Rolf H. Myhre and Andreas Skeidsvoll, 2018
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_psqr(p,s,q,r)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_p, dim_s, dim_q, dim_r), intent(in) :: x_psqr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_psqr(p, s, q, r)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_1423_to_1234


   subroutine add_1432_to_1234(scalar, x_psrq, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x(p,s,r,q)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_p, dim_s, dim_r, dim_q), intent(in) :: x_psrq

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_psrq(p, s, r, q)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_1432_to_1234


   subroutine add_1342_to_1234(scalar, x_prsq, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_prsq(p,r,s,q)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_p, dim_r, dim_s, dim_q), intent(in) :: x_prsq

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_prsq(p, r, s, q)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_1342_to_1234


   subroutine add_1324_to_1234(scalar, x_prqs, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Andreas Skeidsvoll, Apr 2019: Created by modifying add_1342_to_1234
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_prqs(p,r,q,s)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_p, dim_r, dim_q, dim_s), intent(in) :: x_prqs

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_prqs(p, r, q, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_1324_to_1234


   subroutine add_1243_to_1234(scalar, x_pqsr, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_pqsr(p,q,s,r)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_p, dim_q, dim_s, dim_r), intent(in) :: x_pqsr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_pqsr(p, q, s, r)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_1243_to_1234


   subroutine add_3412_to_1234(scalar, x_rspq, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x(r,s,p,q)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_r, dim_s, dim_p, dim_q), intent(in) :: x_rspq

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(p,q,r,s)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_rspq(r, s, p, q)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_3412_to_1234


   subroutine add_3421_to_1234(scalar, x_rsqp, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_rsqp(r,s,q,p)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_r, dim_s, dim_q, dim_p), intent(in) :: x_rsqp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(p,q,r,s)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_rsqp(r, s, q, p)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_3421_to_1234


   subroutine add_2341_to_1234(scalar, x_qrsp, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_qrsp(q,r,s,p)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_q, dim_r, dim_s, dim_p), intent(in) :: x_qrsp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_qrsp(q, r, s, p)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_2341_to_1234


   subroutine add_2314_to_1234(scalar, x_qrps, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_qrsp(q,r,s,p)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_q, dim_r, dim_p, dim_s), intent(in) :: x_qrps

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_qrps(q, r, p, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_2314_to_1234


   subroutine add_2143_to_1234(scalar, x_qpsr, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x(q,p,s,r)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_q, dim_p, dim_s, dim_r), intent(in) :: x_qpsr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_qpsr(q, p, s, r)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_2143_to_1234


   subroutine add_2134_to_1234(scalar, x_qprs, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Sarai D. Folkestad,
      !! Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_qprs(q,p,r,s)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_q, dim_p, dim_r, dim_s), intent(in) :: x_qprs

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_qprs(q, p, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_2134_to_1234


   subroutine add_3214_to_1234(scalar, x_rqps, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x(r,q,p,s)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_r, dim_q, dim_p, dim_s), intent(in) :: x_rqps

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_rqps(r, q, p, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_3214_to_1234


   subroutine add_4231_to_1234(scalar, x_sqrp, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x(s,q,r,p)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_s, dim_q, dim_r, dim_p), intent(in) :: x_sqrp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_sqrp(s, q, r, p)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_4231_to_1234


   subroutine add_2413_to_1234(scalar, x_qspr, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Sarai D. Folkestad,
      !! Eirik F. Kjoenstad and Alexander C. Paul, Jan 2019
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_qspr(q,s,p,r)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_q, dim_s, dim_p, dim_r), intent(in) :: x_qspr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_qspr(q, s, p, r)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_2413_to_1234


   subroutine add_2431_to_1234(scalar, x_qsrp, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Sarai D. Folkestad,
      !! Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_qsrp(q,s,r,p)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_q, dim_s, dim_r, dim_p), intent(in) :: x_qsrp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_qsrp(q, s, r, p)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_2431_to_1234


   subroutine add_4213_to_1234(scalar, x_sqpr, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_sqpr(s,q,p,r)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_s, dim_q, dim_p, dim_r), intent(in) :: x_sqpr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_sqpr(s, q, p, r)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_4213_to_1234


   subroutine add_4321_to_1234(scalar, x_srqp, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_srqp(s,r,q,p)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_s, dim_r, dim_q, dim_p), intent(in) :: x_srqp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_srqp(s, r, q, p)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_4321_to_1234


   subroutine sort_to_4321(x_pqrs, x_srqp, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad, Rolf H. Myhre and Andreas Skeidsvoll, 2018
      !!
      !! Reorders the array x_pqrs to x_srqp (i.e., 1234 to 4321).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_s, dim_r, dim_q, dim_p), intent(out) :: x_srqp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do p = 1, dim_p
         do q = 1, dim_q
            do r = 1, dim_r
               do s = 1, dim_s

                  x_srqp(s, r, q, p) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_4321


   subroutine add_4123_to_1234(scalar, x_spqr, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_spqr(s,p,q,r)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_s, dim_p, dim_q, dim_r), intent(in) :: x_spqr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_spqr(s, p, q, r)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_4123_to_1234


   subroutine add_4132_to_1234(scalar, x_sprq, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_sprq(s,p,r,q)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_s, dim_p, dim_r, dim_q), intent(in) :: x_sprq

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_sprq(s, p, r, q)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_4132_to_1234


   subroutine add_4312_to_1234(scalar, x_srpq, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad, Rolf H. Myhre and Tor S. Haugland, Dec 2017 - 2023
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x_srpq(s,r,p,q)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_s, dim_r, dim_p, dim_q), intent(in) :: x_srpq

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_srpq(s, r, p, q)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_4312_to_1234


   subroutine add_3241_to_1234(scalar, x_rqsp, y_pqrs, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Add 3241 to 1234
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Performs:
      !!
      !!    y_pqrs(p,q,r,s) = y_pqrs(p,q,r,s) + scalar * x(r,q,s,p)
      !!
      implicit none

      real(dp), intent(in) :: scalar

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(inout) :: y_pqrs
      real(dp), dimension(dim_r, dim_q, dim_s, dim_p), intent(in) :: x_rqsp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do r = 1, dim_r
            do q = 1, dim_q
               do p = 1, dim_p

                  y_pqrs(p, q, r, s) = y_pqrs(p, q, r, s) + scalar * x_rqsp(r, q, s, p)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_3241_to_1234


   subroutine squareup_and_sort_to_1432(x_pqrs, x_psrq, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the packed array x_pqrs to unpacked x_psrq (i.e., 1234 to 1432).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(((dim_p * dim_q + 1) * (dim_r * dim_s)) / 2), intent(in) :: x_pqrs
      real(dp), dimension(dim_p, dim_s, dim_r, dim_q), intent(out) :: x_psrq

      integer :: p, q, r, s, pq, rs, pqrs

      !$omp parallel do schedule(static) private(s,r,q,p,pq,rs,pqrs)
      do q = 1, dim_q
         do r = 1, dim_r
            do s = 1, dim_s

               rs = dim_r * (s - 1) + r

               do p = 1, dim_p

                  pq = dim_p * (q - 1) + p

                  pqrs = (max(pq, rs) * (max(pq, rs) - 3) / 2) + pq + rs

                  x_psrq(p, s, r, q) = x_pqrs(pqrs)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine squareup_and_sort_to_1432


   subroutine squareup_and_sort_to_1243(x_pqrs, x_pqsr, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the packed array x_pqrs to unpacked x_pqsr (i.e., 1234 to 1432).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(((dim_p * dim_q + 1) * (dim_r * dim_s)) / 2), intent(in) :: x_pqrs
      real(dp), dimension(dim_p, dim_q, dim_s, dim_r), intent(out) :: x_pqsr

      integer :: p, q, r, s, pq, rs, pqrs

      !$omp parallel do schedule(static) private(s,r,q,p,pq,rs,pqrs)
      do r = 1, dim_r
         do s = 1, dim_s

            rs = dim_r * (s - 1) + r

            do q = 1, dim_q
               do p = 1, dim_p

                  pq = dim_p * (q - 1) + p
                  pqrs = (max(pq, rs) * (max(pq, rs) - 3) / 2) + pq + rs

                  x_pqsr(p, q, s, r) = x_pqrs(pqrs)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine squareup_and_sort_to_1243


   subroutine squareup_and_sort_to_1423(x_pqrs, x_psqr, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the packed array x_pqrs to unpacked x_psqr (i.e., 1234 to 1423).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(((dim_p * dim_q + 1) * (dim_r * dim_s)) / 2), intent(in) :: x_pqrs
      real(dp), dimension(dim_p, dim_s, dim_q, dim_r), intent(out) :: x_psqr

      integer :: p, q, r, s, pq, rs, pqrs

      !$omp parallel do schedule(static) private(s,r,q,p,pq,rs,pqrs)
      do r = 1, dim_r
         do q = 1, dim_q
            do s = 1, dim_s

               rs = dim_r * (s - 1) + r

               do p = 1, dim_p

                  pq = dim_p * (q - 1) + p
                  pqrs = (max(pq, rs) * (max(pq, rs) - 3) / 2) + pq + rs

                  x_psqr(p, s, q, r) = x_pqrs(pqrs)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine squareup_and_sort_to_1423


   subroutine sort_to_3214(x_pqrs, x_rqps, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pq_rs to x_rq_ps (i.e., 1234 to 3214).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_r, dim_q, dim_p, dim_s), intent(out) :: x_rqps

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do s = 1, dim_s
         do p = 1, dim_p
            do q = 1, dim_q
               do r = 1, dim_r

                  x_rqps(r, q, p, s) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_3214


   subroutine sort_to_4231(x_pqrs, x_sqrp, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_sqrp (i.e., 1234 to 4231).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_s, dim_q, dim_r, dim_p), intent(out) :: x_sqrp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do p = 1, dim_p
         do r = 1, dim_r
            do q = 1, dim_q
               do s = 1, dim_s

                  x_sqrp(s, q, r, p) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_4231


   subroutine sort_to_4213(x_pqrs, x_sqpr, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pq_rs to x_sq_pr (i.e., 1234 to 4213).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_s, dim_q, dim_p, dim_r), intent(out) :: x_sqpr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do r = 1, dim_r
         do p = 1, dim_p
            do q = 1, dim_q
               do s = 1, dim_s

                  x_sqpr(s, q, p, r) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_4213


   subroutine sort_to_3241(x_pqrs, x_rqsp, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_rqsp (i.e., 1234 to 3241).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_r, dim_q, dim_s, dim_p), intent(out) :: x_rqsp

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(s,r,q,p)
      do p = 1, dim_p
         do s = 1, dim_s
            do q = 1, dim_q
               do r = 1, dim_r

                  x_rqsp(r, q, s, p) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_3241


   subroutine sort_to_1243(x_pqrs, x_pqsr, dim_p, dim_q, dim_r, dim_s)
      !!
      !! Written by Eirik F. Kjoenstad and Rolf H. Myhre, Dec 2017
      !!
      !! Reorders the array x_pqrs to x_pqsr (i.e., 1234 to 1243).
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s), intent(in) :: x_pqrs
      real(dp), dimension(dim_p, dim_q, dim_s, dim_r), intent(out) :: x_pqsr

      integer :: p, q, r, s

      !$omp parallel do schedule(static) private(p, q, r, s)
      do r = 1, dim_r
         do s = 1, dim_s
            do q = 1, dim_q
               do p = 1, dim_p

                  x_pqsr(p, q, s, r) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_1243


   subroutine sort_to_1243_subblock(x_pqrs, x_pqsr, p_range, q_range, r_range, s_range)
      !!
      !! Written by Marcus T. Lexander 2023
      !!
      !! Reorders the array x_pqrs to a subblock of x_pqsr (i.e., 1234 to 1243).
      !!
      use range_class

      implicit none

      class(range_), intent(in) :: p_range, q_range, r_range, s_range

      real(dp), dimension(p_range%length, q_range%length, r_range%length, s_range%length), intent(in) :: &
         x_pqrs
      real(dp), dimension(:, :, :, :), intent(out) :: x_pqsr

      integer :: p, q, r, s, pp, qq, rr, ss

      !$omp parallel do schedule(static) private(p, q, r, s, pp, qq, rr, ss)
      do s = 1, s_range%length
         ss = s_range%first + (s - 1) * s_range%step

         do r = 1, r_range%length
            rr = r_range%first + (r - 1) * r_range%step

            do q = 1, q_range%length
               qq = q_range%first + (q - 1) * q_range%step

               do p = 1, p_range%length
                  pp = p_range%first + (p - 1) * p_range%step

                  x_pqsr(pp, qq, ss, rr) = x_pqrs(p, q, r, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_1243_subblock

   ! -::- Squareup and packin and related routines -::-
   ! --------------------------------------------------

   subroutine add_to_packed(packed, unpacked, N)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, Jan 2017
      !!
      !! Adds a symmetric unpacked N x N matrix to a packed N x N
      !! matrix.
      !!
      implicit none

      integer, intent(in) :: N

      real(dp), dimension(N * (N + 1) / 2), intent(inout) :: packed
      real(dp), dimension(N, N), intent(in) :: unpacked

      integer :: i, j, ij

      !$omp parallel do schedule(static) private(i,j, ij)
      do i = 1, N
         do j = i, N
            ij = (max(i, j) * (max(i, j) - 3) / 2) + i + j
            packed(ij) = packed(ij) + unpacked(i, j)
         end do
      end do
      !$omp end parallel do

   end subroutine add_to_packed


   subroutine symmetrize_and_add_rank_2_to_packed(packed, unpacked, N)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, Jan 2017
      !!
      !! Symmetrizes unpacked N x N matrix and adds the symmtrized sum
      !! to a packed N x N matrix.
      !!
      implicit none

      integer, intent(in) :: N

      real(dp), dimension(N * (N + 1) / 2), intent(out) :: packed
      real(dp), dimension(N, N), intent(in) :: unpacked

      integer :: i, j, ij

      !$omp parallel do schedule(static) private(i,j, ij)
      do i = 1, N
         do j = i, N
            ij = (max(i, j) * (max(i, j) - 3) / 2) + i + j
            packed(ij) = packed(ij) + unpacked(i, j) + unpacked(j, i)
         end do
      end do
      !$omp end parallel do

   end subroutine symmetrize_and_add_rank_2_to_packed


   subroutine symmetrize_and_add_rank_4_to_packed(packed, unpacked, N)
      !!
      !! Written by Andreas Skeidsvoll, Sep 2019
      !!
      !! Symmetrizes 4-dimensional unpacked matrix and adds the symmetrized sum
      !! to a packed matrix.
      !!
      implicit none

      integer, intent(in) :: N

      real(dp), dimension(N * (N + 1) / 2), intent(out) :: packed
      real(dp), dimension(:, :, :, :), intent(in) :: unpacked

      call symmetrize_and_add_rank_2_to_packed(packed, unpacked, N)

   end subroutine symmetrize_and_add_rank_4_to_packed


   subroutine symmetrize_add_contra_1324_to_packed(x, y, dim_p, dim_q)
      !!
      !! Written by Rolf H. Myhre and Alexander C. Paul, Aug 2020
      !!
      !! Symmetrize and add an unsymmetric unpacked pq x rs matrix ordered prqs
      !!    (2 X_pqrs - X_rqps)
      !! to a packed symmetric matrix Y_pqrs
      !!
      !! Performs:
      !!
      !!    Y_pqrs = 1/3(2X_pqrs + X_rqps + 2X_rspq + X_psrq)
      !!
      !! Note that this routine requires dim_p = dim_r and dim_q = dim_s
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q

      real(dp), dimension(dim_p, dim_p, dim_q, dim_q), intent(in) :: x
      real(dp), dimension(dim_p * dim_q * (dim_p * dim_q + 1) / 2), intent(inout) :: y

      integer :: p, q, r, s, pq, rs, pqrs, p_end

      !$omp parallel do schedule(static) collapse(2) private(s,r,q,p,pq,rs,pqrs,p_end)
      do s = 1, dim_q
         do r = 1, dim_p
            do q = 1, s

               if (s /= q) then
                  p_end = dim_p
               else
                  p_end = r
               end if

               do p = 1, p_end

                  pq = dim_p * (q - 1) + p
                  rs = dim_p * (s - 1) + r
                  pqrs = max(pq, rs) * (max(pq, rs) - 3) / 2 + pq + rs

                  y(pqrs) = y(pqrs) &
                            + third &
                            * (two * x(p, r, q, s) + x(r, p, q, s) + two * x(r, p, s, q) + x(p, r, s, q))

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine symmetrize_add_contra_1324_to_packed


   subroutine symmetrize_add_contra_to_packed(x, y, dim_p, dim_q)
      !!
      !! Written by Rolf H. Myhre and Alexander C. Paul and Tor S. Haugland, 2023
      !!
      !! Symmetrize and add an unsymmetric unpacked pq x rs matrix ordered prqs
      !!    (2 X_pqrs - X_rqps)
      !! to a packed symmetric matrix Y_pqrs
      !!
      !! Performs:
      !!
      !!    Y_pqrs = 1/3(2X_pqrs + X_rqps + 2X_rspq + X_psrq)
      !!
      !! Note that this routine requires dim_p = dim_r and dim_q = dim_s
      !!
      !! Edited, added 1234 variant.
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q

      real(dp), dimension(dim_p, dim_q, dim_p, dim_q), intent(in) :: x
      real(dp), dimension(dim_p * dim_q * (dim_p * dim_q + 1) / 2), intent(inout) :: y

      integer :: p, q, r, s, pq, rs, pqrs, p_end

      !$omp parallel do schedule(static) collapse(2) private(s,r,q,p,pq,rs,pqrs,p_end)
      do s = 1, dim_q
         do r = 1, dim_p
            do q = 1, s

               if (s /= q) then
                  p_end = dim_p
               else
                  p_end = r
               end if

               do p = 1, p_end

                  pq = dim_p * (q - 1) + p
                  rs = dim_p * (s - 1) + r
                  pqrs = max(pq, rs) * (max(pq, rs) - 3) / 2 + pq + rs

                  y(pqrs) = y(pqrs) &
                            + third &
                            * (two * x(p, q, r, s) + x(p, s, r, q) + two * x(r, s, p, q) + x(r, q, p, s))

               end do
            end do
         end do
      end do
      !$omp end parallel do


   end subroutine symmetrize_add_contra_to_packed


   subroutine symmetrize_add_to_packed(x, y, dim_p, dim_q)
      !!
      !! Written by Rolf H. Myhre and Alexander C. Paul, Aug 2020
      !!
      !! Symmetrize and add an unsymmetric unpacked pq x rs matrix X_prqs
      !! to a packed symmetric matrix Y_pqrs
      !!
      !! Note that this routine requires dim_p = dim_r and dim_q = dim_s
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q

      real(dp), dimension(dim_p, dim_p, dim_q, dim_q), intent(in) :: x
      real(dp), dimension(dim_p * dim_q * (dim_p * dim_q + 1) / 2), intent(inout) :: y

      integer :: p, q, r, s, pq, rs, pqrs, p_end

      !$omp parallel do schedule(static) collapse(2) private(s,r,q,p,pq,rs,pqrs,p_end)
      do s = 1, dim_q
         do r = 1, dim_p
            do q = 1, s

               if (s /= q) then
                  p_end = dim_p
               else
                  p_end = r
               end if

               do p = 1, p_end

                  pq = dim_p * (q - 1) + p
                  rs = dim_p * (s - 1) + r
                  pqrs = max(pq, rs) * (max(pq, rs) - 3) / 2 + pq + rs

                  y(pqrs) = y(pqrs) + (x(p, r, q, s) + x(r, p, s, q))

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine symmetrize_add_to_packed


   subroutine squareup_anti(packed, unpacked, N)
      !!
      !! Written by Eirik F. Kjoenstad, 2018
      !!
      !! Squares up to full dimension (N x N) of packed matrix. The packed
      !! antisymmetric matrix contains the strictly lower triangular part
      !  of the full unpacked matrix.
      !!
      implicit none

      integer, intent(in) :: N

      real(dp), dimension(N * (N - 1) / 2), intent(in) :: packed
      real(dp), dimension(N, N), intent(out) :: unpacked

      integer :: i, j

      ! Set diagonal to zero

      do i = 1, N

         unpacked(i, i) = zero

      end do

      ! Set lower and upper strictly triangular parts

      do i = 2, N
         do j = 1, i - 1

            unpacked(i, j) = packed((max(i - 1, j) * (max(i - 1, j) - 3) / 2) + i - 1 + j)
            unpacked(j, i) = - packed((max(i - 1, j) * (max(i - 1, j) - 3) / 2) + i - 1 + j)

         end do
      end do

   end subroutine squareup_anti


   subroutine squareup_rank_2(packed, unpacked, N)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, Jan 2017
      !!
      !! Squares up to full dimension (N x N) of packed matrices.
      !!
      implicit none

      integer, intent(in) :: N

      real(dp), dimension(N * (N + 1) / 2), intent(in) :: packed
      real(dp), dimension(N, N), intent(out) :: unpacked

      integer :: i, j

      !$omp parallel do schedule(static) private(i,j)
      do j = 1, N
         do i = 1, N
            unpacked(i, j) = packed((max(i, j) * (max(i, j) - 3) / 2) + i + j)
         end do
      end do
      !$omp end parallel do

   end subroutine squareup_rank_2


   subroutine squareup_and_add(factor, packed, unpacked, N)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, Jan 2017
      !!
      !! Squares up to full dimension (N x N) of packed matrices.
      !!
      implicit none

      integer, intent(in) :: N

      real(dp), intent(in) :: factor
      real(dp), dimension(N * (N + 1) / 2), intent(in) :: packed
      real(dp), dimension(N, N), intent(inout) :: unpacked

      integer :: i, j, ij_packed

      !$omp parallel do schedule(static) private(i, j, ij_packed)
      do j = 1, N
         do i = 1, N
            ij_packed = (max(i, j) * (max(i, j) - 3) / 2) + i + j
            unpacked(i, j) = unpacked(i, j) + factor * packed(ij_packed)
         end do
      end do
      !$omp end parallel do

   end subroutine squareup_and_add


   subroutine squareup_rank_1(packed, unpacked, N)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, Jan 2017
      !!
      !! Squares up to full dimension (N x N) of packed matrices.
      !!
      implicit none

      integer, intent(in) :: N

      real(dp), dimension(N * (N + 1) / 2), intent(in) :: packed
      real(dp), dimension(N**2), intent(out) :: unpacked

      integer :: i, j, ij

      !$omp parallel do schedule(static) private(i,j,ij)
      do j = 1, N
         do i = 1, N

            ij = N * (j - 1) + i
            unpacked(ij) = packed((max(i, j) * (max(i, j) - 3) / 2) + i + j)

         end do
      end do
      !$omp end parallel do

   end subroutine squareup_rank_1


   subroutine squareup_rank_4(packed, unpacked, N)
      !!
      !! Written by Andreas Skeidsvoll, Sep 2019
      !!
      !! Squares up to full dimension of four dimensional packed matrices.
      !!
      implicit none

      integer, intent(in) :: N

      real(dp), dimension(N * (N + 1) / 2), intent(in) :: packed
      real(dp), dimension(:, :, :, :), intent(out) :: unpacked

      call squareup_rank_2(packed, unpacked, N)

   end subroutine squareup_rank_4


   subroutine packin_rank_2(packed, unpacked, N)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, Jan 2017
      !!
      !! Pack down full square matrix of dimension N x N.
      !!
      implicit none

      integer, intent(in) :: N

      real(dp), dimension(N * (N + 1) / 2), intent(out) :: packed
      real(dp), dimension(n, N), intent(in) :: unpacked

      integer :: i, j

      !$omp parallel do schedule(static) private(i,j)
      do i = 1, N
         do j = 1, i

            packed((max(i, j) * (max(i, j) - 3) / 2) + i + j) = unpacked(i, j)

         end do
      end do
      !$omp end parallel do

   end subroutine packin_rank_2


   subroutine packin_rank_4(packed, unpacked, N)
      !!
      !! Written by Andreas Skeidsvoll, Sep 2019
      !!
      !! Pack down full 4-dimensional square matrix.
      !!
      implicit none

      integer, intent(in) :: N

      real(dp), dimension(N * (N + 1) / 2), intent(out) :: packed
      real(dp), dimension(:, :, :, :), intent(in) :: unpacked

      call packin_rank_2(packed, unpacked, N)

   end subroutine packin_rank_4


   subroutine packin_rank_4_from_1324_order(packed, unpacked, dim_p, dim_q)
      !!
      !! Written by Rolf H. Myhre, Oct 2019
      !!
      !! Pack in unpacked array X_prqs to packed array Y_pqrs
      !! where dim_p = dim_r and dim_q = dim_s
      !!
      implicit none

      integer, intent(in) :: dim_p
      integer, intent(in) :: dim_q

      real(dp), dimension(dim_p * dim_q * (dim_p * dim_q + 1) / 2), intent(out) :: packed
      real(dp), dimension(dim_p, dim_p, dim_q, dim_q), intent(in) :: unpacked

      integer :: p, q, r, s, pq, rs, pqrs, r_end

      !$omp parallel do schedule(static) private(p, q, r, s, pq, rs, pqrs, r_end)
      do q = 1, dim_q
         do p = 1, dim_p

            pq = dim_p * (q - 1) + p

            do s = 1, q

               if (s /= q) then
                  r_end = dim_p
               else
                  r_end = p
               end if

               do r = 1, r_end

                  rs = dim_p * (s - 1) + r

                  pqrs = pq * (pq - 3) / 2 + pq + rs

                  packed(pqrs) = unpacked(p, r, q, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine packin_rank_4_from_1324_order


   subroutine packin_and_add_from_1324_order(packed, unpacked, dim_p, dim_q)
      !!
      !! Written by Rolf H. Myhre, Oct 2019
      !!
      !! Almost identical to non-adding routine by Rolf H. Myhre, Oct 2019
      !!
      !! Pack in unpacked array X_prqs to packed array Y_pqrs
      !! where dim_p = dim_r and dim_q = dim_s
      !!
      implicit none

      integer, intent(in) :: dim_p
      integer, intent(in) :: dim_q

      real(dp), dimension(dim_p * dim_q * (dim_p * dim_q + 1) / 2), intent(inout) :: packed
      real(dp), dimension(dim_p, dim_p, dim_q, dim_q), intent(in) :: unpacked

      integer :: p, q, r, s, pq, rs, pqrs, r_end

      !$omp parallel do schedule(static) private(p, q, r, s, pq, rs, pqrs, r_end)
      do q = 1, dim_q
         do p = 1, dim_p

            pq = dim_p * (q - 1) + p

            do s = 1, q

               if (s /= q) then
                  r_end = dim_p
               else
                  r_end = p
               end if

               do r = 1, r_end

                  rs = dim_p * (s - 1) + r

                  pqrs = pq * (pq - 3) / 2 + pq + rs

                  packed(pqrs) = packed(pqrs) + unpacked(p, r, q, s)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine packin_and_add_from_1324_order


   subroutine packin_anti(packed, unpacked, N)
      !!
      !! Written by Eirik F. Kjoenstad, 2018
      !!
      !! Pack down full square anti-symmetric matrix of dimension N x N,
      !! where the strictly lower triangular part of the unpacked matrix
      !! is stored in packed form.
      !!
      implicit none

      integer, intent(in) :: N

      real(dp), dimension(N * (N - 1) / 2), intent(out) :: packed
      real(dp), dimension(N, N), intent(in) :: unpacked

      integer :: i, j

      do i = 2, N
         do j = 1, i - 1

            packed((max(i - 1, j) * (max(i - 1, j) - 3) / 2) + i - 1 + j) = unpacked(i, j)

         end do
      end do

   end subroutine packin_anti


   subroutine construct_packed_contravariant(x, y, dim_p, dim_q)
      !!
      !! Written by Rolf H. Myhre and Alexander C. Paul, Aug 2020
      !!
      !! Constructs
      !!    Y_pqrs = (2 X_pqrs - X_rqps) for packed arrays X and Y
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q

      real(dp), dimension(dim_p * dim_q * (dim_p * dim_q + 1) / 2), intent(in) :: x
      real(dp), dimension(dim_p * dim_q * (dim_p * dim_q + 1) / 2), intent(inout) :: y

      integer :: p, q, r, s, pq, rs, pqrs, p_end, rq, ps, rqps

      !$omp parallel do schedule(static) collapse(2) &
      !$omp private(p, q, r, s, rs, rq, pq, ps, pqrs, rqps, p_end)
      do s = 1, dim_q
         do r = 1, dim_p

            rs = dim_p * (s - 1) + r

            do q = 1, s

               rq = dim_p * (q - 1) + r

               if (s /= q) then
                  p_end = dim_p
               else
                  p_end = r
               end if

               do p = 1, p_end

                  pq = dim_p * (q - 1) + p
                  ps = dim_p * (s - 1) + p
                  pqrs = rs * (rs - 3) / 2 + pq + rs
                  rqps = max(rq, ps) * (max(rq, ps) - 3) / 2 + rq + ps

                  y(pqrs) = (two * x(pqrs) - x(rqps))

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine construct_packed_contravariant


   subroutine construct_packed_covariant(x, y, dim_p, dim_q)
      !!
      !! Written by Rolf H. Myhre and Alexander C. Paul, Aug 2020
      !!
      !! Constructs:
      !!    Y_pqrs = 1/3(2X_pqrs + X_rqps)
      !!
      !! Note that this routine requires dim_p = dim_r and dim_q = dim_s
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q

      real(dp), dimension(dim_p * dim_q * (dim_p * dim_q + 1) / 2), intent(in) :: x
      real(dp), dimension(dim_p * dim_q * (dim_p * dim_q + 1) / 2), intent(out) :: y

      integer :: p, q, r, s, pq, rs, pqrs, p_end, rq, ps, rqps

      !$omp parallel do schedule(static) collapse(2) &
      !$omp private(p,q,r,s,rs, rq, pq, ps, pqrs, rqps, p_end)
      do s = 1, dim_q
         do r = 1, dim_p

            rs = dim_p * (s - 1) + r

            do q = 1, s

               rq = dim_p * (q - 1) + r

               if (s /= q) then
                  p_end = dim_p
               else
                  p_end = r
               end if

               do p = 1, p_end

                  pq = dim_p * (q - 1) + p
                  ps = dim_p * (s - 1) + p
                  pqrs = rs * (rs - 3) / 2 + pq + rs
                  rqps = max(rq, ps) * (max(rq, ps) - 3) / 2 + rq + ps

                  y(pqrs) = third * (two * x(pqrs) + x(rqps))

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine construct_packed_covariant


   subroutine construct_covariant_1324(x_pqrs, y_prqs, dim_p, dim_q)
      !!
      !! Written by Alexander C. Paul, Jan 2021
      !!
      !! Constructs:
      !!    Y_prqs = 1/3(2X_pqrs + X_rqps)
      !! from packed vector x_pqrs
      !!
      !! Note that this routine requires dim_p = dim_r and dim_q = dim_s
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q

      real(dp), dimension(((dim_p * dim_q + 1) * (dim_p * dim_q) / 2)), intent(in) :: x_pqrs
      real(dp), dimension(dim_p, dim_p, dim_q, dim_q), intent(out) :: y_prqs

      integer :: p, q, r, s, pq, rs, ps, rq, pqrs, rqps

      !$omp parallel do schedule(static) private(s,r,q,p, rs, rq, pq, ps, pqrs, rqps)
      do s = 1, dim_q
         do q = 1, dim_q
            do r = 1, dim_p

               rs = dim_p * (s - 1) + r
               rq = dim_p * (q - 1) + r

               do p = 1, dim_p

                  pq = dim_p * (q - 1) + p
                  ps = dim_p * (s - 1) + p

                  pqrs = max(pq, rs) * (max(pq, rs) - 3) / 2 + pq + rs
                  rqps = max(rq, ps) * (max(rq, ps) - 3) / 2 + rq + ps

                  y_prqs(p, r, q, s) = third * (two * x_pqrs(pqrs) + x_pqrs(rqps))

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine construct_covariant_1324


   subroutine construct_contravariant_t3(t, u, dim_)
      !!
      !! Written by Rolf H. Myhre and Alexander C. Paul, August 2020
      !!
      !! Construct:
      !!    t_pqr = 4t_pqr - 2t_qpr - 2t_rqp - 2t_prq + t_qrp + t_rpq
      !!
      use array_initialization, only: copy_and_scale

      implicit none

      integer, intent(in) :: dim_

      real(dp), dimension(dim_, dim_, dim_), intent(inout) :: t
      real(dp), dimension(dim_, dim_, dim_), intent(out) :: u

      call copy_and_scale(two, t, u, dim_**3)
      call add_132_to_123(- one, t, u, dim_, dim_, dim_)
      call add_321_to_123(- one, t, u, dim_, dim_, dim_)

      call copy_and_scale(two, u, t, dim_**3)

      call add_213_to_123(- one, u, t, dim_, dim_, dim_)

   end subroutine construct_contravariant_t3


   subroutine antisymmetric_sum(x, dim_)
      !!
      !! Written by Eirik F. Kjoenstad, Dec 2017
      !!
      !! Performs the action
      !!
      !!    x(p,q) = x(p,q) - x(q,p)
      !!
      !! without making a separate copy of x.
      !!
      !! Note: the effect is equal to the routine "add_21_to_12" with scalar = -1,
      !!       where a second copy of x is not needed.
      !!
      implicit none

      integer, intent(in) :: dim_

      real(dp), dimension(dim_, dim_), intent(inout) :: x

      integer :: p, q

      ! Overwrite the lower triangular part of the matrix

      !$omp parallel do private(p, q)
      do q = 1, dim_
         do p = q, dim_

            x(p, q) = x(p, q) - x(q, p)

         end do
      end do
      !$omp end parallel do

      ! Copy the lower triangular part to the upper triangular part

      !$omp parallel do private(p, q)
      do p = 1, dim_
         do q = p + 1, dim_

            x(p, q) = - x(q, p)

         end do
      end do
      !$omp end parallel do

   end subroutine antisymmetric_sum


   subroutine antisymmetrize(x, y, dim_)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      implicit none

      integer, intent(in) :: dim_

      real(dp), dimension(dim_, dim_), intent(in) :: x
      real(dp), dimension(dim_, dim_), intent(out) :: y

      integer :: q, k

      !$omp parallel do private(q,k) schedule(static)
      do q = 1, dim_
         do k = 1, dim_

            y(q, k) = half * (x(q, k) - x(k, q))

         end do
      end do
      !$omp end parallel do

   end subroutine antisymmetrize


   subroutine sort_to_rank6(x_pqrstu, x_perm, dims, perm)
      !!
      !! Written by Tor S. Haugland and Marcus T. Lexander, 2023
      !!
      !! Reorders x_pqrstu to x_perm(pqrstu).
      !! dims is an array of the dimensions of 'x_pqrstu'.
      !!
      implicit none

      real(dp), dimension(:, :, :, :, :, :), intent(in) :: x_pqrstu
      real(dp), dimension(:, :, :, :, :, :), intent(out) :: x_perm
      integer, dimension(6), intent(in) :: dims
      integer, dimension(6), intent(in) :: perm

      integer :: p, q, r, s, t, u
      integer, dimension(6) :: i1, i2

      !$omp parallel do schedule(static) private(p,q,r,s,t,u,i1,i2) collapse(3)
      do u = 1, dims(6)
         do t = 1, dims(5)
            do s = 1, dims(4)
               do r = 1, dims(3)
                  do q = 1, dims(2)
                     do p = 1, dims(1)
                        i1 = [p, q, r, s, t, u]
                        i2 = i1(perm)
                        x_perm(i2(1), i2(2), i2(3), i2(4), i2(5), i2(6)) = x_pqrstu(p, q, r, s, t, u)
                     end do
                  end do
               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_rank6


   subroutine add_to_rank6(scalar, x_perm, y_pqrstu, dims, perm)
      !!
      !! Written by Tor S. Haugland and Marcus T. Lexander, 2023
      !!
      !! y(pqrstu) = y(pqrstu) + scalar * x(perm(pqrstu))
      !! dims is an array of the dimensions of 'y_pqrstu'.
      !!
      implicit none

      real(dp), intent(in) :: scalar
      real(dp), dimension(:, :, :, :, :, :), intent(in) :: x_perm
      real(dp), dimension(:, :, :, :, :, :), intent(inout) :: y_pqrstu
      integer, dimension(6), intent(in) :: dims
      integer, dimension(6), intent(in) :: perm

      integer :: p, q, r, s, t, u
      integer, dimension(6) :: i1, i2

      !$omp parallel do schedule(static) private(p,q,r,s,t,u,i1,i2) collapse(3)
      do u = 1, dims(6)
         do t = 1, dims(5)
            do s = 1, dims(4)
               do r = 1, dims(3)
                  do q = 1, dims(2)
                     do p = 1, dims(1)
                        i1 = [p, q, r, s, t, u]
                        i2 = i1(perm)

                        y_pqrstu(p, q, r, s, t, u) = y_pqrstu(p, q, r, s, t, u) &
                                                     + scalar &
                                                     * x_perm(i2(1), i2(2), i2(3), i2(4), i2(5), i2(6))

                     end do
                  end do
               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_to_rank6


   subroutine symmetric_sum_triples(x, dim_)
      !!
      !! Written by Tor S. Haugland, 2023
      !!
      !! x(p,q,r) = x(p,q,r) + x(q,p,r) + x(r,q,p) + x(p,r,q) + x(r,p,q) + x(q,r,p)
      !!
      !! without making a separate copy of x.
      !!
      implicit none

      integer, intent(in) :: dim_

      real(dp), dimension(dim_, dim_, dim_), intent(inout) :: x

      integer :: p, q, r

      !$omp parallel private(p, q, r)
      !$omp do
      do r = 1, dim_
         do q = r, dim_
            do p = q, dim_
               x(p, q, r) = x(p, q, r) + x(q, p, r) + x(r, q, p) + x(p, r, q) + x(r, p, q) + x(q, r, p)
            end do
         end do
      end do
      !$omp end do

      !$omp do
      do r = 1, dim_
         do p = r, dim_
            do q = p, dim_
               x(p, q, r) = x(q, p, r)
            end do
         end do
      end do
      !$omp end do

      !$omp do
      do p = 1, dim_
         do q = p, dim_
            do r = q, dim_
               x(p, q, r) = x(r, q, p)
            end do
         end do
      end do
      !$omp end do

      !$omp do
      do p = 1, dim_
         do r = p, dim_
            do q = r, dim_
               x(p, q, r) = x(q, r, p)
            end do
         end do
      end do
      !$omp end do

      !$omp do
      do q = 1, dim_
         do p = q, dim_
            do r = p, dim_
               x(p, q, r) = x(r, p, q)
            end do
         end do
      end do
      !$omp end do

      !$omp do
      do q = 1, dim_
         do r = q, dim_
            do p = r, dim_
               x(p, q, r) = x(p, r, q)
            end do
         end do
      end do
      !$omp end do
      !$omp end parallel

   end subroutine symmetric_sum_triples


   subroutine packin_cube_rank_3(packed, unpacked, N)
      !!
      !! Written by Tor S. Haugland, 2023
      !!
      !! Pack down full cube matrix of dimension N x N x N.
      !!
      implicit none

      integer, intent(in) :: N
      real(dp), dimension((N * (N + 1) * (N + 2)) / 6), intent(out) :: packed
      real(dp), dimension(N, N, N), intent(in) :: unpacked

      integer :: i, j, k, ijk

      !$omp parallel do schedule(dynamic) private(i, j, k, ijk)
      do i = 1, N
         do j = 1, i
            do k = 1, j
               ijk = (i - 1) * i * (i + 1) / 6 + j * (j - 1) / 2 + k
               packed(ijk) = unpacked(i, j, k)
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine packin_cube_rank_3


   subroutine packin_cube_rank_6(packed, unpacked, N)
      !!
      !! Written by Tor S. Haugland, 2023
      !!
      !! Pack down full cube matrix of dimension N x N x N.
      !!
      implicit none

      integer, intent(in) :: N
      real(dp), dimension((N * (N + 1) * (N + 2)) / 6), intent(out) :: packed
      real(dp), dimension(:, :, :, :, :, :), intent(in) :: unpacked

      call packin_cube_rank_3(packed, unpacked, N)

   end subroutine packin_cube_rank_6


   subroutine squareup_cube_rank_3(packed, unpacked, N)
      !!
      !! Written by Tor S. Haugland, 2023
      !!
      !! Squares up to full dimension (N x N x N) of packed cubic matrix.
      !!
      implicit none

      integer, intent(in) :: N
      real(dp), dimension((N * (N + 1) * (N + 2)) / 6), intent(in) :: packed
      real(dp), dimension(N, N, N), intent(out) :: unpacked

      integer :: i, j, k, ijk

      !$omp parallel do schedule(dynamic) private(i, j, k, ijk)
      do i = 1, N
         do j = 1, i
            do k = 1, j
               ijk = (i - 1) * i * (i + 1) / 6 + j * (j - 1) / 2 + k
               unpacked(i, j, k) = packed(ijk)
               unpacked(i, k, j) = packed(ijk)
               unpacked(j, i, k) = packed(ijk)
               unpacked(j, k, i) = packed(ijk)
               unpacked(k, j, i) = packed(ijk)
               unpacked(k, i, j) = packed(ijk)
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine squareup_cube_rank_3


   subroutine squareup_cube_rank_6(packed, unpacked, N)
      !!
      !! Written by Tor S. Haugland, 2023
      !!
      !! Squares up to full dimension (N x N x N) of packed cubic matrix.
      !!
      implicit none

      integer, intent(in) :: N
      real(dp), dimension((N * (N + 1) * (N + 2)) / 2), intent(in) :: packed
      real(dp), dimension(:, :, :, :, :, :), intent(out) :: unpacked

      call squareup_cube_rank_3(packed, unpacked, N)

   end subroutine squareup_cube_rank_6


   subroutine add_to_subblock_rank_2(scalar, x, y, p_range, q_range)
      !!
      !! Written by Alexander C. Paul, Apr 2021
      !!
      !! Add elements of x to the block of y defined by first/last p and q.
      !! y is assumed to
      !!
      use range_class

      implicit none

      real(dp), intent(in) :: scalar
      class(range_), intent(in) :: p_range, q_range

      real(dp), dimension(:, :), intent(inout) :: y
      real(dp), dimension(p_range%length, q_range%length), intent(in) :: x

      integer :: p, q, pp, qq

      !$omp parallel do schedule(static) private(p,q, pp, qq)
      do q = 1, q_range%length
         qq = q_range%first + (q - 1) * q_range%step

         do p = 1, p_range%length
            pp = p_range%first + (p - 1) * p_range%step

            y(pp, qq) = y(pp, qq) + scalar * x(p, q)

         end do
      end do
      !$omp end parallel do

   end subroutine add_to_subblock_rank_2


   subroutine sort_to_21345(x_pqrst, x_qprst, dim_p, dim_q, dim_r, dim_s, dim_t)
      !!
      !! Written by Alexander C. Paul, Nov 2023
      !!
      implicit none

      integer, intent(in) :: dim_p, dim_q, dim_r, dim_s, dim_t

      real(dp), dimension(dim_p, dim_q, dim_r, dim_s, dim_t), intent(in) :: x_pqrst
      real(dp), dimension(dim_q, dim_p, dim_r, dim_s, dim_t), intent(out) :: x_qprst

      integer :: p, q, r, s, t

      !$omp parallel do schedule(static) private(p, q, r, s, t), collapse(3)
      do r = 1, dim_r
         do s = 1, dim_s
            do q = 1, dim_q
               do p = 1, dim_p
                  do t = 1, dim_t

                     x_qprst(q, p, r, s, t) = x_pqrst(p, q, r, s, t)

                  end do
               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_to_21345


   subroutine construct_contravariant_rank4_from_packed(x_contra, x, n_1, n_2)
      !!
      !! Written by Sarai D. Folkestad, Jan 2019
      !!
      !! Constructs the contravariant rank-4 tensor
      !!
      !!    2x_aibj - x_ajbi
      !!
      !! from packed x

      use array_initialization, only: copy_and_scale
      use memory_manager_class, only: mem

      implicit none

      integer, intent(in) :: n_1, n_2

      real(dp), dimension(n_1, n_2, n_1, n_2), intent(out) :: x_contra
      real(dp), dimension(n_1 * n_2 * (n_1 * n_2 + 1) / 2), intent(in) :: x

      real(dp), dimension(:, :, :, :), allocatable :: x_aibj

      call mem%alloc(x_aibj, n_1, n_2, n_1, n_2)
      call squareup(x, x_aibj, n_1 * n_2)

      call copy_and_scale(two, x_aibj, x_contra, n_1**2 * n_2**2)
      call add_1432_to_1234(- one, x_aibj, x_contra, n_1, n_2, n_1, n_2)

      call mem%dealloc(x_aibj)

   end subroutine construct_contravariant_rank4_from_packed


   subroutine construct_contravariant_rank4_from_full(x_contra, x, n_1, n_2)
      !!
      !! Written by Sarai D. Folkestad, Jan 2019
      !!
      !! Constructs the contravariant rank-4 tensor
      !!
      !!    2x_aibj - x_ajbi
      !!
      use array_initialization, only: copy_and_scale
      implicit none

      integer, intent(in) :: n_1, n_2

      real(dp), dimension(n_1, n_2, n_1, n_2), intent(out) :: x_contra
      real(dp), dimension(n_1, n_2, n_1, n_2), intent(in) :: x

      call copy_and_scale(two, x, x_contra, n_1**2 * n_2**2)
      call add_1432_to_1234(- one, x, x_contra, n_1, n_2, n_1, n_2)

   end subroutine construct_contravariant_rank4_from_full


   subroutine sort_and_extract_subblock_full(x, x_perm, perm, range_1, range_2, range_3, range_4)
      !!
      !! Written by Sarai D. Folkestad, 2026
      !!
      !! Reorders and extracts elements from subblock of (the large array) x, defined by the ranges 1-4, into y.
      !! Permuted according to 'perm'.
      !!
      !! Note: The provided ranges are given relative to the dimensions of the array x
      !! Note: The provided permutation is relative to the indices in x:
      !!
      !!    y_rqps =  x_pqrs <- perm = [3, 2, 1, 4]
      !!
      use range_class, only: range_
      use array_utilities, only: quicksort_with_index_ascending_int
      implicit none

      real(dp), dimension(:, :, :, :), intent(in) :: x
      real(dp), dimension(:, :, :, :), intent(out) :: x_perm
      integer, dimension(4), intent(in) :: perm

      type(range_), intent(in), optional :: range_1, range_2, range_3, range_4

      integer :: p, q, r, s
      integer, dimension(4) :: idx_x, idx_perm
      integer, dimension(4) :: perm_reverse, permutation_copy

      integer, dimension(4) :: dims
      integer, dimension(4) :: local_firsts

      local_firsts = ([1, 1, 1, 1])
      if (present(range_1)) local_firsts(1) = range_1%first
      if (present(range_2)) local_firsts(2) = range_2%first
      if (present(range_3)) local_firsts(3) = range_3%first
      if (present(range_4)) local_firsts(4) = range_4%first

      dims(1) = size(x_perm, 1)
      dims(2) = size(x_perm, 2)
      dims(3) = size(x_perm, 3)
      dims(4) = size(x_perm, 4)

      permutation_copy = perm
      call quicksort_with_index_ascending_int(permutation_copy, perm_reverse, 4)

      !$omp parallel do schedule(static) private(p,q,r,s,idx_perm,idx_x) collapse(2)
      do s = 1, dims(4)
         do r = 1, dims(3)
            do q = 1, dims(2)
               do p = 1, dims(1)
                  idx_perm = [p, q, r, s]
                  idx_x = idx_perm(perm_reverse)

                  x_perm(p, q, r, s) = x(idx_x(1) + local_firsts(1) - 1, &
                                         idx_x(2) + local_firsts(2) - 1, &
                                         idx_x(3) + local_firsts(3) - 1, &
                                         idx_x(4) + local_firsts(4) - 1)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_and_extract_subblock_full


   subroutine sort_and_extract_subblock_from_packed(x, x_perm, dims, perm, range_1, range_2, range_3, range_4)
      !!
      !! Written by Sarai D. Folkestad, 2026
      !!
      !! Reorders and extracts elements from subblock of (the large and packed array) x, defined by the ranges 1-4, into y.
      !! Permuted according to 'perm'.
      !!
      !! Note: The provided ranges are given relative to the dimensions of the array x
      !! Note: The provided permutation is relative to the indices in x:
      !!
      !!    y_rqps =  x_pqrs <- perm = [3, 2, 1, 4]
      !!
      use range_class, only: range_
      use array_utilities, only: quicksort_with_index_ascending_int
      implicit none

      real(dp), dimension(:), intent(in) :: x
      real(dp), dimension(:, :, :, :), intent(out) :: x_perm
      integer, dimension(4), intent(in) :: dims
      integer, dimension(4), intent(in) :: perm

      type(range_), intent(in), optional :: range_1, range_2, range_3, range_4

      integer :: p, q, r, s, pq, rs, pqrs
      integer, dimension(4) :: idx_x, idx_perm
      integer, dimension(4) :: perm_reverse, permutation_copy

      integer, dimension(4) :: local_dims, local_dims_permuted
      integer, dimension(4) :: local_firsts

      local_firsts = ([1, 1, 1, 1])
      if (present(range_1)) local_firsts(1) = range_1%first
      if (present(range_2)) local_firsts(2) = range_2%first
      if (present(range_3)) local_firsts(3) = range_3%first
      if (present(range_4)) local_firsts(4) = range_4%first

      local_dims = dims
      if (present(range_1)) local_dims(1) = range_1%length
      if (present(range_2)) local_dims(2) = range_2%length
      if (present(range_3)) local_dims(3) = range_3%length
      if (present(range_4)) local_dims(4) = range_4%length

      local_dims_permuted = local_dims(perm)

      permutation_copy = perm
      call quicksort_with_index_ascending_int(permutation_copy, perm_reverse, 4)

      !$omp parallel do schedule(static) private(p,q,r,s,idx_perm,idx_x, pq, rs, pqrs) collapse(2)
      do s = 1, local_dims_permuted(4)
         do r = 1, local_dims_permuted(3)
            do q = 1, local_dims_permuted(2)
               do p = 1, local_dims_permuted(1)

                  idx_perm = [p, q, r, s]
                  idx_x = idx_perm(perm_reverse)

                  pq = dims(1) * (idx_x(2) + local_firsts(2) - 2) + idx_x(1) + local_firsts(1) - 1
                  rs = dims(3) * (idx_x(4) + local_firsts(4) - 2) + idx_x(3) + local_firsts(3) - 1

                  pqrs = max(pq, rs) * (max(pq, rs) - 3) / 2 + pq + rs
                  x_perm(p, q, r, s) = x(pqrs)

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine sort_and_extract_subblock_from_packed


   subroutine add_to_subblock_rank_4(scalar, x, y, perm, range_1, range_2, range_3, range_4)
      !!
      !! Written by Sarai D. Folkestad, 2026
      !!
      !! Add elements of x to the subblock of y defined by the ranges 1-4,
      !! permuted according to 'perm'.
      !!
      !! Note: The provided ranges are ordered according to the dimensions of the array y
      !! Note: The provided permutation is relative to the indices in y:
      !!
      !!    y_pqrs += scalar * x_sqrp <- perm = [4, 2, 3, 1]
      !!
      !! Note that the x is assumed to be allocated in the correct shape.
      !!
      !!
      use range_class
      use array_utilities, only: quicksort_with_index_ascending_int

      implicit none

      real(dp), intent(in) :: scalar
      integer, dimension(4), intent(in) :: perm
      class(range_), intent(in), optional :: range_1, range_2, range_3, range_4

      real(dp), dimension(:, :, :, :), intent(inout) :: y
      real(dp), dimension(:, :, :, :), intent(in) :: x

      integer :: p, q, r, s, pp, qq, rr, ss

      integer, dimension(4) :: local_firsts, dims_perm, dims, permutation_copy, perm_reverse
      integer, dimension(4) :: idx_x, idx_y

      local_firsts = ([1, 1, 1, 1])
      if (present(range_1)) local_firsts(1) = range_1%first
      if (present(range_2)) local_firsts(2) = range_2%first
      if (present(range_3)) local_firsts(3) = range_3%first
      if (present(range_4)) local_firsts(4) = range_4%first

      dims_perm(1) = size(x, 1)
      dims_perm(2) = size(x, 2)
      dims_perm(3) = size(x, 3)
      dims_perm(4) = size(x, 4)

      permutation_copy = perm
      call quicksort_with_index_ascending_int(permutation_copy, perm_reverse, 4)

      dims = dims_perm(perm_reverse)

      !$omp parallel do schedule(static) private(p,q,r,s,pp,qq,rr,ss, idx_Y, idx_X)
      do s = 1, dims(4)
         do r = 1, dims(3)
            do q = 1, dims(2)
               do p = 1, dims(1)

                  pp = p + local_firsts(1) - 1
                  qq = q + local_firsts(2) - 1
                  rr = r + local_firsts(3) - 1
                  ss = s + local_firsts(4) - 1

                  idx_Y = [p, q, r, s]
                  idx_X = idx_Y(perm)

                  y(pp, qq, rr, ss) = y(pp, qq, rr, ss) + scalar * x(idx_X(1), idx_X(2), idx_X(3), idx_X(4))

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_to_subblock_rank_4


   subroutine add_from_subblock_rank_4(scalar, x, y, perm, range_1, range_2, range_3, range_4)
      !!
      !! Written by Sarai D. Folkestad, 2026
      !!
      !! Add elements of the subblock of (the large array) x defined by the ranges 1-4 to y,
      !! permuted according to 'perm'.
      !!
      !! Note: The provided ranges are ordered according to the dimensions of the array y
      !! Note: The provided permutation is relative to the indices in y:
      !!
      !!    y_pqrs += scalar * x_sqrp <- perm = [4, 2, 3, 1]
      !!
      !! Note: that the y is assumed to be allocated in the correct shape.
      !!
      !!
      use range_class
      use array_utilities, only: quicksort_with_index_ascending_int

      implicit none

      real(dp), intent(in) :: scalar
      integer, dimension(4), intent(in) :: perm
      class(range_), intent(in), optional :: range_1, range_2, range_3, range_4

      real(dp), dimension(:, :, :, :), intent(inout) :: y
      real(dp), dimension(:, :, :, :), intent(in) :: x

      integer :: p, q, r, s, pp, qq, rr, ss

      integer, dimension(4) :: local_firsts, dims, permutation_copy, perm_reverse
      integer, dimension(4) :: idx_x, idx_y

      local_firsts = ([1, 1, 1, 1])
      if (present(range_1)) local_firsts(1) = range_1%first
      if (present(range_2)) local_firsts(2) = range_2%first
      if (present(range_3)) local_firsts(3) = range_3%first
      if (present(range_4)) local_firsts(4) = range_4%first

      dims(1) = size(y, 1)
      dims(2) = size(y, 2)
      dims(3) = size(y, 3)
      dims(4) = size(y, 4)

      permutation_copy = perm
      call quicksort_with_index_ascending_int(permutation_copy, perm_reverse, 4)

      !$omp parallel do schedule(static) private(p,q,r,s,pp,qq,rr,ss, idx_Y, idx_X)
      do s = 1, dims(4)
         do r = 1, dims(3)
            do q = 1, dims(2)
               do p = 1, dims(1)

                  pp = p + local_firsts(1) - 1
                  qq = q + local_firsts(2) - 1
                  rr = r + local_firsts(3) - 1
                  ss = s + local_firsts(4) - 1

                  idx_Y = [pp, qq, rr, ss]
                  idx_X = idx_Y(perm)

                  y(p, q, r, s) = y(p, q, r, s) + scalar * x(idx_X(1), idx_X(2), idx_X(3), idx_X(4))

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine add_from_subblock_rank_4


end module reordering_r

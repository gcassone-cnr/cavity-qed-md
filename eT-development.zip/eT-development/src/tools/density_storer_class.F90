

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module density_storer_class

   !!
   !! Density storer class module
   !! Written by Alexander C. Paul, 2022
   !!
   !! Object for storing a set of ground state, excited state and
   !! transition densities. This is done using a record storer
   !! where the statenumber of the left and right state are linked to
   !! a specific record number
   !!

   use kinds
   use record_storer_class, only: record_storer

   implicit none

   type :: density_storer

      type(record_storer), allocatable, private :: storer
      integer, dimension(:, :), allocatable, private :: record_numbers

      integer, private :: n_densities_stored
      integer, private :: n_states
      integer, private :: density_size

   contains

      procedure, public :: initialize => initialize_density_storer
      procedure, public :: finalize => finalize_density_storer

      procedure, public :: copy_density_in
      procedure, public :: copy_density_out
      procedure, public :: is_density_stored

      procedure, private :: get_next_record_number

   end type density_storer


   interface density_storer

      procedure :: new_density_storer_class

   end interface density_storer


contains


   function new_density_storer_class(name_, density_size, n_states, records_in_mem) result(this)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      !! name_:          Name of storer
      !! density_size:   Size of the density matrices to be storer, also the record length
      !! n_records:      Maximum number of densities, also n_records
      !! records_in_mem: Store records in memory if true.
      !!                 Stores records on direct stream file if false.
      !!
      implicit none

      type(density_storer) :: this

      character(len=*), intent(in) :: name_

      integer, intent(in) :: density_size, n_states
      logical, intent(in) :: records_in_mem

      this%density_size = density_size
      this%n_states = n_states

      this%n_densities_stored = 0

      this%storer = record_storer(name_=trim(name_), &
                                  record_length=this%density_size, &
                                  max_n_records=this%n_states**2, &
                                  records_in_mem=records_in_mem)

   end function new_density_storer_class


   subroutine initialize_density_storer(this)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      use memory_manager_class, only: mem
      use range_class, only: range_

      implicit none

      class(density_storer), intent(inout) :: this
      type(range_) :: zero_indexed_n_states

      call this%storer%initialize()

      zero_indexed_n_states = range_(0, this%n_states)

      call mem%alloc(this%record_numbers, &
                     zero_indexed_n_states, &
                     zero_indexed_n_states, &
                     set_zero=.true.)

   end subroutine initialize_density_storer


   subroutine finalize_density_storer(this)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      use memory_manager_class, only: mem

      implicit none

      class(density_storer), intent(inout) :: this

      call mem%dealloc(this%record_numbers)
      call this%storer%finalize

   end subroutine finalize_density_storer


   subroutine copy_density_in(this, density, left_state, right_state)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      !! Add density to record this, based on the state numbers
      !! of the left and right state contributing to the density
      !!
      implicit none

      class(density_storer), intent(inout) :: this

      real(dp), dimension(this%density_size), intent(in) :: density
      integer, intent(in) :: left_state, right_state

      integer :: record_number

      record_number = this%record_numbers(left_state, right_state)

      if (record_number == 0) then
         record_number = this%get_next_record_number(left_state, right_state)
      end if

      call this%storer%copy_record_in(density, record_number)

   end subroutine copy_density_in


   subroutine copy_density_out(this, density, left_state, right_state)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      !! Copy density determined by the left and right state number into the array x.
      !!
      use global_out, only: output

      implicit none

      class(density_storer), intent(inout) :: this

      real(dp), dimension(this%density_size), intent(out) :: density
      integer, intent(in) :: left_state, right_state

      integer :: record_number

      record_number = this%record_numbers(left_state, right_state)

      if (record_number == 0) then

         call output%error_msg( &
                 'Tried copying out density for left state (i0) and right state (i0), but no density has been&
                 & stored.', &
                 ints=[left_state, right_state] &
              )

      end if

      call this%storer%copy_record_out(density, record_number)

   end subroutine copy_density_out


   function get_next_record_number(this, left_state, right_state) result(record_number)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      !! Update record number then return it
      !!
      implicit none

      class(density_storer), intent(inout) :: this

      integer, intent(in) :: left_state, right_state
      integer :: record_number

      this%n_densities_stored = this%n_densities_stored + 1

      this%record_numbers(left_state, right_state) = this%n_densities_stored
      record_number = this%n_densities_stored

   end function get_next_record_number


   function is_density_stored(this, left_state, right_state) result(is_stored)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      implicit none

      class(density_storer), intent(in) :: this
      integer, intent(in) :: left_state, right_state

      logical :: is_stored
      integer :: record_number

      is_stored = .false.

      record_number = this%record_numbers(left_state, right_state)
      if (record_number > 0) is_stored = .true.

   end function is_density_stored


end module density_storer_class

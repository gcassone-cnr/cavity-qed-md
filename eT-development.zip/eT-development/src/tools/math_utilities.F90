

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module math_utilities

   !!
   !! Math utilities module
   !!
   !! This module contains routines that perform various math operations.
   !!

   use parameters
   use global_out, only: output

   implicit none

contains

   function factorial(arg) result(f)
      !!
      !! Written by Sarai D. Folkestad, Dec 2018
      !!
      implicit none

      integer, intent(in) :: arg
      integer :: f, i

      if (arg < 0) then

         call output%error_msg('factorial operation not defined for negative numbers!')

      end if

      f = 1

      do i = 1, arg

         f = f * i

      end do

   end function factorial


   function double_factorial(arg) result(f)
      !!
      !! Written by Andreas Skeidsvoll, Jul 2019
      !!
      implicit none

      integer, intent(in) :: arg
      integer :: f, i

      if (arg < - 1) then

         call output%error_msg('double factorial operation not defined for numbers less than -1!')

      end if

      f = 1

      do i = arg, 2, - 2

         f = f * i

      end do

   end function double_factorial


   function delta(i, j) result(delta_ij)
      !!
      !! Written by Eirik F. Kjoenstad, 2019
      !!
      !! Returns the Kronecker delta as a real number:
      !!
      !!   delta_ij = 1 if i .eq. j
      !!   delta_ij = 0 if i .ne. j
      !!
      implicit none

      real(dp) :: delta_ij

      integer, intent(in) :: i, j

      if (i == j) then

         delta_ij = one

      else

         delta_ij = zero

      end if

   end function delta


   function binomial(n, k) result(b)
      !!
      !! Written by Enrico Ronca and Tor S. Haugland, 2020
      !!
      !! b = n!/(k!(n-k)!)
      !!
      implicit none

      integer, intent(in) :: n, k
      integer :: b
      integer :: i

      if (k > n) then

         call output%error_msg('k ((i0)) is greater than n ((i0)) in binomial function.', &
                               ints=[k, n])

      else if (k < 0) then

         call output%error_msg('k ((i0)) is smaller than zero in binomial function.', &
                               ints=[k])

      end if

      if (k == 0) then

         b = 1
         return

      end if

      b = 1
      if (n - k >= k) then  ! consider n!/(n-k)! explicitly, then divide by k!

         do i = n - k + 1, n
            b = b * i
         end do

         b = b / factorial(k)

      else  ! consider n!/(k)! explicitly, then divide by (n-k)!

         do i = k + 1, n
            b = b * i
         end do

         b = b / factorial(n - k)

      end if

   end function binomial


   function cross_product_R3(r1, r2) result(r3)
      !!
      !! Written by Sarai D. Folkestad Oct 2020
      !!
      implicit none

      real(dp), dimension(3), intent(in) :: r1, r2
      real(dp), dimension(3) :: r3

      r3(1) = r1(2) * r2(3) - r1(3) * r2(2)  !   y1 * z2 - y2 * z1
      r3(2) = - r1(1) * r2(3) + r1(3) * r2(1)  ! - x1 * z2 + x2 * z1
      r3(3) = r1(1) * r2(2) - r1(2) * r2(1)  !   y1 * z2 - y2 * z1

   end function cross_product_R3


   function dot_R3(r1, r2) result(r1_dot_r2)
      !!
      !! Written by Sarai D. Folkestad Oct 2020
      !!
      implicit none

      real(dp), dimension(3), intent(in) :: r1, r2

      real(dp) :: r1_dot_r2

      r1_dot_r2 = r1(1) * r2(1) + r1(2) * r2(2) + r1(3) * r2(3)

   end function dot_R3


   function norm_R3(r) result(r_norm)
      !!
      !! Written by Sarai D. Folkestad Oct 2020
      !!
      implicit none

      real(dp), dimension(3), intent(in) :: r

      real(dp) :: r_norm

      r_norm = sqrt(r(1)**2 + r(2)**2 + r(3)**2)

   end function norm_R3


   elemental function gcd(a, b) result(d)
      !!
      !! Greatest common divisor
      !! Written by Rolf H. Myhre, April 2021
      !!
      !! Uses the Eucledean Algorithm
      !! to compute the greatest common divisor of a and b
      !! See https://en.wikipedia.org/wiki/Euclidean_algorithm for details
      !!
      implicit none

      integer, intent(in) :: a, b

      integer :: tmp1, tmp2
      integer :: d

      d = max(abs(a), abs(b))
      tmp1 = min(abs(a), abs(b))

      do while (tmp1 /= 0)
         tmp2 = tmp1
         tmp1 = mod(d, tmp2)
         d = tmp2
      end do

   end function gcd


   elemental function lcm(a, b) result(m)
      !!
      !! Least common multiple
      !! Written by Rolf H. Myhre, April 2021
      !!
      !! Computes the least common multiple of a and b
      !! See https://en.wikipedia.org/wiki/Least_common_multiple for details
      !!
      implicit none

      integer, intent(in) :: a, b

      integer :: m

      m = (abs(a) / gcd(a, b)) * abs(b)

   end function lcm


   pure recursive function solve_n1s1_n2s2(s1, s2, x) result(n1)
      !!
      !! Solve n1*s1 - n2*s2
      !! Written by Rolf H. Myhre, May 2021
      !!
      !! Returns an n1 solving the equation
      !! n1*s1 - n2*s2 = x
      !! if they exists.
      !! If they do not exist, the function returns garbage.
      !! Solutions exist iff x/gcd(s1,s2) is an integer.
      !!
      !! The algorithm works by by exploiting that s1 = q*s2 + r
      !! Inserting this in the original expression, we get
      !! n1'*s2 - n2'*r = x
      !! with n1' = (n1*q - n2) and n2' = -n1
      !! This is repeated until x is dividable by r and n1 is 0.
      !!
      implicit none

      integer, intent(in) :: s1, s2, x
      integer :: n1, n1p

      if (mod(x, s2) == 0) then
         n1 = 0
      else
         n1p = solve_n1s1_n2s2(s2, mod(s1, s2), x)
         n1 = - (n1p * s2 - x) / mod(s1, s2)
      end if

   end function solve_n1s1_n2s2


   pure recursive function least_positive_n1s1_n2s2(s1, s2, x) result(n1)
      !!
      !! Least positive n1*s1 - n2*s2
      !! Written by Rolf H. Myhre, May 2021
      !!
      !! Solve n1*s1 - n2*s2 = x
      !!
      !! and return the least positive n1 corresponding to a positive n2
      !!
      implicit none

      integer, intent(in) :: s1, s2, x
      integer :: n1, n2, l, c1, c2

      l = lcm(s1, s2)
      c1 = l / s1
      c2 = l / s2

      n1 = solve_n1s1_n2s2(s1, s2, x)

      n1 = n1 - (n1 / c1) * c1
      if (n1 < 0) n1 = n1 + c1

      n2 = (n1 * s1 - x) / s2

      if (n2 < 0) then
         c2 = l / s2
         n1 = n1 - (n2 / c2) * c1
         if (mod(n2, c2) /= 0) n1 = n1 + c1
      end if

   end function least_positive_n1s1_n2s2


   subroutine convert_integer_to_binary_string(b, i, n_bits)
      !!
      !! Written by Enrico Ronca, 2020
      !!
      !! Converts integer to binary in little endian format
      !!
      implicit none

      integer, intent(in) :: i, n_bits
      integer, dimension(:), intent(out) :: b

      integer :: bit, remainder

      remainder = i

      b = zero

      do bit = n_bits, 1, - 1

         if (remainder == 0) return

         b(bit) = mod(remainder, 2)
         remainder = remainder / 2

      end do

   end subroutine convert_integer_to_binary_string


   pure function get_n_values_greater_sum(dim_, values, sum_) result(n)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, May 2021
      !!
      !! Get the n first values that add up to sum or more
      !!
      implicit none

      integer, intent(in) :: dim_

      real(dp), dimension(dim_), intent(in) :: values

      real(dp), intent(in) :: sum_

      integer :: n, p
      real(dp) :: local_sum

      local_sum = zero

      do p = 1, dim_

         if (local_sum >= sum_) exit
         local_sum = local_sum + values(p)

      end do

      n = p - 1

   end function get_n_values_greater_sum


   pure function is_real(value_) result(real_)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      complex(dp), intent(in) :: value_
      logical :: real_

      real_ = (aimag(value_) == zero)

   end function is_real


   function random_x_from_normal_distribution(mu, sigma) result(x)
      !!
      !! Added by Eirik F. Kjoenstad, 2023
      !!
      !! https://masuday.github.io/fortran_tutorial/random.html
      !!
      use parameters

      implicit none

      real(dp), intent(in) :: mu, sigma

      real(dp) :: x

      real(dp) :: u1, u2

      u1 = random_stduniform()
      u2 = random_stduniform()

      x = sigma * sqrt(- two * log(u1)) * cos(two * pi * u2) + mu

   end function random_x_from_normal_distribution


   function random_stduniform() result(u)
      !!
      !! Added by Eirik F. Kjoenstad, 2023
      !!
      !! Returns a random number 0 < u <= 1
      !! https://masuday.github.io/fortran_tutorial/random.html
      !!
      implicit none

      real(dp) :: u

      real(dp) :: r

      call random_number(r)

      u = one - r

   end function random_stduniform


end module math_utilities

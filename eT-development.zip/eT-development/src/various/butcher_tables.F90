

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module butcher_tables

   !!
   !! Butcher tables module
   !! Written by Andreas Skeidsvoll, 2019-2021
   !!
   !! Contains parameters that give the values of Butcher tables, which are used in Runge-Kutta
   !! methods. Butcher tables specify the given Runge-Kutta method, and are given on the form
   !!
   !!    c1 | A11 A12 ... A1n
   !!    c2 | A21 A22 ... A2n
   !!     : |  :   :       :
   !!    cn | An1 An2 ... Ann
   !!       -----------------
   !!         b11 b21 ... bn1
   !!         b12 b22 ... bn2
   !!          :   :       :
   !!
   !! See e.g. Butcher, J. C. (2016). Numerical Methods for Ordinary Differential Equations.
   !!

   use kinds

   implicit none

   ! 2nd order Gauss-Legendre table

   real(dp), dimension(1, 1), parameter :: A_gl2 = reshape(shape=[1, 1], source=[ &
   ! Column 1
   0.5_dp])

   real(dp), dimension(1, 1), parameter :: b_gl2 = reshape(shape=[1, 1], source=[ &
   ! b1
   1.0_dp])

   real(dp), dimension(1), parameter :: c_gl2 = [0.5_dp]

   ! 4th order Gauss-Legendre table

   real(dp), dimension(2, 2), parameter :: A_gl4 = reshape(shape=[2, 2], source=[ &
   ! Column 1
   0.25_dp, 0.25_dp + sqrt(3.0_dp) / 6.0_dp, &
   ! Column 2
   0.25_dp - sqrt(3.0_dp) / 6.0_dp, 0.25_dp])

   real(dp), dimension(2, 2), parameter :: b_gl4 = reshape(shape=[2, 2], source=[ &
   ! b1
   0.5_dp, 0.5_dp, &
   ! b2
   1.0_dp + sqrt(3.0_dp) / 2.0_dp, 1.0_dp - sqrt(3.0_dp) / 2.0_dp])

   real(dp), dimension(2, 1), parameter :: b_egl4 = reshape(shape=[2, 1], source=[ &
   ! b1
   0.5_dp, 0.5_dp])

   real(dp), dimension(2), parameter :: c_gl4 = &
      [0.5_dp - sqrt(3.0_dp) / 6.0_dp, 0.5_dp + sqrt(3.0_dp) / 6.0_dp]

   ! 6th order Gauss-Legendre table

   real(dp), dimension(3, 3), parameter :: A_gl6 = reshape(shape=[3, 3], source=[ &
   ! Column 1
   5.0_dp / 36.0_dp, 5.0_dp / 36.0_dp + sqrt(15.0_dp) / 24.0_dp, 5.0_dp / 36.0_dp + sqrt(15.0_dp) / 30.0_dp, &
   ! Column 2
   2.0_dp / 9.0_dp - 1.0_dp / sqrt(15.0_dp), 2.0_dp / 9.0_dp, 2.0_dp / 9.0_dp + 1.0_dp / sqrt(15.0_dp), &
   ! Column 3
   5.0_dp / 36.0_dp - sqrt(15.0_dp) / 30.0_dp, 5.0_dp / 36.0_dp - sqrt(15.0_dp) / 24.0_dp, 5.0_dp / 36.0_dp])


   real(dp), dimension(3, 1), parameter :: b_gl6 = reshape(shape=[3, 1], source=[ &
   ! b1
   5.0_dp / 18.0_dp, 4.0_dp / 9.0_dp, 5.0_dp / 18.0_dp])

   real(dp), dimension(3, 2), parameter :: b_egl6 = reshape(shape=[3, 2], source=[ &
   ! b1
   5.0_dp / 18.0_dp, 4.0_dp / 9.0_dp, 5.0_dp / 18.0_dp, &
   ! b2
   - 5.0_dp / 6.0_dp, 8.0_dp / 3.0_dp, - 5.0_dp / 6.0_dp])

   real(dp), dimension(3), parameter :: c_gl6 = &
      [0.5_dp - 0.1_dp * sqrt(15.0_dp), 0.5_dp, 0.5_dp + 0.1_dp * sqrt(15.0_dp)]


   ! 4th order Lobatto IIIC method

   real(dp), dimension(3, 3), parameter :: A_lob3c4 = reshape(shape=[3, 3], source=[ &
   ! Column 1
   1.0_dp / 6.0_dp, 1.0_dp / 6.0_dp, 1.0_dp / 6.0_dp, &
   ! Column 2
   - 1.0_dp / 3.0_dp, 5.0_dp / 12.0_dp, 2.0_dp / 3.0_dp, &
   ! Column 3
   1.0_dp / 6.0_dp, - 1.0_dp / 12.0_dp, 1.0_dp / 6.0_dp])

   real(dp), dimension(3, 2), parameter :: b_lob3c4 = reshape(shape=[3, 2], source=[ &
   ! b1
   1.0_dp / 6.0_dp, 2.0_dp / 3.0_dp, 1.0_dp / 6.0_dp, &
   ! b2
   - 0.5_dp, 2.0_dp, - 0.5_dp])

   real(dp), dimension(3), parameter :: c_lob3c4 = [0.0_dp, 0.5_dp, 1.0_dp]

   ! Euler table

   real(dp), dimension(1, 1), parameter :: A_euler = reshape(shape=[1, 1], source=[ &
   ! Column 1
   0.0_dp])

   real(dp), dimension(1, 1), parameter :: b_euler = reshape(shape=[1, 1], source=[ &
   ! b1
   1.0_dp])

   real(dp), dimension(1), parameter :: c_euler = [0.0_dp]

   ! RK4 table

   real(dp), dimension(4, 4), parameter :: A_rk4 = reshape(shape=[4, 4], source=[ &
   ! Column 1
   0.0_dp, 0.5_dp, 0.0_dp, 0.0_dp, &
   ! Column 2
   0.0_dp, 0.0_dp, 0.5_dp, 0.0_dp, &
   ! Column 3
   0.0_dp, 0.0_dp, 0.0_dp, 1.0_dp, &
   ! Column 4
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp])

   real(dp), dimension(4, 1), parameter :: b_rk4 = reshape(shape=[4, 1], source=[ &
   ! b1
   1.0_dp / 6.0_dp, 1.0_dp / 3.0_dp, 1.0_dp / 3.0_dp, 1.0_dp / 6.0_dp])

   real(dp), dimension(4), parameter :: c_rk4 = [0.0_dp, 0.5_dp, 0.5_dp, 1.0_dp]

   ! Heun-Euler table

   real(dp), dimension(2, 2), parameter :: A_heuneuler = reshape(shape=[2, 2], source=[ &
   ! Column 1
   0.0_dp, 1.0_dp, &
   ! Column 2
   0.0_dp, 0.0_dp])

   real(dp), dimension(2, 2), parameter :: b_heuneuler = reshape(shape=[2, 2], source=[ &
   ! b2
   1.0_dp, 0.0_dp, &
   ! b1
   0.5_dp, 0.5_dp])

   real(dp), dimension(2), parameter :: c_heuneuler = [0.0_dp, 1.0_dp]

   ! Dormand-Prince 5(4) table

   real(dp), dimension(7, 7), parameter :: A_dopri5 = reshape(shape=[7, 7], source=[ &
   ! Column 1
   0.0_dp, 1.0_dp / 5.0_dp, 3.0_dp / 40.0_dp, 44.0_dp / 45.0_dp, 19372.0_dp / 6561.0_dp, &
      9017.0_dp / 3168.0_dp, 35.0_dp / 384.0_dp, &
   ! Column 2
   0.0_dp, 0.0_dp, 9.0_dp / 40.0_dp, - 56.0_dp / 15.0_dp, - 25360.0_dp / 2187.0_dp, - 355.0_dp / 33.0_dp, &
      0.0_dp, &
   ! Column 3
   0.0_dp, 0.0_dp, 0.0_dp, 32.0_dp / 9.0_dp, 64448.0_dp / 6561.0_dp, 46732.0_dp / 5247.0_dp, &
      500.0_dp / 1113.0_dp, &
   ! Column 4
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, - 212.0_dp / 729.0_dp, 49.0_dp / 176.0_dp, 125.0_dp / 192.0_dp, &
   ! Column 5
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, - 5103.0_dp / 18656.0_dp, - 2187.0_dp / 6784.0_dp, &
   ! Column 6
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 11.0_dp / 84.0_dp, &
   ! Column 7
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp])

   real(dp), dimension(7, 2), parameter :: b_dopri5 = reshape(shape=[7, 2], source=[ &
   ! b1
   35.0_dp / 384.0_dp, 0.0_dp, 500.0_dp / 1113.0_dp, 125.0_dp / 192.0_dp, - 2187.0_dp / 6784.0_dp, &
      11.0_dp / 84.0_dp, 0.0_dp, &
   ! b2
   5179.0_dp / 57600.0_dp, 0.0_dp, 7571.0_dp / 16695.0_dp, 393.0_dp / 640.0_dp, - 92097.0_dp / 339200.0_dp, &
      187.0_dp / 2100.0_dp, 1.0_dp / 40.0_dp])

   real(dp), dimension(7), parameter :: c_dopri5 = &
      [0.0_dp, 0.2_dp, 0.3_dp, 0.8_dp, 8.0_dp / 9.0_dp, 1.0_dp, 1.0_dp]

   ! Cash-Karp table

   real(dp), dimension(6, 6), parameter :: A_cashkarp = reshape(shape=[6, 6], source=[ &
   ! Column 1
   0.0_dp, 1.0_dp / 5.0_dp, 3.0_dp / 40.0_dp, 3.0_dp / 10.0_dp, - 11.0_dp / 54.0_dp, 1631.0_dp / 55296.0_dp, &
   ! Column 2
   0.0_dp, 0.0_dp, 9.0_dp / 40.0_dp, - 9.0_dp / 10.0_dp, 5.0_dp / 2.0_dp, 175.0_dp / 512.0_dp, &
   ! Column 3
   0.0_dp, 0.0_dp, 0.0_dp, 6.0_dp / 5.0_dp, - 70.0_dp / 27.0_dp, 575.0_dp / 13824.0_dp, &
   ! Column 4
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 35.0_dp / 27.0_dp, 44275.0_dp / 110592.0_dp, &
   ! Column 5
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 253.0_dp / 4096.0_dp, &
   ! Column 6
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp])

   real(dp), dimension(6, 2), parameter :: b_cashkarp = reshape(shape=[6, 2], source=[ &
   ! b1
   37.0_dp / 378.0_dp, 0.0_dp, 250.0_dp / 621.0_dp, 125.0_dp / 594.0_dp, 0.0_dp, 512.0_dp / 1771.0_dp, &
   ! b2
   2825.0_dp / 27648.0_dp, 0.0_dp, 18575.0_dp / 48384.0_dp, 13525.0_dp / 55296.0_dp, 277.0_dp / 14336.0_dp, &
      1.0_dp / 4.0_dp])

   real(dp), dimension(6), parameter :: c_cashkarp = [0.0_dp, 0.2_dp, 0.3_dp, 0.6_dp, 1.0_dp, 7.0_dp / 8.0_dp]

   ! Dormand-Prince 8(5,3) table

   real(dp), dimension(12, 12), parameter :: A_dop853 = reshape(shape=[12, 12], source=[ &
   ! Column 1
   0.0_dp, 5.26001519587677318785587544488e-2_dp, 1.97250569845378994544595329183e-2_dp, &
      2.95875854768068491816892993775e-2_dp, 2.41365134159266685502369798665e-1_dp, &
      3.7037037037037037037037037037e-2_dp, 3.7109375e-2_dp, 3.70920001185047927108779319836e-2_dp, &
      6.24110958716075717114429577812e-1_dp, 4.77662536438264365890433908527e-1_dp, &
      - 9.3714243008598732571704021658e-1_dp, 2.27331014751653820792359768449e0_dp, &
   ! Column 2
   0.0_dp, 0.0_dp, 5.91751709536136983633785987549e-2_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, &
      0.0_dp, 0.0_dp, 0.0_dp, &
   ! Column 3
   0.0_dp, 0.0_dp, 0.0_dp, 8.87627564304205475450678981324e-2_dp, - 8.84549479328286085344864962717e-1_dp, &
      0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, &
   ! Column 4
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 9.24834003261792003115737966543e-1_dp, &
      1.70828608729473871279604482173e-1_dp, 1.70252211019544039314978060272e-1_dp, &
      1.70383925712239993810214054705e-1_dp, - 3.36089262944694129406857109825e0_dp, &
      - 2.48811461997166764192642586468e0_dp, 5.18637242884406370830023853209e0_dp, &
      - 1.05344954667372501984066689879e1_dp, &
   ! Column 5
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 1.25467687566822425016691814123e-1_dp, &
      6.02165389804559606850219397283e-2_dp, 1.07262030446373284651809199168e-1_dp, &
      - 8.68219346841726006818189891453e-1_dp, - 5.90290826836842996371446475743e-1_dp, &
      1.09143734899672957818500254654e0_dp, - 2.00087205822486249909675718444e0_dp, &
   ! Column 6
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, - 1.7578125e-2_dp, &
      - 1.53194377486244017527936158236e-2_dp, 2.75920996994467083049415600797e1_dp, &
      2.12300514481811942347288949897e1_dp, - 8.14978701074692612513997267357e0_dp, &
      - 1.79589318631187989172765950534e1_dp, &
   ! Column 7
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 8.27378916381402288758473766002e-3_dp, &
      2.01540675504778934086186788979e1_dp, 1.52792336328824235832596922938e1_dp, &
      - 1.85200656599969598641566180701e1_dp, 2.79488845294199600508499808837e1_dp, &
   ! Column 8
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, - 4.34898841810699588477366255144e1_dp, &
      - 3.32882109689848629194453265587e1_dp, 2.27394870993505042818970056734e1_dp, &
      - 2.85899827713502369474065508674e0_dp, &
   ! Column 9
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, &
      - 2.03312017085086261358222928593e-2_dp, 2.49360555267965238987089396762e0_dp, &
      - 8.87285693353062954433549289258e0_dp, &
   ! Column 10
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, &
      - 3.0467644718982195003823669022e0_dp, 1.23605671757943030647266201528e1_dp, &
   ! Column 11
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, &
      6.43392746015763530355970484046e-1_dp, &
   ! Column 12
   0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp])

   real(dp), dimension(12, 3), parameter :: b_dop853 = reshape(shape=[12, 3], source=[ &
   ! b1
   5.42937341165687622380535766363e-2_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, &
      4.45031289275240888144113950566e0_dp, 1.89151789931450038304281599044e0_dp, &
      - 5.8012039600105847814672114227e0_dp, 3.1116436695781989440891606237e-1_dp, &
      - 1.52160949662516078556178806805e-1_dp, 2.01365400804030348374776537501e-1_dp, &
      4.47106157277725905176885569043e-2_dp, &
   ! b2 (B+ER)
   6.74137791107636429705546065963e-2_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, &
      3.22515644637620444072056975266e0_dp, 1.39575894965725019152140799524e0_dp, &
      - 4.1368267775555982445056810077e0_dp, - 3.916448179215378727973266663e-2_dp, &
      1.82018169050501400473553077295e-1_dp, 2.83288607289146060840483963631e-1_dp, &
      2.23553078638862952588442784543e-2_dp, &
   ! b3 (BHH)
   0.244094488188976377952755905512e0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, 0.0_dp, &
      0.733846688281611857341361741547e0_dp, 0.0_dp, 0.0_dp, 0.220588235294117647058823529412e-1_dp])

   real(dp), dimension(12), parameter :: c_dop853 = &
      [0.0_dp, 0.526001519587677318785587544488e-1_dp, 0.789002279381515978178381316732e-1_dp, &
      0.118350341907227396726757197510e0_dp, 0.281649658092772603273242802490e0_dp, &
      0.333333333333333333333333333333e0_dp, 0.25e0_dp, 0.307692307692307692307692307692e0_dp, &
      0.651282051282051282051282051282e0_dp, 0.6e0_dp, 0.857142857142857142857142857142e0_dp, 1.0_dp]  ! XPH in algorithm

end module butcher_tables



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_angular_momentum_class

   !!
   !! Abstract angular momenta class
   !! Written by Alexander C. Paul, June 2021
   !!
   !! Stores and returns information about spherical angular momenta
   !!
   !! Libint ordering described in:
   !! https://github.com/evaleev/libint/wiki/using-modern-CPlusPlus-API
   !!

   use parameters

   type, abstract :: abstract_angular_momentum

      integer :: l, n_functions
      character(len=1) :: l_letter
      character(len=6), dimension(:), allocatable :: components

      integer, dimension(:), allocatable :: offsets

      real(dp), dimension(:), allocatable :: normalization
      real(dp), dimension(:, :), allocatable :: conversion

      integer :: n_powers
      integer(i8), dimension(:, :), allocatable :: powers

   contains

      procedure, non_overridable, public :: get_label
      procedure, non_overridable, public :: get_molden_offset
      procedure, non_overridable, public :: get_normalization_factor
      procedure, non_overridable, public :: get_l_integer
      procedure, non_overridable, public :: get_l_string

      procedure, non_overridable, public :: initialize_powers
      procedure, non_overridable, public :: initialize_conversion

      procedure, public :: get_angular_part_from_powers => &
                           get_angular_part_from_powers_abstract_angular_momentum

      procedure, public :: get_derivative_from_powers => get_derivative_from_powers_abstract_angular_momentum

      procedure(get_angular_part), deferred, public :: get_angular_part
      procedure(get_derivative_angular_part), deferred, public :: get_derivative_angular_part

   end type


   abstract interface

      function get_angular_part(this, x, y, z) result(angular_part)

         use kinds
         import :: abstract_angular_momentum

         implicit none

         class(abstract_angular_momentum), intent(in) :: this

         real(dp), intent(in) :: x, y, z

         real(dp), dimension(this%n_functions) :: angular_part

      end function get_angular_part


      function get_derivative_angular_part(this, r) result(angular_part)

         use kinds
         import :: abstract_angular_momentum

         implicit none

         class(abstract_angular_momentum), intent(in) :: this

         real(dp), intent(in) :: r(3)

         real(dp), dimension(this%n_functions, 3) :: angular_part

      end function get_derivative_angular_part

   end interface


contains


   subroutine initialize_powers(this)
      !!
      !! Written by Marco Scavino, Mar 2023
      !!
      !! Set powers x, y, z
      !! Build the powers of x, y, z from components
      !!

      implicit none

      class(abstract_angular_momentum), intent(inout) :: this

      integer :: nx, ny, nz, i

      this%n_powers = (this%l + 1) * (this%l + 2) / 2
      allocate(this%powers(3, this%n_powers))

      i = 1

      do nx = this%l, 0, - 1

         do nz = 0, this%l - nx

            ny = this%l - nx - nz

            this%powers(1, i) = int(nx, kind(this%powers))
            this%powers(2, i) = int(ny, kind(this%powers))
            this%powers(3, i) = int(nz, kind(this%powers))

            i = i + 1

         end do

      end do

   end subroutine initialize_powers


   pure function get_l_integer(this) result(l)
      !!
      !! Written by Alexander C. Paul, June 2021
      !!
      !! Return angular momentum as integer
      !!
      implicit none

      class(abstract_angular_momentum), intent(in) :: this

      integer :: l

      l = this%l

   end function get_l_integer


   pure function get_l_string(this) result(l)
      !!
      !! Written by Alexander C. Paul, June 2021
      !!
      !! Return angular momentum as letter
      !!
      implicit none

      class(abstract_angular_momentum), intent(in) :: this

      character(len=1) :: l

      l = this%l_letter

   end function get_l_string


   pure function get_label(this, index_) result(label)
      !!
      !! Written by Alexander C. Paul, June 2021
      !!
      !! Returns string containing the angular momenta and its spatial component
      !!
      implicit none

      class(abstract_angular_momentum), intent(in) :: this

      integer, intent(in) :: index_

      character(len=:), allocatable :: label

      label = this%l_letter // ' ' // trim(this%components(index_))

   end function get_label


   pure function get_molden_offset(this, index_) result(offset)
      !!
      !! Written by Alexander C. Paul, June 2021
      !!
      !! Return offset from the first AO index_ in the shell
      !! to obtain the AO order molden expects.
      !!
      implicit none

      class(abstract_angular_momentum), intent(in) :: this

      integer, intent(in) :: index_

      integer :: offset

      offset = this%offsets(index_)

   end function get_molden_offset


   pure function get_normalization_factor(this, index_) result(factor)
      !!
      !! Written by Alexander C. Paul, June 2021
      !!
      !! Return factor to normalize the function determined
      !! by the angular momentum l and the index_
      !!
      implicit none

      class(abstract_angular_momentum), intent(in) :: this

      integer, intent(in) :: index_

      real(dp) :: factor

      factor = this%normalization(index_)

   end function get_normalization_factor


   function get_angular_part_from_powers_abstract_angular_momentum(this, x, y, z) result(angular_part)
      !!
      !! Written by Marco Scavino, Mar 2023
      !!
      !! Return angular part of the AOs evaluated at x, y, z
      !!

      implicit none

      class(abstract_angular_momentum), intent(in) :: this

      real(dp), intent(in) :: x, y, z

      real(dp), dimension(this%n_powers) :: angular_part

      integer :: i, nx, ny, nz

      do i = 1, this%n_powers

         nx = int(this%powers(1, i))
         ny = int(this%powers(2, i))
         nz = int(this%powers(3, i))

         angular_part(i) = x**nx * y**ny * z**nz

      end do

   end function get_angular_part_from_powers_abstract_angular_momentum


   function get_derivative_from_powers_abstract_angular_momentum(this, r) result(angular_part)
      !!
      !! Written by Marco Scavino, Mar 2023
      !!
      !! Get x, y, z derivative angular part

      implicit none

      class(abstract_angular_momentum), intent(in) :: this

      real(dp), intent(in) :: r(3)

      real(dp), dimension(this%n_powers, 3) :: angular_part

      integer :: i, nx, ny, nz

      angular_part = zero

      if (this%l == 0) return

      do i = 1, this%n_powers

         nx = int(this%powers(1, i))
         ny = int(this%powers(2, i))
         nz = int(this%powers(3, i))

         if (nx /= 0) angular_part(i, 1) = nx * r(1)**(nx - 1) * r(2)**ny * r(3)**nz

         if (ny /= 0) angular_part(i, 2) = ny * r(1)**nx * r(2)**(ny - 1) * r(3)**nz

         if (nz /= 0) angular_part(i, 3) = nz * r(1)**nx * r(2)**ny * r(3)**(nz - 1)

      end do

   end function get_derivative_from_powers_abstract_angular_momentum


   subroutine initialize_conversion(this)
      !!
      !! Written by Marco Scavino and Tommaso Giovannini, Feb 2022
      !!
      !! Conversion matrices from cartesian to pure as described in
      !! https://iodata.readthedocs.io/en/latest/basis.html#transformation-from-cartesian-to-pure-functions
      !!
      implicit none

      class(abstract_angular_momentum), intent(inout) :: this

      integer :: n_pure, n_cartesian

      n_cartesian = (this%l + 1) * (this%l + 2) / 2
      n_pure = 2 * this%l + 1

      allocate(this%conversion(n_pure, n_cartesian))

      this%conversion = zero

      select case (this%l)

         case (0)

            this%conversion(1, 1) = one

         case (1)

            this%conversion(1, 2) = one
            this%conversion(2, 3) = one
            this%conversion(3, 1) = one

         case (2)

            this%conversion(1, 2) = sqrt(3.0_dp)
            this%conversion(2, 5) = sqrt(3.0_dp)
            this%conversion(3, 1) = - half
            this%conversion(3, 4) = - half
            this%conversion(3, 6) = one
            this%conversion(4, 3) = sqrt(3.0_dp)
            this%conversion(5, 1) = half * sqrt(3.0_dp)
            this%conversion(5, 4) = - half * sqrt(3.0_dp)

         case (3)

            this%conversion(1, 2) = (3.0_dp / 4.0_dp) * sqrt(10.0_dp)
            this%conversion(1, 7) = - 1.0_dp / 4.0_dp * sqrt(10.0_dp)
            this%conversion(2, 5) = sqrt(15.0_dp)
            this%conversion(3, 2) = - 1.0_dp / 4.0_dp * sqrt(6.0_dp)
            this%conversion(3, 7) = - 1.0_dp / 4.0_dp * sqrt(6.0_dp)
            this%conversion(3, 9) = sqrt(6.0_dp)
            this%conversion(4, 3) = - 3.0_dp / 2.0_dp
            this%conversion(4, 8) = - 3.0_dp / 2.0_dp
            this%conversion(4, 10) = one
            this%conversion(5, 1) = - 1.0_dp / 4.0_dp * sqrt(6.0_dp)
            this%conversion(5, 4) = - 1.0_dp / 4.0_dp * sqrt(6.0_dp)
            this%conversion(5, 6) = sqrt(6.0_dp)
            this%conversion(6, 3) = half * sqrt(15.0_dp)
            this%conversion(6, 8) = - half * sqrt(15.0_dp)
            this%conversion(7, 1) = (1.0_dp / 4.0_dp) * sqrt(10.0_dp)
            this%conversion(7, 4) = - 3.0_dp / 4.0_dp * sqrt(10.0_dp)

         case (4)

            this%conversion(1, 2) = half * sqrt(35.0_dp)
            this%conversion(1, 7) = - half * sqrt(35.0_dp)
            this%conversion(2, 5) = (3.0_dp / 4.0_dp) * sqrt(70.0_dp)
            this%conversion(2, 12) = - 1.0_dp / 4.0_dp * sqrt(70.0_dp)
            this%conversion(3, 2) = - half * sqrt(5.0_dp)
            this%conversion(3, 7) = - half * sqrt(5.0_dp)
            this%conversion(3, 9) = 3 * sqrt(5.0_dp)
            this%conversion(4, 5) = - 3.0_dp / 4.0_dp * sqrt(10.0_dp)
            this%conversion(4, 12) = - 3.0_dp / 4.0_dp * sqrt(10.0_dp)
            this%conversion(4, 14) = sqrt(10.0_dp)
            this%conversion(5, 1) = 3.0_dp / 8.0_dp
            this%conversion(5, 4) = 3.0_dp / 4.0_dp
            this%conversion(5, 6) = - three
            this%conversion(5, 11) = 3.0_dp / 8.0_dp
            this%conversion(5, 13) = - three
            this%conversion(5, 15) = one
            this%conversion(6, 3) = - 3.0_dp / 4.0_dp * sqrt(10.0_dp)
            this%conversion(6, 8) = - 3.0_dp / 4.0_dp * sqrt(10.0_dp)
            this%conversion(6, 10) = sqrt(10.0_dp)
            this%conversion(7, 1) = - 1.0_dp / 4.0_dp * sqrt(5.0_dp)
            this%conversion(7, 6) = (3.0_dp / 2.0_dp) * sqrt(5.0_dp)
            this%conversion(7, 11) = (1.0_dp / 4.0_dp) * sqrt(5.0_dp)
            this%conversion(7, 13) = - 3.0_dp / 2.0_dp * sqrt(5.0_dp)
            this%conversion(8, 3) = (1.0_dp / 4.0_dp) * sqrt(70.0_dp)
            this%conversion(8, 8) = - 3.0_dp / 4.0_dp * sqrt(70.0_dp)
            this%conversion(9, 1) = (1.0_dp / 8.0_dp) * sqrt(35.0_dp)
            this%conversion(9, 4) = - 3.0_dp / 4.0_dp * sqrt(35.0_dp)
            this%conversion(9, 11) = (1.0_dp / 8.0_dp) * sqrt(35.0_dp)

         case (5)

            this%conversion(1, 2) = (15.0_dp / 16.0_dp) * sqrt(14.0_dp)
            this%conversion(1, 7) = - 15.0_dp / 8.0_dp * sqrt(14.0_dp)
            this%conversion(1, 16) = (3.0_dp / 16.0_dp) * sqrt(14.0_dp)
            this%conversion(2, 5) = (3.0_dp / 2.0_dp) * sqrt(35.0_dp)
            this%conversion(2, 12) = - 3.0_dp / 2.0_dp * sqrt(35.0_dp)
            this%conversion(3, 2) = - 3.0_dp / 16.0_dp * sqrt(70.0_dp)
            this%conversion(3, 7) = - 1.0_dp / 8.0_dp * sqrt(70.0_dp)
            this%conversion(3, 9) = (3.0_dp / 2.0_dp) * sqrt(70.0_dp)
            this%conversion(3, 16) = (1.0_dp / 16.0_dp) * sqrt(70.0_dp)
            this%conversion(3, 18) = - half * sqrt(70.0_dp)
            this%conversion(4, 5) = - half * sqrt(105.0_dp)
            this%conversion(4, 12) = - half * sqrt(105.0_dp)
            this%conversion(4, 14) = sqrt(105.0_dp)
            this%conversion(5, 2) = (1.0_dp / 8.0_dp) * sqrt(15.0_dp)
            this%conversion(5, 7) = (1.0_dp / 4.0_dp) * sqrt(15.0_dp)
            this%conversion(5, 9) = - 3.0_dp / 2.0_dp * sqrt(15.0_dp)
            this%conversion(5, 16) = (1.0_dp / 8.0_dp) * sqrt(15.0_dp)
            this%conversion(5, 18) = - 3.0_dp / 2.0_dp * sqrt(15.0_dp)
            this%conversion(5, 20) = sqrt(15.0_dp)
            this%conversion(6, 3) = 15.0_dp / 8.0_dp
            this%conversion(6, 8) = 15.0_dp / 4.0_dp
            this%conversion(6, 10) = - 5.0_dp
            this%conversion(6, 17) = 15.0_dp / 8.0_dp
            this%conversion(6, 19) = - 5.0_dp
            this%conversion(6, 21) = one
            this%conversion(7, 1) = (1.0_dp / 8.0_dp) * sqrt(15.0_dp)
            this%conversion(7, 4) = (1.0_dp / 4.0_dp) * sqrt(15.0_dp)
            this%conversion(7, 6) = - 3.0_dp / 2.0_dp * sqrt(15.0_dp)
            this%conversion(7, 11) = (1.0_dp / 8.0_dp) * sqrt(15.0_dp)
            this%conversion(7, 13) = - 3.0_dp / 2.0_dp * sqrt(15.0_dp)
            this%conversion(7, 15) = sqrt(15.0_dp)
            this%conversion(8, 3) = - 1.0_dp / 4.0_dp * sqrt(105.0_dp)
            this%conversion(8, 10) = half * sqrt(105.0_dp)
            this%conversion(8, 17) = (1.0_dp / 4.0_dp) * sqrt(105.0_dp)
            this%conversion(8, 19) = - half * sqrt(105.0_dp)
            this%conversion(9, 1) = - 1.0_dp / 16.0_dp * sqrt(70.0_dp)
            this%conversion(9, 4) = (1.0_dp / 8.0_dp) * sqrt(70.0_dp)
            this%conversion(9, 6) = half * sqrt(70.0_dp)
            this%conversion(9, 11) = (3.0_dp / 16.0_dp) * sqrt(70.0_dp)
            this%conversion(9, 13) = - 3.0_dp / 2.0_dp * sqrt(70.0_dp)
            this%conversion(10, 3) = (3.0_dp / 8.0_dp) * sqrt(35.0_dp)
            this%conversion(10, 8) = - 9.0_dp / 4.0_dp * sqrt(35.0_dp)
            this%conversion(10, 17) = (3.0_dp / 8.0_dp) * sqrt(35.0_dp)
            this%conversion(11, 1) = (3.0_dp / 16.0_dp) * sqrt(14.0_dp)
            this%conversion(11, 4) = - 15.0_dp / 8.0_dp * sqrt(14.0_dp)
            this%conversion(11, 11) = (15.0_dp / 16.0_dp) * sqrt(14.0_dp)

         case (6)

            this%conversion(1, 2) = (3.0_dp / 16.0_dp) * sqrt(462.0_dp)
            this%conversion(1, 7) = - 5.0_dp / 8.0_dp * sqrt(462.0_dp)
            this%conversion(1, 16) = (3.0_dp / 16.0_dp) * sqrt(462.0_dp)
            this%conversion(2, 5) = (15.0_dp / 16.0_dp) * sqrt(154.0_dp)
            this%conversion(2, 12) = - 15.0_dp / 8.0_dp * sqrt(154.0_dp)
            this%conversion(2, 23) = (3.0_dp / 16.0_dp) * sqrt(154.0_dp)
            this%conversion(3, 2) = - 3.0_dp / 4.0_dp * sqrt(7.0_dp)
            this%conversion(3, 9) = (15.0_dp / 2.0_dp) * sqrt(7.0_dp)
            this%conversion(3, 16) = (3.0_dp / 4.0_dp) * sqrt(7.0_dp)
            this%conversion(3, 18) = - 15.0_dp / 2.0_dp * sqrt(7.0_dp)
            this%conversion(4, 5) = - 9.0_dp / 16.0_dp * sqrt(210.0_dp)
            this%conversion(4, 12) = - 3.0_dp / 8.0_dp * sqrt(210.0_dp)
            this%conversion(4, 14) = (3.0_dp / 2.0_dp) * sqrt(210.0_dp)
            this%conversion(4, 23) = (3.0_dp / 16.0_dp) * sqrt(210.0_dp)
            this%conversion(4, 25) = - half * sqrt(210.0_dp)
            this%conversion(5, 2) = (1.0_dp / 16.0_dp) * sqrt(210.0_dp)
            this%conversion(5, 7) = (1.0_dp / 8.0_dp) * sqrt(210.0_dp)
            this%conversion(5, 9) = - sqrt(210.0_dp)
            this%conversion(5, 16) = (1.0_dp / 16.0_dp) * sqrt(210.0_dp)
            this%conversion(5, 18) = - sqrt(210.0_dp)
            this%conversion(5, 20) = sqrt(210.0_dp)
            this%conversion(6, 5) = (5.0_dp / 8.0_dp) * sqrt(21.0_dp)
            this%conversion(6, 12) = (5.0_dp / 4.0_dp) * sqrt(21.0_dp)
            this%conversion(6, 14) = - 5.0_dp / 2.0_dp * sqrt(21.0_dp)
            this%conversion(6, 23) = (5.0_dp / 8.0_dp) * sqrt(21.0_dp)
            this%conversion(6, 25) = - 5.0_dp / 2.0_dp * sqrt(21.0_dp)
            this%conversion(6, 27) = sqrt(21.0_dp)
            this%conversion(7, 1) = - 5.0_dp / 16.0_dp
            this%conversion(7, 4) = - 15.0_dp / 16.0_dp
            this%conversion(7, 6) = 45.0_dp / 8.0_dp
            this%conversion(7, 11) = - 15.0_dp / 16.0_dp
            this%conversion(7, 13) = 45.0_dp / 4.0_dp
            this%conversion(7, 15) = - 15.0_dp / 2.0_dp
            this%conversion(7, 22) = - 5.0_dp / 16.0_dp
            this%conversion(7, 24) = 45.0_dp / 8.0_dp
            this%conversion(7, 26) = - 15.0_dp / 2.0_dp
            this%conversion(7, 28) = one
            this%conversion(8, 3) = (5.0_dp / 8.0_dp) * sqrt(21.0_dp)
            this%conversion(8, 8) = (5.0_dp / 4.0_dp) * sqrt(21.0_dp)
            this%conversion(8, 10) = - 5.0_dp / 2.0_dp * sqrt(21.0_dp)
            this%conversion(8, 17) = (5.0_dp / 8.0_dp) * sqrt(21.0_dp)
            this%conversion(8, 19) = - 5.0_dp / 2.0_dp * sqrt(21.0_dp)
            this%conversion(8, 21) = sqrt(21.0_dp)
            this%conversion(9, 1) = (1.0_dp / 32.0_dp) * sqrt(210.0_dp)
            this%conversion(9, 4) = (1.0_dp / 32.0_dp) * sqrt(210.0_dp)
            this%conversion(9, 6) = - half * sqrt(210.0_dp)
            this%conversion(9, 11) = - 1.0_dp / 32.0_dp * sqrt(210.0_dp)
            this%conversion(9, 15) = half * sqrt(210.0_dp)
            this%conversion(9, 22) = - 1.0_dp / 32.0_dp * sqrt(210.0_dp)
            this%conversion(9, 24) = half * sqrt(210.0_dp)
            this%conversion(9, 26) = - half * sqrt(210.0_dp)
            this%conversion(10, 3) = - 3.0_dp / 16.0_dp * sqrt(210.0_dp)
            this%conversion(10, 8) = (3.0_dp / 8.0_dp) * sqrt(210.0_dp)
            this%conversion(10, 10) = half * sqrt(210.0_dp)
            this%conversion(10, 17) = (9.0_dp / 16.0_dp) * sqrt(210.0_dp)
            this%conversion(10, 19) = - 3.0_dp / 2.0_dp * sqrt(210.0_dp)
            this%conversion(11, 1) = - 3.0_dp / 16.0_dp * sqrt(7.0_dp)
            this%conversion(11, 4) = (15.0_dp / 16.0_dp) * sqrt(7.0_dp)
            this%conversion(11, 6) = (15.0_dp / 8.0_dp) * sqrt(7.0_dp)
            this%conversion(11, 11) = (15.0_dp / 16.0_dp) * sqrt(7.0_dp)
            this%conversion(11, 13) = - 45.0_dp / 4.0_dp * sqrt(7.0_dp)
            this%conversion(11, 22) = - 3.0_dp / 16.0_dp * sqrt(7.0_dp)
            this%conversion(11, 24) = (15.0_dp / 8.0_dp) * sqrt(7.0_dp)
            this%conversion(12, 3) = (3.0_dp / 16.0_dp) * sqrt(154.0_dp)
            this%conversion(12, 8) = - 15.0_dp / 8.0_dp * sqrt(154.0_dp)
            this%conversion(12, 17) = (15.0_dp / 16.0_dp) * sqrt(154.0_dp)
            this%conversion(13, 1) = (1.0_dp / 32.0_dp) * sqrt(462.0_dp)
            this%conversion(13, 4) = - 15.0_dp / 32.0_dp * sqrt(462.0_dp)
            this%conversion(13, 11) = (15.0_dp / 32.0_dp) * sqrt(462.0_dp)
            this%conversion(13, 22) = - 1.0_dp / 32.0_dp * sqrt(462.0_dp)

      end select

   end subroutine initialize_conversion

end module abstract_angular_momentum_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module angular_momentum_factory_class

   !!
   !! Angular momentum factory class
   !! Written by Alexander C. Paul, June 2021
   !!
   !! Creates angular momentum object based on the length of a shell
   !! and the logical cartesian
   !!

   use parameters

   implicit none

   type :: angular_momentum_factory

      logical, private :: cartesian = .false.
      integer, private :: l = - 1
      character(len=1) :: ang_mom = ""

   contains

      procedure, public :: create => create_angular_momentum_factory

      procedure, private :: create_cartesian => create_cartesian_angular_momentum_factory

      procedure, private :: create_spherical => create_spherical_angular_momentum_factory

   end type angular_momentum_factory

   interface angular_momentum_factory

      procedure :: new_angular_momentum_factory

   end interface angular_momentum_factory


contains


   function new_angular_momentum_factory(cartesian, ang_mom) result(this)
      !!
      !! Written by Alexander C. Paul, June 2021
      !!

      use global_out, only: output
      use string_utilities, only: convert_to_lowercase, convert_character_to_uppercase

      implicit none

      type(angular_momentum_factory) :: this

      logical, intent(in) :: cartesian
      character(len=1), intent(in) :: ang_mom
      character(len=*), parameter :: ang_mom_letters = "SPDFGHI"

      this%cartesian = cartesian
      this%ang_mom = ang_mom

      ! Get the angular momentum value from the label

      this%l = index(ang_mom_letters, convert_character_to_uppercase(ang_mom)) - 1

      call convert_to_lowercase(this%ang_mom)

      if (this%l < 0) then

         call output%error_msg('Angular momentum (a0) beyond l = (i0) not supported.', &
                               chars=[ang_mom], &
                               ints=[len_trim(ang_mom_letters)])

      end if


   end function new_angular_momentum_factory


   subroutine create_angular_momentum_factory(this, angular_momentum)
      !!
      !! Written by Alexander C. Paul, June 2021
      !!
      !! Constructs the angular momentum object
      !!

      use abstract_angular_momentum_class

      implicit none

      class(angular_momentum_factory), intent(in) :: this
      class(abstract_angular_momentum), allocatable, intent(out) :: angular_momentum

      if (this%cartesian) then

         call this%create_cartesian(angular_momentum)

      else

         call this%create_spherical(angular_momentum)

      end if

   end subroutine create_angular_momentum_factory


   subroutine create_cartesian_angular_momentum_factory(this, angular_momentum)
      !!
      !! Written by Marco Scavino, Mar 2023
      !!

      use abstract_angular_momentum_class
      use cartesian_angular_momentum_class

      implicit none

      class(angular_momentum_factory), intent(in) :: this

      class(abstract_angular_momentum), allocatable, intent(out) :: angular_momentum

      integer, dimension(:), allocatable :: offsets

      integer :: i, n_functions

      n_functions = (this%l + 1) * (this%l + 2) / 2

      allocate(offsets(n_functions))

      select case (this%ang_mom)
         case ("s")

            offsets = [1]

         case ("p")

            offsets = [(i, i = 1, 3)]

         case ("d")

            ! instead of   xx, xy, xz, yy, yz, zz
            ! Molden needs xx, yy, zz, xy, xz, yz
            offsets = [1, 4, 6, 2, 3, 5]

         case ("f")

            ! instead of   xxx, xxy, xxz, xyy, xyz, xzz, yyy, yyz, yzz, zzz
            ! Molden needs xxx, yyy, zzz, xyy, xxy, xxz, xzz, yzz, yyz, xyz
            offsets = [1, 7, 10, 4, 2, 3, 6, 9, 8, 5]

         case ("g")

            ! instead of   xxxx, xxxy, xxxz, xxyy, xxyz, xxzz, xyyy, xyyz,
            !              xyzz, xzzz, yyyy, yyyz, yyzz, yzzz, zzzz
            ! Molden needs xxxx, yyyy, zzzz, xxxy, xxxz, yyyx, yyyz, zzzx,
            !              zzzy, xxyy, xxzz, yyzz, xxyz, yyxz, zzxy
            offsets = [1, 11, 15, 2, 3, 7, 12, 10, 14, 4, 6, 13, 5, 8, 9]

         case default

            ! Molden cannot handle l > 4
            offsets = [(i, i = 1, n_functions)]

      end select
      angular_momentum = cartesian_angular_momentum(this%l, this%ang_mom, offsets)

   end subroutine create_cartesian_angular_momentum_factory


   subroutine create_spherical_angular_momentum_factory(this, angular_momentum)
      !!
      !! Written by Marco Scavino, Mar 2023
      !!

      use abstract_angular_momentum_class
      use spherical_angular_momentum_class

      implicit none

      class(angular_momentum_factory), intent(in) :: this

      class(abstract_angular_momentum), allocatable, intent(out) :: angular_momentum

      integer, dimension(:), allocatable :: offsets

      integer :: i, n_functions

      n_functions = 2 * this%l + 1

      allocate(offsets(n_functions))

      select case (this%ang_mom)
         case ("s")

            offsets = [1]

         case ("p")

            ! instead of  -1,  0, 1
            ! Molden needs 1, -1, 0 (which is identical to x, y, z)
            offsets = [3, 1, 2]

         case ("d")

            ! instead of  -2,-1, 0, 1, 2
            ! Molden needs 0, 1,-1, 2,-2
            offsets = [3, 4, 2, 5, 1]

         case ("f")

            ! instead of  -3,-2,-1, 0, 1, 2, 3
            ! Molden needs 0, 1,-1, 2,-2, 3,-3
            offsets = [4, 5, 3, 6, 2, 7, 1]

         case ("g")

            ! instead of  -4,-3,-2,-1, 0, 1, 2, 3, 4
            ! Molden needs 0, 1,-1, 2,-2, 3,-3, 4,-4
            offsets = [5, 6, 4, 7, 3, 8, 2, 9, 1]

         case default

            ! Molden cannot handle l > 4
            offsets = [(i, i = 1, n_functions)]

      end select

      angular_momentum = spherical_angular_momentum(this%l, this%ang_mom, offsets)

   end subroutine create_spherical_angular_momentum_factory


end module angular_momentum_factory_class

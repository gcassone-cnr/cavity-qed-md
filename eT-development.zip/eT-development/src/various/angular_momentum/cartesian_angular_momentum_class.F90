

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cartesian_angular_momentum_class

   !!
   !! Cartesian cartesian angular momentum class
   !! Written by Alexander C. Paul, Feb 2022
   !!
   !! Stores information about cartesian angular momentum
   !!
   !! Libint ordering and normalization described in:
   !! https://github.com/evaleev/libint/wiki/using-modern-CPlusPlus-API
   !!

   use abstract_angular_momentum_class


   type, extends(abstract_angular_momentum) :: cartesian_angular_momentum

   contains

      procedure :: get_angular_part => get_angular_part_cartesian_angular_momentum

      procedure :: get_derivative_angular_part => get_derivative_angular_part_cartesian_angular_momentum

      procedure, private :: initialize_components
      procedure, private :: initialize_normalization

   end type

   interface cartesian_angular_momentum

      procedure :: new_cartesian_angular_momentum

   end interface


contains


   function new_cartesian_angular_momentum(l, ang_mom, offsets) result(momentum)
      !!
      !! Written by Marco Scavino, Mar 2023
      !!
      implicit none

      integer, intent(in) :: l
      character(len=1), intent(in) :: ang_mom
      integer, allocatable, intent(inout) :: offsets(:)

      type(cartesian_angular_momentum) :: momentum

      momentum%l = l
      momentum%l_letter = ang_mom
      call move_alloc(offsets, momentum%offsets)

      momentum%n_functions = (l + 1) * (l + 2) / 2

      call momentum%initialize_powers()
      call momentum%initialize_normalization()
      call momentum%initialize_components()

   end function new_cartesian_angular_momentum


   subroutine initialize_components(this)
      !!
      !! Written by Marco Scavino, Apr 2023
      !!
      implicit none
      class(cartesian_angular_momentum), intent(inout) :: this

      integer :: nx, ny, nz, i

      allocate(this%components(this%n_functions))

      do i = 1, this%n_functions

         nx = int(this%powers(1, i))
         ny = int(this%powers(2, i))
         nz = int(this%powers(3, i))

         this%components(i) = repeat('x', nx) // repeat('y', ny) // repeat('z', nz)

      end do

   end subroutine initialize_components


   subroutine initialize_normalization(this)
      !!
      !! Written by Marco Scavino, Apr 2023
      !!
      use math_utilities, only: double_factorial

      implicit none

      class(cartesian_angular_momentum), intent(inout) :: this

      integer :: nx, ny, nz
      integer :: i
      integer :: l

      allocate(this%normalization(this%n_functions))

      this%normalization = one

      do i = 1, this%n_functions

         nx = int(this%powers(1, i))
         ny = int(this%powers(2, i))
         nz = int(this%powers(3, i))

         l = nx + ny + nz

         this%normalization(i) = sqrt(real(double_factorial(2 * l - 1), dp))

      end do

   end subroutine initialize_normalization


   function get_angular_part_cartesian_angular_momentum(this, x, y, z) result(angular_part)
      !!
      !! Written by Alexander C. Paul, June 2021
      !! Modified by Marco Scavino, May 2023
      !!
      !! Return angular part of the AOs evaluated at x, y, z
      !!

      implicit none

      class(cartesian_angular_momentum), intent(in) :: this

      real(dp), intent(in) :: x, y, z

      real(dp), dimension(this%n_functions) :: angular_part

      angular_part = this%get_angular_part_from_powers(x, y, z)

   end function get_angular_part_cartesian_angular_momentum


   function get_derivative_angular_part_cartesian_angular_momentum(this, r) result(angular_part)
      !!
      !! Written by Marco Scavino, May 2023
      !!
      !! Return the first derivative of angular part of the AOs evaluated at x, y, z
      !!

      implicit none

      class(cartesian_angular_momentum), intent(in) :: this

      real(dp), intent(in) :: r(3)

      real(dp), dimension(this%n_functions, 3) :: angular_part

      angular_part = this%get_derivative_from_powers(r)

      angular_part(:, 1) = angular_part(:, 1)
      angular_part(:, 2) = angular_part(:, 2)
      angular_part(:, 3) = angular_part(:, 3)

   end function get_derivative_angular_part_cartesian_angular_momentum


end module cartesian_angular_momentum_class

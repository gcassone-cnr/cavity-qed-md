

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module spherical_angular_momentum_class

   !!
   !! Abstract spherical angular momentum class
   !! Written by Alexander C. Paul, Feb 2022
   !!
   !! Stores information about spherical angular momentum
   !!
   !! Libint ordering and normalization described in:
   !! https://github.com/evaleev/libint/wiki/using-modern-CPlusPlus-API
   !!

   use abstract_angular_momentum_class


   type, extends(abstract_angular_momentum) :: spherical_angular_momentum

   contains

      procedure :: get_angular_part => get_angular_part_spherical_angular_momentum

      procedure :: get_derivative_angular_part => get_derivative_angular_part_spherical_angular_momentum

      procedure, private :: initialize_components

   end type


   interface spherical_angular_momentum

      procedure :: new_spherical_angular_momentum

   end interface


contains


   function new_spherical_angular_momentum(l, ang_mom, offsets) result(momentum)

      !!
      !! Written by Marco Scavino, Mar 2023
      !! Modified by Tommaso Giovannini, Jan 2024
      !!
      use math_utilities, only: double_factorial
      implicit none

      integer, intent(in) :: l
      character(len=*), intent(in) :: ang_mom
      integer, allocatable, intent(inout) :: offsets(:)

      type(spherical_angular_momentum) :: momentum

      momentum%l = l
      momentum%l_letter = ang_mom
      call move_alloc(offsets, momentum%offsets)
      momentum%n_functions = 2 * l + 1

      call momentum%initialize_conversion()
      call momentum%initialize_powers()
      call momentum%initialize_components()

      allocate(momentum%normalization(momentum%n_functions), &
               source=sqrt(real(double_factorial(2 * l - 1), dp)))

   end function


   subroutine initialize_components(this)
      !!
      !! Written by Marco Scavino, Apr 2023
      !!
      implicit none
      class(spherical_angular_momentum), intent(inout) :: this

      integer :: i

      allocate(this%components(this%n_functions))

      if (this%l == 0) then

         this%components(1) = ''
         return

      end if

      do i = 1, this%n_functions

         write(this%components(i), '(i2)') i - 1 - this%l

      end do

   end subroutine initialize_components


   function get_angular_part_spherical_angular_momentum(this, x, y, z) result(angular_part)
      !!
      !! Written by Marco Scavino, Mar 2023
      !!
      !! Evaluate spherical harmonic of the AOs at x, y, z
      !!
      !! Solid harmonic from Molecular electronic structure theory eqn. (6.4.47)
      !!

      implicit none

      class(spherical_angular_momentum), intent(in) :: this

      real(dp), intent(in) :: x, y, z

      real(dp), dimension(this%n_functions) :: angular_part
      real(dp), dimension(this%n_powers) :: cartesian

      cartesian = this%get_angular_part_from_powers(x, y, z)

      call dgemv("N", &
                 this%n_functions, &
                 this%n_powers, &
                 one, &
                 this%conversion, &
                 this%n_functions, &
                 cartesian, &
                 1, &
                 zero, &
                 angular_part, &
                 1)

   end function get_angular_part_spherical_angular_momentum


   function get_derivative_angular_part_spherical_angular_momentum(this, r) result(angular_part)
      !!
      !! Written by Marco Scavino, Mar 2023
      !!
      implicit none

      class(spherical_angular_momentum), intent(in) :: this

      real(dp), intent(in) :: r(3)

      real(dp), dimension(this%n_functions, 3) :: angular_part
      real(dp), dimension(this%n_functions, 3) :: cartesian

      cartesian = this%get_derivative_from_powers(r)

      call dgemm("N", &
                 "T", &
                 this%n_functions, &
                 3, &
                 this%n_powers, &
                 one, &
                 this%conversion, &
                 this%n_powers, &
                 cartesian, &
                 this%n_powers, &
                 zero, &
                 angular_part, &
                 this%n_powers)

   end function get_derivative_angular_part_spherical_angular_momentum


end module spherical_angular_momentum_class

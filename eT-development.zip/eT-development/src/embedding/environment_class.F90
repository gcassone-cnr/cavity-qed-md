

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module environment_class

   !!
   !! Abstract environment class module
   !! Written by Sarai D. Folkestad, Sep 2020
   !!
   !! Defines the interface to the environment classes
   !!

   use parameters

   implicit none

   type, abstract :: environment

      character(len=50) :: type_
      real(dp), dimension(:, :), allocatable :: F

   contains


      procedure(update_environment), deferred :: update
      procedure(get_energy_environment), deferred :: get_energy
      procedure(initialize_environment), deferred :: initialize
      procedure(get_scf_energy_contribution_environment), deferred :: get_scf_energy_contribution
      procedure(print_description_environment), deferred :: print_description
      procedure(print_energy_environment), deferred :: print_energy

   end type environment

   abstract interface

      subroutine initialize_environment(embedding)

         import environment

         implicit none

         class(environment), intent(inout) :: embedding

      end subroutine


      real(dp) function get_scf_energy_contribution_environment(embedding, density) result(embedding_energy)

         use parameters

         import environment

         implicit none

         class(environment), intent(in) :: embedding
         real(dp), dimension(:, :), intent(in) :: density

      end function


      subroutine print_energy_environment(embedding, density)

         use parameters

         import environment

         implicit none

         class(environment) :: embedding
         real(dp), dimension(:, :), intent(in) :: density

      end subroutine


      subroutine print_description_environment(embedding)

         import environment

         implicit none

         class(environment), intent(in) :: embedding

      end subroutine


      subroutine update_environment(embedding, density)

         use parameters

         import environment

         implicit none

         class(environment), intent(inout) :: embedding
         real(dp), dimension(:, :), intent(in) :: density

      end subroutine


      real(dp) function get_energy_environment(embedding, density) result(embedding_energy)

         use parameters

         import environment

         implicit none

         class(environment), intent(in) :: embedding
         real(dp), dimension(:, :), intent(in) :: density

      end function

   end interface


end module environment_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cavity_environment_class

   !!
   !! Cavity environment class module
   !! Written by Sara Angelico and Tor S. Haugland, 2022
   !!

   use parameters

   use global_out, only: output
   use memory_manager_class, only: mem
   use environment_class, only: environment
   use boson_tool_class, only: boson_tool
   use boson_factory_class, only: boson_factory
   use ao_tool_class, only: ao_tool

   implicit none

   type, extends(environment) :: cavity_environment

      class(boson_tool), allocatable, private :: qed
      type(ao_tool), pointer :: ao

   contains

      procedure, public :: initialize => initialize_cavity_environment

      procedure, public :: update => update_cavity_environment

      procedure, public :: get_energy => get_energy_cavity_environment

      procedure, public :: get_scf_energy_contribution => get_scf_energy_contribution_cavity_environment

      procedure, public :: print_energy => print_energy_cavity_environment

      procedure, public :: print_description => print_description_cavity_environment


      final :: destructor

      procedure, private :: initialize_bosons => initialize_bosons_cavity_environment

   end type cavity_environment

   interface cavity_environment

      procedure :: new_cavity_environment

   end interface cavity_environment

contains


   function new_cavity_environment(ao) result(embedding)
      !!
      !! New environment
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      implicit none

      type(cavity_environment) :: embedding
      type(ao_tool), target :: ao

      embedding%type_ = 'cavity'
      embedding%ao => ao

   end function new_cavity_environment


   subroutine initialize_cavity_environment(embedding)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      implicit none

      class(cavity_environment), intent(inout) :: embedding

      call embedding%initialize_bosons()
      call mem%alloc(embedding%F, embedding%ao%n, embedding%ao%n)

   end subroutine initialize_cavity_environment


   subroutine initialize_bosons_cavity_environment(embedding)
      !!
      !! Written By T. S. Haugland, 2022
      !!
      !! Initializes bosons with a concrete type, for instance photons.
      !!
      implicit none

      class(cavity_environment), intent(inout) :: embedding
      type(boson_factory), allocatable :: qed_factory

      qed_factory = boson_factory()
      call qed_factory%create(embedding%qed)
      call embedding%qed%initialize(embedding%ao)

   end subroutine initialize_bosons_cavity_environment


   subroutine update_cavity_environment(embedding, density)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      use array_initialization, only: zero_array

      implicit none

      class(cavity_environment), intent(inout) :: embedding
      real(dp), dimension(:, :), intent(in) :: density

      if (embedding%qed%is_optimizing_bosons) then
         call embedding%qed%update_coherent_states(density)
      end if

      call zero_array(embedding%F, embedding%ao%n**2)
      call embedding%qed%add_ao_h_contribution(embedding%F)

   end subroutine update_cavity_environment


   function get_energy_cavity_environment(embedding, density) result(energy)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      !! The cavity energy is given by
      !!       E =  Tr(DV)
      !! where V is the ao h contribution from the cavity.
      !!

      implicit none

      class(cavity_environment), intent(in) :: embedding
      real(dp), dimension(:, :), intent(in) :: density
      real(dp) :: energy

      real(dp), external :: ddot

      energy = half * ddot(embedding%ao%n**2, density, 1, embedding%F, 1)

   end function get_energy_cavity_environment


   function get_scf_energy_contribution_cavity_environment(embedding, density) result(embedding_energy)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      !! The cavity energy is given by
      !!       E = 0.5 Tr(DV)
      !! where V is the ao h contribution from the cavity.
      !!

      implicit none

      class(cavity_environment), intent(in) :: embedding
      real(dp), dimension(:, :), intent(in) :: density
      real(dp) :: embedding_energy

      real(dp), external :: ddot

      embedding_energy = half * ddot(embedding%ao%n**2, density, 1, embedding%F, 1)

   end function get_scf_energy_contribution_cavity_environment


   subroutine print_energy_cavity_environment(embedding, density)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      use warning_suppressor, only: do_nothing
      implicit none

      class(cavity_environment) :: embedding
      real(dp), dimension(:, :), intent(in) :: density

      call do_nothing(density)
      call embedding%qed%print_summary()

   end subroutine print_energy_cavity_environment


   subroutine print_description_cavity_environment(embedding)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      implicit none

      class(cavity_environment), intent(in) :: embedding

      call output%printf('m', 'This is a cavity QED calculation', fs='(/t3,a)')

      call output%printf('n', 'Embedding type: (a0)', chars=[trim(embedding%type_)], fs='(/t6,a)')

   end subroutine print_description_cavity_environment


   subroutine destructor(embedding)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      implicit none

      type(cavity_environment) :: embedding

      if (allocated(embedding%qed)) call embedding%qed%cleanup()
      if (allocated(embedding%F)) call mem%dealloc(embedding%F)

   end subroutine destructor


end module cavity_environment_class

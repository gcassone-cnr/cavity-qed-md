

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the FNU Feneral Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! FNU Feneral Public License for more details.

! You should have received a copy of the FNU Feneral Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module density_environment_class

   !!
   !! Density environment class module
   !! Written by Tommaso Giovannini, Eirik F. Kjoenstad and Sarai D. Folkestad, 2018 and 2020
   !!

   use parameters

   use memory_manager_class, only: mem

   implicit none

   type :: density_environment

      real(dp), dimension(:, :), allocatable :: F, h
      ! Idempotent densities
      real(dp), dimension(:, :), allocatable :: D
      real(dp), dimension(:, :), allocatable :: D_v  ! D_v = 2 C_v^T C_v

      integer :: n_ao
      real(dp) :: energy

      logical :: embedded

      ! For frozen QED contributions
      integer :: n_modes
      real(dp), dimension(:), allocatable :: bilinear_core

   contains

      procedure, public :: initialize => initialize_density_environment

      procedure, public :: get_energy => get_energy_density_environment

      procedure, public :: set_bilinear

      procedure, public :: get_dipole => get_dipole_density_environment

      procedure, public :: get_quadrupole => get_quadrupole_density_environment

      procedure, public :: get_CCT => get_CCT_density_environment

      generic, public :: get_fock => get_fock_real, get_fock_complex

      procedure, private :: get_fock_real
      procedure, private :: get_fock_complex


      final :: destructor

   end type density_environment

   interface density_environment

      procedure :: new_density_environment

   end interface density_environment

contains


   function new_density_environment(n_ao) result(embedding)
      !!
      !! Written by Sarai D. Folkestad, 2020
      !!
      implicit none

      type(density_environment) :: embedding
      integer :: n_ao

      embedding%n_ao = n_ao

   end function new_density_environment


   subroutine initialize_density_environment(embedding, D, D_v, F, h, constant_energy)
      !!
      !! Written by Sarai D. Folkestad, Sep 2020
      !!
      use array_initialization, only: copy_and_scale
      implicit none

      class(density_environment), intent(inout) :: embedding
      real(dp) :: constant_energy

      real(dp), dimension(embedding%n_ao, embedding%n_ao), intent(in) :: D, D_v
      real(dp), dimension(embedding%n_ao, embedding%n_ao), intent(in) :: F, h
      real(dp) :: ddot


      call mem%alloc(embedding%F, embedding%n_ao, embedding%n_ao)
      call mem%alloc(embedding%h, embedding%n_ao, embedding%n_ao)
      call mem%alloc(embedding%D, embedding%n_ao, embedding%n_ao)
      call mem%alloc(embedding%D_v, embedding%n_ao, embedding%n_ao)

      call copy_and_scale(one, D, embedding%D, embedding%n_ao**2)
      call copy_and_scale(one, D_v, embedding%D_v, embedding%n_ao**2)
      call copy_and_scale(one, F, embedding%F, embedding%n_ao**2)
      call copy_and_scale(one, h, embedding%h, embedding%n_ao**2)

      embedding%energy = constant_energy + ddot(embedding%n_ao**2, embedding%D, 1, embedding%h, 1) &
                         + half * ddot(embedding%n_ao**2, embedding%D, 1, embedding%F, 1)

   end subroutine initialize_density_environment


   subroutine set_bilinear(embedding, n_modes, bilinear)
      !!
      !! Written by Sarai D. Folkestad, 2025
      !!
      implicit none

      class(density_environment), intent(inout) :: embedding
      integer, intent(in) :: n_modes
      real(dp), dimension(n_modes), intent(in) :: bilinear

      embedding%n_modes = n_modes
      call mem%alloc(embedding%bilinear_core, embedding%n_modes)

      call dcopy(embedding%n_modes, bilinear, 1, embedding%bilinear_core, 1)

   end subroutine set_bilinear


   function get_energy_density_environment(embedding, density) result(embedding_energy)
      !!
      !! Written by Sarai D. Folkestad, 2025
      !!
      implicit none

      class(density_environment), intent(in) :: embedding
      real(dp), dimension(:, :), intent(in) :: density
      real(dp) :: embedding_energy
      real(dp) :: ddot

      embedding_energy = embedding%energy
      embedding_energy = embedding_energy + ddot(embedding%n_ao**2, density, 1, embedding%F, 1)

      if (embedding%embedded) embedding_energy = embedding_energy

   end function get_energy_density_environment


   subroutine destructor(embedding)
      !!
      !! Written by Sarai Dery Folkestad, 2024
      !!
      implicit none

      type(density_environment) :: embedding

      if (allocated(embedding%F)) call mem%dealloc(embedding%F)
      if (allocated(embedding%h)) call mem%dealloc(embedding%h)
      if (allocated(embedding%D)) call mem%dealloc(embedding%D)
      if (allocated(embedding%D_v)) call mem%dealloc(embedding%D_v)

      if (allocated(embedding%bilinear_core)) call mem%dealloc(embedding%bilinear_core)

   end subroutine destructor


   function get_dipole_density_environment(embedding, ao) result(mu)
      !!
      !! Written by Sarai Dery Folkestad, 2024
      !!
      !! Frozen electronic dipole contributions
      !!
      use abstract_ao_oei_getter_class, only: abstract_ao_oei_getter
      implicit none

      class(density_environment) :: embedding
      class(abstract_ao_oei_getter) :: ao
      real(dp), dimension(3) :: mu

      real(dp), dimension(:, :, :), allocatable :: mu_ao
      integer :: i
      real(dp) :: ddot

      call mem%alloc(mu_ao, embedding%n_ao, embedding%n_ao, 3)
      call ao%get_oei('dipole', mu_ao)

      do i = 1, 3
         mu(i) = ddot(embedding%n_ao**2, embedding%D, 1, mu_ao(:, :, i), 1)
      end do

      call mem%dealloc(mu_ao)

   end function get_dipole_density_environment


   function get_quadrupole_density_environment(embedding, ao) result(q)
      !!
      !! Written by Sarai Dery Folkestad, 2024
      !!
      !! Frozen electronic quadrupole contributions
      !!
      use abstract_ao_oei_getter_class, only: abstract_ao_oei_getter
      implicit none

      class(density_environment) :: embedding
      class(abstract_ao_oei_getter) :: ao
      real(dp), dimension(6) :: q

      real(dp), dimension(:, :, :), allocatable :: q_ao
      integer :: i
      real(dp) :: ddot

      call mem%alloc(q_ao, embedding%n_ao, embedding%n_ao, 6)
      call ao%get_oei('quadrupole', q_ao)

      do i = 1, 6
         q(i) = ddot(embedding%n_ao**2, embedding%D, 1, q_ao(:, :, i), 1)
      end do

      call mem%dealloc(q_ao)

   end function get_quadrupole_density_environment


   subroutine get_CCT_density_environment(embedding, CCT)
      !!
      !! Written by Sarai Dery Folkestad, 2024
      !!
      !! Total frozen orbital density.
      !! To be used for orbital partitioning
      !!
      use array_initialization, only: copy_and_scale
      implicit none

      class(density_environment) :: embedding
      real(dp), dimension(embedding%n_ao, embedding%n_ao), intent(out) :: CCT

      call copy_and_scale(half, embedding%D, CCT, embedding%n_ao**2)
      call daxpy(embedding%n_ao**2, half, embedding%D_v, 1, CCT, 1)

   end subroutine get_CCT_density_environment


   subroutine get_fock_real(embedding, F, C, n_mo)
      !!
      !! Written by Sarai D. Folkestad
      !!
      use array_utilities, only: symmetric_sandwich

      implicit none

      class(density_environment), intent(in) :: embedding
      integer, intent(in) :: n_mo
      real(dp), dimension(embedding%n_ao, n_mo), intent(in) :: C
      real(dp), dimension(n_mo, n_mo), intent(inout) :: F

      call symmetric_sandwich(F, embedding%F, C, embedding%n_ao, n_mo)

   end subroutine get_fock_real


   subroutine get_fock_complex(embedding, F, C, n_mo)
      !!
      !! Written by Sarai D. Folkestad
      !!
      use array_utilities, only: symmetric_sandwich

      implicit none

      class(density_environment), intent(in) :: embedding
      integer, intent(in) :: n_mo
      real(dp), dimension(embedding%n_ao, n_mo), intent(in) :: C
      complex(dp), dimension(n_mo, n_mo), intent(inout) :: F

      real(dp), dimension(:, :), allocatable :: F_real

      call mem%alloc(F_real, n_mo, n_mo)
      call symmetric_sandwich(F_real, embedding%F, C, embedding%n_ao, n_mo)
      ! Copy real to complex matrix
      call zlacp2(n_mo, n_mo, F_real, n_mo, F, n_mo)
      call mem%dealloc(F_real)

   end subroutine get_fock_complex

end module density_environment_class

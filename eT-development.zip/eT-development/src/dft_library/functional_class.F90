! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.

module functional_class

   !!
   !! Functional class
   !! Written by Marco Scavino, 2022
   !!
   !! Abstract class for dft functional.
   !! Each external library have to write its own
   !! interface class
   !!

   use parameters, only: dp
   use iso_c_binding

   implicit none

   type, abstract :: functional

      character(len=80) :: name
      real(dp) :: coefficient
      real(dp) :: hf_fraction

      character(len=40) :: family
      character(len=40) :: kind_
      integer(c_int) :: flags

      integer :: n_references
      character(len=1024), dimension(:), allocatable :: reference
      character(len=1024), dimension(:), allocatable :: reference_doi

      logical :: is_polarized

   contains

      procedure(initialize_functional), deferred :: initialize
      procedure(calculate_exc_vxc_functional), deferred :: calculate_exc_vxc
      procedure(calculate_td_vxc_fxc_functional), deferred :: calculate_td_vxc_fxc
      procedure(cleanup_functional), deferred :: cleanup

      procedure(read_functionals_names_functional), deferred :: read_functionals_names

   end type

   abstract interface

      subroutine initialize_functional(this, name, is_polarized, density_threshold, coeff, hf_fraction)
         !!
         !! Written by Marco Scavino, 2022
         !!
         !! Initialize the functional class.
         !!
         !! name:         the functional name
         !! is_polarized: logical to set if functional is polarized
         !! density_threshold: threshold to cutoff the density rho
         !! coeff: coefficient to multiply the entire functional
         !! hf_fraction: for hybrid
         !!
         import :: functional, dp
         implicit none
         character(len=*), intent(in) :: name
         logical, intent(in) :: is_polarized

         class(functional), intent(inout) :: this

         real(dp), intent(in) :: density_threshold
         real(dp), intent(in), optional :: coeff, hf_fraction

      end subroutine initialize_functional


      subroutine cleanup_functional(this)
         !!
         !! Written by Marco Scavino, 2022
         !!
         import :: functional
         implicit none
         class(functional) :: this
      end subroutine cleanup_functional


      subroutine calculate_exc_vxc_functional(this, &
                                              n_points, &
                                              rho, &
                                              sigma, &
                                              e_xc, &
                                              v_rho, &
                                              v_sigma)

         import :: functional, dp

         implicit none

         class(functional), intent(in) :: this
         integer, intent(in) :: n_points
         real(dp), dimension(n_points), intent(in) :: rho, sigma
         real(dp), dimension(n_points), intent(out) :: e_xc, v_rho, v_sigma

      end subroutine calculate_exc_vxc_functional


      subroutine calculate_td_vxc_fxc_functional(this, &
                                                 n_points, &
                                                 rho, &
                                                 sigma, &
                                                 v_rho, &
                                                 v_sigma, &
                                                 v2_rho2, &
                                                 v2_rhosigma, &
                                                 v2_sigma2)
         !!
         !! Written by Tommaso Giovannini and Marco Scavino, 2025
         !!
         !! This subroutine returns the XC contribution to G in TDDFT
         !!
         import :: functional, dp

         implicit none

         class(functional), intent(inout) :: this
         integer, intent(in) :: n_points

         real(dp), dimension(n_points), intent(in) :: rho
         real(dp), dimension(n_points), intent(in) :: sigma
         real(dp), dimension(n_points), intent(out) :: v_rho
         real(dp), dimension(n_points), intent(out) :: v_sigma
         real(dp), dimension(n_points), intent(out) :: v2_rho2
         real(dp), dimension(n_points), intent(out) :: v2_rhosigma
         real(dp), dimension(n_points), intent(out) :: v2_sigma2

      end subroutine calculate_td_vxc_fxc_functional


      subroutine read_functionals_names_functional(this, names)
         !!
         !! Written by Marco Scavino, 2022
         !!
         !! names: array of character containing the selected names
         !!

         import :: functional

         implicit none

         class(functional), intent(in) :: this

         character(len=200), allocatable, intent(out) :: names(:)

      end subroutine read_functionals_names_functional

   end interface

contains

end module functional_class

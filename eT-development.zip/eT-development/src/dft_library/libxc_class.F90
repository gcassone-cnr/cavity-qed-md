! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.

module libxc_class
   !!
   !! libxc class
   !! Written by Marco Scavino, 2022
   !!
   !! LibXC interface class
   !!


   use parameters
   use global_out, only: output
   use global_in, only: input

   use iso_c_binding
   use functional_class, only: functional
   use xc_f03_lib_m, only: XC_UNPOLARIZED, XC_POLARIZED, XC_FAMILY_LDA, XC_FAMILY_GGA, XC_FAMILY_HYB_GGA, &
      XC_FLAGS_HAVE_FXC, XC_CORRELATION, XC_EXCHANGE, XC_EXCHANGE_CORRELATION, xc_f03_version_string, &
      xc_f03_reference, xc_f03_reference_doi, xc_f03_func_t, xc_f03_func_info_t, xc_f03_func_info_get_flags, &
      xc_f03_func_info_get_references, xc_f03_func_reference_get_ref, xc_f03_func_reference_get_doi, &
      xc_f03_func_init, xc_f03_func_end, xc_f03_func_get_info, xc_f03_func_set_dens_threshold, &
      xc_f03_func_info_get_family, xc_f03_func_info_get_name, xc_f03_func_info_get_kind, &
      xc_f03_functional_get_number, xc_f03_hyb_exx_coef, xc_f03_lda_exc_vxc, xc_f03_gga_exc_vxc, &
      xc_f03_lda_fxc, xc_f03_gga_fxc, xc_f03_gga_vxc

   implicit none

   ! After version 5, the n_points integer was changed from int to size_t

#if (LIBXC_MAJOR < 5)
   integer, parameter :: n_points_type = c_int
#elif LIBXC_MAJOR >= 5
   integer, parameter :: n_points_type = c_size_t
#endif

   type, extends(functional) :: libxc

      type(xc_f03_func_t) :: xc_functional

   contains

      procedure :: initialize => initialize_libxc
      procedure :: calculate_exc_vxc => calculate_exc_vxc_libxc
      procedure :: calculate_td_vxc_fxc => calculate_td_vxc_fxc_libxc
      procedure :: cleanup => cleanup_libxc

      procedure :: read_functionals_names => read_functionals_names_libxc

      procedure, private, nopass :: read_functional_name
      procedure, private, nopass :: read_exchange_name
      procedure, private, nopass :: read_correlation_name

      procedure, private :: set_family
      procedure, private :: set_kind

   end type

contains

   subroutine read_functionals_names_libxc(this, names)
      !!
      !! Written by Marco Scaino, 2022
      !!
      !! names: array of character containing the selected names
      !!
      implicit none

      class(libxc), intent(in) :: this
      character(len=200), dimension(:), allocatable, intent(out) :: names

      character(len=200) :: exchange_name, correlation_name
      logical :: has_exchange, has_correlation, has_exchange_correlation

      call this%read_functional_name(names, has_exchange_correlation)

      if (.not. has_exchange_correlation) then

         exchange_name = ""
         correlation_name = ""

         call this%read_exchange_name(exchange_name, has_exchange)
         call this%read_correlation_name(correlation_name, has_correlation)

         if (has_exchange .and. has_correlation) then

            names = [exchange_name, correlation_name]

         elseif (has_exchange) then

            names = [exchange_name]

         elseif (has_correlation) then

            names = [correlation_name]

         else

            call output%error_msg("No functional selected!")

         end if

      end if

   end subroutine read_functionals_names_libxc


   subroutine read_functional_name(names, found)
      !!
      !! Written by Marco Scavino, October 2019
      !!
      !! Check for allowed functional names whithin the preset list. If not found, pass to the library.
      !!
      implicit none

      character(len=200), dimension(:), allocatable, intent(out) :: names
      logical, intent(out) :: found

      character(len=200) :: key

      key = "no functional"
      call input%get_keyword('functional', 'dft functional', key)

      found = .false.
      if (key == "no functional") return

      select case (key)
         case ("b3lyp")

            names = ["hyb_gga_xc_b3lyp"]

         case ("pbe")

            names = [character(len=200) :: "gga_x_pbe", "gga_c_pbe"]

         case ("pbe0")

            names = ["hyb_gga_xc_pbeh"]

         case ("lsda", "lda")

            names = [character(len=200) :: "lda_x", "lda_c_vwn_rpa"]

         case ("blyp")

            names = ["gga_x_b88", "gga_c_lyp"]

         case ("bhandhlyp")

            names = ["hyb_gga_xc_bhandhlyp"]

         case ("sogga11x")

            names = [character(len=200) :: "hyb_gga_x_sogga11_x", "gga_c_sogga11_x"]

         case default

            names = [key]

      end select

      found = .true.

   end subroutine read_functional_name


   subroutine read_exchange_name(name, found)
      !!
      !! Written by Marco Scavino, October 2019
      !!
      !! Check for allowed functional names whithin the preset list or the LibXC list.
      !!
      implicit none

      character(len=200), intent(out) :: name
      logical, intent(out) :: found

      character(len=200) :: key

      key = "no functional"
      call input%get_keyword('exchange', 'dft functional', key)

      found = .false.
      if (key == "no functional") return

      select case (key)

         case ("pbe")

            name = "gga_x_pbe"

         case ("lda")

            name = "lda_x"

         case ("b88")

            name = "gga_x_b88"

         case ("xsogga11x")

            name = "hyb_gga_x_sogga11_x"

         case default

            name = key

      end select

      found = .true.

   end subroutine read_exchange_name


   subroutine read_correlation_name(name, found)
      !!
      !! Written by Marco Scavino, October 2019
      !!
      !! Check for allowed functional name whithin the preset list or the LibXC list.
      !!
      implicit none

      character(len=200), intent(out) :: name
      logical, intent(out) :: found

      character(len=200) :: key

      key = "no functional"
      call input%get_keyword('correlation', 'dft functional', key)

      found = .false.
      if (key == "no functional") return

      select case (key)

         case ("pbe")

            name = "gga_c_pbe"

         case ("lyp")

            name = "gga_c_lyp"

         case ("lda", "vwn")

            name = "lda_c_vwn_rpa"

         case ("csogga11x")

            name = "hyb_gga_c_sogga11_x"

         case default

            name = key

      end select

      found = .true.

   end subroutine read_correlation_name


   subroutine initialize_libxc(this, name, is_polarized, density_threshold, coeff, hf_fraction)
      !!
      !! Written by Marco Scavino, 2022
      !!
      !! Initialize libxc functional.
      !!

      implicit none

      class(libxc), intent(inout) :: this
      character(len=*), intent(in) :: name
      logical, intent(in) :: is_polarized

      real(dp), intent(in) :: density_threshold
      real(dp), intent(in), optional :: coeff, hf_fraction

      type(xc_f03_func_info_t) :: xc_info
      integer(c_int) :: id_, polarized, i
      integer :: k
      character(len=1064) :: fake_ref

      this%is_polarized = is_polarized

      polarized = XC_UNPOLARIZED
      if (this%is_polarized) polarized = XC_POLARIZED

      id_ = xc_f03_functional_get_number(name)
      call xc_f03_func_init(this%xc_functional, id_, polarized)

      call xc_f03_func_set_dens_threshold(this%xc_functional, density_threshold)

      xc_info = xc_f03_func_get_info(this%xc_functional)

      this%name = trim(xc_f03_func_info_get_name(xc_info))
      this%flags = xc_f03_func_info_get_flags(xc_info)

      call this%set_family(xc_info)
      call this%set_kind(xc_info)

      this%coefficient = one
      if (present(coeff)) this%coefficient = coeff

      if (present(hf_fraction)) then

         this%hf_fraction = hf_fraction

      else

         this%hf_fraction = xc_f03_hyb_exx_coef(this%xc_functional)

      end if

      this%n_references = 0
      i = 0
      do while (i >= 0)
         this%n_references = this%n_references + 1
         fake_ref = trim(xc_f03_func_reference_get_ref(xc_f03_func_info_get_references(xc_info, i)))
      end do

      allocate(this%reference(this%n_references))
      allocate(this%reference_doi(this%n_references))
      i = 0
      k = 1
      do while (i >= 0)
         this%reference(k) = trim(xc_f03_func_reference_get_ref(xc_f03_func_info_get_references(xc_info, i)))
         k = k + 1
      end do
      i = 0
      k = 1
      do while (i >= 0)
         this%reference_doi(k) = &
            trim(xc_f03_func_reference_get_doi(xc_f03_func_info_get_references(xc_info, i)))
         k = k + 1
      end do

   end subroutine initialize_libxc


   subroutine set_family(this, xc_info)
      !!
      !! Written by Marco Scavino, 2022
      !!
      implicit none
      class(libxc) :: this

      type(xc_f03_func_info_t) :: xc_info

      select case (xc_f03_func_info_get_family(xc_info))
         case (XC_FAMILY_LDA)
            this%family = "LDA"

         case (XC_FAMILY_GGA, XC_FAMILY_HYB_GGA)
            this%family = "GGA"

         case default
            call output%error_msg("Unkonwn functional family")
      end select

   end subroutine


   subroutine set_kind(this, xc_info)
      !!
      !! Written by Marco Scavino, 2022
      !!

      implicit none
      class(libxc) :: this
      type(xc_f03_func_info_t), intent(in) :: xc_info

      select case (xc_f03_func_info_get_kind(xc_info))
         case (XC_CORRELATION)
            this%kind_ = "CORRELATION"

         case (XC_EXCHANGE)
            this%kind_ = "EXCHANGE"

         case (XC_EXCHANGE_CORRELATION)
            this%kind_ = "EXCHANGE_CORRELATION"
         case default
            call output%error_msg("Unkonwn functional kind")
      end select

   end subroutine


   subroutine cleanup_libxc(this)
      !!
      !! Written by Marco Scavino, 2022
      !!

      implicit none

      class(libxc) :: this

      call xc_f03_func_end(this%xc_functional)

   end subroutine cleanup_libxc


   subroutine calculate_exc_vxc_libxc(this, n_points, rho, sigma, e_xc, v_rho, v_sigma)
      !!
      !! Written by Marco Scavino, 2022
      !!
      !! Given a rho (and also sigma for GGA), return the derivatives of the functional
      !!
      !! e_xc    = depsilon_xc/dr
      !! v_rho   = depsilon_xc/drho
      !! v_sigma = depsilon_xc/dgradrho
      !!

      implicit none

      class(libxc), intent(in) :: this

      integer, intent(in) :: n_points
      real(dp), dimension(n_points), intent(in) :: rho, sigma
      real(dp), dimension(n_points), intent(out) :: e_xc, v_rho, v_sigma

      integer(n_points_type) :: n_points_c

      n_points_c = int(n_points, n_points_type)

      select case (this%family)
         case ("LDA")
            call xc_f03_lda_exc_vxc(this%xc_functional, n_points_c, rho, e_xc, v_rho)

         case ("GGA")

            call xc_f03_gga_exc_vxc(this%xc_functional, &
                                    n_points_c, &
                                    rho, &
                                    sigma, &
                                    e_xc, &
                                    v_rho, &
                                    v_sigma)

      end select

   end subroutine calculate_exc_vxc_libxc


   subroutine calculate_td_vxc_fxc_libxc(this, &
                                         n_points, &
                                         rho, &
                                         sigma, &
                                         v_rho, &
                                         v_sigma, &
                                         v2_rho2, &
                                         v2_rhosigma, &
                                         v2_sigma2)
      !!
      !! Written by Tommaso Giovannini and Marco Scavino, 2025
      !!
      !! This subroutine returns the XC contribution to G in TDDFT
      !!
      implicit none

      class(libxc), intent(inout) :: this
      integer, intent(in) :: n_points

      real(dp), dimension(n_points), intent(in) :: rho
      real(dp), dimension(n_points), intent(in) :: sigma
      real(dp), dimension(n_points), intent(out) :: v_rho
      real(dp), dimension(n_points), intent(out) :: v_sigma
      real(dp), dimension(n_points), intent(out) :: v2_rho2
      real(dp), dimension(n_points), intent(out) :: v2_rhosigma
      real(dp), dimension(n_points), intent(out) :: v2_sigma2

      integer(n_points_type) :: n_points_c

      if (iand(XC_FLAGS_HAVE_FXC, this%flags) == 0) then
         call output%error_msg( &
            "Functional (a0) doesn't have fxc calculation. Please check your libxc library installation", &
            chars = [trim(this%name)])
      end if

      n_points_c = int(n_points, n_points_type)

      select case (this%family)
         case ("LDA")
            call xc_f03_lda_fxc(this%xc_functional, n_points_c, rho, v2_rho2)
         case ("GGA")
            call xc_f03_gga_vxc(this%xc_functional, n_points_c, rho, sigma, v_rho, v_sigma)
            call xc_f03_gga_fxc(this%xc_functional, n_points_c, rho, sigma, v2_rho2, v2_rhosigma, v2_sigma2)
      end select

   end subroutine calculate_td_vxc_fxc_libxc


end module libxc_class

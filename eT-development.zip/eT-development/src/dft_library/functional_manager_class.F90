! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.

module functional_manager_class

   !!
   !! Functional manager class module
   !! Written by Marco Scavino, October 2022
   !!
   !! This class is a wrapper to get the XC functionals from the libxc
   !! external library
   !!

   use parameters
   use global_in, only: input
   use functional_class, only: functional

   use memory_manager_class, only: mem

   use global_out, only: output

   implicit none


   type :: functional_manager

      real(dp) :: hf_percentage = zero
      real(dp) :: hf_fraction = zero

      real(dp) :: rho_threshold
      logical :: is_polarized = .false.

      integer :: n_functionals
      class(functional), dimension(:), allocatable :: functionals

      character(len=3) :: functional_type = ''
      character(len=30) :: library_name_version = ''
      character(len=200) :: library_reference = ''
      character(len=200) :: library_reference_doi = ''

   contains

      procedure :: print_settings => print_settings_functional_manager

      procedure :: cleanup => cleanup_functional_manager

      procedure :: calculate_exc_vxc => calculate_exc_vxc_functional_manager
      procedure :: calculate_td_vxc_fxc => calculate_td_vxc_fxc_functional_manager

      procedure, private :: initialize
      procedure, private, nopass :: get_library

   end type functional_manager

   interface functional_manager
      procedure :: new_functional_manager
   end interface functional_manager

contains

   function new_functional_manager(is_polarized) result(this)
      !!
      !! Written by Marco Scavino, May 2019
      !!
      !! Call the libxc library to get all the info about the selected functional.
      !!
      implicit none

      logical, intent(in) :: is_polarized

      type(functional_manager) :: this

      this%rho_threshold = 1.0E-15_dp
      this%is_polarized = .false.

      if (is_polarized) this%is_polarized = is_polarized

      this%n_functionals = 0

      call this%initialize()

      ! check if family is hybrid. In case, get the proper HF exchange percentage

      if (this%hf_fraction == zero) then

         call input%get_keyword("hf percentage", "dft functional", this%hf_percentage)

         if (this%hf_percentage < zero .or. this%hf_percentage > 100.0_dp) then

            call output%printf('n', "HF percentage equal to (f6.2)!", reals=[this%hf_percentage])
            call output%error_msg("Should be greater than 0 and lower than 100!")

         end if

         this%hf_fraction = this%hf_percentage / 100.0_dp

      end if

   end function new_functional_manager


   subroutine cleanup_functional_manager(this)
      !!
      !! Written by Marco Scavino, May 2019
      !!
      implicit none

      class(functional_manager), intent(inout) :: this
      integer :: i

      do i = 1, this%n_functionals

         call this%functionals(i)%cleanup()

      end do

   end subroutine cleanup_functional_manager


   subroutine print_settings_functional_manager(this)
      !!
      !! Written by Marco Scavino, May 2019
      !!
      implicit none

      class(functional_manager), intent(in) :: this

      integer :: i, k

      call output%printf('n', &
                         "External DFT Library: (a0)", &
                         chars=[trim(this%library_name_version)], &
                         fs='(/t6,a)')

      call output%printf('n', "Reference: (a0)", chars=[trim(this%library_reference)], fs='(t6,a)', ll=100)

      call output%printf('n', &
                         "           DOI: (a0)", &
                         chars=[trim(this%library_reference_doi)], &
                         fs='(t6,a)', &
                         ll=100)

      do i = 1, this%n_functionals

         call output%printf('n', 'Functional:  (a0)', chars=[trim(this%functionals(i)%name)], fs='(/t6,a)')
         call output%printf('n', 'Reference(s): ', fs='(t6,a)')

         do k = 1, this%functionals(i)%n_references

            call output%printf('n', &
                               ' - (a0). ', &
                               chars=[trim(this%functionals(i)%reference(k))], &
                               fs='(t6,a)', &
                               ll=100, &
                               adv=.false.)

            call output%printf('n', &
                               'DOI: (a0)', &
                               chars=[trim(this%functionals(i)%reference_doi(k))], &
                               fs='(a)', &
                               ll=100)

         end do

      end do


      call output%printf('n', 'Density threshold:      (e8.2)', reals=[this%rho_threshold], fs='(/t6,a)')

      call output%printf('n', &
                         'HF percentage (%):      (f8.2)', &
                         reals=[this%hf_fraction * 100.0E0_dp], &
                         fs='(t6,a)')

   end subroutine print_settings_functional_manager


   subroutine calculate_exc_vxc_functional_manager(this, n_points, rho, sigma, e_xc, v_rho, v_sigma)
      !!
      !! Written by Marco Scavino, 2022
      !!
      !! Given a rho (and also sigma for GGA), return the derivatives of the functional
      !!
      !! e_xc    = depsilon_xc/dr
      !! v_rho   = depsilon_xc/drho
      !! v_sigma = depsilon_xc/dgradrho
      !!

      use array_initialization, only: zero_array
      use omp_lib

      implicit none

      class(functional_manager), intent(inout) :: this
      integer, intent(in) :: n_points

      real(dp), dimension(n_points), intent(in) :: rho, sigma
      real(dp), dimension(n_points), intent(out) :: v_rho, v_sigma, e_xc

      integer :: i
      real(dp) :: beta

      real(dp), dimension(:), allocatable :: v_rho_local, v_sigma_local, e_xc_local

      call mem%alloc(e_xc_local, n_points)
      call mem%alloc(v_rho_local, n_points)
      call mem%alloc(v_sigma_local, n_points)

      call zero_array(e_xc, n_points)
      call zero_array(v_rho, n_points)
      call zero_array(v_sigma, n_points)

      do i = 1, this%n_functionals

         call this%functionals(i)%calculate_exc_vxc(n_points, &
                                                    rho, &
                                                    sigma, &
                                                    e_xc_local, &
                                                    v_rho_local, &
                                                    v_sigma_local)

         ! If hybrid exchange, scale by (1 - alpha)

         beta = one

         if (this%functionals(i)%hf_fraction > zero .and. this%functionals(i)%kind_ == "EXCHANGE") then
            beta = (one - this%functionals(i)%hf_fraction)
         end if

         call daxpy(n_points, beta, e_xc_local, 1, e_xc, 1)
         call daxpy(n_points, beta, v_rho_local, 1, v_rho, 1)

         if (this%functionals(i)%family == "GGA") then

            call daxpy(n_points, beta, v_sigma_local, 1, v_sigma, 1)

         end if

      end do

      call mem%dealloc(e_xc_local)
      call mem%dealloc(v_rho_local)
      call mem%dealloc(v_sigma_local)

   end subroutine calculate_exc_vxc_functional_manager


   subroutine calculate_td_vxc_fxc_functional_manager(this, &
                                                      n_points, &
                                                      rho, &
                                                      sigma, &
                                                      v_rho, &
                                                      v_sigma, &
                                                      v2_rho2, &
                                                      v2_rhosigma, &
                                                      v2_sigma2)
      !!
      !! Written by Tommaso Giovannini and Marco Scavino, 2025
      !!
      !! This subroutine returns the XC contribution to G in TDDFT
      !!

      use memory_manager_class, only: mem
      implicit none

      class(functional_manager), intent(inout) :: this
      integer, intent(in) :: n_points

      real(dp), dimension(n_points), intent(in) :: rho
      real(dp), dimension(n_points), intent(in) :: sigma
      real(dp), dimension(n_points), intent(out) :: v_rho
      real(dp), dimension(n_points), intent(out) :: v_sigma
      real(dp), dimension(n_points), intent(out) :: v2_rho2
      real(dp), dimension(n_points), intent(out) :: v2_rhosigma
      real(dp), dimension(n_points), intent(out) :: v2_sigma2

      integer :: i
      real(dp) :: beta
      real(dp), dimension(:), allocatable :: v_rho_local, v_sigma_local, v2_rho2_local, v2_rhosigma_local, &
                                             v2_sigma2_local

      call mem%alloc(v2_rho2_local, n_points, set_zero=.true.)
      do i = 1, this%n_functionals

         call mem%alloc(v_rho_local, n_points, set_zero=.true.)
         call mem%alloc(v_sigma_local, n_points, set_zero=.true.)
         call mem%alloc(v2_rhosigma_local, n_points, set_zero=.true.)
         call mem%alloc(v2_sigma2_local, n_points, set_zero=.true.)

         call this%functionals(i)%calculate_td_vxc_fxc(n_points, &
                                                       rho, &
                                                       sigma, &
                                                       v_rho_local, &
                                                       v_sigma_local, &
                                                       v2_rho2_local, &
                                                       v2_rhosigma_local, &
                                                       v2_sigma2_local)

         ! If hybrid exchange, scale by (1 - alpha)
         beta = one

         if (this%functionals(i)%hf_fraction > zero .and. this%functionals(i)%kind_ == "EXCHANGE") then
            beta = (one - this%functionals(i)%hf_fraction)
         end if

         call daxpy(n_points, beta, v2_rho2_local, 1, v2_rho2, 1)

         if (this%functionals(i)%family == "GGA") then
            call daxpy(n_points, beta, v_rho_local, 1, v_rho, 1)
            call daxpy(n_points, beta, v_sigma_local, 1, v_sigma, 1)
            call daxpy(n_points, beta, v2_rhosigma_local, 1, v2_rhosigma, 1)
            call daxpy(n_points, beta, v2_sigma2_local, 1, v2_sigma2, 1)
         end if
         call mem%dealloc(v_rho_local)
         call mem%dealloc(v_sigma_local)
         call mem%dealloc(v2_rhosigma_local)
         call mem%dealloc(v2_sigma2_local)

      end do

      call mem%dealloc(v2_rho2_local)


   end subroutine calculate_td_vxc_fxc_functional_manager


   subroutine get_library(selected, library_name_version, library_reference, library_reference_doi)
      !!
      !! Written by Marco Scavino and Tommaso Giovannini, 2022
      !!
      !! Select the available library
      !!
      use warning_suppressor, only: do_nothing
#ifdef LIBXC_MAJOR
      use libxc_class, only: libxc, xc_f03_version_string, xc_f03_reference, xc_f03_reference_doi
#endif
      implicit none

      class(functional), allocatable :: selected
      character(len=*), intent(inout) :: library_name_version
      character(len=*), intent(inout) :: library_reference
      character(len=*), intent(inout) :: library_reference_doi
      character(len=200) :: version

#ifdef LIBXC_MAJOR
      allocate(libxc :: selected)
      call xc_f03_version_string(version)
      library_name_version = "LibXC " // trim(version)
      call xc_f03_reference(library_reference)
      call xc_f03_reference_doi(library_reference_doi)
#else
      call do_nothing(library_name_version)
      call do_nothing(version)
      call do_nothing(library_reference)
      call do_nothing(library_reference_doi)
      call do_nothing(selected)
      call do_nothing(version)
      call do_nothing(library_name_version)
      call do_nothing(library_reference)
      call do_nothing(library_reference_doi)
      call output%error_msg("eT has not been compiled with a proper functional library!")
#endif

   end subroutine get_library


   subroutine initialize(this)
      !!
      !! Written by Marco Scavino, October 2019
      !!
      implicit none

      class(functional_manager), intent(inout) :: this

      character(len=200), allocatable :: names(:)
      class(functional), allocatable :: selected

      integer :: i

      call this%get_library(selected, &
                            this%library_name_version, &
                            this%library_reference, &
                            this%library_reference_doi)

      call selected%read_functionals_names(names)

      this%n_functionals = size(names)
      allocate(this%functionals(this%n_functionals), source = selected)

      this%hf_percentage = zero

      do i = 1, this%n_functionals

         call this%functionals(i)%initialize(names(i), this%is_polarized, this%rho_threshold)

         if (trim(this%functional_type) == 'lda' .or. this%functionals(i)%family == 'LDA') then

            this%functional_type = 'lda'

         else if (trim(this%functional_type) == 'gga' .or. this%functionals(i)%family == 'GGA') then

            this%functional_type = 'gga'

         end if

         if (this%hf_fraction > zero .or. this%functionals(i)%hf_fraction > zero) then

            this%hf_fraction = this%hf_fraction + this%functionals(i)%hf_fraction

         end if

      end do

   end subroutine initialize


end module

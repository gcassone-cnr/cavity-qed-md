

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_ao_eri_getter_class

   !!
   !! Abstract AO ERI getter class
   !! Written by Sara Angelico, 2022
   !!
   !! Interface definition for the ERI getter
   !!

   use parameters

   implicit none

   type, abstract :: abstract_ao_eri_getter

   contains

      procedure(get_eri_abstract), deferred, public :: get_eri
      procedure(cleanup_abstract), deferred, public :: cleanup

   end type abstract_ao_eri_getter

   abstract interface

      subroutine get_eri_abstract(this, g, A, B, C, D, precision, skip)

         use parameters
         import abstract_ao_eri_getter

         implicit none

         class(abstract_ao_eri_getter), intent(in) :: this
         integer :: A, B, C, D
         real(dp), dimension(*), intent(out) :: g
         real(dp), intent(in), optional :: precision
         integer, intent(out), optional :: skip

      end subroutine get_eri_abstract


      subroutine cleanup_abstract(this)

         import abstract_ao_eri_getter

         implicit none

         class(abstract_ao_eri_getter), intent(inout) :: this

      end subroutine cleanup_abstract

   end interface

end module abstract_ao_eri_getter_class

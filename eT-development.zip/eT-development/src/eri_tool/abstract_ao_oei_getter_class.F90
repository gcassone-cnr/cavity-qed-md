

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_ao_oei_getter_class

   !!
   !! Abstract AO OEI getter class
   !! Written by Sara Angelico, 2022
   !!
   !! Interface definition for the OEI tools
   !!
   !!

   use kinds, only: dp

   implicit none

   type, abstract :: abstract_ao_oei_getter

   contains

      procedure(get_oei_abstract), deferred, public :: get_oei

   end type abstract_ao_oei_getter

   abstract interface

      subroutine get_oei_abstract(this, oei_type, oei, screening)

         import dp
         import abstract_ao_oei_getter

         implicit none

         class(abstract_ao_oei_getter), intent(in) :: this
         character(len=*), intent(in) :: oei_type
         logical, intent(in), optional :: screening

         real(dp), dimension(*), intent(out) :: oei

      end subroutine get_oei_abstract

   end interface

end module abstract_ao_oei_getter_class

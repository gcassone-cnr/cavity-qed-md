

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module qed_ao_eri_getter_class
   !!
   !! QED AO ERI getter class
   !! Written by Sarai D. Folkestad, Tor S. Haugland, Sara Angelico, 2022
   !!
   !! Tool to extract ERIs from the AO-tool
   !! and add the QED specific two electron integrals
   !!
   !!
   use parameters

   use abstract_ao_eri_getter_class, only: abstract_ao_eri_getter

   use global_in, only: input
   use global_out, only: output
   use memory_manager_class, only: mem
   use ao_tool_class, only: ao_tool

   implicit none

   type, extends(abstract_ao_eri_getter) :: qed_ao_eri_getter

      class(ao_tool), pointer, private :: ao
      integer, private :: n_modes
      real(dp), dimension(:, :, :), allocatable, private :: scaled_polarized_dipole

   contains

      procedure, public :: get_eri => get_eri_qed_ao_eri_getter
      procedure, public :: cleanup => cleanup_qed_ao_eri_getter

      procedure, private :: add_ao_g_contribution
      procedure, private :: initialize_scaled_polarized_dipole
      procedure, private :: get_polarized_ao_dipole_wx
      procedure, private :: get_self_couplings
      procedure, private :: get_polarizations
      procedure, private, nopass :: wavevector_to_polarizations

   end type qed_ao_eri_getter

   interface qed_ao_eri_getter

      procedure :: new_qed_ao_eri_getter

   end interface qed_ao_eri_getter

contains


   function new_qed_ao_eri_getter(ao) result(this)
      !!
      !! Written by Sarai D. Folkestad, Tor S. Haugland and Sara Angelico, 2021-2022
      !!
      implicit none

      type(qed_ao_eri_getter) :: this
      class(ao_tool), intent(in), target :: ao

      this%ao => ao

      this%n_modes = 0
      call input%get_required_keyword('modes', 'boson', this%n_modes)

      call this%initialize_scaled_polarized_dipole()

   end function new_qed_ao_eri_getter


   subroutine get_eri_qed_ao_eri_getter(this, g, A, B, C, D, precision, skip)
      !!
      !! Written by Eirik F. Kjoenstad, Sarai D. Folkestad,
      !! Tor S. Haugland and Sara Angelico, 2020-2022
      !!
      !! Get electron repulsion integrals for the shell quartet (A, B, C, D) with
      !! QED contribution.
      !!
      implicit none

      class(qed_ao_eri_getter), intent(in) :: this
      integer :: A, B, C, D
      real(dp), dimension(*), intent(out) :: g
      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      call this%ao%get_eri(g, A, B, C, D, precision, skip)
      call this%add_ao_g_contribution(g, A, B, C, D)

   end subroutine get_eri_qed_ao_eri_getter


   subroutine cleanup_qed_ao_eri_getter(this)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      implicit none

      class(qed_ao_eri_getter), intent(inout) :: this

      call mem%dealloc(this%scaled_polarized_dipole)

   end subroutine cleanup_qed_ao_eri_getter


   subroutine add_ao_g_contribution(this, g, A, B, C, D)
      !!
      !! Written by Tor S. Haugland and Sara Angelico, 2022
      !!
      !! Add quadratic self-energy QED contribution to electron repulsion integrals for the
      !! shell quartet (A, B, C, D).
      !!
      !!    g += 2/omega * g_wx g_yz
      !!
      implicit none

      class(qed_ao_eri_getter), intent(in) :: this
      integer :: A, B, C, D
      real(dp), dimension(this%ao%shells(A)%length * this%ao%shells(B)%length * this%ao%shells(C)%length &
         * this%ao%shells(D)%length), intent(out), target :: g

      real(dp), dimension(:, :, :, :), pointer :: g_p
      integer :: w, x, y, z, mode

      g_p(this%ao%shells(A)%first:this%ao%shells(A)%get_last(), &
          this%ao%shells(B)%first:this%ao%shells(B)%get_last(), &
          this%ao%shells(C)%first:this%ao%shells(C)%get_last(), &
          this%ao%shells(D)%first:this%ao%shells(D)%get_last()) => g

      do mode = 1, this%n_modes
         do z = this%ao%shells(D)%first, this%ao%shells(D)%get_last()
            do y = this%ao%shells(C)%first, this%ao%shells(C)%get_last()
               do x = this%ao%shells(B)%first, this%ao%shells(B)%get_last()
                  do w = this%ao%shells(A)%first, this%ao%shells(A)%get_last()

                     g_p(w, x, y, z) = g_p(w, x, y, z) &
                                       + this%scaled_polarized_dipole(w, x, mode) &
                                       * this%scaled_polarized_dipole(y, z, mode)

                  end do
               end do
            end do
         end do
      end do

   end subroutine add_ao_g_contribution


   subroutine initialize_scaled_polarized_dipole(this)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      !! Sets the dipole integrals needed for computation of the two-
      !! electron integral contribution (ERI).
      !!
      implicit none

      class(qed_ao_eri_getter), intent(inout) :: this
      real(dp), dimension(this%n_modes) :: couplings
      integer :: mode
      real(dp) :: scalar

      call this%get_self_couplings(couplings)

      call mem%alloc(this%scaled_polarized_dipole, this%ao%n, this%ao%n, this%n_modes)
      do mode = 1, this%n_modes
         scalar = sqrt(two * couplings(mode))
         call this%get_polarized_ao_dipole_wx(this%scaled_polarized_dipole(:, :, mode), mode)
         call dscal(this%ao%n**2, scalar, this%scaled_polarized_dipole(:, :, mode), 1)
      end do

   end subroutine initialize_scaled_polarized_dipole


   subroutine get_polarized_ao_dipole_wx(this, dipole_wx, mode)
      !!
      !! Written by Tor S. Haugland and Sara Angelico, 2022
      !!
      !! Gets the product between the photon transversal polarization
      !! and the dipole moments.
      !!    dipole_wx = <w| (e dot dipole_el) |x> + (e dot dipole_nuc) S_wx / N_el
      !!       e : transversal polarization vector
      !!
      use array_initialization, only: zero_array
      use point_charges_class, only: point_charges

      implicit none

      class(qed_ao_eri_getter), intent(in) :: this
      real(dp), dimension(:, :), intent(out) :: dipole_wx
      integer, intent(in) :: mode

      real(dp), external :: ddot
      integer :: i
      real(dp), dimension(3, this%n_modes) :: polarizations
      real(dp), dimension(:, :, :), allocatable :: ao_dipole
      real(dp), dimension(3) :: dipole_nuc
      real(dp) :: d_nuc
      type(point_charges) :: pc

      call this%get_polarizations(polarizations)

      ! Electronic Contribution

      call mem%alloc(ao_dipole, this%ao%n, this%ao%n, 3)
      call this%ao%get_oei('dipole', ao_dipole)

      call zero_array(dipole_wx, this%ao%n**2)
      do i = 1, 3
         call daxpy(this%ao%n**2, polarizations(i, mode), ao_dipole(:, :, i), 1, dipole_wx, 1)
      end do

      ! Nuclear Contribution

      call this%ao%get_point_charges(pc)
      dipole_nuc = pc%get_dipole()
      d_nuc = ddot(3, dipole_nuc, 1, polarizations(:, mode), 1)

      call daxpy(this%ao%n**2, d_nuc / this%ao%get_n_electrons(), this%ao%S, 1, dipole_wx, 1)

      call mem%dealloc(ao_dipole)

   end subroutine get_polarized_ao_dipole_wx


   subroutine get_self_couplings(this, couplings)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      !! Reads the input and gets the self-coupling in QED calculations
      !!    Self-coupling = 0.5 lambda^2
      !!
      implicit none

      class(qed_ao_eri_getter), intent(in) :: this
      real(dp), dimension(this%n_modes), intent(out) :: couplings


      if (input%is_keyword_present('coupling self', 'boson')) then

         call input%get_array_for_keyword('coupling self', 'boson', this%n_modes, couplings)

      elseif (input%is_keyword_present('coupling', 'boson')) then

         call input%get_array_for_keyword('coupling', 'boson', this%n_modes, couplings)
         couplings = half * couplings**2

      else

         call output%error_msg("Keyword coupling or coupling self must be specified")

      end if

   end subroutine


   subroutine get_polarizations(this, polarizations)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      !! Reads the input and gets the polarizations in QED calculations
      !!
      implicit none

      class(qed_ao_eri_getter), intent(in) :: this
      real(dp), dimension(3, this%n_modes) :: polarizations
      real(dp), dimension(3) :: k
      integer :: i

      if (input%is_keyword_present('wavevector', 'boson')) then

         call input%get_array_for_keyword('wavevector', 'boson', 3, k)

         do i = 1, this%n_modes, 2
            call this%wavevector_to_polarizations(k, polarizations(:, i), polarizations(:, i + 1))
         end do

      else if (input%is_keyword_present('polarization', 'boson')) then

         call input%get_array_for_keyword('polarization', 'boson', 3, polarizations(:, 1))

         do i = 1, this%n_modes
            polarizations(:, i) = polarizations(:, 1)
         end do

      else

         call output%error_msg("Keyword wavevector or polarization must be specified")

      end if


   end subroutine get_polarizations


   subroutine wavevector_to_polarizations(wavevector, pol_1, pol_2)
      !!
      !! Written by Tor S. Haugland, May 2021
      !!
      !! From a wavevector, form two orthogonal polarization directions.
      !!
      use math_utilities, only: cross_product_R3
      use array_utilities, only: are_vectors_parallel

      implicit none

      real(dp), dimension(3), intent(in) :: wavevector
      real(dp), dimension(3), intent(out) :: pol_1, pol_2
      real(dp), dimension(3) :: rand_vec
      logical :: is_parallel

      rand_vec = [zero, zero, one]
      is_parallel = are_vectors_parallel(rand_vec, wavevector, 3, 1d-10)
      if (is_parallel) rand_vec = [zero, one, zero]

      pol_1 = cross_product_R3(rand_vec, wavevector)
      pol_1 = pol_1 / norm2(pol_1)

      pol_2 = cross_product_R3(wavevector, pol_1)
      pol_2 = pol_2 / norm2(pol_2)

   end subroutine wavevector_to_polarizations


end module qed_ao_eri_getter_class

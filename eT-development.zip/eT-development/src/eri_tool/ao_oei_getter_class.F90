

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module ao_oei_getter_class

   !!
   !! AO OEI getter class
   !! Written by Sara Angelico and Tor S. Haugland, 2022
   !!
   !! Tool to extract OEIs from the AO-tool
   !!

   use kinds, only: dp

   use ao_tool_class, only: ao_tool
   use abstract_ao_oei_getter_class, only: abstract_ao_oei_getter

   implicit none

   type, extends(abstract_ao_oei_getter) :: ao_oei_getter

      type(ao_tool), pointer, private :: ao

   contains

      procedure, public :: get_oei => get_oei_ao_oei_getter
      procedure, public :: get_oei_1der => get_oei_1der_ao_oei_getter
      procedure, public :: get_oei_1der_shell => get_oei_1der_shell_ao_oei_getter

   end type ao_oei_getter

   interface ao_oei_getter

      procedure :: new_ao_oei_getter

   end interface ao_oei_getter

contains


   function new_ao_oei_getter(ao) result(this)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      implicit none

      type(ao_oei_getter) :: this
      class(ao_tool), intent(in), target :: ao

      this%ao => ao

   end function new_ao_oei_getter


   subroutine get_oei_ao_oei_getter(this, oei_type, oei, screening)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      !! Wrapper for ao tool routine
      !!
      implicit none

      class(ao_oei_getter), intent(in) :: this
      character(len=*), intent(in) :: oei_type
      logical, intent(in), optional :: screening

      real(dp), dimension(*), intent(out) :: oei

      logical :: screening_local

      screening_local = .false.
      if (present(screening)) screening_local = screening

      call this%ao%get_oei(oei_type, oei, screening_local)

   end subroutine get_oei_ao_oei_getter


   subroutine get_oei_1der_ao_oei_getter(this, oei_type, oei)
      !!
      !! Written by Marcus T. Lexander, 2023
      !!
      implicit none

      class(ao_oei_getter), intent(in) :: this
      character(len=*), intent(in) :: oei_type

      real(dp), dimension(*), intent(out) :: oei

      call this%ao%get_oei_1der(oei_type, oei)

   end subroutine get_oei_1der_ao_oei_getter


   subroutine get_oei_1der_shell_ao_oei_getter(this, oei_type, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, 2024
      !!
      implicit none

      class(ao_oei_getter), intent(in) :: this
      character(len=*), intent(in) :: oei_type

      real(dp), dimension(:), intent(out) :: oei

      integer, intent(in) :: A, B

      call this%ao%get_oei_1der_shell(oei_type, oei, A, B)

   end subroutine get_oei_1der_shell_ao_oei_getter

end module ao_oei_getter_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module qed_ao_oei_getter_class

   !!
   !! QED AO OEI getter class
   !! Written by Sara Angelico and Tor S. Haugland, 2022
   !!
   !! Tool to extract OEIs from the AO-tool
   !! and add the QED specific two electron integrals
   !!

   use kinds, only: dp

   use abstract_ao_oei_getter_class, only: abstract_ao_oei_getter

   use ao_tool_class, only: ao_tool
   use boson_tool_class, only: boson_tool

   implicit none

   type, extends(abstract_ao_oei_getter) :: qed_ao_oei_getter

      type(ao_tool), pointer, private :: ao
      class(boson_tool), pointer, private :: qed

   contains

      procedure, public :: get_oei => get_oei_qed_ao_oei_getter

   end type qed_ao_oei_getter

   interface qed_ao_oei_getter

      procedure :: new_qed_ao_oei_getter

   end interface qed_ao_oei_getter

contains


   function new_qed_ao_oei_getter(ao, qed) result(this)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      implicit none

      type(qed_ao_oei_getter) :: this
      class(ao_tool), intent(in), target :: ao
      class(boson_tool), intent(in), target :: qed

      this%ao => ao
      this%qed => qed

   end function new_qed_ao_oei_getter


   subroutine get_oei_qed_ao_oei_getter(this, oei_type, oei, screening)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      !! Wrapper for ao tool routine that adds the qed contribution
      !! to the one-electron part of the hamiltonian
      !!
      implicit none

      class(qed_ao_oei_getter), intent(in) :: this
      character(len=*), intent(in) :: oei_type
      logical, intent(in), optional :: screening

      real(dp), dimension(*), intent(out) :: oei

      logical :: screening_local

      screening_local = .false.

      if (present(screening)) screening_local = screening

      call this%ao%get_oei(oei_type, oei, screening_local)

      if (oei_type == "hamiltonian") then
         call this%qed%add_ao_h_contribution(oei)
      end if

   end subroutine get_oei_qed_ao_oei_getter

end module qed_ao_oei_getter_class



! eT - a coupled cluster program
! Copyright (C) 2016-2025 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module qed_ao_eri_1der_getter_class
   !!
   !! AO ERI-1der getter class
   !! Written by Marcus T. Lexander, 2024
   !!
   !! Tool to extract derivative ERIs from the AO-tool
   !!
   !!
   use kinds, only: dp

   use global_in, only: input
   use global_out, only: output
   use ao_tool_class, only: ao_tool
   use abstract_ao_eri_getter_class, only: abstract_ao_eri_getter
   use memory_manager_class, only: mem
   use parameters

   implicit none

   type, extends(abstract_ao_eri_getter) :: qed_ao_eri_1der_getter

      class(ao_tool), pointer, private :: ao

      integer, private :: n_modes

      real(dp), private :: d_nuc
      real(dp), dimension(3) :: mu_nuc
      real(dp), dimension(:, :, :, :), allocatable, private :: overlap_1der
      real(dp), dimension(:, :, :, :, :), allocatable, private :: dipole_1der
      real(dp), dimension(:, :, :), allocatable, private :: scaled_polarized_dipole

   contains

      procedure, public :: get_eri => get_eri_qed_ao_eri_1der_getter
      procedure, public :: cleanup => cleanup_qed_ao_eri_1der_getter

      procedure, private :: add_ao_g_1der_contribution
      procedure, private :: initialize_scaled_polarized_dipole
      procedure, private :: initialize_1der_quantities
      procedure, private :: get_polarized_ao_dipole_wx
      procedure, private :: get_self_couplings
      procedure, private :: get_polarizations
      procedure, private :: get_d_nuc_divided_N_el
      procedure, private, nopass :: wavevector_to_polarizations

      procedure, private :: construct_scaled_polarized_dipole_1der

   end type qed_ao_eri_1der_getter

   interface qed_ao_eri_1der_getter

      procedure :: new_qed_ao_eri_1der_getter

   end interface qed_ao_eri_1der_getter

contains


   function new_qed_ao_eri_1der_getter(ao) result(this)
      !!
      !! Written by Sarai D. Folkestad, Aug 2021
      !!
      implicit none

      type(qed_ao_eri_1der_getter) :: this
      class(ao_tool), intent(in), target :: ao

      this%ao => ao

      this%n_modes = 0
      call input%get_required_keyword('modes', 'boson', this%n_modes)

      call this%initialize_scaled_polarized_dipole()
      call this%initialize_1der_quantities()

   end function new_qed_ao_eri_1der_getter


   subroutine get_eri_qed_ao_eri_1der_getter(this, g, A, B, C, D, precision, skip)
      !!
      !! Written by Marcus T. Lexander, 2024
      !!
      !! Wrapper for ao tool routine
      !!
      implicit none

      class(qed_ao_eri_1der_getter), intent(in) :: this

      integer :: A, B, C, D

      real(dp), dimension(*), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      call this%ao%get_eri_1der(g, A, B, C, D, precision, skip)
      call this%add_ao_g_1der_contribution(g, A, B, C, D)

   end subroutine get_eri_qed_ao_eri_1der_getter


   subroutine add_ao_g_1der_contribution(this, g, A, B, C, D)
      !!
      !! Written by Sara Angelico and Eirik F. Kjoenstad, 2024
      !!
      !! Adds the derivative of the quadratic self-energy QED contribution (electronic+overlap)
      !! to electron repulsion integrals for the shell quartet (A, B, C, D).
      !! The derivative of the nuclear dipole moment is treated separately
      !!
      !!    g' += 2/omega * g'_wx g_yz when differentiating w or x
      !!    g' += 2/omega * g_wx g'_yz when differentiating y or z
      !!    g'_xy = g'_xy(el) + d_nuc * S'_xy
      !!
      implicit none

      class(qed_ao_eri_1der_getter), intent(in) :: this
      integer :: A, B, C, D
      real(dp), dimension(this%ao%shells(A)%length * this%ao%shells(B)%length * this%ao%shells(C)%length &
         * this%ao%shells(D)%length * 3 * 4), intent(inout), target :: g

      real(dp), dimension(:, :, :, :, :, :), pointer :: g_p
      integer :: w, x, y, z, mode, q, k

      g_p(1:this%ao%shells(A)%length, &
          1:this%ao%shells(B)%length, &
          1:this%ao%shells(C)%length, &
          1:this%ao%shells(D)%length, &
          1:3, &
          1:4 &
      ) => g(1:this%ao%shells(A)%length * this%ao%shells(B)%length * this%ao%shells(C)%length &
         * this%ao%shells(D)%length * 3 * 4)

      do mode = 1, this%n_modes
         do k = 1, 2
            do q = 1, 3
               do z = 1, this%ao%shells(D)%length
                  do y = 1, this%ao%shells(C)%length
                     do x = 1, this%ao%shells(B)%length
                        do w = 1, this%ao%shells(A)%length

                           g_p(w, x, y, z, q, k) = g_p(w, x, y, z, q, k) &
                                                   + this%scaled_polarized_dipole(y &
                                                   + this%ao%shells(C)%first - 1, &
                                                   z + this%ao%shells(D)%first - 1, mode) &
                                                   * (this%dipole_1der(w + this%ao%shells(A)%first - 1, &
                                                   x + this%ao%shells(B)%first - 1, q, k, mode) &
                                                   + this%d_nuc &
                                                   * this%overlap_1der(w + this%ao%shells(A)%first - 1, &
                                                   x + this%ao%shells(B)%first - 1, q, k))

                        end do
                     end do
                  end do
               end do
            end do
         end do
      end do

      do mode = 1, this%n_modes
         do k = 3, 4
            do q = 1, 3
               do z = 1, this%ao%shells(D)%length
                  do y = 1, this%ao%shells(C)%length
                     do x = 1, this%ao%shells(B)%length
                        do w = 1, this%ao%shells(A)%length

                           g_p(w, x, y, z, q, k) = g_p(w, x, y, z, q, k) &
                                                   + this%scaled_polarized_dipole(w &
                                                   + this%ao%shells(A)%first - 1, &
                                                   x + this%ao%shells(B)%first - 1, mode) &
                                                   * (this%dipole_1der(y + this%ao%shells(C)%first - 1, &
                                                   z + this%ao%shells(D)%first - 1, q, k - 2, mode) &
                                                   + this%d_nuc &
                                                   * this%overlap_1der(y + this%ao%shells(C)%first - 1, &
                                                   z + this%ao%shells(D)%first - 1, q, k - 2))

                        end do
                     end do
                  end do
               end do
            end do
         end do
      end do

   end subroutine add_ao_g_1der_contribution


   subroutine initialize_scaled_polarized_dipole(this)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      !! Sets the dipole integrals needed for computation of the two-
      !! electron integral contribution (ERI).
      !!
      implicit none

      class(qed_ao_eri_1der_getter), intent(inout) :: this
      real(dp), dimension(this%n_modes) :: couplings
      integer :: mode
      real(dp) :: scalar

      call this%get_self_couplings(couplings)

      call mem%alloc(this%scaled_polarized_dipole, this%ao%n, this%ao%n, this%n_modes)
      do mode = 1, this%n_modes
         scalar = sqrt(two * couplings(mode))
         call this%get_polarized_ao_dipole_wx(this%scaled_polarized_dipole(:, :, mode), mode)
         call dscal(this%ao%n**2, scalar, this%scaled_polarized_dipole(:, :, mode), 1)
      end do

   end subroutine initialize_scaled_polarized_dipole


   subroutine initialize_1der_quantities(this)
      !!
      !! Written by Marcus T. Lexander, 2024
      !!
      use point_charges_class, only: point_charges

      implicit none

      class(qed_ao_eri_1der_getter), intent(inout) :: this

      real(dp), dimension(:), allocatable, target :: buf
      real(dp), dimension(:, :, :, :), pointer :: overlap_sh_ptr
      real(dp), dimension(:, :, :, :, :), pointer :: dipole_sh_ptr

      integer :: A, B

      type(point_charges) :: pc

      call mem%alloc(this%overlap_1der, this%ao%n, this%ao%n, 3, 2)

      call mem%alloc(buf, this%ao%max_sh_size**2 * 3 * 2 * 3 * this%n_modes)

      do A = 1, this%ao%n_sh
         do B = 1, this%ao%n_sh
            call this%ao%get_overlap_1der_shell(buf, A, B)
            overlap_sh_ptr(this%ao%shells(A)%first:this%ao%shells(A)%get_last(), &
                           this%ao%shells(B)%first:this%ao%shells(B)%get_last(), &
                           1:3, &
                           1:2) => buf(1:this%ao%shells(A)%length * this%ao%shells(B)%length * 3 * 2)

            this%overlap_1der(this%ao%shells(A)%first:this%ao%shells(A)%get_last(), &
               this%ao%shells(B)%first:this%ao%shells(B)%get_last(), :, :) = overlap_sh_ptr(:, :, :, :)
         end do
      end do

      call mem%alloc(this%dipole_1der, this%ao%n, this%ao%n, 3, 2, this%n_modes)

      do A = 1, this%ao%n_sh
         do B = 1, this%ao%n_sh
            call this%construct_scaled_polarized_dipole_1der(buf, A, B)
            dipole_sh_ptr(this%ao%shells(A)%first:this%ao%shells(A)%get_last(), &
                          this%ao%shells(B)%first:this%ao%shells(B)%get_last(), &
                          1:3, &
                          1:2, &
                          1:this%n_modes &
            ) => buf(1:this%ao%shells(A)%length * this%ao%shells(B)%length * 3 * 2 * this%n_modes)

            this%dipole_1der(this%ao%shells(A)%first:this%ao%shells(A)%get_last(), &
               this%ao%shells(B)%first:this%ao%shells(B)%get_last(), :, :, :) = dipole_sh_ptr(:, :, :, :, :)
         end do
      end do

      call mem%dealloc(buf)

      call this%get_d_nuc_divided_N_el(this%d_nuc)

      call this%ao%get_point_charges(pc)
      this%mu_nuc = pc%get_dipole()

   end subroutine initialize_1der_quantities


   subroutine construct_scaled_polarized_dipole_1der(this, scaled_dipole_1der_CD_qk, C, D)
      !!
      !! Written by Sara Angelico and Eirik F. Kjoenstad, 2024
      !!
      use reordering_r, only: sort_to_2134
      implicit none

      class(qed_ao_eri_1der_getter), intent(in) :: this

      integer, intent(in) :: C, D
      real(dp), dimension(this%ao%shells(C)%length, this%ao%shells(D)%length, 3, 2, this%n_modes) :: &
         scaled_dipole_1der_CD_qk

      real(dp), dimension(:), allocatable, target :: dipole_1der_CD_qmu
      real(dp), dimension(:), allocatable :: dipole_1der_DC_qmu_unsorted
      real(dp), dimension(:), allocatable, target :: dipole_1der_DC_qmu
      real(dp), dimension(:, :, :, :), pointer :: dipole_1der_CD_qmu_p
      real(dp), dimension(:, :, :, :), pointer :: dipole_1der_DC_qmu_p

      real(dp), dimension(3, this%n_modes) :: polarizations
      real(dp), dimension(this%n_modes) :: couplings

      integer :: mode, mu
      real(dp) :: scalar

      scaled_dipole_1der_CD_qk = zero

      call mem%alloc(dipole_1der_CD_qmu, this%ao%shells(C)%length * this%ao%shells(D)%length * 3 * 3)
      call mem%alloc(dipole_1der_DC_qmu_unsorted, this%ao%shells(C)%length * this%ao%shells(D)%length * 3 * 3)

      dipole_1der_CD_qmu = zero
      dipole_1der_DC_qmu_unsorted = zero

      call this%ao%get_dipole_1der_shell(dipole_1der_CD_qmu, C, D)
      call this%ao%get_dipole_1der_shell(dipole_1der_DC_qmu_unsorted, D, C)

      call mem%alloc(dipole_1der_DC_qmu, this%ao%shells(C)%length * this%ao%shells(D)%length * 3 * 3)

      call sort_to_2134(dipole_1der_DC_qmu_unsorted, &
                        dipole_1der_DC_qmu, &
                        this%ao%shells(D)%length, &
                        this%ao%shells(C)%length, &
                        3, &
                        3)

      dipole_1der_DC_qmu_p(1:this%ao%shells(C)%length, &
                           1:this%ao%shells(D)%length, &
                           1:3, &
                           1:3 &
      ) => dipole_1der_DC_qmu(1:this%ao%shells(C)%length * this%ao%shells(D)%length * 3 * 3)

      dipole_1der_CD_qmu_p(1:this%ao%shells(C)%length, &
                           1:this%ao%shells(D)%length, &
                           1:3, &
                           1:3 &
      ) => dipole_1der_CD_qmu(1:this%ao%shells(C)%length * this%ao%shells(D)%length * 3 * 3)

      if (this%ao%shell_to_center(C) == this%ao%shell_to_center(D)) then
         dipole_1der_DC_qmu = half * dipole_1der_DC_qmu
         dipole_1der_CD_qmu = half * dipole_1der_CD_qmu
      end if

      call this%get_polarizations(polarizations)
      call this%get_self_couplings(couplings)

      do mode = 1, this%n_modes
         scalar = sqrt(two * couplings(mode))
         do mu = 1, 3

            call daxpy(this%ao%shells(C)%length * this%ao%shells(D)%length * 3, &
                       polarizations(mu, mode), &
                       dipole_1der_CD_qmu_p(:, :, :, mu), &
                       1, &
                       scaled_dipole_1der_CD_qk(:, :, :, 2, mode), &
                       1)

         end do

         call dscal(this%ao%shells(C)%length * this%ao%shells(D)%length * 3, &
                    scalar, &
                    scaled_dipole_1der_CD_qk(:, :, :, 2, mode), &
                    1)

      end do

      do mode = 1, this%n_modes
         scalar = sqrt(two * couplings(mode))
         do mu = 1, 3

            call daxpy(this%ao%shells(C)%length * this%ao%shells(D)%length * 3, &
                       polarizations(mu, mode), &
                       dipole_1der_DC_qmu_p(:, :, :, mu), &
                       1, &
                       scaled_dipole_1der_CD_qk(:, :, :, 1, mode), &
                       1)

         end do

         call dscal(this%ao%shells(C)%length * this%ao%shells(D)%length * 3, &
                    scalar, &
                    scaled_dipole_1der_CD_qk(:, :, :, 1, mode), &
                    1)

      end do

      call mem%dealloc(dipole_1der_CD_qmu)
      call mem%dealloc(dipole_1der_DC_qmu_unsorted)
      call mem%dealloc(dipole_1der_DC_qmu)

   end subroutine construct_scaled_polarized_dipole_1der


   subroutine get_d_nuc_divided_N_el(this, d_nuc)
      !!
      !! Written by Sara Angelico, January 2024
      !!
      use point_charges_class, only: point_charges

      implicit none

      class(qed_ao_eri_1der_getter) :: this
      real(dp), intent(out) :: d_nuc
      real(dp) :: ddot, scalar
      real(dp), dimension(3) :: mu_nuc
      real(dp), dimension(3, this%n_modes) :: polarizations
      real(dp), dimension(this%n_modes) :: couplings

      type(point_charges) :: pc

      integer :: mode

      d_nuc = zero

      call this%ao%get_point_charges(pc)
      mu_nuc = pc%get_dipole()

      call this%get_self_couplings(couplings)
      call this%get_polarizations(polarizations)

      do mode = 1, this%n_modes
         scalar = sqrt(two * couplings(mode))
         d_nuc = d_nuc + ddot(3, mu_nuc, 1, polarizations(:, mode), 1)
         d_nuc = scalar * d_nuc
      end do

      d_nuc = d_nuc / this%ao%get_n_electrons()

   end subroutine get_d_nuc_divided_N_el


   subroutine get_self_couplings(this, couplings)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      !! Reads the input and gets the self-coupling in QED calculations
      !!    Self-coupling = 0.5 lambda^2
      !!
      implicit none

      class(qed_ao_eri_1der_getter), intent(in) :: this
      real(dp), dimension(this%n_modes), intent(out) :: couplings

      if (input%is_keyword_present('coupling', 'boson')) then

         call input%get_array_for_keyword('coupling', 'boson', this%n_modes, couplings)
         couplings = half * couplings**2

      elseif (input%is_keyword_present('coupling self', 'boson')) then

         call input%get_array_for_keyword('coupling self', 'boson', this%n_modes, couplings)

      else

         call output%error_msg("Keyword coupling or coupling self must be specified")

      end if

   end subroutine


   subroutine get_polarizations(this, polarizations)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      !! Reads the input and gets the polarizations in QED calculations
      !!
      implicit none

      class(qed_ao_eri_1der_getter), intent(in) :: this
      real(dp), dimension(3, this%n_modes) :: polarizations
      real(dp), dimension(3) :: k
      integer :: i

      if (input%is_keyword_present('wavevector', 'boson')) then

         call input%get_array_for_keyword('wavevector', 'boson', 3, k)

         do i = 1, this%n_modes, 2
            call this%wavevector_to_polarizations(k, polarizations(:, i), polarizations(:, i + 1))
         end do

      else if (input%is_keyword_present('polarization', 'boson')) then

         call input%get_array_for_keyword('polarization', 'boson', 3, polarizations(:, 1))

         do i = 1, this%n_modes
            polarizations(:, i) = polarizations(:, 1)
         end do

      else

         call output%error_msg("Keyword wavevector or polarization must be specified")

      end if

   end subroutine get_polarizations


   subroutine wavevector_to_polarizations(wavevector, pol_1, pol_2)
      !!
      !! Written by Tor S. Haugland, May 2021
      !!
      !! From a wavevector, form two orthogonal polarization directions.
      !!
      use math_utilities, only: cross_product_R3
      use array_utilities, only: are_vectors_parallel

      implicit none

      real(dp), dimension(3), intent(in) :: wavevector
      real(dp), dimension(3), intent(out) :: pol_1, pol_2
      real(dp), dimension(3) :: rand_vec
      logical :: is_parallel

      rand_vec = [zero, zero, one]
      is_parallel = are_vectors_parallel(rand_vec, wavevector, 3, 1d-10)
      if (is_parallel) rand_vec = [zero, one, zero]

      pol_1 = cross_product_R3(rand_vec, wavevector)
      pol_1 = pol_1 / norm2(pol_1)

      pol_2 = cross_product_R3(wavevector, pol_1)
      pol_2 = pol_2 / norm2(pol_2)

   end subroutine wavevector_to_polarizations


   subroutine get_polarized_ao_dipole_wx(this, dipole_wx, mode)
      !!
      !! Written by Tor S. Haugland and Sara Angelico, 2022
      !!
      !! Gets the product between the photon transversal polarization
      !! and the dipole moments.
      !!    dipole_wx = <w| (e dot dipole_el) |x> + (e dot dipole_nuc) S_wx / N_el
      !!       e : transversal polarization vector
      !!
      use array_initialization, only: zero_array
      use point_charges_class, only: point_charges

      implicit none

      class(qed_ao_eri_1der_getter), intent(in) :: this
      real(dp), dimension(:, :), intent(out) :: dipole_wx
      integer, intent(in) :: mode

      real(dp), external :: ddot
      integer :: i
      real(dp), dimension(3, this%n_modes) :: polarizations
      real(dp), dimension(:, :, :), allocatable :: ao_dipole
      real(dp), dimension(3) :: dipole_nuc
      real(dp) :: d_nuc
      type(point_charges) :: pc

      call this%get_polarizations(polarizations)

      ! Electronic Contribution

      call mem%alloc(ao_dipole, this%ao%n, this%ao%n, 3)
      call this%ao%get_oei('dipole', ao_dipole)

      call zero_array(dipole_wx, this%ao%n**2)
      do i = 1, 3
         call daxpy(this%ao%n**2, polarizations(i, mode), ao_dipole(:, :, i), 1, dipole_wx, 1)
      end do

      ! Nuclear Contribution

      call this%ao%get_point_charges(pc)
      dipole_nuc = pc%get_dipole()
      d_nuc = ddot(3, dipole_nuc, 1, polarizations(:, mode), 1)

      call daxpy(this%ao%n**2, d_nuc / this%ao%get_n_electrons(), this%ao%S, 1, dipole_wx, 1)

      call mem%dealloc(ao_dipole)

   end subroutine get_polarized_ao_dipole_wx


   subroutine cleanup_qed_ao_eri_1der_getter(this)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!

      implicit none

      class(qed_ao_eri_1der_getter), intent(inout) :: this

      call mem%dealloc(this%overlap_1der)
      call mem%dealloc(this%dipole_1der)
      call mem%dealloc(this%scaled_polarized_dipole)

   end subroutine cleanup_qed_ao_eri_1der_getter

end module qed_ao_eri_1der_getter_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module ao_eri_getter_class
   !!
   !! AO ERI getter class
   !! Written by Sarai D. Folkestad, 2022
   !!
   !! Tool to extract ERIs from the AO-tool
   !!
   !!
   use kinds, only: dp

   use ao_tool_class, only: ao_tool
   use abstract_ao_eri_getter_class, only: abstract_ao_eri_getter

   implicit none

   type, extends(abstract_ao_eri_getter) :: ao_eri_getter

      class(ao_tool), pointer, private :: ao

   contains

      procedure, public :: get_eri => get_eri_ao_eri_getter
      procedure, public :: cleanup => cleanup_ao_eri_getter

   end type ao_eri_getter

   interface ao_eri_getter

      procedure :: new_ao_eri_getter

   end interface ao_eri_getter

contains


   function new_ao_eri_getter(ao) result(this)
      !!
      !! Written by Sarai D. Folkestad, Aug 2021
      !!
      implicit none

      type(ao_eri_getter) :: this
      class(ao_tool), intent(in), target :: ao

      this%ao => ao

   end function new_ao_eri_getter


   subroutine get_eri_ao_eri_getter(this, g, A, B, C, D, precision, skip)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !!
      !! Wrapper for ao tool routine
      !!
      implicit none

      class(ao_eri_getter), intent(in) :: this

      integer :: A, B, C, D

      real(dp), dimension(*), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      call this%ao%get_eri(g, A, B, C, D, precision, skip)

   end subroutine get_eri_ao_eri_getter


   subroutine cleanup_ao_eri_getter(this)
      !!
      !! Written by Sara Angelico and Tor S. Haugland, 2022
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(ao_eri_getter), intent(inout) :: this

      call do_nothing(this)

   end subroutine cleanup_ao_eri_getter


end module ao_eri_getter_class

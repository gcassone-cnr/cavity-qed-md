

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module amplitude_file_storer_class

   !!
   !! Amplitude file storer class
   !! Written by Alexander C. Paul, Mar 2022
   !!
   !! Tool that handles storage of amplitudes, e.g. coupled cluster
   !! ground or excited state amplitudes on file.
   !!

   use parameters
   use stream_file_class, only: stream_file
   use global_out, only: output
   use state_descriptor_class, only: state_descriptor

   implicit none

   type :: amplitude_file_storer

      integer, private :: n_amplitudes
      type(stream_file), private :: file_
      type(state_descriptor) :: descriptor

   contains

      procedure, public :: save_ => save_amplitude_file_storer
      procedure, public :: read_ => read_amplitude_file_storer
      procedure, public :: read_energy => read_energy_amplitude_file_storer
      procedure, public :: get_filename => get_filename_amplitude_file_storer
      procedure, public :: file_exists => file_exists_amplitude_file_storer
      procedure, public :: delete_file => delete_file_amplitude_file_storer

   end type amplitude_file_storer


   interface amplitude_file_storer

      procedure :: new_amplitude_file_storer

   end interface amplitude_file_storer


contains

   function new_amplitude_file_storer(file_name, n_amplitudes) result(this)
      !!
      !! Written by Alexander C. Paul, 2022-2024
      !!
      implicit none

      type(amplitude_file_storer) :: this

      character(len=*), intent(in) :: file_name

      integer :: n_amplitudes

      this%file_ = stream_file(file_name)
      this%n_amplitudes = n_amplitudes

   end function new_amplitude_file_storer


   subroutine save_amplitude_file_storer(this, vector, energy)
      !!
      !! Written by Alexander C. Paul and Sarai D. Folkestad, 2022-2024
      !!
      implicit none

      class(amplitude_file_storer), intent(inout) :: this

      real(dp), dimension(this%n_amplitudes), intent(in) :: vector
      real(dp), intent(in), optional :: energy

      real(dp) :: local_energy

      local_energy = zero
      if (present(energy)) local_energy = energy

      call this%file_%open_('rewind')
      call this%file_%write_(this%n_amplitudes)
      call this%file_%write_(local_energy)
      call this%file_%write_(vector, this%n_amplitudes)
      call this%file_%close_()

   end subroutine save_amplitude_file_storer


   subroutine read_amplitude_file_storer(this, vector, energy, n_read)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      class(amplitude_file_storer), intent(inout) :: this

      real(dp), dimension(this%n_amplitudes), intent(out) :: vector
      real(dp), intent(out), optional :: energy
      integer, intent(out), optional :: n_read

      integer :: n

      real(dp) :: local_energy

      call this%file_%open_('rewind')

      call this%file_%read_(n)
      if (n /= this%n_amplitudes) &
         call output%warning_msg('Mismatch in number of amplitudes read in amplitude_storer!')
      if (present(n_read)) n_read = n

      call this%file_%read_(local_energy)
      call this%file_%read_(vector, this%n_amplitudes)

      call this%file_%close_()
      if (present(energy)) energy = local_energy

   end subroutine read_amplitude_file_storer


   subroutine read_energy_amplitude_file_storer(this, energy)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      class(amplitude_file_storer), intent(inout) :: this

      real(dp), intent(out) :: energy

      integer :: n

      call this%file_%open_('rewind')

      call this%file_%read_(n)
      if (n /= this%n_amplitudes) &
         call output%warning_msg('Mismatch in number of amplitudes read in amplitude_storer!')

      call this%file_%read_(energy)

      call this%file_%close_()

   end subroutine read_energy_amplitude_file_storer


   function get_filename_amplitude_file_storer(this) result(filename)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      class(amplitude_file_storer), intent(in) :: this

      character(len=:), allocatable :: filename

      filename = this%file_%get_name()

   end function get_filename_amplitude_file_storer


   function file_exists_amplitude_file_storer(this) result(exists)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      class(amplitude_file_storer), intent(in) :: this

      logical :: exists

      exists = this%file_%exists()

   end function file_exists_amplitude_file_storer


   subroutine delete_file_amplitude_file_storer(this)
      !!
      !! Written by Alexander C. Paul, Mar 2022
      !!
      implicit none

      class(amplitude_file_storer), intent(inout) :: this

      call this%file_%delete_()

   end subroutine delete_file_amplitude_file_storer

end module amplitude_file_storer_class

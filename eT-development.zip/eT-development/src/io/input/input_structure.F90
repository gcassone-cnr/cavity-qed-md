
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module input_structure

   !!
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Sara Angelico, Alexander C. Paul and Leo Stoll, 2019-2026
   !!
   !! Input structure module
   !!
   !! Defines sections/keywords and their value types
   !!

   use input_specification_class, only: input_specification, keyword_descriptor, keyword_descriptor_type
   use keyword_value_types_module, only: KV_BOOL, KV_INT_NONNEGATIVE, KV_INT_POSITIVE, KV_REAL_NONNEGATIVE, &
      KV_REAL_POSITIVE, KV_REAL

   implicit none

   private

   public :: get_input_structure

contains


   subroutine get_input_structure(rf_wfs, cc_wfs, ci_wfs, input_spec)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018-2019
      !!
      !! Defines input sections and associated valid keywords and/or default values.
      !! These are added to the input specification object.
      !!
      implicit none

      character(len=30), dimension(:), allocatable, intent(out) :: rf_wfs
      character(len=30), dimension(:), allocatable, intent(out) :: cc_wfs
      character(len=30), dimension(:), allocatable, intent(out) :: ci_wfs
      type(input_specification), intent(inout) :: input_spec

      ! Allocate wavefunction arrays
      allocate(rf_wfs, &
               source=[character(len=30) :: 'dft', &
                  'hf', &
                  'uhf', &
                  'mlhf', &
                  'qed-hf', &
                  'sc-qed-hf', &
                  'cuhf', &
                  'rohf'])

      allocate(cc_wfs, &
               source=[character(len=30) :: 'ccs', &
                  'mp2', &
                  'cc2', &
                  'lowmem-cc2', &
                  'ccsd', &
                  'cc3', &
                  'ccsd(t)', &
                  'ccsdt', &
                  'mlcc2', &
                  'mlccsd', &
                  'qed-ccsd'])

      allocate(ci_wfs, &
               source=[character(len=30) :: 'casci', 'fci', 'qed-casci', 'qed-fci'])

      call register_method_section(input_spec, rf_wfs, cc_wfs, ci_wfs)
      ! Register sections in alphabetical order

      call input_spec%add_section(section_name='active atoms', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('selection type'), &
                                     keyword_descriptor('central atom', KV_INT_POSITIVE), &
                                     keyword_descriptor('hf'), &
                                     keyword_descriptor('ccs'), &
                                     keyword_descriptor('cc2'), &
                                     keyword_descriptor('ccsd'), &
                                     keyword_descriptor('cc3'), &
                                     keyword_descriptor('ccsd(t)'), &
                                     keyword_descriptor('inactive basis'), &
                                     keyword_descriptor('hf basis'), &
                                     keyword_descriptor('ccs basis'), &
                                     keyword_descriptor('cc2 basis'), &
                                     keyword_descriptor('ccsd basis'), &
                                     keyword_descriptor('cc3 basis'), &
                                     keyword_descriptor('ccsd(t) basis')])


      call input_spec%add_section(section_name='active space', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('canonical'), &
                                     keyword_descriptor('freeze core'), &
                                     keyword_descriptor('freeze atom cores'), &
                                     keyword_descriptor('localized', KV_BOOL)])


      call input_spec%add_section(section_name='boson', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('boson number'), &
                                     keyword_descriptor('boson states'), &
                                     keyword_descriptor('cbo'), &
                                     keyword_descriptor('coherent state'), &
                                     keyword_descriptor('coupling bilinear', KV_REAL), &
                                     keyword_descriptor('coupling self', KV_REAL), &
                                     keyword_descriptor('coupling', KV_REAL), &
                                     keyword_descriptor('frequency', KV_REAL), &
                                     keyword_descriptor('interaction type'), &
                                     keyword_descriptor('modes', KV_INT_POSITIVE), &
                                     keyword_descriptor('polarization', KV_REAL), &
                                     keyword_descriptor('print dipole eri construction'), &
                                     keyword_descriptor('quadrupole oei'), &
                                     keyword_descriptor('wavevector', KV_REAL)])


      call input_spec%add_section(section_name='do', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('cholesky eri', KV_BOOL), &
                                     keyword_descriptor('ground state', KV_BOOL), &
                                     keyword_descriptor('geometry optimization', KV_BOOL), &
                                     keyword_descriptor('harmonic frequencies', KV_BOOL), &
                                     keyword_descriptor('excited state', KV_BOOL), &
                                     keyword_descriptor('response', KV_BOOL), &
                                     keyword_descriptor('mean value', KV_BOOL), &
                                     keyword_descriptor('real time', KV_BOOL), &
                                     keyword_descriptor('restart', KV_BOOL)])


      call input_spec%add_section(section_name='cc mean value', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('dipole', KV_BOOL), &
                                     keyword_descriptor('quadrupole', KV_BOOL), &
                                     keyword_descriptor('occupation numbers', KV_BOOL), &
                                     keyword_descriptor('molecular gradient', KV_BOOL)])


      call input_spec%add_section(section_name='cc response', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('asymmetric', KV_BOOL), &
                                     keyword_descriptor('damping', KV_REAL_POSITIVE), &
                                     keyword_descriptor('derivative coupling'), &
                                     keyword_descriptor('dipole length', KV_BOOL), &
                                     keyword_descriptor('dipole velocity', KV_BOOL), &
                                     keyword_descriptor('dyson orbitals', KV_BOOL), &
                                     keyword_descriptor('eom', KV_BOOL), &
                                     keyword_descriptor('frequencies', KV_REAL), &
                                     keyword_descriptor('initial states'), &
                                     keyword_descriptor('lr', KV_BOOL), &
                                     keyword_descriptor('permanent moments', KV_BOOL), &
                                     keyword_descriptor('polarizabilities'), &
                                     keyword_descriptor('response components'), &
                                     keyword_descriptor('rotatory strength', KV_BOOL), &
                                     keyword_descriptor('variational energy', KV_BOOL), &
                                     keyword_descriptor('transition moments', KV_BOOL), &
                                     keyword_descriptor('molecular gradient', KV_BOOL), &
                                     keyword_descriptor('enforce sum rule', KV_BOOL), &
                                     keyword_descriptor('full-space transition moments', KV_BOOL)])


      call input_spec%add_section(section_name='cc real time', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('propagation', KV_BOOL), &
                                     keyword_descriptor('fft dipole moment', KV_BOOL), &
                                     keyword_descriptor('fft electric field', KV_BOOL)])


      call input_spec%add_section(section_name='ci mean value', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('dipole', KV_BOOL), &
                                     keyword_descriptor('quadrupole', KV_BOOL)])


      call input_spec%add_section(section_name='ci transition property', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('dipole', KV_BOOL), &
                                     keyword_descriptor('quadrupole', KV_BOOL), &
                                     keyword_descriptor('final states'), &
                                     keyword_descriptor('initial states')])


      call input_spec%add_section(section_name='dft functional', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('correlation'), &
                                     keyword_descriptor('exchange'), &
                                     keyword_descriptor('functional'), &
                                     keyword_descriptor('hf percentage', KV_REAL)])


      call input_spec%add_section(section_name='electric field', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('envelope'), &
                                     keyword_descriptor('x polarization', KV_REAL), &
                                     keyword_descriptor('y polarization', KV_REAL), &
                                     keyword_descriptor('z polarization', KV_REAL), &
                                     keyword_descriptor('central time', KV_REAL), &
                                     keyword_descriptor('width', KV_REAL_POSITIVE), &
                                     keyword_descriptor('carrier angular frequency', KV_REAL), &
                                     keyword_descriptor('peak strength', KV_REAL_POSITIVE), &
                                     keyword_descriptor('phase shift', KV_REAL), &
                                     keyword_descriptor('repetition', KV_REAL), &
                                     keyword_descriptor('separation', KV_REAL)])


      call input_spec%add_section(section_name='harmonic frequencies', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('gradient displacement', KV_REAL_POSITIVE), &
                                     keyword_descriptor('gradient method'), &
                                     keyword_descriptor('hessian displacement', KV_REAL_POSITIVE), &
                                     keyword_descriptor('run geometry optimization', KV_BOOL), &
                                     keyword_descriptor('state', KV_INT_NONNEGATIVE), &
                                     keyword_descriptor('wigner samples', KV_INT_POSITIVE), &
                                     keyword_descriptor('wigner seed', KV_INT_NONNEGATIVE)])


      call input_spec%add_section(section_name='grid info', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('cube side', KV_REAL), &
                                     keyword_descriptor('cube offset', KV_REAL), &
                                     keyword_descriptor('minimum angular order', KV_INT_NONNEGATIVE), &
                                     keyword_descriptor('maximum angular order', KV_INT_POSITIVE), &
                                     keyword_descriptor('partitioning'), &
                                     keyword_descriptor('radial threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('quadrature')])


      call input_spec%add_section(section_name='hf mean value', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('dipole', KV_BOOL), &
                                     keyword_descriptor('molecular gradient', KV_BOOL), &
                                     keyword_descriptor('quadrupole', KV_BOOL)])

      call input_spec%add_section(section_name='hf response', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('shielding', KV_BOOL), &
                                     keyword_descriptor('dipole velocity', KV_BOOL), &
                                     keyword_descriptor('rotatory strength', KV_BOOL), &
                                     keyword_descriptor('polarizabilities', KV_BOOL)])


      call input_spec%add_section(section_name='integrals', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('cholesky storage'), &
                                     keyword_descriptor('eri storage'), &
                                     keyword_descriptor('mo eri in memory', KV_BOOL), &
                                     keyword_descriptor('ri'), &
                                     keyword_descriptor('t1 eri in memory', KV_BOOL)])


      call input_spec%add_section(section_name='lanczos', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('biorthogonalize last', KV_INT_POSITIVE), &
                                     keyword_descriptor('chain length', KV_INT_POSITIVE), &
                                     keyword_descriptor('deflation threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('lanczos normalization'), &
                                     keyword_descriptor('max energy', KV_REAL_POSITIVE), &
                                     keyword_descriptor('min energy', KV_REAL_POSITIVE), &
                                     keyword_descriptor('min transition strength', KV_REAL_POSITIVE), &
                                     keyword_descriptor('operators'), &
                                     keyword_descriptor('overlap threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('restart states'), &
                                     keyword_descriptor('skip convergence', KV_BOOL)])


      call input_spec%add_section(section_name='memory', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('available'), keyword_descriptor('unit')])

      call input_spec%add_section(section_name='mlcc', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('cc2 orbitals'), &
                                     keyword_descriptor('canonical virtual cc2', KV_INT_POSITIVE), &
                                     keyword_descriptor('canonical virtual ccsd', KV_INT_POSITIVE), &
                                     keyword_descriptor('ccsd orbitals'), &
                                     keyword_descriptor('cholesky threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('cnto restart', KV_BOOL), &
                                     keyword_descriptor('cnto occupied cc2', KV_INT_POSITIVE), &
                                     keyword_descriptor('cnto virtual cc2', KV_INT_POSITIVE), &
                                     keyword_descriptor('cnto occupied ccsd', KV_INT_POSITIVE), &
                                     keyword_descriptor('cnto virtual ccsd', KV_INT_POSITIVE), &
                                     keyword_descriptor('cnto states'), &
                                     keyword_descriptor('levels'), &
                                     keyword_descriptor('nto restart', KV_BOOL), &
                                     keyword_descriptor('nto states'), &
                                     keyword_descriptor('nto occupied cc2', KV_INT_POSITIVE), &
                                     keyword_descriptor('nto occupied ccsd', KV_INT_POSITIVE), &
                                     keyword_descriptor('orbital restart', KV_BOOL), &
                                     keyword_descriptor('orbitals'), &
                                     keyword_descriptor('print ccs calculation', KV_BOOL), &
                                     keyword_descriptor('print cc2 calculation', KV_BOOL)] &
           )  ! Deprecated -> removed in v3.0  ! Deprecated -> removed in v3.0


      call input_spec%add_section(section_name='multilevel hf', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('initial hf optimization', KV_BOOL), &
                                     keyword_descriptor('initial hf threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('print initial hf', KV_BOOL), &
                                     keyword_descriptor('cholesky threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('project on minimal basis', KV_BOOL), &
                                     keyword_descriptor('cholesky virtuals', KV_BOOL), &
                                     keyword_descriptor('no mo screening', KV_BOOL)])


      call input_spec%add_section(section_name='molecular mechanics', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('forcefield'), &
                                     keyword_descriptor('algorithm ')])


      call input_spec%add_section(section_name='orbital localization', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('orbitals'), &
                                     keyword_descriptor('threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('type')])


      call input_spec%add_section(section_name='pcm', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('solvent'), &
                                     keyword_descriptor('input'), &
                                     keyword_descriptor('tesserae area', KV_REAL_POSITIVE), &
                                     keyword_descriptor('solver type')])


      call input_spec%add_section(section_name='print', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('output print level '), &
                                     keyword_descriptor('timing print level '), &
                                     keyword_descriptor('full references', KV_BOOL), &
                                     keyword_descriptor('z-matrix', KV_BOOL)])


      call input_spec%add_section(section_name='solver cpp', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('max iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('max reduced dimension', KV_INT_POSITIVE), &
                                     keyword_descriptor('residual minimization', KV_BOOL), &
                                     keyword_descriptor('residual threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('restart', KV_BOOL), &
                                     keyword_descriptor('storage')])

      call input_spec%add_section(section_name='solver cc es', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('algorithm' &
                                     ), keyword_descriptor('olsen', KV_BOOL), &
                                     keyword_descriptor('core index'), &
                                     keyword_descriptor('core excitation'), &
                                     keyword_descriptor('electron attachment', KV_BOOL), &
                                     keyword_descriptor('ionization', KV_BOOL), &
                                     keyword_descriptor('energy threshold ', KV_REAL_POSITIVE, &
                                     default='1.0d-3'), keyword_descriptor('crop', KV_BOOL), &
                                     keyword_descriptor('residual threshold', KV_REAL_POSITIVE, &
                                     default='1.0d-3'), &
                                     keyword_descriptor('max iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('remove core'), &
                                     keyword_descriptor('restart', KV_BOOL), &
                                     keyword_descriptor('left eigenvectors', KV_BOOL), &
                                     keyword_descriptor('right eigenvectors', KV_BOOL), &
                                     keyword_descriptor('storage'), keyword_descriptor('singlet states'), &
                                     keyword_descriptor('triplet states'), &
                                     keyword_descriptor('diis dimension', KV_INT_POSITIVE), &
                                     keyword_descriptor('max reduced dimension', KV_INT_POSITIVE), &
                                     keyword_descriptor('max micro iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('rel micro threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('state guesses'), keyword_descriptor('type')] &
           )  ! Deprecated -> removed in v3.0  ! Deprecated -> removed in v3.0


      call input_spec%add_section(section_name='solver cc gs', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('algorithm'), &
                                     keyword_descriptor('energy threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('residual threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('crop', KV_BOOL), &
                                     keyword_descriptor('micro iteration storage'), &
                                     keyword_descriptor('max micro iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('multimodel newton'), &
                                     keyword_descriptor('rel micro threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('storage'), &
                                     keyword_descriptor('max iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('diis dimension', KV_INT_POSITIVE), &
                                     keyword_descriptor('restart', KV_BOOL)])


      call input_spec%add_section(section_name='solver cc multipliers', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('algorithm'), &
                                     keyword_descriptor('threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('storage'), &
                                     keyword_descriptor('crop', KV_BOOL), &
                                     keyword_descriptor('micro iteration storage'), &
                                     keyword_descriptor('max micro iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('multimodel newton'), &
                                     keyword_descriptor('rel micro threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('diis dimension', KV_INT_POSITIVE), &
                                     keyword_descriptor('restart', KV_BOOL), &
                                     keyword_descriptor('max reduced dimension', KV_INT_POSITIVE), &
                                     keyword_descriptor('max iterations', KV_INT_POSITIVE)])


      call input_spec%add_section(section_name='solver cc propagation', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('initial time', KV_REAL_NONNEGATIVE), &
                                     keyword_descriptor('restart time', KV_REAL), &
                                     keyword_descriptor('final time', KV_REAL_NONNEGATIVE), &
                                     keyword_descriptor('time step', KV_REAL), &
                                     keyword_descriptor('steps between output', KV_INT_POSITIVE), &
                                     keyword_descriptor('step reduction factor', KV_REAL), &
                                     keyword_descriptor('implicit threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('max error', KV_REAL_POSITIVE), &
                                     keyword_descriptor('min error', KV_REAL_POSITIVE), &
                                     keyword_descriptor('energy output', KV_BOOL), &
                                     keyword_descriptor('dipole moment output', KV_BOOL), &
                                     keyword_descriptor('electric field output', KV_BOOL), &
                                     keyword_descriptor('parameters output', KV_BOOL), &
                                     keyword_descriptor('mo density matrix output', KV_BOOL), &
                                     keyword_descriptor('method'), &
                                     keyword_descriptor('restart', KV_BOOL), &
                                     keyword_descriptor('integrator')])


      call input_spec%add_section(section_name='solver cc response', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('gradient response threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('storage'), &
                                     keyword_descriptor('max iterations', KV_INT_POSITIVE)])


      call input_spec%add_section(section_name='solver cholesky', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('span'), &
                                     keyword_descriptor('batches', KV_INT_POSITIVE), &
                                     keyword_descriptor('qualified'), &
                                     keyword_descriptor('one center', KV_BOOL), &
                                     keyword_descriptor('diagonal test', KV_BOOL), &
                                     keyword_descriptor('mo screening', KV_BOOL)])


      call input_spec%add_section(section_name='solver ci', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('energy threshold ', KV_REAL_POSITIVE), &
                                     keyword_descriptor('max iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('max reduced dimension', KV_INT_POSITIVE), &
                                     keyword_descriptor('residual threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('restart', KV_BOOL), &
                                     keyword_descriptor('start guess'), &
                                     keyword_descriptor('states', KV_INT_POSITIVE), &
                                     keyword_descriptor('storage')])

      call input_spec%add_section(section_name='solver fft dipole moment', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('initial time', KV_REAL_NONNEGATIVE), &
                                     keyword_descriptor('final time', KV_REAL_NONNEGATIVE), &
                                     keyword_descriptor('time step', KV_REAL), &
                                     keyword_descriptor('padding initial time', KV_REAL), &
                                     keyword_descriptor('hann window', KV_BOOL), &
                                     keyword_descriptor('rectangular window', KV_BOOL)])


      call input_spec%add_section(section_name='solver fft electric field', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('initial time', KV_REAL_NONNEGATIVE), &
                                     keyword_descriptor('final time', KV_REAL_NONNEGATIVE), &
                                     keyword_descriptor('time step', KV_REAL), &
                                     keyword_descriptor('padding initial time', KV_REAL), &
                                     keyword_descriptor('hann window', KV_BOOL), &
                                     keyword_descriptor('rectangular window', KV_BOOL)])


      call input_spec%add_section(section_name='solver geometry optimization', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('algorithm'), &
                                     keyword_descriptor('energy threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('residual threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('residual rms threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('state', KV_INT_NONNEGATIVE), &
                                     keyword_descriptor('max iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('max step', KV_REAL_POSITIVE), &
                                     keyword_descriptor('gradient method'), &
                                     keyword_descriptor('restart', KV_BOOL), &
                                     keyword_descriptor('step size', KV_REAL_POSITIVE), &
                                     keyword_descriptor('displacement threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('displacement rms threshold', KV_REAL_POSITIVE)])


      call input_spec%add_section(section_name='solver scf', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('algorithm'), &
                                     keyword_descriptor('ao density guess'), &
                                     keyword_descriptor('coulomb exchange terms'), &
                                     keyword_descriptor('coulomb threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('crop', KV_BOOL), &
                                     keyword_descriptor('cumulative fock threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('diis dimension', KV_INT_POSITIVE), &
                                     keyword_descriptor('diabatize orbitals', KV_BOOL), &
                                     keyword_descriptor('energy threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('exchange threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('residual threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('gradient response threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('max iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('population analysis'), &
                                     keyword_descriptor('write orbitals', KV_BOOL), &
                                     keyword_descriptor('restart', KV_BOOL), &
                                     keyword_descriptor('rohf coupling parameters'), &
                                     keyword_descriptor('skip', KV_BOOL), &
                                     keyword_descriptor('storage'), &
                                     keyword_descriptor('write molden', KV_BOOL)])


      call input_spec%add_section(section_name='solver scf es', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('energy threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('max iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('max reduced dimension', KV_INT_POSITIVE), &
                                     keyword_descriptor('residual threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('restart', KV_BOOL), &
                                     keyword_descriptor('storage'), &
                                     keyword_descriptor('singlet states', KV_INT_POSITIVE), &
                                     keyword_descriptor('tamm-dancoff', KV_BOOL)])


      call input_spec%add_section(section_name='solver hf es', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('energy threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('max iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('max reduced dimension', KV_INT_POSITIVE), &
                                     keyword_descriptor('residual threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('restart', KV_BOOL), &
                                     keyword_descriptor('storage'), &
                                     keyword_descriptor('singlet states', KV_INT_POSITIVE), &
                                     keyword_descriptor('tamm-dancoff', KV_BOOL)])


      call input_spec%add_section(section_name='solver hf response', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('frequencies', KV_REAL), &
                                     keyword_descriptor('max iterations', KV_INT_POSITIVE), &
                                     keyword_descriptor('max reduced dimension', KV_INT_POSITIVE), &
                                     keyword_descriptor('print iterations', KV_INT_NONNEGATIVE), &
                                     keyword_descriptor('residual threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('restart', KV_BOOL), &
                                     keyword_descriptor('storage')])


      call input_spec%add_section(section_name='system', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('cartesian gaussians', KV_BOOL), &
                                     keyword_descriptor('write orbitals', KV_BOOL), &
                                     keyword_descriptor('pure gaussians', KV_BOOL), &
                                     keyword_descriptor('charge'), &
                                     keyword_descriptor('multiplicity', KV_INT_POSITIVE)])


      call input_spec%add_section(section_name='visualization', &
                                  required=.false., &
                                  keywords=[keyword_descriptor('file format'), &
                                     keyword_descriptor('grid spacing', KV_REAL_POSITIVE), &
                                     keyword_descriptor('grid buffer', KV_REAL_NONNEGATIVE), &
                                     keyword_descriptor('grid min', KV_REAL), &
                                     keyword_descriptor('grid max', KV_REAL), &
                                     keyword_descriptor('plot cc density', KV_BOOL), &
                                     keyword_descriptor('plot cc orbitals'), &
                                     keyword_descriptor('plot dyson orbitals', KV_BOOL), &
                                     keyword_descriptor('plot es densities'), &
                                     keyword_descriptor('plot hf orbitals'), &
                                     keyword_descriptor('plot hf density'), &
                                     keyword_descriptor('plot hf active density'), &
                                     keyword_descriptor('plot cntos'), &
                                     keyword_descriptor('plot ntos'), &
                                     keyword_descriptor('nto threshold', KV_REAL_POSITIVE), &
                                     keyword_descriptor('plot transition densities'), &
                                     keyword_descriptor('states to plot')])

   end subroutine get_input_structure


   subroutine register_method_section(input_spec, rf_wfs, cc_wfs, ci_wfs)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2019
      !!
      !! Register the method section with keywords derived from rf_wfs, cc_wfs, ci_wfs.
      !!
      implicit none

      type(input_specification), intent(inout) :: input_spec
      character(len=30), dimension(:), intent(in) :: rf_wfs
      character(len=30), dimension(:), intent(in) :: cc_wfs
      character(len=30), dimension(:), intent(in) :: ci_wfs

      type(keyword_descriptor_type), allocatable :: method_keywords(:)
      integer :: i, idx, n

      n = size(rf_wfs) + size(cc_wfs) + size(ci_wfs)
      allocate(method_keywords(n))

      idx = 0
      do i = 1, size(rf_wfs)
         idx = idx + 1
         method_keywords(idx) = keyword_descriptor(rf_wfs(i), KV_BOOL)
      end do

      do i = 1, size(cc_wfs)
         idx = idx + 1
         method_keywords(idx) = keyword_descriptor(cc_wfs(i), KV_BOOL)
      end do

      do i = 1, size(ci_wfs)
         idx = idx + 1
         method_keywords(idx) = keyword_descriptor(ci_wfs(i), KV_BOOL)
      end do

      call input_spec%add_section(section_name='method', required=.false., keywords=method_keywords)

   end subroutine register_method_section


end module input_structure



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module input_tool_class

   !!
   !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
   !!
   !! Input tool class module
   !!

   use kinds
   use input_structure, only: get_input_structure
   use et_config_class, only: et_config, et_config_entry
   use input_specification_class, only: input_specification
   use global_out, only: output

   use string_utilities, only: string_starts_with, first_index_of_substring
   use string_utilities, only: is_empty, remove_substring_after_symbol
   use string_utilities, only: convert_to_lowercase
   use deprecated_keys_handler_class, only: deprecated_keys_handler
   use geometry_parser_class, only: geometry_parser
   use input_set_range_parser, only: get_n_sets_and_ranges, get_n_elements_in_set_or_range, &
      get_integers_from_set_or_range, expect_set, check_get_array_for_keyword


   type :: input_tool

      type(geometry_parser), private :: geometry_parser_
      type(deprecated_keys_handler), allocatable, private :: deprecated_keywords

      character(len=30), dimension(:), allocatable, private :: rf_wfs
      character(len=30), dimension(:), allocatable, private :: cc_wfs
      character(len=30), dimension(:), allocatable, private :: ci_wfs

      type(input_specification), pointer, private :: input_spec => null()
      type(et_config), pointer, private :: config_ => null()

      character(len=200), dimension(:), allocatable, private :: keyword_lines_

   contains

      procedure, public :: read_input
      procedure, public :: get_config
      procedure, public :: to_config
      procedure, public :: process_input

      procedure, private :: print_input_except_geometry

      procedure, public :: get_n_atoms => get_n_atoms_input_tool

      procedure, public :: get_n_mm_atoms => get_n_mm_atoms_input_tool

      procedure, public :: get_n_mm_molecules => get_n_mm_molecules_input_tool

      procedure, public :: get_geometry => get_geometry_input_tool

      procedure, public :: get_mm_geometry_fq => get_mm_geometry_fq_input_tool

      procedure, public :: get_mm_geometry_non_polarizable => get_mm_geometry_non_polarizable_input_tool

      procedure, public :: get_reference_wavefunction
      procedure, public :: get_cc_wavefunction
      procedure, public :: get_ci_wavefunction

      procedure, public :: requested_reference_calculation
      procedure, public :: requested_cc_calculation
      procedure, public :: requested_ci_calculation
      procedure, public :: requested_active_space_calculation

      generic, public :: get_keyword => get_32bit_integer_keyword, get_64bit_integer_keyword, &
         get_string_keyword, get_real_dp_keyword

      generic, public :: get_required_keyword => get_required_string_keyword, &
         get_required_32bit_integer_keyword, get_required_64bit_integer_keyword, &
         get_required_real_dp_keyword

      procedure, public :: get_n_elements_for_keyword

      generic, public :: get_array_for_keyword => get_integer_array_for_keyword, get_real_array_for_keyword, &
         get_string_array_for_keyword

      procedure, public :: string_in_array_keyword => string_in_array_keyword

      procedure, public :: cleanup => cleanup_input_tool

      procedure, public :: is_section_present => is_section_present_input_tool

      procedure, public :: is_keyword_present => is_keyword_present_input_tool

      procedure, public :: is_embedding_on => is_embedding_on_input_tool

      procedure, public :: place_records_in_memory => place_records_in_memory_input_tool

      procedure, public :: get_n_state_guesses
      procedure, public :: get_state_guesses

      procedure, public :: get_present_keywords => get_present_keywords_input_tool

      procedure, private :: process_keyword_lines
      procedure, private, nopass :: parse_keyword_line
      procedure, private :: check_for_errors
      procedure, private :: check_for_deprecations

      procedure, private :: get_wavefunction
      procedure, private :: requested_calculation

      procedure, private :: print_sections

      procedure, private :: get_32bit_integer_keyword
      procedure, private :: get_64bit_integer_keyword
      procedure, private :: get_string_keyword
      procedure, private :: get_real_dp_keyword
      procedure, private :: get_required_string_keyword
      procedure, private :: get_required_32bit_integer_keyword
      procedure, private :: get_required_64bit_integer_keyword
      procedure, private :: get_required_real_dp_keyword

      procedure, private :: get_integer_array_for_keyword
      procedure, private :: get_real_array_for_keyword
      procedure, private :: get_string_array_for_keyword

      procedure, private :: is_section_recognized
      procedure, private :: section_not_recognized
      procedure, private :: get_local_qm_geometry
      procedure, private :: get_local_mm_geometry
      procedure, public :: get_es_spin_symmetry
      procedure, public :: get_es_left_or_right
      procedure, public :: get_es_types
      procedure, public :: get_n_es_types

      generic, public :: get_n_es_states => get_n_es_states_many, get_n_es_states_one

      procedure, private :: get_n_es_states_many
      procedure, private :: get_n_es_states_one

      procedure, public :: get_mlcc_levels
      procedure, public :: get_orbital_keyword_mlcc

   end type input_tool

   interface input_tool

      procedure :: new_input_tool

   end interface input_tool


contains


   function new_input_tool() result(this)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, June 2018
      !!
      implicit none

      type(input_tool) :: this

      this%deprecated_keywords = deprecated_keys_handler()
      this%geometry_parser_ = geometry_parser()
      allocate(this%input_spec, source = input_specification())
      call get_input_structure(this%rf_wfs, this%cc_wfs, this%ci_wfs, this%input_spec)

   end function new_input_tool


   subroutine read_input(this, file_name)
      !!
      !! Written by Eirik F. Kjoenstad, May 2022
      !!
      use input_file_parser_class, only: input_file_parser

      implicit none

      class(input_tool), intent(inout) :: this

      character(len=*), intent(in) :: file_name

      type(input_file_parser), allocatable :: file_parser

      character(len=200), dimension(:), allocatable :: keyword_lines
      character(len=200), dimension(:), allocatable :: qm_geometry
      character(len=200), dimension(:), allocatable :: mm_geometry

      integer :: n_keyword_lines
      integer :: n_qm_atom_lines
      integer :: n_mm_atom_lines

      type(input_specification), pointer :: schema_ptr

      file_parser = input_file_parser(file_name)
      call file_parser%read_and_process_input_file()
      call file_parser%get_keyword_lines(keyword_lines, n_keyword_lines)
      call file_parser%get_qm_geometry_lines(qm_geometry, n_qm_atom_lines)

      if (size(keyword_lines) /= n_keyword_lines) error stop 'keyword line count mismatch'
      if (size(qm_geometry) /= n_qm_atom_lines) error stop 'qm geometry line count mismatch'

      if (file_parser%is_mm_geometry_present()) then

         call file_parser%get_mm_geometry_lines(mm_geometry, n_mm_atom_lines)
         if (size(mm_geometry) /= n_mm_atom_lines) error stop 'mm geometry line count mismatch'

      end if


      if (.not. associated(this%config_)) allocate(this%config_)
      schema_ptr => this%input_spec
      this%config_ = et_config(schema_ptr)

      if (allocated(this%keyword_lines_)) deallocate(this%keyword_lines_)
      allocate(this%keyword_lines_, source = keyword_lines)

      call this%config_%set_qm_geometry(qm_geometry)
      if (file_parser%is_mm_geometry_present()) call this%config_%set_mm_geometry(mm_geometry)

      deallocate(file_parser)

   end subroutine read_input


   subroutine process_input(this)
      !!
      !! Written by Eirik F. Kjoenstad, Mar 2024
      !!
      implicit none

      class(input_tool), intent(inout) :: this

      call this%process_keyword_lines()
      call this%print_input_except_geometry()
      call this%check_for_errors()
      call this%check_for_deprecations()

   end subroutine process_input


   subroutine print_input_except_geometry(this)
      !!
      !! Written by Eirik F. Kjoenstad, May 2022
      !!
      implicit none

      class(input_tool), intent(inout) :: this

      integer :: n

      call output%printf('m', ':: Input file', fs='(//t3,a)')
      call output%print_separator('m', 13, '=', fs='(t3,a/)')

      call output%printf('m', 'Note: geometry section is excluded from this print.', fs='(t6,a/)')

      if (.not. associated(this%config_)) return
      if (.not. allocated(this%keyword_lines_)) return

      do n = 1, size(this%keyword_lines_)

         call output%printf('m', this%keyword_lines_(n), fs='(t6,a)', ll=120)

      end do


      if (allocated(this%keyword_lines_)) deallocate(this%keyword_lines_)

   end subroutine print_input_except_geometry


   function get_config(this) result(config_ptr)
      !!
      !! Written by Eirik F. Kjoenstad, Mar 2024
      !!
      !! Get mutable handle to input configuration
      !!
      implicit none

      class(input_tool), intent(inout), target :: this
      class(et_config), pointer :: config_ptr

      type(input_specification), pointer :: schema_ptr

      if (.not. associated(this%config_)) then

         schema_ptr => this%input_spec
         allocate(this%config_)
         this%config_ = et_config(schema_ptr)

      end if

      config_ptr => this%config_

   end function get_config


   function to_config(this) result(config)
      !!
      !! Written by Eirik F. Kjoenstad, Mar 2024
      !!
      !! Export parsed input section/keyword pairs as et_config
      !!
      implicit none

      class(input_tool), intent(inout) :: this

      type(et_config) :: config

      type(input_specification), pointer :: schema_ptr

      if (associated(this%config_)) then

         config = this%config_

      else

         schema_ptr => this%input_spec
         config = et_config(schema_ptr)

      end if

   end function to_config


   subroutine get_local_qm_geometry(this, qm_geometry_lines, n_qm_lines)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      implicit none

      class(input_tool), intent(in) :: this
      character(len=200), dimension(:), allocatable, intent(out) :: qm_geometry_lines
      integer, intent(out) :: n_qm_lines

      if (associated(this%config_) .and. this%config_%has_qm_geometry()) then

         call this%config_%get_qm_geometry(qm_geometry_lines)

      else

         allocate(qm_geometry_lines(0))

      end if

      n_qm_lines = size(qm_geometry_lines)

   end subroutine get_local_qm_geometry


   subroutine get_local_mm_geometry(this, mm_geometry_lines, n_mm_lines)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      implicit none

      class(input_tool), intent(in) :: this
      character(len=200), dimension(:), allocatable, intent(out) :: mm_geometry_lines
      integer, intent(out) :: n_mm_lines

      if (associated(this%config_) .and. this%config_%has_mm_geometry()) then

         call this%config_%get_mm_geometry(mm_geometry_lines)

      else

         allocate(mm_geometry_lines(0))

      end if

      n_mm_lines = size(mm_geometry_lines)

   end subroutine get_local_mm_geometry


   subroutine process_keyword_lines(this)
      !!
      !! Written by Sara Angelico and Alexander C. Paul, 2023
      !!
      !! Parse keyword_lines_ and insert section/keyword/value pairs into config.
      !!
      implicit none

      class(input_tool), intent(inout) :: this

      integer :: start_, end_, i, j, l
      character(len=200) :: section, line, section_line, keyword_line
      character(len=200) :: keyword, keyword_value

      if (.not. associated(this%config_)) return
      if (.not. allocated(this%keyword_lines_)) return

      do i = 1, size(this%keyword_lines_)

         line = trim(adjustl(this%keyword_lines_(i)))

         if (.not. string_starts_with(line, '-')) cycle

         start_ = i + 1
         section = trim(adjustl(line(2:)))
         section = remove_substring_after_symbol(section, "!")

         if (.not. this%is_section_recognized(section)) call this%section_not_recognized(section)

         end_ = size(this%keyword_lines_)

         do j = start_, size(this%keyword_lines_)

            section_line = trim(adjustl(this%keyword_lines_(j)))

            if (.not. string_starts_with(section_line, '-')) cycle

            end_ = j - 1
            exit

         end do

         do l = start_, end_

            keyword_line = trim(adjustl(this%keyword_lines_(l)))

            if (string_starts_with(keyword_line, "!")) cycle
            if (is_empty(keyword_line)) cycle

            keyword_line = remove_substring_after_symbol(keyword_line, '!')
            keyword_line = adjustl(keyword_line)

            call this%parse_keyword_line(keyword_line, keyword, keyword_value)
            call this%config_%set_string_from_file(trim(section), trim(keyword), trim(keyword_value))

         end do

      end do

   end subroutine process_keyword_lines


   subroutine parse_keyword_line(line, keyword, keyword_value)
      !!
      !! Written by Sara Angelico and Alexander C. Paul, 2023
      !!
      !! Extract keyword and value from "keyword: value" format.
      !!
      implicit none

      character(len=*), intent(in) :: line
      character(len=200), intent(out) :: keyword
      character(len=200), intent(out) :: keyword_value

      integer :: colon_position

      keyword = adjustl(line)
      colon_position = index(keyword, ':')

      if (colon_position > 0) then

         keyword(colon_position:) = ""
         keyword_value = adjustl(line(colon_position + 1:))
         call convert_to_lowercase(keyword_value)

      else

         keyword_value = ""

      end if

   end subroutine parse_keyword_line


   subroutine print_sections(this)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=200), dimension(:), allocatable :: section_names
      integer :: k

      call output%printf('m', 'The valid input sections are:', fs='(/t3,a/)')

      if (associated(this%input_spec)) then
         call this%input_spec%get_added_sections(section_names)
         do k = 1, size(section_names)
            call output%printf('m', '(a0)', chars=[trim(section_names(k))], fs='(t6,a)')
         end do
      end if

   end subroutine print_sections


   function requested_reference_calculation(this) result(requested)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Apr 2019
      !!
      implicit none

      class(input_tool), intent(in) :: this

      logical :: requested

      requested = this%requested_calculation(this%rf_wfs)

   end function requested_reference_calculation


   function requested_calculation(this, wfs) result(requested)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Apr 2019
      !!
      !! Looks for wfs(k) in method and returns true if it finds one such wf
      !! in the input file. Gives an error if it finds more than one of wfs(k).
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=30), dimension(:), intent(in) :: wfs

      logical :: requested

      integer :: n_wfs, k

      n_wfs = 0

      do k = 1, size(wfs)

         if (this%is_keyword_present(trim(wfs(k)), 'method')) then

            n_wfs = n_wfs + 1

         end if

      end do

      requested = .false.

      if (n_wfs == 1) then

         requested = .true.

      elseif (n_wfs > 1) then

         call output%error_msg( &
                 'Requested more than one method of a single kind (e.g., two CC methods).' &
              )

      end if


   end function requested_calculation


   function requested_cc_calculation(this) result(requested)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Apr 2019
      !!
      implicit none

      class(input_tool), intent(in) :: this

      logical :: requested

      requested = this%requested_calculation(this%cc_wfs)

   end function requested_cc_calculation


   function requested_ci_calculation(this) result(requested)
      !!
      !! Written by Enrico Ronca, 2020
      !!
      implicit none

      class(input_tool), intent(in) :: this

      logical :: requested

      requested = this%requested_calculation(this%ci_wfs)

   end function requested_ci_calculation


   function requested_active_space_calculation(this) result(requested)
      !!
      !! Written by Sarai D. Folkestad, 2025
      !!
      implicit none

      class(input_tool), intent(in) :: this

      logical :: requested

      character(len=30), dimension(:), allocatable :: mlhf
      allocate(mlhf, source = [character(len=30) :: 'mlhf'])

      requested = this%is_keyword_present('freeze core', 'active space') .or. &
                  this%is_keyword_present('freeze atom cores', 'active space') .or. &
                  this%is_keyword_present('localized', 'active space') .or. &
                  this%is_keyword_present('canonical', 'active space') .or. &
                  this%is_keyword_present('plot hf active density', 'visualization') .or. &
                  this%is_embedding_on() .or. &
                  (this%requested_calculation(mlhf) .and. this%requested_cc_calculation())

   end function requested_active_space_calculation


   function get_reference_wavefunction(this) result(ref_wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Apr 2019
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=30) :: ref_wf

      ref_wf = this%get_wavefunction(this%rf_wfs)

   end function get_reference_wavefunction


   function get_cc_wavefunction(this) result(cc_wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Apr 2019
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=30) :: cc_wf

      cc_wf = this%get_wavefunction(this%cc_wfs)

   end function get_cc_wavefunction


   function get_ci_wavefunction(this) result(ci_wf)
      !!
      !! Written by Enrico Ronca, Apr 2020
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=30) :: ci_wf

      ci_wf = this%get_wavefunction(this%ci_wfs)

   end function get_ci_wavefunction


   function get_wavefunction(this, wfs) result(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Apr 2019
      !!
      !! Looks for wfs(k) in the 'method' section of the input.
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=30), dimension(:), intent(in) :: wfs

      character(len=30) :: wf

      integer :: k

      do k = 1, size(wfs)

         if (this%is_keyword_present(trim(wfs(k)), 'method')) then

            wf = wfs(k)
            return

         end if

      end do

      call output%error_msg( &
              'Failed to read wavefunction from input.  Did you forget to specify all wavefunctions for the&
              & calculation?' &
           )

   end function get_wavefunction


   subroutine get_32bit_integer_keyword(this, keyword, section, keyword_value)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! If specified, reads keyword as an integer into keyword value.
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section

      integer(i32), intent(inout) :: keyword_value

      character(len=200) :: keyword_value_string

      keyword_value_string = ""
      call this%get_string_keyword(keyword, section, keyword_value_string)

      if (is_empty(keyword_value_string)) return

      read(keyword_value_string, *) keyword_value

   end subroutine get_32bit_integer_keyword


   subroutine get_64bit_integer_keyword(this, keyword, section, keyword_value)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! If specified, reads keyword as an integer into keyword value.
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section

      integer(i64), intent(inout) :: keyword_value

      character(len=200) :: keyword_value_string

      keyword_value_string = ""
      call this%get_string_keyword(keyword, section, keyword_value_string)

      if (is_empty(keyword_value_string)) return

      read(keyword_value_string, *) keyword_value

   end subroutine get_64bit_integer_keyword


   subroutine get_required_32bit_integer_keyword(this, keyword, section, keyword_value)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Reads keyword as an integer into keyword value. If the keyword or the
      !! section is not specified, an error occurs because the keyword is "required".
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section

      integer(i32), intent(inout) :: keyword_value

      character(len=200) :: keyword_value_string

      keyword_value_string = ""
      call this%get_string_keyword(keyword, section, keyword_value_string)

      if (is_empty(keyword_value_string)) then

         call output%error_msg('could not find the required keyword ' // trim(keyword) // ' in section ' // &
            trim(section))

      end if

      read(keyword_value_string, *) keyword_value

   end subroutine get_required_32bit_integer_keyword


   subroutine get_required_64bit_integer_keyword(this, keyword, section, keyword_value)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Reads keyword as an integer into keyword value. If the keyword or the
      !! section is not specified, an error occurs because the keyword is "required".
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section

      integer(i64), intent(out) :: keyword_value

      character(len=200) :: keyword_value_string

      keyword_value_string = ""
      call this%get_string_keyword(keyword, section, keyword_value_string)

      if (is_empty(keyword_value_string)) then

         call output%error_msg('could not find the required keyword ' // trim(keyword) // ' in section ' // &
            trim(section))

      end if

      read(keyword_value_string, *) keyword_value

   end subroutine get_required_64bit_integer_keyword


   subroutine get_real_dp_keyword(this, keyword, section, keyword_value)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! If specified, reads keyword as a real double precision into keyword value.
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section

      real(dp), intent(inout) :: keyword_value

      character(len=200) :: keyword_value_string

      keyword_value_string = ""
      call this%get_string_keyword(keyword, section, keyword_value_string)

      if (is_empty(keyword_value_string)) return

      read(keyword_value_string, *) keyword_value

   end subroutine get_real_dp_keyword


   subroutine get_required_real_dp_keyword(this, keyword, section, keyword_value)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Reads keyword as an double precision into keyword value. If the keyword or the
      !! section is not specified, an error occurs because the keyword is "required".
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section

      real(dp), intent(out) :: keyword_value

      character(len=200) :: keyword_value_string

      keyword_value_string = ""
      call this%get_string_keyword(keyword, section, keyword_value_string)

      if (is_empty(keyword_value_string)) then

         call output%error_msg('could not find the required keyword ' // trim(keyword) // ' in section ' // &
            trim(section))

      end if

      read(keyword_value_string, *) keyword_value

   end subroutine get_required_real_dp_keyword


   subroutine get_string_keyword(this, keyword, section, keyword_value)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! If specified, reads keyword as a string into keyword value.
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section

      character(len=200), intent(inout) :: keyword_value
      character(len=200) :: keyword_value_string
      logical :: found
      logical :: has_default

      keyword_value_string = ''
      found = .false.
      has_default = .false.

      if (associated(this%config_)) then

         call this%config_%get_string(section, keyword, keyword_value_string, found)

      end if

      if (is_empty(keyword_value_string) .and. associated(this%input_spec)) then
         call this%input_spec%get_keyword_default(section, keyword, keyword_value_string, has_default)
      end if

      ! Make sure not to overwrite defaults set on the outside
      if (is_empty(keyword_value_string)) return

      keyword_value = keyword_value_string

   end subroutine get_string_keyword


   subroutine get_required_string_keyword(this, keyword, section, keyword_value)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! If specified, reads keyword as a string into keyword value.
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section

      character(len=200) :: keyword_value

      keyword_value = ""
      call this%get_string_keyword(keyword, section, keyword_value)

      if (is_empty(keyword_value)) then

         call output%error_msg('could not find the required keyword ' // trim(keyword) // ' in section ' // &
            trim(section))

      end if

   end subroutine get_required_string_keyword


   subroutine get_orbital_keyword_mlcc(this, keyword_value)
      !!
      !! Written by Edvard D. Hansen, 2025
      !!
      !! Gets required orbital keyword for MLCC calculation, and
      !! supports legacy MLCC orbital keywords (cc2 orbitals, ccsd orbitals).
      !!
      implicit none

      class(input_tool), intent(in) :: this
      character(len=200) :: keyword_value

      keyword_value = ""

      ! Current

      call this%get_string_keyword('orbitals', 'mlcc', keyword_value)

      ! Support for keywords in v2.0, will be removed for v3.0
      if (is_empty(keyword_value)) call this%get_string_keyword('cc2 orbitals', 'mlcc', keyword_value)

      if (is_empty(keyword_value)) call this%get_string_keyword('ccsd orbitals', 'mlcc', keyword_value)

      if (is_empty(keyword_value)) then

         call output%error_msg('could not find the required keyword orbitals or ' // &
            'legacy keywords (cc2 orbitals, ccsd orbitals) in section mlcc')

      end if

   end subroutine get_orbital_keyword_mlcc


   function is_keyword_present_input_tool(this, keyword, section) result(is_present)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Returns true if the keyword is in the section.
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section

      logical :: is_present

      is_present = .false.

      if (associated(this%config_)) then
         is_present = this%config_%contains(section, keyword)
      end if

   end function is_keyword_present_input_tool


   subroutine get_present_keywords_input_tool(this, section, keywords)
      !!
      !! Written by Leo Stoll, 2025
      !!
      !! For a given section returns the keywords given in the input file.
      !!
      implicit none

      class(input_tool), intent(inout) :: this

      character(len=*), intent(in) :: section

      character(len=200), dimension(:), allocatable, intent(inout) :: keywords

      if (associated(this%config_)) then

         call this%config_%get_keywords_in_section(section, keywords)

      else

         if (allocated(keywords)) deallocate(keywords)
         allocate(keywords(0))

      end if

   end subroutine get_present_keywords_input_tool


   function is_section_present_input_tool(this, section) result(is_present)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Returns true if the section exists, false if it doesn't.
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: section

      logical :: is_present

      character(len=200), dimension(:), allocatable :: keywords

      is_present = .false.

      if (associated(this%config_)) then

         call this%config_%get_keywords_in_section(section, keywords)
         is_present = size(keywords) > 0

      end if

   end function is_section_present_input_tool


   function get_n_elements_for_keyword(this, keyword, section) result(n_elements)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Gets the number of elements specified for a keyword in set/range notation
      !!
      !! Ranges should always be given as [a,b].
      !! Lists should always be given as {a, b, c, d}.
      !!
      !! Function is called in preparation for get_array_for_keyword
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section

      integer :: n_elements

      character(len=200) :: keyword_value_string

      n_elements = 0
      keyword_value_string = ''
      if (.not. this%is_keyword_present(keyword, section)) return

      call this%get_keyword(keyword, section, keyword_value_string)
      if (is_empty(keyword_value_string)) return  ! Keyword present but no value (e.g. "freeze core" alone)
      if (trim(keyword_value_string) == trim(keyword)) &
         return  ! Character keyword without list or range or value

      n_elements = get_n_elements_in_set_or_range(keyword_value_string)

   end function get_n_elements_for_keyword


   subroutine get_integer_array_for_keyword(this, keyword, section, n_elements, array_)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Gets input variable array (array_) for keyword which is specified on input
      !! by either an integer range or list (of length n_elements).
      !!
      !! Ranges should always be given as [a,b].
      !! Lists should always be given as {a, b, c, d}.
      !!
      !! Routine should be called after the get_n_elements_for_keyword is called
      !! in order to determine n_elements so that array_ can be allocated.
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section

      integer, intent(in) :: n_elements

      integer, dimension(n_elements) :: array_

      character(len=200) :: keyword_value_string

      call check_get_array_for_keyword(keyword, section, n_elements)

      call this%get_keyword(keyword, section, keyword_value_string)

      call get_integers_from_set_or_range(keyword_value_string, n_elements, array_)

   end subroutine get_integer_array_for_keyword


   subroutine get_real_array_for_keyword(this, keyword, section, n_elements, array_)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Andreas Skeidsvoll and Alexander C. Paul, 2019-2023
      !!
      !! Gets input variable array (array_) for keyword
      !! which is specified on input by a list
      !!
      !! Lists should always be given as {a, b, c, d}
      !!
      !! Routine should be called after the get_n_elements_for_keyword is called
      !! in order to determine n_elements so that array_ can be allocated.
      !!
      use string_utilities, only: read_comma_separated_list

      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section
      integer, intent(in) :: n_elements

      real(dp), dimension(n_elements), intent(inout) :: array_

      character(len=200) :: keyword_value_string
      character(len=:), allocatable :: string

      call check_get_array_for_keyword(keyword, section, n_elements)

      call this%get_keyword(keyword, section, keyword_value_string)

      string = trim(adjustl(keyword_value_string))

      if (string(1:1) /= "{" .and. n_elements == 1) then

         read(string, *) array_(1)

      else

         call expect_set(string)
         call read_comma_separated_list(string(2:len(string) - 1), array_, n_elements)

      end if


   end subroutine get_real_array_for_keyword


   subroutine get_string_array_for_keyword(this, keyword, section, n_elements, array_)
      !!
      !! Written by Anna Kristina Schnack-Petersen and Alexander C. Paul, 2022-2023
      !!
      !! Gets input variable array (array_) for keyword which is specified on input
      !! by a list of strings (of length n_elements).
      !!
      !! Lists should always be given as {a, b, c, d}
      !!
      !! Routine should be called after the get_n_elements_for_keyword is called
      !! in order to determine n_elements so that array_ can be allocated.
      !!
      use string_utilities, only: split_at_delimiter

      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: section
      integer, intent(in) :: n_elements

      character(len=200), dimension(n_elements), intent(inout) :: array_

      character(len=200) :: keyword_value_string
      character(len=:), allocatable :: string

      integer :: i

      call check_get_array_for_keyword(keyword, section, n_elements)

      call this%get_keyword(keyword, section, keyword_value_string)

      string = trim(adjustl(keyword_value_string))

      if (string(1:1) /= "{" .and. n_elements == 1) then

         array_(1) = string

      else

         call expect_set(string)
         call split_at_delimiter(string(2:len(string) - 1), n_elements - 1, array_, ',')

         do i = 1, n_elements

            array_(i) = adjustl(array_(i))

         end do

      end if

   end subroutine get_string_array_for_keyword


   function get_n_atoms_input_tool(this) result(n_atoms)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Get n atoms
      !!
      !! Reads the geometry section of the input and counts the number of atoms
      !!
      implicit none

      class(input_tool), intent(in) :: this

      integer :: n_atoms

      character(len=200), dimension(:), allocatable :: qm_geometry
      integer :: n_qm_atom_lines

      call this%get_local_qm_geometry(qm_geometry, n_qm_atom_lines)

      n_atoms = this%geometry_parser_%count_qm_atoms(qm_geometry)

   end function get_n_atoms_input_tool


   function get_n_mm_atoms_input_tool(this) result(n_atoms)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Get n MM atoms
      !!
      implicit none

      class(input_tool), intent(in) :: this

      integer :: n_atoms
      character(len=200), dimension(:), allocatable :: mm_geometry

      call this%get_local_mm_geometry(mm_geometry, n_atoms)

   end function get_n_mm_atoms_input_tool


   function get_n_mm_molecules_input_tool(this) result(n_molecules)
      !!
      !! Written by Sarai D. Folkestad, Sep 2020
      !!
      !! Reads the MM geometry and counts the number of molecules
      !!
      implicit none

      class(input_tool), intent(in) :: this

      integer :: n_molecules

      character(len=200), dimension(:), allocatable :: mm_geometry
      integer :: n_mm_atom_lines

      call this%get_local_mm_geometry(mm_geometry, n_mm_atom_lines)

      n_molecules = this%geometry_parser_%count_mm_molecules(mm_geometry)

   end function get_n_mm_molecules_input_tool


   subroutine get_geometry_input_tool(this, &
                                      n_atoms, &
                                      symbols, &
                                      positions, &
                                      basis_sets, &
                                      charge, &
                                      units_angstrom, &
                                      is_ghost)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad
      !! Asmund H. Tveten and Tor S. Haugland, 2019-2021
      !!
      !! Reads the geometry from the output file and sets it in the list of atoms.
      !!
      !! Note: This routine should be called after a call to the function
      !! get_n_atoms_input_tool which finds the number of atoms in the system
      !!
      implicit none

      class(input_tool), intent(in) :: this

      integer, intent(in) :: n_atoms

      character(len=2), dimension(n_atoms), intent(out) :: symbols
      character(len=100), dimension(n_atoms), intent(out) :: basis_sets
      logical, dimension(n_atoms), intent(out) :: is_ghost

      real(dp), dimension(3, n_atoms), intent(out) :: positions  ! x, y, z
      integer, dimension(n_atoms), intent(out) :: charge

      logical, intent(out) :: units_angstrom

      character(len=200), dimension(:), allocatable :: qm_geometry
      integer :: n_qm_atom_lines

      call this%get_local_qm_geometry(qm_geometry, n_qm_atom_lines)

      call this%geometry_parser_%parse_qm_geometry(qm_geometry, &
                                                   n_atoms, &
                                                   symbols, &
                                                   positions, &
                                                   basis_sets, &
                                                   charge, &
                                                   units_angstrom, &
                                                   is_ghost)

   end subroutine get_geometry_input_tool


   subroutine get_mm_geometry_fq_input_tool(this, &
                                            n_atoms, &
                                            n_molecules, &
                                            n_atoms_per_molecule, &
                                            symbols, &
                                            positions, &
                                            chi, &
                                            eta)
      !!
      !! Written by Tommaso Giovanini and Sarai D. Folkestad, 2019-2020
      !!
      !! Reads the geometry of the MM portion from the input file in the case
      !! of an fq calculation and sets it in the list of atoms.
      !!
      !! Note: In order to be run, you need to know the number of MM atoms and molecules
      !!       in the system
      !!
      implicit none

      class(input_tool), intent(in) :: this
      integer, intent(in) :: n_atoms
      integer, intent(in) :: n_molecules

      character(len=2), dimension(n_atoms), intent(out) :: symbols
      real(dp), dimension(3, n_atoms), intent(out) :: positions
      real(dp), dimension(n_atoms), intent(out) :: chi
      real(dp), dimension(n_atoms), intent(out) :: eta
      integer, dimension(n_molecules), intent(out) :: n_atoms_per_molecule

      character(len=200), dimension(:), allocatable :: mm_geometry
      integer :: n_mm_atom_lines

      call this%get_local_mm_geometry(mm_geometry, n_mm_atom_lines)

      call this%geometry_parser_%parse_mm_geometry_fq(mm_geometry, &
                                                      n_atoms, &
                                                      n_molecules, &
                                                      n_atoms_per_molecule, &
                                                      symbols, &
                                                      positions, &
                                                      chi, &
                                                      eta)

   end subroutine get_mm_geometry_fq_input_tool


   subroutine get_mm_geometry_non_polarizable_input_tool(this, &
                                                         n_atoms, &
                                                         symbols, &
                                                         positions, &
                                                         charge)
      !!
      !! Written by Tommaso Giovanini and Sarai D. Folkestad, 2019-2020
      !!
      !! Reads the geometry of the MM portion from the input file and
      !! sets it in the list of atoms.
      !!
      !! Note: In order to be run, you need to know the number of MM atoms
      !!       there are in the system
      !!
      implicit none

      class(input_tool), intent(in) :: this

      integer, intent(in) :: n_atoms

      character(len=2), dimension(n_atoms), intent(out) :: symbols
      real(dp), dimension(3, n_atoms), intent(out) :: positions
      real(dp), dimension(n_atoms), intent(out) :: charge

      character(len=200), dimension(:), allocatable :: mm_geometry
      integer :: n_mm_atom_lines

      call this%get_local_mm_geometry(mm_geometry, n_mm_atom_lines)

      call this%geometry_parser_%parse_mm_geometry_non_polarizable(mm_geometry, &
                                                                   n_atoms, &
                                                                   symbols, &
                                                                   positions, &
                                                                   charge)

   end subroutine get_mm_geometry_non_polarizable_input_tool


   function string_in_array_keyword(this, keyword, section, string) result(in_list)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, 2019-2023
      !!
      !! Determines if the 'string' is one of the keyword values in the comma separated
      !! list given with 'keyword' in the given 'section' of the input file.
      !!
      !! Examples of such a keyword is 'levels' from the 'mlcc' section:
      !!
      !!    levels: ccs, cc2, ccsd
      !!
      !! This function assumes that the keyword is requested. If it is not, a test should be performed
      !! before the routine is called
      !!
      use string_utilities, only: string_in_comma_separated_list

      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: section
      character(len=*), intent(in) :: keyword
      character(len=*), intent(in) :: string

      logical :: in_list

      character(len=200) :: keyword_value_string

      call this%get_required_keyword(keyword, section, keyword_value_string)
      in_list = string_in_comma_separated_list(keyword_value_string, string)

   end function string_in_array_keyword


   subroutine get_mlcc_levels(this, levels)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, 2019-2023
      !!
      !! Determines if the 'string' is one of the keyword values in the comma separated
      !! list given with 'keyword' in the given 'section' of the input file.
      !!
      !! Examples of such a keyword is 'levels' from the 'mlcc' section:
      !!
      !!    levels: ccs, cc2, ccsd

      use string_utilities, only: read_comma_separated_list

      implicit none

      class(input_tool), intent(in) :: this

      character(len=40), dimension(:), allocatable :: levels
      character(len=40), dimension(:), allocatable :: unordered_levels

      character(len=200) :: keyword_value_string

      integer :: i, j, n_levels, counter

      call this%get_required_keyword('levels', 'mlcc', keyword_value_string)
      call read_comma_separated_list(keyword_value_string, unordered_levels)


      n_levels = size(unordered_levels)
      allocate(levels(n_levels))

      counter = 0

      do i = size(this%cc_wfs), 1, - 1

         do j = 1, n_levels

            if (trim(this%cc_wfs(i)) == unordered_levels(j)) then

               counter = counter + 1
               levels(counter) = unordered_levels(j)

            end if

         end do

      end do


      deallocate(unordered_levels)

   end subroutine get_mlcc_levels


   subroutine cleanup_input_tool(this)
      !!
      !! Written by Eirik F. Kjoenstad, May 2022
      !!
      implicit none

      class(input_tool), intent(inout) :: this

      if (associated(this%config_)) deallocate(this%config_)

   end subroutine cleanup_input_tool


   function is_embedding_on_input_tool(this) result(embedding)
      !!
      !! Written by Sarai D. Folkestad, Sep 2020
      !!
      !! Returns true if wavefunction is embedded.
      !!
      implicit none

      class(input_tool), intent(in) :: this

      logical :: embedding

      embedding = this%is_section_present('molecular mechanics') .or. &
                  this%is_section_present('pcm') .or. this%is_keyword_present('cbo', 'boson')

   end function is_embedding_on_input_tool


   subroutine place_records_in_memory_input_tool(this, section, records_in_memory)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Checks if storage for 'section' is in memory or on disk
      !!
      !! records_in_mem is intent(inout) because it should be set
      !! to a default value before a call to this routine
      !!
      implicit none

      class(input_tool), intent(in) :: this
      character(len=*), intent(in) :: section

      logical, intent(inout) :: records_in_memory

      character(len=200) :: storage

      if (.not. this%is_keyword_present('storage', trim(section))) return

      call this%get_keyword('storage', trim(section), storage)

      ! Determine whether to store records in memory or on file

      if (trim(storage) == 'memory') then

         records_in_memory = .true.

      elseif (trim(storage) == 'disk') then

         records_in_memory = .false.

      else

         call output%error_msg('Could not recognize keyword storage in solver: ', &
                               chars=[trim(storage)])

      end if

   end subroutine place_records_in_memory_input_tool


   function get_n_state_guesses(this) result(n_guesses)
      !!
      !! Written by Eirik F. Kjoenstad, Dec 2021
      !!
      implicit none

      class(input_tool) :: this

      integer :: n_guesses

      character(len=200) :: state_guesses

      call this%get_keyword('state guesses', 'solver cc es', state_guesses)

      n_guesses = get_n_sets_and_ranges(state_guesses)

   end function get_n_state_guesses


   subroutine get_state_guesses(this, occupied, virtual, n_states)
      !!
      !! Written by Sarai D. Folkestad, Dec 2021
      !!
      !! state guesses: {i=1, a=2}, {i=2, a=2}, {i=1, a=1}
      !!
      !! Provided as a (comma separated) list of sets.
      !!
      !! A set comprises of two elements which are
      !! the occupied and virtual indices of the start vector
      !!
      !! 'i =' provides occupied index
      !! 'a =' provides virtual index
      !!
      use string_utilities, only: remove_delimiter_from_string, split_at_delimiter
      use string_utilities, only: n_instances_of_character

      implicit none

      class(input_tool) :: this

      integer, intent(in) :: n_states
      integer, dimension(n_states), intent(out) :: virtual, occupied

      character(len=200) :: state_guesses
      character(len=200), dimension(:), allocatable :: split_string

      integer :: n_elements, cursor_a, cursor_i, i, n_occupied, n_virtual

      call this%get_keyword('state guesses', 'solver cc es', state_guesses)
      state_guesses = adjustl(state_guesses)

      n_occupied = n_instances_of_character(state_guesses, 'i')
      n_virtual = n_instances_of_character(state_guesses, 'a')

      if (n_virtual /= n_occupied) call output%error_msg('in keyword (state guesses)')

      if (n_virtual /= n_states) call output%error_msg('in keyword (state guesses)')

      ! {i=1, a=2}, {i=2, a=2}, {i=1, a=1} -> i=1, a=2} i=2, a=2} i=1, a=1}
      call remove_delimiter_from_string(state_guesses, '{')

      n_elements = n_instances_of_character(state_guesses, '}')

      if (n_elements /= n_states) call output%error_msg('in keyword (state guesses)')

      allocate(split_string(n_elements))

      ! i=1, a=2} i=2, a=2} i=1, a=1} -> string array ("i=1, a=2", "i=2, a=2", "i=1, a=1")
      call split_at_delimiter(state_guesses, n_elements, split_string, '}')

      do i = 1, n_elements

         call remove_delimiter_from_string(split_string(i), '=')
         call remove_delimiter_from_string(split_string(i), ',')

         cursor_i = first_index_of_substring(split_string(i), 'i')
         cursor_a = first_index_of_substring(split_string(i), 'a')

         if (cursor_i < cursor_a) then

            read(split_string(i)(cursor_i + 1:cursor_a - 1), *) occupied(i)
            read(split_string(i)(cursor_a + 1:), *) virtual(i)

         else

            read(split_string(i)(cursor_a + 1:cursor_i - 1), *) virtual(i)
            read(split_string(i)(cursor_i + 1:), *) occupied(i)

         end if

      end do

      deallocate(split_string)

   end subroutine get_state_guesses


   subroutine check_for_errors(this)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Looks for errors the user may have made when writing the input file.
      !! Illegal keywords and duplicates are validated during parse (set_string_from_file).
      !! Here we check that required sections are present.
      !!
      implicit none

      class(input_tool), intent(in) :: this

      integer :: k
      character(len=200), dimension(:), allocatable :: keywords
      character(len=200), dimension(:), allocatable :: section_names

      if (.not. associated(this%config_)) return
      if (.not. associated(this%input_spec)) return

      call this%input_spec%get_added_sections(section_names)
      do k = 1, size(section_names)
         if (.not. this%input_spec%section_is_required(section_names(k))) cycle
         call this%config_%get_keywords_in_section(trim(section_names(k)), keywords)
         if (size(keywords) == 0) then

            call output%error_msg('All calculations require the section "(a0)". It appears to be missing.', &
                                  chars=[trim(section_names(k))])

         end if
      end do

   end subroutine check_for_errors


   subroutine check_for_deprecations(this)
      !!
      !! Written by Edvard D. Hansen, 2026
      !!
      !! Checks if any of the used keywords are deprecated according to the
      !! deprecation table in deprecated_keys.F90
      !!
      implicit none

      class(input_tool), intent(in) :: this

      integer :: i
      integer :: j
      type(et_config_entry) :: entry
      character(len=200) :: section_str
      character(len=200) :: keyword_str
      logical :: is_deprecated
      logical :: section_already_checked
      character(len=:), allocatable :: replacement
      character(len=:), allocatable :: deprecated_in_version
      character(len=:), allocatable :: removed_in_version
      character(len=200), dimension(:), allocatable :: checked_sections
      character(len=200), dimension(:), allocatable :: new_checked_sections

      if (.not. associated(this%config_)) return
      allocate(checked_sections(0))

      do i = 1, this%config_%get_n_entries()

         entry = this%config_%get_entry(i)
         section_str = entry%section_name
         keyword_str = entry%keyword_name

         section_already_checked = .false.
         do j = 1, size(checked_sections)
            if (trim(section_str) == trim(checked_sections(j))) then
               section_already_checked = .true.
               exit
            end if
         end do

         if (.not. section_already_checked) then

            call this%deprecated_keywords%check_deprecated_keyword(section_str, &
                                                                   is_deprecated, &
                                                                   replacement, &
                                                                   deprecated_in_version, &
                                                                   removed_in_version)

            if (is_deprecated) then

               call output%warning_msg( &
                       'Section ''(a0)'' is deprecated as of eT (a0) ' // &
                          'and will be removed by eT (a0). ' // &
                          'Use ''(a0)'' instead. For more information ' // &
                          'see manual at www.etprogram.org.', &
                       chars=[character(len=200) :: section_str, &
                          deprecated_in_version, &
                          removed_in_version, &
                          replacement], &
                       fs='(t12,a)' &
                    )

            end if

            allocate(new_checked_sections(size(checked_sections) + 1))
            if (size(checked_sections) > 0) new_checked_sections(1:size(checked_sections)) = checked_sections
            new_checked_sections(size(new_checked_sections)) = section_str
            call move_alloc(new_checked_sections, checked_sections)

         end if

         call this%deprecated_keywords%check_deprecated_keyword(keyword_str, &
                                                                is_deprecated, &
                                                                replacement, &
                                                                deprecated_in_version, &
                                                                removed_in_version)

         if (is_deprecated) then

            call output%warning_msg( &
                    'Keyword ''(a0)'' is deprecated as of eT (a0) ' // 'and will be removed by eT (a0). ' // &
                       'Use ''(a0)'' instead. For more information ' // 'see manual at www.etprogram.org.', &
                    chars=[character(len=200) :: keyword_str, &
                       deprecated_in_version, &
                       removed_in_version, &
                       replacement], &
                    fs='(t12,a)' &
                 )

         end if

      end do

   end subroutine check_for_deprecations


   function is_section_recognized(this, section) result(allowed)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2019-2021
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: section

      logical :: allowed

      allowed = .false.
      if (associated(this%input_spec)) then
         allowed = this%input_spec%is_section_added(section)
      end if

   end function is_section_recognized


   subroutine section_not_recognized(this, section)
      !!
      !! Written by Sara Angelico and Alexander C. Paul, 2023
      !!
      implicit none

      class(input_tool), intent(in) :: this

      character(len=*), intent(in) :: section

      call output%printf('m', &
                         'Could not recognize section named "(a0)".', &
                         chars=[trim(section)], &
                         fs='(/t3,a)')

      call this%print_sections()
      call output%error_msg('Something is wrong in the input file. See above.')

   end subroutine section_not_recognized


   function get_n_es_types(this) result(n)
      !!
      !! Written by Sarai D. Folkestad, Feb 2026
      !!
      implicit none
      class(input_tool), intent(inout) :: this
      integer :: n

      n = this%get_n_elements_for_keyword('type', 'solver cc es')
      if (.not. this%is_keyword_present('type', 'solver cc es')) n = 1

   end function get_n_es_types


   subroutine get_n_es_states_many(this, n, n_states, spin_symmetry)
      !!
      !! Written by Sarai D. Folkestad, Feb 2026
      !!
      implicit none
      class(input_tool), intent(inout) :: this
      integer, intent(in) :: n
      character(len=*), intent(in) :: spin_symmetry
      integer, dimension(n), intent(out) :: n_states

      call this%get_array_for_keyword(trim(spin_symmetry) // ' states', 'solver cc es', n, n_states)

   end subroutine get_n_es_states_many


   subroutine get_n_es_states_one(this, n_states, spin_symmetry)
      !!
      !! Written by Sarai D. Folkestad, Feb 2026
      !!
      implicit none
      class(input_tool), intent(inout) :: this
      character(len=*), intent(in) :: spin_symmetry
      integer, intent(out) :: n_states

      call this%get_keyword(trim(spin_symmetry) // ' states', 'solver cc es', n_states)

   end subroutine get_n_es_states_one


   subroutine get_es_types(this, n, es_types)
      !!
      !! Written by Sarai D. Folkestad, Feb 2026
      !!
      use state_descriptor_class, only: es_type

      implicit none
      class(input_tool), intent(inout) :: this
      integer, intent(in) :: n

      type(es_type), dimension(n), intent(out) :: es_types

      character(len=200), dimension(:), allocatable :: es_strings
      character(len=200) :: string

      integer :: i

      if (.not. this%is_keyword_present('type', 'solver cc es')) then

         es_types(1) = es_type()

         if (this%is_keyword_present('ionization', 'solver cc es')) es_types(1)%ip = .true.
         if (this%is_keyword_present('electron attachment', 'solver cc es')) es_types(1)%ea = .true.

         ! Ensure input compatibility within major v2
         if (this%is_keyword_present('core excitation', 'solver cc es')) es_types(1)%cvs = .true.
         if (this%is_keyword_present('remove core', 'solver cc es')) es_types(1)%rm_core = .true.

      else

         allocate(es_strings(n))
         call this%get_array_for_keyword('type', 'solver cc es', n, es_strings)

         do i = 1, n

            string = trim(es_strings(i))

            if (string == 'valence') es_types(i) = es_type()
            if (string == 'core') es_types(i) = es_type(cvs=.true., rm_core=.false., ip=.false., ea=.false.)
            if (string == 'remove core') &
               es_types(i) = es_type(cvs=.false., rm_core=.true., ip=.false., ea=.false.)

            if (this%is_keyword_present('ionization', 'solver cc es')) es_types(i)%ip = .true.
            if (this%is_keyword_present('electron attachment', 'solver cc es')) es_types(i)%ea = .true.

         end do

      end if

   end subroutine get_es_types


   function get_es_spin_symmetry(this) result(do_spin)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      !! Determines the spin symmetry to run
      !!
      !! this%do_spin(k)
      !!
      !! k = 1 -> singlet
      !! k = 2 -> triplet
      !!
      implicit none

      class(input_tool), intent(inout) :: this
      logical, dimension(2) :: do_spin

      do_spin = .false.

      if (this%is_keyword_present('triplet states', 'solver cc es')) then

         do_spin(2) = .true.

      end if

      if (this%is_keyword_present('singlet states', 'solver cc es')) then

         do_spin(1) = .true.

      end if

   end function get_es_spin_symmetry


   function get_es_left_or_right(this) result(do_left_or_right)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      !! Determine the transformation
      !!
      !! k = 1 -> right
      !! k = 2 -> left
      !!
      implicit none

      class(input_tool), intent(inout) :: this
      logical, dimension(2) :: do_left_or_right

      do_left_or_right = .false.

      if (this%is_keyword_present('left eigenvectors', 'solver cc es')) then

         do_left_or_right(2) = .true.

      end if

      if (this%is_keyword_present('right eigenvectors', 'solver cc es')) then

         do_left_or_right(1) = .true.

      end if

   end function get_es_left_or_right

end module input_tool_class

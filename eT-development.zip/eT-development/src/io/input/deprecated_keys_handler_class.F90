
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module deprecated_keys_handler_class
   !!
   !! Deprecated keys class
   !! Written by Edvard D. Hansen, 2026
   !!
   !! The deprecation table below may be updated when keywords become deprecated.
   !! Update by adding new deprecated keywords to the construct_deprecation_table routine.
   !!
   implicit none

   type :: deprecated_key

      character(len=30) :: old_keyword
      character(len=30) :: replacement_keyword
      character(len=30) :: deprecated_in_version
      character(len=30) :: removed_in_version

   end type deprecated_key


   type :: deprecated_keys_handler

      integer :: n_deprecated_keys
      type(deprecated_key), dimension(:), allocatable :: deprecation_table

   contains

      procedure, public :: check_deprecated_keyword

   end type deprecated_keys_handler

   interface deprecated_keys_handler

      procedure :: new_deprecated_keys_handler

   end interface deprecated_keys_handler

contains

   function new_deprecated_keys_handler() result(this)

      !! Written by Sarai D. Folkestad and Edvard D. Hansen, 2026

      implicit none
      type(deprecated_keys_handler) :: this

      ! Remember to update when adding a new deprecated key
      this%n_deprecated_keys = 5
      allocate(this%deprecation_table(this%n_deprecated_keys))

      this%deprecation_table(1) = deprecated_key(old_keyword='cc2 orbitals', &
                                                 replacement_keyword='orbitals', &
                                                 deprecated_in_version='v2.2', &
                                                 removed_in_version='v3.0')

      this%deprecation_table(2) = deprecated_key(old_keyword='ccsd orbitals', &
                                                 replacement_keyword='orbitals', &
                                                 deprecated_in_version='v2.2', &
                                                 removed_in_version='v3.0')

      this%deprecation_table(3) = deprecated_key(old_keyword='core excitation', &
                                                 replacement_keyword='type', &
                                                 deprecated_in_version='v2.2', &
                                                 removed_in_version='v3.0')

      this%deprecation_table(4) = deprecated_key(old_keyword='remove core', &
                                                 replacement_keyword='type', &
                                                 deprecated_in_version='v2.2', &
                                                 removed_in_version='v3.0')

      this%deprecation_table(5) = deprecated_key(old_keyword='solver hf es', &
                                                 replacement_keyword='solver scf es', &
                                                 deprecated_in_version='v2.4', &
                                                 removed_in_version='v3.0')

   end function new_deprecated_keys_handler


   subroutine check_deprecated_keyword(this, &
                                       keyword, &
                                       is_deprecated, &
                                       replacement, &
                                       deprecated_in_version, &
                                       removed_in_version)
      !!
      !! Written by Edvard D. Hansen, 2026
      !!
      !! Checks if a given keyword is deprecated according to the deprecation table above.
      !! If a deprecated keyword is found, the routine provides the replacement keyword,
      !! and deprecation/removal version numbers.
      !!
      implicit none

      class(deprecated_keys_handler) :: this

      character(len=*), intent(in) :: keyword
      logical, intent(out) :: is_deprecated
      character(len=:), allocatable, intent(out) :: replacement
      character(len=:), allocatable, intent(out) :: deprecated_in_version
      character(len=:), allocatable, intent(out) :: removed_in_version

      integer :: i

      is_deprecated = .false.

      do i = 1, this%n_deprecated_keys

         if (trim(keyword) == trim(this%deprecation_table(i)%old_keyword)) then
            replacement = trim(this%deprecation_table(i)%replacement_keyword)
            deprecated_in_version = trim(this%deprecation_table(i)%deprecated_in_version)
            removed_in_version = trim(this%deprecation_table(i)%removed_in_version)

            is_deprecated = .true.

            return
         end if
      end do

   end subroutine check_deprecated_keyword

end module deprecated_keys_handler_class

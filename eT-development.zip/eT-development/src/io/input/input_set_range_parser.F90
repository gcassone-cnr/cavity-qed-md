
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module input_set_range_parser

   !!
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad and Alexander C. Paul, 2019-2023; extracted 2026
   !!
   !! Parses set {a,b,c} and range [a,b] notation from input strings.
   !!

   use global_out, only: output
   use string_utilities, only: string_starts_with, n_instances_of_character
   use string_utilities, only: read_comma_separated_list

   implicit none

   private

   public :: get_n_sets_and_ranges
   public :: get_n_elements_in_set_or_range
   public :: get_integers_from_set_or_range
   public :: expect_set
   public :: expect_range
   public :: check_get_array_for_keyword


contains


   function get_n_sets_and_ranges(string) result(n_elements)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Gets the number of sets/ranges in a string,
      !!
      !! Ranges should always be given as [a,b].
      !!
      !! Lists/ranges should always be given as {a, b, c, d},
      !! that is, in set notation.
      !!
      implicit none

      character(len=200), intent(inout) :: string

      integer :: n_elements

      integer :: i
      integer :: n_set_start, n_set_end
      integer :: n_range_start, n_range_end

      n_set_start = 0
      n_set_end = 0

      n_range_start = 0
      n_range_end = 0

      string = adjustl(string)

      do i = 1, len_trim(string)

         if (string(i:i) == '{') n_set_start = n_set_start + 1
         if (string(i:i) == '}') n_set_end = n_set_end + 1

         if (string(i:i) == '[') n_range_start = n_range_start + 1
         if (string(i:i) == ']') n_range_end = n_range_end + 1

      end do

      if (n_set_start /= n_set_end) call output%error_msg('found open set in input file')
      if (n_range_start /= n_range_end) call output%error_msg('found open range in input file')

      n_elements = n_set_start + n_range_start

   end function get_n_sets_and_ranges


   function get_n_elements_in_set_or_range(string) result(n_elements)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Gets the number of elements in range or list,
      !!
      !! Ranges should always be given as [a,b], where a and b are integers.
      !! Lists/Sets should always be given as {a, b, c, d}.
      !!
      implicit none

      character(len=200), intent(inout) :: string

      integer :: n_elements

      integer :: last, first, n_characters
      integer :: comma_index

      n_elements = 0

      string = adjustl(string)

      n_characters = len_trim(string)

      if (string_starts_with(string, '[')) then  ! range

         call expect_range(string)

         comma_index = index(string, ',')

         read(string(2:comma_index - 1), *) first
         read(string(comma_index + 1:n_characters - 1), *) last

         n_elements = last - first + 1

      else if (string_starts_with(string, '{')) then  ! set

         call expect_set(string)

         n_elements = 1  ! Assuming that the set contains at least one element (otherwise why give list?)
         n_elements = n_elements + n_instances_of_character(string(2:), ',')

      else  ! Did not find list or range (assume single element)

         n_elements = 1

      end if

   end function get_n_elements_in_set_or_range


   subroutine get_integers_from_set_or_range(string, n_elements, elements)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      !! Ranges should always be given as [a,b].
      !!
      !! Lists should always be given as {a, b, c, d}.
      !!
      implicit none

      character(len=200), intent(inout) :: string

      integer, intent(in) :: n_elements

      integer, dimension(n_elements), intent(out) :: elements

      integer :: first, last, length, n_characters
      integer :: i, comma_index

      string = adjustl(string)

      n_characters = len_trim(string)

      if (string_starts_with(string, '[')) then  ! range

         call expect_range(string)

         comma_index = index(string, ',')

         read(string(2:comma_index - 1), *) first
         read(string(comma_index + 1:n_characters - 1), *) last
         length = last - first + 1

         if (n_elements /= length) call output%error_msg('Mismatch in number of elements of range.')

         elements = [(i, i = first, last)]

      else if (string_starts_with(string, '{')) then  ! set

         call expect_set(string)
         call read_comma_separated_list(string(2:n_characters - 1), elements, n_elements)

      else if (n_elements == 1) then

         read(string, *) elements(1)

      else  ! Did not find list or range

         call output%error_msg('neither list nor range was found.')

      end if

   end subroutine get_integers_from_set_or_range


   subroutine expect_set(string)
      !!
      !! Written by Alexander C. Paul, Mar 2023
      !!
      implicit none

      character(len=*), intent(in) :: string
      integer :: opening, closing

      opening = index(string, '{')
      if (opening == 0) call output%error_msg('Expected set, but no "{" found in string.')

      closing = index(string, '}')
      if (closing == 0) call output%error_msg('Expected set, but no "}" found in string.')

      if (closing < opening) call output%error_msg('Expected set, but "}" found before "{".')

   end subroutine expect_set


   subroutine expect_range(string)
      !!
      !! Written by Alexander C. Paul, Mar 2023
      !!
      implicit none

      character(len=*), intent(in) :: string
      integer :: opening, closing, comma

      opening = index(string, '[')
      if (opening == 0) call output%error_msg('Expected range, but no "[" found in string.')

      closing = index(string, ']')
      if (closing == 0) call output%error_msg('Expected range, but no "]" found in string.')

      comma = index(string, ',')
      if (comma == 0) call output%error_msg('Expected range, but no "," found in string.')

      if (comma < opening) call output%error_msg('Expected range, but "," found before "[".')
      if (closing < comma) call output%error_msg('Expected range, but "]" found before ",".')

   end subroutine expect_range


   subroutine check_get_array_for_keyword(keyword, section, n_elements)
      !!
      !! Written by Alexander C. Paul, May 2023
      !!
      implicit none

      character(len=*), intent(in) :: keyword, section
      integer, intent(in) :: n_elements

      if (n_elements <= 0) then

         call output%error_msg( &
                 "Get array for keyword called with n_elements=(i0). Keyword: (a0) Section: " // section, &
                 ints=[n_elements], &
                 chars=[keyword] &
              )

      end if

   end subroutine check_get_array_for_keyword


end module input_set_range_parser


! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module keyword_value_types_module

   !!
   !! Written by Eirik F. Kjoenstad, 2026
   !!
   !! Keyword value type constants for schema-based validation.
   !! Used by input_specification and et_config.
   !!

   implicit none

   integer, parameter, public :: KV_NONE = 0
   integer, parameter, public :: KV_INT_POSITIVE = 1
   integer, parameter, public :: KV_INT_NONNEGATIVE = 2
   integer, parameter, public :: KV_REAL_POSITIVE = 3
   integer, parameter, public :: KV_REAL_NONNEGATIVE = 4
   integer, parameter, public :: KV_BOOL = 5
   integer, parameter, public :: KV_REAL = 6

end module keyword_value_types_module

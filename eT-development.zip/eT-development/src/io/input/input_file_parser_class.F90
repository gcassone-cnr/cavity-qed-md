
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module input_file_parser_class
   !!
   !! Input file parser
   !!
   !! Object that reads the eT input file and provides character arrays that
   !! can be searched for keywords and sections
   !!
   use formatted_read_file_class, only: formatted_read_file
   use string_utilities, only: is_empty, remove_substring_after_symbol

   implicit none

   type :: input_file_parser

      type(formatted_read_file), allocatable, private :: file_

      integer, private :: n_keyword_lines  ! Number of lines excluding the geometry section
      integer, private :: n_qm_atom_lines  ! Number of QM atoms
      integer, private :: n_mm_atom_lines  ! Number of MM atoms

      ! Arrays storing lines in the input
      character(len=200), dimension(:), allocatable, private :: keyword_lines
      character(len=200), dimension(:), allocatable, private :: qm_geometry
      character(len=200), dimension(:), allocatable, private :: mm_geometry

   contains

      procedure, public :: read_and_process_input_file

      procedure, private :: read_and_process_keywords_and_geometry
      procedure, private :: count_keyword_and_geometry_lines

      procedure, public :: get_keyword_lines
      procedure, public :: get_qm_geometry_lines

      procedure, public :: is_mm_geometry_present
      procedure, public :: get_mm_geometry_lines

   end type input_file_parser


   interface input_file_parser

      procedure :: new_input_file_parser

   end interface input_file_parser


contains


   function new_input_file_parser(name_) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      type(input_file_parser) :: this

      character(len=*), intent(in) :: name_

      this%file_ = formatted_read_file(name_)

   end function new_input_file_parser


   subroutine read_and_process_input_file(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      class(input_file_parser), intent(inout) :: this

      call this%file_%open_()
      call this%read_and_process_keywords_and_geometry()
      call this%file_%close_()

   end subroutine read_and_process_input_file


   subroutine read_and_process_keywords_and_geometry(this)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !!
      !!
      !! Reads input file, extracting information into
      !! this%keyword_lines (input file lines excluding the geometry)
      !! and into this%qm_geometry and this%mm_geometry.
      !!
      implicit none

      class(input_file_parser), intent(inout) :: this
      call this%file_%rewind_()
      call this%count_keyword_and_geometry_lines()

      ! Read keyword lines
      allocate(this%keyword_lines(this%n_keyword_lines))

      call this%file_%rewind_()
      call this%file_%read_n_lines_as_lowercase(this%keyword_lines, this%n_keyword_lines)

      if (this%n_qm_atom_lines < 1) error stop 'No QM atoms in geometry!'

      ! Read QM geometry lines
      allocate(this%qm_geometry(this%n_qm_atom_lines))

      call this%file_%skip(1)  ! Skip section header: 'geometry'

      call this%file_%read_n_lines_as_lowercase(this%qm_geometry, &
                                                this%n_qm_atom_lines, &
                                                adjust=.true.)

      ! Read MM geometry lines if present
      if (this%n_mm_atom_lines > 0) then

         allocate(this%mm_geometry(this%n_mm_atom_lines))

         call this%file_%skip(1)  ! Skip separator line: '--'
         call this%file_%read_n_lines_as_lowercase(this%mm_geometry, this%n_mm_atom_lines, adjust=.true.)

      end if


   end subroutine read_and_process_keywords_and_geometry


   subroutine count_keyword_and_geometry_lines(this)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(input_file_parser), intent(inout) :: this

      character(len=200) :: line

      integer :: io_error
      logical :: QM_atoms

      this%n_keyword_lines = 0

      do

         call this%file_%read_(line, '(a)', io_stat=io_error)

         if (trim(adjustl(remove_substring_after_symbol(line, '!'))) == '- geometry') then

            exit

         elseif (io_error /= 0) then

            error stop "The 'geometry' section appears to be missing in the input file."

         end if

         this%n_keyword_lines = this%n_keyword_lines + 1

      end do

      ! Continue reading the geometry to count QM and MM atoms

      QM_atoms = .true.
      this%n_qm_atom_lines = 0
      this%n_mm_atom_lines = 0

      do

         call this%file_%read_(line, '(a)', io_stat=io_error)

         if (is_iostat_end(io_error)) exit

         if (is_empty(line)) cycle

         if (trim(adjustl(line)) == '--') then  ! QM and MM atoms separator

            QM_atoms = .false.
            cycle

         end if

         if (QM_atoms) then

            this%n_qm_atom_lines = this%n_qm_atom_lines + 1

         else

            this%n_mm_atom_lines = this%n_mm_atom_lines + 1

         end if

      end do

   end subroutine count_keyword_and_geometry_lines


   subroutine get_keyword_lines(this, keyword_lines, n_keyword_lines)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      class(input_file_parser), intent(in) :: this

      character(len=200), dimension(:), allocatable, intent(out) :: keyword_lines
      integer, intent(out) :: n_keyword_lines

      allocate(keyword_lines, source = this%keyword_lines)
      n_keyword_lines = this%n_keyword_lines

   end subroutine get_keyword_lines


   subroutine get_qm_geometry_lines(this, qm_geometry_lines, n_qm_atom_lines)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      class(input_file_parser), intent(in) :: this

      character(len=200), dimension(:), allocatable, intent(out) :: qm_geometry_lines
      integer, intent(out) :: n_qm_atom_lines

      allocate(qm_geometry_lines, source = this%qm_geometry)
      n_qm_atom_lines = this%n_qm_atom_lines

   end subroutine get_qm_geometry_lines


   function is_mm_geometry_present(this) result(present)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      class(input_file_parser), intent(in) :: this

      logical :: present

      present = this%n_mm_atom_lines > 0

   end function is_mm_geometry_present


   subroutine get_mm_geometry_lines(this, mm_geometry_lines, n_mm_atom_lines)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      class(input_file_parser), intent(in) :: this

      character(len=200), dimension(:), allocatable, intent(out) :: mm_geometry_lines
      integer, intent(out) :: n_mm_atom_lines

      allocate(mm_geometry_lines, source = this%mm_geometry)
      n_mm_atom_lines = this%n_mm_atom_lines

   end subroutine get_mm_geometry_lines


end module input_file_parser_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module input_specification_class

   !!
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Sara Angelico, Alexander C. Paul and Leo Stoll, 2019-2026
   !!
   !! Input specification class
   !!
   !! This class is used to store a given set of sections with allowed keywords and defined keyword value types.
   !! Includes functionality to check if section and keyword-in-section exists.
   !! See the input_structure module for the actual defined sections/keywords.
   !!
   !!

   use string_utilities, only: convert_to_lowercase, is_empty
   use keyword_value_types_module, only: KV_NONE

   implicit none

   private

   type, public :: keyword_descriptor_type

      character(len=30) :: name
      integer :: value_type
      character(len=200) :: default_value

   end type keyword_descriptor_type

   public :: keyword_descriptor

   interface keyword_descriptor

      procedure :: keyword_untyped
      procedure :: keyword_typed

   end interface keyword_descriptor

   type :: section_entry

      character(len=:), allocatable :: section_name
      logical :: required
      character(len=30), dimension(:), allocatable :: allowed_keywords
      integer, dimension(:), allocatable :: keyword_value_types
      character(len=200), dimension(:), allocatable :: keyword_defaults

   end type section_entry

   type, public :: input_specification

      type(section_entry), dimension(:), allocatable, private :: sections

   contains

      procedure, public :: clear
      procedure, public :: add_section_with_value_types
      procedure, public :: is_section_added
      procedure, public :: is_keyword_added
      procedure, public :: get_keyword_value_type
      procedure, public :: get_keyword_default
      procedure, public :: get_added_sections
      procedure, public :: get_added_keywords_for_section
      procedure, public :: has_sections
      procedure, public :: section_is_required
      procedure, public :: add_section

      procedure, private :: get_section_index

   end type input_specification

   interface input_specification

      procedure :: new_input_specification

   end interface input_specification

contains

   function keyword_untyped(name) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Constructor for untyped keyword (value_type = KV_NONE).
      !!
      implicit none
      character(len=*), intent(in) :: name
      type(keyword_descriptor_type) :: this

      this%name = name
      this%value_type = KV_NONE
      this%default_value = ''

   end function keyword_untyped


   function keyword_typed(name, value_type, default) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Constructor for typed keyword (value_type for sanity checks).
      !! Optional default: string value used when keyword is absent from config.
      !!
      implicit none
      character(len=*), intent(in) :: name
      integer, intent(in) :: value_type
      character(len=*), intent(in), optional :: default
      type(keyword_descriptor_type) :: this

      this%name = name
      this%value_type = value_type
      if (present(default) .and. .not. is_empty(default)) then
         this%default_value = trim(adjustl(default))
      else
         this%default_value = ''
      end if

   end function keyword_typed


   function new_input_specification() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Constructor: empty specification.
      !!
      implicit none

      type(input_specification) :: this

      allocate(this%sections(0))

   end function new_input_specification


   subroutine clear(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Drop all registered sections/keywords.
      !!
      implicit none

      class(input_specification), intent(inout) :: this

      if (allocated(this%sections)) deallocate(this%sections)

   end subroutine clear


   subroutine add_section_with_value_types(this, &
                                           section_name, &
                                           allowed_keywords, &
                                           keyword_value_types, &
                                           required, &
                                           keyword_defaults)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Sara Angelico, Alexander C. Paul and Leo Stoll, 2019-2026
      !!
      !! Insert or replace one section entry with value-type metadata for sanity checks.
      !! Optional keyword_defaults: default string values when keyword is absent from config.
      !!
      implicit none

      class(input_specification), intent(inout) :: this

      character(len=*), intent(in) :: section_name
      character(len=30), dimension(:), intent(in) :: allowed_keywords
      integer, dimension(:), intent(in) :: keyword_value_types
      logical, intent(in), optional :: required
      character(len=200), dimension(:), intent(in), optional :: keyword_defaults

      character(len=:), allocatable :: standardized_section_name
      character(len=30), dimension(:), allocatable :: normalized_keywords
      integer, dimension(:), allocatable :: value_types
      type(section_entry), dimension(:), allocatable :: new_registry

      integer :: i
      integer :: section_index
      integer :: n_sections

      standardized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(standardized_section_name)

      allocate(normalized_keywords(size(allowed_keywords)))
      allocate(value_types(size(keyword_value_types)))
      do i = 1, size(allowed_keywords)

         normalized_keywords(i) = trim(adjustl(allowed_keywords(i)))
         call convert_to_lowercase(normalized_keywords(i))
         value_types(i) = keyword_value_types(i)

      end do

      if (.not. allocated(this%sections)) allocate(this%sections(0))

      section_index = this%get_section_index(standardized_section_name)

      if (section_index > 0) then

         this%sections(section_index)%allowed_keywords = normalized_keywords
         this%sections(section_index)%keyword_value_types = value_types
         this%sections(section_index)%required = .false.

         if (present(required)) this%sections(section_index)%required = required

         if (allocated(this%sections(section_index)%keyword_defaults)) &
            deallocate(this%sections(section_index)%keyword_defaults)

         if (present(keyword_defaults)) then
            allocate(this%sections(section_index)%keyword_defaults(size(keyword_defaults)))
            this%sections(section_index)%keyword_defaults = keyword_defaults
         end if

         return

      end if

      n_sections = size(this%sections)
      allocate(new_registry(n_sections + 1))
      if (n_sections > 0) new_registry(1:n_sections) = this%sections

      new_registry(n_sections + 1)%section_name = standardized_section_name
      new_registry(n_sections + 1)%required = .false.
      if (present(required)) new_registry(n_sections + 1)%required = required

      allocate(new_registry(n_sections + 1)%allowed_keywords(size(normalized_keywords)))
      new_registry(n_sections + 1)%allowed_keywords = normalized_keywords

      allocate(new_registry(n_sections + 1)%keyword_value_types(size(value_types)))
      new_registry(n_sections + 1)%keyword_value_types = value_types

      if (present(keyword_defaults)) then
         allocate(new_registry(n_sections + 1)%keyword_defaults(size(keyword_defaults)))
         new_registry(n_sections + 1)%keyword_defaults = keyword_defaults
      end if

      call move_alloc(new_registry, this%sections)

   end subroutine add_section_with_value_types


   subroutine add_section(this, section_name, required, keywords)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Sara Angelico, Alexander C. Paul and Leo Stoll, 2019-2026
      !!
      !! Insert or replace (if already present) section in the input specification.
      !!
      implicit none

      class(input_specification), intent(inout) :: this
      character(len=*), intent(in) :: section_name
      logical, intent(in) :: required
      type(keyword_descriptor_type), dimension(:), intent(in) :: keywords

      character(len=30), dimension(:), allocatable :: allowed_keywords
      integer, dimension(:), allocatable :: keyword_value_types
      character(len=200), dimension(:), allocatable :: keyword_defaults
      integer :: k

      allocate(allowed_keywords(size(keywords)))
      allocate(keyword_value_types(size(keywords)))
      allocate(keyword_defaults(size(keywords)))

      do k = 1, size(keywords)
         allowed_keywords(k) = keywords(k)%name
         keyword_value_types(k) = keywords(k)%value_type

         if (.not. is_empty(keywords(k)%default_value)) then
            keyword_defaults(k) = trim(adjustl(keywords(k)%default_value))
         else
            keyword_defaults(k) = ''
         end if
      end do

      call this%add_section_with_value_types(section_name, &
                                             allowed_keywords, &
                                             keyword_value_types, &
                                             required, &
                                             keyword_defaults)

   end subroutine add_section


   function is_section_added(this, section_name) result(found)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Sara Angelico, Alexander C. Paul and Leo Stoll, 2019-2026
      !!
      !! Return true if section exists in specification.
      !!
      implicit none

      class(input_specification), intent(in) :: this
      character(len=*), intent(in) :: section_name
      logical :: found
      character(len=:), allocatable :: standardized_section_name

      standardized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(standardized_section_name)

      found = this%get_section_index(standardized_section_name) > 0

   end function is_section_added


   function is_keyword_added(this, section_name, keyword_name) result(found)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Sara Angelico, Alexander C. Paul and Leo Stoll, 2019-2026
      !!
      !! Return true if keyword exists under section in specification.
      !!
      implicit none

      class(input_specification), intent(in) :: this
      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name

      logical :: found

      character(len=:), allocatable :: standardized_section_name
      character(len=:), allocatable :: standardized_keyword_name

      integer :: i
      integer :: section_index

      standardized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(standardized_section_name)

      standardized_keyword_name = trim(adjustl(keyword_name))
      call convert_to_lowercase(standardized_keyword_name)

      section_index = this%get_section_index(standardized_section_name)
      if (section_index <= 0) then
         found = .false.
         return
      end if

      found = .false.
      do i = 1, size(this%sections(section_index)%allowed_keywords)
         if (trim(this%sections(section_index)%allowed_keywords(i)) == trim(standardized_keyword_name)) then
            found = .true.
            return
         end if
      end do

   end function is_keyword_added


   function get_keyword_value_type(this, section_name, keyword_name) result(value_type)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Sara Angelico, Alexander C. Paul and Leo Stoll, 2019-2026
      !!
      !! Return value type (KV_*) for keyword in section, or KV_NONE if not specified.
      !!
      implicit none

      class(input_specification), intent(in) :: this
      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name

      integer :: value_type

      character(len=:), allocatable :: standardized_section_name
      character(len=:), allocatable :: standardized_keyword_name

      integer :: i
      integer :: section_index

      value_type = KV_NONE

      standardized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(standardized_section_name)

      standardized_keyword_name = trim(adjustl(keyword_name))
      call convert_to_lowercase(standardized_keyword_name)

      section_index = this%get_section_index(standardized_section_name)
      if (section_index <= 0) return

      if (.not. allocated(this%sections(section_index)%keyword_value_types)) return

      do i = 1, size(this%sections(section_index)%allowed_keywords)
         if (trim(this%sections(section_index)%allowed_keywords(i)) == trim(standardized_keyword_name)) then
            value_type = this%sections(section_index)%keyword_value_types(i)
            return
         end if
      end do

   end function get_keyword_value_type


   subroutine get_keyword_default(this, section_name, keyword_name, default_value, has_default)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Return default value for keyword when present; otherwise has_default=.false.
      !!
      implicit none

      class(input_specification), intent(in) :: this
      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(out) :: default_value
      logical, intent(out) :: has_default

      character(len=:), allocatable :: standardized_section_name
      character(len=:), allocatable :: standardized_keyword_name

      integer :: i
      integer :: section_index

      default_value = ''
      has_default = .false.

      standardized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(standardized_section_name)

      standardized_keyword_name = trim(adjustl(keyword_name))
      call convert_to_lowercase(standardized_keyword_name)

      section_index = this%get_section_index(standardized_section_name)
      if (section_index <= 0) return

      if (.not. allocated(this%sections(section_index)%keyword_defaults)) return

      do i = 1, size(this%sections(section_index)%allowed_keywords)

         if (trim(this%sections(section_index)%allowed_keywords(i)) == trim(standardized_keyword_name)) then

            if (i <= size(this%sections(section_index)%keyword_defaults)) then

               if (.not. is_empty(this%sections(section_index)%keyword_defaults(i))) then
                  default_value = trim(adjustl(this%sections(section_index)%keyword_defaults(i)))
                  has_default = .true.
               end if

            end if

            return

         end if

      end do

   end subroutine get_keyword_default


   subroutine get_added_sections(this, section_names)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Sara Angelico, Alexander C. Paul and Leo Stoll, 2019-2026
      !!
      !! Return all registered section names.
      !!
      implicit none

      class(input_specification), intent(in) :: this
      character(len=200), dimension(:), allocatable, intent(out) :: section_names

      integer :: i

      if (.not. this%has_sections()) then
         allocate(section_names(0))
         return
      end if

      allocate(section_names(size(this%sections)))
      do i = 1, size(this%sections)
         section_names(i) = this%sections(i)%section_name
      end do

   end subroutine get_added_sections


   subroutine get_added_keywords_for_section(this, section_name, keywords, found)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Sara Angelico, Alexander C. Paul and Leo Stoll, 2019-2026
      !!
      !! Return all keywords for a section and whether section exists.
      !!
      implicit none

      class(input_specification), intent(in) :: this
      character(len=*), intent(in) :: section_name
      character(len=30), dimension(:), allocatable, intent(out) :: keywords
      logical, intent(out) :: found

      character(len=:), allocatable :: standardized_section_name
      integer :: section_index

      standardized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(standardized_section_name)

      section_index = this%get_section_index(standardized_section_name)
      found = section_index > 0
      if (.not. found) then
         allocate(keywords(0))
         return
      end if

      allocate(keywords(size(this%sections(section_index)%allowed_keywords)))
      keywords = this%sections(section_index)%allowed_keywords

   end subroutine get_added_keywords_for_section


   function has_sections(this) result(has_sections_registered)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Sara Angelico, Alexander C. Paul and Leo Stoll, 2019-2026
      !!
      !! Return true when at least one section has been registered.
      !!
      implicit none

      class(input_specification), intent(in) :: this
      logical :: has_sections_registered

      has_sections_registered = .false.
      if (.not. allocated(this%sections)) return
      has_sections_registered = size(this%sections) > 0

   end function has_sections


   function section_is_required(this, section_name) result(required)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Sara Angelico, Alexander C. Paul and Leo Stoll, 2019-2026
      !!
      !! Return true if the section is marked as required.
      !!
      implicit none

      class(input_specification), intent(in) :: this
      character(len=*), intent(in) :: section_name
      logical :: required

      character(len=:), allocatable :: standardized_section_name
      integer :: section_index

      required = .false.

      standardized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(standardized_section_name)

      section_index = this%get_section_index(standardized_section_name)
      if (section_index <= 0) return

      required = this%sections(section_index)%required

   end function section_is_required


   function get_section_index(this, section_name) result(index_)
      !!
      !! Written by Sara Angelico and Alexander C. Paul, Feb 2023
      !!
      !! Internal helper: get section index or 0 when absent.
      !!
      implicit none

      class(input_specification), intent(in) :: this
      character(len=*), intent(in) :: section_name
      integer :: index_
      integer :: i

      index_ = 0
      if (.not. allocated(this%sections)) return

      do i = 1, size(this%sections)
         if (trim(this%sections(i)%section_name) == trim(section_name)) then
            index_ = i
            return
         end if
      end do

   end function get_section_index


end module input_specification_class


! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module geometry_parser_class

   !!
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Tommaso Giovanini and Tor S. Haugland, 2019-2021; extracted 2026
   !!
   !! Geometry parser class - parses QM and MM geometry lines from input.
   !!

   use kinds
   use global_out, only: output
   use string_utilities, only: string_starts_with, first_index_of_substring
   use string_utilities, only: is_substring_in_string, remove_substring_after_symbol
   use string_utilities, only: convert_character_to_uppercase, last_index_of_substring

   implicit none

   private

   type, public :: geometry_parser

   contains

      procedure, public, nopass :: parse_qm_geometry
      procedure, public, nopass :: parse_mm_geometry_fq
      procedure, public, nopass :: parse_mm_geometry_non_polarizable
      procedure, public, nopass :: count_qm_atoms
      procedure, public, nopass :: count_mm_molecules

   end type geometry_parser


contains


   subroutine parse_qm_geometry(geometry_lines, &
                                n_atoms, &
                                symbols, &
                                positions, &
                                basis_sets, &
                                charge, &
                                units_angstrom, &
                                is_ghost)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad,
      !! Asmund H. Tveten and Tor S. Haugland, 2019-2021
      !!
      !! Parses QM geometry from geometry lines.
      !!
      implicit none

      character(len=200), dimension(:), intent(in) :: geometry_lines

      integer, intent(in) :: n_atoms

      character(len=2), dimension(n_atoms), intent(out) :: symbols
      character(len=100), dimension(n_atoms), intent(out) :: basis_sets
      logical, dimension(n_atoms), intent(out) :: is_ghost

      real(dp), dimension(3, n_atoms), intent(out) :: positions  ! x, y, z
      integer, dimension(n_atoms), intent(out) :: charge

      logical, intent(out) :: units_angstrom

      integer :: current_atom, i, n_qm_atom_lines
      integer :: start_
      character(len=200) :: string
      character(len=100) :: current_basis
      logical :: is_ghost_atom = .false.
      integer :: cursor

      n_qm_atom_lines = size(geometry_lines)
      start_ = 1  ! Specifies the line of the first and required basis

      ! Are units specified?
      ! Note that units can only be specified as the first line of the geometry

      units_angstrom = .true.  ! Default units are Angstrom
      charge = 0  ! Default charge is zero

      if (geometry_lines(1)(1:6) == 'units:') then

         string = (trim(adjustl(geometry_lines(1)(7:200))))

         if (string(1:4) == 'bohr') then

            units_angstrom = .false.

         elseif (string(1:8) /= 'angstrom') then

            call output%error_msg('units of atom coordinates must be either angstrom or bohr')

         end if

         start_ = 2

      end if


      ! Error if next line is not a basis set line

      if (geometry_lines(start_)(1:6) /= 'basis:') &
         call output%error_msg('did not find basis in geometry section.')

      current_atom = 0

      do i = start_, n_qm_atom_lines

         string = trim(adjustl(geometry_lines(i)))

         if (string(1:6) == 'units:') &
            call output%error_msg('Units must be specified as the first line in the geometry section.')

         if (string(1:6) == 'basis:') then

            current_basis = trim(adjustl(string(7:200)))
            current_basis = remove_substring_after_symbol(current_basis, "!")

         elseif (string(1:5) == 'ghost') then

            ! Every atom after 'ghost' keyword are ghosts
            is_ghost_atom = .true.

         else

            current_atom = current_atom + 1

            basis_sets(current_atom) = current_basis
            symbols(current_atom) = string(1:2)
            is_ghost(current_atom) = is_ghost_atom

            string = adjustl(string(3:200))

            if (is_substring_in_string(string, 'q')) then

               cursor = first_index_of_substring(string, 'q')
               read(string(1:cursor - 1), *) positions(:, current_atom)

               string = adjustl(string(cursor + 1:200))

               if (.not. string_starts_with(string, '=')) &
                  call output%error_msg('in assignment of charge to atom in the geometry')

               string = adjustl(string(2:200))
               read(string, *) charge(current_atom)

            else

               read(string(1:), *) positions(:, current_atom)

            end if

         end if

      end do

      ! First character of symbol should be upper case

      do i = 1, n_atoms

         symbols(i)(1:1) = convert_character_to_uppercase(symbols(i)(1:1))

      end do

   end subroutine parse_qm_geometry


   subroutine parse_mm_geometry_fq(geometry_lines, &
                                   n_atoms, &
                                   n_molecules, &
                                   n_atoms_per_molecule, &
                                   symbols, &
                                   positions, &
                                   chi, &
                                   eta)
      !!
      !! Written by Tommaso Giovanini and Sarai D. Folkestad, 2019-2020
      !!
      !! Parses MM geometry (fluctuating charges) from geometry lines.
      !!
      implicit none

      character(len=200), dimension(:), intent(in) :: geometry_lines

      integer, intent(in) :: n_atoms
      integer, intent(in) :: n_molecules

      character(len=2), dimension(n_atoms), intent(out) :: symbols
      real(dp), dimension(3, n_atoms), intent(out) :: positions
      real(dp), dimension(n_atoms), intent(out) :: chi
      real(dp), dimension(n_atoms), intent(out) :: eta
      integer, dimension(n_molecules), intent(out) :: n_atoms_per_molecule

      integer :: record, cursor, current_atom, i, current_molecule
      integer :: n_mm_atom_lines

      character(len=200) :: string, coordinate

      n_mm_atom_lines = size(geometry_lines)
      current_atom = 0
      current_molecule = 0
      n_atoms_per_molecule = 0
      cursor = 0

      do record = 1, n_mm_atom_lines

         current_atom = current_atom + 1
         string = trim(adjustl(geometry_lines(record)))

         ! Determine symbol

         symbols(current_atom) = string(1:2)
         string = adjustl(string(3:200))

         ! Determine molecule index

         if (is_substring_in_string(string, 'mol')) then

            cursor = last_index_of_substring(string, 'mol')

         else

            call output%error_msg('could not find mol in MM geometry')

         end if

         string = adjustl(string(cursor + 1:200))

         if (string(1:1) /= '=') call output%error_msg('in mol specification in MM geometry')
         string = adjustl(string(2:200))

         cursor = first_index_of_substring(string, ']')

         read(string(1:cursor - 1), *) current_molecule
         string = adjustl(string(cursor + 1:200))

         n_atoms_per_molecule(current_molecule) = n_atoms_per_molecule(current_molecule) + 1

         cursor = first_index_of_substring(string, '[')

         coordinate = string(1:cursor - 1)
         read(coordinate, *) positions(:, current_atom)

         string = adjustl(string(cursor + 1:200))

         ! Determine chi

         if (is_substring_in_string(string, 'chi')) then

            cursor = last_index_of_substring(string, 'chi')

         else

            call output%error_msg('could not find chi in MM geometry')

         end if

         string = adjustl(string(cursor + 1:200))

         if (string(1:1) /= '=') call output%error_msg('in chi specification in MM geometry')
         string = adjustl(string(2:200))

         cursor = first_index_of_substring(string, ',')
         read(string(1:cursor - 1), *) chi(current_atom)
         string = adjustl(string(cursor + 1:200))

         ! Determine eta

         if (is_substring_in_string(string, 'eta')) then

            cursor = last_index_of_substring(string, 'eta')

         else

            call output%error_msg('could not find eta in MM geometry')

         end if

         string = trim(adjustl(string(cursor + 1:200)))

         if (string(1:1) /= '=') call output%error_msg('in chi specification in MM geometry')
         string = adjustl(string(2:200))

         cursor = first_index_of_substring(string, ']')
         read(string(1:cursor - 1), *) eta(current_atom)

         if (abs(eta(current_atom)) < 1.0d-8) then

            call output%error_msg('You have put zero chemical hardness on atom: (i0)', &
                                  ints=[current_atom])

         end if

      end do

      ! First character of symbol should be upper case

      do i = 1, n_atoms

         symbols(i)(1:1) = convert_character_to_uppercase(symbols(i)(1:1))

      end do

   end subroutine parse_mm_geometry_fq


   subroutine parse_mm_geometry_non_polarizable(geometry_lines, &
                                                n_atoms, &
                                                symbols, &
                                                positions, &
                                                charge)
      !!
      !! Written by Tommaso Giovanini and Sarai D. Folkestad, 2019-2020
      !!
      !! Parses MM geometry (non-polarizable) from geometry lines.
      !!
      implicit none

      character(len=200), dimension(:), intent(in) :: geometry_lines

      integer, intent(in) :: n_atoms

      character(len=2), dimension(n_atoms), intent(out) :: symbols
      real(dp), dimension(3, n_atoms), intent(out) :: positions
      real(dp), dimension(n_atoms), intent(out) :: charge

      integer :: record, cursor, current_atom, i, current_molecule
      integer :: n_mm_atom_lines

      character(len=200) :: string, coordinate

      n_mm_atom_lines = size(geometry_lines)
      current_atom = 0
      current_molecule = 0
      cursor = 0

      do record = 1, n_mm_atom_lines

         current_atom = current_atom + 1
         string = trim(adjustl(geometry_lines(record)))

         ! Determine symbol

         symbols(current_atom) = string(1:2)
         string = adjustl(string(3:200))

         ! Determine molecule index

         if (is_substring_in_string(string, 'mol')) then

            cursor = last_index_of_substring(string, 'mol')

         else

            call output%error_msg('could not find mol in MM geometry')

         end if

         string = adjustl(string(cursor + 1:200))

         if (string(1:1) /= '=') call output%error_msg('in mol specification in MM geometry')
         string = adjustl(string(2:200))

         cursor = first_index_of_substring(string, ']')
         read(string(1:cursor - 1), *) current_molecule
         string = adjustl(string(cursor + 1:200))

         ! Determine position

         cursor = first_index_of_substring(string, '[')

         coordinate = string(1:cursor - 1)
         read(coordinate, *) positions(:, current_atom)

         string = adjustl(string(cursor + 1:200))

         ! Determine charge

         cursor = first_index_of_substring(string, 'q')
         string = adjustl(string(cursor + 1:200))

         if (string(1:1) /= '=') call output%error_msg('in charge specification in MM geometry')
         string = adjustl(string(2:200))

         cursor = first_index_of_substring(string, ']')
         read(string(1:cursor - 1), *) charge(current_atom)

         if (abs(charge(current_atom)) < 1.0d-8) then

            call output%warning_msg('You put zero charge on atom = (i0)', &
                                    ints=[current_atom], &
                                    fs='(t6,a)')

         end if

      end do

      ! First character of symbol should be upper case

      do i = 1, n_atoms

         symbols(i)(1:1) = convert_character_to_uppercase(symbols(i)(1:1))

      end do

   end subroutine parse_mm_geometry_non_polarizable


   function count_qm_atoms(geometry_lines) result(n_atoms)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Tommaso Giovanini and Tor S. Haugland, 2019-2021; extracted 2026
      !!
      !! Counts QM atoms in geometry lines, excluding basis:, units:, and ghost lines.
      !!
      implicit none

      character(len=200), dimension(:), intent(in) :: geometry_lines

      integer :: n_atoms

      integer :: record, n_qm_atom_lines

      n_qm_atom_lines = size(geometry_lines)
      n_atoms = 0

      do record = 1, n_qm_atom_lines

         if (geometry_lines(record)(1:6) /= 'basis:' .and. (geometry_lines(record)(1:6) /= 'units:') .and. &
             (geometry_lines(record)(1:5) /= 'ghost')) &
            n_atoms = n_atoms + 1

      end do

   end function count_qm_atoms


   function count_mm_molecules(geometry_lines) result(n_molecules)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Tommaso Giovanini and Tor S. Haugland, 2019-2021; extracted 2026
      !!
      !! Counts MM molecules from geometry lines by parsing mol=[...] entries.
      !!
      implicit none

      character(len=200), dimension(:), intent(in) :: geometry_lines

      integer :: n_molecules

      integer :: cursor, record, current_molecule, previous_molecule

      character(len=200) :: string, imolecule
      integer :: n_mm_atom_lines

      n_mm_atom_lines = size(geometry_lines)
      previous_molecule = 1
      n_molecules = 1

      do record = 1, n_mm_atom_lines

         string = (trim(adjustl(geometry_lines(record))))
         cursor = first_index_of_substring(string, '=')

         string = string(cursor + 1:200)

         cursor = first_index_of_substring(string, ']')

         imolecule = string(1:cursor - 1)
         read(imolecule, '(i4)') current_molecule

         if (record == 1 .and. current_molecule /= 1) call output%error_msg('Molecule 1 is missing!')

         if (current_molecule == previous_molecule + 1) then

            n_molecules = n_molecules + 1

         elseif (current_molecule /= previous_molecule .and. current_molecule /= previous_molecule + 1) then

            call output%error_msg( &
                    'Molecule (i0) missing even though (i0) should be present in QM/MM calculation.', &
                    ints=[previous_molecule + 1, n_molecules] &
                 )

         end if

         previous_molecule = current_molecule

      end do

   end function count_mm_molecules


end module geometry_parser_class

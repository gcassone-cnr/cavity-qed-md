

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module et_config_class

   !!
   !! Written by Eirik F. Kjoenstad, 2026
   !!
   !! eT config class module
   !!
   !! Stores the actual settings (config) for the eT calculation. These settings either come from:
   !!
   !!    1. Parsed input file (eT.inp, standard route)
   !!    2. User that uses the config object to set geometry/keyword-value pairs (non-standard but used for scripting and unit tests).
   !!
   !! The class also validates the settings against the defined input specification of eT (i.e. allowed sections/keywords and their value-types).
   !!
   !!

   use kinds, only: dp
   use string_utilities, only: convert_to_lowercase, is_empty, n_instances_of_character, split_at_delimiter
   use global_out, only: output
   use input_specification_class, only: input_specification
   use keyword_value_types_module, only: KV_BOOL, KV_NONE, KV_INT_POSITIVE, KV_INT_NONNEGATIVE, &
      KV_REAL_POSITIVE, KV_REAL_NONNEGATIVE, KV_REAL

   implicit none

   private

   type, public :: et_config_entry

      character(len=:), allocatable :: section_name
      character(len=:), allocatable :: keyword_name
      character(len=:), allocatable :: keyword_value

   end type et_config_entry


   type, public :: et_config

      type(input_specification), pointer, private :: input_spec => null()
      type(et_config_entry), dimension(:), allocatable, private :: entries
      character(len=200), dimension(:), allocatable, private :: qm_geometry
      character(len=200), dimension(:), allocatable, private :: mm_geometry

   contains

      generic, public :: set => set_real_dp, set_integer, set_logical, set_string

      procedure, public :: set_string
      procedure, public :: set_string_from_file
      procedure, public :: set_real_dp
      procedure, public :: set_logical
      procedure, public :: set_integer
      procedure, public :: set_qm_geometry
      procedure, public :: set_mm_geometry

      procedure, public :: get_n_entries
      procedure, public :: get_entry
      procedure, public :: has_qm_geometry
      procedure, public :: has_mm_geometry
      procedure, public :: get_qm_geometry
      procedure, public :: get_mm_geometry
      procedure, public :: contains
      procedure, public :: get_string
      procedure, public :: get_keywords_in_section

      procedure, private :: set_normalized_value
      procedure, private :: set_normalized_value_from_file
      procedure, private :: get_entry_index
      procedure, private :: validate_section_keyword
      procedure, private :: validate_keyword_value
      procedure, private :: validate_real_or_real_array
      procedure, private :: validate_real_array
      procedure, private :: validate_real
      procedure, private, nopass :: is_valid_bool
      procedure, private, nopass :: report_invalid_keyword_string_value
      procedure, private, nopass :: report_invalid_keyword_integer_value
      procedure, private, nopass :: report_invalid_keyword_real_value
      procedure, private, nopass :: report_invalid_keyword_bool_value
      procedure, private :: print_added_sections
      procedure, private :: print_added_keywords

   end type et_config


   interface et_config

      procedure :: new_et_config
      procedure :: new_et_config_with_input_spec

   end interface et_config

contains


   function new_et_config() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Constructor without input specification (validation will error if input specification is not set).
      !!
      implicit none

      type(et_config) :: this

      allocate(this%entries(0))

   end function new_et_config


   function new_et_config_with_input_spec(input_spec) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      implicit none

      type(input_specification), pointer, intent(in) :: input_spec
      type(et_config) :: this

      allocate(this%entries(0))
      this%input_spec => input_spec

   end function new_et_config_with_input_spec


   subroutine set_qm_geometry(this, qm_geometry_lines)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Set QM geometry lines
      !!
      implicit none

      class(et_config), intent(inout) :: this
      character(len=200), dimension(:), intent(in) :: qm_geometry_lines

      this%qm_geometry = qm_geometry_lines

   end subroutine set_qm_geometry


   subroutine set_mm_geometry(this, mm_geometry_lines)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Set MM geometry lines
      !!
      implicit none

      class(et_config), intent(inout) :: this
      character(len=200), dimension(:), intent(in) :: mm_geometry_lines

      this%mm_geometry = mm_geometry_lines

   end subroutine set_mm_geometry


   subroutine set_string(this, section_name, keyword_name, keyword_value)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Set string-valued keyword in section
      !!
      implicit none

      class(et_config), intent(inout) :: this

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: keyword_value

      character(len=:), allocatable :: normalized_value

      normalized_value = trim(adjustl(keyword_value))
      call convert_to_lowercase(normalized_value)

      call this%set_normalized_value(section_name, keyword_name, normalized_value)

   end subroutine set_string


   subroutine set_string_from_file(this, section_name, keyword_name, keyword_value)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Set string-valued keyword from file parsing. Errors if section and keyword
      !! already exists (duplicate keyword in input file).
      !!
      implicit none

      class(et_config), intent(inout) :: this

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: keyword_value

      character(len=:), allocatable :: normalized_value

      normalized_value = trim(adjustl(keyword_value))
      call convert_to_lowercase(normalized_value)

      call this%set_normalized_value_from_file(section_name, keyword_name, normalized_value)

   end subroutine set_string_from_file


   subroutine set_integer(this, section_name, keyword_name, keyword_value)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Set default-kind integer-valued keyword in section
      !!
      implicit none

      class(et_config), intent(inout) :: this

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      integer, intent(in) :: keyword_value

      character(len=200) :: value_string

      write(value_string, '(i0)') keyword_value

      call this%set_normalized_value(section_name, keyword_name, trim(adjustl(value_string)))

   end subroutine set_integer


   subroutine set_real_dp(this, section_name, keyword_name, keyword_value)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Set real(dp)-valued keyword in section
      !!
      implicit none

      class(et_config), intent(inout) :: this

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      real(dp), intent(in) :: keyword_value

      character(len=200) :: value_string
      character(len=:), allocatable :: normalized_value

      write(value_string, '(es24.16)') keyword_value

      normalized_value = trim(adjustl(value_string))
      call convert_to_lowercase(normalized_value)

      call this%set_normalized_value(section_name, keyword_name, normalized_value)

   end subroutine set_real_dp


   subroutine set_logical(this, section_name, keyword_name, keyword_value)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Set logical-valued keyword in section
      !!
      implicit none

      class(et_config), intent(inout) :: this

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      logical, intent(in) :: keyword_value

      character(len=:), allocatable :: normalized_value

      if (keyword_value) then

         normalized_value = '.true.'

      else

         normalized_value = '.false.'

      end if

      call this%set_normalized_value(section_name, keyword_name, normalized_value)

   end subroutine set_logical


   function get_n_entries(this) result(n_entries)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Get number of section/keyword/value entries
      !!
      implicit none

      class(et_config), intent(in) :: this
      integer :: n_entries

      if (allocated(this%entries)) then

         n_entries = size(this%entries)

      else

         n_entries = 0

      end if


   end function get_n_entries


   function has_qm_geometry(this) result(has_geometry)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Check if QM geometry lines were set
      !!
      implicit none

      class(et_config), intent(in) :: this
      logical :: has_geometry

      has_geometry = allocated(this%qm_geometry)

   end function has_qm_geometry


   function has_mm_geometry(this) result(has_geometry)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Check if MM geometry lines were set
      !!
      implicit none

      class(et_config), intent(in) :: this
      logical :: has_geometry

      has_geometry = allocated(this%mm_geometry)

   end function has_mm_geometry


   subroutine get_qm_geometry(this, qm_geometry_lines)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Get QM geometry lines; errors if QM geometry is absent
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=200), dimension(:), allocatable, intent(out) :: qm_geometry_lines

      if (allocated(this%qm_geometry)) then

         allocate(qm_geometry_lines, source = this%qm_geometry)

      else

         call output%error_msg('Requested QM geometry from et_config, but none was set.')

      end if

   end subroutine get_qm_geometry


   subroutine get_mm_geometry(this, mm_geometry_lines)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Get MM geometry lines; errors if MM geometry is absent
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=200), dimension(:), allocatable, intent(out) :: mm_geometry_lines

      if (allocated(this%mm_geometry)) then

         allocate(mm_geometry_lines, source = this%mm_geometry)

      else

         call output%error_msg('Requested MM geometry from et_config, but none was set.')

      end if

   end subroutine get_mm_geometry


   function contains(this, section_name, keyword_name) result(is_present)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Check if section and keyword exists in config
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name

      logical :: is_present
      character(len=:), allocatable :: normalized_section_name
      character(len=:), allocatable :: normalized_keyword_name

      normalized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(normalized_section_name)

      normalized_keyword_name = trim(adjustl(keyword_name))
      call convert_to_lowercase(normalized_keyword_name)

      is_present = this%get_entry_index(normalized_section_name, normalized_keyword_name) > 0

   end function contains


   subroutine get_string(this, section_name, keyword_name, keyword_value, found)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Get normalized string value from config
      !! Returns found=.false. if key is absent; does not raise an error.
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(out) :: keyword_value
      logical, intent(out) :: found

      character(len=:), allocatable :: normalized_section_name
      character(len=:), allocatable :: normalized_keyword_name
      integer :: entry_index

      keyword_value = ''
      found = .false.

      normalized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(normalized_section_name)

      normalized_keyword_name = trim(adjustl(keyword_name))
      call convert_to_lowercase(normalized_keyword_name)

      entry_index = this%get_entry_index(normalized_section_name, normalized_keyword_name)
      if (entry_index <= 0) return

      keyword_value = this%entries(entry_index)%keyword_value
      found = .true.

   end subroutine get_string


   subroutine get_keywords_in_section(this, section_name, keywords)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Get all configured keyword names for one section
      !! Only returns keys that are currently set in this config object.
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=*), intent(in) :: section_name
      character(len=200), dimension(:), allocatable, intent(out) :: keywords

      character(len=:), allocatable :: normalized_section_name
      integer :: i
      integer :: n_keywords

      normalized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(normalized_section_name)

      n_keywords = 0

      if (allocated(this%entries)) then

         do i = 1, size(this%entries)

            if (trim(this%entries(i)%section_name) == trim(normalized_section_name)) &
               n_keywords = n_keywords + 1

         end do

      end if

      allocate(keywords(n_keywords))

      n_keywords = 0

      if (allocated(this%entries)) then

         do i = 1, size(this%entries)

            if (trim(this%entries(i)%section_name) /= trim(normalized_section_name)) cycle
            n_keywords = n_keywords + 1
            keywords(n_keywords) = this%entries(i)%keyword_name

         end do

      end if

   end subroutine get_keywords_in_section


   function get_entry(this, index_) result(entry)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Get single section/keyword/value entry by index
      !!
      implicit none

      class(et_config), intent(in) :: this
      integer, intent(in) :: index_

      type(et_config_entry) :: entry

      entry = this%entries(index_)

   end function get_entry


   subroutine set_normalized_value(this, section_name, keyword_name, keyword_value_string)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Insert/update section and keyword pair (overwrite semantics)
      !! Validation is enforced against input_specification_class.
      !!
      implicit none

      class(et_config), intent(inout) :: this

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: keyword_value_string

      character(len=:), allocatable :: normalized_section_name
      character(len=:), allocatable :: normalized_keyword_name

      integer :: entry_index
      integer :: n_entries

      type(et_config_entry), dimension(:), allocatable :: new_entries

      normalized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(normalized_section_name)

      normalized_keyword_name = trim(adjustl(keyword_name))
      call convert_to_lowercase(normalized_keyword_name)

      call this%validate_section_keyword(normalized_section_name, normalized_keyword_name)

      if (.not. is_empty(keyword_value_string)) then

         call this%validate_keyword_value(normalized_section_name, &
                                          normalized_keyword_name, &
                                          trim(adjustl(keyword_value_string)))

      end if

      entry_index = this%get_entry_index(normalized_section_name, normalized_keyword_name)

      if (entry_index > 0) then

         this%entries(entry_index)%keyword_value = trim(adjustl(keyword_value_string))
         return

      end if

      if (.not. allocated(this%entries)) allocate(this%entries(0))


      n_entries = this%get_n_entries()

      allocate(new_entries(n_entries + 1))

      if (n_entries > 0) new_entries(1:n_entries) = this%entries

      new_entries(n_entries + 1)%section_name = normalized_section_name
      new_entries(n_entries + 1)%keyword_name = normalized_keyword_name
      new_entries(n_entries + 1)%keyword_value = trim(adjustl(keyword_value_string))

      call move_alloc(new_entries, this%entries)

   end subroutine set_normalized_value


   subroutine set_normalized_value_from_file(this, section_name, keyword_name, keyword_value_string)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Insert section and keyword pair from file parsing. Errors if section and keyword
      !! already exists (duplicate keyword in input file).
      !!
      implicit none

      class(et_config), intent(inout) :: this

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: keyword_value_string

      character(len=:), allocatable :: normalized_section_name
      character(len=:), allocatable :: normalized_keyword_name

      integer :: entry_index
      integer :: n_entries

      type(et_config_entry), dimension(:), allocatable :: new_entries

      normalized_section_name = trim(adjustl(section_name))
      call convert_to_lowercase(normalized_section_name)

      normalized_keyword_name = trim(adjustl(keyword_name))
      call convert_to_lowercase(normalized_keyword_name)

      call this%validate_section_keyword(normalized_section_name, normalized_keyword_name)

      if (.not. is_empty(keyword_value_string)) then

         call this%validate_keyword_value(normalized_section_name, &
                                          normalized_keyword_name, &
                                          trim(adjustl(keyword_value_string)))

      end if

      entry_index = this%get_entry_index(normalized_section_name, normalized_keyword_name)

      if (entry_index > 0) then

         call output%printf('m', &
                            'Found duplicate keyword "' // trim(normalized_keyword_name) // &
                               '" in the section "' // trim(normalized_section_name) // '".', &
                            fs='(/t3,a)')

         call output%error_msg('Something is wrong in the input file.')

      end if

      if (.not. allocated(this%entries)) allocate(this%entries(0))

      n_entries = this%get_n_entries()

      allocate(new_entries(n_entries + 1))

      if (n_entries > 0) new_entries(1:n_entries) = this%entries

      new_entries(n_entries + 1)%section_name = normalized_section_name
      new_entries(n_entries + 1)%keyword_name = normalized_keyword_name
      new_entries(n_entries + 1)%keyword_value = trim(adjustl(keyword_value_string))

      call move_alloc(new_entries, this%entries)

   end subroutine set_normalized_value_from_file


   subroutine validate_section_keyword(this, section_name, keyword_name)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Check section/keyword against registered input specification and error out with
      !! user-oriented diagnostics (including valid alternatives) if invalid.
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name

      logical :: section_found

      section_found = .false.

      if (.not. associated(this%input_spec)) then

         call output%error_msg('No config keyword input specification has been registered. ' // &
            'Initialize input_tool() before setting config keywords.')

      end if

      if (.not. this%input_spec%has_sections()) then

         call output%error_msg('No config keyword input specification has been registered. ' // &
            'Initialize input_tool() before setting config keywords.')

      end if

      if (.not. this%input_spec%is_section_added(section_name)) then

         call output%printf('m', &
                            'Could not recognize section named "(a0)".', &
                            chars=[trim(section_name)], &
                            fs='(/t3,a)')

         call this%print_added_sections()
         call output%error_msg('Something is wrong in the config.')

      end if

      if (.not. this%input_spec%is_keyword_added(section_name, keyword_name)) then

         call output%printf('m', &
                            'Could not recognize keyword "' // trim(keyword_name) // '" in section "' // &
                               trim(section_name) // '".', &
                            fs='(/t3,a)')

         call this%print_added_keywords(section_name, section_found)
         call output%error_msg('Something is wrong in the config.')

      end if

   end subroutine validate_section_keyword


   function is_valid_bool(value_string) result(valid)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Return true if value_string is a valid boolean: .true., .false., true, false, yes, no.
      !!
      implicit none

      character(len=*), intent(in) :: value_string
      logical :: valid

      character(len=:), allocatable :: s

      s = trim(adjustl(value_string))
      call convert_to_lowercase(s)

      valid = &
         (s == '.true.' .or. s == '.false.' .or. s == 'true' .or. s == 'false' .or. s == 'yes' .or. &
         s == 'no')

   end function is_valid_bool


   subroutine report_invalid_keyword_string_value(section_name, keyword_name, type_description, value_string)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Report invalid keyword value where the offending value is printed as string.
      !!
      implicit none

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: type_description
      character(len=*), intent(in) :: value_string

      call output%printf('m', &
                         'Keyword "' // trim(keyword_name) // '" in section "' // trim(section_name) // &
                            '" must be a ' // trim(type_description) // ', but got: "(a0)".', &
                         chars=[trim(value_string)], &
                         fs='(/t3,a)')

      call output%error_msg('Invalid value for keyword.')

   end subroutine report_invalid_keyword_string_value


   subroutine report_invalid_keyword_integer_value(section_name, keyword_name, type_description, int_val)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Report invalid keyword value where the offending value is printed as integer.
      !!
      implicit none

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: type_description
      integer, intent(in) :: int_val

      call output%printf('m', &
                         'Keyword "' // trim(keyword_name) // '" in section "' // trim(section_name) // &
                            '" must be a ' // trim(type_description) // ', but got: (i0).', &
                         ints=[int_val], &
                         fs='(/t3,a)')

      call output%error_msg('Invalid value for keyword.')

   end subroutine report_invalid_keyword_integer_value


   subroutine report_invalid_keyword_real_value(section_name, keyword_name, type_description, real_val)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Report invalid keyword value where the offending value is printed as real.
      !!
      implicit none

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: type_description
      real(dp), intent(in) :: real_val

      call output%printf('m', &
                         'Keyword "' // trim(keyword_name) // '" in section "' // trim(section_name) // &
                            '" must be a ' // trim(type_description) // ', but got: (es24.16).', &
                         reals=[real_val], &
                         fs='(/t3,a)')

      call output%error_msg('Invalid value for keyword.')

   end subroutine report_invalid_keyword_real_value


   subroutine report_invalid_keyword_bool_value(section_name, keyword_name, value_string)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Report invalid keyword value for boolean keyword.
      !!
      implicit none

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: value_string

      call output%printf('m', &
                         'Keyword "' // trim(keyword_name) // '" in section "' // trim(section_name) // &
                            '" must be .true., .false., true, false, yes, or no; but got: "(a0)".', &
                         chars=[trim(value_string)], &
                         fs='(/t3,a)')

      call output%error_msg('Invalid value for keyword.')

   end subroutine report_invalid_keyword_bool_value


   subroutine validate_real_or_real_array(this, &
                                          value_string, &
                                          section_name, &
                                          keyword_name, &
                                          type_description, &
                                          require_positive, &
                                          require_nonnegative)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Validate value_string as either a single real or array of reals in { } notation.
      !! Used for KV_REAL, KV_REAL_POSITIVE, KV_REAL_NONNEGATIVE.
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=*), intent(in) :: value_string
      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: type_description
      logical, intent(in) :: require_positive
      logical, intent(in) :: require_nonnegative

      if (len_trim(value_string) >= 2 .and. value_string(1:1) == '{') then

         call this%validate_real_array(value_string, &
                                       section_name, &
                                       keyword_name, &
                                       type_description, &
                                       require_positive, &
                                       require_nonnegative)

      else

         call this%validate_real(value_string, &
                                 section_name, &
                                 keyword_name, &
                                 type_description, &
                                 require_positive, &
                                 require_nonnegative)

      end if

   end subroutine validate_real_or_real_array


   subroutine validate_real_array(this, &
                                  value_string, &
                                  section_name, &
                                  keyword_name, &
                                  type_description, &
                                  require_positive, &
                                  require_nonnegative)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Validate value_string as an array of reals in { } notation.
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=*), intent(in) :: value_string
      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: type_description
      logical, intent(in) :: require_positive
      logical, intent(in) :: require_nonnegative

      integer, parameter :: max_elements = 100
      character(len=200), dimension(max_elements) :: parts
      character(len=200) :: elem_str
      character(len=:), allocatable :: inner
      integer :: n_commas, n_elements, i, ierr
      real(dp) :: real_val

      inner = trim(adjustl(value_string(2:len_trim(value_string) - 1)))
      n_commas = n_instances_of_character(inner, ',')
      n_elements = n_commas + 1

      if (n_elements > max_elements) then

         call output%printf('m', &
                            'Keyword "' // trim(keyword_name) // '" in section "' // trim(section_name) // &
                               '" has too many array elements.', &
                            fs='(/t3,a)')

         call output%error_msg('Invalid value for keyword. ')

      end if

      call split_at_delimiter(inner, n_commas, parts(1:n_elements), ',')

      do i = 1, n_elements

         elem_str = trim(adjustl(parts(i)))
         read(elem_str, *, iostat = ierr) real_val

         if (ierr /= 0) then

            call this%report_invalid_keyword_string_value(section_name, &
                                                          keyword_name, &
                                                          type_description, &
                                                          value_string)

         end if

         if (require_positive .and. real_val <= 0.0_dp) then

            call this%report_invalid_keyword_real_value(section_name, &
                                                        keyword_name, &
                                                        type_description, &
                                                        real_val)

         end if

         if (require_nonnegative .and. real_val < 0.0_dp) then

            call this%report_invalid_keyword_real_value(section_name, &
                                                        keyword_name, &
                                                        type_description, &
                                                        real_val)

         end if

      end do

   end subroutine validate_real_array


   subroutine validate_real(this, &
                            value_string, &
                            section_name, &
                            keyword_name, &
                            type_description, &
                            require_positive, &
                            require_nonnegative)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Validate value_string as a single real.
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=*), intent(in) :: value_string
      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: type_description
      logical, intent(in) :: require_positive
      logical, intent(in) :: require_nonnegative

      character(len=200) :: elem_str
      integer :: ierr
      real(dp) :: real_val

      elem_str = trim(adjustl(value_string))
      read(elem_str, *, iostat = ierr) real_val

      if (ierr /= 0) then

         call this%report_invalid_keyword_string_value(section_name, &
                                                       keyword_name, &
                                                       type_description, &
                                                       value_string)

      end if

      if (require_positive .and. real_val <= 0.0_dp) then

         call this%report_invalid_keyword_real_value(section_name, &
                                                     keyword_name, &
                                                     type_description, &
                                                     real_val)

      end if

      if (require_nonnegative .and. real_val < 0.0_dp) then

         call this%report_invalid_keyword_real_value(section_name, &
                                                     keyword_name, &
                                                     type_description, &
                                                     real_val)

      end if

   end subroutine validate_real


   subroutine validate_keyword_value(this, section_name, keyword_name, value_string)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Validate value string against input specification value type (e.g. positive integer).
      !! Errors out with user-oriented message if invalid.
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name
      character(len=*), intent(in) :: value_string

      integer :: value_type
      integer :: ierr
      integer :: int_val

      if (.not. associated(this%input_spec)) return
      if (.not. this%input_spec%has_sections()) return

      value_type = this%input_spec%get_keyword_value_type(section_name, keyword_name)
      if (value_type == KV_NONE) return

      select case (value_type)

         case (KV_INT_POSITIVE)
            read(value_string, *, iostat = ierr) int_val

            if (ierr /= 0) then

               call this%report_invalid_keyword_string_value(section_name, &
                                                             keyword_name, &
                                                             'positive integer', &
                                                             value_string)

            end if

            if (int_val <= 0) then

               call this%report_invalid_keyword_integer_value(section_name, &
                                                              keyword_name, &
                                                              'positive integer', &
                                                              int_val)

            end if

         case (KV_INT_NONNEGATIVE)
            read(value_string, *, iostat = ierr) int_val

            if (ierr /= 0) then

               call this%report_invalid_keyword_string_value(section_name, &
                                                             keyword_name, &
                                                             'nonnegative integer', &
                                                             value_string)

            end if

            if (int_val < 0) then

               call this%report_invalid_keyword_integer_value(section_name, &
                                                              keyword_name, &
                                                              'nonnegative integer', &
                                                              int_val)

            end if

         case (KV_REAL)

            call this%validate_real_or_real_array(value_string, &
                                                  section_name, &
                                                  keyword_name, &
                                                  'real number', &
                                                  require_positive=.false., &
                                                  require_nonnegative=.false.)

         case (KV_REAL_POSITIVE)

            call this%validate_real_or_real_array(value_string, &
                                                  section_name, &
                                                  keyword_name, &
                                                  'positive real number', &
                                                  require_positive=.true., &
                                                  require_nonnegative=.false.)

         case (KV_REAL_NONNEGATIVE)

            call this%validate_real_or_real_array(value_string, &
                                                  section_name, &
                                                  keyword_name, &
                                                  'nonnegative real number', &
                                                  require_positive=.false., &
                                                  require_nonnegative=.true.)

         case (KV_BOOL)
            if (.not. this%is_valid_bool(value_string)) then
               call this%report_invalid_keyword_bool_value(section_name, keyword_name, value_string)
            end if

      end select

   end subroutine validate_keyword_value


   subroutine print_added_sections(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Print all known section names from the input specification.
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=200), dimension(:), allocatable :: section_names
      integer :: i

      if (.not. associated(this%input_spec)) return

      call this%input_spec%get_added_sections(section_names)

      call output%printf('m', 'The valid input sections are:', fs='(/t3,a/)')

      do i = 1, size(section_names)

         call output%printf('m', '(a0)', chars=[trim(section_names(i))], fs='(t6,a)')

      end do

   end subroutine print_added_sections


   subroutine print_added_keywords(this, section_name, section_found)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Print all known keywords for one section from the input specification.
      !! section_found is returned so caller can avoid duplicate lookups.
      !!
      implicit none

      class(et_config), intent(in) :: this
      character(len=*), intent(in) :: section_name
      logical, intent(out) :: section_found

      character(len=30), dimension(:), allocatable :: keywords
      integer :: i

      section_found = .false.
      if (.not. associated(this%input_spec)) return

      call this%input_spec%get_added_keywords_for_section(section_name, keywords, section_found)
      if (.not. section_found) return

      call output%printf('m', &
                         'The valid keywords in the section named "' // trim(section_name) // '" are:', &
                         fs='(/t3,a/)')

      do i = 1, size(keywords)

         call output%printf('m', '(a0)', chars=[trim(keywords(i))], fs='(t6,a)')

      end do

   end subroutine print_added_keywords


   function get_entry_index(this, section_name, keyword_name) result(index_)
      !!
      !! Written by Eirik F. Kjoenstad, 2026
      !!
      !! Get index of section and keyword pair, or zero if absent
      !!
      implicit none

      class(et_config), intent(in) :: this

      character(len=*), intent(in) :: section_name
      character(len=*), intent(in) :: keyword_name

      integer :: index_
      integer :: i

      index_ = 0

      if (.not. allocated(this%entries)) return

      do i = 1, size(this%entries)

         if (trim(this%entries(i)%section_name) == trim(section_name) .and. &
             trim(this%entries(i)%keyword_name) == trim(keyword_name)) then

            index_ = i
            return

         end if

      end do

   end function get_entry_index


end module et_config_class

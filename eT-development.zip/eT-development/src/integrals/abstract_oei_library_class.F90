

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_oei_library_class

   !!
   !! Abstract one electron integral library class
   !! Written by Marcus T. Lexander 2022
   !!
   !! This class contains functions to get oei-shells and full matrices.
   !! OEI libraries should be implemented to extend this one so that it will slot nicely in to be used in the AO-tool class
   !!

   use parameters
   use global_out, only: output
   use memory_manager_class, only: mem
   use range_class, only: range_
   use atomic_center_class, only: atomic_center

   implicit none

   type, abstract :: abstract_oei_library

      real(dp) :: oei_precision

      type(range_), dimension(:), pointer :: shells
      integer, dimension(:), pointer :: shell_to_center
      real(dp), dimension(:, :), allocatable :: shp_max_overlap

      integer :: n_ao, n_sh, max_sh_size, n_centers

   contains

      procedure, public :: get_oei => get_oei_abstract_oei_library

      procedure, public :: get_oei_1der => get_oei_1der_abstract_oei_library

      procedure, nopass, public :: get_n_oei_components => get_n_oei_components_abstract_oei_library

      procedure, public :: initialize => initialize_abstract_oei_library

      procedure, public :: get_oei_precision
      procedure, public :: set_oei_precision

      procedure, public :: cleanup
      procedure(update_centers), deferred, public :: update_centers

      procedure(get_oei_shell), deferred, public :: get_oei_shell
      procedure(get_oei_1der_shell), deferred, public :: get_oei_1der_shell

      procedure(initialize_external_charges_from_point_charges), deferred, public :: &
         initialize_external_charges_from_point_charges
      procedure(initialize_external_charges), deferred, public :: initialize_external_charges
      procedure(initialize_external_unit_charges), deferred, public :: initialize_external_unit_charges

      procedure, private :: construct_oei
      procedure, private :: construct_oei_screened
      procedure, public :: shp_on_same_atom
      procedure :: construct_shp_max_overlap

      procedure, private :: construct_coordinate_independent_oei_1der => &
                            construct_coordinate_independent_oei_1der_abstract_oei_library
      procedure, private :: construct_oei_nuclear_1der => construct_oei_nuclear_1der_abstract_oei_library
      procedure, private :: construct_oei_dipole_1der => construct_oei_dipole_1der_abstract_oei_library


   end type

   abstract interface

      subroutine update_centers(this, centers, n_centers)

         import abstract_oei_library, atomic_center

         implicit none

         class(abstract_oei_library), intent(inout) :: this

         integer, intent(in) :: n_centers

         type(atomic_center), dimension(n_centers), intent(in) :: centers

      end subroutine update_centers


      subroutine get_oei_shell(this, oei_type, oei, A, B)

         import abstract_oei_library, dp

         implicit none

         class(abstract_oei_library), intent(inout) :: this

         character(len=*), intent(in) :: oei_type

         real(dp), dimension(:), intent(out), target :: oei

         integer, intent(in) :: A, B

      end subroutine get_oei_shell


      subroutine get_oei_1der_shell(this, oei_type, oei, A, B)

         import abstract_oei_library, dp

         implicit none

         class(abstract_oei_library), intent(inout) :: this

         character(len=*), intent(in) :: oei_type

         real(dp), dimension(:), intent(out), target :: oei

         integer, intent(in) :: A, B

      end subroutine get_oei_1der_shell


      subroutine get_oei_1der(this, oei_type, oei)

         import abstract_oei_library
         import dp

         implicit none

         class(abstract_oei_library), intent(in) :: this

         character(len=*), intent(in) :: oei_type

         real(dp), dimension(*), intent(out), target :: oei

      end subroutine get_oei_1der


      subroutine initialize_external_charges_from_point_charges(this, pc)

         use point_charges_class, only: point_charges

         import abstract_oei_library
         import dp

         implicit none

         class(abstract_oei_library), intent(inout) :: this
         type(point_charges), intent(in) :: pc

      end subroutine initialize_external_charges_from_point_charges


      subroutine initialize_external_charges(this, n_charges, positions, charges)

         import abstract_oei_library
         import dp

         implicit none

         class(abstract_oei_library), intent(inout) :: this
         integer, intent(in) :: n_charges
         real(dp), dimension(3, n_charges), intent(in) :: positions
         real(dp), dimension(n_charges), intent(in) :: charges

      end subroutine initialize_external_charges


      subroutine initialize_external_unit_charges(this, n_charges, positions)

         import abstract_oei_library
         import dp

         implicit none

         class(abstract_oei_library), intent(inout) :: this
         integer, intent(in) :: n_charges
         real(dp), dimension(3, n_charges), intent(in) :: positions

      end subroutine initialize_external_unit_charges

   end interface

contains


   subroutine get_oei_abstract_oei_library(this, oei_type, oei, screening)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !!
      !! Constructs one-electron integrals in the AO basis and places the result in 'oei'
      !!
      !!    oei:      integral array (n_ao x n_ao x n_components)
      !!    oei_type: which integral to calculate
      !!
      !! 'oei_type' can be:
      !!
      !!    - 'hamiltonian'  One-electron Hamiltonian (h)  n_components = 1
      !!    - 'overlap'      AO overlap (S)                n_components = 1
      !!    - 'dipole'       Dipole moment (mu)            n_components = 3 (mu_x, mu_y, mu_z)
      !!    - 'quadrupole'   Quadrupole moment (q)         n_components = 6 (q_xx, q_xy, q_xz,
      !!                                                                     q_yy, q_yz, q_zz)
      !!
      use timings_class, only: timings

      implicit none

      class(abstract_oei_library), intent(inout) :: this

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(*), intent(out) :: oei

      logical, intent(in), optional :: screening

      integer :: n_components

      type(timings), allocatable :: timer

      logical :: screening_local

      timer = timings('One-electron integrals (' // trim(oei_type) // ')', 'm')
      call timer%turn_on()

      screening_local = .false.
      if (present(screening)) screening_local = screening

      n_components = this%get_n_oei_components(oei_type, this%n_centers)

      if (screening_local) then

         call this%construct_oei_screened(trim(oei_type), oei, n_components)

      else

         call this%construct_oei(trim(oei_type), oei, n_components)

      end if

      call timer%turn_off()

   end subroutine get_oei_abstract_oei_library


   subroutine construct_oei(this, oei_type, x, n_components)
      !!
      !! Written by Eirik F. Kjoenstad, 2019
      !!
      !! Computes the one-electron AO integral matrix x using
      !! the C++ construction routine get_oei_c. This C++ routine constructs
      !! the x_ABk contributions to x for the shells A and B, where k
      !! denotes the components (e.g., x, y, z, for dipole integrals)
      !!
      !! Modified by EFK and SDF, 2020: generalized to any number of components.
      !!
      implicit none

      class(abstract_oei_library), intent(inout) :: this

      character(len=*), intent(in) :: oei_type

      integer, intent(in) :: n_components

      real(dp), dimension(this%n_ao, this%n_ao, n_components), intent(out) :: x

      integer :: w, y, k, w_f, y_f

      integer :: A, B

      real(dp), dimension(:, :, :), pointer :: x_ABk_p
      real(dp), dimension(this%max_sh_size**2 * n_components), target :: x_ABk

      !$omp parallel do private(A, B, x_ABk, x_ABk_p, w, y, w_f, y_f, k) schedule(dynamic)
      do A = 1, this%n_sh
         do B = 1, this%n_sh

            call this%get_oei_shell(oei_type, x_ABk, A, B)

            x_ABk_p(1:this%shells(A)%length, &
                    1:this%shells(B)%length, &
                    1:n_components) => x_ABk(1:this%shells(A)%length * this%shells(B)%length * n_components)

            do k = 1, n_components
               do w = 1, this%shells(A)%length
                  do y = 1, this%shells(B)%length

                     w_f = this%shells(A)%first - 1 + w
                     y_f = this%shells(B)%first - 1 + y

                     x(w_f, y_f, k) = x_ABk_p(w, y, k)

                  end do
               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine construct_oei


   subroutine construct_oei_screened(this, oei_type, x, n_components)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2021
      !!
      use array_initialization, only: zero_array

      implicit none

      class(abstract_oei_library), intent(inout) :: this

      integer, intent(in) :: n_components

      real(dp), dimension(this%n_ao, this%n_ao, n_components), intent(out) :: x

      character(len=*) :: oei_type

      integer :: w, y, k, w_f, y_f

      integer :: A, B, n_shp, AB

      real(dp) :: max_s

      real(dp), dimension(:, :, :), pointer :: x_ABk_p
      real(dp), dimension(this%max_sh_size**2 * n_components), target :: x_ABk

      integer, dimension(:, :), allocatable :: shp_list

      if (trim(oei_type) == 'overlap') call output%error_msg('cannot use overlap screening on overlap')

      call zero_array(x, this%n_ao**2 * n_components)

      ! Count the number of significant shell pairs

      call mem%alloc(shp_list, this%n_sh**2, 2)

      n_shp = 0

      do A = 1, this%n_sh
         do B = 1, this%n_sh

            if (this%shp_on_same_atom(A, B)) then

               n_shp = n_shp + 1
               shp_list(n_shp, 1) = A
               shp_list(n_shp, 2) = B

            else

               max_s = this%shp_max_overlap(A, B)

               if (max_s > this%oei_precision) then

                  n_shp = n_shp + 1
                  shp_list(n_shp, 1) = A
                  shp_list(n_shp, 2) = B

               end if

            end if

         end do
      end do

      !$omp parallel do private(AB, A, B, x_ABk, x_ABk_p, w, y, w_f, y_f, k) schedule(dynamic)
      do AB = 1, n_shp

         A = shp_list(AB, 1)
         B = shp_list(AB, 2)

         call this%get_oei_shell(oei_type, x_ABk, A, B)

         x_ABk_p(1:this%shells(A)%length, &
                 1:this%shells(B)%length, &
                 1:n_components) => x_ABk(1:this%shells(A)%length * this%shells(B)%length * n_components)

         do k = 1, n_components
            do w = 1, this%shells(A)%length
               do y = 1, this%shells(B)%length

                  w_f = this%shells(A)%first - 1 + w
                  y_f = this%shells(B)%first - 1 + y

                  x(w_f, y_f, k) = x_ABk_p(w, y, k)

               end do
            end do
         end do
      end do
      !$omp end parallel do

      call mem%dealloc(shp_list)

   end subroutine construct_oei_screened


   function get_n_oei_components_abstract_oei_library(oei_type, n_atoms) result(n_components)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Returns the number of one-electron integral components for the
      !! integral of type 'oei_type'.
      !!
      implicit none

      character(len=*), intent(in) :: oei_type

      integer, intent(in), optional :: n_atoms

      integer :: n_components

      if (trim(oei_type) == 'hamiltonian' .or. trim(oei_type) == 'nuclear' .or. &
          trim(oei_type) == 'kinetic' .or. trim(oei_type) == 'overlap' .or. &
          trim(oei_type) == 'electrostatic potential' .or. &
          trim(oei_type) == 'electrostatic potential unit') then

         n_components = 1

      elseif (trim(oei_type) == 'dipole' .or. trim(oei_type) == 'momentum' .or. &
              trim(oei_type) == 'angular momentum' .or. &
              trim(oei_type) == 'first-order derivative wrt B giao overlap' .or. &
              trim(oei_type) == 'first-order derivative wrt B giao angular momentum' .or. &
              trim(oei_type) == 'first-order derivative wrt B giao kinetic energy' .or. &
              trim(oei_type) == 'first-order derivative wrt B giao nuclear potential') then

         n_components = 3

      elseif (trim(oei_type) == 'quadrupole') then

         n_components = 6

      elseif (trim(oei_type) == 'giao paramagnetic spin-orbit') then

         n_components = 3 * n_atoms

      elseif (trim(oei_type) == 'first-order derivative wrt B giao paramagnetic spin-orbit' .or. &
              trim(oei_type) == 'giao diamagnetic') then

         n_components = 9 * n_atoms

      else

         n_components = 0

         call output%error_msg('Could not recognize one-electron integral (a0)', &
                               chars=[trim(oei_type)])

      end if

   end function get_n_oei_components_abstract_oei_library


   subroutine initialize_abstract_oei_library(this)
      !!
      !! Written by Sarai D. Folkestad, 2022
      !!
      implicit none

      class(abstract_oei_library), intent(inout) :: this

      if (.not. allocated(this%shp_max_overlap)) then
         call mem%alloc(this%shp_max_overlap, this%n_sh, this%n_sh)
         call this%construct_shp_max_overlap()
      end if

   end subroutine initialize_abstract_oei_library


   subroutine cleanup(this)
      !!
      !! Written by Sarai D. Folkestad, 2022
      !!
      implicit none

      class(abstract_oei_library), intent(inout) :: this

      if (allocated(this%shp_max_overlap)) call mem%dealloc(this%shp_max_overlap)

   end subroutine cleanup


   subroutine construct_shp_max_overlap(this)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2021-2022
      !!
      implicit none

      class(abstract_oei_library), intent(inout) :: this
      real(dp), dimension(:), allocatable :: s

      integer :: A, B

      call mem%alloc(s, this%max_sh_size**2)

      do A = 1, this%n_sh
         do B = 1, A

            call this%get_oei_shell('overlap', s, A, B)
            this%shp_max_overlap(A, B) = maxval(abs(s(1:this%shells(A)%length * this%shells(B)%length)))
            this%shp_max_overlap(B, A) = this%shp_max_overlap(A, B)

         end do
      end do

      call mem%dealloc(s)

   end subroutine construct_shp_max_overlap


   function shp_on_same_atom(this, A, B) result(on_same_atom)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Checks if shells A and B are on the same atom
      !!
      implicit none

      class(abstract_oei_library), intent(in) :: this
      integer, intent(in) :: A, B
      logical :: on_same_atom

      on_same_atom = (this%shell_to_center(A) == this%shell_to_center(B))

   end function shp_on_same_atom


   pure function get_oei_precision(this) result(oei_precision)
      !!
      !! Get oei precision
      !! Written by Alexander C. Paul, Dec 2022
      !!
      implicit none

      class(abstract_oei_library), intent(in) :: this
      real(dp) :: oei_precision

      oei_precision = this%oei_precision

   end function get_oei_precision


   subroutine set_oei_precision(this, oei_precision)
      !!
      !! Written by Alexander C. Paul, Dec 2022
      !!
      implicit none

      class(abstract_oei_library), intent(inout) :: this
      real(dp), intent(in) :: oei_precision

      this%oei_precision = oei_precision

   end subroutine set_oei_precision


   subroutine get_oei_1der_abstract_oei_library(this, oei_type, oei)
      !!
      !! Written by Andrea Bianchi, 2022
      !!
      !! Constructs first derivative of one-electron integrals in the AO basis and places
      !! the rersult in 'oei'.
      !!
      !!    oei:      integral array (n_ao x n_ao x 3 * n_centers)
      !!    oei_type: integral type
      !!
      !! 'oei_type' can be:
      !!
      !!    - 'kinetic'      Kinetic contribution to one-electron Hamiltonian (h)
      !!    - 'nuclear'      Nuclear attraction contribution to one-electron Hamiltonian (h)
      !!    - 'overlap'      AO overlap (S)
      !!
      !! Modified by Marcus Takvam Lexander, 2022 to be moved to oei_library
      !!
      use array_initialization, only: zero_array
      use timings_class, only: timings

      implicit none

      class(abstract_oei_library), intent(inout) :: this

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(*), intent(out), target :: oei
      real(dp), dimension(:, :, :, :), pointer :: oei_p_one_components
      real(dp), dimension(:, :, :, :, :), pointer :: oei_p_n_components

      integer :: n_components

      type(timings), allocatable :: timer

      timer = timings('First-derivative, one-electron integrals (' // trim(oei_type) // ')', 'v')
      call timer%turn_on()

      n_components = this%get_n_oei_components(oei_type)

      call zero_array(oei, 3 * n_components * (this%n_centers) * (this%n_ao)**2)

      if (n_components == 1) then
         oei_p_one_components(1:this%n_ao, &
                              1:this%n_ao, &
                              1:3, &
                              1:this%n_centers) => oei(1:this%n_ao**2 * 3 * this%n_centers)
      else
         oei_p_n_components(1:this%n_ao, &
                            1:this%n_ao, &
                            1:n_components, &
                            1:3, &
                            1:this%n_centers) => oei(1:this%n_ao**2 * n_components * 3 * this%n_centers)
      end if

      if (trim(oei_type) == 'kinetic' .or. trim(oei_type) == 'overlap') then

         call this%construct_coordinate_independent_oei_1der(oei_type, oei_p_one_components)

      elseif (trim(oei_type) == 'nuclear') then

         call this%construct_oei_nuclear_1der(oei_p_one_components)

      elseif (trim(oei_type) == 'dipole') then

         call this%construct_oei_dipole_1der(oei_p_n_components)

      else

         call output%error_msg('Could not recognize integral type (a0) in construct_oei_1der!', &
                               chars=[trim(oei_type)])

      end if

      call timer%turn_off()

   end subroutine get_oei_1der_abstract_oei_library


   subroutine construct_coordinate_independent_oei_1der_abstract_oei_library(this, oei_type, oei)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      implicit none

      class(abstract_oei_library), intent(inout) :: this

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(:, :, :, :), intent(out) :: oei

      real(dp), dimension(:, :, :, :), pointer :: oei_shell_p
      real(dp), dimension(6 * (this%max_sh_size)**2), target :: oei_shell

      integer :: w, y, q, w_f, y_f
      integer :: A, B, A_center, B_center

      !$omp parallel do private(A, B, A_center, B_center, oei_shell, oei_shell_p, w, y, w_f, y_f, q) &
      !$omp schedule(dynamic)
      do A = 1, this%n_sh
         do B = 1, A

            call this%get_oei_1der_shell(oei_type, oei_shell, A, B)

            oei_shell_p(1:this%shells(A)%length, &
                        1:this%shells(B)%length, &
                        1:3, &
                        1:2) => oei_shell(1:6 * this%shells(A)%length * this%shells(B)%length)

            A_center = this%shell_to_center(A)
            B_center = this%shell_to_center(B)

            do q = 1, 3
               do w = 1, this%shells(A)%length
                  do y = 1, this%shells(B)%length

                     w_f = this%shells(A)%first - 1 + w
                     y_f = this%shells(B)%first - 1 + y

                     oei(w_f, y_f, q, A_center) = oei(w_f, y_f, q, A_center) + oei_shell_p(w, y, q, 1)
                     oei(y_f, w_f, q, A_center) = oei(y_f, w_f, q, A_center) + oei_shell_p(w, y, q, 1)

                     oei(w_f, y_f, q, B_center) = oei(w_f, y_f, q, B_center) + oei_shell_p(w, y, q, 2)
                     oei(y_f, w_f, q, B_center) = oei(y_f, w_f, q, B_center) + oei_shell_p(w, y, q, 2)

                  end do
               end do
            end do

         end do
      end do
      !$omp end parallel do

   end subroutine construct_coordinate_independent_oei_1der_abstract_oei_library


   subroutine construct_oei_nuclear_1der_abstract_oei_library(this, oei)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      implicit none

      class(abstract_oei_library), intent(inout) :: this

      real(dp), dimension(:, :, :, :), intent(out) :: oei

      real(dp), dimension(:, :, :, :), pointer :: oei_shell_p
      real(dp), dimension(3 * this%n_centers * (this%max_sh_size)**2), target :: oei_shell

      integer :: w, y, q, w_f, y_f
      integer :: A, B, i_center

      !$omp parallel do private(A, B, oei_shell, oei_shell_p, w, y, w_f, y_f, q, i_center) &
      !$omp schedule(dynamic)
      do A = 1, this%n_sh
         do B = 1, A

            call this%get_oei_1der_shell('nuclear', oei_shell, A, B)

            oei_shell_p(1:this%shells(A)%length, &
                        1:this%shells(B)%length, &
                        1:3, &
                        1:this%n_centers &
            ) => oei_shell(1:3 * this%n_centers * this%shells(A)%length * this%shells(B)%length)

            do q = 1, 3
               do i_center = 1, this%n_centers
                  do w = 1, this%shells(A)%length
                     do y = 1, this%shells(B)%length

                        w_f = this%shells(A)%first - 1 + w
                        y_f = this%shells(B)%first - 1 + y

                        oei(w_f, y_f, q, i_center) = oei(w_f, y_f, q, i_center) &
                                                     + oei_shell_p(w, y, q, i_center)

                        if (A == B) cycle

                        oei(y_f, w_f, q, i_center) = oei(y_f, w_f, q, i_center) &
                                                     + oei_shell_p(w, y, q, i_center)

                     end do
                  end do
               end do
            end do

         end do
      end do
      !$omp end parallel do

   end subroutine construct_oei_nuclear_1der_abstract_oei_library


   subroutine construct_oei_dipole_1der_abstract_oei_library(this, oei)
      !!
      !! Written by Marcus T. Lexander, 2022
      !!
      !! In one dimension:
      !!
      !! Dipole integral:
      !!
      !! d_ij = <phi_i(x - A) |x| phi_j(x - B)>
      !! where A is the x coord of the center for ao-i is on, and B for the center of ao-j.
      !! If these are on the same atom or differen atoms makes for different expressions:
      !!
      !! If A and B are the same atom, the derivative is just the overlap:
      !!
      !! d_ij = <phi_i(x - A) |x| phi_j(x - A)> = <phi_i(x) |x + A| phi_j(x)>
      !! d/dA d_ij = d/dA <phi_i(x) |x + A| phi_j(x)> = <phi_i(x) | phi_j(x)> = S_ij
      !!
      !! If A and B are different atoms we can express as electronic derivative:
      !!
      !! d/dA d_ij =   d/dA <phi_i(x - A) |x| phi_j(x - B)>
      !!          =   <d/dA phi_i(x - A) |x| phi_j(x - B)>
      !!          = - <d/dx phi_i(x - A) |x| phi_j(x - B)>
      !!
      use reordering_r, only: sort_to_1243_subblock, sort_to_2143_subblock

      implicit none

      class(abstract_oei_library) :: this

      ! Output matrix (ao, ao, xyz, xyz, atm)
      real(dp), dimension(this%n_ao, this%n_ao, 3, 3, this%n_centers), intent(out) :: oei

      real(dp), dimension(:, :, :, :), pointer :: oei_shell_p
      real(dp), dimension(3 * 3 * (this%max_sh_size)**2), target :: oei_shell

      integer :: A, B, A_center, B_center

      !$omp parallel do private(A, B, A_center, B_center, oei_shell, oei_shell_p) &
      !$omp schedule(dynamic)
      do A = 1, this%n_sh
         do B = 1, this%n_sh

            call this%get_oei_1der_shell('dipole', oei_shell, A, B)

            oei_shell_p(1:this%shells(A)%length, &
                        1:this%shells(B)%length, &
                        1:3, &
                        1:3) => oei_shell(1:3 * 3 * this%shells(A)%length * this%shells(B)%length)

            A_center = this%shell_to_center(A)
            B_center = this%shell_to_center(B)

            call sort_to_1243_subblock(oei_shell_p, &
                                       oei(:, :, :, :, B_center), &
                                       this%shells(A), &
                                       this%shells(B), &
                                       range_(1, 3), &
                                       range_(1, 3))

            call sort_to_2143_subblock(oei_shell_p, &
                                       oei(:, :, :, :, B_center), &
                                       this%shells(A), &
                                       this%shells(B), &
                                       range_(1, 3), &
                                       range_(1, 3))

         end do
      end do
      !$omp end parallel do

   end subroutine construct_oei_dipole_1der_abstract_oei_library


end module abstract_oei_library_class

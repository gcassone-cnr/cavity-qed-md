
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module libcint_tool_class
   !!
   !! libcint tool class module
   !! Written by Marcus T. Lexander and Andrea Bianchi, May 2022
   !!
   !! This tool contains the data used for calling libcint functions.
   !! Example usage:
   !!
   !!    type(libcint_tool) :: this
   !!
   !!    real(dp), dimension(9)       :: oei
   !!    integer(c_int), dimension(2) :: shells ! These have to be zero indexed
   !!
   !!    shells(1) = 2
   !!    shells(2) = 3
   !!    call cint1e_ovlp_sph(oei, shells, this%lc_centers, this%n_centers, &
   !!                         this%lc_shells, this%n_lc_shells, this%lc_environment)
   !!
   use parameters

   use memory_manager_class, only: mem
   use atomic_center_class, only: atomic_center
   use shell_class, only: shell
   use iso_c_binding, only: c_int
   use global_out, only: output

   implicit none

   type :: libcint_tool

      ! The lc_ prefixed arrays are the libcint formatted arrays. All indices start at zero.

      ! lc_environment: Called env in libcint.
      ! This is the array where all floating point data used by libcint is stored.
      ! The format used here is:

      ! [
      !    CONFIG   : 20 numbers left free for configuration data, including integral precision and origin coordinates
      !    CENTERS  : Atomic center coordinates; 3 * n_centers
      !    SHELLS   : Shell information. Each shell is stored as (exponents, coefficients)
      !   (RI SHELLS: When RI is initialized the RI shell information is stored right after the normal shells in the same format)
      ! ]

      ! To be thread safe, each omp thread needs its own copy of the environment,
      ! so the lc_environment array is of size n_environment x n_threads.


      ! lc_centers: Called atm in libcint.
      ! 6 x n_centers int32 array which contains information about the atomic centers.

      ! Each column of the array corresponds to one atomic center, with the following information:
      ! 1:   Nuclear charge
      ! 2:   Index in lc_environment where the center coordinates are stored.
      ! 3-6: Information about nuclear charge distribution model.
      !      eT currently only supports point charge model so these are set to zero.


      ! lc_shells: Called bas in libcint.
      ! 8 x n_lc_shells int32 array with information about each shell.
      ! n_lc_shells is the number of ao-shells plus the number of ri shells.

      ! Each column of the array corresponds to one shell, with the following information:
      ! 1: Index in lc_centers to the atomic center the shell is located at.
      ! 2: Angular momentum. 0 = s, 1 = p, ...
      ! 3: Number of primitive gaussians in the shell.
      ! 4: Number of contracted gaussians in the shell. Currently in eT this is always 1.
      ! 5: Information about spin-orbitals. Currently in eT this is always set to 0.
      ! 6: Index in lc_environment where the exponents are located.
      ! 7: Index in lc_environment where the coefficients are located.
      ! 8: Currently unused by libcint and always set to zero.

      integer(c_int), dimension(:, :), allocatable, public :: lc_centers, lc_shells
      real(dp), dimension(:, :), allocatable, public :: lc_environment
      integer, public :: n_lc_shells, n_environment, n_threads, n_centers, n_sh

      logical :: cartesian  ! If not, it is spherical

      ! Variables for the external point charge integrals (used in QM/MM)
      integer(c_int) :: n_point_charges
      real(dp), dimension(:, :), allocatable, public :: point_charge_centers
      real(dp), dimension(:), allocatable, public :: point_charge_charges

      ! For unit charges
      integer(c_int) :: n_unit_charges
      real(dp), dimension(:, :), allocatable, public :: unit_charge_centers

      ! RI data
      logical :: ri_initialized
      integer :: ri_offset  ! Index in lc_environment where the ri-shells begin

   contains

      procedure, public :: cleanup => cleanup_libcint_tool
      procedure, public :: export_centers => export_centers_libcint_tool
      procedure, public :: set_integral_precision => set_integral_precision_libcint_tool
      procedure, public :: set_electrostatic_potential_origin => set_electrostatic_potential_origin_libcint

      procedure, private :: initialize_n_environment => initialize_n_environment_libcint_tool
      procedure, private :: initialize_shells_and_centers => initialize_shells_and_centers_libcint_tool
      procedure, private :: initialize_shell => initialize_shell_libcint_tool

   end type libcint_tool

   interface libcint_tool

      procedure :: new_libcint_tool

   end interface libcint_tool


contains


   function new_libcint_tool(centers, n_centers, n_sh) result(this)
      !!
      !! Written by Marcus T. Lexander and Andrea Bianchi, 2022
      !!
      use omp_lib, only: omp_get_max_threads

      implicit none

      integer, intent(in) :: n_centers, n_sh
      type(atomic_center), dimension(n_centers), intent(in) :: centers

      type(libcint_tool) :: this

      integer :: i, offset

      real(dp), external :: cintgto_norm

      this%n_threads = 1
      !$    this%n_threads = omp_get_max_threads()

      this%n_centers = n_centers
      call mem%alloc(this%lc_centers, 6, n_centers)

      this%n_sh = n_sh
      this%n_lc_shells = n_sh  ! This one will increase when RI shells are initialized
      call mem%alloc(this%lc_shells, 8, this%n_lc_shells)

      this%cartesian = centers(1)%cartesian

      ! Libcint will not work with some spherical and some cartesian, so we check that all are the same
      do i = 1, n_centers
         if (centers(i)%cartesian .neqv. centers(1)%cartesian) then

            call output%error_msg( &
                    "Libcint does not support both spherical and cartesian functions at the same time!" &
                 )

         end if
      end do

      ! Find how much memory to allocate for env
      call this%initialize_n_environment(centers, offset)

      call mem%alloc(this%lc_environment, this%n_environment, this%n_threads, set_zero=.true.)

      ! Origin (for the calculation of the dipole)
      this%lc_environment(2:4, 1) = zero

      call this%set_electrostatic_potential_origin([zero, zero, zero])

      call this%initialize_shells_and_centers(centers, offset)

      ! Now that lc_environment is fully setup, copy to the other threads
      do i = 2, this%n_threads

         this%lc_environment(:, i) = this%lc_environment(:, 1)

      end do

      this%ri_initialized = .false.

   end function new_libcint_tool


   subroutine initialize_n_environment_libcint_tool(this, centers, offset)
      !!
      !! Written by Marcus T. Lexander and Andrea Bianchi, 2022
      !! Sets size of libcint environment
      !!
      implicit none

      class(libcint_tool), intent(inout) :: this
      type(atomic_center), dimension(this%n_centers), intent(in) :: centers
      integer, intent(inout) :: offset

      integer :: i, j

      ! 20 real(dp) of free space in the start of env is required (for parameters such as precision)
      offset = 20
      this%n_environment = offset + 3 * this%n_centers  ! 3 real(dp) to store coordinate of center
      do i = 1, this%n_centers
         do j = 1, centers(i)%n_shells
            ! 2 real(dp) for each primitive (1 exponent, 1 coefficient)
            this%n_environment = this%n_environment + centers(i)%shells(j)%get_n_primitives() * 2
         end do
      end do

   end subroutine initialize_n_environment_libcint_tool


   subroutine initialize_shells_and_centers_libcint_tool(this, centers, offset)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      implicit none

      class(libcint_tool), intent(inout) :: this
      type(atomic_center), dimension(this%n_centers), intent(in) :: centers
      integer, intent(inout) :: offset

      integer :: i, j, current_shell, current_ao

      offset = offset + 1
      current_shell = 1
      current_ao = 1
      do i = 1, this%n_centers

         ! Writing center coords
         this%lc_environment(offset:offset + 2, 1) = centers(i)%coordinates * angstrom_to_bohr

         ! Writing center information

         this%lc_centers(:, i) = &
            [int(centers(i)%nuclear_charge, c_int), int(offset - 1, c_int), 0_c_int, 0_c_int, 0_c_int, &
            0_c_int]  ! Nuclear charge  ! Where in env are coords  ! Nuclear charge distribution model = point charge  ! Unused  ! Unused  ! Unused

         offset = offset + 3

         ! Writing exponents and coefficients
         do j = 1, centers(i)%n_shells

            call this%initialize_shell(offset, centers(i)%shells(j), i, current_shell, current_ao)

         end do

      end do

   end subroutine initialize_shells_and_centers_libcint_tool


   subroutine initialize_shell_libcint_tool(this, offset, sh, center_index, current_shell, current_ao)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use shell_class, only: shell

      implicit none

      class(libcint_tool), intent(inout) :: this
      integer, intent(inout) :: offset
      type(shell), intent(in) :: sh
      integer, intent(in) :: center_index
      integer, intent(inout) :: current_shell, current_ao

      integer :: i, l, n_primitives, coefficient_offset, exponent_offset

      l = sh%get_angular_momentum()
      n_primitives = sh%get_n_primitives()

      ! Exponents
      exponent_offset = offset - 1
      do i = 1, n_primitives
         this%lc_environment(offset, 1) = sh%get_exponent_i(i)
         offset = offset + 1
      end do

      ! Coefficients
      coefficient_offset = offset - 1

      call normalize_contracted_gaussian(sh, &
                                         this%lc_environment(offset:offset + n_primitives - 1, 1), &
                                         this%cartesian)

      offset = offset + n_primitives

      this%lc_shells(:, current_shell) = &
         [int(center_index - 1, c_int), int(l, c_int), int(n_primitives, c_int), 1_c_int, 0_c_int, &
         int(exponent_offset, c_int), int(coefficient_offset, c_int), 0_c_int]  ! Atom index  ! Angular momentum  ! Primitives  ! One contracted per shell  ! No Spinor  ! Exponent offset  ! Coefficient offset  ! Unused

      current_ao = current_ao + 2 * l + 1

      current_shell = current_shell + 1

   end subroutine initialize_shell_libcint_tool


   subroutine cleanup_libcint_tool(this)
      !!
      !! Written by Marcus T. Lexander and Andrea Bianchi, 2022
      !!
      implicit none

      class(libcint_tool), intent(inout) :: this

      if (allocated(this%lc_centers)) call mem%dealloc(this%lc_centers)
      if (allocated(this%lc_shells)) call mem%dealloc(this%lc_shells)

      if (allocated(this%lc_environment)) call mem%dealloc(this%lc_environment)

      if (allocated(this%point_charge_centers)) call mem%dealloc(this%point_charge_centers)
      if (allocated(this%point_charge_charges)) call mem%dealloc(this%point_charge_charges)

      if (allocated(this%unit_charge_centers)) call mem%dealloc(this%unit_charge_centers)

   end subroutine cleanup_libcint_tool


   subroutine normalize_contracted_gaussian(sh, coeffs, cartesian)
      !!
      !! Written by Marcus T. Lexander and Andrea Bianchi, 2022
      !!
      implicit none
      type(shell), intent(in) :: sh

      real(dp), dimension(sh%get_n_primitives()), intent(out) :: coeffs
      logical :: cartesian

      integer :: i, j, l
      real(dp) :: self_overlap, gto_norm
      real(dp), external :: cintgto_norm

      l = sh%get_angular_momentum()

      self_overlap = zero

      do i = 1, sh%get_n_primitives()

         self_overlap = self_overlap + sh%get_coefficient_i(i)**2

         gto_norm = cintgto_norm(l, sh%get_exponent_i(i))

         coeffs(i) = sh%get_coefficient_i(i) * gto_norm

      end do

      do i = 1, sh%get_n_primitives()

         do j = 1, i - 1

            gto_norm = cintgto_norm(l, (sh%get_exponent_i(i) + sh%get_exponent_i(j)) / two)

            self_overlap = self_overlap + two * coeffs(i) * coeffs(j) / gto_norm**2

         end do

      end do

      call dscal(sh%get_n_primitives(), one / sqrt(self_overlap), coeffs, 1)

      ! To use the same normalization as libint
      if ((l > 1) .and. cartesian) then

         coeffs = coeffs * sqrt((2 * l + one) / (four * pi))

      end if

   end subroutine normalize_contracted_gaussian


   subroutine export_centers_libcint_tool(this, centers, n_centers)
      !!
      !! Written by Marcus T. Lexander and Andrea Bianchi, 2022
      !!
      implicit none

      class(libcint_tool), intent(inout) :: this

      type(atomic_center), dimension(:), intent(in) :: centers  ! AO basis centers

      integer, intent(in) :: n_centers

      integer :: i, j

      if (.not. allocated(this%lc_centers)) return

      this%n_centers = n_centers

      do i = 1, this%n_threads
         do j = 1, n_centers

            this%lc_environment(this%lc_centers(2, j) + 1:this%lc_centers(2, j) + 3, i) = &
                                                                                          centers(j &
                                                                                          )%coordinates &
                                                                                          * angstrom_to_bohr

         end do

      ! Potential TODO: reinitialize ri-optimizer objects if changing geometry for ri becomes relevant

      end do

   end subroutine export_centers_libcint_tool


   subroutine set_electrostatic_potential_origin_libcint(this, coord, lc_environment)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      !! For the libcint integrals of the form: 1 / |\vec{r} - \vec{R}_(env[PTR_RINV_ORIG])|
      !! For the electrostatic potential integrals respect to external charges or individual nuclei
      !! Note: it sets only this%lc_environment for the current thread
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_tool), intent(inout) :: this

      real(dp), dimension(3) :: coord

      real(dp), dimension(:), optional :: lc_environment

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      if (present(lc_environment)) then

         lc_environment(5:7) = coord

      else

         this%lc_environment(5:7, i_thread) = coord

      end if

   end subroutine set_electrostatic_potential_origin_libcint


   subroutine set_integral_precision_libcint_tool(this, precision, i_thread)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      !! If the i_thread parameter is present, modify the integral precision exclusively for the indicated thread.
      !!

      implicit none

      class(libcint_tool), intent(inout) :: this

      real(dp), intent(in) :: precision

      integer, intent(in), optional :: i_thread

      ! Integral cutoff ~ precision ** 2
      ! Libcint integral cutoff ~ abs(log(cutoff)) = two * abs(log(precision))

      if (present(i_thread)) then

         this%lc_environment(1, i_thread) = two * abs(log(precision))

      else

         this%lc_environment(1, :) = two * abs(log(precision))

      end if

   end subroutine set_integral_precision_libcint_tool


end module libcint_tool_class

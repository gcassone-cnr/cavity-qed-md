

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module libcint_oei_library_class

   !!
   !! Libcint one electron integral library class
   !! Written by Marcus T. Lexander, Andrea Bianchi 2022
   !!
   !! Extends abstract_oei_library_class to give interface to libcint one electron integrals.
   !!

   use parameters

   use abstract_oei_library_class, only: abstract_oei_library
   use libcint_tool_class, only: libcint_tool
   use iso_c_binding, only: c_int
   use global_out, only: output
   use memory_manager_class, only: mem
   use range_class, only: range_
   use atomic_center_class, only: atomic_center


   implicit none

   type, extends(abstract_oei_library) :: libcint_oei_library

      type(libcint_tool) :: libcint

   contains

      procedure, public :: cleanup => cleanup_oei_libcint
      procedure, public :: update_centers => update_centers_oei_libcint


      procedure, public :: get_oei_shell => get_oei_shell_libcint
      procedure, public :: get_oei_1der_shell => get_oei_1der_shell_libcint

      procedure, public :: initialize_external_charges_from_point_charges => &
                           initialize_external_charges_from_point_charges_libcint
      procedure, public :: initialize_external_charges => initialize_external_charges_libcint
      procedure, public :: initialize_external_unit_charges => initialize_external_unit_charges_libcint

      procedure, private :: get_oei_shell_overlap => get_oei_shell_overlap_libcint
      procedure, private :: get_oei_shell_hamiltonian => get_oei_shell_hamiltonian_libcint
      procedure, private :: get_oei_shell_dipole => get_oei_shell_dipole_libcint
      procedure, private :: get_oei_shell_quadrupole => get_oei_shell_quadrupole_libcint
      procedure, private :: get_oei_shell_momentum => get_oei_shell_momentum_libcint
      procedure, private :: get_oei_shell_angular_momentum => get_oei_shell_angular_momentum_libcint
      procedure, private :: get_oei_shell_electrostatic_potential => &
                            get_oei_shell_electrostatic_potential_libcint
      procedure, private :: get_oei_shell_electrostatic_potential_unit => &
                            get_oei_shell_electrostatic_potential_unit_libcint

      procedure, private :: get_oei_shell_1Bder_giao_overlap => get_oei_shell_1Bder_giao_overlap_libcint
      procedure, private :: get_oei_shell_1Bder_giao_ang_mom => get_oei_shell_1Bder_giao_ang_mom_libcint
      procedure, private :: get_oei_shell_1Bder_giao_kinetic => get_oei_shell_1Bder_giao_kinetic_libcint
      procedure, private :: get_oei_shell_1Bder_giao_nuclear => get_oei_shell_1Bder_giao_nuclear_libcint
      procedure, private :: get_oei_shell_1Bder_giao_paramagnetic_spin_orbit => &
                            get_oei_shell_1Bder_giao_paramagnetic_spin_orbit_libcint
      procedure, private :: get_oei_shell_giao_paramagnetic_spin_orbit => &
                            get_oei_shell_giao_paramagnetic_spin_orbit_libcint
      procedure, private :: get_oei_shell_giao_diamagnetic => get_oei_shell_giao_diamagnetic_libcint

      procedure, private :: get_oei_1der_overlap_shell => get_oei_1der_overlap_shell_libcint
      procedure, private :: get_oei_1der_kinetic_shell => get_oei_1der_kinetic_shell_libcint
      procedure, private :: get_oei_1der_nuclear_shell => get_oei_1der_nuclear_shell_libcint
      procedure, private :: get_oei_1der_dipole_shell => get_oei_1der_dipole_shell_libcint

   end type libcint_oei_library

   interface libcint_oei_library

      procedure :: new_libcint_oei_library

   end interface libcint_oei_library

contains

   function new_libcint_oei_library(precision, &
                                    n_ao, &
                                    centers, &
                                    n_centers, &
                                    n_sh, &
                                    max_sh_size, &
                                    shells, &
                                    shell_to_center) result(this)
      !!
      !! Written by Marcus T. Lexander, 2022
      !!
      implicit none

      type(libcint_oei_library) :: this

      real(dp), intent(in) :: precision

      integer, intent(in) :: n_ao, n_centers, n_sh, max_sh_size
      type(atomic_center), dimension(n_centers), intent(in), target :: centers
      type(range_), dimension(n_sh), intent(in), target :: shells
      integer, dimension(n_sh), intent(in), target :: shell_to_center

      this%n_ao = n_ao
      this%n_sh = n_sh
      this%max_sh_size = max_sh_size
      this%n_centers = n_centers
      this%shells => shells
      this%shell_to_center => shell_to_center

      this%libcint = libcint_tool(centers, n_centers, n_sh)

      call this%set_oei_precision(precision)

   end function new_libcint_oei_library


   subroutine cleanup_oei_libcint(this)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      implicit none

      class(libcint_oei_library), intent(inout) :: this

      if (allocated(this%shp_max_overlap)) call mem%dealloc(this%shp_max_overlap)

      call this%libcint%cleanup()

   end subroutine cleanup_oei_libcint


   subroutine update_centers_oei_libcint(this, centers, n_centers)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      implicit none

      class(libcint_oei_library), intent(inout) :: this

      integer, intent(in) :: n_centers

      type(atomic_center), dimension(n_centers), intent(in) :: centers

      call this%libcint%export_centers(centers, n_centers)

      call this%initialize()

   end subroutine update_centers_oei_libcint


   subroutine get_oei_shell_libcint(this, oei_type, oei, A, B)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      !! Computes the one-electron AO integral matrix x using
      !! the x_ABk contributions to x for the shells A and B, where k
      !! denotes the components (e.g., x, y, z, for dipole integrals)
      !!
      implicit none

      class(libcint_oei_library), intent(inout) :: this

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(:), intent(out), target :: oei

      integer, intent(in) :: A, B

      select case (oei_type)

         case ("overlap")

            call this%get_oei_shell_overlap(oei, A, B)

         case ("hamiltonian")

            call this%get_oei_shell_hamiltonian(oei, A, B)

         case ("dipole")

            call this%get_oei_shell_dipole(oei, A, B)

         case ("quadrupole")

            call this%get_oei_shell_quadrupole(oei, A, B)

         case ("momentum")

            call this%get_oei_shell_momentum(oei, A, B)

         case ("angular momentum")

            call this%get_oei_shell_angular_momentum(oei, A, B)

         case ("electrostatic potential")

            call this%get_oei_shell_electrostatic_potential(oei, A, B)

         case ("electrostatic potential unit")

            call this%get_oei_shell_electrostatic_potential_unit(oei, A, B)

         case ("first-order derivative wrt B giao overlap")

            call this%get_oei_shell_1Bder_giao_overlap(oei, A, B)

         case ("first-order derivative wrt B giao angular momentum")

            call this%get_oei_shell_1Bder_giao_ang_mom(oei, A, B)

         case ("first-order derivative wrt B giao kinetic energy")

            call this%get_oei_shell_1Bder_giao_kinetic(oei, A, B)

         case ("first-order derivative wrt B giao nuclear potential")

            call this%get_oei_shell_1Bder_giao_nuclear(oei, A, B)

         case ("giao paramagnetic spin-orbit")

            call this%get_oei_shell_giao_paramagnetic_spin_orbit(oei, A, B)

         case ("first-order derivative wrt B giao paramagnetic spin-orbit")

            call this%get_oei_shell_1Bder_giao_paramagnetic_spin_orbit(oei, A, B)

         case ("giao diamagnetic")

            call this%get_oei_shell_giao_diamagnetic(oei, A, B)

         case default

            call output%error_msg("Could not recognize the one-electron integral in the Libcint interface." &
               // " Please change integral program or add integral to the Libcint interface.")

      end select

   end subroutine get_oei_shell_libcint


   subroutine get_oei_shell_overlap_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_ovlp_cart(oei, &
                               shells, &
                               this%libcint%lc_centers, &
                               this%n_centers, &
                               this%libcint%lc_shells, &
                               this%libcint%n_lc_shells, &
                               this%libcint%lc_environment(:, i_thread), &
                               0)

      else

         call cint1e_ovlp_sph(oei, &
                              shells, &
                              this%libcint%lc_centers, &
                              this%n_centers, &
                              this%libcint%lc_shells, &
                              this%libcint%n_lc_shells, &
                              this%libcint%lc_environment(:, i_thread), &
                              0)

      end if

   end subroutine get_oei_shell_overlap_libcint


   subroutine get_oei_shell_hamiltonian_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length) :: oei_kinetic

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_kin_cart(oei_kinetic, &
                              shells, &
                              this%libcint%lc_centers, &
                              this%n_centers, &
                              this%libcint%lc_shells, &
                              this%libcint%n_lc_shells, &
                              this%libcint%lc_environment(:, i_thread))

         call cint1e_nuc_cart(oei, &
                              shells, &
                              this%libcint%lc_centers, &
                              this%n_centers, &
                              this%libcint%lc_shells, &
                              this%libcint%n_lc_shells, &
                              this%libcint%lc_environment(:, i_thread), &
                              0)

      else

         call cint1e_kin_sph(oei_kinetic, &
                             shells, &
                             this%libcint%lc_centers, &
                             this%n_centers, &
                             this%libcint%lc_shells, &
                             this%libcint%n_lc_shells, &
                             this%libcint%lc_environment(:, i_thread))

         call cint1e_nuc_sph(oei, &
                             shells, &
                             this%libcint%lc_centers, &
                             this%n_centers, &
                             this%libcint%lc_shells, &
                             this%libcint%n_lc_shells, &
                             this%libcint%lc_environment(:, i_thread), &
                             0)

      end if

      ! add kinetic and nuclear
      call daxpy(this%shells(A)%length * this%shells(B)%length, one, oei_kinetic, 1, oei, 1)

   end subroutine get_oei_shell_hamiltonian_libcint


   subroutine get_oei_shell_dipole_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_r_cart(oei, &
                            shells, &
                            this%libcint%lc_centers, &
                            this%n_centers, &
                            this%libcint%lc_shells, &
                            this%libcint%n_lc_shells, &
                            this%libcint%lc_environment(:, i_thread))

      else

         call cint1e_r_sph(oei, &
                           shells, &
                           this%libcint%lc_centers, &
                           this%n_centers, &
                           this%libcint%lc_shells, &
                           this%libcint%n_lc_shells, &
                           this%libcint%lc_environment(:, i_thread))

      end if

      ! negate because of electrons having negative charge
      call dscal(this%shells(A)%length * this%shells(B)%length * 3, - one, oei, 1)

   end subroutine get_oei_shell_dipole_libcint


   subroutine get_oei_shell_quadrupole_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 6), intent(out), target :: oei

      integer(c_int), dimension(2) :: shells

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length, 3, 3) :: oei_quadrupole
      real(dp), dimension(:, :), pointer :: oei_p

      integer :: i_thread, i, j

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_rr_cart(oei_quadrupole, &
                             shells, &
                             this%libcint%lc_centers, &
                             this%n_centers, &
                             this%libcint%lc_shells, &
                             this%libcint%n_lc_shells, &
                             this%libcint%lc_environment(:, i_thread))

      else

         call cint1e_rr_sph(oei_quadrupole, &
                            shells, &
                            this%libcint%lc_centers, &
                            this%n_centers, &
                            this%libcint%lc_shells, &
                            this%libcint%n_lc_shells, &
                            this%libcint%lc_environment(:, i_thread))

      end if

      oei_p(1:this%shells(A)%length * this%shells(B)%length, 1:6) => oei

      ! libcint gives the 3x3 matrix, eT uses only the upper triangular part
      do i = 1, 3
         do j = i, 3

            oei_p(:, (i - 1) * (2 * 3 - i) / 2 + j) = - oei_quadrupole(:, i, j)

         end do
      end do

   end subroutine get_oei_shell_quadrupole_libcint


   subroutine get_oei_shell_momentum_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_ovlpip_cart(oei, &
                                 shells, &
                                 this%libcint%lc_centers, &
                                 this%n_centers, &
                                 this%libcint%lc_shells, &
                                 this%libcint%n_lc_shells, &
                                 this%libcint%lc_environment(:, i_thread))

      else

         call cint1e_ovlpip_sph(oei, &
                                shells, &
                                this%libcint%lc_centers, &
                                this%n_centers, &
                                this%libcint%lc_shells, &
                                this%libcint%n_lc_shells, &
                                this%libcint%lc_environment(:, i_thread))

      end if

   end subroutine get_oei_shell_momentum_libcint


   subroutine get_oei_shell_angular_momentum_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_cg_irxp_cart(oei, &
                                  shells, &
                                  this%libcint%lc_centers, &
                                  this%n_centers, &
                                  this%libcint%lc_shells, &
                                  this%libcint%n_lc_shells, &
                                  this%libcint%lc_environment(:, i_thread))

      else

         call cint1e_cg_irxp_sph(oei, &
                                 shells, &
                                 this%libcint%lc_centers, &
                                 this%n_centers, &
                                 this%libcint%lc_shells, &
                                 this%libcint%n_lc_shells, &
                                 this%libcint%lc_environment(:, i_thread))

      end if

   end subroutine get_oei_shell_angular_momentum_libcint


   subroutine get_oei_shell_electrostatic_potential_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num
      use array_initialization, only: zero_array

      implicit none

      class(libcint_oei_library), intent(inout) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length) :: oei_single

      integer :: i_thread, i

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      call zero_array(oei, this%shells(A)%length * this%shells(B)%length)

      do i = 1, this%libcint%n_point_charges

         call this%libcint%set_electrostatic_potential_origin(this%libcint%point_charge_centers(:, i))

         if (this%libcint%cartesian) then

            call cint1e_rinv_cart(oei_single, &
                                  shells, &
                                  this%libcint%lc_centers, &
                                  this%n_centers, &
                                  this%libcint%lc_shells, &
                                  this%libcint%n_lc_shells, &
                                  this%libcint%lc_environment(:, i_thread))

         else

            call cint1e_rinv_sph(oei_single, &
                                 shells, &
                                 this%libcint%lc_centers, &
                                 this%n_centers, &
                                 this%libcint%lc_shells, &
                                 this%libcint%n_lc_shells, &
                                 this%libcint%lc_environment(:, i_thread))

         end if

         call daxpy(this%shells(A)%length * this%shells(B)%length, &
                    - this%libcint%point_charge_charges(i), &
                    oei_single, &
                    1, &
                    oei, &
                    1)

         call this%libcint%set_electrostatic_potential_origin([zero, zero, zero], &
                                                              this%libcint%lc_environment(:, i_thread))

      end do

   end subroutine get_oei_shell_electrostatic_potential_libcint


   subroutine get_oei_shell_electrostatic_potential_unit_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num
      use array_initialization, only: zero_array

      implicit none

      class(libcint_oei_library), intent(inout) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length) :: oei_single

      integer :: i_thread, i

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      call zero_array(oei, this%shells(A)%length * this%shells(B)%length)

      do i = 1, this%libcint%n_unit_charges

         call this%libcint%set_electrostatic_potential_origin(this%libcint%unit_charge_centers(:, i))

         if (this%libcint%cartesian) then

            call cint1e_rinv_cart(oei_single, &
                                  shells, &
                                  this%libcint%lc_centers, &
                                  this%n_centers, &
                                  this%libcint%lc_shells, &
                                  this%libcint%n_lc_shells, &
                                  this%libcint%lc_environment(:, i_thread))

         else

            call cint1e_rinv_sph(oei_single, &
                                 shells, &
                                 this%libcint%lc_centers, &
                                 this%n_centers, &
                                 this%libcint%lc_shells, &
                                 this%libcint%n_lc_shells, &
                                 this%libcint%lc_environment(:, i_thread))

         end if

         call daxpy(this%shells(A)%length * this%shells(B)%length, - one, oei_single, 1, oei, 1)

         call this%libcint%set_electrostatic_potential_origin([zero, zero, zero], &
                                                              this%libcint%lc_environment(:, i_thread))

      end do

   end subroutine get_oei_shell_electrostatic_potential_unit_libcint


   subroutine get_oei_shell_1Bder_giao_overlap_libcint(this, oei, A, B)
      !!
      !! Written by Alberto Barlini, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_igovlp_cart(oei, &
                                 shells, &
                                 this%libcint%lc_centers, &
                                 this%n_centers, &
                                 this%libcint%lc_shells, &
                                 this%libcint%n_lc_shells, &
                                 this%libcint%lc_environment(:, i_thread))

      else

         call cint1e_igovlp_sph(oei, &
                                shells, &
                                this%libcint%lc_centers, &
                                this%n_centers, &
                                this%libcint%lc_shells, &
                                this%libcint%n_lc_shells, &
                                this%libcint%lc_environment(:, i_thread))

      end if

   end subroutine get_oei_shell_1Bder_giao_overlap_libcint


   subroutine get_oei_shell_1Bder_giao_ang_mom_libcint(this, oei, A, B)
      !!
      !! Written by Alberto Barlini, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_giao_irjxp_cart(oei, &
                                     shells, &
                                     this%libcint%lc_centers, &
                                     this%n_centers, &
                                     this%libcint%lc_shells, &
                                     this%libcint%n_lc_shells, &
                                     this%libcint%lc_environment(:, i_thread))

      else

         call cint1e_giao_irjxp_sph(oei, &
                                    shells, &
                                    this%libcint%lc_centers, &
                                    this%n_centers, &
                                    this%libcint%lc_shells, &
                                    this%libcint%n_lc_shells, &
                                    this%libcint%lc_environment(:, i_thread))

      end if

   end subroutine get_oei_shell_1Bder_giao_ang_mom_libcint


   subroutine get_oei_shell_1Bder_giao_kinetic_libcint(this, oei, A, B)
      !!
      !! Written by Alberto Barlini, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_igkin_cart(oei, &
                                shells, &
                                this%libcint%lc_centers, &
                                this%n_centers, &
                                this%libcint%lc_shells, &
                                this%libcint%n_lc_shells, &
                                this%libcint%lc_environment(:, i_thread))

      else

         call cint1e_igkin_sph(oei, &
                               shells, &
                               this%libcint%lc_centers, &
                               this%n_centers, &
                               this%libcint%lc_shells, &
                               this%libcint%n_lc_shells, &
                               this%libcint%lc_environment(:, i_thread))

      end if

   end subroutine get_oei_shell_1Bder_giao_kinetic_libcint


   subroutine get_oei_shell_1Bder_giao_nuclear_libcint(this, oei, A, B)
      !!
      !! Written by Alberto Barlini, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_ignuc_cart(oei, &
                                shells, &
                                this%libcint%lc_centers, &
                                this%n_centers, &
                                this%libcint%lc_shells, &
                                this%libcint%n_lc_shells, &
                                this%libcint%lc_environment(:, i_thread))

      else

         call cint1e_ignuc_sph(oei, &
                               shells, &
                               this%libcint%lc_centers, &
                               this%n_centers, &
                               this%libcint%lc_shells, &
                               this%libcint%n_lc_shells, &
                               this%libcint%lc_environment(:, i_thread))

      end if

   end subroutine get_oei_shell_1Bder_giao_nuclear_libcint


   subroutine get_oei_shell_giao_paramagnetic_spin_orbit_libcint(this, oei, A, B)
      !!
      !! Written by Alberto Barlini, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num
      use array_initialization, only: zero_array

      implicit none

      class(libcint_oei_library), intent(inout) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3 &
         * this%n_centers), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      integer :: i_thread, i, offset

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      call zero_array(oei, this%shells(A)%length * this%shells(B)%length * 3 * this%n_centers)

      do i = 1, this%n_centers

         offset = 1 + this%shells(A)%length * this%shells(B)%length * (i - 1) * 3

         call this%libcint%set_electrostatic_potential_origin(this%libcint%lc_environment( &
            this%libcint%lc_centers(2, i) + 1:this%libcint%lc_centers(2, i) + 3, i_thread))

         if (this%libcint%cartesian) then

            call cint1e_prinvxp_cart(oei(offset:), &
                                     shells, &
                                     this%libcint%lc_centers, &
                                     this%n_centers, &
                                     this%libcint%lc_shells, &
                                     this%libcint%n_lc_shells, &
                                     this%libcint%lc_environment(:, i_thread))

         else

            call cint1e_prinvxp_sph(oei(offset:), &
                                    shells, &
                                    this%libcint%lc_centers, &
                                    this%n_centers, &
                                    this%libcint%lc_shells, &
                                    this%libcint%n_lc_shells, &
                                    this%libcint%lc_environment(:, i_thread))

         end if

      end do

      call this%libcint%set_electrostatic_potential_origin([zero, zero, zero], &
                                                           this%libcint%lc_environment(:, i_thread))

   end subroutine get_oei_shell_giao_paramagnetic_spin_orbit_libcint


   subroutine get_oei_shell_1Bder_giao_paramagnetic_spin_orbit_libcint(this, oei, A, B)
      !!
      !! Written by Alberto Barlini, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num
      use array_initialization, only: zero_array

      implicit none

      class(libcint_oei_library), intent(inout) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 9 &
         * this%n_centers), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      integer :: i_thread, i, offset

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      call zero_array(oei, this%shells(A)%length * this%shells(B)%length * 9 * this%n_centers)

      do i = 1, this%n_centers

         offset = 1 + this%shells(A)%length * this%shells(B)%length * (i - 1) * 9

         call this%libcint%set_electrostatic_potential_origin(this%libcint%lc_environment( &
            this%libcint%lc_centers(2, i) + 1:this%libcint%lc_centers(2, i) + 3, i_thread))

         if (this%libcint%cartesian) then

            call cint1e_a01gp_cart(oei(offset:), &
                                   shells, &
                                   this%libcint%lc_centers, &
                                   this%n_centers, &
                                   this%libcint%lc_shells, &
                                   this%libcint%n_lc_shells, &
                                   this%libcint%lc_environment(:, i_thread))

         else

            call cint1e_a01gp_sph(oei(offset:), &
                                  shells, &
                                  this%libcint%lc_centers, &
                                  this%n_centers, &
                                  this%libcint%lc_shells, &
                                  this%libcint%n_lc_shells, &
                                  this%libcint%lc_environment(:, i_thread))

         end if

      end do

      call this%libcint%set_electrostatic_potential_origin([zero, zero, zero], &
                                                           this%libcint%lc_environment(:, i_thread))

   end subroutine get_oei_shell_1Bder_giao_paramagnetic_spin_orbit_libcint


   subroutine get_oei_shell_giao_diamagnetic_libcint(this, oei, A, B)
      !!
      !! Written by Alberto Barlini, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num
      use array_initialization, only: zero_array

      implicit none

      class(libcint_oei_library), intent(inout) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 9 &
         * this%n_centers), intent(out) :: oei

      integer(c_int), dimension(2) :: shells

      integer :: i_thread, i, offset

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      call zero_array(oei, this%shells(A)%length * this%shells(B)%length * 9 * this%n_centers)

      do i = 1, this%n_centers

         offset = 1 + this%shells(A)%length * this%shells(B)%length * (i - 1) * 9

         call this%libcint%set_electrostatic_potential_origin(this%libcint%lc_environment( &
            this%libcint%lc_centers(2, i) + 1:this%libcint%lc_centers(2, i) + 3, i_thread))

         if (this%libcint%cartesian) then

            call cint1e_giao_a11part_cart(oei(offset:), &
                                          shells, &
                                          this%libcint%lc_centers, &
                                          this%n_centers, &
                                          this%libcint%lc_shells, &
                                          this%libcint%n_lc_shells, &
                                          this%libcint%lc_environment(:, i_thread))

         else

            call cint1e_giao_a11part_sph(oei(offset:), &
                                         shells, &
                                         this%libcint%lc_centers, &
                                         this%n_centers, &
                                         this%libcint%lc_shells, &
                                         this%libcint%n_lc_shells, &
                                         this%libcint%lc_environment(:, i_thread))

         end if

      end do

      call this%libcint%set_electrostatic_potential_origin([zero, zero, zero], &
                                                           this%libcint%lc_environment(:, i_thread))

   end subroutine get_oei_shell_giao_diamagnetic_libcint


   subroutine get_oei_1der_shell_libcint(this, oei_type, oei, A, B)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      !! Computes the one-electron AO integral matrix x using
      !! the x_ABk contributions to x for the shells A and B, where k
      !! denotes the components (e.g., x, y, z, for dipole integrals)
      !!

      implicit none

      class(libcint_oei_library), intent(inout) :: this

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(:), intent(out), target :: oei

      integer, intent(in) :: A, B

      select case (oei_type)

         case ("overlap")

            call this%get_oei_1der_overlap_shell(oei, A, B)

         case ("kinetic")

            call this%get_oei_1der_kinetic_shell(oei, A, B)

         case ("nuclear")

            call this%get_oei_1der_nuclear_shell(oei, A, B)

         case ("dipole")

            call this%get_oei_1der_dipole_shell(oei, A, B)

         case default

            call output%error_msg("Could not recognize the one-electron integral in the Libcint interface." &
               // " Please change integral program or add integral to the Libcint interface.")

      end select

   end subroutine get_oei_1der_shell_libcint


   subroutine get_oei_1der_overlap_shell_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 6), intent(out), target :: oei

      real(dp), dimension(:, :, :, :), pointer :: oei_p

      integer(c_int), dimension(2) :: shells

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      oei_p(1:this%shells(A)%length, &
            1:this%shells(B)%length, &
            1:3, &
            1:2) => oei(1:this%shells(A)%length * this%shells(B)%length * 6)

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_ipovlp_cart(oei_p(:, :, :, 1), &
                                 shells, &
                                 this%libcint%lc_centers, &
                                 this%n_centers, &
                                 this%libcint%lc_shells, &
                                 this%libcint%n_lc_shells, &
                                 this%libcint%lc_environment(:, i_thread))

      else

         call cint1e_ipovlp_sph(oei_p(:, :, :, 1), &
                                shells, &
                                this%libcint%lc_centers, &
                                this%n_centers, &
                                this%libcint%lc_shells, &
                                this%libcint%n_lc_shells, &
                                this%libcint%lc_environment(:, i_thread))

      end if

      call dcopy(this%shells(A)%length * this%shells(B)%length * 3, &
                 oei_p(:, :, :, 1), &
                 1, &
                 oei_p(:, :, :, 2), &
                 1)

      call dscal(this%shells(A)%length * this%shells(B)%length * 3, - one, oei_p(:, :, :, 1), 1)

   end subroutine get_oei_1der_overlap_shell_libcint


   subroutine get_oei_1der_kinetic_shell_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 6), intent(out), target :: oei

      real(dp), dimension(:, :, :, :), pointer :: oei_p

      integer(c_int), dimension(2) :: shells

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      oei_p(1:this%shells(A)%length, &
            1:this%shells(B)%length, &
            1:3, &
            1:2) => oei(1:this%shells(A)%length * this%shells(B)%length * 6)

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%libcint%cartesian) then

         call cint1e_ipkin_cart(oei_p(:, :, :, 1), &
                                shells, &
                                this%libcint%lc_centers, &
                                this%n_centers, &
                                this%libcint%lc_shells, &
                                this%libcint%n_lc_shells, &
                                this%libcint%lc_environment(:, i_thread))

      else

         call cint1e_ipkin_sph(oei_p(:, :, :, 1), &
                               shells, &
                               this%libcint%lc_centers, &
                               this%n_centers, &
                               this%libcint%lc_shells, &
                               this%libcint%n_lc_shells, &
                               this%libcint%lc_environment(:, i_thread))

      end if

      call dcopy(this%shells(A)%length * this%shells(B)%length * 3, &
                 oei_p(:, :, :, 1), &
                 1, &
                 oei_p(:, :, :, 2), &
                 1)

      call dscal(this%shells(A)%length * this%shells(B)%length * 3, - one, oei_p(:, :, :, 1), 1)

   end subroutine get_oei_1der_kinetic_shell_libcint


   subroutine get_oei_1der_nuclear_shell_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use omp_lib, only: omp_get_thread_num
      use array_initialization, only: zero_array
      use reordering_r, only: sort_to_213

      implicit none

      class(libcint_oei_library), intent(inout) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3 &
         * this%n_centers), intent(out), target :: oei

      real(dp), dimension(this%shells(A)%length, this%shells(B)%length, 3) :: oei_buf
      real(dp), dimension(this%shells(B)%length, this%shells(A)%length, 3) :: oei_buf_rev

      real(dp), dimension(:, :, :, :), pointer :: oei_p

      integer(c_int), dimension(2) :: shells, shells_rev

      integer :: i_thread, i

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      oei_p(1:this%shells(A)%length, &
            1:this%shells(B)%length, &
            1:3, &
            1:this%n_centers) => oei(1:this%shells(A)%length * this%shells(B)%length * 3 * this%n_centers)

      call zero_array(oei_p, this%shells(A)%length * this%shells(B)%length * 3 * this%n_centers)

      shells = [int(A - 1, c_int), int(B - 1, c_int)]
      shells_rev = [int(B - 1, c_int), int(A - 1, c_int)]

      do i = 1, this%n_centers

         ! Set coordinate of current center
         call this%libcint%set_electrostatic_potential_origin(this%libcint%lc_environment( &
            this%libcint%lc_centers(2, i) + 1, i_thread))

         if (this%libcint%cartesian) then

            call cint1e_iprinv_cart(oei_buf, &
                                    shells, &
                                    this%libcint%lc_centers, &
                                    this%n_centers, &
                                    this%libcint%lc_shells, &
                                    this%libcint%n_lc_shells, &
                                    this%libcint%lc_environment(:, i_thread))

            call cint1e_iprinv_cart(oei_buf_rev, &
                                    shells_rev, &
                                    this%libcint%lc_centers, &
                                    this%n_centers, &
                                    this%libcint%lc_shells, &
                                    this%libcint%n_lc_shells, &
                                    this%libcint%lc_environment(:, i_thread))

         else

            call cint1e_iprinv_sph(oei_buf, &
                                   shells, &
                                   this%libcint%lc_centers, &
                                   this%n_centers, &
                                   this%libcint%lc_shells, &
                                   this%libcint%n_lc_shells, &
                                   this%libcint%lc_environment(:, i_thread))

            call cint1e_iprinv_sph(oei_buf_rev, &
                                   shells_rev, &
                                   this%libcint%lc_centers, &
                                   this%n_centers, &
                                   this%libcint%lc_shells, &
                                   this%libcint%n_lc_shells, &
                                   this%libcint%lc_environment(:, i_thread))

         end if

         call daxpy(this%shells(A)%length * this%shells(B)%length * 3, &
                    - real(this%libcint%lc_centers(1, i), dp), &
                    oei_buf, &
                    1, &
                    oei_p(:, :, :, i), &
                    1)

         call sort_to_213(oei_buf_rev, oei_buf, this%shells(B)%length, this%shells(A)%length, 3)

         call daxpy(this%shells(A)%length * this%shells(B)%length * 3, &
                    - real(this%libcint%lc_centers(1, i), dp), &
                    oei_buf, &
                    1, &
                    oei_p(:, :, :, i), &
                    1)

      end do

      if (this%libcint%cartesian) then

         call cint1e_ipnuc_cart(oei_buf, &
                                shells, &
                                this%libcint%lc_centers, &
                                this%n_centers, &
                                this%libcint%lc_shells, &
                                this%libcint%n_lc_shells, &
                                this%libcint%lc_environment(:, i_thread))

         call cint1e_ipnuc_cart(oei_buf_rev, &
                                shells_rev, &
                                this%libcint%lc_centers, &
                                this%n_centers, &
                                this%libcint%lc_shells, &
                                this%libcint%n_lc_shells, &
                                this%libcint%lc_environment(:, i_thread))

      else

         call cint1e_ipnuc_sph(oei_buf, &
                               shells, &
                               this%libcint%lc_centers, &
                               this%n_centers, &
                               this%libcint%lc_shells, &
                               this%libcint%n_lc_shells, &
                               this%libcint%lc_environment(:, i_thread))

         call cint1e_ipnuc_sph(oei_buf_rev, &
                               shells_rev, &
                               this%libcint%lc_centers, &
                               this%n_centers, &
                               this%libcint%lc_shells, &
                               this%libcint%n_lc_shells, &
                               this%libcint%lc_environment(:, i_thread))

      end if

      call daxpy(this%shells(A)%length * this%shells(B)%length * 3, &
                 - one, &
                 oei_buf, &
                 1, &
                 oei_p(:, :, :, this%shell_to_center(A)), &
                 1)

      call sort_to_213(oei_buf_rev, oei_buf, this%shells(B)%length, this%shells(A)%length, 3)

      call daxpy(this%shells(A)%length * this%shells(B)%length * 3, &
                 - one, &
                 oei_buf, &
                 1, &
                 oei_p(:, :, :, this%shell_to_center(B)), &
                 1)

      call this%libcint%set_electrostatic_potential_origin([zero, zero, zero], &
                                                           this%libcint%lc_environment(:, i_thread))

   end subroutine get_oei_1der_nuclear_shell_libcint


   subroutine get_oei_1der_dipole_shell_libcint(this, oei, A, B)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      !! Dipole integral:
      !!
      !! d_ij = <phi_i(x - A) |x| phi_j(x - B)>
      !! where A is the x coord of the center for ao-i is on, and B for the center of ao-j.
      !! If these are on the same atom or differen atoms makes for different expressions:
      !!
      !! If A and B are the same atom, the derivative is just the overlap:
      !!
      !! d_ij = <phi_i(x - A) |x| phi_j(x - A)> = <phi_i(x) |x + A| phi_j(x)>
      !! d/dA d_ij = d/dA <phi_i(x) |x + A| phi_j(x)> = <phi_i(x) | phi_j(x)> = S_ij
      !!
      !! If A and B are different atoms we can express as electronic derivative:
      !!
      !! d/dB d_ij =   d/dB <phi_i(x - A) |x| phi_j(x - B)>
      !!          =   <phi_i(x - A) |x| d/dB phi_j(x - B)>
      !!          = - <phi_i(x - A) |x| d/dx phi_j(x - B)>
      !!
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3 * 3), intent(out), target :: oei

      real(dp), dimension(:, :, :, :), pointer :: oei_p

      integer(c_int), dimension(2) :: shells

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      oei_p(1:this%shells(A)%length, &
            1:this%shells(B)%length, &
            1:3, &
            1:3) => oei(1:this%shells(A)%length * this%shells(B)%length * 3 * 3)

      shells = [int(A - 1, c_int), int(B - 1, c_int)]

      if (this%shp_on_same_atom(A, B)) then

         oei_p(:, :, :, :) = zero

         if (this%libcint%cartesian) then

            call cint1e_ovlp_cart(oei_p, &
                                  shells, &
                                  this%libcint%lc_centers, &
                                  this%n_centers, &
                                  this%libcint%lc_shells, &
                                  this%libcint%n_lc_shells, &
                                  this%libcint%lc_environment(:, i_thread), &
                                  0)

         else

            call cint1e_ovlp_sph(oei_p, &
                                 shells, &
                                 this%libcint%lc_centers, &
                                 this%n_centers, &
                                 this%libcint%lc_shells, &
                                 this%libcint%n_lc_shells, &
                                 this%libcint%lc_environment(:, i_thread), &
                                 0)

         end if

         call dscal(this%shells(A)%length * this%shells(B)%length, - one, oei_p(:, :, 1, 1), 1)

         call dcopy(this%shells(A)%length * this%shells(B)%length, oei_p(:, :, 1, 1), 1, oei_p(:, :, 2, 2), 1)
         call dcopy(this%shells(A)%length * this%shells(B)%length, oei_p(:, :, 1, 1), 1, oei_p(:, :, 3, 3), 1)

      else

         if (this%libcint%cartesian) then

            call cint1e_irp_cart(oei_p, &
                                 shells, &
                                 this%libcint%lc_centers, &
                                 this%n_centers, &
                                 this%libcint%lc_shells, &
                                 this%libcint%n_lc_shells, &
                                 this%libcint%lc_environment(:, i_thread))

         else

            call cint1e_irp_sph(oei_p, &
                                shells, &
                                this%libcint%lc_centers, &
                                this%n_centers, &
                                this%libcint%lc_shells, &
                                this%libcint%n_lc_shells, &
                                this%libcint%lc_environment(:, i_thread))

         end if

      end if

   end subroutine get_oei_1der_dipole_shell_libcint


   subroutine initialize_external_charges_from_point_charges_libcint(this, pc)
      !!
      !! Written by Andrea Bianchi, 2022
      !!
      !! Initializes the external charge engines that are needed for
      !! embedding (QM/MM)
      !!
      use point_charges_class, only: point_charges

      implicit none

      class(libcint_oei_library), intent(inout) :: this
      type(point_charges), intent(in) :: pc

      if (allocated(this%libcint%point_charge_centers)) then
         call mem%dealloc(this%libcint%point_charge_centers)
      end if

      if (allocated(this%libcint%point_charge_charges)) then
         call mem%dealloc(this%libcint%point_charge_charges)
      end if

      this%libcint%n_point_charges = int(pc%n_charges, c_int)

      call mem%alloc(this%libcint%point_charge_centers, 3, pc%n_charges)
      call mem%alloc(this%libcint%point_charge_charges, pc%n_charges)

      this%libcint%point_charge_centers = pc%r * angstrom_to_bohr
      this%libcint%point_charge_charges = pc%q

   end subroutine initialize_external_charges_from_point_charges_libcint


   subroutine initialize_external_charges_libcint(this, n_charges, positions, charges)
      !!
      !! Written by Andrea Bianchi, 2022
      !!
      !! Initializes the external charge engines that are needed for
      !! embedding (QM/MM)
      !!
      implicit none

      class(libcint_oei_library), intent(inout) :: this
      integer, intent(in) :: n_charges
      real(dp), dimension(3, n_charges), intent(in) :: positions
      real(dp), dimension(n_charges), intent(in) :: charges

      if (allocated(this%libcint%point_charge_centers)) then
         call mem%dealloc(this%libcint%point_charge_centers)
      end if

      if (allocated(this%libcint%point_charge_charges)) then
         call mem%dealloc(this%libcint%point_charge_charges)
      end if

      this%libcint%n_point_charges = int(n_charges, c_int)

      call mem%alloc(this%libcint%point_charge_centers, 3, n_charges)
      call mem%alloc(this%libcint%point_charge_charges, n_charges)

      this%libcint%point_charge_centers = positions * angstrom_to_bohr
      this%libcint%point_charge_charges = charges

   end subroutine initialize_external_charges_libcint


   subroutine initialize_external_unit_charges_libcint(this, n_charges, positions)
      !!
      !! Written by Andrea Bianchi, 2022
      !!
      !! Initializes the external charge engines that are needed for
      !! embedding (QM/MM)
      !!
      implicit none

      class(libcint_oei_library), intent(inout) :: this
      integer, intent(in) :: n_charges
      real(dp), dimension(3, n_charges), intent(in) :: positions

      if (allocated(this%libcint%unit_charge_centers)) then
         call mem%dealloc(this%libcint%unit_charge_centers)
      end if

      this%libcint%n_unit_charges = int(n_charges, c_int)

      call mem%alloc(this%libcint%unit_charge_centers, 3, n_charges)

      this%libcint%unit_charge_centers = positions * angstrom_to_bohr

   end subroutine initialize_external_unit_charges_libcint


   subroutine set_oei_precision_libcint(this, oei_precision)
      !!
      !! Written by Andrea Bianchi, March 2023
      !!
      implicit none

      class(libcint_oei_library), intent(inout) :: this
      real(dp), intent(in) :: oei_precision

      this%oei_precision = oei_precision

      call this%libcint%set_integral_precision(this%oei_precision)

   end subroutine set_oei_precision_libcint


end module libcint_oei_library_class

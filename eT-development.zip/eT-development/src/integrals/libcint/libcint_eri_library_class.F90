

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module libcint_eri_library_class

   !!
   !! libcint electron repulsion integral library class
   !! Written by Marcus T. Lexander and Andrea Bianchi, 2022
   !!
   !! Extends abstract_eri_library_class to give interface to libcint electron repulsion integrals.
   !!

   use parameters

   use memory_manager_class, only: mem
   use abstract_eri_library_class, only: abstract_eri_library
   use atomic_center_class, only: atomic_center
   use libcint_tool_class, only: libcint_tool
   use iso_c_binding, only: c_int
   use range_class, only: range_

   implicit none

   type, extends(abstract_eri_library) :: libcint_eri_library

      type(libcint_tool) :: libcint
      integer :: n_sh
      type(range_), dimension(:), pointer :: shells


      ! Eri optimizer objects.
      ! These are pointers to C-objects that store useful data to speed up two electron integrals.
      ! Each libcint function requires its own type of optimizer.
      ! The mapping of which optmizer is used for which libcint functions are:
      !    cint2e     => optimizer_eri
      !    cint2e_ip1 => optimizer_eri_1der1
      !    cint2e_ip2 => optimizer_eri_1der2

      integer(i64), dimension(:), allocatable, public :: optimizer_eri, optimizer_eri_1der1, &
                                                         optimizer_eri_1der2

      ! Optimizer objects for 2- and 3-center integrals.
      integer(i64), dimension(:), allocatable, public :: optimizer_eri_2c, optimizer_eri_3c

   contains

      procedure, public :: get_eri => get_eri_libcint

      procedure, public :: get_first_order_derivative_wrt_B_giao_eri => &
                           get_first_order_derivative_wrt_B_giao_eri_libcint

      procedure, public :: get_eri_1der => get_eri_1der_libcint
      procedure, private :: get_eri_1der_cartesian => get_eri_1der_cartesian_libcint
      procedure, private :: get_eri_1der_spherical => get_eri_1der_spherical_libcint

      procedure, public :: get_eri_2c => get_eri_2c_libcint
      procedure, public :: get_eri_3c => get_eri_3c_libcint

      procedure, public :: prepare_for_ri => prepare_for_ri_libcint

      procedure, public :: set_eri_precision => set_eri_precision_libcint

      procedure, public :: initialize => initialize_eri_libcint
      procedure, public :: cleanup => cleanup_eri_libcint
      procedure, public :: update_centers => update_centers_eri_libcint

      procedure, private :: initialize_eri_optimizers => initialize_eri_optimizers_libcint

   end type libcint_eri_library

   interface libcint_eri_library

      procedure :: new_libcint

   end interface libcint_eri_library

contains

   function new_libcint(centers, n_centers, n_sh, shells, eri_precision) result(this)
      !!
      !! Written by Marcus T. Lexander, 2022
      !!
      implicit none

      type(libcint_eri_library) :: this

      integer, intent(in) :: n_centers, n_sh
      type(atomic_center), dimension(n_centers), intent(in) :: centers
      type(range_), dimension(n_sh), intent(in), target :: shells
      real(dp), intent(in) :: eri_precision

      this%name = 'libcint'
      this%libcint = libcint_tool(centers, n_centers, n_sh)

      call this%set_eri_precision(eri_precision)

      this%n_sh = n_sh
      this%shells => shells

   end function new_libcint


   subroutine initialize_eri_libcint(this)
      !!
      !! Written by Eirik F. Kjoenstad, June 2019
      !!

      implicit none

      class(libcint_eri_library), intent(inout) :: this

      call this%initialize_eri_optimizers()

   end subroutine initialize_eri_libcint


   subroutine cleanup_eri_libcint(this)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      implicit none

      class(libcint_eri_library), intent(inout) :: this

      integer :: i

      if (allocated(this%optimizer_eri)) then

         do i = 1, this%libcint%n_threads

            call CINTdel_optimizer(this%optimizer_eri(i))
            call CINTdel_optimizer(this%optimizer_eri_1der1(i))
            call CINTdel_optimizer(this%optimizer_eri_1der2(i))

         end do

         call mem%dealloc(this%optimizer_eri)
         call mem%dealloc(this%optimizer_eri_1der1)
         call mem%dealloc(this%optimizer_eri_1der2)

      end if

      if (this%libcint%ri_initialized) then

         do i = 1, this%libcint%n_threads

            call CINTdel_optimizer(this%optimizer_eri_2c(i))
            call CINTdel_optimizer(this%optimizer_eri_3c(i))

         end do

         call mem%dealloc(this%optimizer_eri_2c)
         call mem%dealloc(this%optimizer_eri_3c)

      end if

      call this%libcint%cleanup()

   end subroutine cleanup_eri_libcint


   subroutine update_centers_eri_libcint(this, centers, n_centers)
      !!
      !! Written by Marcus T. Lexander
      !!
      implicit none

      class(libcint_eri_library), intent(inout) :: this

      integer, intent(in) :: n_centers

      type(atomic_center), dimension(n_centers), intent(in) :: centers

      call this%libcint%export_centers(centers, n_centers)

      call this%initialize()

   end subroutine update_centers_eri_libcint


   subroutine initialize_eri_optimizers_libcint(this)
      !!
      !! Written by Marcus T. Lexander
      !!
      implicit none

      class(libcint_eri_library), intent(inout) :: this

      integer :: i
      logical :: cleanup

      cleanup = allocated(this%optimizer_eri)

      if (.not. allocated(this%optimizer_eri)) call mem%alloc(this%optimizer_eri, this%libcint%n_threads)
      if (.not. allocated(this%optimizer_eri_1der1)) &
         call mem%alloc(this%optimizer_eri_1der1, this%libcint%n_threads)
      if (.not. allocated(this%optimizer_eri_1der2)) &
         call mem%alloc(this%optimizer_eri_1der2, this%libcint%n_threads)

      do i = 1, this%libcint%n_threads
         if (cleanup) then
            call CINTdel_optimizer(this%optimizer_eri(i))
            call CINTdel_optimizer(this%optimizer_eri_1der1(i))
            call CINTdel_optimizer(this%optimizer_eri_1der2(i))
         end if

         if (this%libcint%cartesian) then

            call cint2e_cart_optimizer(this%optimizer_eri(i), &
                                       this%libcint%lc_centers, &
                                       this%libcint%n_centers, &
                                       this%libcint%lc_shells, &
                                       this%libcint%n_lc_shells, &
                                       this%libcint%lc_environment(:, i))

            call cint2e_ip1_cart_optimizer(this%optimizer_eri_1der1(i), &
                                           this%libcint%lc_centers, &
                                           this%libcint%n_centers, &
                                           this%libcint%lc_shells, &
                                           this%libcint%n_lc_shells, &
                                           this%libcint%lc_environment(:, i))

            call cint2e_ip2_cart_optimizer(this%optimizer_eri_1der2(i), &
                                           this%libcint%lc_centers, &
                                           this%libcint%n_centers, &
                                           this%libcint%lc_shells, &
                                           this%libcint%n_lc_shells, &
                                           this%libcint%lc_environment(:, i))

         else

            call cint2e_sph_optimizer(this%optimizer_eri(i), &
                                      this%libcint%lc_centers, &
                                      this%libcint%n_centers, &
                                      this%libcint%lc_shells, &
                                      this%libcint%n_lc_shells, &
                                      this%libcint%lc_environment(:, i))

            call cint2e_ip1_sph_optimizer(this%optimizer_eri_1der1(i), &
                                          this%libcint%lc_centers, &
                                          this%libcint%n_centers, &
                                          this%libcint%lc_shells, &
                                          this%libcint%n_lc_shells, &
                                          this%libcint%lc_environment(:, i))

            call cint2e_ip2_sph_optimizer(this%optimizer_eri_1der2(i), &
                                          this%libcint%lc_centers, &
                                          this%libcint%n_centers, &
                                          this%libcint%lc_shells, &
                                          this%libcint%n_lc_shells, &
                                          this%libcint%lc_environment(:, i))

         end if
      end do

   end subroutine initialize_eri_optimizers_libcint


   subroutine get_eri_libcint(this, g, A, B, C, D, precision, skip)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      !! Wrapper for constructing electron repulsion integrals g for the
      !! shell quartet (A, B, C, D).
      !!
      !! The integrals are placed in g.
      !!
      !! Two optional arguments:
      !!
      !!    precision:  (intent in) Double precision real corresponding to the precision value
      !!                to use when calculating the integral. Does not guarantee a precision
      !!                to the given value and should therefore be selected conservatively.
      !!
      !!    skip:       (intent out) If present, this integer will be 1 if libcint decided not to
      !!                calculate the integral; it will be zero otherwise. Also, if it is present, g will
      !!                not be zeroed out if libcint decides not to calculate g. Thus, only pass 'skip'
      !!                to the routine if you wish to avoid zeroing out elements that are negligible.
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_eri_library), intent(inout) :: this

      integer, intent(in) :: A, B, C, D

      real(dp), dimension(*), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      integer(c_int), dimension(4) :: shells

      integer(c_int), external :: cint2e_cart, cint2e_sph
      integer(c_int) :: integral_is_significant_cint
      integer :: integral_is_significant
      integer :: n_A, n_B, n_C, n_D

      real(dp) :: precision_local

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      precision_local = this%get_local_eri_precision(precision)

      call this%libcint%set_integral_precision(precision_local, i_thread)

      shells(1) = int(A - 1, c_int)
      shells(2) = int(B - 1, c_int)
      shells(3) = int(C - 1, c_int)
      shells(4) = int(D - 1, c_int)

      if (this%libcint%cartesian) then

         integral_is_significant_cint = cint2e_cart(g, &
                                                    shells, &
                                                    this%libcint%lc_centers, &
                                                    this%libcint%n_centers, &
                                                    this%libcint%lc_shells, &
                                                    this%libcint%n_lc_shells, &
                                                    this%libcint%lc_environment(:, i_thread), &
                                                    this%optimizer_eri(i_thread))

      else

         integral_is_significant_cint = cint2e_sph(g, &
                                                   shells, &
                                                   this%libcint%lc_centers, &
                                                   this%libcint%n_centers, &
                                                   this%libcint%lc_shells, &
                                                   this%libcint%n_lc_shells, &
                                                   this%libcint%lc_environment(:, i_thread), &
                                                   this%optimizer_eri(i_thread))

      end if

      integral_is_significant = int(integral_is_significant_cint)

      n_A = this%shells(A)%length
      n_B = this%shells(B)%length
      n_C = this%shells(C)%length
      n_D = this%shells(D)%length

      call this%is_integral_significant(g, n_A * n_B * n_C * n_D, integral_is_significant, skip)

   end subroutine get_eri_libcint


   subroutine get_first_order_derivative_wrt_B_giao_eri_libcint(this, g, A, B, C, D, precision, skip)
      !!
      !! Written by Alberto Barlini, November 2022
      !!
      !! Compute first-order derivative wrt B giao eri integrals.
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_eri_library), intent(inout) :: this

      integer, intent(in) :: A, B, C, D

      real(dp), dimension(*), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      integer(c_int), dimension(4) :: shells

      integer(c_int), external :: cint2e_ig1_cart, cint2e_ig1_sph
      integer(c_int) :: integral_is_significant_cint
      integer :: integral_is_significant
      integer :: n_A, n_B, n_C, n_D

      real(dp) :: precision_local

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      precision_local = this%get_local_eri_precision(precision)

      call this%libcint%set_integral_precision(precision_local, i_thread)

      shells(1) = int(A - 1, c_int)
      shells(2) = int(B - 1, c_int)
      shells(3) = int(C - 1, c_int)
      shells(4) = int(D - 1, c_int)

      if (this%libcint%cartesian) then

         integral_is_significant_cint = cint2e_ig1_cart(g, &
                                                        shells, &
                                                        this%libcint%lc_centers, &
                                                        this%libcint%n_centers, &
                                                        this%libcint%lc_shells, &
                                                        this%libcint%n_lc_shells, &
                                                        this%libcint%lc_environment(:, i_thread), &
                                                        zero)

      else

         integral_is_significant_cint = cint2e_ig1_sph(g, &
                                                       shells, &
                                                       this%libcint%lc_centers, &
                                                       this%libcint%n_centers, &
                                                       this%libcint%lc_shells, &
                                                       this%libcint%n_lc_shells, &
                                                       this%libcint%lc_environment(:, i_thread), &
                                                       zero)

      end if

      integral_is_significant = int(integral_is_significant_cint)

      n_A = this%shells(A)%length
      n_B = this%shells(B)%length
      n_C = this%shells(C)%length
      n_D = this%shells(D)%length

      call this%is_integral_significant(g, n_A * n_B * n_C * n_D * 3, integral_is_significant, skip)

   end subroutine get_first_order_derivative_wrt_B_giao_eri_libcint


   subroutine get_eri_1der_libcint(this, g, A, B, C, D, precision, skip)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      !! Wrapper for constructing first derivative electron repulsion integrals g for the
      !! shell quartet (A, B, C, D). The result is stored in g, in the order of ABCDqk, where
      !! q = 1,2,3 are Cartesian coordinates (x,y,z) and k = 1,2,3,4 are the atomic centers
      !! corresponding to the atoms where A,B,C,D are located.
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_eri_library), intent(inout) :: this

      integer, intent(in) :: A, B, C, D

      real(dp), dimension(*), intent(out), target :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      real(dp), dimension(:, :, :, :, :, :), pointer :: g_p

      real(dp), dimension(this%shells(A)%length, this%shells(B)%length, this%shells(C)%length, this%shells(D &
         )%length, 3) :: g_1der_A

      real(dp), dimension(this%shells(B)%length, this%shells(A)%length, this%shells(C)%length, this%shells(D &
         )%length, 3) :: g_1der_B

      real(dp), dimension(this%shells(A)%length, this%shells(B)%length, this%shells(C)%length, this%shells(D &
         )%length, 3) :: g_1der_C

      integer :: I, J, K, L, M, n_A, n_B, n_C, n_D

      real(dp) :: precision_local

      integer :: i_thread, integral_is_significant

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      precision_local = this%get_local_eri_precision(precision)

      call this%libcint%set_integral_precision(precision_local, i_thread)

      g_p(1:this%shells(A)%length, &
          1:this%shells(B)%length, &
          1:this%shells(C)%length, &
          1:this%shells(D)%length, &
          1:3, &
          1:4 &
      ) => g(1:this%shells(A)%length * this%shells(B)%length * this%shells(C)%length * this%shells(D)%length &
         * 12)

      if (this%libcint%cartesian) then

         call this%get_eri_1der_cartesian(g_1der_A, g_1der_B, g_1der_C, A, B, C, D, integral_is_significant)

      else

         call this%get_eri_1der_spherical(g_1der_A, g_1der_B, g_1der_C, A, B, C, D, integral_is_significant)

      end if

      g_p(:, :, :, :, :, 1) = - g_1der_A
      g_p(:, :, :, :, :, 3) = - g_1der_C

      ! permute (to improve in some way)
      do M = 1, 3
         do L = 1, this%shells(D)%length
            do K = 1, this%shells(C)%length

               do J = 1, this%shells(B)%length
                  do I = 1, this%shells(A)%length

                     g_p(I, J, K, L, M, 2) = - g_1der_B(J, I, K, L, M)

                  end do

               end do
            end do
         end do
      end do

      g_p(:, :, :, :, :, 4) = - g_p(:, :, :, :, :, 1) - g_p(:, :, :, :, :, 2) - g_p(:, :, :, :, :, 3)

      n_A = this%shells(A)%length
      n_B = this%shells(B)%length
      n_C = this%shells(C)%length
      n_D = this%shells(D)%length

      call this%is_integral_significant(g, n_A * n_B * n_C * n_D * 3, integral_is_significant, skip)

   end subroutine get_eri_1der_libcint


   subroutine get_eri_1der_cartesian_libcint(this, g_1der_A, g_1der_B, g_1der_C, A, B, C, D, significant)
      !!
      !! Written by Marcus T. Lexander and Andrea Bianchi, 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_eri_library), intent(in) :: this

      integer, intent(in) :: A, B, C, D

      integer, intent(out) :: significant

      real(dp), dimension(this%shells(A)%length, this%shells(B)%length, this%shells(C)%length, this%shells(D &
         )%length, 3), intent(out) :: g_1der_A

      real(dp), dimension(this%shells(B)%length, this%shells(A)%length, this%shells(C)%length, this%shells(D &
         )%length, 3), intent(out) :: g_1der_B

      real(dp), dimension(this%shells(A)%length, this%shells(B)%length, this%shells(C)%length, this%shells(D &
         )%length, 3), intent(out) :: g_1der_C

      integer(c_int), dimension(4) :: shells

      integer :: i_thread, significant1, significant2, significant3

      integer(c_int), external :: cint2e_ip1_cart, cint2e_ip2_cart

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int), int(C - 1, c_int), int(D - 1, c_int)]

      ! [A'B|CD]

      significant1 = cint2e_ip1_cart(g_1der_A, &
                                     shells, &
                                     this%libcint%lc_centers, &
                                     this%libcint%n_centers, &
                                     this%libcint%lc_shells, &
                                     this%libcint%n_lc_shells, &
                                     this%libcint%lc_environment(:, i_thread), &
                                     this%optimizer_eri_1der1(i_thread))

      ! [AB|C'D]

      significant2 = cint2e_ip2_cart(g_1der_C, &
                                     shells, &
                                     this%libcint%lc_centers, &
                                     this%libcint%n_centers, &
                                     this%libcint%lc_shells, &
                                     this%libcint%n_lc_shells, &
                                     this%libcint%lc_environment(:, i_thread), &
                                     this%optimizer_eri_1der2(i_thread))

      ! [AB'|CD]

      shells(1:2) = [int(B - 1, c_int), int(A - 1, c_int)]

      significant3 = cint2e_ip1_cart(g_1der_B, &
                                     shells, &
                                     this%libcint%lc_centers, &
                                     this%libcint%n_centers, &
                                     this%libcint%lc_shells, &
                                     this%libcint%n_lc_shells, &
                                     this%libcint%lc_environment(:, i_thread), &
                                     this%optimizer_eri_1der1(i_thread))

      significant = 1
      if (significant1 == 0 .and. significant2 == 0 .and. significant3 == 0) significant = 0

   end subroutine get_eri_1der_cartesian_libcint


   subroutine get_eri_1der_spherical_libcint(this, g_1der_A, g_1der_B, g_1der_C, A, B, C, D, significant)
      !!
      !! Written by Marcus T. Lexander and Andrea Bianchi, 2022
      !!
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_eri_library), intent(in) :: this

      integer, intent(in) :: A, B, C, D

      integer, intent(out) :: significant

      real(dp), dimension(this%shells(A)%length, this%shells(B)%length, this%shells(C)%length, this%shells(D &
         )%length, 3), intent(out) :: g_1der_A

      real(dp), dimension(this%shells(B)%length, this%shells(A)%length, this%shells(C)%length, this%shells(D &
         )%length, 3), intent(out) :: g_1der_B

      real(dp), dimension(this%shells(A)%length, this%shells(B)%length, this%shells(C)%length, this%shells(D &
         )%length, 3), intent(out) :: g_1der_C

      integer(c_int), dimension(4) :: shells

      integer :: i_thread, significant1, significant2, significant3

      integer(c_int), external :: cint2e_ip1_sph, cint2e_ip2_sph

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      shells = [int(A - 1, c_int), int(B - 1, c_int), int(C - 1, c_int), int(D - 1, c_int)]

      ! [A'B|CD]

      significant1 = cint2e_ip1_sph(g_1der_A, &
                                    shells, &
                                    this%libcint%lc_centers, &
                                    this%libcint%n_centers, &
                                    this%libcint%lc_shells, &
                                    this%libcint%n_lc_shells, &
                                    this%libcint%lc_environment(:, i_thread), &
                                    this%optimizer_eri_1der1(i_thread))

      ! [AB|C'D]

      significant2 = cint2e_ip2_sph(g_1der_C, &
                                    shells, &
                                    this%libcint%lc_centers, &
                                    this%libcint%n_centers, &
                                    this%libcint%lc_shells, &
                                    this%libcint%n_lc_shells, &
                                    this%libcint%lc_environment(:, i_thread), &
                                    this%optimizer_eri_1der2(i_thread))

      ! [AB'|CD]

      shells(1:2) = [int(B - 1, c_int), int(A - 1, c_int)]

      significant3 = cint2e_ip1_sph(g_1der_B, &
                                    shells, &
                                    this%libcint%lc_centers, &
                                    this%libcint%n_centers, &
                                    this%libcint%lc_shells, &
                                    this%libcint%n_lc_shells, &
                                    this%libcint%lc_environment(:, i_thread), &
                                    this%optimizer_eri_1der1(i_thread))

      significant = 1
      if (significant1 == 0 .and. significant2 == 0 .and. significant3 == 0) significant = 0

   end subroutine get_eri_1der_spherical_libcint


   subroutine get_eri_2c_libcint(this, g, J, K, precision, skip)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      !! Two optional arguments:
      !!
      !!    precision:  (intent in) Double precision real corresponding to the precision value
      !!                to use when calculating the integral. Does not guarantee a precision
      !!                to the given value and should therefore be selected conservatively.
      !!
      !!    skip:       (intent out) If present, this integer will be 1 if libcint decided not to
      !!                calculate the integral; it will be zero otherwise. If it is present, g will
      !!                not be zeroed out if libcint decides not to calculate g. Thus, only pass 'skip'
      !!                to the routine if you wish to avoid zeroing out elements that are negligible.
      !!
      use shell_class, only: shell
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_eri_library), intent(inout) :: this
      type(shell), intent(in) :: J, K

      real(dp), dimension(J%length * K%length), intent(out), target :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      integer(c_int), dimension(2) :: shells

      real(dp) :: precision_local

      integer(c_int), external :: cint2c2e_cart, cint2c2e_sph
      integer(c_int) :: integral_is_significant_cint
      integer :: integral_is_significant

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      precision_local = this%get_local_eri_precision(precision)

      call this%libcint%set_integral_precision(precision_local, i_thread)

      shells(1) = int(J%number_ + this%libcint%ri_offset - 1, c_int)
      shells(2) = int(K%number_ + this%libcint%ri_offset - 1, c_int)

      if (this%libcint%cartesian) then

         integral_is_significant_cint = cint2c2e_cart(g, &
                                                      shells, &
                                                      this%libcint%lc_centers, &
                                                      this%libcint%n_centers, &
                                                      this%libcint%lc_shells, &
                                                      this%libcint%n_lc_shells, &
                                                      this%libcint%lc_environment(:, i_thread), &
                                                      this%optimizer_eri_2c(i_thread))

      else

         integral_is_significant_cint = cint2c2e_sph(g, &
                                                     shells, &
                                                     this%libcint%lc_centers, &
                                                     this%libcint%n_centers, &
                                                     this%libcint%lc_shells, &
                                                     this%libcint%n_lc_shells, &
                                                     this%libcint%lc_environment(:, i_thread), &
                                                     this%optimizer_eri_2c(i_thread))

      end if

      integral_is_significant = int(integral_is_significant_cint)

      call this%is_integral_significant(g, J%length * K%length, integral_is_significant, skip)

   end subroutine get_eri_2c_libcint


   subroutine get_eri_3c_libcint(this, g, J, C, D, precision, skip)
      !!
      !! Written by Andrea Bianchi, 2022
      !!
      !!    precision:  (intent in) Double precision real corresponding to the precision value
      !!                to use when calculating the integral. Does not guarantee a precision
      !!                to the given value and should therefore be selected conservatively.
      !!
      !!    skip:       (intent out) If present, this integer will be 1 if libcint decided not to
      !!                calculate the integral; it will be zero otherwise. If it is present, g will
      !!                not be zeroed out if libcint decides not to calculate g. Thus, only pass 'skip'
      !!                to the routine if you wish to avoid zeroing out elements that are negligible.
      !!
      use shell_class, only: shell
      use omp_lib, only: omp_get_thread_num

      implicit none

      class(libcint_eri_library), intent(inout) :: this

      integer, intent(in) :: C, D

      type(shell), intent(in) :: J

      real(dp), dimension(*), intent(out), target :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      real(dp), dimension(:, :), pointer :: g_p

      real(dp), dimension(this%shells(C)%length * this%shells(D)%length, J%length) :: g_transp

      integer(c_int), dimension(3) :: shells

      real(dp) :: precision_local

      integer(c_int), external :: cint3c2e_cart, cint3c2e_sph
      integer(c_int) :: integral_is_significant_cint
      integer :: integral_is_significant

      integer :: i_thread

      i_thread = 1
      !$    i_thread = omp_get_thread_num() + 1

      precision_local = this%get_local_eri_precision(precision)

      call this%libcint%set_integral_precision(precision_local, i_thread)

      if (present(skip)) skip = 0

      shells(1) = int(C - 1, c_int)
      shells(2) = int(D - 1, c_int)
      shells(3) = int(J%number_ + this%libcint%ri_offset - 1, c_int)

      if (this%libcint%cartesian) then

         integral_is_significant_cint = cint3c2e_cart(g_transp, &
                                                      shells, &
                                                      this%libcint%lc_centers, &
                                                      this%libcint%n_centers, &
                                                      this%libcint%lc_shells, &
                                                      this%libcint%n_lc_shells, &
                                                      this%libcint%lc_environment(:, i_thread), &
                                                      this%optimizer_eri_3c(i_thread))

      else

         integral_is_significant_cint = cint3c2e_sph(g_transp, &
                                                     shells, &
                                                     this%libcint%lc_centers, &
                                                     this%libcint%n_centers, &
                                                     this%libcint%lc_shells, &
                                                     this%libcint%n_lc_shells, &
                                                     this%libcint%lc_environment(:, i_thread), &
                                                     this%optimizer_eri_3c(i_thread))

      end if

      g_p(1:J%length, &
          1:this%shells(C)%length * this%shells(D)%length &
      ) => g(1:J%length * this%shells(C)%length * this%shells(D)%length)

      g_p = transpose(g_transp)

      integral_is_significant = int(integral_is_significant_cint)

      call this%is_integral_significant(g, &
                                        J%length * this%shells(C)%length * this%shells(D)%length, &
                                        integral_is_significant, &
                                        skip)

   end subroutine get_eri_3c_libcint


   subroutine prepare_for_ri_libcint(this, basis_set, precision, centers)
      !!
      !! Written by Marcus T. Lexander, 2022
      !!
      use atomic_center_class, only: atomic_center
      use warning_suppressor, only: do_nothing
      use memory_manager_class, only: mem

      use libcint_tool_class, only: normalize_contracted_gaussian

      implicit none

      character(len=100), intent(in) :: basis_set
      real(dp), intent(in) :: precision
      type(atomic_center), dimension(:), intent(in) :: centers

      class(libcint_eri_library), intent(inout) :: this

      integer(c_int), dimension(:, :), allocatable :: lc_shells_ri
      real(dp), dimension(:, :), allocatable :: lc_environment_ri

      integer :: i, j, k, n_lc_shells_ri, n_lc_environment_ri, offset, l, n_primitives, exponent_offset, &
                 coefficient_offset, current_shell, old_nenv

      call do_nothing(basis_set)
      call do_nothing(precision)

      n_lc_shells_ri = 0
      n_lc_environment_ri = 0

      do i = 1, size(centers)

         n_lc_shells_ri = n_lc_shells_ri + centers(i)%n_shells

         do j = 1, centers(i)%n_shells

            ! Only need to store new coefficients and exponents
            n_lc_environment_ri = n_lc_environment_ri + centers(i)%shells(j)%get_n_primitives() * 2

         end do

      end do

      call mem%alloc(lc_shells_ri, 8, this%libcint%n_lc_shells + n_lc_shells_ri)

      call mem%alloc(lc_environment_ri, &
                     this%libcint%n_environment + n_lc_environment_ri, &
                     this%libcint%n_threads)

      lc_shells_ri(:, 1:this%libcint%n_lc_shells) = this%libcint%lc_shells
      lc_environment_ri(1:this%libcint%n_environment, :) = this%libcint%lc_environment

      call mem%dealloc(this%libcint%lc_shells)
      call mem%dealloc(this%libcint%lc_environment)

      call mem%alloc(this%libcint%lc_shells, 8, this%libcint%n_lc_shells + n_lc_shells_ri)

      call mem%alloc(this%libcint%lc_environment, &
                     this%libcint%n_environment + n_lc_environment_ri, &
                     this%libcint%n_threads)

      this%libcint%lc_shells = lc_shells_ri
      this%libcint%lc_environment = lc_environment_ri

      call mem%dealloc(lc_shells_ri)
      call mem%dealloc(lc_environment_ri)

      this%libcint%ri_offset = this%libcint%n_lc_shells
      old_nenv = this%libcint%n_environment
      offset = old_nenv + 1

      this%libcint%n_lc_shells = this%libcint%n_lc_shells + n_lc_shells_ri
      this%libcint%n_environment = this%libcint%n_environment + n_lc_environment_ri

      current_shell = this%libcint%ri_offset + 1

      do i = 1, size(centers)

         do j = 1, centers(i)%n_shells

            l = centers(i)%shells(j)%get_angular_momentum()
            n_primitives = centers(i)%shells(j)%get_n_primitives()

            ! Exponents
            exponent_offset = offset - 1
            do k = 1, n_primitives
               this%libcint%lc_environment(offset, 1) = centers(i)%shells(j)%get_exponent_i(k)
               offset = offset + 1
            end do

            ! Coefficients
            coefficient_offset = offset - 1

            call normalize_contracted_gaussian(centers(i)%shells(j), &
                                               this%libcint%lc_environment(offset:offset + n_primitives - 1, &
                                                  1), &
                                               this%libcint%cartesian)

            offset = offset + n_primitives

            this%libcint%lc_shells(:, current_shell) = &
               [int(i - 1, c_int), int(l, c_int), int(n_primitives, c_int), 1_c_int, 0_c_int, &
               int(exponent_offset, c_int), int(coefficient_offset, c_int), 0_c_int]  ! Atom index  ! Angular momentum  ! Primitives  ! One contracted per shell  ! No Spinor  ! Exponent offset  ! Coefficient offset  ! Unused

            current_shell = current_shell + 1

         end do

      end do

      do i = 2, this%libcint%n_threads

         this%libcint%lc_environment(old_nenv + 1:this%libcint%n_environment, i) = &
            this%libcint%lc_environment(old_nenv + 1:this%libcint%n_environment, 1)

      end do

      call mem%alloc(this%optimizer_eri_2c, this%libcint%n_threads)
      call mem%alloc(this%optimizer_eri_3c, this%libcint%n_threads)

      do i = 1, this%libcint%n_threads
         if (this%libcint%cartesian) then

            call cint2c2e_cart_optimizer(this%optimizer_eri_2c(i), &
                                         this%libcint%lc_centers, &
                                         this%libcint%n_centers, &
                                         this%libcint%lc_shells, &
                                         this%libcint%n_lc_shells, &
                                         this%libcint%lc_environment(:, 1))

            call cint3c2e_cart_optimizer(this%optimizer_eri_3c(i), &
                                         this%libcint%lc_centers, &
                                         this%libcint%n_centers, &
                                         this%libcint%lc_shells, &
                                         this%libcint%n_lc_shells, &
                                         this%libcint%lc_environment(:, 1))

         else

            call cint2c2e_sph_optimizer(this%optimizer_eri_2c(i), &
                                        this%libcint%lc_centers, &
                                        this%libcint%n_centers, &
                                        this%libcint%lc_shells, &
                                        this%libcint%n_lc_shells, &
                                        this%libcint%lc_environment(:, 1))

            call cint3c2e_sph_optimizer(this%optimizer_eri_3c(i), &
                                        this%libcint%lc_centers, &
                                        this%libcint%n_centers, &
                                        this%libcint%lc_shells, &
                                        this%libcint%n_lc_shells, &
                                        this%libcint%lc_environment(:, 1))

         end if
      end do

      this%libcint%ri_initialized = .true.

   end subroutine prepare_for_ri_libcint


   subroutine set_eri_precision_libcint(this, eri_precision)
      !!
      !! Written by Andrea Bianchi, March 2023
      !!
      implicit none

      class(libcint_eri_library), intent(inout) :: this
      real(dp), intent(in) :: eri_precision

      this%eri_precision = eri_precision

      call this%libcint%set_integral_precision(this%eri_precision)

   end subroutine set_eri_precision_libcint


end module libcint_eri_library_class

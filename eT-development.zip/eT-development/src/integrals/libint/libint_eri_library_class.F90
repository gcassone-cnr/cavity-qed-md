

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module libint_eri_library_class

   !!
   !! Libint electron repulsion integral library class
   !! Written by Marcus T. Lexander 2022
   !!
   !! Extends abstract_eri_library_class to give interface to libint electron repulsion integrals.
   !!

   use parameters, only: dp
   use atomic_center_class, only: atomic_center
   use abstract_eri_library_class, only: abstract_eri_library
   use iso_c_binding, only: c_int
   use range_class, only: range_

   implicit none

   type, extends(abstract_eri_library) :: libint_eri_library

      integer :: n_sh
      type(range_), dimension(:), pointer :: shells

   contains

      procedure, public :: get_eri => get_eri_libint
      procedure, public :: get_eri_1der => get_eri_1der_libint

      procedure, public :: get_eri_2c => get_eri_2c_libint
      procedure, public :: get_eri_3c => get_eri_3c_libint

      procedure, public :: prepare_for_ri => prepare_for_ri_libint

      procedure, public :: set_eri_precision => set_eri_precision_libint

      procedure, public :: initialize => initialize_libint_integral_engines
      procedure, public :: cleanup => cleanup_eri_libint
      procedure, public :: update_centers => update_centers_eri_libint

   end type libint_eri_library

   include "eri_cdef.F90"
   include "libint_initialization_cdef.F90"

   interface libint_eri_library

      procedure :: new_libint_eri_library

   end interface libint_eri_library

contains

   function new_libint_eri_library(centers, n_centers, n_sh, shells, eri_precision) result(this)
      !!
      !! Written by Marcus T. Lexander 2022
      !!
      implicit none

      type(libint_eri_library) :: this

      integer, intent(in) :: n_centers, n_sh
      real(dp), intent(in) :: eri_precision

      type(atomic_center), dimension(n_centers), intent(in) :: centers
      type(range_), dimension(n_sh), intent(in), target :: shells

      this%name = 'libint'
      this%eri_precision = eri_precision

      this%n_sh = n_sh
      this%shells => shells

      call this%update_centers(centers, n_centers)

   end function new_libint_eri_library


   subroutine initialize_libint_integral_engines(this)
      !!
      !! Written by Eirik F. Kjoenstad, June 2019
      !!
      !! In order to set a precision value for the integral in libint,
      !! it is necessary to provide approximately the squared value of the precision as the input.
      !!
      implicit none
      class(libint_eri_library), intent(inout) :: this

      call initialize_eri_c(this%eri_precision**2)

   end subroutine initialize_libint_integral_engines


   subroutine cleanup_eri_libint(this)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(libint_eri_library), intent(inout) :: this

      call do_nothing(this)

   end subroutine cleanup_eri_libint


   subroutine update_centers_eri_libint(this, centers, n_centers)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use libint_initialization, only: export_geometry_and_basis_to_libint

      implicit none

      class(libint_eri_library), intent(inout) :: this

      integer, intent(in) :: n_centers

      type(atomic_center), dimension(n_centers), intent(in) :: centers

      call export_geometry_and_basis_to_libint(centers)
      call this%initialize()

   end subroutine update_centers_eri_libint


   subroutine get_eri_libint(this, g, A, B, C, D, precision, skip)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !!
      !! Wrapper for constructing electron repulsion integrals g for the
      !! shell quartet (A, B, C, D).
      !!
      !! The integrals are placed in g.
      !!
      !! Two optional arguments:
      !!
      !!    precision:  (intent in) Double precision real corresponding to the precision value
      !!                to use when calculating the integral. Does not guarantee a precision
      !!                to the given value and should therefore be selected conservatively.
      !!
      !!    skip:       (intent out) If present, this integer will be 1 if Libint decided not to
      !!                calculate the integral; it will be zero otherwise. If it is present, g will
      !!                not be zeroed out if Libint decides not to calculate g. Thus, only pass 'skip'
      !!                to the routine if you wish to avoid zeroing out elements that are negligible.
      !!
      implicit none

      class(libint_eri_library), intent(inout) :: this

      integer, intent(in) :: A, B, C, D

      real(dp), dimension(*), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      integer(c_int) :: A_, B_, C_, D_
      integer(c_int) :: n_A, n_B, n_C, n_D

      integer(c_int) :: integral_is_significant

      real(dp) :: precision_local

      A_ = int(A, c_int)
      B_ = int(B, c_int)
      C_ = int(C, c_int)
      D_ = int(D, c_int)

      n_A = int(this%shells(A)%length, c_int)
      n_B = int(this%shells(B)%length, c_int)
      n_C = int(this%shells(C)%length, c_int)
      n_D = int(this%shells(D)%length, c_int)

      ! Set precision to non-default value if requested

      precision_local = this%get_local_eri_precision(precision)

      ! Get the integrals g from Libint

      call get_eri_c(g, &
                     A_, &
                     B_, &
                     C_, &
                     D_, &
                     precision_local**2, &
                     integral_is_significant, &
                     n_A, &
                     n_B, &
                     n_C, &
                     n_D)

      call this%is_integral_significant(g, int(n_A * n_B * n_C * n_D), int(integral_is_significant), skip)

   end subroutine get_eri_libint


   subroutine get_eri_1der_libint(this, g, A, B, C, D, precision, skip)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !!
      !! Wrapper for constructing first derivative electron repulsion integrals g for the
      !! shell quartet (A, B, C, D). The result is stored in g, in the order of ABCDqk, where
      !! q = 1,2,3 are Cartesian coordinates (x,y,z) and k = 1,2,3,4 are the atomic centers
      !! corresponding to the atoms where A,B,C,D are located.
      !!
      implicit none

      class(libint_eri_library), intent(inout) :: this

      integer, intent(in) :: A, B, C, D

      real(dp), dimension(*), intent(out), target :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      integer(c_int) :: A_, B_, C_, D_

      integer(c_int) :: integral_is_significant

      real(dp) :: precision_local

      integer :: n_A, n_B, n_C, n_D

      precision_local = this%get_local_eri_precision(precision)

      A_ = int(A, c_int)
      B_ = int(B, c_int)
      C_ = int(C, c_int)
      D_ = int(D, c_int)

      ! Get the integrals g from Libint

      n_A = this%shells(A)%length
      n_B = this%shells(B)%length
      n_C = this%shells(C)%length
      n_D = this%shells(D)%length

      call get_eri_1der_c(g, A_, B_, C_, D_, precision_local, integral_is_significant)

      call this%is_integral_significant(g, n_A * n_B * n_C * n_D, int(integral_is_significant), skip)

   end subroutine get_eri_1der_libint


   subroutine get_eri_2c_libint(this, g, J, K, precision, skip)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !!
      !! Two optional arguments:
      !!
      !!    precision:  (intent in) Double precision real corresponding to the precision value
      !!                to use when calculating the integral. Does not guarantee a precision
      !!                to the given value and should therefore be selected conservatively.
      !!
      !!    skip:       (intent out) If present, this integer will be 1 if Libint decided not to
      !!                calculate the integral; it will be zero otherwise. If it is present, g will
      !!                not be zeroed out if Libint decides not to calculate g. Thus, only pass 'skip'
      !!                to the routine if you wish to avoid zeroing out elements that are negligible.
      !!

      use shell_class, only: shell

      implicit none

      class(libint_eri_library), intent(inout) :: this
      type(shell), intent(in) :: J, K

      real(dp), dimension(J%length * K%length), intent(out), target :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      integer(c_int) :: J_, K_
      integer(c_int) :: n_J, n_K

      integer(c_int) :: integral_is_significant

      real(dp) :: precision_local

      J_ = int(J%number_, c_int)
      K_ = int(K%number_, c_int)

      n_J = int(J%length, c_int)
      n_K = int(K%length, c_int)

      precision_local = this%get_local_eri_precision(precision)

      call get_eri_2c_c(g, &
                        J_, &
                        K_, &
                        precision_local**2, &
                        integral_is_significant, &
                        n_J, &
                        n_K)

      call this%is_integral_significant(g, int(n_J * n_K), int(integral_is_significant), skip)

   end subroutine get_eri_2c_libint


   subroutine get_eri_3c_libint(this, g, J, C, D, precision, skip)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !!
      !!    precision:  (intent in) Double precision real corresponding to the precision value
      !!                to use when calculating the integral. Does not guarantee a precision
      !!                to the given value and should therefore be selected conservatively.
      !!
      !!    skip:       (intent out) If present, this integer will be 1 if Libint decided not to
      !!                calculate the integral; it will be zero otherwise. If it is present, g will
      !!                not be zeroed out if Libint decides not to calculate g. Thus, only pass 'skip'
      !!                to the routine if you wish to avoid zeroing out elements that are negligible.
      !!
      use shell_class, only: shell

      implicit none

      class(libint_eri_library), intent(inout) :: this

      integer, intent(in) :: C, D

      type(shell), intent(in) :: J

      real(dp), dimension(*), intent(out), target :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      integer(c_int) :: J_, C_, D_
      integer(c_int) :: n_J, n_C, n_D

      integer(c_int) :: integral_is_significant

      real(dp) :: precision_local

      J_ = int(J%number_, c_int)
      C_ = int(C, c_int)
      D_ = int(D, c_int)

      n_J = int(J%length, c_int)
      n_C = int(this%shells(C)%length, c_int)
      n_D = int(this%shells(D)%length, c_int)

      precision_local = this%get_local_eri_precision(precision)

      call get_eri_3c_c(g, &
                        J_, &
                        C_, &
                        D_, &
                        precision_local**2, &
                        integral_is_significant, &
                        n_J, &
                        n_C, &
                        n_D)

      call this%is_integral_significant(g, int(n_J * n_C * n_D), int(integral_is_significant), skip)

   end subroutine get_eri_3c_libint


   subroutine prepare_for_ri_libint(this, basis_set, precision, centers)
      !!
      !! Written by Marcus T. Lexander 2022
      !!
      use atomic_center_class, only: atomic_center
      use warning_suppressor, only: do_nothing
      use iso_c_binding, only: c_null_char

      implicit none

      character(len=100), intent(in) :: basis_set
      real(dp), intent(in) :: precision
      type(atomic_center), dimension(:), intent(in) :: centers

      class(libint_eri_library), intent(inout) :: this

      call do_nothing(this)
      call do_nothing(centers(1))

      call prepare_for_ri_c(precision**2, trim(basis_set) // c_null_char)

   end subroutine prepare_for_ri_libint


   subroutine set_eri_precision_libint(this, eri_precision)
      !!
      !! Written by Alexander C. Paul, Dec 2022
      !!
      !! In order to set a precision value for the integral in libint,
      !! it is necessary to provide approximately the squared value of the precision as the input.
      !!
      implicit none

      class(libint_eri_library), intent(inout) :: this
      real(dp), intent(in) :: eri_precision

      this%eri_precision = eri_precision
      call set_eri_precision_c(this%eri_precision**2)

   end subroutine set_eri_precision_libint


end module libint_eri_library_class

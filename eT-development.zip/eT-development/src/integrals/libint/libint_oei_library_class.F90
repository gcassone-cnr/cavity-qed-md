

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module libint_oei_library_class

   !!
   !! Libint one electron integral library class
   !! Written by Marcus T. Lexander 2022
   !!
   !! Extends abstract_oei_library_class to give interface to libint one electron integrals.
   !!

   use parameters, only: dp, angstrom_to_bohr
   use abstract_oei_library_class, only: abstract_oei_library
   use iso_c_binding, only: c_int, c_null_char
   use warning_suppressor, only: do_nothing
   use range_class, only: range_

   implicit none

   type, extends(abstract_oei_library) :: libint_oei_library

   contains

      procedure, public :: update_centers => update_centers_oei_libint

      procedure, public :: get_oei_shell => get_oei_shell_libint

      procedure, public :: get_oei_1der_shell => get_oei_1der_shell_libint

      procedure, public :: get_oei_1der_nuclear_shell => get_oei_1der_nuclear_shell_libint

      procedure, public :: initialize => initialize_libint_oei_library

      procedure, public :: initialize_external_charges_from_point_charges => &
                           initialize_external_charges_from_point_charges_libint

      procedure, public :: initialize_external_charges => initialize_external_charges_libint

      procedure, public :: initialize_external_unit_charges => initialize_external_unit_charges_libint

   end type libint_oei_library

   include "oei_cdef.F90"
   include "libint_initialization_cdef.F90"

   interface libint_oei_library

      procedure :: new_libint_oei_library

   end interface libint_oei_library

contains

   function new_libint_oei_library(oei_precision, &
                                   n_ao, &
                                   n_centers, &
                                   n_sh, &
                                   max_sh_size, &
                                   shells, &
                                   shell_to_center) result(this)
      !!
      !! Written by Marcus T. Lexander 2022
      !!
      implicit none

      type(libint_oei_library) :: this

      real(dp), intent(in) :: oei_precision
      integer, intent(in) :: n_ao, n_sh, max_sh_size, n_centers

      type(range_), dimension(n_sh), intent(in), target :: shells
      integer, dimension(n_sh), intent(in), target :: shell_to_center

      this%n_ao = n_ao
      this%n_sh = n_sh
      this%max_sh_size = max_sh_size
      this%n_centers = n_centers
      this%oei_precision = oei_precision
      this%shells => shells
      this%shell_to_center => shell_to_center

   end function new_libint_oei_library


   subroutine initialize_libint_oei_library(this)
      !!
      !! Written by Eirik F. Kjoenstad, June 2019
      !!
      !! Initialize libint integral engines
      !!
      use memory_manager_class, only: mem

      implicit none

      class(libint_oei_library), intent(inout) :: this

      call initialize_kinetic_c()
      call initialize_nuclear_c()
      call initialize_overlap_c()
      call initialize_dipole_c()
      call initialize_quadrupole_c()

      if (.not. allocated(this%shp_max_overlap)) then
         call mem%alloc(this%shp_max_overlap, this%n_sh, this%n_sh)
         call this%construct_shp_max_overlap()
      end if

   end subroutine initialize_libint_oei_library


   subroutine update_centers_oei_libint(this, centers, n_centers)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      use atomic_center_class, only: atomic_center
      use libint_initialization, only: export_geometry_and_basis_to_libint

      implicit none

      class(libint_oei_library), intent(inout) :: this

      integer, intent(in) :: n_centers

      type(atomic_center), dimension(n_centers), intent(in) :: centers

      call export_geometry_and_basis_to_libint(centers)
      call this%initialize()

   end subroutine update_centers_oei_libint


   subroutine get_oei_shell_libint(this, oei_type, oei, A, B)
      !!
      !! Written by Marcus T. Lexander 2022
      !!
      !! Wrapper to get_oei_c to get oei of shell A and B from libint
      !!
      implicit none

      class(libint_oei_library), intent(inout) :: this

      character(len=*), intent(in) :: oei_type
      real(dp), dimension(:), intent(out), target :: oei

      integer, intent(in) :: A, B

      call do_nothing(this)

      call get_oei_c(trim(oei_type) // c_null_char, oei, int(A, c_int), int(B, c_int))

   end subroutine get_oei_shell_libint


   subroutine get_oei_1der_shell_libint(this, oei_type, oei, A, B)
      !!
      !! Written by Marcus T. Lexander 2022
      !!
      !! Wrapper to get_oei_1der_c to get 1st derivative of oei for shell A and B from libint
      !!
      implicit none

      class(libint_oei_library), intent(inout) :: this

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(:), intent(out), target :: oei

      integer, intent(in) :: A, B

      call do_nothing(this)

      if (trim(oei_type) == 'nuclear') then

         call this%get_oei_1der_nuclear_shell(oei, A, B)

      else

         call get_oei_1der_c(trim(oei_type) // c_null_char, oei, int(A, c_int), int(B, c_int))

      end if

   end subroutine get_oei_1der_shell_libint


   subroutine get_oei_1der_nuclear_shell_libint(this, oei, A, B)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !! Moved to a separate subroutine by Andrea Bianchi, 2023
      !! Updated by Marcus T. Lexander, 2024
      !!
      use parameters

      implicit none

      class(libint_oei_library), intent(inout) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3 &
         * this%n_centers), intent(out), target :: oei

      oei = zero

      call add_nuclear_1der_c(oei, int(A, c_int), int(B, c_int))

   end subroutine get_oei_1der_nuclear_shell_libint


   subroutine initialize_external_charges_from_point_charges_libint(this, pc)
      !!
      !! Written by Sarai D. Folkestad, 2020
      !!
      !! Initializes the external charge engines that are needed for
      !! embedding (QM/MM)
      !!
      use libint_initialization, only: initialize_coulomb_external_charges_c
      use point_charges_class, only: point_charges

      implicit none

      class(libint_oei_library), intent(inout) :: this
      type(point_charges), intent(in) :: pc

      call do_nothing(this)

      call initialize_coulomb_external_charges_c(pc%q, &
                                                 pc%r * angstrom_to_bohr, &
                                                 int(pc%n_charges, kind=c_int))

   end subroutine initialize_external_charges_from_point_charges_libint


   subroutine initialize_external_charges_libint(this, n_charges, positions, charges)
      !!
      !! Written by Sarai D. Folkestad, 2020
      !!
      !! Initializes the external charge engines that are needed for
      !! embedding (QM/MM)
      !!
      use libint_initialization, only: initialize_coulomb_external_charges_c

      implicit none

      class(libint_oei_library), intent(inout) :: this
      integer, intent(in) :: n_charges
      real(dp), dimension(3, n_charges), intent(in) :: positions
      real(dp), dimension(n_charges), intent(in) :: charges

      call do_nothing(this)

      call initialize_coulomb_external_charges_c(charges, &
                                                 positions * angstrom_to_bohr, &
                                                 int(n_charges, kind=c_int))

   end subroutine initialize_external_charges_libint


   subroutine initialize_external_unit_charges_libint(this, n_charges, positions)
      !!
      !! Written by Sarai D. Folkestad, 2020
      !!
      use libint_initialization, only: initialize_coulomb_external_unit_charges_c

      implicit none

      class(libint_oei_library), intent(inout) :: this
      integer, intent(in) :: n_charges
      real(dp), dimension(3, n_charges), intent(in) :: positions

      call do_nothing(this)

      call initialize_coulomb_external_unit_charges_c(positions * angstrom_to_bohr, &
                                                      int(n_charges, kind=c_int))

   end subroutine initialize_external_unit_charges_libint


end module libint_oei_library_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_eri_library_class

   !!
   !! Abstract electron repulsion integral library class
   !! Written by Marcus T. Lexander 2022
   !!
   !! This class contains functions to get eri-shells.
   !! ERI libraries should be implemented to extend this one so that it will slot nicely in to be used in the AO-tool class
   !!

   use parameters
   use atomic_center_class, only: atomic_center
   use shell_class, only: shell

   implicit none

   type, abstract :: abstract_eri_library

      character(len=20) :: name
      real(dp), public :: eri_precision

   contains

      procedure(initialize), deferred, public :: initialize
      procedure(cleanup), deferred, public :: cleanup
      procedure(update_centers), deferred, public :: update_centers

      procedure(get_eri), deferred, public :: get_eri

      procedure(get_eri_1der), deferred, public :: get_eri_1der

      procedure, public :: get_first_order_derivative_wrt_B_giao_eri => &
                           get_first_order_derivative_wrt_B_giao_eri_abstract_eri_library

      procedure, public :: get_eri_2c => get_eri_2c_abstract_eri_library
      procedure, public :: get_eri_3c => get_eri_3c_abstract_eri_library

      procedure, public :: prepare_for_ri => prepare_for_ri_abstract_eri_library

      procedure, public :: get_local_eri_precision => get_local_eri_precision_abstract_eri_library
      procedure, public, nopass :: is_integral_significant => is_integral_significant_abstract_eri_library

      procedure, public :: get_eri_precision
      procedure, public :: set_eri_precision => set_eri_precision_abstract_eri_library

   end type

   abstract interface

      subroutine initialize(this)

         import abstract_eri_library

         implicit none

         class(abstract_eri_library), intent(inout) :: this

      end subroutine initialize


      subroutine cleanup(this)

         import abstract_eri_library

         implicit none

         class(abstract_eri_library), intent(inout) :: this

      end subroutine cleanup


      subroutine update_centers(this, centers, n_centers)

         import abstract_eri_library, atomic_center

         implicit none

         class(abstract_eri_library), intent(inout) :: this

         integer, intent(in) :: n_centers

         type(atomic_center), dimension(n_centers), intent(in) :: centers

      end subroutine update_centers


      subroutine get_eri(this, g, A, B, C, D, precision, skip)

         import abstract_eri_library
         import dp

         implicit none

         class(abstract_eri_library), intent(inout) :: this

         real(dp), dimension(*), intent(out) :: g

         integer, intent(in) :: A, B, C, D

         real(dp), intent(in), optional :: precision
         integer, intent(out), optional :: skip

      end subroutine get_eri


      subroutine get_first_order_derivative_wrt_B_giao_eri(this, g, A, B, C, D, precision, skip)

         import abstract_eri_library
         import dp

         implicit none

         class(abstract_eri_library), intent(inout) :: this

         real(dp), dimension(*), intent(out) :: g

         integer, intent(in) :: A, B, C, D

         real(dp), intent(in), optional :: precision
         integer, intent(out), optional :: skip

      end subroutine get_first_order_derivative_wrt_B_giao_eri


      subroutine get_eri_1der(this, g, A, B, C, D, precision, skip)

         import abstract_eri_library
         import dp

         implicit none

         class(abstract_eri_library), intent(inout) :: this

         real(dp), dimension(*), intent(out), target :: g

         integer, intent(in) :: A, B, C, D

         real(dp), intent(in), optional :: precision
         integer, intent(out), optional :: skip

      end subroutine get_eri_1der


      subroutine get_eri_2c(this, g, J, K, precision, skip)

         import abstract_eri_library
         import dp
         import shell

         implicit none

         class(abstract_eri_library), intent(inout) :: this

         type(shell), intent(in) :: J, K

         real(dp), dimension(J%length * K%length), intent(out), target :: g

         real(dp), intent(in), optional :: precision
         integer, intent(out), optional :: skip

      end subroutine get_eri_2c


      subroutine get_eri_3c(this, g, J, C, D, precision, skip)

         import abstract_eri_library
         import dp
         import shell

         implicit none

         class(abstract_eri_library), intent(inout) :: this

         real(dp), dimension(*), intent(out), target :: g

         type(shell), intent(in) :: J
         integer, intent(in) :: C, D

         real(dp), intent(in), optional :: precision
         integer, intent(out), optional :: skip

      end subroutine get_eri_3c


      subroutine prepare_for_ri(this, basis_set, eri_precision, centers)

         import abstract_eri_library
         import atomic_center
         import dp

         implicit none

         character(len=100), intent(in) :: basis_set
         real(dp), intent(in) :: eri_precision
         type(atomic_center), dimension(:), intent(in) :: centers

         class(abstract_eri_library), intent(inout) :: this

      end subroutine prepare_for_ri

   end interface

contains

   pure function get_local_eri_precision_abstract_eri_library(this, precision) result(precision_local)
      !!
      !! Get local ERI precision
      !! Written by Sarai D. Folkestad, Sep 2021
      !!
      implicit none

      class(abstract_eri_library), intent(in) :: this
      real(dp), intent(in), optional :: precision

      real(dp) :: precision_local

      if (present(precision)) then

         precision_local = precision

      else

         precision_local = this%eri_precision

      end if

   end function get_local_eri_precision_abstract_eri_library


   subroutine is_integral_significant_abstract_eri_library(g, size_, integral_is_significant, skip)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Checks if integral is zero using the is_zero integer that is returned
      !! by the integral library:
      !! is_zero == 1 : Integral is zero
      !! is_zero == 0 : Integral is not zero
      !!
      !! To avoid zeroing out and to handle the exception on the outside
      !! the optional skip can be returned which is 1 (true) if the integral is zero.
      !!
      use array_initialization, only: zero_array

      implicit none

      integer, intent(out), optional :: skip
      integer, intent(in) :: integral_is_significant
      integer, intent(in) :: size_
      real(dp), dimension(size_), intent(inout) :: g

      if (present(skip)) then

         if (integral_is_significant == 0) then
            skip = 1
         else
            skip = 0
         end if

      else

         if (integral_is_significant == 0) call zero_array(g, size_)

      end if

   end subroutine is_integral_significant_abstract_eri_library


   pure function get_eri_precision(this) result(eri_precision)
      !!
      !! Get eri precision
      !! Written by Alexander C. Paul, Dec 2022
      !!
      implicit none

      class(abstract_eri_library), intent(in) :: this
      real(dp) :: eri_precision

      eri_precision = this%eri_precision

   end function get_eri_precision


   subroutine set_eri_precision_abstract_eri_library(this, eri_precision)
      !!
      !! Written by Alexander C. Paul, Dec 2022
      !!
      implicit none

      class(abstract_eri_library), intent(inout) :: this
      real(dp), intent(in) :: eri_precision

      this%eri_precision = eri_precision

   end subroutine set_eri_precision_abstract_eri_library


   subroutine get_first_order_derivative_wrt_B_giao_eri_abstract_eri_library(this, &
                                                                             g, &
                                                                             A, &
                                                                             B, &
                                                                             C, &
                                                                             D, &
                                                                             precision, &
                                                                             skip)
      !!
      !! Written by Alberto Barlini, November 2022
      !!
      use global_out, only: output
      use warning_suppressor, only: do_nothing

      implicit none

      class(abstract_eri_library), intent(inout) :: this

      integer, intent(in) :: A, B, C, D

      real(dp), dimension(*), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      call output%error_msg('The "first_order_derivative_wrt_B_giao" integral is not available in (a0)', &
                            chars=[this%name])

      call do_nothing(this)
      call do_nothing(g(1))
      call do_nothing(precision)
      call do_nothing(skip)
      call do_nothing(A)
      call do_nothing(B)
      call do_nothing(C)
      call do_nothing(D)

   end subroutine get_first_order_derivative_wrt_B_giao_eri_abstract_eri_library


   subroutine get_eri_2c_abstract_eri_library(this, g, J, K, precision, skip)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      use shell_class, only: shell
      use global_out, only: output
      use warning_suppressor, only: do_nothing

      implicit none

      class(abstract_eri_library), intent(inout) :: this
      type(shell), intent(in) :: J, K

      real(dp), dimension(J%length * K%length), intent(out), target :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      call output%error_msg('The "ERI 2 center" integral is not available in (a0)', chars=[this%name])

      call do_nothing(this)

      call do_nothing(J)
      call do_nothing(K)
      call do_nothing(g(1))
      call do_nothing(precision)
      call do_nothing(skip)

   end subroutine get_eri_2c_abstract_eri_library


   subroutine get_eri_3c_abstract_eri_library(this, g, J, C, D, precision, skip)
      !!
      !! Written by Andrea Bianchi, 2022
      !!
      use shell_class, only: shell
      use global_out, only: output
      use warning_suppressor, only: do_nothing

      implicit none

      class(abstract_eri_library), intent(inout) :: this

      integer, intent(in) :: C, D

      type(shell), intent(in) :: J

      real(dp), dimension(*), intent(out), target :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      call output%error_msg('The "ERI 3 center" integral is not available in (a0)', chars=[this%name])

      call do_nothing(this)
      call do_nothing(C)
      call do_nothing(D)

      call do_nothing(J)
      call do_nothing(g(1))
      call do_nothing(precision)
      call do_nothing(skip)

   end subroutine get_eri_3c_abstract_eri_library


   subroutine prepare_for_ri_abstract_eri_library(this, basis_set, precision, centers)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      use global_out, only: output
      use warning_suppressor, only: do_nothing

      implicit none

      class(abstract_eri_library), intent(inout) :: this

      character(len=100), intent(in) :: basis_set
      real(dp), intent(in) :: precision
      type(atomic_center), dimension(:), intent(in) :: centers

      call output%error_msg('The "RI" integrals are not available in (a0)', chars=[this%name])

      call do_nothing(this)
      call do_nothing(basis_set)
      call do_nothing(precision)
      call do_nothing(centers(1))

   end subroutine prepare_for_ri_abstract_eri_library


end module abstract_eri_library_class

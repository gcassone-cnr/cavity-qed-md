! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module phasedint_oei_library_class

   !!
   !! PhasedInt one electron integral library class
   !! Written by Andrea Bianchi 2023
   !!
   !! Extends abstract_oei_library_class to give interface to phasedint one electron integrals.
   !!

   use iso_c_binding, only: c_int64_t, c_bool

   use parameters

   use abstract_oei_library_class, only: abstract_oei_library
   use phasedint_tool_class, only: phasedint_tool
   use memory_manager_class, only: mem
   use range_class, only: range_
   use atomic_center_class, only: atomic_center
   use global_out, only: output

   implicit none

   type, extends(abstract_oei_library) :: phasedint_oei_library

      type(phasedint_tool) :: phint

   contains

      procedure, public :: cleanup => cleanup_oei_phasedint
      procedure, public :: update_centers => update_centers_oei_phasedint

      procedure, public :: get_oei_shell => get_oei_shell_phasedint
      procedure, public :: get_oei_1der_shell => get_oei_1der_shell_phasedint

      procedure, public :: initialize_external_charges_from_point_charges => &
                           initialize_external_charges_from_point_charges_phasedint
      procedure, public :: initialize_external_charges => initialize_external_charges_phasedint
      procedure, public :: initialize_external_unit_charges => initialize_external_unit_charges_phasedint

      procedure, private :: get_oei_shell_overlap => get_oei_shell_overlap_phasedint
      procedure, private :: get_oei_shell_hamiltonian => get_oei_shell_hamiltonian_phasedint
      procedure, private :: get_oei_shell_dipole => get_oei_shell_dipole_phasedint
      procedure, private :: get_oei_shell_quadrupole => get_oei_shell_quadrupole_phasedint
      procedure, private :: get_oei_shell_momentum => get_oei_shell_momentum_phasedint
      procedure, private :: get_oei_shell_angular_momentum => get_oei_shell_angular_momentum_phasedint
      procedure, private :: get_oei_shell_electrostatic_potential => &
                            get_oei_shell_electrostatic_potential_phasedint
      procedure, private :: get_oei_shell_electrostatic_potential_unit => &
                            get_oei_shell_electrostatic_potential_unit_phasedint

      procedure, private :: get_oei_shell_1Bder_giao_overlap => get_oei_shell_1Bder_giao_overlap_phasedint
      procedure, private :: get_oei_shell_1Bder_giao_ang_mom => get_oei_shell_1Bder_giao_ang_mom_phasedint
      procedure, private :: get_oei_shell_1Bder_giao_kinetic => get_oei_shell_1Bder_giao_kinetic_phasedint
      procedure, private :: get_oei_shell_1Bder_giao_nuclear => get_oei_shell_1Bder_giao_nuclear_phasedint
      procedure, private :: get_oei_shell_1Bder_giao_paramagnetic_spin_orbit => &
                            get_oei_shell_1Bder_giao_paramagnetic_spin_orbit_phasedint
      procedure, private :: get_oei_shell_giao_paramagnetic_spin_orbit => &
                            get_oei_shell_giao_paramagnetic_spin_orbit_phasedint
      procedure, private :: get_oei_shell_giao_diamagnetic => get_oei_shell_giao_diamagnetic_phasedint

      procedure, private :: get_oei_1der_overlap_shell => get_oei_1der_overlap_shell_phasedint
      procedure, private :: get_oei_1der_kinetic_shell => get_oei_1der_kinetic_shell_phasedint
      procedure, private :: get_oei_1der_nuclear_shell => get_oei_1der_nuclear_shell_phasedint
      procedure, private :: get_oei_1der_dipole_shell => get_oei_1der_dipole_shell_phasedint

   end type phasedint_oei_library

   interface phasedint_oei_library

      procedure :: new_phasedint_oei_library

   end interface phasedint_oei_library

   interface

      include "phasedint.f90"

   end interface

contains

   function new_phasedint_oei_library(oei_precision, &
                                      n_ao, &
                                      centers, &
                                      n_centers, &
                                      n_sh, &
                                      max_sh_size, &
                                      shells, &
                                      shell_to_center) result(this)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      type(phasedint_oei_library) :: this

      real(dp), intent(in) :: oei_precision

      integer, intent(in) :: n_ao, n_centers, n_sh, max_sh_size
      type(atomic_center), dimension(n_centers), intent(in), target :: centers
      type(range_), dimension(n_sh), intent(in), target :: shells
      integer, dimension(n_sh), intent(in), target :: shell_to_center

      this%n_ao = n_ao
      this%n_sh = n_sh
      this%max_sh_size = max_sh_size
      this%n_centers = n_centers
      this%oei_precision = oei_precision
      this%shells => shells
      this%shell_to_center => shell_to_center

      this%phint = phasedint_tool(centers, n_centers, n_sh)

   end function new_phasedint_oei_library


   subroutine cleanup_oei_phasedint(this)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(inout) :: this

      if (allocated(this%shp_max_overlap)) call mem%dealloc(this%shp_max_overlap)

      call this%phint%cleanup()

   end subroutine cleanup_oei_phasedint


   subroutine update_centers_oei_phasedint(this, centers, n_centers)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(inout) :: this

      integer, intent(in) :: n_centers

      type(atomic_center), dimension(n_centers), intent(in) :: centers

      call this%phint%export_centers(centers, n_centers)

      call this%initialize()

   end subroutine update_centers_oei_phasedint


   subroutine initialize_external_charges_from_point_charges_phasedint(this, pc)
      !!
      !! Written by Andrea Bianchi, 2022
      !!
      !! Initializes the external charge engines that are needed for
      !! embedding (QM/MM)
      !!
      use point_charges_class, only: point_charges

      implicit none

      class(phasedint_oei_library), intent(inout) :: this
      type(point_charges), intent(in) :: pc

      if (allocated(this%phint%point_charge_centers)) then
         call mem%dealloc(this%phint%point_charge_centers)
      end if

      if (allocated(this%phint%point_charge_charges)) then
         call mem%dealloc(this%phint%point_charge_charges)
      end if

      this%phint%n_point_charges = int(pc%n_charges)

      call mem%alloc(this%phint%point_charge_centers, 3, pc%n_charges)
      call mem%alloc(this%phint%point_charge_charges, pc%n_charges)

      this%phint%point_charge_centers = pc%r * angstrom_to_bohr
      this%phint%point_charge_charges = pc%q

   end subroutine initialize_external_charges_from_point_charges_phasedint


   subroutine initialize_external_charges_phasedint(this, n_charges, positions, charges)
      !!
      !! Written by Andrea Bianchi, 2022
      !!
      !! Initializes the external charge engines that are needed for
      !! embedding (QM/MM)
      !!
      implicit none

      class(phasedint_oei_library), intent(inout) :: this
      integer, intent(in) :: n_charges
      real(dp), dimension(3, n_charges), intent(in) :: positions
      real(dp), dimension(n_charges), intent(in) :: charges

      if (allocated(this%phint%point_charge_centers)) then
         call mem%dealloc(this%phint%point_charge_centers)
      end if

      if (allocated(this%phint%point_charge_charges)) then
         call mem%dealloc(this%phint%point_charge_charges)
      end if

      this%phint%n_point_charges = int(n_charges)

      call mem%alloc(this%phint%point_charge_centers, 3, n_charges)
      call mem%alloc(this%phint%point_charge_charges, n_charges)

      this%phint%point_charge_centers = positions * angstrom_to_bohr
      this%phint%point_charge_charges = charges

   end subroutine initialize_external_charges_phasedint


   subroutine initialize_external_unit_charges_phasedint(this, n_charges, positions)
      !!
      !! Written by Andrea Bianchi, 2022
      !!
      !! Initializes the external charge engines that are needed for
      !! embedding (QM/MM)
      !!
      implicit none

      class(phasedint_oei_library), intent(inout) :: this
      integer, intent(in) :: n_charges
      real(dp), dimension(3, n_charges), intent(in) :: positions

      if (allocated(this%phint%unit_charge_centers)) then
         call mem%dealloc(this%phint%unit_charge_centers)
         call mem%dealloc(this%phint%unit_charge_charges)
      end if

      this%phint%n_unit_charges = n_charges

      call mem%alloc(this%phint%unit_charge_centers, 3, n_charges)
      call mem%alloc(this%phint%unit_charge_charges, n_charges)

      this%phint%unit_charge_centers = positions * angstrom_to_bohr
      this%phint%unit_charge_charges = one

   end subroutine initialize_external_unit_charges_phasedint


   subroutine get_oei_shell_phasedint(this, oei_type, oei, A, B)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      !! Computes the one-electron AO integral matrix x using
      !! the x_ABk contributions to x for the shells A and B, where k
      !! denotes the components (e.g., x, y, z, for dipole integrals)
      !!
      implicit none

      class(phasedint_oei_library), intent(inout) :: this

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(:), intent(out), target :: oei

      integer, intent(in) :: A, B

      select case (oei_type)

         case ("overlap")

            call this%get_oei_shell_overlap(oei, A, B)

         case ("hamiltonian")

            call this%get_oei_shell_hamiltonian(oei, A, B)

         case ("dipole")

            call this%get_oei_shell_dipole(oei, A, B)

         case ("quadrupole")

            call this%get_oei_shell_quadrupole(oei, A, B)

         case ("momentum")

            call this%get_oei_shell_momentum(oei, A, B)

         case ("angular momentum")

            call this%get_oei_shell_angular_momentum(oei, A, B)

         case ("electrostatic potential")

            call this%get_oei_shell_electrostatic_potential(oei, A, B)

         case ("electrostatic potential unit")

            call this%get_oei_shell_electrostatic_potential_unit(oei, A, B)

         case ("first-order derivative wrt B giao overlap")

            call this%get_oei_shell_1Bder_giao_overlap(oei, A, B)

         case ("first-order derivative wrt B giao angular momentum")

            call this%get_oei_shell_1Bder_giao_ang_mom(oei, A, B)

         case ("first-order derivative wrt B giao kinetic energy")

            call this%get_oei_shell_1Bder_giao_kinetic(oei, A, B)

         case ("first-order derivative wrt B giao nuclear potential")

            call this%get_oei_shell_1Bder_giao_nuclear(oei, A, B)

         case ("giao paramagnetic spin-orbit")

            call this%get_oei_shell_giao_paramagnetic_spin_orbit(oei, A, B)

         case ("first-order derivative wrt B giao paramagnetic spin-orbit")

            call this%get_oei_shell_1Bder_giao_paramagnetic_spin_orbit(oei, A, B)

         case ("giao diamagnetic")

            call this%get_oei_shell_giao_diamagnetic(oei, A, B)

         case default

            call output%error_msg( &
               "Could not recognize the one-electron integral in the phasedint interface." // &
               " Please change integral program or add integral to the phasedint interface.")

      end select

   end subroutine get_oei_shell_phasedint


   subroutine get_oei_shell_overlap_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length), intent(out) :: oei

      logical(c_bool) :: skipped

      call get_shell_overlap(oei, &
                             this%phint%shell_angmom(A), &
                             this%phint%shell_n_prim(A), &
                             1_c_int64_t, &
                             this%phint%shell_coeffs(:, A), &
                             this%phint%shell_exponents(:, A), &
                             this%phint%shell_coordinates(:, A), &
                             this%phint%shell_angmom(B), &
                             this%phint%shell_n_prim(B), &
                             1_c_int64_t, &
                             this%phint%shell_coeffs(:, B), &
                             this%phint%shell_exponents(:, B), &
                             this%phint%shell_coordinates(:, B), &
                             this%phint%cartesian, &
                             this%oei_precision, &
                             one, &
                             skipped)

   end subroutine get_oei_shell_overlap_phasedint


   subroutine get_oei_shell_hamiltonian_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length), intent(out) :: oei

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length) :: oei_kinetic

      logical(c_bool) :: skipped

      call get_shell_kinetic(oei_kinetic, &
                             this%phint%shell_angmom(A), &
                             this%phint%shell_n_prim(A), &
                             1_c_int64_t, &
                             this%phint%shell_coeffs(:, A), &
                             this%phint%shell_exponents(:, A), &
                             this%phint%shell_coordinates(:, A), &
                             this%phint%shell_angmom(B), &
                             this%phint%shell_n_prim(B), &
                             1_c_int64_t, &
                             this%phint%shell_coeffs(:, B), &
                             this%phint%shell_exponents(:, B), &
                             this%phint%shell_coordinates(:, B), &
                             this%phint%cartesian, &
                             this%oei_precision, &
                             one, &
                             skipped)

      call get_shell_ep(oei, &
                        this%phint%shell_angmom(A), &
                        this%phint%shell_n_prim(A), &
                        1_c_int64_t, &
                        this%phint%shell_coeffs(:, A), &
                        this%phint%shell_exponents(:, A), &
                        this%phint%shell_coordinates(:, A), &
                        this%phint%shell_angmom(B), &
                        this%phint%shell_n_prim(B), &
                        1_c_int64_t, &
                        this%phint%shell_coeffs(:, B), &
                        this%phint%shell_exponents(:, B), &
                        this%phint%shell_coordinates(:, B), &
                        this%phint%cartesian, &
                        this%oei_precision, &
                        one, &
                        skipped, &
                        int(this%phint%n_centers, c_int64_t), &
                        this%phint%centers_charge, &
                        this%phint%centers_coordinates)

      ! add kinetic and nuclear
      call daxpy(this%shells(A)%length * this%shells(B)%length, one, oei_kinetic, 1, oei, 1)

   end subroutine get_oei_shell_hamiltonian_phasedint


   subroutine get_oei_shell_dipole_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      logical(c_bool) :: skipped

      call get_shell_dipole(oei, &
                            this%phint%shell_angmom(A), &
                            this%phint%shell_n_prim(A), &
                            1_c_int64_t, &
                            this%phint%shell_coeffs(:, A), &
                            this%phint%shell_exponents(:, A), &
                            this%phint%shell_coordinates(:, A), &
                            this%phint%shell_angmom(B), &
                            this%phint%shell_n_prim(B), &
                            1_c_int64_t, &
                            this%phint%shell_coeffs(:, B), &
                            this%phint%shell_exponents(:, B), &
                            this%phint%shell_coordinates(:, B), &
                            this%phint%cartesian, &
                            this%oei_precision, &
                            - one, &
                            skipped)

   end subroutine get_oei_shell_dipole_phasedint


   subroutine get_oei_shell_quadrupole_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 6), intent(out), target :: oei

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length, 3, 3) :: oei_quadrupole
      real(dp), dimension(:, :), pointer :: oei_p

      integer :: i, j

      logical(c_bool) :: skipped

      call get_shell_quadrupole(oei_quadrupole, &
                                this%phint%shell_angmom(A), &
                                this%phint%shell_n_prim(A), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, A), &
                                this%phint%shell_exponents(:, A), &
                                this%phint%shell_coordinates(:, A), &
                                this%phint%shell_angmom(B), &
                                this%phint%shell_n_prim(B), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, B), &
                                this%phint%shell_exponents(:, B), &
                                this%phint%shell_coordinates(:, B), &
                                this%phint%cartesian, &
                                this%oei_precision, &
                                one, &
                                skipped)

      oei_p(1:this%shells(A)%length * this%shells(B)%length, 1:6) => oei

      ! phasedint gives the 3x3 matrix, eT uses only the upper triangular part
      do i = 1, 3
         do j = i, 3

            oei_p(:, (i - 1) * (2 * 3 - i) / 2 + j) = - oei_quadrupole(:, i, j)

         end do
      end do

   end subroutine get_oei_shell_quadrupole_phasedint


   subroutine get_oei_shell_momentum_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      logical(c_bool) :: skipped

      call get_shell_overlap_dR_A(oei, &
                                  this%phint%shell_angmom(A), &
                                  this%phint%shell_n_prim(A), &
                                  1_c_int64_t, &
                                  this%phint%shell_coeffs(:, A), &
                                  this%phint%shell_exponents(:, A), &
                                  this%phint%shell_coordinates(:, A), &
                                  this%phint%shell_angmom(B), &
                                  this%phint%shell_n_prim(B), &
                                  1_c_int64_t, &
                                  this%phint%shell_coeffs(:, B), &
                                  this%phint%shell_exponents(:, B), &
                                  this%phint%shell_coordinates(:, B), &
                                  this%phint%cartesian, &
                                  this%oei_precision, &
                                  one, &
                                  skipped)

   end subroutine get_oei_shell_momentum_phasedint


   subroutine get_oei_shell_angular_momentum_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      logical(c_bool) :: skipped

      call get_shell_r_cross_ip(oei, &
                                this%phint%shell_angmom(A), &
                                this%phint%shell_n_prim(A), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, A), &
                                this%phint%shell_exponents(:, A), &
                                this%phint%shell_coordinates(:, A), &
                                this%phint%shell_angmom(B), &
                                this%phint%shell_n_prim(B), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, B), &
                                this%phint%shell_exponents(:, B), &
                                this%phint%shell_coordinates(:, B), &
                                this%phint%cartesian, &
                                this%oei_precision, &
                                one, &
                                skipped)


   end subroutine get_oei_shell_angular_momentum_phasedint


   subroutine get_oei_shell_electrostatic_potential_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(inout) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length), intent(out) :: oei

      logical(c_bool) :: skipped

      call get_shell_ep(oei, &
                        this%phint%shell_angmom(A), &
                        this%phint%shell_n_prim(A), &
                        1_c_int64_t, &
                        this%phint%shell_coeffs(:, A), &
                        this%phint%shell_exponents(:, A), &
                        this%phint%shell_coordinates(:, A), &
                        this%phint%shell_angmom(B), &
                        this%phint%shell_n_prim(B), &
                        1_c_int64_t, &
                        this%phint%shell_coeffs(:, B), &
                        this%phint%shell_exponents(:, B), &
                        this%phint%shell_coordinates(:, B), &
                        this%phint%cartesian, &
                        this%oei_precision, &
                        one, &
                        skipped, &
                        this%phint%n_point_charges, &
                        this%phint%point_charge_charges, &
                        this%phint%point_charge_centers)

   end subroutine get_oei_shell_electrostatic_potential_phasedint


   subroutine get_oei_shell_electrostatic_potential_unit_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(inout) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length), intent(out) :: oei

      logical(c_bool) :: skipped

      call get_shell_ep(oei, &
                        this%phint%shell_angmom(A), &
                        this%phint%shell_n_prim(A), &
                        1_c_int64_t, &
                        this%phint%shell_coeffs(:, A), &
                        this%phint%shell_exponents(:, A), &
                        this%phint%shell_coordinates(:, A), &
                        this%phint%shell_angmom(B), &
                        this%phint%shell_n_prim(B), &
                        1_c_int64_t, &
                        this%phint%shell_coeffs(:, B), &
                        this%phint%shell_exponents(:, B), &
                        this%phint%shell_coordinates(:, B), &
                        this%phint%cartesian, &
                        this%oei_precision, &
                        one, &
                        skipped, &
                        this%phint%n_unit_charges, &
                        this%phint%unit_charge_charges, &
                        this%phint%unit_charge_centers)

   end subroutine get_oei_shell_electrostatic_potential_unit_phasedint


   subroutine get_oei_1der_shell_phasedint(this, oei_type, oei, A, B)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      !! Computes the one-electron AO integral matrix x using
      !! the x_ABk contributions to x for the shells A and B, where k
      !! denotes the components (e.g., x, y, z, for dipole integrals)
      !!

      implicit none

      class(phasedint_oei_library), intent(inout) :: this

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(:), intent(out), target :: oei

      integer, intent(in) :: A, B

      select case (oei_type)

         case ("overlap")

            call this%get_oei_1der_overlap_shell(oei, A, B)

         case ("kinetic")

            call this%get_oei_1der_kinetic_shell(oei, A, B)

         case ("nuclear")

            call this%get_oei_1der_nuclear_shell(oei, A, B)

         case ("dipole")

            call this%get_oei_1der_dipole_shell(oei, A, B)

         case default

            call output%error_msg( &
               "Could not recognize the one-electron integral in the phasedint interface." // &
               " Please change integral program or add integral to the phasedint interface.")

      end select

   end subroutine get_oei_1der_shell_phasedint


   subroutine get_oei_1der_overlap_shell_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 6), intent(out), target :: oei

      real(dp), dimension(:, :, :, :), pointer :: oei_p

      logical(c_bool) :: skipped

      oei_p(1:this%shells(A)%length, &
            1:this%shells(B)%length, &
            1:3, &
            1:2) => oei(1:this%shells(A)%length * this%shells(B)%length * 6)

      call get_shell_overlap_dR_A(oei, &
                                  this%phint%shell_angmom(A), &
                                  this%phint%shell_n_prim(A), &
                                  1_c_int64_t, &
                                  this%phint%shell_coeffs(:, A), &
                                  this%phint%shell_exponents(:, A), &
                                  this%phint%shell_coordinates(:, A), &
                                  this%phint%shell_angmom(B), &
                                  this%phint%shell_n_prim(B), &
                                  1_c_int64_t, &
                                  this%phint%shell_coeffs(:, B), &
                                  this%phint%shell_exponents(:, B), &
                                  this%phint%shell_coordinates(:, B), &
                                  this%phint%cartesian, &
                                  this%oei_precision, &
                                  one, &
                                  skipped)

      call dcopy(this%shells(A)%length * this%shells(B)%length * 3, &
                 - oei_p(:, :, :, 1), &
                 1, &
                 oei_p(:, :, :, 2), &
                 1)

   end subroutine get_oei_1der_overlap_shell_phasedint


   subroutine get_oei_1der_kinetic_shell_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 6), intent(out), target :: oei

      real(dp), dimension(:, :, :, :), pointer :: oei_p

      logical(c_bool) :: skipped

      oei_p(1:this%shells(A)%length, &
            1:this%shells(B)%length, &
            1:3, &
            1:2) => oei(1:this%shells(A)%length * this%shells(B)%length * 6)

      call get_shell_kinetic_dR_A(oei, &
                                  this%phint%shell_angmom(A), &
                                  this%phint%shell_n_prim(A), &
                                  1_c_int64_t, &
                                  this%phint%shell_coeffs(:, A), &
                                  this%phint%shell_exponents(:, A), &
                                  this%phint%shell_coordinates(:, A), &
                                  this%phint%shell_angmom(B), &
                                  this%phint%shell_n_prim(B), &
                                  1_c_int64_t, &
                                  this%phint%shell_coeffs(:, B), &
                                  this%phint%shell_exponents(:, B), &
                                  this%phint%shell_coordinates(:, B), &
                                  this%phint%cartesian, &
                                  this%oei_precision, &
                                  one, &
                                  skipped)

      call dcopy(this%shells(A)%length * this%shells(B)%length * 3, &
                 - oei_p(:, :, :, 1), &
                 1, &
                 oei_p(:, :, :, 2), &
                 1)

   end subroutine get_oei_1der_kinetic_shell_phasedint


   subroutine get_oei_1der_nuclear_shell_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      use array_initialization, only: zero_array
      use reordering_r, only: sort_to_213

      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3 &
         * this%n_centers), intent(out), target :: oei

      real(dp), dimension(this%shells(A)%length, this%shells(B)%length, 3) :: oei_buf
      real(dp), dimension(this%shells(B)%length, this%shells(A)%length, 3) :: oei_buf_rev

      real(dp), dimension(:, :, :, :), pointer :: oei_p

      integer :: i

      logical(c_bool) :: skipped

      oei_p(1:this%shells(A)%length, &
            1:this%shells(B)%length, &
            1:3, &
            1:this%n_centers) => oei(1:this%shells(A)%length * this%shells(B)%length * 3 * this%n_centers)

      call zero_array(oei_p, this%shells(A)%length * this%shells(B)%length * 3 * this%n_centers)

      do i = 1, this%n_centers

         call get_shell_ep_dR_A(oei_buf, &
                                this%phint%shell_angmom(A), &
                                this%phint%shell_n_prim(A), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, A), &
                                this%phint%shell_exponents(:, A), &
                                this%phint%shell_coordinates(:, A), &
                                this%phint%shell_angmom(B), &
                                this%phint%shell_n_prim(B), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, B), &
                                this%phint%shell_exponents(:, B), &
                                this%phint%shell_coordinates(:, B), &
                                this%phint%cartesian, &
                                this%oei_precision, &
                                - one, &
                                skipped, &
                                1_c_int64_t, &
                                [this%phint%centers_charge(i)], &
                                this%phint%centers_coordinates(:, i))

         call get_shell_ep_dR_A(oei_buf_rev, &
                                this%phint%shell_angmom(B), &
                                this%phint%shell_n_prim(B), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, B), &
                                this%phint%shell_exponents(:, B), &
                                this%phint%shell_coordinates(:, B), &
                                this%phint%shell_angmom(A), &
                                this%phint%shell_n_prim(A), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, A), &
                                this%phint%shell_exponents(:, A), &
                                this%phint%shell_coordinates(:, A), &
                                this%phint%cartesian, &
                                this%oei_precision, &
                                - one, &
                                skipped, &
                                1_c_int64_t, &
                                [this%phint%centers_charge(i)], &
                                this%phint%centers_coordinates(:, i))

         call daxpy(this%shells(A)%length * this%shells(B)%length * 3, one, oei_buf, 1, oei_p(:, :, :, i), 1)

         call sort_to_213(oei_buf_rev, oei_buf, this%shells(B)%length, this%shells(A)%length, 3)

         call daxpy(this%shells(A)%length * this%shells(B)%length * 3, one, oei_buf, 1, oei_p(:, :, :, i), 1)

      end do

      call get_shell_ep_dR_A(oei_buf, &
                             this%phint%shell_angmom(A), &
                             this%phint%shell_n_prim(A), &
                             1_c_int64_t, &
                             this%phint%shell_coeffs(:, A), &
                             this%phint%shell_exponents(:, A), &
                             this%phint%shell_coordinates(:, A), &
                             this%phint%shell_angmom(B), &
                             this%phint%shell_n_prim(B), &
                             1_c_int64_t, &
                             this%phint%shell_coeffs(:, B), &
                             this%phint%shell_exponents(:, B), &
                             this%phint%shell_coordinates(:, B), &
                             this%phint%cartesian, &
                             this%oei_precision, &
                             - one, &
                             skipped, &
                             int(this%phint%n_centers, c_int64_t), &
                             this%phint%centers_charge, &
                             this%phint%centers_coordinates)

      call get_shell_ep_dR_A(oei_buf_rev, &
                             this%phint%shell_angmom(B), &
                             this%phint%shell_n_prim(B), &
                             1_c_int64_t, &
                             this%phint%shell_coeffs(:, B), &
                             this%phint%shell_exponents(:, B), &
                             this%phint%shell_coordinates(:, B), &
                             this%phint%shell_angmom(A), &
                             this%phint%shell_n_prim(A), &
                             1_c_int64_t, &
                             this%phint%shell_coeffs(:, A), &
                             this%phint%shell_exponents(:, A), &
                             this%phint%shell_coordinates(:, A), &
                             this%phint%cartesian, &
                             this%oei_precision, &
                             - one, &
                             skipped, &
                             int(this%phint%n_centers, c_int64_t), &
                             this%phint%centers_charge, &
                             this%phint%centers_coordinates)

      call daxpy(this%shells(A)%length * this%shells(B)%length * 3, &
                 - one, &
                 oei_buf, &
                 1, &
                 oei_p(:, :, :, this%shell_to_center(A)), &
                 1)

      call sort_to_213(oei_buf_rev, oei_buf, this%shells(B)%length, this%shells(A)%length, 3)

      call daxpy(this%shells(A)%length * this%shells(B)%length * 3, &
                 - one, &
                 oei_buf, &
                 1, &
                 oei_p(:, :, :, this%shell_to_center(B)), &
                 1)


   end subroutine get_oei_1der_nuclear_shell_phasedint


   subroutine get_oei_1der_dipole_shell_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length, 3, 3), intent(out) :: oei

      logical(c_bool) :: skipped

      if (this%shp_on_same_atom(A, B)) then

         oei(:, :, :) = zero

         call get_shell_overlap(oei, &
                                this%phint%shell_angmom(A), &
                                this%phint%shell_n_prim(A), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, A), &
                                this%phint%shell_exponents(:, A), &
                                this%phint%shell_coordinates(:, A), &
                                this%phint%shell_angmom(B), &
                                this%phint%shell_n_prim(B), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, B), &
                                this%phint%shell_exponents(:, B), &
                                this%phint%shell_coordinates(:, B), &
                                this%phint%cartesian, &
                                this%oei_precision, &
                                - one, &
                                skipped)

         call dcopy(this%shells(A)%length * this%shells(B)%length, oei(:, 1, 1), 1, oei(:, 2, 2), 1)
         call dcopy(this%shells(A)%length * this%shells(B)%length, oei(:, 1, 1), 1, oei(:, 3, 3), 1)

      else

         call get_shell_dipole_dR_B(oei, &
                                    this%phint%shell_angmom(A), &
                                    this%phint%shell_n_prim(A), &
                                    1_c_int64_t, &
                                    this%phint%shell_coeffs(:, A), &
                                    this%phint%shell_exponents(:, A), &
                                    this%phint%shell_coordinates(:, A), &
                                    this%phint%shell_angmom(B), &
                                    this%phint%shell_n_prim(B), &
                                    1_c_int64_t, &
                                    this%phint%shell_coeffs(:, B), &
                                    this%phint%shell_exponents(:, B), &
                                    this%phint%shell_coordinates(:, B), &
                                    this%phint%cartesian, &
                                    this%oei_precision, &
                                    - one, &
                                    skipped)

      end if

   end subroutine get_oei_1der_dipole_shell_phasedint


   subroutine get_oei_shell_1Bder_giao_overlap_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2024
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      logical(c_bool) :: skipped

      call get_shell_overlap_idB_A(oei, &
                                   this%phint%shell_angmom(A), &
                                   this%phint%shell_n_prim(A), &
                                   1_c_int64_t, &
                                   this%phint%shell_coeffs(:, A), &
                                   this%phint%shell_exponents(:, A), &
                                   this%phint%shell_coordinates(:, A), &
                                   this%phint%shell_angmom(B), &
                                   this%phint%shell_n_prim(B), &
                                   1_c_int64_t, &
                                   this%phint%shell_coeffs(:, B), &
                                   this%phint%shell_exponents(:, B), &
                                   this%phint%shell_coordinates(:, B), &
                                   this%phint%cartesian, &
                                   this%oei_precision, &
                                   one, &
                                   skipped, &
                                   this%phint%shell_coordinates(:, B))

   end subroutine get_oei_shell_1Bder_giao_overlap_phasedint


   subroutine get_oei_shell_1Bder_giao_ang_mom_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2024
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      logical(c_bool) :: skipped

      call get_shell_rR_cross_ip(oei, &
                                 this%phint%shell_angmom(A), &
                                 this%phint%shell_n_prim(A), &
                                 1_c_int64_t, &
                                 this%phint%shell_coeffs(:, A), &
                                 this%phint%shell_exponents(:, A), &
                                 this%phint%shell_coordinates(:, A), &
                                 this%phint%shell_angmom(B), &
                                 this%phint%shell_n_prim(B), &
                                 1_c_int64_t, &
                                 this%phint%shell_coeffs(:, B), &
                                 this%phint%shell_exponents(:, B), &
                                 this%phint%shell_coordinates(:, B), &
                                 this%phint%cartesian, &
                                 this%oei_precision, &
                                 one, &
                                 skipped)

   end subroutine get_oei_shell_1Bder_giao_ang_mom_phasedint


   subroutine get_oei_shell_1Bder_giao_kinetic_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2024
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      logical(c_bool) :: skipped

      call get_shell_kinetic_idB_A(oei, &
                                   this%phint%shell_angmom(A), &
                                   this%phint%shell_n_prim(A), &
                                   1_c_int64_t, &
                                   this%phint%shell_coeffs(:, A), &
                                   this%phint%shell_exponents(:, A), &
                                   this%phint%shell_coordinates(:, A), &
                                   this%phint%shell_angmom(B), &
                                   this%phint%shell_n_prim(B), &
                                   1_c_int64_t, &
                                   this%phint%shell_coeffs(:, B), &
                                   this%phint%shell_exponents(:, B), &
                                   this%phint%shell_coordinates(:, B), &
                                   this%phint%cartesian, &
                                   this%oei_precision, &
                                   one, &
                                   skipped, &
                                   this%phint%shell_coordinates(:, B))

   end subroutine get_oei_shell_1Bder_giao_kinetic_phasedint


   subroutine get_oei_shell_1Bder_giao_nuclear_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2024
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length * this%shells(B)%length * 3), intent(out) :: oei

      logical(c_bool) :: skipped

      call get_shell_ep_idB_A(oei, &
                              this%phint%shell_angmom(A), &
                              this%phint%shell_n_prim(A), &
                              1_c_int64_t, &
                              this%phint%shell_coeffs(:, A), &
                              this%phint%shell_exponents(:, A), &
                              this%phint%shell_coordinates(:, A), &
                              this%phint%shell_angmom(B), &
                              this%phint%shell_n_prim(B), &
                              1_c_int64_t, &
                              this%phint%shell_coeffs(:, B), &
                              this%phint%shell_exponents(:, B), &
                              this%phint%shell_coordinates(:, B), &
                              this%phint%cartesian, &
                              this%oei_precision, &
                              one, &
                              skipped, &
                              int(this%phint%n_centers, kind=c_int64_t), &
                              this%phint%centers_charge, &
                              this%phint%centers_coordinates, &
                              this%phint%shell_coordinates(:, B))

   end subroutine get_oei_shell_1Bder_giao_nuclear_phasedint


   subroutine get_oei_shell_giao_paramagnetic_spin_orbit_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2024
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length &
         * this%shells(B)%length, 3, this%n_centers), intent(out) :: oei

      logical(c_bool) :: skipped

      integer :: i

      oei = zero

      do i = 1, this%n_centers

         call get_shell_pso(oei(:, :, i), &
                            this%phint%shell_angmom(A), &
                            this%phint%shell_n_prim(A), &
                            1_c_int64_t, &
                            this%phint%shell_coeffs(:, A), &
                            this%phint%shell_exponents(:, A), &
                            this%phint%shell_coordinates(:, A), &
                            this%phint%shell_angmom(B), &
                            this%phint%shell_n_prim(B), &
                            1_c_int64_t, &
                            this%phint%shell_coeffs(:, B), &
                            this%phint%shell_exponents(:, B), &
                            this%phint%shell_coordinates(:, B), &
                            this%phint%cartesian, &
                            this%oei_precision, &
                            one, &
                            skipped, &
                            1_c_int64_t, &
                            [one], &
                            this%phint%centers_coordinates(:, i))

      end do

   end subroutine get_oei_shell_giao_paramagnetic_spin_orbit_phasedint


   subroutine get_oei_shell_1Bder_giao_paramagnetic_spin_orbit_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2024
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length, this%shells(B)%length, 9, this%n_centers), intent(out) :: oei

      logical(c_bool) :: skipped

      integer :: i

      do i = 1, this%n_centers

         call get_shell_pso_idB_A(oei(:, :, :, i), &
                                  this%phint%shell_angmom(A), &
                                  this%phint%shell_n_prim(A), &
                                  1_c_int64_t, &
                                  this%phint%shell_coeffs(:, A), &
                                  this%phint%shell_exponents(:, A), &
                                  this%phint%shell_coordinates(:, A), &
                                  this%phint%shell_angmom(B), &
                                  this%phint%shell_n_prim(B), &
                                  1_c_int64_t, &
                                  this%phint%shell_coeffs(:, B), &
                                  this%phint%shell_exponents(:, B), &
                                  this%phint%shell_coordinates(:, B), &
                                  this%phint%cartesian, &
                                  this%oei_precision, &
                                  one, &
                                  skipped, &
                                  1_c_int64_t, &
                                  [one], &
                                  this%phint%centers_coordinates(:, i), &
                                  this%phint%shell_coordinates(:, B))

      end do

   end subroutine get_oei_shell_1Bder_giao_paramagnetic_spin_orbit_phasedint


   subroutine get_oei_shell_giao_diamagnetic_phasedint(this, oei, A, B)
      !!
      !! Written by Andrea Bianchi, 2024
      !!
      implicit none

      class(phasedint_oei_library), intent(in) :: this

      integer, intent(in) :: A, B

      real(dp), dimension(this%shells(A)%length &
         * this%shells(B)%length, 9, this%n_centers), intent(out) :: oei

      logical(c_bool) :: skipped

      integer :: i

      do i = 1, this%n_centers

         call get_shell_dia(oei(:, :, i), &
                            this%phint%shell_angmom(A), &
                            this%phint%shell_n_prim(A), &
                            1_c_int64_t, &
                            this%phint%shell_coeffs(:, A), &
                            this%phint%shell_exponents(:, A), &
                            this%phint%shell_coordinates(:, A), &
                            this%phint%shell_angmom(B), &
                            this%phint%shell_n_prim(B), &
                            1_c_int64_t, &
                            this%phint%shell_coeffs(:, B), &
                            this%phint%shell_exponents(:, B), &
                            this%phint%shell_coordinates(:, B), &
                            this%phint%cartesian, &
                            this%oei_precision, &
                            one, &
                            skipped, &
                            1_c_int64_t, &
                            [one], &
                            this%phint%centers_coordinates(:, i))

      end do

   end subroutine get_oei_shell_giao_diamagnetic_phasedint


end module phasedint_oei_library_class

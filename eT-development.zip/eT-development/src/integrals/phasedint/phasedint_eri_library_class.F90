

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module phasedint_eri_library_class

   !!
   !! PhasedInt electron repulsion integral library class
   !! Written by Andrea Bianchi, 2023
   !!
   !! Extends abstract_eri_library_class to give interface to phasedint electron repulsion integrals.
   !!

   use iso_c_binding, only: c_bool, c_int64_t

   use parameters

   use abstract_eri_library_class, only: abstract_eri_library
   use atomic_center_class, only: atomic_center
   use phasedint_tool_class, only: phasedint_tool
   use range_class, only: range_

   implicit none

   type, extends(abstract_eri_library) :: phasedint_eri_library

      type(phasedint_tool) :: phint

      type(range_), dimension(:), pointer :: shells

      logical :: ri_initialized
      integer(c_int64_t), dimension(:), allocatable :: ri_shell_angmom
      integer(c_int64_t), dimension(:), allocatable :: ri_shell_n_prim

      real(dp), dimension(:, :), allocatable :: ri_shell_coordinates
      real(dp), dimension(:, :), allocatable :: ri_shell_coeffs
      real(dp), dimension(:, :), allocatable :: ri_shell_exponents

   contains

      procedure, public :: get_eri => get_eri_phasedint
      procedure, public :: get_eri_1der => get_eri_1der_phasedint

      procedure, public :: get_first_order_derivative_wrt_B_giao_eri => &
                           get_first_order_derivative_wrt_B_giao_eri_phasedint

      procedure, public :: get_eri_2c => get_eri_2c_phasedint
      procedure, public :: get_eri_3c => get_eri_3c_phasedint

      procedure, public :: initialize => initialize_eri_phasedint
      procedure, public :: cleanup => cleanup_eri_phasedint
      procedure, public :: update_centers => update_centers_eri_phasedint
      procedure, public :: prepare_for_ri => prepare_for_ri_phasedint

   end type phasedint_eri_library

   interface phasedint_eri_library

      procedure :: new_phasedint

   end interface phasedint_eri_library

   interface

      include "phasedint.f90"

   end interface

contains

   function new_phasedint(centers, n_centers, n_sh, shells, eri_precision) result(this)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      type(phasedint_eri_library) :: this

      integer, intent(in) :: n_centers, n_sh
      type(atomic_center), dimension(n_centers), intent(in) :: centers
      type(range_), dimension(n_sh), intent(in), target :: shells
      real(dp), intent(in) :: eri_precision

      this%phint = phasedint_tool(centers, n_centers, n_sh)
      this%eri_precision = eri_precision
      this%ri_initialized = .false.

      this%shells => shells

   end function new_phasedint


   subroutine initialize_eri_phasedint(this)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(phasedint_eri_library), intent(inout) :: this

      call do_nothing(this)

   end subroutine initialize_eri_phasedint


   subroutine cleanup_eri_phasedint(this)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      use memory_manager_class, only: mem

      implicit none

      class(phasedint_eri_library), intent(inout) :: this

      if (this%ri_initialized) then

         call mem%dealloc(this%ri_shell_angmom)
         call mem%dealloc(this%ri_shell_n_prim)
         call mem%dealloc(this%ri_shell_coordinates)
         call mem%dealloc(this%ri_shell_coeffs)
         call mem%dealloc(this%ri_shell_exponents)

      end if

      call this%phint%cleanup()

   end subroutine cleanup_eri_phasedint


   subroutine update_centers_eri_phasedint(this, centers, n_centers)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_eri_library), intent(inout) :: this

      integer, intent(in) :: n_centers

      type(atomic_center), dimension(n_centers), intent(in) :: centers

      call this%phint%export_centers(centers, n_centers)

   end subroutine update_centers_eri_phasedint


   subroutine get_eri_phasedint(this, g, A, B, C, D, precision, skip)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      !! Wrapper for constructing electron repulsion integrals g for the
      !! shell quartet (A, B, C, D).
      !!
      !! The integrals are placed in g.
      !!
      !! Two optional arguments:
      !!
      !!    precision:  (intent in) Double precision real corresponding to the phasedint precision
      !!                'epsilon' to use when calculating the integral. Does not guarantee a precision
      !!                to the given value and should therefore be selected conservatively.
      !!
      !!    skip:       (intent out) If present, this integer will be 1 if phasedint decided not to
      !!                calculate the integral; it will be zero otherwise. Also, if it is present, g will
      !!                not be zeroed out if phasedint decides not to calculate g. Thus, only pass 'skip'
      !!                to the routine if you wish to avoid zeroing out elements that are negligible.
      !!
      implicit none

      class(phasedint_eri_library), intent(inout) :: this

      integer, intent(in) :: A, B, C, D

      real(dp), dimension(*), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      real(dp) :: precision_local

      logical(c_bool) :: skipped

      precision_local = this%get_local_eri_precision(precision)

      call get_shell_eri(g, &
                         this%phint%shell_angmom(A), &
                         this%phint%shell_n_prim(A), &
                         1_c_int64_t, &
                         this%phint%shell_coeffs(:, A), &
                         this%phint%shell_exponents(:, A), &
                         this%phint%shell_coordinates(:, A), &
                         this%phint%shell_angmom(B), &
                         this%phint%shell_n_prim(B), &
                         1_c_int64_t, &
                         this%phint%shell_coeffs(:, B), &
                         this%phint%shell_exponents(:, B), &
                         this%phint%shell_coordinates(:, B), &
                         this%phint%shell_angmom(C), &
                         this%phint%shell_n_prim(C), &
                         1_c_int64_t, &
                         this%phint%shell_coeffs(:, C), &
                         this%phint%shell_exponents(:, C), &
                         this%phint%shell_coordinates(:, C), &
                         this%phint%shell_angmom(D), &
                         this%phint%shell_n_prim(D), &
                         1_c_int64_t, &
                         this%phint%shell_coeffs(:, D), &
                         this%phint%shell_exponents(:, D), &
                         this%phint%shell_coordinates(:, D), &
                         this%phint%cartesian, &
                         precision_local, &
                         one, &
                         skipped)

      if (present(skip)) skip = merge(1, 0, skipped)

   end subroutine get_eri_phasedint


   subroutine get_eri_1der_phasedint(this, g, A, B, C, D, precision, skip)
      !!
      !! Written by Andrea Bianchi, September 2022
      !!
      !! Wrapper for constructing first derivative electron repulsion integrals g for the
      !! shell quartet (A, B, C, D). The result is stored in g, in the order of ABCDqk, where
      !! q = 1,2,3 are Cartesian coordinates (x,y,z) and k = 1,2,3,4 are the atomic centers
      !! corresponding to the atoms where A,B,C,D are located.
      !!
      implicit none

      class(phasedint_eri_library), intent(inout) :: this

      integer, intent(in) :: A, B, C, D

      real(dp), dimension(*), intent(out), target :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      real(dp) :: precision_local

      logical(c_bool) :: skipped

      integer :: dim_1der

      precision_local = this%get_local_eri_precision(precision)

      dim_1der = this%shells(A)%length * this%shells(B)%length\
      * this%shells(C)%length * this%shells(D)%length * 3

      call get_shell_eri_dR_ABC(g(1:3 * dim_1der), &
                                this%phint%shell_angmom(A), &
                                this%phint%shell_n_prim(A), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, A), &
                                this%phint%shell_exponents(:, A), &
                                this%phint%shell_coordinates(:, A), &
                                this%phint%shell_angmom(B), &
                                this%phint%shell_n_prim(B), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, B), &
                                this%phint%shell_exponents(:, B), &
                                this%phint%shell_coordinates(:, B), &
                                this%phint%shell_angmom(C), &
                                this%phint%shell_n_prim(C), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, C), &
                                this%phint%shell_exponents(:, C), &
                                this%phint%shell_coordinates(:, C), &
                                this%phint%shell_angmom(D), &
                                this%phint%shell_n_prim(D), &
                                1_c_int64_t, &
                                this%phint%shell_coeffs(:, D), &
                                this%phint%shell_exponents(:, D), &
                                this%phint%shell_coordinates(:, D), &
                                this%phint%cartesian, &
                                precision_local, &
                                one, &
                                skipped)

      g(1 + dim_1der * 3:dim_1der * 4) = - g(1:dim_1der * 1) - g(1 + dim_1der * 1:dim_1der * 2) &
                                         - g(1 + dim_1der * 2:dim_1der * 3)

      if (present(skip)) skip = merge(1, 0, skipped)

   end subroutine get_eri_1der_phasedint


   subroutine get_first_order_derivative_wrt_B_giao_eri_phasedint(this, g, A, B, C, D, precision, skip)
      !!
      !! Written by Andrea Bianchi, 2024
      !!
      implicit none

      class(phasedint_eri_library), intent(inout) :: this

      integer, intent(in) :: A, B, C, D

      real(dp), dimension(*), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      real(dp) :: precision_local

      logical(c_bool) :: skipped

      precision_local = this%get_local_eri_precision(precision)

      call get_shell_eri_idB_A(g, &
                               this%phint%shell_angmom(A), &
                               this%phint%shell_n_prim(A), &
                               1_c_int64_t, &
                               this%phint%shell_coeffs(:, A), &
                               this%phint%shell_exponents(:, A), &
                               this%phint%shell_coordinates(:, A), &
                               this%phint%shell_angmom(B), &
                               this%phint%shell_n_prim(B), &
                               1_c_int64_t, &
                               this%phint%shell_coeffs(:, B), &
                               this%phint%shell_exponents(:, B), &
                               this%phint%shell_coordinates(:, B), &
                               this%phint%shell_angmom(C), &
                               this%phint%shell_n_prim(C), &
                               1_c_int64_t, &
                               this%phint%shell_coeffs(:, C), &
                               this%phint%shell_exponents(:, C), &
                               this%phint%shell_coordinates(:, C), &
                               this%phint%shell_angmom(D), &
                               this%phint%shell_n_prim(D), &
                               1_c_int64_t, &
                               this%phint%shell_coeffs(:, D), &
                               this%phint%shell_exponents(:, D), &
                               this%phint%shell_coordinates(:, D), &
                               this%phint%cartesian, &
                               precision_local, &
                               one, &
                               skipped, &
                               this%phint%shell_coordinates(:, B))

      if (present(skip)) skip = merge(1, 0, skipped)


   end subroutine get_first_order_derivative_wrt_B_giao_eri_phasedint


   subroutine get_eri_2c_phasedint(this, g, J, K, precision, skip)
      !!
      !! Written by Andrea Bianchi, 2024
      !!
      use shell_class, only: shell

      implicit none

      class(phasedint_eri_library), intent(inout) :: this
      type(shell), intent(in) :: J, K

      real(dp), dimension(J%length * K%length), intent(out), target :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      real(dp) :: precision_local

      logical(c_bool) :: skipped

      integer :: A, C

      precision_local = this%get_local_eri_precision(precision)

      A = J%number_
      C = K%number_

      call get_shell_eri(g, &
                         this%ri_shell_angmom(A), &
                         this%ri_shell_n_prim(A), &
                         1_c_int64_t, &
                         this%ri_shell_coeffs(:, A), &
                         this%ri_shell_exponents(:, A), &
                         this%ri_shell_coordinates(:, A), &
                         0_c_int64_t, &
                         1_c_int64_t, &
                         1_c_int64_t, &
                         [one], &
                         [zero], &
                         [zero, zero, zero], &
                         this%ri_shell_angmom(C), &
                         this%ri_shell_n_prim(C), &
                         1_c_int64_t, &
                         this%ri_shell_coeffs(:, C), &
                         this%ri_shell_exponents(:, C), &
                         this%ri_shell_coordinates(:, C), &
                         0_c_int64_t, &
                         1_c_int64_t, &
                         1_c_int64_t, &
                         [one], &
                         [zero], &
                         [zero, zero, zero], &
                         this%phint%cartesian, &
                         precision_local, &
                         one, &
                         skipped)

      if (present(skip)) skip = merge(1, 0, skipped)

   end subroutine get_eri_2c_phasedint


   subroutine get_eri_3c_phasedint(this, g, J, C, D, precision, skip)
      !!
      !! Written by Andrea Bianchi, 2024
      !!
      use shell_class, only: shell

      implicit none

      class(phasedint_eri_library), intent(inout) :: this

      integer, intent(in) :: C, D

      type(shell), intent(in) :: J

      real(dp), dimension(*), intent(out), target :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      real(dp) :: precision_local

      logical(c_bool) :: skipped

      integer :: A

      precision_local = this%get_local_eri_precision(precision)

      A = J%number_

      call get_shell_eri(g, &
                         this%ri_shell_angmom(A), &
                         this%ri_shell_n_prim(A), &
                         1_c_int64_t, &
                         this%ri_shell_coeffs(:, A), &
                         this%ri_shell_exponents(:, A), &
                         this%ri_shell_coordinates(:, A), &
                         0_c_int64_t, &
                         1_c_int64_t, &
                         1_c_int64_t, &
                         [one], &
                         [zero], &
                         [zero, zero, zero], &
                         this%phint%shell_angmom(C), &
                         this%phint%shell_n_prim(C), &
                         1_c_int64_t, &
                         this%phint%shell_coeffs(:, C), &
                         this%phint%shell_exponents(:, C), &
                         this%phint%shell_coordinates(:, C), &
                         this%phint%shell_angmom(D), &
                         this%phint%shell_n_prim(D), &
                         1_c_int64_t, &
                         this%phint%shell_coeffs(:, D), &
                         this%phint%shell_exponents(:, D), &
                         this%phint%shell_coordinates(:, D), &
                         this%phint%cartesian, &
                         precision_local, &
                         one, &
                         skipped)

      if (present(skip)) skip = merge(1, 0, skipped)

   end subroutine get_eri_3c_phasedint


   subroutine prepare_for_ri_phasedint(this, basis_set, precision, centers)
      !!
      !! Written by Andrea Bianchi, 2024
      !!
      use atomic_center_class, only: atomic_center
      use warning_suppressor, only: do_nothing
      use memory_manager_class, only: mem
      use global_out, only: output

      use phasedint_tool_class, only: normalize_raw_primitives_phasedint_tool

      implicit none

      character(len=100), intent(in) :: basis_set
      real(dp), intent(in) :: precision
      type(atomic_center), dimension(:), intent(in) :: centers

      class(phasedint_eri_library), intent(inout) :: this

      real(dp), dimension(:), allocatable :: coeffs, coeffs_normalized
      real(dp), dimension(:), allocatable :: exponents

      integer :: n_centers, n_shells
      integer :: total_number_of_primitives, max_n_primitives
      integer :: i, j, k
      integer :: index_shell

      call do_nothing(basis_set)
      call do_nothing(precision)

      n_centers = size(centers)

      n_shells = 0
      total_number_of_primitives = 0
      max_n_primitives = 0

      do i = 1, n_centers

         n_shells = n_shells + centers(i)%n_shells

         do j = 1, centers(i)%n_shells

            total_number_of_primitives = total_number_of_primitives + centers(i)%shells(j)%get_n_primitives()

            max_n_primitives = max(max_n_primitives, centers(i)%shells(j)%get_n_primitives())

         end do
      end do

      call mem%alloc(this%ri_shell_angmom, n_shells)
      call mem%alloc(this%ri_shell_n_prim, n_shells)
      call mem%alloc(this%ri_shell_coeffs, total_number_of_primitives, n_shells)
      call mem%alloc(this%ri_shell_exponents, total_number_of_primitives, n_shells)
      call mem%alloc(this%ri_shell_coordinates, 3, n_shells)

      call mem%alloc(coeffs, max_n_primitives)
      call mem%alloc(coeffs_normalized, max_n_primitives)
      call mem%alloc(exponents, max_n_primitives)

      index_shell = 1

      do i = 1, n_centers

         if (centers(i)%cartesian .neqv. this%phint%cartesian) then

            call output%error_msg( &
                    "PhasedInt does not support both spherical and cartesian functions at the same time!" &
                 )

         end if

         do j = 1, centers(i)%n_shells

            this%ri_shell_angmom(index_shell) = centers(i)%shells(j)%get_angular_momentum()
            this%ri_shell_n_prim(index_shell) = centers(i)%shells(j)%get_n_primitives()
            this%ri_shell_coordinates(:, index_shell) = centers(i)%coordinates * angstrom_to_bohr

            do k = 1, centers(i)%shells(j)%get_n_primitives()

               coeffs(k) = centers(i)%shells(j)%get_coefficient_i(k)

               exponents(k) = centers(i)%shells(j)%get_exponent_i(k)

            end do

            this%ri_shell_exponents(1:centers(i)%shells(j)%get_n_primitives(), index_shell) = &
               exponents(1:centers(i)%shells(j)%get_n_primitives())

            call normalize_raw_primitives_phasedint_tool(centers(i)%shells(j)%get_angular_momentum(), &
                                                         centers(i)%shells(j)%get_n_primitives(), &
                                                         coeffs_normalized, &
                                                         coeffs, &
                                                         exponents)

            this%ri_shell_coeffs(1:centers(i)%shells(j)%get_n_primitives(), index_shell) = &
               coeffs_normalized(1:centers(i)%shells(j)%get_n_primitives())

            index_shell = index_shell + 1

         end do
      end do

      call mem%dealloc(coeffs)
      call mem%dealloc(coeffs_normalized)
      call mem%dealloc(exponents)

      this%ri_initialized = .true.

   end subroutine prepare_for_ri_phasedint


end module phasedint_eri_library_class

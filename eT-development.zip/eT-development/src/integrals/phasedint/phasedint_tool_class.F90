
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module phasedint_tool_class
   !!
   !! PhasedInt tool class module
   !! Written by Andrea Bianchi, May 2023
   !!
   !! This tool contains the data used for calling phasedint functions.
   !!
   !!
   use iso_c_binding, only: c_bool, c_int64_t

   use parameters

   use memory_manager_class, only: mem
   use atomic_center_class, only: atomic_center

   implicit none

   type :: phasedint_tool

      logical(c_bool) :: cartesian
      integer :: n_shells, n_centers, total_number_of_primitives

      integer(c_int64_t), dimension(:), allocatable :: shell_angmom
      integer(c_int64_t), dimension(:), allocatable :: shell_n_prim

      real(dp), dimension(:, :), allocatable :: shell_coordinates

      real(dp), dimension(:, :), allocatable :: shell_coeffs
      real(dp), dimension(:, :), allocatable :: shell_exponents

      real(dp), dimension(:, :), allocatable :: centers_coordinates
      real(dp), dimension(:), allocatable :: centers_charge

      ! Variables for the external point charge integrals (used in QM/MM)
      integer(c_int64_t) :: n_point_charges
      real(dp), dimension(:, :), allocatable, public :: point_charge_centers
      real(dp), dimension(:), allocatable, public :: point_charge_charges

      ! For unit charges
      integer(c_int64_t) :: n_unit_charges
      real(dp), dimension(:, :), allocatable, public :: unit_charge_centers
      real(dp), dimension(:), allocatable, public :: unit_charge_charges  ! all one


   contains

      procedure, public :: cleanup => cleanup_phasedint_tool
      procedure, public :: export_centers => export_centers_phasedint_tool

   end type phasedint_tool

   interface phasedint_tool

      procedure :: new_phasedint_tool

   end interface phasedint_tool


contains


   function new_phasedint_tool(centers, n_centers, n_sh) result(this)
      !!
      !! Written by Andrea Bianchi, 2022
      !!
      use global_out, only: output

      implicit none

      integer, intent(in) :: n_centers, n_sh
      type(atomic_center), dimension(n_centers), intent(in) :: centers

      type(phasedint_tool) :: this
      real(dp), dimension(:), allocatable :: coeffs, coeffs_normalized
      real(dp), dimension(:), allocatable :: exponents

      integer :: max_n_primitives
      integer :: i, j, k
      integer :: index_shell

      this%n_shells = n_sh
      this%n_centers = n_centers

      call mem%alloc(this%centers_coordinates, 3, this%n_centers)
      call mem%alloc(this%centers_charge, this%n_centers)

      do i = 1, this%n_centers

         this%centers_coordinates(:, i) = centers(i)%coordinates * angstrom_to_bohr
         this%centers_charge(i) = real(centers(i)%nuclear_charge)

      end do

      this%total_number_of_primitives = 0
      max_n_primitives = 0

      do i = 1, this%n_centers
         do j = 1, centers(i)%n_shells

            this%total_number_of_primitives = this%total_number_of_primitives + centers(i &
                                              )%shells(j)%get_n_primitives()

            max_n_primitives = max(max_n_primitives, centers(i)%shells(j)%get_n_primitives())

         end do
      end do

      call mem%alloc(this%shell_angmom, this%n_shells)
      call mem%alloc(this%shell_n_prim, this%n_shells)
      call mem%alloc(this%shell_coeffs, max_n_primitives, this%n_shells)
      call mem%alloc(this%shell_exponents, max_n_primitives, this%n_shells)
      call mem%alloc(this%shell_coordinates, 3, this%n_shells)

      call mem%alloc(coeffs, max_n_primitives)
      call mem%alloc(coeffs_normalized, max_n_primitives)
      call mem%alloc(exponents, max_n_primitives)

      index_shell = 1

      this%cartesian = centers(1)%cartesian

      do i = 1, this%n_centers

         if (centers(i)%cartesian .neqv. this%cartesian) then

            call output%error_msg( &
                    "PhasedInt does not support both spherical and cartesian functions at the same time!" &
                 )

         end if

         do j = 1, centers(i)%n_shells

            this%shell_angmom(index_shell) = centers(i)%shells(j)%get_angular_momentum()
            this%shell_n_prim(index_shell) = centers(i)%shells(j)%get_n_primitives()

            do k = 1, centers(i)%shells(j)%get_n_primitives()

               coeffs(k) = centers(i)%shells(j)%get_coefficient_i(k)

               exponents(k) = centers(i)%shells(j)%get_exponent_i(k)

            end do

            this%shell_exponents(1:centers(i)%shells(j)%get_n_primitives(), index_shell) = &
               exponents(1:centers(i)%shells(j)%get_n_primitives())

            call normalize_raw_primitives_phasedint_tool(centers(i)%shells(j)%get_angular_momentum(), &
                                                         centers(i)%shells(j)%get_n_primitives(), &
                                                         coeffs_normalized, &
                                                         coeffs, &
                                                         exponents)

            this%shell_coeffs(1:centers(i)%shells(j)%get_n_primitives(), index_shell) = &
               coeffs_normalized(1:centers(i)%shells(j)%get_n_primitives())

            index_shell = index_shell + 1

         end do
      end do

      call mem%dealloc(coeffs)
      call mem%dealloc(coeffs_normalized)
      call mem%dealloc(exponents)

   end function new_phasedint_tool


   subroutine normalize_raw_primitives_phasedint_tool(angmom, &
                                                      n_prim, &
                                                      normalized_coefficients, &
                                                      coefficients, &
                                                      exponents)
      !!
      !! Written by Andrea Bianchi, 2022
      !!
      !! Normalization of each primitive with respect to itself:
      !! c_i -> c_i/ sqrt(c_i<i|i>c_i)
      !!
      !! Normalization of the contracted shell:
      !! c_i -> c_i/( sum_k sqrt(c_i<i|k>c_k) )
      !!
      !! where:
      !! <i|k> = (2 * n - 1)!!  (pi / ( alpha_i + alpha_k))**1.5 / (2 * (alpha_i + alpha_j))**n
      !!
      use math_utilities, only: double_factorial

      implicit none

      integer, intent(in) :: angmom, n_prim
      real(dp), dimension(n_prim), intent(out) :: normalized_coefficients
      real(dp), dimension(n_prim), intent(in) :: coefficients
      real(dp), dimension(n_prim), intent(in) :: exponents

      integer :: K, L
      real(dp) :: alpha_1, coeff_1, overlap_kk, overlap_kl, alpha_2, coeff_2
      real(dp) :: sum_

      normalized_coefficients = coefficients

      do K = 1, n_prim

         alpha_1 = exponents(K)
         coeff_1 = normalized_coefficients(K)

         overlap_kk = ((pi / (two * alpha_1))**1.5_dp) / (four * (alpha_1))**angmom
         overlap_kk = double_factorial(2 * angmom - 1) * overlap_kk

         coeff_1 = coeff_1 / sqrt(overlap_kk)
         normalized_coefficients(K) = coeff_1

      end do

      sum_ = zero

      do K = 1, n_prim

         alpha_1 = exponents(K)
         coeff_1 = normalized_coefficients(K)

         overlap_kk = ((pi / (two * alpha_1))**1.5_dp) / (four * (alpha_1))**angmom
         overlap_kk = double_factorial(2 * angmom - 1) * overlap_kk
         sum_ = sum_ + coeff_1 * coeff_1 * overlap_kk

         do L = 1, K - 1

            alpha_2 = exponents(L)
            coeff_2 = normalized_coefficients(L)

            overlap_kl = ((pi / (alpha_1 + alpha_2))**1.5_dp) / (two * (alpha_1 + alpha_2))**angmom
            overlap_kl = double_factorial(2 * angmom - 1) * overlap_kl
            sum_ = sum_ + two * coeff_1 * coeff_2 * overlap_kl

         end do

      end do

      do K = 1, n_prim

         coeff_1 = normalized_coefficients(K)
         coeff_1 = coeff_1 / sqrt(sum_)
         normalized_coefficients(K) = coeff_1

      end do

   end subroutine normalize_raw_primitives_phasedint_tool


   subroutine cleanup_phasedint_tool(this)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_tool), intent(inout) :: this

      if (allocated(this%centers_coordinates)) call mem%dealloc(this%centers_coordinates)
      if (allocated(this%centers_charge)) call mem%dealloc(this%centers_charge)

      if (allocated(this%shell_angmom)) call mem%dealloc(this%shell_angmom)
      if (allocated(this%shell_n_prim)) call mem%dealloc(this%shell_n_prim)

      if (allocated(this%shell_coeffs)) call mem%dealloc(this%shell_coeffs)
      if (allocated(this%shell_exponents)) call mem%dealloc(this%shell_exponents)
      if (allocated(this%shell_coordinates)) call mem%dealloc(this%shell_coordinates)

      if (allocated(this%point_charge_centers)) call mem%dealloc(this%point_charge_centers)
      if (allocated(this%point_charge_charges)) call mem%dealloc(this%point_charge_charges)

      if (allocated(this%unit_charge_centers)) call mem%dealloc(this%unit_charge_charges)
      if (allocated(this%unit_charge_centers)) call mem%dealloc(this%unit_charge_centers)


   end subroutine cleanup_phasedint_tool


   subroutine export_centers_phasedint_tool(this, centers, n_centers)
      !!
      !! Written by Andrea Bianchi, 2023
      !!
      implicit none

      class(phasedint_tool), intent(inout) :: this

      type(atomic_center), dimension(:), intent(in) :: centers  ! AO basis centers

      integer, intent(in) :: n_centers

      integer :: i, j, index_shell


      if (.not. allocated(this%shell_coordinates)) return

      this%n_centers = n_centers

      index_shell = 0

      do i = 1, this%n_centers

         do j = 1, centers(i)%n_shells

            index_shell = index_shell + 1
            this%shell_coordinates(:, index_shell) = centers(i)%coordinates * angstrom_to_bohr

         end do

         this%centers_coordinates(:, i) = centers(i)%coordinates * angstrom_to_bohr
         this%centers_charge(i) = real(centers(i)%nuclear_charge)

      end do

   end subroutine export_centers_phasedint_tool


end module phasedint_tool_class

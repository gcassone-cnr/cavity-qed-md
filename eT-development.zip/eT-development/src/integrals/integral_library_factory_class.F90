

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module integral_library_factory_class

   !!
   !! Integral library factory class module
   !! Written by Marcus T. Lexander, Dec 2022
   !!

   use parameters

   use atomic_center_class, only: atomic_center
   use range_class, only: range_

   use abstract_oei_library_class, only: abstract_oei_library
   use abstract_eri_library_class, only: abstract_eri_library

#ifdef OEI_LIBINT
   use libint_oei_library_class, only: libint_oei_library
#endif
#ifdef OEI_LIBCINT
   use libcint_oei_library_class, only: libcint_oei_library
#elif defined OEI_PHASEDINT
   use phasedint_oei_library_class, only: phasedint_oei_library
#endif

#ifdef ERI_LIBINT
   use libint_eri_library_class, only: libint_eri_library
#endif
#ifdef ERI_LIBCINT
   use libcint_eri_library_class, only: libcint_eri_library
#elif defined ERI_PHASEDINT
   use phasedint_eri_library_class, only: phasedint_eri_library
#endif

   implicit none

   type :: integral_library_factory

      integer, private :: n_ao, n_centers, n_sh, max_sh_size

      type(atomic_center), dimension(:), pointer, private :: centers
      type(range_), dimension(:), pointer, private :: shells
      integer, dimension(:), pointer, private :: shell_to_center

   contains

      procedure, public :: create_oei_library => create_oei_library_integral_library_factory
      procedure, public :: create_eri_library => create_eri_library_integral_library_factory

   end type integral_library_factory

   interface integral_library_factory

      procedure :: new_integral_library_factory

   end interface integral_library_factory

contains


   function new_integral_library_factory(n_ao, &
                                         centers, &
                                         n_centers, &
                                         shells, &
                                         n_sh, &
                                         max_sh_size, &
                                         shell_to_center) result(this)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      implicit none

      type(integral_library_factory) :: this

      integer, intent(in) :: n_ao, n_centers, n_sh, max_sh_size

      type(atomic_center), dimension(n_centers), intent(in), target :: centers
      type(range_), dimension(n_sh), intent(in), target :: shells
      integer, dimension(:), intent(in), target :: shell_to_center

      this%n_ao = n_ao
      this%n_centers = n_centers
      this%n_sh = n_sh
      this%max_sh_size = max_sh_size

      this%centers => centers
      this%shells => shells
      this%shell_to_center => shell_to_center

   end function new_integral_library_factory


   subroutine create_oei_library_integral_library_factory(this, oei_precision, oei_lib)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      implicit none

      class(integral_library_factory), intent(in) :: this

      class(abstract_oei_library), allocatable, intent(inout) :: oei_lib

      real(dp), intent(in) :: oei_precision

#ifdef OEI_LIBINT
      oei_lib = libint_oei_library(oei_precision, &
                                   this%n_ao, &
                                   this%n_centers, &
                                   this%n_sh, &
                                   this%max_sh_size, &
                                   this%shells, &
                                   this%shell_to_center)
#elif defined OEI_LIBCINT
      oei_lib = libcint_oei_library(oei_precision, &
                                    this%n_ao, &
                                    this%centers, &
                                    this%n_centers, &
                                    this%n_sh, &
                                    this%max_sh_size, &
                                    this%shells, &
                                    this%shell_to_center)
#elif defined OEI_PHASEDINT
      oei_lib = phasedint_oei_library(oei_precision, &
                                      this%n_ao, &
                                      this%centers, &
                                      this%n_centers, &
                                      this%n_sh, &
                                      this%max_sh_size, &
                                      this%shells, &
                                      this%shell_to_center)
#endif

      call oei_lib%update_centers(this%centers, this%n_centers)

   end subroutine create_oei_library_integral_library_factory


   subroutine create_eri_library_integral_library_factory(this, eri_precision, eri_lib)
      !!
      !! Written by Marcus T. Lexander, Dec 2022
      !!
      implicit none

      class(integral_library_factory), intent(in) :: this

      class(abstract_eri_library), allocatable, intent(inout) :: eri_lib

      real(dp), intent(in) :: eri_precision

#ifdef ERI_LIBINT
      eri_lib = libint_eri_library(this%centers, this%n_centers, this%n_sh, this%shells, eri_precision)
#elif defined ERI_LIBCINT
      eri_lib = libcint_eri_library(this%centers, this%n_centers, this%n_sh, this%shells, eri_precision)
#elif defined ERI_PHASEDINT
      eri_lib = phasedint_eri_library(this%centers, this%n_centers, this%n_sh, this%shells, eri_precision)
#endif

      call eri_lib%update_centers(this%centers, this%n_centers)

   end subroutine create_eri_library_integral_library_factory


end module integral_library_factory_class

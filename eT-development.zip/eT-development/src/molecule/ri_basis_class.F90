

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module ri_basis_class

   !!
   !! RI basis class
   !! Written by Sarai D. Folkestad, Aug 2021
   !!

   use kinds
   use atomic_center_class, only: atomic_center
   use shell_class, only: shell
   use ao_tool_class, only: ao_tool

   implicit none


   type :: ri_basis

      type(atomic_center), dimension(:), allocatable, private :: centers

      type(shell), dimension(:), allocatable, private :: shells

      integer :: n_centers, n_shells
      integer :: n_ao
      integer :: max_dim

      character(len=200) :: basis_set

   contains

      procedure, public :: initialize_shells
      procedure, public :: cleanup_shells
      procedure, public :: get_shell_length
      procedure, public :: get_shell_first
      procedure, public :: get_shell_last
      procedure, public :: get_shell

   end type ri_basis

   interface ri_basis

      procedure :: new_ri_basis

   end interface ri_basis


contains


   function new_ri_basis(ao, basis_set, eri_precision) result(this)
      !!
      !! Written by Sarai D. Folkestad, Aug 2021
      !!

      implicit none

      type(ao_tool), intent(inout) :: ao
      character(len=100), intent(in) :: basis_set
      real(dp), intent(in) :: eri_precision

      type(ri_basis) :: this

      this%basis_set = basis_set
      this%n_centers = ao%n_centers

      call ao%prepare_for_ri(basis_set, eri_precision, this%centers)

   end function new_ri_basis


   subroutine initialize_shells(this)
      !!
      !! Written by Sarai D. Folkestad, Aug 2021
      !!

      implicit none

      class(ri_basis) :: this

      integer :: i, sh

      this%n_shells = 0

      do i = 1, this%n_centers

         this%n_shells = this%n_shells + this%centers(i)%n_shells

      end do

      allocate(this%shells(this%n_shells))

      sh = 1

      do i = 1, this%n_centers

         this%shells(sh:sh + this%centers(i)%n_shells - 1) = this%centers(i)%shells
         sh = sh + this%centers(i)%n_shells

      end do

      this%n_ao = 0
      this%max_dim = 0

      do i = 1, this%n_shells

         this%n_ao = this%n_ao + this%shells(i)%length
         if (this%shells(i)%length > this%max_dim) this%max_dim = this%shells(i)%length

      end do

   end subroutine initialize_shells


   subroutine cleanup_shells(this)
      !!
      !! Written by Sarai D. Folkestad, Aug 2021
      !!
      implicit none

      class(ri_basis) :: this

      integer :: i

      do i = 1, this%n_centers

         call this%centers(i)%cleanup()

      end do

      deallocate(this%shells)
      deallocate(this%centers)

   end subroutine cleanup_shells


   pure function get_shell_length(this, I) result(length)
      !!
      !! Get shell length
      !! Written by Sarai D. Folkestad
      !!
      implicit none

      class(ri_basis), intent(in) :: this
      integer, intent(in) :: I
      integer :: length

      length = this%shells(I)%length

   end function get_shell_length


   pure function get_shell_first(this, I) result(first)
      !!
      !! Get shell first
      !! Written by Sarai D. Folkestad
      !!
      implicit none

      class(ri_basis), intent(in) :: this
      integer, intent(in) :: I
      integer :: first

      first = this%shells(I)%first

   end function get_shell_first


   pure function get_shell_last(this, I) result(last)
      !!
      !! Get shell last
      !! Written by Sarai D. Folkestad
      !!
      implicit none

      class(ri_basis), intent(in) :: this
      integer, intent(in) :: I
      integer :: last

      last = this%shells(I)%get_last()

   end function get_shell_last


   pure function get_shell(this, I) result(shell_I)
      !!
      !! Get shell
      !! Written by Sarai D. Folkestad
      !!
      implicit none

      class(ri_basis), intent(in) :: this
      integer, intent(in) :: I
      type(shell) :: shell_I

      shell_I = this%shells(I)

   end function get_shell

end module ri_basis_class

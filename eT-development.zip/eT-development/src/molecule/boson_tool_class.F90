

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module boson_tool_class

   !!
   !! Boson tool class module
   !! Written by Tor S. Haugland and Enrico Ronca, 2022-2023
   !!
   !! Class that stores information about bosons and routines related to computing electron-boson
   !! interactions for the Hamiltonian
   !!    H = H_e + w b^+ b + g_b (b + b^+) + g_s^2/w
   !! where w is the frequency of the boson mode and g_b and g_s electron-boson bilinear interaction integrals
   !! and may be different, such as for plasmons, or the same, such as for photons.
   !!
   !! In particular, adding interaction terms to the one- and two-electron integrals (h and g),
   !! as well as getting the electron-boson bilinear interaction integrals. The bilinear integrals
   !! g_b and g_s, often also referred to as g in the literature, are one-electron integrals which
   !! depend on the photon mode, in contrast to the ERI g which are two-electron integrals.
   !!

   use kinds, only: dp
   use memory_manager_class, only: mem
   use ao_tool_class, only: ao_tool
   use ao_oei_getter_class, only: ao_oei_getter
   use abstract_ao_eri_getter_class, only: abstract_ao_eri_getter

   implicit none

   type, abstract :: boson_tool

      integer, public :: n_ao, n_electrons, n_centers, n_modes

      integer, dimension(:), allocatable, public :: n_boson_states

      real(dp), dimension(:), allocatable, public :: frequencies
      real(dp), dimension(:), allocatable, public :: coherent_states_z  ! also known as boson displacement

      logical, public :: is_optimizing_bosons = .true.

      class(ao_oei_getter), allocatable :: ao_oei

      character(len=:), allocatable :: boson_type


   contains

      procedure(initialize_boson), deferred :: initialize
      procedure(cleanup_boson), deferred :: cleanup
      procedure(print_summary_boson), deferred :: print_summary

      procedure(add_ao_h_contribution_boson), deferred :: add_ao_h_contribution
      procedure(get_ao_electron_boson_interaction_boson), deferred :: get_ao_electron_boson_interaction
      procedure(create_ao_eri_getter_boson), deferred, nopass :: create_ao_eri_getter

      procedure(get_ao_electron_boson_interaction_1der_boson), deferred :: &
         get_ao_electron_boson_interaction_1der
      procedure(construct_molecular_gradient_boson_interaction_boson), deferred :: &
         construct_molecular_gradient_boson_interaction

      procedure, public :: read_boson_settings => read_general_boson_settings
      procedure, public :: update_coherent_states

      procedure, public :: get_bilinear

      procedure(get_scaled_polarized_nuclear_dipole_1der_boson), deferred :: &
         get_scaled_polarized_nuclear_dipole_1der

   end type boson_tool

   abstract interface


      subroutine initialize_boson(this, ao)

         import boson_tool
         import ao_tool

         implicit none

         class(boson_tool), intent(inout) :: this
         class(ao_tool), intent(inout) :: ao

      end subroutine initialize_boson


      subroutine cleanup_boson(this)

         import boson_tool
         implicit none

         class(boson_tool), intent(inout) :: this

      end subroutine cleanup_boson


      subroutine get_ao_electron_boson_interaction_boson(this, g_wx, mode)

         import dp
         import boson_tool
         implicit none

         class(boson_tool), intent(in) :: this
         real(dp), dimension(:, :), intent(out) :: g_wx
         integer, intent(in) :: mode

      end subroutine get_ao_electron_boson_interaction_boson


      subroutine get_ao_electron_boson_interaction_1der_boson(this, g_wxqk, mode)

         import dp
         import boson_tool
         implicit none

         class(boson_tool), intent(in) :: this
         real(dp), dimension(:, :, :, :), intent(out) :: g_wxqk
         integer, intent(in) :: mode

      end subroutine get_ao_electron_boson_interaction_1der_boson


      subroutine construct_molecular_gradient_boson_interaction_boson(this, ao, E_qk, D, mode, prefactor)

         import dp
         import boson_tool
         import ao_tool
         implicit none

         class(boson_tool), intent(in) :: this
         class(ao_tool), intent(in) :: ao
         real(dp), dimension(3, this%n_centers), intent(inout) :: E_qk
         integer, intent(in) :: mode
         real(dp), dimension(this%n_ao, this%n_ao), intent(in) :: D
         real(dp), intent(in), optional :: prefactor

      end subroutine construct_molecular_gradient_boson_interaction_boson


      subroutine add_ao_h_contribution_boson(this, h)

         import dp
         import boson_tool
         implicit none

         class(boson_tool), intent(in) :: this
         real(dp), dimension(*), intent(inout), target :: h

      end subroutine add_ao_h_contribution_boson


      subroutine print_summary_boson(this)

         import boson_tool
         implicit none

         class(boson_tool), intent(in) :: this

      end subroutine print_summary_boson


      subroutine create_ao_eri_getter_boson(eri_getter, ao)

         import abstract_ao_eri_getter
         import ao_tool
         implicit none

         class(abstract_ao_eri_getter), allocatable :: eri_getter
         class(ao_tool) :: ao

      end subroutine create_ao_eri_getter_boson


      subroutine get_scaled_polarized_nuclear_dipole_1der_boson(this, mu_nuc_qk)

         import boson_tool
         import dp
         implicit none

         class(boson_tool) :: this
         real(dp), dimension(:, :), intent(inout) :: mu_nuc_qk

      end subroutine get_scaled_polarized_nuclear_dipole_1der_boson

   end interface


contains


   subroutine read_general_boson_settings(this)
      !!
      !! Written by Enrico Ronca, 2023
      !!

      use parameters, only: half
      use global_in, only: input
      use global_out, only: output

      implicit none

      class(boson_tool), intent(inout) :: this

      integer :: k

      if (input%is_keyword_present('frequency', 'boson')) then
         call input%get_array_for_keyword('frequency', 'boson', this%n_modes, this%frequencies)
      else
         call output%error_msg("Keyword frequency must be specified.")
      end if

      if (input%is_keyword_present('boson states', 'boson')) then
         call input%get_array_for_keyword('boson states', 'boson', this%n_modes, this%n_boson_states)
      else
         this%n_boson_states(:) = 1
      end if

      if (input%is_keyword_present('coherent state', 'boson')) then

         this%is_optimizing_bosons = .false.
         call input%get_array_for_keyword('coherent state', 'boson', this%n_modes, this%coherent_states_z)

      elseif (input%is_keyword_present('cbo', 'boson')) then

         this%is_optimizing_bosons = .false.
         call input%get_array_for_keyword('cbo', 'boson', this%n_modes, this%coherent_states_z)

         do k = 1, this%n_modes
            this%coherent_states_z(k) = this%coherent_states_z(k) * sqrt(half * this%frequencies(k))
         end do

      end if

   end subroutine read_general_boson_settings


   subroutine update_coherent_states(this, ao_density)
      !!
      !! Written by T. S. Haugland, June 2021
      !!
      !! Coherent state z is given from the bilinear coupling g_b and frequency w,
      !!    z = - <g_b> / w = - Tr[D g_b] / w
      !!
      implicit none

      class(boson_tool) :: this
      real(dp), dimension(this%n_ao, this%n_ao) :: ao_density

      real(dp), external :: ddot
      real(dp), dimension(:, :), allocatable :: g_wx
      integer :: mode

      call mem%alloc(g_wx, this%n_ao, this%n_ao)
      do mode = 1, this%n_modes
         call this%get_ao_electron_boson_interaction(g_wx, mode)
         this%coherent_states_z(mode) = - ddot(this%n_ao**2, ao_density, 1, g_wx, 1) / this%frequencies(mode)
      end do
      call mem%dealloc(g_wx)

   end subroutine update_coherent_states


   subroutine get_bilinear(this, D, bilinear)
      !!
      !! Written by Sarai D. Folkestad, 2025
      !!
      implicit none

      class(boson_tool), intent(inout) :: this
      real(dp), dimension(this%n_ao, this%n_ao), intent(in) :: D
      real(dp), dimension(this%n_modes), intent(out) :: bilinear

      real(dp), dimension(:, :), allocatable :: g_wx
      real(dp), external :: ddot
      integer :: mode

      call mem%alloc(g_wx, this%n_ao, this%n_ao)

      do mode = 1, this%n_modes

         call this%get_ao_electron_boson_interaction(g_wx, mode)
         bilinear(mode) = ddot(this%n_ao**2, g_wx, 1, D, 1)

      end do

      call mem%dealloc(g_wx)

   end subroutine get_bilinear


end module boson_tool_class

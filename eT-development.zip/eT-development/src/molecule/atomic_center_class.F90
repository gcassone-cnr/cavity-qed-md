

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module atomic_center_class

   !!
   !! Atomic center class module
   !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2018 and 2020
   !!

   use parameters
   use global_out, only: output
   use formatted_read_file_class, only: formatted_read_file
   use shell_class, only: shell
   use memory_manager_class, only: mem

   implicit none

   ! NIST Atomic Spectra Database (ver. 5.8),
   ! https://physics.nist.gov/asd, 2021, January 27

   ! Multiplicity for lead from:
   ! Dembcyn'ski et al. Phys. Rev. A, 49, 745-754, 1994

   integer, dimension(105) :: atomic_multiplicities = &
      (/ 2, 1, 2, 1, 2, 3, 4, 3, 2, 1, 2, 1, 2, 3, 4, 3, 2, 1, 2, 1, 2, 3, 4, 7, 6, 5, 4, 3, 2, 1, 2, 3, 4, &
      3, 2, 1, 2, 1, 2, 3, 6, 7, 6, 5, 4, 1, 2, 1, 2, 3, 4, 3, 2, 1, 2, 1, 2, 2, 1, 4, 5, 6, 7, 8, 9, 6, 5, &
      4, 3, 2, 1, 3, 4, 5, 6, 5, 4, 3, 2, 1, 2, 3, 4, 3, 2, 1, 2, 1, 2, 2, 3, 4, 5, 6, 7, 8, 9, 6, 5, 4, 3, &
      2, 1, 3, 4 /)  ! Fr .. Db  ! H,    He  ! Li .. Ne  ! Na .. Ar  ! K  .. Kr  ! Rb .. Xe  ! Cs .. Rn

   type :: atomic_center

      character(len=2) :: symbol  ! He, Fe, P, ...

      integer :: n_ao

      integer :: n_shells
      type(shell), dimension(:), allocatable :: shells
      character(len=100) :: basis

      real(dp), dimension(3) :: coordinates  ! x, y, z

      integer :: number_  ! Atomic number Z
      integer :: charge
      integer :: nuclear_charge  ! = number_ (if (ghost) then = 0)
      real(dp) :: mass  ! = atomic mass in amu (if (ghost) then = 0)

      integer :: input_number  ! Atom # in the input file
      integer :: eT_internal_number  ! Center # in eT

      logical :: cartesian  ! If not, it is spherical

   contains

      procedure :: symbol_to_number => symbol_to_number_atomic_center

      procedure :: rename_core_valence_dunning_sets => rename_core_valence_dunning_sets_atomic_center

      procedure :: get_basis_set_name => get_basis_set_name_atomic_center

      procedure :: set_cartesian => set_cartesian_atomic_center

      procedure :: read_atomic_uhf_density => read_atomic_uhf_density_atomic_center

      procedure :: get_ground_state_multiplicity => get_ground_state_multiplicity_atomic_center

      procedure :: get_ao_range => get_ao_range_atomic_center

      procedure :: is_ghost => is_ghost_atomic_center

      procedure :: get_molden_order => get_molden_order_atomic_center

      procedure :: get_identifier_string => get_identifier_string_atomic_center

      procedure :: cleanup => cleanup_atomic_center

      ! Reads primitives, exponents, coefficients
      procedure, private :: read_basis_info => read_basis_info_atomic_center

      procedure, private :: read_shell_basis_info => read_shell_basis_info_atomic_center

      procedure, private, nopass :: get_path_to_basis_set_file

   end type atomic_center

   interface atomic_center

      procedure :: new_atomic_center

   end interface atomic_center


contains


   function new_atomic_center(eT_internal_number, &
                              input_number, &
                              symbol, &
                              coordinates, &
                              basis, &
                              basis_type_, &
                              charge, &
                              is_ghost) result(center)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      use periodic_table, only: atomic_mass

      implicit none

      type(atomic_center) :: center

      integer, intent(in) :: eT_internal_number, input_number, charge

      character(len=2), intent(in) :: symbol

      real(dp), dimension(3), intent(in) :: coordinates

      character(len=100), intent(in) :: basis

      character(len=*), intent(in) :: basis_type_

      logical, intent(in) :: is_ghost

      center%eT_internal_number = eT_internal_number
      center%symbol = symbol
      center%basis = basis
      center%coordinates = coordinates
      center%input_number = input_number
      center%charge = charge

      call center%symbol_to_number()

      center%nuclear_charge = center%number_
      if (is_ghost) center%nuclear_charge = 0

      ! Note: the atomic masses are taken to be most common
      ! masses/isotopes for the atoms
      center%mass = zero
      if (.not. is_ghost) then
         center%mass = atomic_mass(center%number_)
      end if

      if (center%number_ == - 1) call output%error_msg('illegal atomic symbol, check the eT.inp file ')

      if (center%charge > center%number_) call output%error_msg('Positive charge exceeds atomic number')

      call center%rename_core_valence_dunning_sets()  ! Otherwise Libint looks for 'augmentation'
      ! files that don't exist for these basis sets

      call center%set_cartesian(basis_type_)

   end function new_atomic_center


   subroutine rename_core_valence_dunning_sets_atomic_center(center)
      !!
      !! Written by Eirik F. Kjoenstad, Nov 2019
      !!
      !! Renames the basis sets (if any) of the core-valence type:
      !!
      !!    aug-cc-pCVXZ -> _aug-cc-pCVXZ
      !!
      !! This is necessary because the Libint files must be named
      !! with an "_" prefix to avoid it looking for an "augmentation" file.
      !!
      implicit none

      class(atomic_center) :: center

      integer :: k

      integer, parameter :: n_renamings = 4

      character(len = 20), dimension(n_renamings), parameter :: original_names = &
         ['aug-cc-pcvdz', 'aug-cc-pcvtz', 'aug-cc-pcvqz', 'aug-cc-pcv5z']

      character(len = 20), dimension(n_renamings), parameter :: new_names = &
         ['_aug-cc-pcvdz', '_aug-cc-pcvtz', '_aug-cc-pcvqz', '_aug-cc-pcv5z']

      do k = 1, n_renamings

         if (trim(center%basis) == trim(original_names(k))) then

            center%basis = trim(new_names(k))

         end if

      end do

   end subroutine rename_core_valence_dunning_sets_atomic_center


   pure function get_basis_set_name_atomic_center(center) result(name_)
      !!
      !! Get basis set name
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(atomic_center), intent(in) :: center

      character(len=100) :: name_

      integer :: I

      I = 1
      if (trim(center%basis(1:1)) == '_') I = 2

      name_ = center%basis(I:)

   end function get_basis_set_name_atomic_center


   pure subroutine symbol_to_number_atomic_center(center)
      !!
      !! Symbol to atomic number
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2018
      !!
      !! Uses the periodic table to determine atomic number from atomic symbol
      !!
      use periodic_table

      implicit none

      class(atomic_center), intent(inout) :: center

      integer :: i

      center%number_ = - 1

      do i = 1, size_periodic_table

         if (atomic_symbol(i) == center%symbol) then

            center%number_ = i
            return

         end if
      end do

   end subroutine symbol_to_number_atomic_center


   subroutine initialize_shells_atomic_center(centers)
      !!
      !! Written by Marcus T. Lexander 2022
      !!
      implicit none

      type(atomic_center), dimension(:), intent(inout) :: centers

      integer :: i, ao_number, shell_number

      ao_number = 1
      shell_number = 1

      do i = 1, size(centers)

         call centers(i)%read_basis_info(ao_number, shell_number)

      end do

   end subroutine initialize_shells_atomic_center


   subroutine read_atomic_uhf_density_atomic_center(center, atomic_D)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Aug 2018
      !!
      !! Read the atomic density matrices from file and adds them together. By assumption, these
      !! densities are the result of atomic UHF calculations with the restriction that valence
      !! electrons are smeared out to ensure that the density is spherically symmetric (as required
      !! for a rotationally invariant SAD guess).
      !!
      use stream_file_class, only: stream_file

      implicit none

      class(atomic_center), intent(in) :: center

      real(dp), dimension(center%n_ao, center%n_ao), intent(out) :: atomic_D

      real(dp), dimension(:, :), allocatable :: temporary
      character(len=100) :: alpha_fname, beta_fname, name_

      type(stream_file), allocatable :: alpha_D_file, beta_D_file

      atomic_D = zero

      name_ = "sad_" // trim(center%get_identifier_string())

      alpha_fname = trim(name_) // '_alpha'
      beta_fname = trim(name_) // '_beta'

      alpha_D_file = stream_file(trim(alpha_fname))
      beta_D_file = stream_file(trim(beta_fname))

      call alpha_D_file%open_('rewind')
      call beta_D_file%open_('rewind')

      call mem%alloc(temporary, center%n_ao, center%n_ao)

      call alpha_D_file%read_(temporary, center%n_ao**2)
      atomic_D = atomic_D + temporary

      call beta_D_file%read_(temporary, center%n_ao**2)
      atomic_D = atomic_D + temporary

      call mem%dealloc(temporary)

      call alpha_D_file%close_()
      call beta_D_file%close_()

   end subroutine read_atomic_uhf_density_atomic_center


   function get_ground_state_multiplicity_atomic_center(center) result(multiplicity)
      !!
      !! Written by Tor S. Haugland, 2019
      !!
      !! Returns the multiplicity from the atomic number.
      !! Based on the table 5.1 in Griffith's "Introduction to Quantum Mechanics", 2. ed
      !!
      implicit none

      class(atomic_center), intent(in) :: center

      integer :: multiplicity

      if (center%number_ > size(atomic_multiplicities)) &
         call output%error_msg("Atom multiplicity not supported for Z > (i0)", &
                               ints=[size(atomic_multiplicities)])

      if (center%number_ == center%charge) &
         call output%error_msg('Cannot assign multiplicity without electrons')

      multiplicity = atomic_multiplicities(center%number_ - center%charge)

   end function get_ground_state_multiplicity_atomic_center


   subroutine read_basis_info_atomic_center(center, ao_number, shell_number)
      !!
      !! Written by Sarai D. Folkestad, Dec 2018
      !!
      !! Opens and reads the basis set file and calls routine read_shell_basis_info to set
      !! the information for each shell (n_primitives, exponents, and coefficients).
      !!
      !! Moved and adapted to atomic center class, Eirik F. Kjoenstad, 2020.
      !!
      use string_utilities, only: convert_to_lowercase

      implicit none

      class(atomic_center), intent(inout) :: center

      character(len=200) :: basis
      character(len=200) :: filename

      type(formatted_read_file), allocatable :: basis_file

      integer :: sh

      integer, parameter :: shell_buffer_size = 1000  ! Maximum conceivable number of shells on one atom
      type(shell), dimension(:), allocatable :: shell_buffer

      integer, intent(inout) :: ao_number, shell_number

      center%n_ao = 0

      ! Initialize shell index to zero

      sh = 0

      ! Do the shells in the non-augmented part first

      if (center%basis(1:3) /= 'aug') then

         write(basis, '(a)') center%basis

      else

         write(basis, '(a)') center%basis(5:100)

      end if

      call convert_to_lowercase(basis)

      filename = center%get_path_to_basis_set_file(basis)

      basis_file = formatted_read_file(trim(filename))

      call basis_file%open_('rewind')

      allocate(shell_buffer(shell_buffer_size))

      call center%read_shell_basis_info(basis_file, sh, shell_buffer, ao_number, shell_number)

      call basis_file%close_()

      ! Then the shells in the augmented part

      if (center%basis(1:3) == 'aug') then

         basis = 'augmentation-' // trim(basis)

         filename = center%get_path_to_basis_set_file(basis)

         basis_file = formatted_read_file(trim(filename))

         call basis_file%open_('rewind')

         call center%read_shell_basis_info(basis_file, sh, shell_buffer, ao_number, shell_number)

         call basis_file%close_()

      end if

      center%n_shells = sh
      if (allocated(center%shells)) deallocate(center%shells)
      allocate(center%shells(center%n_shells))
      center%shells = shell_buffer(1:sh)

   end subroutine read_basis_info_atomic_center


   function get_path_to_basis_set_file(basis) result(path)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      character(len=200), intent(in) :: basis
      character(len=200) :: path

      character(len=200) :: ao_basis_path

      integer :: status_integer

      call get_environment_variable("AO_BASIS_PATH", &
                                    ao_basis_path, &
                                    status=status_integer)

      if (status_integer == 1) then
         ! Environment variable not set
         ! Will try to find the basis set file in the current folder
         path = trim(basis) // '.g94'
      else
         path = trim(ao_basis_path) // '/' // trim(basis) // '.g94'
      end if

   end function get_path_to_basis_set_file


   subroutine read_shell_basis_info_atomic_center(center, &
                                                  basis_file, &
                                                  sh, &
                                                  shell_buffer, &
                                                  ao_number, &
                                                  shell_number)
      !!
      !! Written by Sarai D. Folkestad, Dec 2018
      !!
      !! Sets the number of primitives, and the coefficient and exponents of the primitives, in
      !! each of the shells of the atom.
      !!
      !!    basis_file: File associated with the basis set. Assumed to be opened
      !!                and rewinded when the routine is called.
      !!
      !!    sh:         Equal to zero on entry if there is only one file associated with the
      !!                basis set. For each read shell, this integer is incremented by one.
      !!                In the case of multiple basis set files, shell is first incremented
      !!                from zero when reading the first file and then further incremented
      !!                when reading subsequent (e.g., non-augmented and then augmented).
      !!
      !! Modified by Marco Scavino, 2019
      !! Extended to read the SP primitives from Gaussian format
      !!
      !! Moved and adapted to atomic center class, Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(atomic_center), intent(inout) :: center

      type(formatted_read_file), intent(in) :: basis_file

      type(shell), dimension(1000), intent(inout) :: shell_buffer

      integer, intent(inout) :: ao_number, shell_number

      integer, intent(inout) :: sh

      character(len=200) :: line
      logical :: elm_found  ! Element found?

      integer :: n_primitive, primitive, n_functions
      character(len=2) :: angular_momentum
      real(dp) :: coefficient, coefficient_2, exponent_

      ! Find coordinates of atom/element in the basis file
      ! Look for:  ****
      ! Symbol

      elm_found = .false.

      call basis_file%read_(line, '(a200)')

      do while (.not. elm_found)

         if (trim(line) == '****') then

            call basis_file%read_(line, '(a200)')

            if ((line(1:2)) == center%symbol) then

               elm_found = .true.

            end if

         end if

         if (.not. elm_found) then

            call basis_file%read_(line, '(a200)')

         end if

      end do

      ! Read angular momentum and number of primitives

      call basis_file%read_(line, '(a200)')

      do while (trim(line) /= '****')

         ! Increment shell index and read angular momentum symbol and the number of primitive
         ! basis functions in the shell

         sh = sh + 1

         read(line, *) angular_momentum, n_primitive

         ! Set number of primitives and initialize exponents and coefficient array

         shell_buffer(sh) = shell(first=ao_number, &
                                  ang_mom=angular_momentum, &
                                  number_=shell_number, &
                                  cartesian=center%cartesian)

         n_functions = shell_buffer(sh)%angular_momentum%n_functions

         ao_number = ao_number + n_functions
         shell_number = shell_number + 1
         center%n_ao = center%n_ao + n_functions

         call shell_buffer(sh)%set_n_primitives(n_primitive)

         call shell_buffer(sh)%initialize_exponents()
         call shell_buffer(sh)%initialize_coefficients()

         ! Loop over primitives and set coefficient and exponent

         if (angular_momentum == "SP") then

            ! In case of "SP" shell, split S and P coefficients

            shell_buffer(sh + 1) = shell(first=ao_number, &
                                         ang_mom="P", &
                                         number_=shell_number, &
                                         cartesian=center%cartesian)

            ao_number = ao_number + 3
            shell_number = shell_number + 1
            center%n_ao = center%n_ao + 3

            call shell_buffer(sh + 1)%set_n_primitives(n_primitive)

            call shell_buffer(sh + 1)%initialize_exponents()
            call shell_buffer(sh + 1)%initialize_coefficients()

            do primitive = 1, n_primitive

               ! Read coefficients and exponent

               call basis_file%read_(line, '(a200)')
               read(line, *) exponent_, coefficient, coefficient_2

               call shell_buffer(sh)%set_exponent_i(primitive, exponent_)
               call shell_buffer(sh + 1)%set_exponent_i(primitive, exponent_)

               call shell_buffer(sh)%set_coefficient_i(primitive, coefficient)
               call shell_buffer(sh + 1)%set_coefficient_i(primitive, coefficient_2)

            end do

            ! Since we have now read two shells, we need to increment shell again

            sh = sh + 1

         else

            do primitive = 1, n_primitive

               ! Read coefficient and exponent

               call basis_file%read_(line, '(a200)')
               read(line, *) exponent_, coefficient

               call shell_buffer(sh)%set_exponent_i(primitive, exponent_)
               call shell_buffer(sh)%set_coefficient_i(primitive, coefficient)


            end do

         end if

         call basis_file%read_(line, '(a200)')

      end do

   end subroutine read_shell_basis_info_atomic_center


   function angular_momentum_from_symbol(symbol) result(l)
      !!
      !! Written by Sarai D. Folkestad, Dec 2018
      !!
      !! From the symbol ('S', 'P', 'D', ...), the function returns the associated
      !! angular momentum (0, 1, 2, ...).
      !!
      implicit none

      character(len=1), intent(in) :: symbol

      integer :: l

      l = 0

      if (symbol == 'S') then

         l = 0

      elseif (symbol == 'P') then

         l = 1

      elseif (symbol == 'D') then

         l = 2

      elseif (symbol == 'F') then

         l = 3

      elseif (symbol == 'G') then

         l = 4

      elseif (symbol == 'H') then

         l = 5

      elseif (symbol == 'I') then

         l = 6

      else

         call output%error_msg('no support for orbitals with l > 6')

      end if

   end function angular_momentum_from_symbol


   subroutine set_cartesian_atomic_center(center, basis_type)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Includes previous routine 'default_cartesian_basis' written by Rolf H. Myhre, 2020,
      !! for setting default basis.
      !!
      !! Determines whether the basis is Cartesian or spherical.
      !!
      !!    basis_type: string specifying whether basis should be 'cartesian', 'spherical',
      !!                or 'default' (see list in if statement below)
      !!
      implicit none

      class(atomic_center), intent(inout) :: center

      character(len=*), intent(in) :: basis_type

      if (trim(basis_type) == 'cartesian') then

         center%cartesian = .true.

      elseif (trim(basis_type) == 'spherical') then

         center%cartesian = .false.

      elseif (trim(basis_type) == 'default') then

         center%cartesian = .false.

         if (trim(center%basis) == '3-21g' .or. trim(center%basis) == '6-31g' .or. &
             trim(center%basis) == '6-31+g' .or. trim(center%basis) == '6-31++g' .or. &
             trim(center%basis) == '6-31g*' .or. trim(center%basis) == '6-31g**' .or. &
             trim(center%basis) == '6-31+g*' .or. trim(center%basis) == '6-31+g**' .or. &
             trim(center%basis) == '6-31++g**' .or. trim(center%basis) == '6-31g(d,p)' .or. &
             trim(center%basis) == '6-31g(2df,p)' .or. trim(center%basis) == '6-31g(3df,3pd)') then

            center%cartesian = .true.

         end if

      end if

   end subroutine set_cartesian_atomic_center


   function get_ao_range_atomic_center(center) result(aos)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Returns an range containing the first and last AOs on the center,
      !! as well as the length (in an range object 'aos')
      !!
      use range_class

      implicit none

      class(atomic_center), intent(in) :: center

      type(range_) :: aos

      integer :: first, length

      first = center%shells(1)%first
      length = center%shells(center%n_shells)%get_last() - first + 1

      aos = range_(first, length)

   end function get_ao_range_atomic_center


   pure function is_ghost_atomic_center(center) result(is_ghost)
      !!
      !! Is ghost?
      !! Written by Tor S. Hauglan, May 2021
      !!
      !! Ghosts are atoms with zero charge. Their only function is
      !! enlargening the basis.
      !!
      implicit none

      class(atomic_center), intent(in) :: center
      logical :: is_ghost

      is_ghost = (center%nuclear_charge == 0)

   end function is_ghost_atomic_center


   function get_molden_order_atomic_center(center) result(map)
      !!
      !! Written by Alexander C. Paul, May 2021
      !!
      !! Return index list mapping AOs to the order molden expects
      !!
      implicit none

      class(atomic_center), intent(in) :: center

      integer, dimension(center%n_ao) :: map

      integer :: s, offset

      offset = 1

      do s = 1, center%n_shells

         map(offset:offset + center%shells(s)%length - 1) = center%shells(s)%get_molden_order()

         offset = offset + center%shells(s)%length

      end do

   end function get_molden_order_atomic_center


   pure function get_identifier_string_atomic_center(center) result(identifier)
      !!
      !! Get identifier string
      !! Written by Sarai D. Folkestad, Jun 2021
      !!
      !! Returns a string with symbol and basis set
      !!
      implicit none

      class(atomic_center), intent(in) :: center
      character(len=50) :: identifier

      character(len=5) :: charge_sign

      if (center%charge < 0) then
         charge_sign = 'minus'
      else
         charge_sign = 'plus'
      end if

      write(identifier, &
            '(5a,i2.2)' &
      ) trim(center%symbol), '_', trim(center%basis), '_', trim(charge_sign), abs(center%charge)

   end function get_identifier_string_atomic_center


   subroutine cleanup_atomic_center(center)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2018
      !!
      use stream_file_class, only: stream_file

      implicit none

      class(atomic_center) :: center

      integer :: sh
      character(len=100) :: file_name, name_
      type(stream_file), allocatable :: alpha_D_file, beta_D_file

      do sh = 1, center%n_shells

         call center%shells(sh)%cleanup()

      end do

      name_ = "sad_" // trim(center%get_identifier_string())

      file_name = trim(name_) // '_alpha'
      alpha_D_file = stream_file(file_name)
      if (alpha_D_file%exists()) call alpha_D_file%delete_()

      file_name = trim(name_) // '_beta'
      beta_D_file = stream_file(file_name)
      if (beta_D_file%exists()) call beta_D_file%delete_()

   end subroutine cleanup_atomic_center


end module atomic_center_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module ao_tool_class

   !!
   !! Atomic orbital tool class module
   !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2018-2020
   !!
   !! Class that stores information of the atomic orbital (AO) basis
   !! and can be used to calculate AO integrals. In particular, it contains
   !! a set of centers (atomic, non-atomic), each of which consists of a set
   !! of shells.
   !!

   use parameters
   use named_range_class

   use global_in, only: input
   use global_out, only: output
   use memory_manager_class, only: mem

   use atomic_center_class, only: atomic_center
   use point_charges_class, only: point_charges

   use abstract_oei_library_class, only: abstract_oei_library
   use abstract_eri_library_class, only: abstract_eri_library

   use integral_library_factory_class, only: integral_library_factory

   implicit none

   ! Type definition

   type :: ao_tool

      ! Number of AOs, number of shells, and the maximum shell size

      integer, public :: n, n_sh, max_sh_size

      ! Vector of shell intervals (first, last, length)

      type(range_), dimension(:), allocatable, public :: shells
      type(range_), dimension(:), allocatable, public :: ri_shells

      ! Various useful index mappings

      integer, dimension(:), allocatable, public :: shell_to_center
      integer, dimension(:), allocatable, public :: ao_to_center
      integer, dimension(:), allocatable, public :: ao_to_shell

      ! One-electron integral (OEI) arrays

      real(dp), dimension(:, :), allocatable, public :: h  ! Hamiltonian one-electron integral matrix
      real(dp), dimension(:, :), allocatable, public :: s  ! Overlap integral matrix
      real(dp), dimension(:, :), allocatable, public :: v  ! Coulomb external charges integral matrix

      ! Cauchy-Schwarz electron repulsion integral (CS-ERI) screenings

      integer, public :: n_sig_eri_shp  ! Number of AB for which (AB|AB) exceeds ERI precision

      real(dp), dimension(:, :), allocatable, public :: cs_eri_max  ! Contains (AB|AB)^1/2
      integer, dimension(:, :), allocatable, public :: cs_eri_max_indices  ! Sorting indices
      real(dp), dimension(:), allocatable, public :: cs_eri_max_sh
      real(dp), public :: g_max

      integer, dimension(:, :), allocatable, public :: sig_s2_for_s1
      integer, dimension(:), allocatable, public :: n_sig_s2_for_s1

      integer :: n_centers
      type(atomic_center), dimension(:), allocatable, private :: centers  ! AO basis centers

      integer, private :: n_orthonormal_ao  ! Orthonormal AOs (OAOs)
      ! Threshold for removing linear dependency between AOs n_orthonormal_ao
      real(dp), private :: lindep_threshold

      real(dp), dimension(:, :), allocatable, public :: P, L  ! AO-to-OAO transformation matrices

      integer, private :: n_center_subsets
      type(named_range), dimension(:), allocatable, private :: center_subsets

      real(dp), private :: eri_precision

      character(len=200) :: basis_type_  ! standard, spherical, or Gaussian

      logical :: is_cartesian
      integer :: n_cartesian, n_pure_basis  ! number of cartesian/pure gaussian functions
      ! if AO basis is transformed to pure/cartesian respectively

      integer :: charge

      class(abstract_oei_library), allocatable, private :: oei_lib
      class(abstract_eri_library), allocatable, private :: eri_lib

   contains

      procedure, public :: initialize => initialize_ao_tool

      procedure, public :: initialize_ao_tool_from_template

      generic, public :: initialize_external_charges => initialize_external_charges_ao_tool, &
         initialize_external_charges_from_point_charges_ao_tool

      procedure, public :: initialize_external_charges_ao_tool
      procedure, public :: initialize_external_charges_from_point_charges_ao_tool

      procedure, public :: initialize_external_unit_charges => initialize_external_unit_charges_ao_tool

      procedure, public :: get_oei => get_oei_ao_tool  ! OEI = one-electron integral

      procedure, public :: get_oei_1der => get_oei_1der_ao_tool  ! 1der = first derivative

      procedure, public :: get_oei_1der_shell => get_oei_1der_shell_ao_tool  ! 1der = first derivative

      procedure, public :: get_eri => get_eri_ao_tool  ! ERI = electron repulsion integral

      procedure, public :: get_eri_2c => get_eri_2c_ao_tool

      procedure, public :: get_eri_3c => get_eri_3c_ao_tool

      procedure, public :: get_eri_1der => get_eri_1der_ao_tool

      procedure, public :: get_dipole_1der_shell => get_dipole_1der_shell_ao_tool

      procedure, public :: get_overlap_1der_shell => get_overlap_1der_shell_ao_tool

      procedure, public :: get_first_order_derivative_wrt_B_giao_eri => &
                           get_first_order_derivative_wrt_B_giao_eri_ao_tool

      procedure, public :: get_n_oei_components => get_n_oei_components_ao_tool  ! e.g. 3 for dipole (x,y,z)

      procedure, public :: initialize_oei => initialize_oei_ao_tool

      procedure, public :: destruct_oei => destruct_oei_ao_tool

      procedure, public :: construct_stored_oei => construct_stored_oei_ao_tool

      procedure, public :: set_atomic_centers => set_atomic_centers_ao_tool

      procedure, public :: get_sad_guess => get_sad_guess_ao_tool  ! SAD = superposition of atomic densities

      ! AO indices for a specific center subset
      procedure, public :: get_aos_in_subset => get_aos_in_subset_ao_tool

      procedure, public :: get_center => get_center_ao_tool

      procedure, public :: get_n_centers => get_n_centers_ao_tool

      procedure, public :: is_center_subset => is_center_subset_ao_tool

      procedure, public :: get_n_centers_in_subset => get_n_centers_in_subset_ao_tool

      procedure, public :: set_integral_precision => set_integral_precision_ao_tool

      procedure, public :: get_eri_precision => get_eri_precision_ao_tool

      procedure, public :: get_reduced_ao_metric => get_reduced_ao_metric_ao_tool

      procedure, public :: get_n_orthonormal_ao => get_n_orthonormal_ao_ao_tool

      procedure, public :: print_ao_vectors => print_ao_vectors_ao_tool

      procedure, public :: get_n_frozen_orbitals => get_n_frozen_orbitals_ao_tool

      procedure, public :: get_n_frozen_orbitals_for_center => get_n_frozen_orbitals_for_center_ao_tool

      procedure, public :: get_first_ao_index_of_center

      procedure, public :: print_centers => print_centers_ao_tool

      procedure, public :: print_z_matrix => print_z_matrix_ao_tool

      procedure, public :: evaluate_aos_at_point => evaluate_aos_at_point_ao_tool

      procedure, public :: get_center_coordinates => get_center_coordinates_ao_tool

      procedure, public :: get_center_symbols => get_center_symbols_ao_tool

      procedure, public :: get_point_charges => get_point_charges_ao_tool

      procedure, public :: export_centers_to_integral_libraries => &
                           export_centers_to_integral_libraries_ao_tool

      procedure, public :: get_n_electrons => get_n_electrons_ao_tool

      procedure, public :: get_subset_point_charges => get_subset_point_charges_ao_tool

      procedure, public :: has_ghost_atoms => has_ghost_atoms_ao_tool

      procedure, public :: get_center_masses => get_center_masses_ao_tool

      procedure, public :: print_integral_precision

      ! Routines to write a molden file

      procedure, public :: get_molden_ao_indices => get_molden_ao_indices_ao_tool

      procedure, public :: get_ao_normalization_factors => get_ao_normalization_factors_ao_tool

      procedure, public :: print_molden_geometry => print_molden_geometry_ao_tool

      procedure, public :: print_basis_set_molden => print_basis_set_molden_ao_tool

      procedure, public :: get_centers => get_centers_ao_tool

      procedure, public :: get_max_angular_momentum => get_max_angular_momentum_ao_tool
      procedure, public :: print_geometry => print_geometry_ao_tool

      procedure, public :: construct_shp_X => construct_shp_X_ao_tool

      procedure, public :: construct_sh_X_from_shp_X => construct_sh_X_from_shp_X_ao_tool

      procedure, public :: construct_sh_X_max_index_1 => construct_sh_X_max_index_1_ao_tool

      procedure, public :: prepare_for_ri => prepare_for_ri_ao_tool

      procedure, public :: append_geometry_to_xyz => append_geometry_to_xyz_ao_tool

      procedure, public :: save_geometry_to_xyz => save_geometry_to_xyz_ao_tool

      procedure, public :: is_molecule_linear

      procedure, public :: calculate_natural_connection => calculate_natural_connection_ao_tool

      procedure, private :: cleanup

      procedure, private :: construct_cs_eri_max_screenings  ! Cauchy-Schwarz (CS),
      ! electron repulsion integrals (ERIs)

      procedure, private :: determine_linearly_independent_aos

      procedure, private :: set_up_centers

      procedure, private :: initialize_centers
      procedure, private :: initialize_centers_from_template
      procedure, private :: initialize_centers_from_ao_tool
      procedure, private :: initialize_centers_from_input_file
      procedure, private :: initialize_center_shells

      procedure, private :: check_for_close_atoms

      procedure, private :: set_atomic_center_positions

      procedure, private :: initialize_total_charge

      procedure, private :: calculate_n_shells
      procedure, private :: calculate_n_aos
      procedure, private :: calculate_max_shell_size

      procedure, private :: construct_shells
      procedure, private :: construct_shell_to_center
      procedure, private :: construct_ao_to_shell
      procedure, private :: construct_ao_to_center

      procedure, private :: calculate_geometry_dependent_variables  ! h, s, ERI screening lists, ...
      procedure, private :: copy_geometry_dependent_variables

      procedure, private :: construct_cartesian_shells
      procedure, private :: get_subset_index

      procedure :: transform_to_cartesian => transform_to_cartesian_ao_tool
      procedure :: transform_from_cartesian => transform_from_cartesian_ao_tool
      procedure :: calculate_n_pure_and_n_cartesian => calculate_n_pure_and_n_cartesian_ao_tool
      procedure :: is_basis_cartesian => is_basis_cartesian_ao_tool

      procedure :: relevant_elements_in_basis_and_molecule_grid => &
                   relevant_elements_in_basis_and_molecule_grid_ao_tool

      procedure :: construct_chi_mu_r => construct_chi_mu_r_ao_tool
      procedure :: construct_d1_chi_mu_r => construct_d1_chi_mu_r_ao_tool

      final :: destructor

   end type ao_tool

   interface ao_tool

      procedure :: new_ao_tool

   end interface ao_tool


contains


   function new_ao_tool() result(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      type(ao_tool) :: ao

      ao%lindep_threshold = 1.0d-6
      ao%eri_precision = 1.0d-12

      ! Enforce Cartesian or spherical Gaussians, or use default for the given basis?

      ao%basis_type_ = 'default'

      if (input%is_keyword_present('cartesian gaussians', 'system')) then

         ao%basis_type_ = 'cartesian'

      elseif (input%is_keyword_present('pure gaussians', 'system')) then

         ao%basis_type_ = 'spherical'

      end if

      ao%is_cartesian = .false.

   end function new_ao_tool


   subroutine initialize_ao_tool(ao, centers, charge)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Makes the AO tool ready to use.
      !! Centers are by default read from input. Uses the optional 'centers' instead if given.
      !!
      use timings_class, only: timings

      implicit none

      class(ao_tool), intent(inout), target :: ao

      class(atomic_center), dimension(:), intent(in), optional :: centers
      integer, intent(in), optional :: charge

      logical :: print_z_matrix
      real(dp) :: oei_precision

      type(integral_library_factory) :: int_lib_factory

      type(timings) :: timer

      timer = timings('Time initializing AO tool', 'n')
      call timer%turn_on()

      call ao%set_up_centers(centers)
      call ao%initialize_total_charge(charge)

      call ao%print_centers('angstrom')
      call ao%print_centers('bohr')

      print_z_matrix = input%is_keyword_present('z-matrix', 'print')
      if (print_z_matrix) call ao%print_z_matrix()

      call ao%check_for_close_atoms()

      call ao%calculate_n_aos()
      call ao%calculate_n_shells()

      allocate(ao%shells(ao%n_sh))

      call mem%alloc(ao%shell_to_center, ao%n_sh)
      call mem%alloc(ao%ao_to_center, ao%n)
      call mem%alloc(ao%ao_to_shell, ao%n)

      call ao%construct_shells()
      call ao%construct_shell_to_center()
      call ao%construct_ao_to_center()
      call ao%construct_ao_to_shell()

      call ao%calculate_max_shell_size()

      call mem%alloc(ao%cs_eri_max, ao%n_sh * (ao%n_sh + 1) / 2, 2)
      call mem%alloc(ao%cs_eri_max_indices, ao%n_sh * (ao%n_sh + 1) / 2, 3)
      call mem%alloc(ao%cs_eri_max_sh, ao%n_sh)
      call mem%alloc(ao%sig_s2_for_s1, ao%n_sh, ao%n_sh)
      call mem%alloc(ao%n_sig_s2_for_s1, ao%n_sh)

      oei_precision = ao%eri_precision * 1.0d-5

      int_lib_factory = integral_library_factory(ao%n, &
                                                 ao%centers, &
                                                 ao%n_centers, &
                                                 ao%shells, &
                                                 ao%n_sh, &
                                                 ao%max_sh_size, &
                                                 ao%shell_to_center)

      call int_lib_factory%create_oei_library(oei_precision, ao%oei_lib)
      call int_lib_factory%create_eri_library(ao%eri_precision, ao%eri_lib)

      call ao%construct_stored_oei('overlap')
      call ao%determine_linearly_independent_aos()
      call ao%construct_cs_eri_max_screenings()

      if (ao%get_n_electrons() == 0) call output%error_msg('no electrons in system')

      call ao%calculate_n_pure_and_n_cartesian()
      ao%is_cartesian = ao%is_basis_cartesian()

      call timer%turn_off()

   end subroutine initialize_ao_tool


   subroutine initialize_ao_tool_from_template(ao, template)
      !!
      !! Written by Alexander C. Paul, Feb. 2021
      !!
      !! Makes the AO tool ready to use, copying from an ao_tool template
      !!
      use array_initialization, only: copy_integer
      use timings_class, only: timings

      implicit none

      class(ao_tool), intent(inout), target :: ao
      class(ao_tool), intent(in) :: template

      type(integral_library_factory) :: int_lib_factory

      type(timings) :: timer
      real(dp) :: oei_precision

      timer = timings('Time initializing AO tool from template', 'v')
      call timer%turn_on()

      ao%n = template%n
      ao%n_sh = template%n_sh
      ao%charge = template%charge

      call ao%set_up_centers(ao_template=template)

      allocate(ao%shells(ao%n_sh))
      ao%shells = template%shells

      call mem%alloc(ao%shell_to_center, ao%n_sh)
      call copy_integer(template%shell_to_center, ao%shell_to_center, ao%n_sh)

      call mem%alloc(ao%ao_to_center, ao%n)
      call copy_integer(template%ao_to_center, ao%ao_to_center, ao%n)

      call mem%alloc(ao%ao_to_shell, ao%n)
      call copy_integer(template%ao_to_shell, ao%ao_to_shell, ao%n)

      ao%max_sh_size = template%max_sh_size

      ao%eri_precision = template%eri_precision
      oei_precision = ao%eri_precision * 1.0d-5

      int_lib_factory = integral_library_factory(ao%n, &
                                                 ao%centers, &
                                                 ao%n_centers, &
                                                 ao%shells, &
                                                 ao%n_sh, &
                                                 ao%max_sh_size, &
                                                 ao%shell_to_center)

      call int_lib_factory%create_oei_library(oei_precision, ao%oei_lib)
      call int_lib_factory%create_eri_library(ao%eri_precision, ao%eri_lib)

      call ao%construct_stored_oei('overlap')
      call ao%construct_stored_oei('hamiltonian')

      call mem%alloc(ao%cs_eri_max, ao%n_sh * (ao%n_sh + 1) / 2, 2)
      call mem%alloc(ao%cs_eri_max_indices, ao%n_sh * (ao%n_sh + 1) / 2, 3)
      call mem%alloc(ao%cs_eri_max_sh, ao%n_sh)
      call mem%alloc(ao%sig_s2_for_s1, ao%n_sh, ao%n_sh)
      call mem%alloc(ao%n_sig_s2_for_s1, ao%n_sh)

      call ao%copy_geometry_dependent_variables(template)

      call ao%calculate_n_pure_and_n_cartesian()
      ao%is_cartesian = ao%is_basis_cartesian()

      call timer%turn_off()

   end subroutine initialize_ao_tool_from_template


   subroutine set_up_centers(ao, centers, ao_template)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Makes the centers fully ready for use.
      !!
      !! Reads centers from input, unless optional arguments are passed:
      !!
      !!    - centers:     copy from an existing set of centers
      !!    - ao_template: copy from centers in another ao_tool
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      class(atomic_center), dimension(:), intent(in), optional :: centers

      type(ao_tool), intent(in), optional :: ao_template

      call ao%initialize_centers(centers, ao_template)
      call ao%initialize_center_shells()

   end subroutine set_up_centers


   subroutine initialize_centers(ao, centers, ao_template)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Allocates and sets the centers as well as the center subsets.
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      class(atomic_center), dimension(:), intent(in), optional :: centers

      type(ao_tool), intent(in), optional :: ao_template

      if (present(centers)) then

         call ao%initialize_centers_from_template(centers)

      else if (present(ao_template)) then

         call ao%initialize_centers_from_ao_tool(ao_template)

      else

         call ao%initialize_centers_from_input_file()

      end if

   end subroutine initialize_centers


   subroutine initialize_centers_from_input_file(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      use atomic_center_reader_class, only: atomic_center_reader

      implicit none

      class(ao_tool), intent(inout) :: ao

      class(atomic_center_reader), allocatable :: center_reader

      center_reader = atomic_center_reader(ao%basis_type_)

      call center_reader%read_centers()

      ao%n_centers = center_reader%get_n_centers()
      ao%n_center_subsets = center_reader%get_n_center_subsets()

      call center_reader%get_centers(ao%centers)
      call center_reader%get_center_subsets(ao%center_subsets)

      deallocate(center_reader)

   end subroutine initialize_centers_from_input_file


   subroutine initialize_centers_from_template(ao, centers)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      class(atomic_center), dimension(:), intent(in) :: centers

      integer :: I

      ao%n_centers = size(centers)

      allocate(ao%centers(ao%n_centers))

      do I = 1, ao%n_centers

         ao%centers(I) = atomic_center(I, &
                                       - 1, &
                                       centers(I)%symbol, &
                                       centers(I)%coordinates, &
                                       centers(I)%basis, &
                                       ao%basis_type_, &
                                       centers(I)%charge, &
                                       centers(I)%is_ghost())

      end do

      ao%n_center_subsets = 1
      allocate(ao%center_subsets(ao%n_center_subsets))

      ao%center_subsets(1) = named_range('unclassified', &
                                         1, &
                                         ao%n_centers)

   end subroutine initialize_centers_from_template


   subroutine initialize_centers_from_ao_tool(ao, ao_template)
      !!
      !! Written by Alexander C. Paul, Feb 2021
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao
      class(ao_tool), intent(in) :: ao_template

      integer :: I

      ao%n_centers = ao_template%n_centers

      allocate(ao%centers(ao%n_centers))

      do I = 1, ao%n_centers

         ao%centers(I) = atomic_center(ao_template%centers(i)%eT_internal_number, &
                                       ao_template%centers(i)%input_number, &
                                       ao_template%centers(i)%symbol, &
                                       ao_template%centers(i)%coordinates, &
                                       ao_template%centers(i)%basis, &
                                       ao_template%basis_type_, &
                                       ao_template%centers(i)%charge, &
                                       ao_template%centers(i)%is_ghost())

      end do

      ao%n_center_subsets = ao_template%n_center_subsets
      allocate(ao%center_subsets(ao%n_center_subsets))

      ao%center_subsets = ao_template%center_subsets

   end subroutine initialize_centers_from_ao_tool


   subroutine export_centers_to_integral_libraries_ao_tool(ao)
      !!
      !! Written by Rolf H. Myhre, Mar. 2020

      implicit none

      class(ao_tool), intent(inout) :: ao

      call ao%oei_lib%update_centers(ao%centers, ao%n_centers)
      call ao%eri_lib%update_centers(ao%centers, ao%n_centers)

   end subroutine export_centers_to_integral_libraries_ao_tool


   subroutine initialize_center_shells(ao)
      !!
      !! Written by Marcus T. Lexander 2022
      !!
      use atomic_center_class, only: initialize_shells_atomic_center

      implicit none

      class(ao_tool), intent(inout) :: ao

      call initialize_shells_atomic_center(ao%centers)

   end subroutine initialize_center_shells


   subroutine initialize_total_charge(ao, charge)
      !!
      !! Written by Sarai D. Folkestad, 2021

      implicit none

      class(ao_tool), intent(inout) :: ao
      integer, intent(in), optional :: charge

      if (present(charge)) then

         ao%charge = charge
         return

      end if

      ao%charge = 0
      call input%get_keyword('charge', 'system', ao%charge)

   end subroutine initialize_total_charge


   subroutine calculate_n_shells(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      integer :: I

      ao%n_sh = 0

      do I = 1, ao%n_centers

         ao%n_sh = ao%n_sh + ao%centers(I)%n_shells

      end do

   end subroutine calculate_n_shells


   subroutine calculate_n_aos(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      integer :: I

      ao%n = 0

      do I = 1, ao%n_centers

         ao%n = ao%n + ao%centers(I)%n_ao

      end do

   end subroutine calculate_n_aos


   subroutine construct_ao_to_center(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      integer :: I, A, B, w

      A = 0

      do I = 1, ao%n_centers
         do B = 1, ao%centers(I)%n_shells

            A = A + 1

            do w = ao%shells(A)%first, ao%shells(A)%get_last()

               ao%ao_to_center(w) = I

            end do
         end do
      end do

   end subroutine construct_ao_to_center


   subroutine construct_ao_to_shell(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      integer :: A, w

      A = 0

      do A = 1, ao%n_sh
         do w = ao%shells(A)%first, ao%shells(A)%get_last()

            ao%ao_to_shell(w) = A

         end do
      end do

   end subroutine construct_ao_to_shell


   subroutine construct_shells(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Constructs 'shells', which is a vector containing the AO intervals for each shell.
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      integer :: I, A, B

      A = 0

      do I = 1, ao%n_centers
         do B = 1, ao%centers(I)%n_shells

            A = A + 1

            ao%shells(A) = range_(ao%centers(I)%shells(B))

         end do
      end do

   end subroutine construct_shells


   subroutine calculate_max_shell_size(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      integer :: A

      ao%max_sh_size = 0

      do A = 1, ao%n_sh

         if (ao%shells(A)%length > ao%max_sh_size) then

            ao%max_sh_size = ao%shells(A)%length

         end if

      end do

   end subroutine calculate_max_shell_size


   function get_n_oei_components_ao_tool(ao, oei_type) result(n_components)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Returns the number of one-electron integral components for the
      !! integral of type 'oei_type'.
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      character(len=*), intent(in) :: oei_type

      integer :: n_components

      n_components = ao%oei_lib%get_n_oei_components(oei_type)

   end function get_n_oei_components_ao_tool


   subroutine get_oei_ao_tool(ao, oei_type, oei, screening)
      !!
      !! Written by Marcus T. Lexander, 2022
      !!
      !! Constructs one-electron integrals in the AO basis and places the result in 'oei'
      !!
      !!    oei:      integral array (n_ao x n_ao x n_components)
      !!    oei_type: which integral to calculate
      !!
      !! 'oei_type' can be:
      !!
      !!    - 'hamiltonian'  One-electron Hamiltonian (h)  n_components = 1
      !!    - 'overlap'      AO overlap (S)                n_components = 1
      !!    - 'dipole'       Dipole moment (mu)            n_components = 3 (mu_x, mu_y, mu_z)
      !!    - 'quadrupole'   Quadrupole moment (q)         n_components = 6 (q_xx, q_xy, q_xz,
      !!                                                                     q_yy, q_yz, q_zz)
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(*), intent(out) :: oei

      logical, intent(in), optional :: screening

      call ao%oei_lib%get_oei(oei_type, oei, screening)

   end subroutine get_oei_ao_tool


   subroutine get_oei_1der_ao_tool(ao, &
                                   oei_type, &
                                   oei_1der)
      !!
      !! Written by Marcus Takvam Lexander, 2022
      !!
      implicit none

      class(ao_tool) :: ao

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(*), intent(out) :: oei_1der

      call ao%oei_lib%get_oei_1der(oei_type, oei_1der)

   end subroutine get_oei_1der_ao_tool


   subroutine get_dipole_1der_shell_ao_tool(ao, dipole_1der_shell, A, B)
      !!
      !! Written by Sara Angelico, 2024
      !!
      implicit none

      class(ao_tool) :: ao

      real(dp), dimension(:), intent(out) :: dipole_1der_shell

      integer :: A, B

      call ao%oei_lib%get_oei_1der_shell("dipole", dipole_1der_shell, A, B)

   end subroutine get_dipole_1der_shell_ao_tool


   subroutine get_overlap_1der_shell_ao_tool(ao, overlap_1der_shell, A, B)
      !!
      !! Written by Sara Angelico, 2024
      !!
      implicit none

      class(ao_tool) :: ao

      real(dp), dimension(:), intent(out) :: overlap_1der_shell

      integer :: A, B

      call ao%oei_lib%get_oei_1der_shell("overlap", overlap_1der_shell, A, B)

   end subroutine get_overlap_1der_shell_ao_tool


   subroutine get_oei_1der_shell_ao_tool(ao, &
                                         oei_type, &
                                         oei_1der, &
                                         A, &
                                         B)
      !!
      !! Written by Marcus Takvam Lexander, 2024
      !!
      implicit none

      class(ao_tool) :: ao

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(:), intent(out) :: oei_1der

      integer, intent(in) :: A, B

      call ao%oei_lib%get_oei_1der_shell(oei_type, oei_1der, A, B)

   end subroutine get_oei_1der_shell_ao_tool


   subroutine get_eri_ao_tool(ao, g, A, B, C, D, precision, skip)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !!
      !! Wrapper for constructing electron repulsion integrals g for the
      !! shell quartet (A, B, C, D).
      !!
      !! The integrals are placed in g.
      !!
      !! Two optional arguments:
      !!
      !!    precision:  (intent in) Double precision real corresponding to the precision value
      !!                to use when calculating the integral. Does not guarantee a precision
      !!                to the given value and should therefore be selected conservatively.
      !!
      !!    skip:       (intent out) If present, this integer will be 1 if the integral library decided not to
      !!                calculate the integral; it will be zero otherwise. If it is present, g will
      !!                not be zeroed out if the integral library decides not to calculate g. Thus, only pass 'skip'
      !!                to the routine if you wish to avoid zeroing out elements that are negligible.
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      integer :: A, B, C, D

      real(dp), dimension(ao%shells(A)%length * ao%shells(B)%length * ao%shells(C)%length &
         * ao%shells(D)%length), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      call ao%eri_lib%get_eri(g, A, B, C, D, precision, skip)

   end subroutine get_eri_ao_tool


   subroutine get_first_order_derivative_wrt_B_giao_eri_ao_tool(ao, g, A, B, C, D)
      !!
      !! Written by Alberto Barlini, November 2022
      !!
      !! Wrapper for constructing giao first-order derivarivative wrt B electron repulsion
      !! integrals g for the shell quartet (A, B, C, D).
      !! The result is stored in g, in the order of ABCDqk, where q = 1,2,3 are
      !! Cartesian coordinates (x,y,z) and k = 1,2,3,4 are the atomic centers
      !! corresponding to the atoms where A,B,C,D are located.
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      integer :: A, B, C, D

      real(dp), dimension(ao%shells(A)%length * ao%shells(B)%length * ao%shells(C)%length &
         * ao%shells(D)%length * 3), intent(out) :: g

      call ao%eri_lib%get_first_order_derivative_wrt_B_giao_eri(g, A, B, C, D)

   end subroutine get_first_order_derivative_wrt_B_giao_eri_ao_tool


   subroutine get_eri_1der_ao_tool(ao, g, A, B, C, D, precision, skip)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !!
      !! Wrapper for constructing first derivative electron repulsion integrals g for the
      !! shell quartet (A, B, C, D). The result is stored in g, in the order of ABCDqk, where
      !! q = 1,2,3 are Cartesian coordinates (x,y,z) and k = 1,2,3,4 are the atomic centers
      !! corresponding to the atoms where A,B,C,D are located.
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      integer :: A, B, C, D

      real(dp), dimension(ao%shells(A)%length * ao%shells(B)%length * ao%shells(C)%length &
         * ao%shells(D)%length * 12), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      call ao%eri_lib%get_eri_1der(g, A, B, C, D, precision, skip)

   end subroutine get_eri_1der_ao_tool


   subroutine relevant_elements_in_basis_and_molecule_grid_ao_tool(ao, grid)
      !!
      !! Written by Marco Scavino, Apr 2021
      !!
      !! Screening of the basis functions. The basis is split into blocks both along the grid points and the basis functions.
      !! The blocks indeces are saved if any basis function primitive is not negligible
      !!
      use batching_index_class
      use math_utilities, only: double_factorial
      use molecule_grid_class, only: molecule_grid

      implicit none

      class(ao_tool), intent(in) :: ao
      class(molecule_grid), intent(inout) :: grid

      logical :: mu_non_zero, pt_non_zero
      real(dp), parameter :: PRIMITIVE_CUTOFF = 1.0e-22

      integer :: atom, pt, sh, primitive, mu, l, m_l, m_l_cart, pt_block
      integer :: i_block, tot_blocks, mu_block, prev_block
      real(dp), dimension(3) :: r
      real(dp) :: alpha, coeff, r_sq, val
      real(dp) :: normalization_constant, overlap_primitives

      type(batching_index) :: pt_batch, mu_batch

      logical :: mu_block_non_zero(grid%ao_batch%num_batches)

      if (grid%n_points == 0) then

         call output%error_msg("No grid generated! Impossible to apply the screening of basis")

      end if

      pt_batch = grid%pt_batch
      mu_batch = grid%ao_batch

      call mem%alloc(grid%non_zeros, mu_batch%num_batches, pt_batch%num_batches, set_zero=.true.)
      call mem%alloc(grid%non_zero_count, pt_batch%num_batches, set_zero=.true.)

      tot_blocks = 0
      mu_block = 0

      !$omp parallel do firstprivate(pt_batch, mu_batch) private(pt_block, i_block, pt_non_zero, mu_block_non_zero, &
      !$omp & pt, mu, prev_block, mu_block, atom, r, r_sq, sh, l, m_l_cart, mu_non_zero, &
      !$omp & primitive, coeff, alpha, val, m_l, normalization_constant, overlap_primitives) &
      !$omp reduction(+:tot_blocks)
      do pt_block = 1, pt_batch%num_batches

         call pt_batch%determine_limits(pt_block)

         mu_block_non_zero(:) = .false.

         do pt = pt_batch%first, pt_batch%get_last()

            mu = 0
            mu_block = 0

            do atom = 1, grid%num_atoms

               ! Get the atom coord (convert to bohr)

               r(:) = grid%points(:, pt) - ao%centers(atom)%coordinates(:) * angstrom_to_bohr

               r_sq = r(1) * r(1) + r(2) * r(2) + r(3) * r(3)

               do sh = 1, ao%centers(atom)%n_shells  !loop on shell

                  l = ao%centers(atom)%shells(sh)%get_angular_momentum()
                  m_l_cart = ((l + 2) * (l + 1)) / 2
                  overlap_primitives = ao%centers(atom)%shells(sh)%get_overlap_of_primitives()

                  mu_non_zero = .false.

                  do primitive = 1, ao%centers(atom)%shells(sh)%get_n_primitives()  !loop over primitives

                     coeff = ao%centers(atom)%shells(sh)%get_coefficient_i(primitive)
                     alpha = ao%centers(atom)%shells(sh)%get_exponent_i(primitive)

                     normalization_constant = (four * alpha) &
                                              **(real(l, dp) * half + three * quarter) &
                                              * sqrt((two * pi)**(three * half) * overlap_primitives &
                                              * real(double_factorial(2 * l - 1), dp))

                     val = abs(normalization_constant * coeff) * exp(- alpha * r_sq)

                     if (val > PRIMITIVE_CUTOFF) then

                        ! Found at least one primitive in shell not negligible

                        mu_non_zero = .true.
                        exit

                     end if

                  end do  !loop over primitives

                  do m_l = 1, m_l_cart

                     ! Check all block, if any is valid then current block of points has at least one valid block

                     mu = mu + 1

                     mu_block = (mu - 1) / mu_batch%max_length + 1

                     mu_block_non_zero(mu_block) = mu_block_non_zero(mu_block) .or. mu_non_zero

                  end do

               end do  !loop shells

            end do  !loop atom

         end do  !loop points

         i_block = 0

         do mu_block = 1, mu_batch%num_batches

            if (mu_block_non_zero(mu_block)) then

               i_block = i_block + 1

               grid%non_zeros(i_block, pt_block) = mu_block

            end if

         end do

         grid%non_zero_count(pt_block) = i_block
         tot_blocks = tot_blocks + i_block

      end do  !loop block points
      !$omp end parallel do

      call output%printf("n", &
                         "Screening: non-zero blocks (i0) over (i0) total blocks", &
                         ints=[tot_blocks, mu_batch%num_batches * pt_batch%num_batches], &
                         fs="(/t6,a)")

   end subroutine relevant_elements_in_basis_and_molecule_grid_ao_tool


   subroutine initialize_external_charges_from_point_charges_ao_tool(ao, pc)
      !!
      !! Written by Sarai D. Folkestad, 2020
      !!
      !! Initializes the external charge engines that are needed for
      !! embedding (QM/MM)
      !!

      implicit none

      class(ao_tool), intent(inout) :: ao

      type(point_charges), intent(in) :: pc

      call ao%oei_lib%initialize_external_charges_from_point_charges(pc)

   end subroutine initialize_external_charges_from_point_charges_ao_tool


   subroutine initialize_external_charges_ao_tool(ao, n_charges, positions, charges)
      !!
      !! Written by Sarai D. Folkestad, 2020
      !!
      !! Initializes the external charge engines that are needed for
      !! embedding (QM/MM)
      !!

      implicit none

      class(ao_tool), intent(inout) :: ao

      integer, intent(in) :: n_charges
      real(dp), dimension(3, n_charges), intent(in) :: positions
      real(dp), dimension(n_charges), intent(in) :: charges

      call ao%oei_lib%initialize_external_charges(n_charges, positions, charges)

   end subroutine initialize_external_charges_ao_tool


   subroutine initialize_external_unit_charges_ao_tool(ao, n_charges, positions)
      !!
      !! Written by Sarai D. Folkestad, 2020
      !!

      implicit none

      class(ao_tool), intent(inout) :: ao

      integer, intent(in) :: n_charges
      real(dp), dimension(3, n_charges), intent(in) :: positions

      call ao%oei_lib%initialize_external_unit_charges(n_charges, positions)

   end subroutine initialize_external_unit_charges_ao_tool


   subroutine initialize_oei_ao_tool(ao, oei_type)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Routine to allocate one-electron integrals that are
      !! to be kept in memory in the AO tool.
      !!
      !! Valid oei_type values:
      !!
      !!    - 'hamiltonian'  One-electron Hamiltonian (h)
      !!    - 'overlap'      AO overlap (S)
      !!    - 'electrostatic potential'      Coulombic interaction of electrons
      !!                              with the external charges (v)
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      character(len=*), intent(in) :: oei_type

      if (trim(oei_type) == 'hamiltonian') then

         if (.not. allocated(ao%h)) call mem%alloc(ao%h, ao%n, ao%n)

      elseif (trim(oei_type) == 'overlap') then

         if (.not. allocated(ao%s)) call mem%alloc(ao%s, ao%n, ao%n)

      elseif (trim(oei_type) == 'electrostatic potential') then

         if (.not. allocated(ao%v)) call mem%alloc(ao%v, ao%n, ao%n)

      else

         call output%error_msg( &
                 'Did not recognize one-electron integral (a0) to initialize. Some integrals (e.g. dipole)&
                 & can only be constructed on-the-fly - see the get_oei routine.' &
              )

      end if

   end subroutine initialize_oei_ao_tool


   subroutine destruct_oei_ao_tool(ao, oei_type)
      !!
      !! Written by Eirik F. Kjoenstad and Linda Goletto, Dec 2022
      !!
      !! Routine to deallocate one-electron integrals.
      !!
      !! Valid oei_type values:
      !!
      !!    - 'hamiltonian'  One-electron Hamiltonian (h)
      !!    - 'overlap'      AO overlap (S)
      !!    - 'electrostatic potential'      Coulombic interaction of electrons
      !!                              with the external charges (v)
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      character(len=*), intent(in) :: oei_type

      if (trim(oei_type) == 'hamiltonian') then

         if (allocated(ao%h)) call mem%dealloc(ao%h)

      elseif (trim(oei_type) == 'overlap') then

         if (allocated(ao%s)) call mem%dealloc(ao%s)

      elseif (trim(oei_type) == 'electrostatic potential') then

         if (allocated(ao%v)) call mem%dealloc(ao%v)

      else

         call output%error_msg( &
                 'Did not recognize one-electron integral (a0) to destruct.' &
              )

      end if

   end subroutine destruct_oei_ao_tool


   subroutine construct_stored_oei_ao_tool(ao, oei_type, screening)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! This routine only constructs integrals that are internally stored.
      !! For computing integrals on-the-fly, use the get_oei routine.
      !!
      !! 'oei_type' can be:
      !!
      !!    - 'hamiltonian'           One-electron Hamiltonian (h)
      !!    - 'overlap'               AO overlap (S)
      !!    - 'electrostatic potential'      Coulombic interaction of electrons
      !!                              with the external charges (v)
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      character(len=*), intent(in) :: oei_type

      logical, intent(in), optional :: screening


      if (trim(oei_type) == 'hamiltonian') then

         call ao%initialize_oei('hamiltonian')
         call ao%get_oei('hamiltonian', ao%h, screening)

      elseif (trim(oei_type) == 'overlap') then

         call ao%initialize_oei('overlap')
         call ao%get_oei('overlap', ao%s)

      elseif (trim(oei_type) == 'electrostatic potential') then

         call ao%initialize_oei('electrostatic potential')
         call ao%get_oei('electrostatic potential', ao%v, screening)

      else

         call output%error_msg( &
                 'Did not recognize one-electron integral (a0) to construct. Some integrals (e.g. dipole) can&
                 & only be constructed on-the-fly - see the get_oei routine.', &
                 chars=[trim(oei_type)] &
              )

      end if

   end subroutine construct_stored_oei_ao_tool


   subroutine print_centers_ao_tool(ao, units)
      !!
      !! Written by Eirik F. Kjoenstad, Alexander C. Paul and Tor S. Haugland, 2018-2021
      !!
      !! Prints xyz of the molecular geometry in the unit specified ('angstrom' or 'bohr').
      !!
      implicit none

      class(ao_tool), intent(in) :: ao
      character(len=*), intent(in) :: units

      real(dp) :: conversion_factor

      integer :: I, line_length

      logical :: print_basis, print_ghost, print_separator

      real(dp), dimension(3) :: position_

      ! Print header for coordinate print

      line_length = 80

      call output%print_separator(pl='m', symbol='=', n=line_length, fs='(/t6,a)')

      call output%printf('m', 'Geometry ((a0))', chars=[get_units_label(units)], fs='(t37,a)')

      call output%print_separator(pl='minimal', symbol='=', n=line_length, fs='(t6,a)')

      !Atom           X                  Y                  Z         #internal  #input

      call output%printf('m', &
                         'Atom           X                  Y                  Z         #internal  #input', &
                         ll=100, &
                         fs='(t6,a)')

      call output%print_separator(pl='minimal', symbol='=', n=line_length, fs='(t6,a)')

      ! Print actual coordinates

      conversion_factor = get_conversion_factor(from='angstrom', to=units)

      do I = 1, ao%n_centers

         if (I == 1) then
            print_basis = .true.
            print_ghost = ao%centers(I)%is_ghost()
            print_separator = .false.
         else
            print_basis = ao%centers(I - 1)%basis /= ao%centers(I)%basis
            print_ghost = (.not. ao%centers(I - 1)%is_ghost()) .and. ao%centers(I)%is_ghost()
            print_separator = ao%centers(I - 1)%is_ghost() .and. (.not. ao%centers(I)%is_ghost())
         end if

         if (print_ghost) then

            call output%printf('m', &
                               '============================== Ghost atoms ==================================&
                               &===', &
                               fs='(t6,a)')

         end if

         if (print_separator) then
            call output%print_separator(pl='m', symbol='=', n=line_length, fs='(t6,a)')
         end if

         if (print_basis) then

            call output%printf('m', &
                               'Basis: ' // trim(ao%centers(I)%get_basis_set_name()), &
                               fs='(t6,a)')

         end if

         position_ = ao%centers(I)%coordinates * conversion_factor

         call output%printf('m', &
                            '(b4) (f18.12) (f18.12) (f18.12)  (i9)  (i6)', &
                            chars=[ao%centers(I)%symbol], &
                            ints=[I, ao%centers(I)%input_number], &
                            reals=position_, &
                            ll=100, &
                            fs='(t6,a)')

      end do

      call output%print_separator(pl='m', symbol='=', n=line_length, fs='(t6,a)')

   end subroutine print_centers_ao_tool


   subroutine set_atomic_centers_ao_tool(ao, R, units)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Updates the position of the atomic centers and updates internal variables
      !! that depend on these positions.
      !!
      !!    R:     New position for the centers (3 x n_atoms)
      !!    units: 'angstrom' or 'bohr', unit of R
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      real(dp), dimension(3, ao%n_centers), intent(in) :: R

      character(len=*), intent(in) :: units

      call ao%set_atomic_center_positions(R, units)

      call ao%export_centers_to_integral_libraries()

      call ao%calculate_geometry_dependent_variables()

   end subroutine set_atomic_centers_ao_tool


   subroutine calculate_geometry_dependent_variables(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Calculates any variable in the object that will depends on the position of
      !! the centers. Should be called on initialization of the object and whenever the
      !! center positions are altered.
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      call ao%construct_stored_oei('overlap')
      call ao%construct_stored_oei('hamiltonian', screening=.true.)

      call ao%determine_linearly_independent_aos()

      call ao%construct_cs_eri_max_screenings()

   end subroutine calculate_geometry_dependent_variables


   subroutine set_atomic_center_positions(ao, R, units)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      real(dp), dimension(3, ao%n_centers), intent(in) :: R

      character(len=*), intent(in) :: units

      integer :: I

      real(dp) :: conversion

      conversion = get_conversion_factor(from=units, to='angstrom')

      do I = 1, ao%n_centers

         ao%centers(I)%coordinates(:) = R(:, I) * conversion

      end do

   end subroutine set_atomic_center_positions


   subroutine calculate_n_pure_and_n_cartesian_ao_tool(ao)
      !!
      !! Written by Tommaso Giovannini, 2019
      !!
      implicit none

      class(ao_tool) :: ao
      integer :: i, j, l

      ao%n_cartesian = 0
      ao%n_pure_basis = 0

      do i = 1, ao%n_centers

         do j = 1, ao%centers(i)%n_shells

            l = ao%centers(i)%shells(j)%get_angular_momentum()

            ao%n_pure_basis = ao%n_pure_basis + 2 * l + 1
            ao%n_cartesian = ao%n_cartesian + (l + 1) * (l + 2) / 2

         end do

      end do


   end subroutine calculate_n_pure_and_n_cartesian_ao_tool


   function is_basis_cartesian_ao_tool(ao) result(is_cartesian)
      !!
      !! Written by Tommaso Giovannini, 2024
      !!
      !! Checks whether the basis set is cartesian
      !!
      implicit none

      class(ao_tool) :: ao

      logical :: is_cartesian

      is_cartesian = .false.  !default

      if (ao%n_cartesian == ao%n .and. all(ao%centers(:)%cartesian)) then

         is_cartesian = .true.

      else if (ao%n_pure_basis == ao%n .and. all(.not. ao%centers(:)%cartesian)) then

         is_cartesian = .false.

      else

         call output%error_msg("Cannot mix spherical and cartersian basis functions.")

      end if

   end function is_basis_cartesian_ao_tool


   subroutine transform_to_cartesian_ao_tool(ao, matrix_in, matrix_out)
      !!
      !! Written by Tommaso Giovannini and Marco Scavino, March 2019
      !!
      !! Convert a matrix to cartesian from pure
      !!
      !! The matrix in input or output in cartesian is in LibInt order default
      !!
      !! d: xx xy xz yy yz zz
      !! f: xxx xxy xxz xyy xyz xzz yyy yyz yzz zzz
      !! g: xxxx xxxy xxxz xxyy xxyz xxzz xyyy xyyz xyzz xzzz yyyy yyyz yyzz yzzz zzzz
      !!
      !! No transformation is needed if the basis set is already cartesian
      !!

      use shell_class, only: shell
      use range_class, only: range_

      implicit none

      class(ao_tool), target :: ao

      real(dp), dimension(ao%n, ao%n), intent(in) :: matrix_in
      real(dp), dimension(ao%n_cartesian, ao%n_cartesian), intent(inout) :: matrix_out

      integer :: atom1, sh1
      integer :: atom2, sh2

      integer :: mu_l, nu_l
      type(range_) :: mu_cart, nu_cart

      type(shell), pointer :: nu, mu
      real(dp), dimension(:, :), pointer :: nu_t, mu_t
      real(dp), dimension(:, :), allocatable :: internal

      if (ao%is_cartesian) then

         call dcopy(ao%n**2, matrix_in, 1, matrix_out, 1)
         return

      end if

      call mem%alloc(internal, ao%n_cartesian, ao%n_pure_basis)

      mu_cart%first = 1

      do atom1 = 1, ao%n_centers  !cycle on number of centers for chi_mu

         do sh1 = 1, ao%centers(atom1)%n_shells  !cycle on shell atom1

            mu => ao%centers(atom1)%shells(sh1)
            mu_t => mu%angular_momentum%conversion
            mu_l = mu%get_angular_momentum()
            mu_cart%length = (mu_l + 1) * (mu_l + 2) / 2

            nu_cart%first = 1

            do atom2 = 1, ao%n_centers  !cycle on number of centers for chi_nu

               do sh2 = 1, ao%centers(atom2)%n_shells  !cycle on shell atom 2

                  nu => ao%centers(atom2)%shells(sh2)
                  nu_t => nu%angular_momentum%conversion
                  nu_l = nu%get_angular_momentum()
                  nu_cart%length = (nu_l + 1) * (nu_l + 2) / 2

                  call dgemm("T", &
                             "N", &
                             nu_cart%length, &
                             mu%length, &
                             nu%length, &
                             one, &
                             nu_t, &
                             nu%length, &
                             matrix_in(nu%first, mu%first), &
                             size(matrix_in, 1), &
                             zero, &
                             internal, &
                             nu_cart%length)

                  call dgemm("T", &
                             "T", &
                             mu_cart%length, &
                             nu_cart%length, &
                             mu%length, &
                             one, &
                             mu_t, &
                             mu%length, &
                             internal, &
                             nu_cart%length, &
                             zero, &
                             matrix_out(mu_cart%first, nu_cart%first), &
                             size(matrix_out, 1))

                  nu_cart%first = nu_cart%first + nu_cart%length

               end do

            end do

            mu_cart%first = mu_cart%first + mu_cart%length

         end do

      end do

      call mem%dealloc(internal)

   end subroutine transform_to_cartesian_ao_tool


   subroutine transform_from_cartesian_ao_tool(ao, matrix_in, matrix_out)
      !!
      !! Written by Tommaso Giovannini and Marco Scavino, March 2019
      !!
      !! Convert a matrix from cartesian to pure
      !! The matrix in input or output in cartesian is in LibInt order default
      !!
      !! d: xx xy xz yy yz zz
      !! f: xxx xxy xxz xyy xyz xzz yyy yyz yzz zzz
      !! g: xxxx xxxy xxxz xxyy xxyz xxzz xyyy xyyz xyzz xzzz yyyy yyyz yyzz yzzz zzzz
      !!
      !! No transformation is needed if the basis set is already cartesian
      !!

      use shell_class, only: shell

      implicit none

      class(ao_tool), target :: ao

      real(dp), dimension(ao%n, ao%n), intent(inout) :: matrix_out
      real(dp), dimension(ao%n_cartesian, ao%n_cartesian), intent(in) :: matrix_in

      integer :: atom1, sh1
      integer :: atom2, sh2

      integer :: mu_l, nu_l
      type(range_) :: mu_cart, nu_cart

      type(shell), pointer :: nu, mu
      real(dp), dimension(:, :), pointer :: nu_t, mu_t

      real(dp), dimension(:, :), allocatable :: internal

      if (ao%is_cartesian) then

         call dcopy(ao%n**2, matrix_in, 1, matrix_out, 1)
         return

      end if

      call mem%alloc(internal, ao%n_cartesian, ao%n_pure_basis)

      mu_cart%first = 1

      do atom1 = 1, ao%n_centers  !cycle on number of centers for chi_mu
         do sh1 = 1, ao%centers(atom1)%n_shells  !cycle on shell atom1

            mu => ao%centers(atom1)%shells(sh1)
            mu_t => mu%angular_momentum%conversion
            mu_l = mu%get_angular_momentum()
            mu_cart%length = (mu_l + 1) * (mu_l + 2) / 2

            nu_cart%first = 1

            do atom2 = 1, ao%n_centers  !cycle on number of centers for chi_nu
               do sh2 = 1, ao%centers(atom2)%n_shells  !cycle on shell atom 2

                  nu => ao%centers(atom2)%shells(sh2)
                  nu_t => nu%angular_momentum%conversion
                  nu_l = nu%get_angular_momentum()
                  nu_cart%length = (nu_l + 1) * (nu_l + 2) / 2

                  call dgemm("N", &
                             "N", &
                             nu%length, &
                             mu_cart%length, &
                             nu_cart%length, &
                             one, &
                             nu_t, &
                             nu%length, &
                             matrix_in(nu_cart%first, mu_cart%first), &
                             size(matrix_in, 1), &
                             zero, &
                             internal, &
                             nu%length)

                  call dgemm("N", &
                             "T", &
                             mu%length, &
                             nu%length, &
                             mu_cart%length, &
                             one, &
                             mu_t, &
                             mu%length, &
                             internal, &
                             nu%length, &
                             zero, &
                             matrix_out(mu%first, nu%first), &
                             size(matrix_out, 1))

                  nu_cart%first = nu_cart%first + nu_cart%length

               end do

            end do

            mu_cart%first = mu_cart%first + mu_cart%length

         end do

      end do

      call mem%dealloc(internal)

   end subroutine transform_from_cartesian_ao_tool


   subroutine construct_cartesian_shells(ao, cartesians)
      !!
      !! Written by Marco Scavino, Apr 2023
      !! Create an array of cartesian shells
      !!

      use shell_class, only: shell

      implicit none

      class(ao_tool), intent(in) :: ao
      type(shell), intent(out), target :: cartesians(ao%n_sh)

      type(shell), pointer :: cartesian

      integer :: center, sh, tot_sh, mu

      mu = 1
      tot_sh = 1

      do center = 1, ao%n_centers

         do sh = 1, ao%centers(center)%n_shells

            cartesian => cartesians(tot_sh)
            cartesian = shell(mu, &
                              ao%centers(center)%shells(sh)%get_angular_momentum_letter(), &
                              0, &
                              .true.)

            call cartesian%copy_coefficients_and_exponents(ao%centers(center)%shells(sh))

            mu = mu + cartesian%get_length()
            tot_sh = tot_sh + 1

         end do

      end do

   end subroutine construct_cartesian_shells


   subroutine construct_chi_mu_r_ao_tool(ao, n_points, r_grid, chi_pt_mu)
      !!
      !! Written by Gioia Marrazzini and Marco Scavino, June 2019
      !!
      !! Given the index of the basis function mu, this works by finding the angular momentum
      !! looping over all functions, and then using the appropriate analytical formula evaluated
      !! at point given by r_grid
      !!

      use shell_class, only: shell

      implicit none

      class(ao_tool), intent(inout) :: ao
      integer, intent(in) :: n_points
      real(dp), dimension(3, n_points), intent(in) :: r_grid

      real(dp), dimension(n_points, ao%n_cartesian), intent(out) :: chi_pt_mu

      integer :: atom, sh, pt, mu_first, mu_last
      type(shell), allocatable :: cartesians(:)

      real(dp), dimension(3) :: r

      allocate(cartesians(ao%n_sh))
      call ao%construct_cartesian_shells(cartesians)

      !$omp parallel do private(pt, atom, sh, mu_first, mu_last, r) collapse(2)
      do pt = 1, n_points

         do sh = 1, ao%n_sh

            atom = ao%shell_to_center(sh)

            r(:) = r_grid(:, pt) - ao%centers(atom)%coordinates(:) * angstrom_to_bohr

            mu_first = cartesians(sh)%first
            mu_last = cartesians(sh)%get_last()

            chi_pt_mu(pt, mu_first:mu_last) = cartesians(sh)%get_aos_at_point(r(1), r(2), r(3))

         end do

      end do
      !$omp end parallel do

      do sh = 1, ao%n_sh
         call cartesians(sh)%cleanup()
      end do

   end subroutine construct_chi_mu_r_ao_tool


   subroutine construct_d1_chi_mu_r_ao_tool(ao, n_points, r_grid, d1_chi_pt_mu)
      !!
      !! Written by Gioia Marrazzini, June 2019
      !!
      !! Calculates gradient (d1) of generic basis function (chi) of index (mu) on the point (r)
      !! Given the index of the basis function mu, this works by finding the angular momentum
      !! looping over all functions, and then using the appropriate analytical formula evaluated
      !! at point given by r_grid
      !!

      use shell_class, only: shell

      implicit none


      class(ao_tool) :: ao
      integer, intent(in) :: n_points
      real(dp), dimension(3, n_points), intent(in) :: r_grid

      real(dp), dimension(n_points, ao%n_cartesian, 3), intent(inout) :: d1_chi_pt_mu

      ! Internal Variables

      integer :: atom, sh, pt, mu_first, mu_last

      real(dp), dimension(3) :: r

      type(shell) :: cartesians(1:ao%n_sh)

      call ao%construct_cartesian_shells(cartesians)

      ! Start counting basis functs

      !$omp parallel do private(pt, sh, atom, r, mu_first, mu_last) collapse(2)
      do pt = 1, n_points

         do sh = 1, ao%n_sh

            atom = ao%shell_to_center(sh)

            ! Get the atom coord (convert to bohr)

            r(:) = r_grid(:, pt) - ao%centers(atom)%coordinates(:) * angstrom_to_bohr

            mu_first = cartesians(sh)%first
            mu_last = cartesians(sh)%get_last()

            d1_chi_pt_mu(pt, mu_first:mu_last, :) = cartesians(sh)%get_derivative_aos_at_point(r)

         end do  !loop over shells

      end do  !loop over grid points
      !$omp end parallel do

      do sh = 1, ao%n_sh
         call cartesians(sh)%cleanup()
      end do


   end subroutine construct_d1_chi_mu_r_ao_tool


   subroutine determine_linearly_independent_aos(ao, s)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      !! This routine determines P and L, and the number of linearly
      !! independent/orthonormal AOs (n_orthonormal_ao), resulting from a Cholesky decomposition
      !! of the AO overlap matrix S to within the linear dependency threshold:
      !!
      !!    P^T S P = L L^T.
      !!
      !! If the optional argument 's' is not present, the routine assumes that the internally
      !! stored overlap matrix (ao%s) has been allocated and constructed.
      !!
      !! Modified by Rolf H. Myhre and Alexander C. Paul, Oct 2019. Included sanity check.
      !! Modified by Eirik F. Kjoenstad, Sep 2020. Introduced optional S.
      !!
      use timings_class, only: timings

      use array_utilities, only: full_cholesky_decomposition

      implicit none

      class(ao_tool), intent(inout), target :: ao

      real(dp), dimension(ao%n, ao%n), intent(in), target, optional :: s

      real(dp), dimension(:, :), pointer :: s_p  ! Points to s or ao%s

      integer, dimension(:), allocatable :: pivots  ! Vector containing selected pivots
      real(dp), dimension(:, :), allocatable :: L  ! Cholesky factor, full dimensionality

      integer :: i, j

      type(timings), allocatable :: timer

      timer = timings('Cholesky decomposition of AO overlap', 'normal')
      call timer%turn_on()

      call output%printf('n', &
                         '- Cholesky decomposition of AO overlap to get linearly independent AOs:', &
                         fs='(/t3,a)')

      if (present(s)) then

         s_p => s

      else

         s_p => ao%s

      end if

      if (allocated(ao%L)) call mem%dealloc(ao%L)
      if (allocated(ao%P)) call mem%dealloc(ao%P)

      ! Decompose AO overlap

      call mem%alloc(L, ao%n, ao%n, set_zero=.true.)
      call mem%alloc(pivots, ao%n, set_zero=.true.)

      call full_cholesky_decomposition(s_p, &
                                       L, &
                                       ao%n, &
                                       ao%n_orthonormal_ao, &
                                       ao%lindep_threshold, &
                                       pivots)

      if (ao%n_orthonormal_ao > ao%n .or. ao%n_orthonormal_ao <= 0 .or. any(pivots > ao%n) .or. &
          any(pivots <= 0)) then

         call output%printf('m', &
                            'Something went wrong when decomposing the AO overlap.', &
                            fs='(/t3,a)')

         call output%printf('m', &
                            'Did you compile with wrong type of integers in setup? For example system native&
                            & BLAS with default 64-bit integers.', &
                            ffs='(/t3,a)')

         call output%printf('m', 'If that is the case, use setup with --int32 or install MKL.')

         call output%error_msg('Failed to decompose AO overlap.')

      end if

      ! Set Cholesky factor L and pivot matrix P

      call mem%alloc(ao%L, ao%n_orthonormal_ao, ao%n_orthonormal_ao)

      !$omp parallel do private(j, i)
      do j = 1, ao%n_orthonormal_ao
         do i = 1, ao%n_orthonormal_ao

            ao%L(i, j) = L(i, j)

         end do
      end do
      !$omp end parallel do

      call mem%dealloc(L)

      call mem%alloc(ao%P, ao%n, ao%n_orthonormal_ao, set_zero=.true.)

      !$omp parallel do private(j)
      do j = 1, ao%n_orthonormal_ao

         ao%P(pivots(j), j) = one

      end do
      !$omp end parallel do

      call mem%dealloc(pivots)

      call output%printf('m', &
                         'Linear dependence threshold:             (e8.2)', &
                         reals=[ao%lindep_threshold], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Number of atomic orbitals:               (i0)', &
                         ints=[ao%n], &
                         fs='(t6,a)')

      call output%printf('m', &
                         'Number of orthonormal atomic orbitals:   (i0)', &
                         ints=[ao%n_orthonormal_ao], &
                         fs='(t6,a)')

      if (ao%n_orthonormal_ao < ao%n) &
         call output%printf('m', &
                            'Removed (i0) AOs due to linear dep.', &
                            ints=[ao%n - ao%n_orthonormal_ao], &
                            fs='(/t6,a)')

      call timer%turn_off()

   end subroutine determine_linearly_independent_aos


   subroutine get_sad_guess_ao_tool(ao, D)
      !!
      !! Written by Eirik F. Kjoenstad, Aug-Sep 2018 and Sep 2020
      !!
      !! Constructs the block-diagonal SAD density D from atomic UHF densities stored on file.
      !!
      !! The UHF calculations have been performed with valence electrons evenly spread out in
      !! the degenerate HOMO orbitals to ensure a spherically symmetric AO density.
      !!
      !! Moved and adapted to AO tool, removed loop allocations, Eirik F. Kjoenstad, 2020
      !!
      use array_initialization, only: zero_array

      implicit none

      class(ao_tool) :: ao

      real(dp), dimension(ao%n, ao%n), intent(out) :: D

      real(dp), dimension(:), allocatable, target :: D_I  ! Holds Ith atomic density
      real(dp), dimension(:, :), pointer :: D_I_p  ! Pointer to Ith atomic density

      integer :: I, w, x, w_full, x_full

      type(range_), allocatable :: aos_I

      call zero_array(D, ao%n**2)

      allocate(aos_I)

      call mem%alloc(D_I, ao%n**2)

      do I = 1, ao%n_centers

         if (ao%centers(I)%is_ghost()) cycle
         if (ao%centers(I)%number_ == ao%centers(I)%charge) cycle  ! No electrons on this atom

         ! Read the atomic density at the Ith center and set pointer
         ! to the relevant portion of the array

         call ao%centers(I)%read_atomic_uhf_density(D_I)

         aos_I = ao%centers(I)%get_ao_range()

         D_I_p(1:aos_I%length, 1:aos_I%length) => D_I(1:aos_I%length**2)

         ! Copy the atomic density into the full space matrix D

         do w = 1, aos_I%length
            do x = 1, aos_I%length

               w_full = w + aos_I%first - 1
               x_full = x + aos_I%first - 1

               D(w_full, x_full) = D_I_p(w, x)

            end do
         end do

      end do

      call mem%dealloc(D_I)

      deallocate(aos_I)

   end subroutine get_sad_guess_ao_tool


   subroutine get_aos_in_subset_ao_tool(ao, subset, first, last)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Gets AOs in center subset specified by 'subset' and optionally returns the first
      !! and last AO indices.
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      character(len=*), intent(in) :: subset

      integer, intent(out), optional :: first
      integer, intent(out), optional :: last

      integer :: set, I

      class(range_), allocatable :: aos

      ! Test if there's nothing to do; if so, tell the developer not to be silly

      if (.not. present(first) .and. .not. present(last)) &
         call output%error_msg('You must specify either first or last in get_aos_in_subset.')

      ! Get the center subset associated with 'subset'

      do set = 1, ao%n_center_subsets

         if (trim(subset) == trim(ao%center_subsets(set)%get_name())) then

            ! Return the requested AO indices

            if (present(first)) then

               I = ao%center_subsets(set)%first
               aos = ao%centers(I)%get_ao_range()

               first = aos%first

            end if

            if (present(last)) then

               I = ao%center_subsets(set)%get_last()
               aos = ao%centers(I)%get_ao_range()

               last = aos%get_last()

            end if

            return

         end if

      end do

      ! Haven't returned? Subset not found!

      call output%error_msg('Could not recognize subset (a0)!', chars=[subset])

   end subroutine get_aos_in_subset_ao_tool


   function is_center_subset_ao_tool(ao, subset) result(is_center_subset)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Checks whether 'subset' corresponds to one of center subsets.
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      character(len=*), intent(in) :: subset

      logical :: is_center_subset

      integer :: set

      is_center_subset = .false.

      do set = 1, ao%n_center_subsets

         if (trim(subset) == trim(ao%center_subsets(set)%get_name())) then

            is_center_subset = .true.
            return

         end if

      end do

   end function is_center_subset_ao_tool


   function get_n_centers_in_subset_ao_tool(ao, subset) result(n_centers)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Returns the number of centers in subset with name 'subset'.
      !! Returns 0 if the set does not exist.
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      character(len=*), intent(in) :: subset

      integer :: n_centers, I

      n_centers = 0

      do I = 1, ao%n_center_subsets

         if (trim(ao%center_subsets(I)%get_name()) == trim(subset)) then

            n_centers = ao%center_subsets(I)%length
            return

         end if

      end do

   end function get_n_centers_in_subset_ao_tool


   subroutine set_integral_precision_ao_tool(ao, integral_precision)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Sets the default integral precision, and sets the depending
      !! values for the oei precision and the eri precision
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      real(dp), intent(in) :: integral_precision

      ao%eri_precision = integral_precision

      call ao%eri_lib%set_eri_precision(ao%eri_precision)
      call ao%oei_lib%set_oei_precision(ao%eri_precision * 1.0d-5)

   end subroutine set_integral_precision_ao_tool


   pure function get_eri_precision_ao_tool(ao) result(eri_precision)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      real(dp) :: eri_precision

      eri_precision = ao%eri_lib%get_eri_precision()

   end function get_eri_precision_ao_tool


   subroutine get_center_ao_tool(ao, I, center)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Sets 'center' equal to the Ith atomic center according
      !! to the AO tool.
      !!
      !! Note: the returned 'center' object does not have initialized shells.
      !!       The initialization of shells is performed during the initialization
      !!       of the AO tool based on center objects, e.g. 'center'.
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      integer, intent(in) :: I

      type(atomic_center), intent(inout) :: center

      if (I > ao%n_centers) &
         call output%error_msg('Center index (i0) greater than total number of centers (i0)', &
                               ints=[I, ao%n_centers])

      center = ao%centers(I)

   end subroutine get_center_ao_tool


   function get_first_ao_index_of_center(ao, center) result(first_ao)
      !!
      !! Written by Alexander C. Paul, Aug 2023
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      integer, intent(in) :: center
      integer :: first_ao

      first_ao = ao%centers(center)%shells(1)%first

   end function get_first_ao_index_of_center


   pure function get_n_centers_ao_tool(ao) result(n_centers)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Returns ao%n_centers.
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      integer :: n_centers

      n_centers = ao%n_centers

   end function get_n_centers_ao_tool


   subroutine get_reduced_ao_metric_ao_tool(ao, S)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018-2020
      !!
      !! Constructs the AO overlap matrix in the
      !! linearly independent ao basis
      !!
      !!    S = L L^T
      !!
      implicit none

      class(ao_tool), intent(in) :: ao
      real(dp), dimension(ao%n_orthonormal_ao, ao%n_orthonormal_ao), intent(out) :: S

      call dgemm('N', &
                 'T', &
                 ao%n_orthonormal_ao, &
                 ao%n_orthonormal_ao, &
                 ao%n_orthonormal_ao, &
                 one, &
                 ao%L, &
                 ao%n_orthonormal_ao, &
                 ao%L, &
                 ao%n_orthonormal_ao, &
                 zero, &
                 S, &
                 ao%n_orthonormal_ao)

   end subroutine get_reduced_ao_metric_ao_tool


   function get_n_orthonormal_ao_ao_tool(ao) result(n_orthonormal_ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      integer :: n_orthonormal_ao

      n_orthonormal_ao = ao%n_orthonormal_ao

   end function get_n_orthonormal_ao_ao_tool


   subroutine print_ao_vectors_ao_tool(ao, C, out_file, m, offset)
      !!
      !! Written by Eirik F. Kjoenstad, Tor S. Haugland, and Alexander C. Paul, 2019-2020
      !!
      !! This routine contains parts of a routine, written & modified by Eirik F. Kjoenstad,
      !! Tor S. Haugland, and Alexander C. Paul, that was originally part of the HF wavefunction.
      !! Moved to AO tool by Eirik F. Kjoenstad, 2020.
      !!
      !! Prints the array 'C' to the output file 'out'
      !!
      !!    C:        (n_ao x m) real double precision vector to print
      !!    out_file: output file where C is to be printed
      !!    m:        Number of vectors; i.e., second dimension of C
      !!    offset:   Number/label for the vectors in C. In particular, k + offset
      !!              is the label given to kth column of C.
      !!
      !! The C-amplitudes along each AO is printed with detailed information
      !! of the AO in question (center, angular momentum and projection, l and m_l,
      !! and so on).
      !!
      use output_file_class, only: output_file

      implicit none

      class(ao_tool), intent(in) :: ao

      integer, intent(in) :: m

      integer, intent(in) :: offset

      real(dp), dimension(ao%n, m), intent(in) :: C

      type(output_file), intent(in) :: out_file

      integer :: w, A, w_red, p, I

      logical :: adv

      character(len=2) :: symbol
      character(len=8) :: angular_momentum
      character(len=50) :: n_format_string
      character(len=7) :: format_string = '(f10.6)'

      call out_file%printf('n', '  AO    Center  l m_l', fs='(/t3,a)', adv=.false.)

      do p = 1, m

         adv = (p == m)

         call out_file%printf('n', '(i4)', adv=adv, ints=[p + offset], fs='(8x,a)')

      end do

      call out_file%print_separator(pl='normal', n=87, symbol='-')

      do I = 1, ao%n_centers

         symbol = trim(ao%centers(I)%symbol)

         do A = 1, ao%centers(I)%n_shells

            do w = ao%centers(I)%shells(A)%first, ao%centers(I)%shells(A)%get_last()

               w_red = w - ao%centers(I)%shells(A)%first + 1

               angular_momentum = ao%centers(I)%shells(A)%get_angular_momentum_label(w_red)

               ! Setup the string for printf to print the right number of reals

               n_format_string = repeat('  ' // format_string, m)

               call out_file%printf('n', &
                                    '(i4) (i4) (b4)  ' // angular_momentum // n_format_string, &
                                    reals=[C(w, 1:m)], &
                                    ints=[w, I], &
                                    chars=[symbol], &
                                    ll=87)

            end do

         end do

      end do

      call out_file%print_separator(pl='normal', n=87, symbol='-')

   end subroutine print_ao_vectors_ao_tool


   subroutine construct_cs_eri_max_screenings(ao)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      !! Computes a vector that contains the largest value (in absolute terms)
      !! of g_wxwx^1/2 for each shell pair (A,B), where w and x is in A and B,
      !! respectively. This array is sorted from largest to smallest and the
      !! sorting indices stored for convenient access.
      !!
      !! In addition, the routine uses the array to determine the number of
      !! shell pairs that are significant (with respect to the ERI precision value).
      !! This is based on the Cauchy-Schwarz inequality
      !!
      !!    abs ( g_wxyz ) <= g_wxwx^1/2 * g_yzyz^1/2 <= g_wxwx^1/2 * (max g)
      !!
      use timings_class, only: timings
      use array_utilities, only: quicksort_with_index_descending, get_abs_max, quicksort_ascending_int
      use array_initialization, only: zero_array

      implicit none

      class(ao_tool), intent(inout) :: ao

      integer :: A, B, AB
      integer :: s1, s2, s1s2, s1s2_packed

      real(dp) :: maximum

      real(dp), dimension(ao%max_sh_size**4) :: g

      type(timings), allocatable :: timer, timer_sort

      timer = timings('Construct Cauchy-Schwarz ERI screenings (total time)', 'v')
      call timer%turn_on()

      ! Compute the maximum element in each shell pair, and store indices

      !$omp parallel do private(A, B, AB, g, maximum) schedule(dynamic)
      do A = 1, ao%n_sh
         do B = 1, A

            AB = (max(A, B) * (max(A, B) - 3) / 2) + A + B

            call ao%get_eri(g, A, B, A, B)

            maximum = get_abs_max(g, (ao%shells(A)%length * ao%shells(B)%length)**2)

            ao%cs_eri_max(AB, 2) = sqrt(maximum)

            ao%cs_eri_max_indices(AB, 1) = A
            ao%cs_eri_max_indices(AB, 2) = B

         end do
      end do
      !$omp end parallel do

      ! Sort the Cauchy-Schwarz maximum elements from largest to smallest, and store sorting indices

      call dcopy(ao%n_sh * (ao%n_sh + 1) / 2, &
                 ao%cs_eri_max(:, 2), &
                 1, &
                 ao%cs_eri_max(:, 1), &
                 1)

      timer_sort = timings('Construct Cauchy-Schwarz ERI screenings (time to sort)', 'v')
      call timer_sort%turn_on()

      call quicksort_with_index_descending(ao%cs_eri_max(:, 1), &  ! On exit, sorted array
                                           ao%cs_eri_max_indices(:, 3), &  ! On exit, sorting indices
                                           ao%n_sh * (ao%n_sh + 1) / 2)

      call timer_sort%turn_off()

      ! Count the number of significant ERI shell-pairs

      ao%n_sig_eri_shp = 0

      do AB = 1, ao%n_sh * (ao%n_sh + 1) / 2

         ! Check if the upper bound of (AB / CD) integrals is below ERI precision; if so,
         ! we do not consider AB to be a significant shell pair

         if (ao%cs_eri_max(AB, 1) * ao%cs_eri_max(1, 1) < ao%eri_precision) then

            exit

         else

            ao%n_sig_eri_shp = ao%n_sig_eri_shp + 1

         end if

      end do

      call zero_array(ao%cs_eri_max_sh, ao%n_sh)

      do s1s2 = 1, ao%n_sig_eri_shp

         s1s2_packed = ao%cs_eri_max_indices(s1s2, 3)
         s1 = ao%cs_eri_max_indices(s1s2_packed, 1)

         if (ao%cs_eri_max(s1s2, 1) > ao%cs_eri_max_sh(s1)) ao%cs_eri_max_sh(s1) = ao%cs_eri_max(s1s2, 1)

      end do

      ao%g_max = get_abs_max(ao%cs_eri_max_sh, ao%n_sh)

      ao%sig_s2_for_s1 = 0
      ao%n_sig_s2_for_s1 = 0

      do s1s2 = 1, ao%n_sig_eri_shp

         s1s2_packed = ao%cs_eri_max_indices(s1s2, 3)

         s1 = ao%cs_eri_max_indices(s1s2_packed, 1)
         s2 = ao%cs_eri_max_indices(s1s2_packed, 2)

         ao%n_sig_s2_for_s1(s1) = ao%n_sig_s2_for_s1(s1) + 1
         ao%sig_s2_for_S1(ao%n_sig_s2_for_s1(s1), s1) = s2

      end do

      ! Sort the columns of the sig_s4_indices matrix in ascending order

      do s1 = 1, ao%n_sh

         if (ao%n_sig_s2_for_s1(s1) > 0) then

            call quicksort_ascending_int(ao%sig_s2_for_s1(1:ao%n_sig_s2_for_s1(s1), s1), &
                                         ao%n_sig_s2_for_s1(s1))

         end if

      end do

      call timer%turn_off()

   end subroutine construct_cs_eri_max_screenings


   function get_n_frozen_orbitals_ao_tool(ao, first, last) result(n_frozen_ao)
      !!
      !! Written by Sarai D. Folkestad, 2022
      !!
      !! Determines which centers to freeze (given by the logical array 'frozen') and
      !! the total number of frozen AOs. It considers only centers 'first' to 'last'.
      !!

      implicit none

      class(ao_tool), intent(in) :: ao
      integer, intent(in) :: first, last
      integer :: n_frozen_ao

      integer :: I, n

      n_frozen_ao = 0
      do I = first, last

         n = ao%get_n_frozen_orbitals_for_center(I)

         if (n > 0) then
            n_frozen_ao = n_frozen_ao + n
         end if
      end do

   end function get_n_frozen_orbitals_ao_tool


   function get_n_frozen_orbitals_for_center_ao_tool(ao, center) result(n_frozen_ao)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, 2018-2021
      !!
      !! Return number of core orbitals for a given center
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      integer, intent(in) :: center

      integer :: n_frozen_ao

      n_frozen_ao = 0

      if (ao%centers(center)%number_ >= 5 .and. ao%centers(center)%number_ <= 12) then

         n_frozen_ao = 1

      elseif (ao%centers(center)%number_ >= 13 .and. ao%centers(center)%number_ <= 30) then

         n_frozen_ao = 5

      elseif (ao%centers(center)%number_ >= 31 .and. ao%centers(center)%number_ <= 38) then

         n_frozen_ao = 9

      elseif (ao%centers(center)%number_ >= 39 .and. ao%centers(center)%number_ <= 48) then

         n_frozen_ao = 14

      elseif (ao%centers(center)%number_ >= 49 .and. ao%centers(center)%number_ <= 70) then

         n_frozen_ao = 18

      elseif (ao%centers(center)%number_ >= 71 .and. ao%centers(center)%number_ <= 80) then

         n_frozen_ao = 23

      elseif (ao%centers(center)%number_ >= 81 .and. ao%centers(center)%number_ <= 103) then

         n_frozen_ao = 34

      elseif (ao%centers(center)%number_ >= 104 .and. ao%centers(center)%number_ <= 105) then

         n_frozen_ao = 50

      elseif (ao%centers(center)%number_ > 105) then

         call output%error_msg('No support for frozen core for Z > 105.')

      end if

   end function get_n_frozen_orbitals_for_center_ao_tool


   subroutine evaluate_aos_at_point_ao_tool(ao, x, y, z, aos_at_point)
      !!
      !! Written by Sarai D. Folkestad and Andreas Skeidsvoll, Jul 2019
      !!
      !! Evaluates all the aos at a point on a grid.
      !!
      !! 'x', 'y', 'z'  : coordinates of the grid point
      !!
      !! 'aos_at_point' : Value of the aos at the grid point (vector of dim n_ao)
      !!
      use array_initialization, only: zero_array

      implicit none

      class(ao_tool), intent(in) :: ao

      real(dp), intent(in) :: x, y, z
      real(dp), dimension(ao%n), intent(out) :: aos_at_point

      integer :: w, shell, center, n

      real(dp) :: x_rel, y_rel, z_rel

      call zero_array(aos_at_point, ao%n)

      w = 1  ! AO index

      do center = 1, ao%n_centers

         ! Find the position of the point relative to the nucleus, in atomic units

         x_rel = (x - ao%centers(center)%coordinates(1)) * angstrom_to_bohr
         y_rel = (y - ao%centers(center)%coordinates(2)) * angstrom_to_bohr
         z_rel = (z - ao%centers(center)%coordinates(3)) * angstrom_to_bohr

         ! Calculate distance between the point and the nucleus

         do shell = 1, ao%centers(center)%n_shells

            n = ao%centers(center)%shells(shell)%get_length()

            aos_at_point(w:w + n - 1) = ao%centers(center)%shells(shell)%get_aos_at_point(x_rel, y_rel, z_rel)

            w = w + n

         end do  ! end loop over shells
      end do  ! end loop over atoms

   end subroutine evaluate_aos_at_point_ao_tool


   function get_center_coordinates_ao_tool(ao) result(R_qk)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Returns the center coordinates R_qk, where q = 1, 2, 3 (corresponding to x, y, and z)
      !! and k = 1, 2, 3, ..., n_centers.
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      real(dp), dimension(3, ao%n_centers) :: R_qk

      integer :: I

      do I = 1, ao%n_centers

         R_qk(:, I) = ao%centers(I)%coordinates

      end do

   end function get_center_coordinates_ao_tool


   subroutine get_center_symbols_ao_tool(ao, symbols)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Returns the center symbols
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      character(len=2), dimension(ao%n_centers), intent(out) :: symbols

      integer :: I

      do I = 1, ao%n_centers

         symbols(I) = ao%centers(I)%symbol

      end do

   end subroutine get_center_symbols_ao_tool


   subroutine get_point_charges_ao_tool(ao, pc)
      !!
      !! Written by Sarai D.Folkestad, 2020
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      type(point_charges), intent(out) :: pc

      integer :: I

      pc = point_charges(ao%n_centers)
      call pc%initialize()

      pc%r = ao%get_center_coordinates()

      do I = 1, ao%n_centers

         pc%q(I) = real(ao%centers(I)%nuclear_charge, kind=dp)

      end do

   end subroutine get_point_charges_ao_tool


   subroutine get_subset_point_charges_ao_tool(ao, pc, name_, include_higher_priority)
      !!
      !! Written by Sarai D.Folkestad, 2020
      !!
      !! Returns the point charges of a subset
      !! or the union of subsets
      !!
      !! name_                   : Name of the subset
      !!
      !! include_higher_priority : Determines if subsets of higher priority
      !!                         should also be included.
      !!
      !!                         If include_higher_priority = .true.,
      !!                         The named subset is the last (lowest priority)
      !!                         subset that is included
      !!
      !!                         If include_higher_priority = .false.,
      !!                         The named subset is the only subset that is included
      !!
      !!
      implicit none

      class(ao_tool), intent(in) :: ao
      character(len=*), intent(in) :: name_
      logical, intent(in) :: include_higher_priority

      type(point_charges), intent(out) :: pc

      integer :: I, first, last, subset_index

      subset_index = ao%get_subset_index(name_)

      if (subset_index == 0) call output%error_msg('did not find subset of name ' // trim(name_))

      if (include_higher_priority) then
         first = 1
      else
         first = ao%center_subsets(subset_index)%first
      end if

      last = ao%center_subsets(subset_index)%get_last()

      pc = point_charges(last - first + 1)
      call pc%initialize()

      do I = first, last

         pc%r(:, I) = ao%centers(I)%coordinates(:)
         pc%q(I) = real(ao%centers(I)%nuclear_charge, kind=dp)

      end do

   end subroutine get_subset_point_charges_ao_tool


   pure function get_subset_index(ao, name_) result(subset_index)
      !!
      !! Get subset index
      !! Written by Sarai D. Folkestad, 2020
      !!
      !! Returns the index of the subset with name = name_
      !!
      !! Returns 0, if no such set exists
      !!
      implicit none

      class(ao_tool), intent(in) :: ao
      character(len=*), intent(in) :: name_
      integer :: subset_index
      integer :: I

      subset_index = 0

      do I = 1, ao%n_center_subsets

         if (ao%center_subsets(I)%get_name() == trim(name_)) subset_index = I

      end do

   end function get_subset_index


   function get_n_electrons_ao_tool(ao) result(n)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      !! Gets the number of electrons based on the total charge specified and the
      !! charges at the atomic centers
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      integer :: n

      integer :: I

      n = 0

      do I = 1, ao%n_centers

         n = n + ao%centers(I)%nuclear_charge

      end do

      n = n - ao%charge

   end function get_n_electrons_ao_tool


   subroutine copy_geometry_dependent_variables(ao, template)
      !!
      !! Written by Alexander C. Paul, Feb 2021
      !!
      use array_initialization, only: copy_integer

      implicit none

      class(ao_tool), intent(inout) :: ao
      type(ao_tool), intent(in) :: template

      call dcopy(ao%n**2, template%s, 1, ao%s, 1)

      ao%n_orthonormal_ao = template%n_orthonormal_ao

      call mem%alloc(ao%L, ao%n_orthonormal_ao, ao%n_orthonormal_ao)
      call mem%alloc(ao%P, ao%n, ao%n_orthonormal_ao)

      call dcopy(ao%n_orthonormal_ao**2, template%L, 1, ao%L, 1)
      call dcopy(ao%n * ao%n_orthonormal_ao, template%P, 1, ao%P, 1)

      ao%n_sig_eri_shp = template%n_sig_eri_shp

      call dcopy(2 * ao%n_sh * (ao%n_sh + 1) / 2, &
                 template%cs_eri_max, &
                 1, &
                 ao%cs_eri_max, &
                 1)

      call copy_integer(template%cs_eri_max_indices, &
                        ao%cs_eri_max_indices, &
                        3 * ao%n_sh * (ao%n_sh + 1) / 2)

   end subroutine copy_geometry_dependent_variables


   subroutine destructor(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      type(ao_tool) :: ao

      integer :: I

      if (allocated(ao%h)) call mem%dealloc(ao%h)
      if (allocated(ao%s)) call mem%dealloc(ao%s)
      if (allocated(ao%v)) call mem%dealloc(ao%v)

      if (allocated(ao%centers)) then

         do I = 1, ao%n_centers

            call ao%centers(I)%cleanup()

         end do

         deallocate(ao%centers)

      end if

      if (allocated(ao%shell_to_center)) call mem%dealloc(ao%shell_to_center)
      if (allocated(ao%ao_to_center)) call mem%dealloc(ao%ao_to_center)
      if (allocated(ao%ao_to_shell)) call mem%dealloc(ao%ao_to_shell)

      if (allocated(ao%L)) call mem%dealloc(ao%L)
      if (allocated(ao%P)) call mem%dealloc(ao%P)

      if (allocated(ao%cs_eri_max)) call mem%dealloc(ao%cs_eri_max)

      if (allocated(ao%cs_eri_max_indices)) call mem%dealloc(ao%cs_eri_max_indices)

      if (allocated(ao%cs_eri_max_sh)) call mem%dealloc(ao%cs_eri_max_sh)

      if (allocated(ao%sig_s2_for_s1)) call mem%dealloc(ao%sig_s2_for_s1)

      if (allocated(ao%n_sig_s2_for_s1)) call mem%dealloc(ao%n_sig_s2_for_s1)

      if (allocated(ao%oei_lib)) then
         call ao%oei_lib%cleanup()
         deallocate(ao%oei_lib)
      end if

      if (allocated(ao%eri_lib)) then
         call ao%eri_lib%cleanup()
         deallocate(ao%eri_lib)
      end if

   end subroutine destructor


   subroutine print_z_matrix_ao_tool(ao)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! Prints the Z-matrix in angstrom.
      !!

      use z_matrix_tool_class, only: z_matrix_tool

      implicit none

      class(ao_tool), intent(in) :: ao

      type(z_matrix_tool), allocatable :: z_matrix

      real(dp), dimension(:, :), allocatable :: R
      character(len=2), dimension(ao%n_centers) :: symbols

      z_matrix = z_matrix_tool(ao%n_centers)
      call z_matrix%initialize()

      call mem%alloc(R, 3, ao%n_centers)

      R = ao%get_center_coordinates()
      call ao%get_center_symbols(symbols)

      call z_matrix%construct(R, symbols)
      call z_matrix%print_(output)

      call mem%dealloc(R)

      call z_matrix%cleanup_z_matrix()

   end subroutine print_z_matrix_ao_tool


   pure function has_ghost_atoms_ao_tool(ao) result(has_ghosts)
      !!
      !! Has ghost atoms?
      !! Written by Tor S. Haugland, May 2021
      !!
      !! Are ghost atoms present in system?
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      logical :: has_ghosts
      integer :: I

      has_ghosts = .false.
      do I = 1, ao%get_n_centers()
         has_ghosts = has_ghosts .or. ao%centers(I)%is_ghost()
      end do

   end function has_ghost_atoms_ao_tool


   function get_molden_ao_indices_ao_tool(ao) result(map)
      !!
      !! Written by Alexander C. Paul, May 2021
      !!
      !! Return index list mapping AOs to the order molden expects
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      integer, dimension(ao%n) :: map

      type(range_), allocatable :: aos
      integer :: c

      do c = 1, ao%n_centers

         aos = ao%centers(c)%get_ao_range()

         map(aos%first:aos%get_last()) = ao%centers(c)%get_molden_order()

      end do

   end function get_molden_ao_indices_ao_tool


   function get_ao_normalization_factors_ao_tool(ao) result(factors)
      !!
      !! Written by Alexander C. Paul and Tommaso Giovannini, 2021-2024
      !!
      !! The normalization factors are the sqrt of the overlap matrix
      !! diagonal elements
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      real(dp), dimension(ao%n) :: factors

      type(range_), allocatable :: aos
      integer :: c
      integer :: i

      do c = 1, ao%n_centers

         aos = ao%centers(c)%get_ao_range()

         do i = aos%first, aos%get_last()

            factors(i) = sqrt(ao%s(i, i))

         end do

      end do

   end function get_ao_normalization_factors_ao_tool


   subroutine print_molden_geometry_ao_tool(ao, file_)
      !!
      !! Written by Alexander C. Paul, May 2021
      !!
      !! Geometry in bohr in the format:
      !! Element  number  "Atomic number"  x  y  z
      !!
      use output_file_class, only: output_file

      implicit none

      class(ao_tool), intent(in) :: ao
      type(output_file), intent(inout) :: file_

      integer :: c

      do c = 1, ao%n_centers

         call file_%printf('m', &
                           '(b2)   (i5)   (i3)   (f15.10)  (f15.10)  (f15.10)', &
                           chars=[ao%centers(c)%symbol], &
                           fs='(t1,a)', &
                           reals=[ao%centers(c)%coordinates * angstrom_to_bohr], &
                           ints=[c, ao%centers(c)%number_])

      end do

   end subroutine print_molden_geometry_ao_tool


   subroutine append_geometry_to_xyz_ao_tool(ao, file_)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use output_file_class, only: output_file

      implicit none

      class(ao_tool) :: ao

      class(output_file) :: file_

      integer :: c

      call file_%printf('m', '(i0)', ints=[ao%n_centers], fs='(t1,a/)')

      do c = 1, ao%n_centers

         call file_%printf('m', &
                           '(b2)3(f19.12)', &
                           chars=[ao%centers(c)%symbol], &
                           fs='(t1,a)', &
                           reals=[ao%centers(c)%coordinates])

      end do

   end subroutine append_geometry_to_xyz_ao_tool


   subroutine save_geometry_to_xyz_ao_tool(ao, file_)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use output_file_class, only: output_file

      implicit none

      class(ao_tool) :: ao

      class(output_file) :: file_

      call file_%open_()

      call ao%append_geometry_to_xyz(file_)

      call file_%close_()

   end subroutine save_geometry_to_xyz_ao_tool


   subroutine print_basis_set_molden_ao_tool(ao, file_)
      !!
      !! Written by Alexander C. Paul, May 2021
      !!
      !! Prints basis set for a molden file:
      !! Atom number 0
      !! shell-label n_primitives 1.00
      !! exponent coefficient
      !! "empty line"
      !!
      !! The atom number is the number in eT (as printed in print_molden_geometry)
      !! The shell label is the angular momentum converted to a letter (s,p,d,f,g)
      !!
      !! If a spherical basis set is used we need to add [5D7F] and [9G].
      !! NB: Mixed spherical and cartesian basis sets are not supported
      !!
      use output_file_class, only: output_file

      implicit none

      class(ao_tool), intent(in) :: ao
      type(output_file), intent(inout) :: file_

      integer :: c, s, i, n
      logical :: cartesian

      do c = 1, ao%n_centers

         call file_%printf('m', '(i0) 0', fs='(t1,a)', ints=[c])

         do s = 1, ao%centers(c)%n_shells

            n = ao%centers(c)%shells(s)%get_n_primitives()

            call file_%printf('m', &
                              ' (a0) (i0) 1.00', &
                              ints=[n], &
                              fs='(t1,a)', &
                              chars=[ao%centers(c)%shells(s)%get_angular_momentum_letter()])

            do i = 1, n

               call file_%printf('m', &
                                 '(f16.7)   (f15.10)', &
                                 fs='(t1,a)', &
                                 reals=[ao%centers(c)%shells(s)%get_exponent_i(i), &
                                    ao%centers(c)%shells(s)%get_coefficient_i(i)])

            end do
         end do

         call file_%newline('m')

      end do

      ! Either only spherical or only cartesian

      cartesian = ao%centers(1)%cartesian

      do c = 1, ao%n_centers
         if (ao%centers(1)%cartesian .neqv. ao%centers(c)%cartesian) then

            call output%error_msg( &
                    'Mixed cartesian and spherical basis sets are not supported in molden-file' &
                 )

         end if
      end do

      if (.not. cartesian) then
         call file_%printf('m', '[5D]', fs='(t1,a)')
         call file_%printf('m', '[7F]', fs='(t1,a)')
         call file_%printf('m', '[9G]', fs='(t1,a)')
         call file_%newline('m')
      end if

   end subroutine print_basis_set_molden_ao_tool


   subroutine get_centers_ao_tool(ao, centers, first, last)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      integer, intent(in) :: first, last

      type(atomic_center), dimension(last - first + 1) :: centers

      integer :: I

      do I = first, last

         centers(I - first + 1) = ao%centers(I)

      end do

   end subroutine get_centers_ao_tool


   pure function get_max_angular_momentum_ao_tool(ao) result(max_l)
      !!
      !! Written by M Scavino, 2022
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      integer :: max_l

      integer :: atom, sh

      max_l = 0

      do atom = 1, ao%n_centers

         do sh = 1, ao%centers(atom)%n_shells

            max_l = max(max_l, ao%centers(atom)%shells(sh)%get_angular_momentum())

         end do

      end do

   end function get_max_angular_momentum_ao_tool


   subroutine construct_shp_X_ao_tool(ao, X, shp_X_max)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Sep 2018
      !!
      !! Computes a vector that contains the largest value (in absolute terms)
      !! of X_wx for each shell pair (A,B), where w and x is in A and B,
      !! respectively.
      !!

      use omp_lib
      use array_utilities, only: get_abs_max

      implicit none

      class(ao_tool), intent(in) :: ao

      real(dp), dimension(ao%n_sh, ao%n_sh) :: shp_X_max

      real(dp), dimension(ao%n, ao%n), intent(in) :: X

      real(dp), dimension(:, :), allocatable, target :: shp_X
      real(dp), dimension(:, :), pointer, contiguous :: shp_X_p => null()

      type(range_) :: s1_range, s2_range

      integer :: s1, s2
      integer :: n_threads, thread

      real(dp) :: maximum

      n_threads = 1
      thread = 0

      !$    n_threads = omp_get_max_threads()

      call mem%alloc(shp_X, ao%max_sh_size**2, n_threads)

      !$omp parallel do private(s1, s2, s1_range, s2_range, shp_X_p, maximum, thread) schedule(dynamic)
      do s1 = 1, ao%n_sh
         do s2 = 1, s1

            !$          thread = omp_get_thread_num()

            s1_range = ao%shells(s1)
            s2_range = ao%shells(s2)

            shp_X_p(1:s1_range%length, &
                    1:s2_range%length) => shp_X(1:s1_range%length * s2_range%length, thread + 1)

            shp_X_p = X(s1_range%first:s1_range%get_last(), &
                        s2_range%first:s2_range%get_last())

            maximum = get_abs_max(shp_X_p, (s1_range%length) * (s2_range%length))

            nullify(shp_X_p)

            shp_X_max(s1, s2) = maximum
            shp_X_max(s2, s1) = maximum

         end do
      end do
      !$omp end parallel do

      call mem%dealloc(shp_X)

   end subroutine construct_shp_X_ao_tool


   subroutine construct_sh_X_from_shp_X_ao_tool(ao, shp_X_max, sh_X_max)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! For the N_sh x N_sh matrix shp_X_max,
      !! this routine returns the max of the second dimension
      !! for each index in the first dimension:
      !!
      !! sh_X_max(p) = max_q shp_X_max(p, q)
      !!
      use array_initialization, only: zero_array

      implicit none

      class(ao_tool), intent(in) :: ao

      real(dp), dimension(ao%n_sh, ao%n_sh) :: shp_X_max
      real(dp), dimension(ao%n_sh), intent(out) :: sh_X_max

      integer :: s1, s2

      call zero_array(sh_X_max, ao%n_sh)

      do s1 = 1, ao%n_sh
         do s2 = 1, ao%n_sh

            if (shp_X_max(s1, s2) > sh_X_max(s1)) sh_X_max(s1) = shp_X_max(s1, s2)

         end do
      end do

   end subroutine construct_sh_X_from_shp_X_ao_tool


   subroutine construct_sh_X_max_index_1_ao_tool(ao, n, X, sh_X_max)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      !! For the N_AO x N matrix X, this routine
      !! returns the maximum within each shell in sh_X_max
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      integer, intent(in) :: n

      real(dp), dimension(ao%n, n) :: X
      real(dp), dimension(ao%n_sh), intent(out) :: sh_X_max

      integer :: s1, w, q

      do s1 = 1, ao%n_sh

         sh_X_max(s1) = zero

         do q = 1, n
            do w = ao%shells(s1)%first, ao%shells(s1)%get_last()

               if (abs(X(w, q)) > sh_X_max(s1)) then

                  sh_X_max(s1) = abs(X(w, q))

               end if

            end do
         end do
      end do

   end subroutine construct_sh_X_max_index_1_ao_tool


   subroutine get_eri_2c_ao_tool(ao, g, J, K, precision, skip)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !!
      !! Two optional arguments:
      !!
      !!    precision:  (intent in) Double precision real corresponding to the precision value
      !!                to use when calculating the integral. Does not guarantee a precision
      !!                to the given value and should therefore be selected conservatively.
      !!
      !!    skip:       (intent out) If present, this integer will be 1 if the integral library decided not to
      !!                calculate the integral; it will be zero otherwise. If it is present, g will
      !!                not be zeroed out if the integral library decides not to calculate g. Thus, only pass 'skip'
      !!                to the routine if you wish to avoid zeroing out elements that are negligible.
      !!
      use shell_class, only: shell

      implicit none

      class(ao_tool), intent(inout) :: ao
      type(shell), intent(in) :: J, K

      real(dp), dimension(J%length * K%length), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      call ao%eri_lib%get_eri_2c(g, J, K, precision, skip)

   end subroutine get_eri_2c_ao_tool


   subroutine get_eri_3c_ao_tool(ao, g, J, C, D, precision, skip)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2020
      !!
      !!    precision:  (intent in) Double precision real corresponding to the precision value
      !!                to use when calculating the integral. Does not guarantee a precision
      !!                to the given value and should therefore be selected conservatively.
      !!
      !!    skip:       (intent out) If present, this integer will be 1 if the integral library decided not to
      !!                calculate the integral; it will be zero otherwise. If it is present, g will
      !!                not be zeroed out if integral library decides not to calculate g. Thus, only pass 'skip'
      !!                to the routine if you wish to avoid zeroing out elements that are negligible.
      !!
      use shell_class, only: shell

      implicit none

      class(ao_tool), intent(inout) :: ao

      integer, intent(in) :: C, D

      type(shell), intent(in) :: J

      real(dp), dimension(J%length * ao%shells(C)%length * ao%shells(D)%length), intent(out) :: g

      real(dp), intent(in), optional :: precision
      integer, intent(out), optional :: skip

      call ao%eri_lib%get_eri_3c(g, J, C, D, precision, skip)

   end subroutine get_eri_3c_ao_tool


   subroutine check_for_close_atoms(ao)
      !!
      !! Written by Alexander C. Paul, Nov 2021
      !!
      use array_utilities, only: get_euclidean_distance

      implicit none

      class(ao_tool), intent(in) :: ao
      integer :: c1, c2
      real(dp) :: distance

      do c1 = 2, ao%n_centers
         do c2 = 1, c1 - 1

            distance = get_euclidean_distance(ao%centers(c1)%coordinates, &
                                              ao%centers(c2)%coordinates, &
                                              3)

            if (distance < 0.1) then

               call output%warning_msg('Atoms (i0) and (i0) are closer than 0.1 Angstrom.', &
                                       ints=[c2, c1])

            end if

         end do
      end do

   end subroutine check_for_close_atoms


   subroutine print_geometry_ao_tool(ao, R, title)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      !! Prints the geometry R which corresponds to the atomic centers, where
      !! title is the header. This can be used to print gradient contributions, for example.
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      real(dp), dimension(3, ao%n_centers), intent(in) :: R

      character(len=*), intent(in) :: title

      integer :: I

      character(len=200) :: fstring

      call output%printf('m', trim(title) // ':', fs='(/t6,a/)')

      fstring = "(b2)3(f19.12)"

      do I = 1, ao%n_centers

         call output%printf('m', &
                            trim(fstring), &
                            chars=[ao%centers(I)%symbol], &
                            reals=[R(1, I), R(2, I), R(3, I)], &
                            fs='(t6,a)')

      end do

   end subroutine print_geometry_ao_tool


   subroutine prepare_for_ri_ao_tool(ao, basis_set, eri_precision, centers)
      !!
      !! Written by Marcus T. Lexander 2022
      !!
      use atomic_center_class, only: initialize_shells_atomic_center

      implicit none

      class(ao_tool), intent(inout) :: ao
      character(len=100), intent(in) :: basis_set
      real(dp), intent(in) :: eri_precision
      type(atomic_center), dimension(:), allocatable, intent(out) :: centers

      integer :: i

      allocate(centers(ao%n_centers))
      centers = ao%centers

      do i = 1, ao%n_centers
         centers(i)%basis = basis_set
      end do

      call initialize_shells_atomic_center(centers)

      call ao%eri_lib%prepare_for_ri(basis_set, eri_precision, centers)

   end subroutine prepare_for_ri_ao_tool


   subroutine construct_shell_to_center(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      implicit none

      class(ao_tool), intent(inout) :: ao

      integer :: I, A, B

      A = 0

      do I = 1, ao%n_centers
         do B = 1, ao%centers(I)%n_shells

            A = A + 1
            ao%shell_to_center(A) = I

         end do
      end do

   end subroutine construct_shell_to_center


   subroutine print_integral_precision(ao)
      !!
      !! Written by Alexander C. Paul, Dec 2022
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      call output%printf('n', &
                         'ERI precision:                   (e11.4)', &
                         reals=[ao%eri_precision], &
                         fs='(t6,a)')

      call output%printf('n', &
                         'One-electron integral precision: (e11.4)', &
                         reals=[ao%oei_lib%get_oei_precision()], &
                         fs='(t6,a)')

   end subroutine print_integral_precision


   subroutine get_center_masses_ao_tool(ao, masses)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(ao_tool), intent(in) :: ao

      real(dp), dimension(ao%n_centers), intent(out) :: masses

      integer :: I

      do I = 1, ao%n_centers

         masses(I) = ao%centers(I)%mass

      end do

   end subroutine get_center_masses_ao_tool


   function is_molecule_linear(ao) result(linear)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(ao_tool), intent(in) :: ao

      logical :: linear

      integer :: I

      real(dp) :: ddot, dotproduct
      real(dp), dimension(3) :: r_ref, r_other

      linear = .true.

      if (ao%n_centers == 1) then

         linear = .false.

      elseif (ao%n_centers > 2) then

         r_ref = ao%centers(2)%coordinates - ao%centers(1)%coordinates

         do I = 3, ao%n_centers

            r_other = ao%centers(I)%coordinates - ao%centers(1)%coordinates

            dotproduct = ddot(3, r_other, 1, r_ref, 1) / (get_l2_norm(r_other, 3) * get_l2_norm(r_ref, 3))

            if (abs(abs(dotproduct) - one) > 1.0d-3) then

               linear = .false.

            end if

         end do

      end if

   end function is_molecule_linear


   subroutine cleanup(ao)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      class(ao_tool) :: ao

      integer :: I

      if (allocated(ao%h)) call mem%dealloc(ao%h)
      if (allocated(ao%s)) call mem%dealloc(ao%s)
      if (allocated(ao%v)) call mem%dealloc(ao%v)

      if (allocated(ao%centers)) then

         do I = 1, ao%n_centers

            call ao%centers(I)%cleanup()

         end do

         deallocate(ao%centers)

      end if

      if (allocated(ao%center_subsets)) deallocate(ao%center_subsets)

      if (allocated(ao%shell_to_center)) call mem%dealloc(ao%shell_to_center)
      if (allocated(ao%ao_to_center)) call mem%dealloc(ao%ao_to_center)
      if (allocated(ao%ao_to_shell)) call mem%dealloc(ao%ao_to_shell)

      if (allocated(ao%L)) call mem%dealloc(ao%L)
      if (allocated(ao%P)) call mem%dealloc(ao%P)

      if (allocated(ao%cs_eri_max)) call mem%dealloc(ao%cs_eri_max)

      if (allocated(ao%cs_eri_max_indices)) call mem%dealloc(ao%cs_eri_max_indices)

      if (allocated(ao%cs_eri_max_sh)) call mem%dealloc(ao%cs_eri_max_sh)

      if (allocated(ao%sig_s2_for_s1)) call mem%dealloc(ao%sig_s2_for_s1)

      if (allocated(ao%n_sig_s2_for_s1)) call mem%dealloc(ao%n_sig_s2_for_s1)

      if (allocated(ao%oei_lib)) then
         call ao%oei_lib%cleanup()
         deallocate(ao%oei_lib)
      end if

      if (allocated(ao%eri_lib)) then
         call ao%eri_lib%cleanup()
         deallocate(ao%eri_lib)
      end if

      if (allocated(ao%shells)) deallocate(ao%shells)

   end subroutine cleanup


   subroutine calculate_natural_connection_ao_tool(ao, W_wxqk)
      !!
      !! Written by Eirik F. Kjoenstad, June 2021
      !!
      !! W_wx^1 = (w|x') ~ (w|x(r+dr)) - (w|x(r))/dr
      !!
      use array_initialization, only: zero_array

      implicit none

      class(ao_tool) :: ao

      real(dp), dimension(ao%n, ao%n, 3, ao%n_centers), intent(out) :: W_wxqk

      type(atomic_center), dimension(:), allocatable :: existing_centers
      type(atomic_center), dimension(:), allocatable :: shifted_centers
      type(atomic_center), dimension(:), allocatable :: shifted_centers2

      real(dp), parameter :: dq = 1.0d-6

      integer :: k, n_ao, n_centers, w, x, w_full, x_full, q, l

      integer, dimension(:), allocatable :: center_to_ao
      real(dp), dimension(:, :), allocatable :: s

      call output%mute()

      n_ao = ao%n
      n_centers = ao%n_centers

      call mem%alloc(s, n_ao, n_ao)
      call dcopy(n_ao**2, ao%s, 1, s, 1)

      call mem%alloc(center_to_ao, n_centers)

      center_to_ao(1) = 1

      do k = 2, n_centers

         center_to_ao(k) = center_to_ao(k - 1) + ao%centers(k - 1)%n_ao

      end do

      allocate(existing_centers(n_centers))
      allocate(shifted_centers(n_centers))
      allocate(shifted_centers2(n_centers))

      do k = 1, n_centers

         existing_centers(k) = atomic_center(k, &
                                             ao%centers(k)%input_number, &
                                             ao%centers(k)%symbol, &
                                             ao%centers(k)%coordinates, &
                                             ao%centers(k)%basis, &
                                             ao%basis_type_, &
                                             ao%centers(k)%charge, &
                                             ao%centers(k)%is_ghost())

         shifted_centers(k) = atomic_center(k, &
                                            - 1, &
                                            ao%centers(k)%symbol, &
                                            ao%centers(k)%coordinates, &
                                            ao%centers(k)%basis, &
                                            ao%basis_type_, &
                                            ao%centers(k)%charge, &
                                            ao%centers(k)%is_ghost())

         shifted_centers2(k) = atomic_center(k, &
                                             - 1, &
                                             ao%centers(k)%symbol, &
                                             ao%centers(k)%coordinates, &
                                             ao%centers(k)%basis, &
                                             ao%basis_type_, &
                                             ao%centers(k)%charge, &
                                             ao%centers(k)%is_ghost())

      end do

      call ao%cleanup()

      call zero_array(W_wxqk, n_ao**2 * 3 * n_centers)

      do k = 1, n_centers
         do l = 1, n_centers
            do q = 1, 3

               shifted_centers(l)%coordinates(q) = shifted_centers(l)%coordinates(q) + dq * bohr_to_angstrom

               shifted_centers2(l)%coordinates(q) = shifted_centers2(l)%coordinates(q) - dq * bohr_to_angstrom

               call ao%initialize([existing_centers(k), shifted_centers(l), shifted_centers2(l)])

               do w = 1, ao%centers(1)%n_ao
                  do x = ao%centers(1)%n_ao + 1, ao%centers(1)%n_ao + ao%centers(2)%n_ao

                     w_full = center_to_ao(k) + w - 1
                     x_full = center_to_ao(l) + x - (ao%centers(1)%n_ao + 1)

                     W_wxqk(w_full, x_full, q, l) = &
                                                    (ao%s(w, x) - ao%s(w, x + ao%centers(2)%n_ao)) / &
                                                    (two * dq)

                  end do
               end do

               call ao%cleanup()

               shifted_centers(l)%coordinates(q) = shifted_centers(l)%coordinates(q) - dq * bohr_to_angstrom

               shifted_centers2(l)%coordinates(q) = shifted_centers2(l)%coordinates(q) + dq * bohr_to_angstrom

            end do
         end do
      end do

      call ao%initialize(existing_centers)

      call mem%dealloc(s)
      call mem%dealloc(center_to_ao)

      call output%unmute()

   end subroutine calculate_natural_connection_ao_tool


end module ao_tool_class

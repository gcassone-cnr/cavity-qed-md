

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module boson_factory_class

   !!
   !! Boson factory class module
   !! Written by Tor S. Haugland, 2023
   !!
   !! This factory reads the input file and returns a concrete boson tool object,
   !! such as a photon tool.
   !!

   use boson_tool_class, only: boson_tool
   use photon_tool_class, only: photon_tool
   use plasmon_tool_class, only: plasmon_tool

   use global_out, only: output
   use global_in, only: input

   implicit none

   type :: boson_factory

      character(len=200) :: interaction_type

   contains

      procedure, public :: create

   end type boson_factory

   interface boson_factory

      procedure :: new

   end interface boson_factory

contains


   function new() result(factory)
      !!
      !! Written by Tor S. Haugland, 2023
      !!
      implicit none

      type(boson_factory) :: factory

      factory%interaction_type = "photon"
      call input%get_keyword("interaction type", "boson", factory%interaction_type)

   end function new


   subroutine create(factory, boson)
      !!
      !! Written by Tor S. Haugland, 2023
      !!
      !! Returns a concrete boson object based on the factory type,
      !! for instance a photon tool.
      !!
      implicit none

      class(boson_factory), intent(in) :: factory
      class(boson_tool), allocatable, intent(inout) :: boson

      if (trim(factory%interaction_type) == 'photon') then
         boson = photon_tool()
      elseif (trim(factory%interaction_type) == 'plasmon') then
         boson = plasmon_tool()
      else
         call output%error_msg("could not recognize boson type: " // trim(factory%interaction_type))
      end if

   end subroutine create


end module boson_factory_class

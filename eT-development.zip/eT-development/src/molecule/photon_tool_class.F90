

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module photon_tool_class

   !!
   !! Photon tool class module
   !! Written by Tor S. Haugland, 2021-2023
   !!
   !! Class that stores information about photons and routines related to computing electron-photon
   !! interactions for the Hamiltonian
   !!    H = H_e + w b^+ b + lambda * sqrt(w/2) * (d dot e) (b + b^+) + 0.5 * lambda^2 * (d dot e)^2
   !! where w is the frequency of the boson mode, lambda is the coupling strength, d is the molecular dipole
   !! and e is the transversal polarization vector.
   !!

   use parameters
   use global_in, only: input
   use global_out, only: output
   use memory_manager_class, only: mem
   use ao_tool_class, only: ao_tool
   use ao_oei_getter_class, only: ao_oei_getter
   use boson_tool_class, only: boson_tool
   use point_charges_class, only: point_charges

   implicit none

   type, extends(boson_tool) :: photon_tool

      real(dp), dimension(:, :), allocatable, private :: polarizations
      real(dp), dimension(3), private :: mu_nuc
      real(dp), dimension(:), allocatable, private :: couplings  ! = (permittivity * V_eff)^(-0.5)
      real(dp), dimension(:), allocatable, private :: couplings_bilinear
      real(dp), dimension(:), allocatable, private :: couplings_self

      type(point_charges), private :: pc

      ! Approximate sum_p |p><p| -> 1? Removes references to virtual orbitals
      logical, public :: complete_basis_approximation = .false.

   contains

      procedure, public :: initialize
      procedure, public :: cleanup
      procedure, public :: print_summary

      procedure, public :: add_ao_h_contribution
      procedure, public :: get_ao_electron_boson_interaction
      procedure, public :: get_ao_electron_boson_interaction_1der
      procedure, public :: construct_molecular_gradient_boson_interaction
      procedure, public, nopass :: create_ao_eri_getter

      procedure, private :: get_polarized_ao_dipole_wx
      procedure, private :: get_polarized_ao_dipole_1der_wxqk
      procedure, private :: get_polarized_ao_quadrupole_wx
      procedure, private :: get_ao_self_energy_oei

      procedure, private, nopass :: wavevector_to_polarizations

      procedure, public :: read_settings => read_settings_photon

      procedure, public :: get_scaled_polarized_nuclear_dipole_1der

   end type photon_tool

   interface photon_tool

      procedure :: new_photon_tool

   end interface photon_tool


contains


   function new_photon_tool() result(this)
      !!
      !! Written by Tor S. Haugland, Oct 2021
      !!
      implicit none

      type(photon_tool) :: this

      call input%get_required_keyword('modes', 'boson', this%n_modes)

      call mem%alloc(this%n_boson_states, this%n_modes)
      call mem%alloc(this%frequencies, this%n_modes)
      call mem%alloc(this%polarizations, 3, this%n_modes)
      call mem%alloc(this%coherent_states_z, this%n_modes)
      call mem%alloc(this%couplings, this%n_modes)
      call mem%alloc(this%couplings_bilinear, this%n_modes)
      call mem%alloc(this%couplings_self, this%n_modes)

      call this%read_settings()

   end function new_photon_tool


   subroutine initialize(this, ao)
      !!
      !! Written by Tor S. Haugland, Dec 2021
      !!
      implicit none

      class(photon_tool), intent(inout) :: this
      class(ao_tool), intent(inout) :: ao

      this%n_ao = ao%n
      this%n_electrons = ao%get_n_electrons()
      this%ao_oei = ao_oei_getter(ao)
      if (.not. allocated(this%boson_type)) allocate(this%boson_type, source = "photon")

      call ao%get_point_charges(this%pc)
      this%mu_nuc = this%pc%get_dipole()

      this%n_centers = ao%n_centers

   end subroutine initialize


   subroutine cleanup(this)
      !!
      !! Written by Tor S. Haugland, Oct 2021
      !!
      implicit none

      class(photon_tool), intent(inout) :: this

      if (allocated(this%n_boson_states)) call mem%dealloc(this%n_boson_states)
      if (allocated(this%frequencies)) call mem%dealloc(this%frequencies)
      if (allocated(this%polarizations)) call mem%dealloc(this%polarizations)
      if (allocated(this%coherent_states_z)) call mem%dealloc(this%coherent_states_z)
      if (allocated(this%couplings)) call mem%dealloc(this%couplings)
      if (allocated(this%couplings_bilinear)) call mem%dealloc(this%couplings_bilinear)
      if (allocated(this%couplings_self)) call mem%dealloc(this%couplings_self)

      if (allocated(this%pc%r)) call this%pc%cleanup()

   end subroutine cleanup


   subroutine read_settings_photon(this)
      !!
      !! Written by Tor S. Haugland and Enrico Ronca, 2023
      !! Modified by Yassir El Moutaoukal, 2024
      !!
      implicit none

      class(photon_tool), intent(inout) :: this
      real(dp), dimension(:), allocatable :: temp
      integer :: k

      call this%read_boson_settings()

      if (input%is_keyword_present('wavevector', 'boson')) then

         if (mod(this%n_modes, 2) /= 0) then

            call output%error_msg( &
                    "If 'wavevector' is specified, two polarizations are automatically considered, therefore&
                    & 'modes' has to be an even number." &
                 )

         else

            call mem%alloc(temp, 3)

            call input%get_array_for_keyword('wavevector', 'boson', 3, temp)
            do k = 1, this%n_modes, 2

               call this%wavevector_to_polarizations(temp, &
                                                     this%polarizations(:, k), &
                                                     this%polarizations(:, k + 1))

            end do

            call mem%dealloc(temp)

         end if

      else if (input%is_keyword_present('polarization', 'boson')) then

         call mem%alloc(temp, 3 * this%n_modes)

         call input%get_array_for_keyword('polarization', 'boson', 3 * this%n_modes, temp)
         do k = 1, this%n_modes
            this%polarizations(:, k) = temp((3 * (k - 1) + 1):(3 * (k - 1) + 3))
         end do

         call mem%dealloc(temp)

      else

         call output%error_msg("Keyword wavevector or polarization must be specified")

      end if

      if (input%is_keyword_present('coupling', 'boson')) then
         call input%get_array_for_keyword('coupling', 'boson', this%n_modes, this%couplings)
      else
         call output%error_msg("coupling is not specified.")
      end if

      do k = 1, this%n_modes
         this%couplings_bilinear(k) = this%couplings(k) * sqrt(this%frequencies(k) * half)
         this%couplings_self(k) = this%couplings(k)**2 * half
      end do

      ! If bilinear- or self-coupling are specified, overwrite the corresponding coupling value

      if (input%is_keyword_present('coupling bilinear', 'boson')) then
         call input%get_array_for_keyword('coupling bilinear', 'boson', this%n_modes, this%couplings_bilinear)
      end if

      if (input%is_keyword_present('coupling self', 'boson')) then
         call input%get_array_for_keyword('coupling self', 'boson', this%n_modes, this%couplings_self)
      end if

      this%complete_basis_approximation = input%is_keyword_present('quadrupole oei', 'boson')

   end subroutine read_settings_photon


   subroutine get_polarized_ao_dipole_wx(this, mu_wx, mode)
      !!
      !! Written by T. S. Haugland, Sep 2018
      !!
      !! Gets the product between the photon transversal polarization
      !! and the dipole moments.
      !!    mu_wx = <w| (e dot mu_el) |x> + (e dot mu_nuc) S_wx / N_el
      !!       e : transversal polarization vector
      !!
      use array_initialization, only: zero_array

      implicit none

      class(photon_tool), intent(in) :: this
      real(dp), dimension(:, :), intent(out) :: mu_wx
      integer, intent(in) :: mode

      real(dp), dimension(:, :, :), allocatable :: ao_dipole
      real(dp), dimension(:, :), allocatable :: ao_overlap
      real(dp) :: d_nuc
      real(dp), external :: ddot
      integer :: i

      ! Electronic Contribution

      call mem%alloc(ao_dipole, this%n_ao, this%n_ao, 3)
      call this%ao_oei%get_oei('dipole', ao_dipole)

      call zero_array(mu_wx, this%n_ao**2)
      do i = 1, 3
         call daxpy(this%n_ao**2, this%polarizations(i, mode), ao_dipole(:, :, i), 1, mu_wx, 1)
      end do

      call mem%dealloc(ao_dipole)

      ! Nuclear Contribution

      call mem%alloc(ao_overlap, this%n_ao, this%n_ao)
      call this%ao_oei%get_oei('overlap', ao_overlap)

      d_nuc = ddot(3, this%mu_nuc, 1, this%polarizations(:, mode), 1)
      call daxpy(this%n_ao**2, d_nuc / this%n_electrons, ao_overlap, 1, mu_wx, 1)

      call mem%dealloc(ao_overlap)

   end subroutine get_polarized_ao_dipole_wx


   subroutine get_polarized_ao_dipole_1der_wxqk(this, mu_wxqk, mode)
      !!
      !! Written by Marcus T. Lexander, 2022
      !!
      !! Gets the molecular first derivative of the polarized_ao_dipole_wx
      !! mu_wx^qk = <w| (e dot mu_el) |x>^qk + (e dot mu_nuc^qk) S_wx / N_el + (e dot mu_nuc) S_wx^qk / N_el
      !!
      !! ^qk means the derivative with respect to moving center number k along axis q (xyz).
      !!
      use array_initialization, only: zero_array

      implicit none

      class(photon_tool), intent(in) :: this
      real(dp), dimension(:, :, :, :), intent(out) :: mu_wxqk
      integer, intent(in) :: mode

      real(dp), dimension(:, :), allocatable :: ao_overlap
      real(dp), dimension(:, :, :, :), allocatable :: ao_overlap_1der
      real(dp), dimension(:, :, :, :, :), allocatable :: ao_dipole_1der

      integer :: p, q, k
      real(dp) :: d_nuc, nuc_contribution
      real(dp), external :: ddot

      call mem%alloc(ao_overlap, this%n_ao, this%n_ao)
      call this%ao_oei%get_oei('overlap', ao_overlap)

      call mem%alloc(ao_overlap_1der, this%n_ao, this%n_ao, 3, this%pc%n_charges)
      call this%ao_oei%get_oei_1der('overlap', ao_overlap_1der)

      call mem%alloc(ao_dipole_1der, this%n_ao, this%n_ao, 3, 3, this%pc%n_charges)
      call this%ao_oei%get_oei_1der('dipole', ao_dipole_1der)

      call zero_array(mu_wxqk, this%n_ao**2 * 3 * this%pc%n_charges)

      d_nuc = ddot(3, this%mu_nuc, 1, this%polarizations(:, mode), 1)

      do k = 1, this%pc%n_charges
         do q = 1, 3

            ! Electronic Contribution (1st term):
            do p = 1, 3

               call daxpy(this%n_ao**2, &
                          this%polarizations(p, mode), &
                          ao_dipole_1der(:, :, p, q, k), &
                          1, &
                          mu_wxqk(:, :, q, k), &
                          1)

            end do

            ! Nuclear Contribution (2nd term):
            nuc_contribution = this%polarizations(q, mode) * this%pc%q(k) / this%n_electrons
            call daxpy(this%n_ao**2, nuc_contribution, ao_overlap, 1, mu_wxqk(:, :, q, k), 1)

         end do
      end do

      ! Nuclear Contribution (3rd term):

      call daxpy(this%n_ao**2 * 3 * this%pc%n_charges, &
                 d_nuc / this%n_electrons, &
                 ao_overlap_1der, &
                 1, &
                 mu_wxqk, &
                 1)

      call mem%dealloc(ao_overlap)
      call mem%dealloc(ao_overlap_1der)
      call mem%dealloc(ao_dipole_1der)

   end subroutine get_polarized_ao_dipole_1der_wxqk


   subroutine construct_molecular_gradient_boson_interaction(this, ao, E_qk, D, mode, prefactor)
      !!
      !! Written by Marcus T. Lexander, 2024
      !!
      !! E_qk = sum_wx (d/d_qk <w| (e dot mu_el) |x> + d/d_qk (e dot mu_nuc) S_wx / N_el) * D_wx
      !!
      use omp_lib
      use timings_class, only: timings
      use ao_tool_class, only: ao_tool

      implicit none

      class(photon_tool), intent(in) :: this
      class(ao_tool), intent(in) :: ao
      real(dp), dimension(3, this%n_centers), intent(inout) :: E_qk
      integer, intent(in) :: mode
      real(dp), dimension(this%n_ao, this%n_ao), intent(in) :: D
      real(dp), intent(in), optional :: prefactor

      real(dp) :: prefactor_local, d_nuc
      real(dp), dimension(:, :, :), allocatable :: E_thread

      real(dp), dimension(ao%max_sh_size**2 * 3 * 3), target :: oei

      real(dp), dimension(:, :, :, :), pointer :: oei_p

      integer :: A, B, w, x, p, q, k, n_threads, thread

      integer, dimension(2) :: atoms

      type(timings) :: timer

      real(dp), external :: ddot

      timer = timings('QED-HF gradient (1e dipole contribution mode)', pl='verbose')

      call timer%turn_on()

      prefactor_local = one
      if (present(prefactor)) prefactor_local = prefactor

      prefactor_local = prefactor_local * this%couplings_bilinear(mode)

      d_nuc = ddot(3, this%mu_nuc, 1, this%polarizations(:, mode), 1) * prefactor_local / this%n_electrons

      n_threads = 1  ! needed when OMP is not enabled
      !$    n_threads = omp_get_max_threads()

      call mem%alloc(E_thread, 3, this%pc%n_charges, n_threads, set_zero=.true.)

      !$omp parallel do private(A, B, w, x, p, q, k, atoms, oei, oei_p, thread) schedule(dynamic) collapse(2)
      do B = 1, ao%n_sh
         do A = 1, ao%n_sh

            thread = 1  ! needed when OMP is not enabled
            !$          thread = omp_get_thread_num() + 1

            atoms = [ao%shell_to_center(A), ao%shell_to_center(B)]

            call this%ao_oei%get_oei_1der_shell('overlap', oei, A, B)

            oei_p(ao%shells(A)%first:ao%shells(A)%get_last(), &
                  ao%shells(B)%first:ao%shells(B)%get_last(), &
                  1:3, &
                  1:2) => oei

            do k = 1, 2
               do q = 1, 3

                  do x = ao%shells(B)%first, ao%shells(B)%get_last()
                     do w = ao%shells(A)%first, ao%shells(A)%get_last()

                        E_thread(q, atoms(k), thread) = E_thread(q, atoms(k), thread) &
                                                        + d_nuc * D(w, x) * oei_p(w, x, q, k)

                     end do
                  end do

               end do
            end do

            call this%ao_oei%get_oei_1der_shell('dipole', oei, A, B)

            oei_p(ao%shells(A)%first:ao%shells(A)%get_last(), &
                  ao%shells(B)%first:ao%shells(B)%get_last(), &
                  1:3, &
                  1:3) => oei

            do p = 1, 3
               do q = 1, 3

                  do x = ao%shells(B)%first, ao%shells(B)%get_last()
                     do w = ao%shells(A)%first, ao%shells(A)%get_last()

                        E_thread(q, atoms(2), thread) = E_thread(q, atoms(2), thread) &
                                                        + prefactor_local * D(w, x) * oei_p(w, x, q, p) &
                                                        * this%polarizations(p, mode)

                        if (atoms(1) == atoms(2)) cycle

                        E_thread(q, atoms(2), thread) = E_thread(q, atoms(2), thread) &
                                                        + prefactor_local * D(x, w) * oei_p(w, x, q, p) &
                                                        * this%polarizations(p, mode)

                     end do
                  end do

               end do
            end do

         end do
      end do
      !$omp end parallel do

      do thread = 1, n_threads
         call daxpy(3 * this%pc%n_charges, one, E_thread(:, :, thread), 1, E_qk, 1)
      end do

      call mem%dealloc(E_thread)

      call timer%turn_off()

   end subroutine construct_molecular_gradient_boson_interaction


   subroutine get_polarized_ao_quadrupole_wx(this, Q_wx, mode)
      !!
      !! Written by T. S. Haugland, Nov 2021
      !!
      !! Gets the product between the photon transversal polarization
      !! and the quadrupole moments. Includes nuclear contribution.
      !!
      !! Q_wx = <w| (mu_tot dot e)^2 |x>
      !!      = <w| (e^T dot Q dot e) |x> + 2 <w| mu dot e | x> (mu_nuc dot e) + (mu_nuc dot e)^2
      !!    e : transversal polarization vector
      !!
      use array_initialization, only: zero_array

      implicit none

      class(photon_tool), intent(in) :: this
      real(dp), dimension(:, :), intent(out) :: Q_wx
      integer, intent(in) :: mode

      real(dp), dimension(:, :), allocatable :: d_el, ao_overlap
      real(dp), dimension(:, :, :), allocatable :: ao_dipole, ao_quadrupole
      real(dp) :: d_nuc, a
      real(dp), external :: ddot
      integer :: i

      ! Electronic contribution

      call mem%alloc(ao_quadrupole, this%n_ao, this%n_ao, 6)
      call this%ao_oei%get_oei('quadrupole', ao_quadrupole)

      call zero_array(Q_wx, this%n_ao**2)

      call daxpy(this%n_ao**2, &
                 - this%polarizations(1, mode) * this%polarizations(1, mode), &
                 ao_quadrupole(:, :, 1), &
                 1, &
                 Q_wx, &
                 1)  !xx

      call daxpy(this%n_ao**2, &
                 - this%polarizations(1, mode) * this%polarizations(2, mode) * two, &
                 ao_quadrupole(:, :, 2), &
                 1, &
                 Q_wx, &
                 1)  !xy

      call daxpy(this%n_ao**2, &
                 - this%polarizations(1, mode) * this%polarizations(3, mode) * two, &
                 ao_quadrupole(:, :, 3), &
                 1, &
                 Q_wx, &
                 1)  !xz

      call daxpy(this%n_ao**2, &
                 - this%polarizations(2, mode) * this%polarizations(2, mode), &
                 ao_quadrupole(:, :, 4), &
                 1, &
                 Q_wx, &
                 1)  !yy

      call daxpy(this%n_ao**2, &
                 - this%polarizations(2, mode) * this%polarizations(3, mode) * two, &
                 ao_quadrupole(:, :, 5), &
                 1, &
                 Q_wx, &
                 1)  !yz

      call daxpy(this%n_ao**2, &
                 - this%polarizations(3, mode) * this%polarizations(3, mode), &
                 ao_quadrupole(:, :, 6), &
                 1, &
                 Q_wx, &
                 1)  !zz

      call mem%dealloc(ao_quadrupole)

      ! Nuclear contribution

      call mem%alloc(ao_overlap, this%n_ao, this%n_ao)
      call this%ao_oei%get_oei('overlap', ao_overlap)

      d_nuc = ddot(3, this%mu_nuc, 1, this%polarizations(:, mode), 1)
      call daxpy(this%n_ao**2, (d_nuc / this%n_electrons)**2, ao_overlap, 1, Q_wx, 1)

      call mem%dealloc(ao_overlap)

      ! Electronic-Nuclear contribution

      call mem%alloc(ao_dipole, this%n_ao, this%n_ao, 3)
      call this%ao_oei%get_oei('dipole', ao_dipole)

      call mem%alloc(d_el, this%n_ao, this%n_ao, set_zero=.true.)
      do i = 1, 3
         call daxpy(this%n_ao**2, this%polarizations(i, mode), ao_dipole(:, :, i), 1, d_el, 1)
      end do

      call mem%dealloc(ao_dipole)

      a = two * d_nuc / this%n_electrons
      call daxpy(this%n_ao**2, a, d_el, 1, Q_wx, 1)

      call mem%dealloc(d_el)

   end subroutine get_polarized_ao_quadrupole_wx


   subroutine get_ao_electron_boson_interaction(this, g_wx, mode)
      !!
      !! Written by T. S. Haugland, June 2021
      !!
      !! Gets the bilinear interaction term in the AO basis,
      !! the g in g(b+b^+).
      !!    g_wx = mu_wx * lambda * sqrt(omega/2)
      !!
      implicit none

      class(photon_tool), intent(in) :: this
      real(dp), dimension(:, :), intent(out) :: g_wx
      integer, intent(in) :: mode

      call this%get_polarized_ao_dipole_wx(g_wx, mode)
      call dscal(this%n_ao**2, this%couplings_bilinear(mode), g_wx, 1)

   end subroutine get_ao_electron_boson_interaction


   subroutine get_ao_electron_boson_interaction_1der(this, g_wxqk, mode)
      !!
      !! Written by Marcus T. Lexander, 2022
      !!
      !! Gets the molecular 1st derivative of the bilinear interaction term in the AO
      !! g_wx^qk = mu_wx^qk * lambda * sqrt(omega/2)
      !!

      implicit none

      class(photon_tool), intent(in) :: this
      real(dp), dimension(:, :, :, :), intent(out) :: g_wxqk
      integer, intent(in) :: mode

      call this%get_polarized_ao_dipole_1der_wxqk(g_wxqk, mode)
      call dscal(this%n_ao**2 * 3 * this%pc%n_charges, this%couplings_bilinear(mode), g_wxqk, 1)

   end subroutine get_ao_electron_boson_interaction_1der


   subroutine get_ao_self_energy_oei(this, g_wx)
      !!
      !! Written by T. S. Haugland, June 2021
      !!
      !! Gets the quadratic one-electron interaction in the AO basis,
      !! also known as the dipole self-energy.
      !!    g2_wx = sum_p g_wp g_px = lambda^2 / 2 * sum_p mu_wp mu_px
      !!
      use array_utilities, only: invert, symmetric_sandwich
      use array_initialization, only: zero_array

      implicit none

      class(photon_tool), intent(in) :: this
      real(dp), dimension(:, :), intent(out) :: g_wx

      real(dp), dimension(:, :), allocatable :: D_full, mu_wx, Q_wx, muDmu_wx, ao_overlap
      integer :: mode

      if (this%complete_basis_approximation) then

         ! Assume sum_p |p><p| = 1 to compute quadrupole integrals instead of full density matrix

         call mem%alloc(Q_wx, this%n_ao, this%n_ao)

         call zero_array(g_wx, this%n_ao**2)
         do mode = 1, this%n_modes
            call this%get_polarized_ao_quadrupole_wx(Q_wx, mode)
            call daxpy(this%n_ao**2, this%couplings_self(mode), Q_wx, 1, g_wx, 1)
         end do

         call mem%dealloc(Q_wx)

      else

         ! Invert S to compute the full density matrix

         call mem%alloc(ao_overlap, this%n_ao, this%n_ao)
         call this%ao_oei%get_oei('overlap', ao_overlap)

         call mem%alloc(D_full, this%n_ao, this%n_ao)
         call invert(D_full, ao_overlap, this%n_ao)
         call mem%dealloc(ao_overlap)

         call mem%alloc(mu_wx, this%n_ao, this%n_ao)
         call mem%alloc(muDmu_wx, this%n_ao, this%n_ao)

         call zero_array(g_wx, this%n_ao**2)
         do mode = 1, this%n_modes
            call this%get_polarized_ao_dipole_wx(mu_wx, mode)
            call symmetric_sandwich(muDmu_wx, D_full, mu_wx, this%n_ao, this%n_ao)
            call daxpy(this%n_ao**2, this%couplings_self(mode), muDmu_wx, 1, g_wx, 1)
         end do

         call mem%dealloc(D_full)
         call mem%dealloc(mu_wx)
         call mem%dealloc(muDmu_wx)

      end if

   end subroutine get_ao_self_energy_oei


   subroutine add_ao_h_contribution(this, h)
      !!
      !! Written by T. S. Haugland, Oct 2021
      !!
      !! Adds the photon AO contribution to h.
      !!    h_wx += [g^2]_wx / omega + 2z * g_wx + omega z^2 S_wx / N_e
      !!
      implicit none

      class(photon_tool), intent(in) :: this
      real(dp), dimension(*), intent(inout), target :: h
      real(dp), dimension(:, :), pointer :: h_wx
      real(dp), dimension(:, :), allocatable :: g_wx, ao_overlap
      integer :: mode
      real(dp) :: wz2

      h_wx(1:this%n_ao, 1:this%n_ao) => h(1:this%n_ao**2)

      call mem%alloc(g_wx, this%n_ao, this%n_ao)
      call this%get_ao_self_energy_oei(g_wx)
      call daxpy(this%n_ao**2, one, g_wx, 1, h_wx, 1)

      do mode = 1, this%n_modes
         call this%get_ao_electron_boson_interaction(g_wx, mode)
         call daxpy(this%n_ao**2, two * this%coherent_states_z(mode), g_wx, 1, h_wx, 1)
      end do
      call mem%dealloc(g_wx)

      call mem%alloc(ao_overlap, this%n_ao, this%n_ao)
      call this%ao_oei%get_oei('overlap', ao_overlap)

      wz2 = sum(this%frequencies * this%coherent_states_z**2)
      call daxpy(this%n_ao**2, wz2 / this%n_electrons, ao_overlap, 1, h_wx, 1)

      call mem%dealloc(ao_overlap)

   end subroutine add_ao_h_contribution


   subroutine print_summary(this)
      !!
      !! Written by T. S. Haugland, Oct 2021
      !!
      implicit none

      class(photon_tool), intent(in) :: this
      integer :: mode

      call output%printf('m', '- Photon parameters and properties', ffs='(/t3,a)')

      call output%printf('m', &
                         'Optimize photons displacement?: (l0)', &
                         logs=[this%is_optimizing_bosons], &
                         ffs='(/t6,a)')

      call output%printf('m', &
                         'Complete basis approximation?:  (l0)', &
                         logs=[this%complete_basis_approximation], &
                         ffs='(t6,a)')

      do mode = 1, this%n_modes
         call output%printf('m', 'Mode (i0):', ints=[mode], ffs='(/t6,a)')
         call output%print_separator(pl='m', symbol='-', n=8, fs='(t6,a)')

         call output%printf('m', &
                            ' Frequency:           (f17.12)', &
                            reals=[this%frequencies(mode)], &
                            ffs='(t6,a)')

         call output%printf('m', &
                            ' Coherent state z:    (f17.12)', &
                            reals=[this%coherent_states_z(mode)], &
                            ffs='(t6,a)')

         call output%printf('m', &
                            ' Polarization:         (f12.8) (f12.8) (f12.8)', &
                            reals=this%polarizations(:, mode), &
                            ffs='(/t6,a)')

         call output%printf('m', ' Coupling', ffs='(/t6,a)')
         call output%printf('m', ' sqrt(1/eps V):    (f17.12)', reals=[this%couplings(mode)], ffs='(t9,a)')

         call output%printf('m', &
                            ' Bilinear:         (f17.12)', &
                            reals=[this%couplings_bilinear(mode)], &
                            ffs='(t9,a)')

         call output%printf('m', &
                            ' Quadratic:        (f17.12)', &
                            reals=[this%couplings_self(mode)], &
                            ffs='(t9,a)')

      end do

   end subroutine print_summary


   subroutine wavevector_to_polarizations(wavevector, pol_1, pol_2)
      !!
      !! Written by Tor S. Haugland, May 2021
      !!
      !! From a wavevector, form two orthogonal polarization directions.
      !!
      use math_utilities, only: cross_product_R3
      use array_utilities, only: are_vectors_parallel

      implicit none

      real(dp), dimension(3), intent(in) :: wavevector
      real(dp), dimension(3), intent(out) :: pol_1, pol_2
      real(dp), dimension(3) :: rand_vec
      logical :: is_parallel

      rand_vec = [zero, zero, one]
      is_parallel = are_vectors_parallel(rand_vec, wavevector, 3, 1d-10)
      if (is_parallel) rand_vec = [zero, one, zero]

      pol_1 = cross_product_R3(rand_vec, wavevector)
      pol_1 = pol_1 / norm2(pol_1)

      pol_2 = cross_product_R3(wavevector, pol_1)
      pol_2 = pol_2 / norm2(pol_2)

   end subroutine wavevector_to_polarizations


   subroutine create_ao_eri_getter(eri_getter, ao)
      !!
      !! Written by Tor S. Haugland, 2023
      !!
      use abstract_ao_eri_getter_class, only: abstract_ao_eri_getter
      use qed_ao_eri_getter_class, only: qed_ao_eri_getter

      implicit none

      class(abstract_ao_eri_getter), allocatable :: eri_getter
      class(ao_tool) :: ao

      eri_getter = qed_ao_eri_getter(ao)

   end subroutine create_ao_eri_getter


   subroutine get_scaled_polarized_nuclear_dipole_1der(this, mu_nuc_qk)
      !!
      !! Written by Sara Angelico, 2024
      !!
      !! Calculates lambda dot d_N'/N_e
      implicit none

      integer :: k, q, mode

      class(photon_tool) :: this

      real(dp), dimension(:, :), intent(inout) :: mu_nuc_qk

      do mode = 1, this%n_modes
         do k = 1, this%pc%n_charges
            do q = 1, 3

               mu_nuc_qk(q, k) = mu_nuc_qk(q, k) &
                                 + this%couplings(mode) * this%polarizations(q, mode) &
                                 * this%pc%q(k) / this%n_electrons

            end do
         end do
      end do

   end subroutine get_scaled_polarized_nuclear_dipole_1der


end module photon_tool_class

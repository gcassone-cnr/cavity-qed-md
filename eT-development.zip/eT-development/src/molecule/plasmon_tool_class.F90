

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module plasmon_tool_class

   !!
   !! Plasmon tool class module
   !! Written by Enrico Ronca and Tor S. Haugland, 2022-2023
   !!
   !! Class that stores information about plasmons and routines related to computing electron-plasmon
   !! interactions for the Hamiltonian
   !!    H = H_e + w b^+ b + sum_n q_n V_n (b + b^+)
   !! where w is the frequency of the boson mode, q is the charge at point n of the plasmon tesserae,
   !! and V_n is the Coulomb interaction at n, V_n = sum_(i in molecule) q_i / |r_n - r_i|.
   !!

   use parameters
   use global_in, only: input
   use global_out, only: output
   use memory_manager_class, only: mem
   use ao_tool_class, only: ao_tool
   use ao_oei_getter_class, only: ao_oei_getter
   use boson_tool_class, only: boson_tool
   use mm_molecule_class, only: mm_molecule
   use formatted_read_file_class, only: formatted_read_file
   use ao_eri_getter_class, only: ao_eri_getter
   use abstract_ao_eri_getter_class, only: abstract_ao_eri_getter

   implicit none

   type, extends(boson_tool) :: plasmon_tool

      type(mm_molecule), dimension(:), allocatable :: charges

      integer, private :: n_points
      real(dp), dimension(:, :, :), allocatable, private :: ao_electron_plasmon_interaction

   contains

      procedure, public :: initialize
      procedure, public :: cleanup
      procedure, public :: print_summary

      procedure, public :: add_ao_h_contribution
      procedure, public :: get_ao_electron_boson_interaction
      procedure, public :: get_ao_electron_boson_interaction_1der
      procedure, public :: construct_molecular_gradient_boson_interaction
      procedure, public, nopass :: create_ao_eri_getter

      procedure, private :: initialize_plasmon_charges
      procedure, private :: construct_ao_electron_plasmon_interaction

      procedure, public :: get_scaled_polarized_nuclear_dipole_1der

   end type plasmon_tool

   interface plasmon_tool

      procedure :: new_plasmon_tool

   end interface plasmon_tool


contains


   function new_plasmon_tool() result(this)
      !!
      !! Written by Tor S. Haugland, Oct 2021
      !!
      implicit none

      type(plasmon_tool) :: this

      call input%get_required_keyword('modes', 'boson', this%n_modes)

      call mem%alloc(this%n_boson_states, this%n_modes, set_zero=.true.)
      call mem%alloc(this%frequencies, this%n_modes, set_zero=.true.)
      call mem%alloc(this%coherent_states_z, this%n_modes, set_zero=.true.)

      call this%read_boson_settings()
      call this%initialize_plasmon_charges()

   end function new_plasmon_tool


   subroutine initialize(this, ao)
      !!
      !! Written by Tor S. Haugland, Dec 2021
      !!
      implicit none

      class(plasmon_tool), intent(inout) :: this
      class(ao_tool), intent(inout) :: ao
      integer :: mode

      this%n_ao = ao%n
      this%n_electrons = ao%get_n_electrons()
      allocate(this%boson_type, source = "plasmon")

      this%ao_oei = ao_oei_getter(ao)

      call mem%alloc(this%ao_electron_plasmon_interaction, &
                     this%n_ao, &
                     this%n_ao, &
                     this%n_modes, &
                     set_zero=.true.)

      do mode = 1, this%n_modes

         call this%construct_ao_electron_plasmon_interaction( &
                 this%ao_electron_plasmon_interaction(:, :, mode), &
                 mode, &
                 ao &
              )

      end do

      this%n_centers = ao%n_centers

   end subroutine initialize


   subroutine cleanup(this)
      !!
      !! Written by Tor S. Haugland, Oct 2021
      !!
      implicit none

      class(plasmon_tool), intent(inout) :: this

      call mem%dealloc(this%n_boson_states)
      call mem%dealloc(this%frequencies)
      call mem%dealloc(this%coherent_states_z)

      call mem%dealloc(this%ao_electron_plasmon_interaction)

   end subroutine cleanup


   subroutine get_ao_electron_boson_interaction(this, g_wx, mode)
      !!
      !! Written by T. S. Haugland, June 2021
      !!
      !! Gets the bilinear interaction term in the AO basis, the g in g(b+b^+).
      !!
      implicit none

      class(plasmon_tool), intent(in) :: this
      real(dp), dimension(:, :), intent(out) :: g_wx
      integer, intent(in) :: mode

      call dcopy(this%n_ao**2, this%ao_electron_plasmon_interaction(:, :, mode), 1, g_wx, 1)

   end subroutine get_ao_electron_boson_interaction


   subroutine get_ao_electron_boson_interaction_1der(this, g_wxqk, mode)
      !!
      !! Written by Marcus T. Lexander, 2023
      !!
      !! placeholder routine
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(plasmon_tool), intent(in) :: this
      real(dp), dimension(:, :, :, :), intent(out) :: g_wxqk
      integer, intent(in) :: mode

      call do_nothing(this)
      call do_nothing(g_wxqk(1, 1, 1, 1))
      call do_nothing(mode)

      call output%error_msg("get_ao_electron_boson_interaction_1der not implemented for plasmon_tool!")

   end subroutine get_ao_electron_boson_interaction_1der


   subroutine construct_molecular_gradient_boson_interaction(this, ao, E_qk, D, mode, prefactor)
      !!
      !! Written by Marcus T. Lexander, 2024
      !!
      !! placeholder routine
      !!
      use warning_suppressor, only: do_nothing
      use ao_tool_class, only: ao_tool

      implicit none

      class(plasmon_tool), intent(in) :: this
      class(ao_tool), intent(in) :: ao
      real(dp), dimension(3, this%n_centers), intent(inout) :: E_qk
      integer, intent(in) :: mode
      real(dp), dimension(this%n_ao, this%n_ao), intent(in) :: D
      real(dp), intent(in), optional :: prefactor

      call do_nothing(this)
      call do_nothing(E_qk(1, 1))
      call do_nothing(D(1, 1))
      call do_nothing(mode)
      call do_nothing(ao)
      if (present(prefactor)) call do_nothing(prefactor)

      call output%error_msg( &
              "construct_molecular_gradient_boson_interaction not implemented for plasmon_tool!" &
           )

   end subroutine construct_molecular_gradient_boson_interaction


   subroutine add_ao_h_contribution(this, h)
      !!
      !! Written by Enrico Ronca, 2022
      !!
      !! Adds the contribution from the coherent states of the plasmons.
      !!
      implicit none

      class(plasmon_tool), intent(in) :: this
      real(dp), dimension(*), intent(inout), target :: h
      real(dp), dimension(:, :), pointer :: h_wx
      integer :: mode
      real(dp) :: prefactor
      real(dp), dimension(:, :), allocatable :: ao_overlap

      h_wx(1:this%n_ao, 1:this%n_ao) => h(1:this%n_ao**2)

      do mode = 1, this%n_modes

         call daxpy(this%n_ao**2, &
                    two * this%coherent_states_z(mode), &
                    this%ao_electron_plasmon_interaction(:, :, mode), &
                    1, &
                    h_wx, &
                    1)

      end do

      call mem%alloc(ao_overlap, this%n_ao, this%n_ao)
      call this%ao_oei%get_oei("overlap", ao_overlap)

      prefactor = sum(this%frequencies * this%coherent_states_z**2) / this%n_electrons
      call daxpy(this%n_ao**2, prefactor, ao_overlap, 1, h_wx, 1)

      call mem%dealloc(ao_overlap)

   end subroutine add_ao_h_contribution


   subroutine print_summary(this)
      !!
      !! Written by T. S. Haugland, Oct 2021
      !!
      implicit none

      class(plasmon_tool), intent(in) :: this
      integer :: mode
      real(dp) :: displacement

      call output%printf('m', '- Plasmon parameters and properties', ffs='(/t3,a)')

      call output%printf('m', &
                         'Optimize plasmons?  :    (l0)', &
                         logs=[this%is_optimizing_bosons], &
                         ffs='(/t6,a)')

      do mode = 1, this%n_modes
         displacement = this%coherent_states_z(mode) * sqrt(two / this%frequencies(mode))
         call output%printf('m', 'Mode (i0):', ints=[mode], ffs='(/t6,a)')
         call output%print_separator(pl='m', symbol='-', n=8, fs='(t6,a)')

         call output%printf('m', &
                            ' Frequency:           (f17.12)', &
                            reals=[this%frequencies(mode)], &
                            ffs='(t6,a)')

         call output%printf('m', &
                            ' Coherent state:      (f17.12)', &
                            reals=[this%coherent_states_z(mode)], &
                            ffs='(t6,a)')

         call output%printf('m', ' Displacement:        (f17.12)', reals=[displacement], ffs='(t6,a)')
      end do

   end subroutine print_summary


   subroutine initialize_plasmon_charges(this)
      !!
      !! Written by Enrico Ronca and Tor S. Haugland, 2022-2023
      !!
      !! Read input file and create array with charges and positions in Angstrom.
      !!
      !! The file input is as follows, where xyz are in bohr:
      !!
      !! n_points
      !! x1 y1 z1 charge_mode_1 charge_mode_2 charge_mode_3 ...
      !! x2 y2 z2 charge_mode_1 charge_mode_2 charge_mode_3 ...
      !! x3 y3 z3 charge_mode_1 charge_mode_2 charge_mode_3 ...
      !! x4 y4 z4 charge_mode_1 charge_mode_2 charge_mode_3 ...
      !! ...
      !!

      implicit none

      class(plasmon_tool) :: this

      type(formatted_read_file) :: plasmons_file

      real(dp), dimension(:, :), allocatable :: plasmon_data, R, q
      character(len=2), dimension(:), allocatable :: symbols

      integer :: mode, n_cols, i, j

      n_cols = 3 + this%n_modes
      plasmons_file = formatted_read_file("plasmons.txt")

      call plasmons_file%open_("rewind")
      call plasmons_file%read_(this%n_points)
      call mem%alloc(plasmon_data, n_cols, this%n_points)
      call plasmons_file%read_(plasmon_data, n_cols * this%n_points)
      call plasmons_file%close_()

      call mem%alloc(R, 3, this%n_points)
      call mem%alloc(q, this%n_points, this%n_modes)

      !$omp parallel do private(i, j)
      do j = 1, this%n_points
         do i = 1, 3

            R(i, j) = bohr_to_angstrom * plasmon_data(i, j)

         end do
      end do
      !$omp end parallel do

      !$omp parallel do private(i, j)
      do j = 1, this%n_modes
         do i = 1, this%n_points

            q(i, j) = plasmon_data(3 + j, i)

         end do
      end do
      !$omp end parallel do

      call mem%dealloc(plasmon_data)

      allocate(symbols(this%n_points))
      symbols = 'X'

      allocate(this%charges(this%n_modes))
      do mode = 1, this%n_modes

         this%charges(mode) = mm_molecule(this%n_points)
         call this%charges(mode)%initialize_mm_atoms(R, symbols)
         call this%charges(mode)%set_q(q(:, mode))

      end do

      call mem%dealloc(R)
      call mem%dealloc(q)
      deallocate(symbols)

   end subroutine initialize_plasmon_charges


   subroutine construct_ao_electron_plasmon_interaction(this, g_wx, mode, ao)
      !!
      !! Written by Enrico Ronca and T. S. Haugland, 2022
      !!
      !! Compute and get the integrals used in the electron-plasmon bilinear interaction,
      !!    g_wx = - sum_i sum_plasmons < w | (q_plasmon / |r_i - R_plasmon|) | x >
      !!           + sum_nuc sum_plasmons q_nuc q_plasmon / |R_nuc - R_plasmon| * < w | x > / N_e
      !!
      use point_charges_class, only: point_charges

      implicit none

      class(plasmon_tool), intent(in) :: this
      real(dp), dimension(this%n_ao, this%n_ao), intent(out) :: g_wx
      integer, intent(in) :: mode
      class(ao_tool), intent(inout) :: ao

      type(point_charges) :: nuclei_pc, plasmon_pc

      integer :: point
      real(dp) :: V_nuc
      real(dp), dimension(3, this%n_points) :: plasmon_coordinates
      real(dp), dimension(this%n_points) :: plasmon_charges
      real(dp), dimension(:, :), allocatable :: ao_overlap

      ! Get nuclei charges and coordinates
      call ao%get_point_charges(nuclei_pc)

      ! Get plasmon charges and coordinates
      do point = 1, this%n_points
         plasmon_coordinates(:, point) = this%charges(mode)%get_r_i(point)
         plasmon_charges(point) = this%charges(mode)%get_q_i(point)
      end do

      plasmon_pc = point_charges(this%n_points)
      call plasmon_pc%initialize()
      plasmon_pc%r = plasmon_coordinates
      plasmon_pc%q = plasmon_charges

      ! Calculate electrostatic potential from plasmons and add it to g_wx
      call ao%initialize_external_charges(this%n_points, plasmon_coordinates, plasmon_charges)
      call ao%get_oei('electrostatic potential', g_wx)

      ! Calculate electrostatic interaction between nuclei and plasmons and add it to g_wx
      V_nuc = nuclei_pc%get_coulomb_interaction_2_point_charges(plasmon_pc)

      call mem%alloc(ao_overlap, this%n_ao, this%n_ao)
      call this%ao_oei%get_oei("overlap", ao_overlap)

      call daxpy(this%n_ao**2, V_nuc / this%n_electrons, ao_overlap, 1, g_wx, 1)

      call mem%dealloc(ao_overlap)

   end subroutine construct_ao_electron_plasmon_interaction


   subroutine create_ao_eri_getter(eri_getter, ao)
      !!
      !! Written by Tor S. Haugland, 2023
      !!
      implicit none

      class(abstract_ao_eri_getter), allocatable :: eri_getter
      class(ao_tool) :: ao

      eri_getter = ao_eri_getter(ao)

   end subroutine create_ao_eri_getter


   subroutine get_scaled_polarized_nuclear_dipole_1der(this, mu_nuc_qk)
      !!
      !! Written by Sara Angelico, 2024
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(plasmon_tool) :: this

      integer :: k, q, mode

      real(dp), dimension(:, :), intent(inout) :: mu_nuc_qk

      call do_nothing(this)
      call do_nothing(k)
      call do_nothing(q)
      call do_nothing(mode)
      call do_nothing(mu_nuc_qk)

   end subroutine get_scaled_polarized_nuclear_dipole_1der

end module plasmon_tool_class

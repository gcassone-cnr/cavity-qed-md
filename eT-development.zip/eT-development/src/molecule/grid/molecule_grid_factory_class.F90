module molecule_grid_factory_class

   !!
   !! Molecule grid factory class module
   !! Written by Marco Scavino, 2022
   !!
   !! Factory to build the molecule_grid class
   !! Possibile type of grid are:
   !!
   !!    * cubic grid. Need the total number of points!
   !!    * radial-angular grid. Possible to set the radial threshold and angular order range
   !!

   use parameters

   use molecule_grid_class, only: molecule_grid
   use atom_grid_class, only: atom_grid

   use radial_quadrature_class, only: radial_quadrature
   use angular_grid_class, only: angular_grid
   use becke_partitioning_class, only: becke_partitioning

   use ao_tool_class, only: ao_tool

   use global_in, only: input
   use global_out, only: output

   use memory_manager_class, only: mem

   implicit none

   type, public :: molecule_grid_factory

      type(angular_grid), allocatable :: angular
      class(becke_partitioning), allocatable :: partitioning
      class(radial_quadrature), allocatable :: quadrature

      logical :: is_cubic

   contains

      procedure :: build_from_input => build_from_input_molecule_grid_factory

      procedure, nopass :: build_cubic => build_cubic_molecule_grid_factory
      procedure :: build_spherical => build_spherical_molecule_grid_factory

      procedure, private :: prepare_radial_and_angular
      procedure, private :: complete_spherical

      procedure, private :: read_radial_quadrature
      procedure, private :: read_partitioning
      procedure, private :: read_angular

      procedure, nopass, private :: set_grid_atoms

      procedure, private :: print_summary

   end type

contains

   subroutine build_from_input_molecule_grid_factory(this, grid, ao, selected)
      !!
      !! Written by Marco Scavino, 2022
      !!
      !! Assemble the molecule grid for the current system of ao reading the input settings
      !!
      !! If `selected` optional argument given, use only the centers in the
      !! selected positions.
      !!
      implicit none

      class(molecule_grid_factory), intent(inout) :: this

      type(molecule_grid), intent(out) :: grid
      type(ao_tool), intent(in) :: ao
      integer, intent(in), optional :: selected(:)
      real(dp) :: cube_side, cube_offset

      call output%printf('n', '- Grid construction', fs='(/t3,a)')

      call this%set_grid_atoms(grid, ao, selected)

      grid%n_cart_basis = ao%n_cartesian

      this%is_cubic = input%is_keyword_present("cube side", "grid info")

      if (this%is_cubic) then

         call input%get_keyword("cube side", "grid info", cube_side)
         call input%get_keyword("cube offset", "grid info", cube_offset)

         call this%build_cubic(grid, cube_side, cube_offset)

      else

         call this%build_spherical(grid)

      end if

      call this%print_summary(grid)

      call grid%set_batching()

   end subroutine build_from_input_molecule_grid_factory


   subroutine build_spherical_molecule_grid_factory(this, grid)
      !!
      !! Written by Marco Scavino, May 2019
      !!

      implicit none

      class(molecule_grid_factory), intent(inout) :: this

      type(molecule_grid), intent(inout) :: grid

      call this%read_angular()
      call this%read_partitioning()
      call this%read_radial_quadrature()

      call this%prepare_radial_and_angular(grid)

      call this%complete_spherical(grid)

      call this%partitioning%build(grid)

      call this%angular%cleanup()

   end subroutine build_spherical_molecule_grid_factory


   subroutine prepare_radial_and_angular(this, grid)
      !!
      !! Written by Marco Scavino, May 2019
      !!
      !! Construct the radial and angular grid. Given in input the radial threshold
      !! (read by the radial_quadrature) and the angular order range (read by the angular_grid)
      !! calculate the number of points in the grid and set up the angular/radial value necessary
      !! to build the final grid.
      !!

      implicit none

      class(molecule_grid_factory), intent(inout) :: this

      type(molecule_grid), intent(inout) :: grid

      integer :: atom

      grid%n_points = 0

      do atom = 1, grid%num_atoms

         ! Save the atom offset for the grid constructor

         grid%atoms(atom)%offset = grid%n_points
         grid%atoms(atom)%n_points = 0

         call this%quadrature%build(grid%atoms(atom))

         call grid%atoms(atom)%pruning(this%angular)

         ! Total number of grid points

         grid%n_points = grid%n_points + grid%atoms(atom)%n_points

      end do

      call mem%alloc(grid%points, 3, grid%n_points)
      call mem%alloc(grid%weight, grid%n_points)

   end subroutine prepare_radial_and_angular


   subroutine complete_spherical(this, grid)
      !!
      !! Written by Marco Scavino, May 2019
      !!

      use omp_lib
      implicit none

      class(molecule_grid_factory), intent(in) :: this

      class(molecule_grid), intent(inout) :: grid

      integer :: atom, point, j, angular_points, ang_index, radial_points, atom_offset

      real(dp) :: r_A(3), r_p, weight

      !$omp parallel do private(atom, atom_offset, j, r_p, r_A, point, weight, &
      !$omp &                   ang_index, angular_points, radial_points)
      do atom = 1, grid%num_atoms

         atom_offset = grid%atoms(atom)%offset
         radial_points = grid%atoms(atom)%radial_points

         r_A = grid%atoms(atom)%r_atom

         do point = 1, radial_points

            r_p = grid%atoms(atom)%radial(point)
            weight = four * pi * grid%atoms(atom)%weight(point)

            ang_index = grid%atoms(atom)%angular_index(point)
            angular_points = this%angular%get_points(ang_index)

            do j = 1, angular_points

               grid%points(1, j + atom_offset) = this%angular%x(j, ang_index) * r_p + r_A(1)
               grid%points(2, j + atom_offset) = this%angular%y(j, ang_index) * r_p + r_A(2)
               grid%points(3, j + atom_offset) = this%angular%z(j, ang_index) * r_p + r_A(3)
               grid%weight(j + atom_offset) = this%angular%w(j, ang_index) * weight

            end do

            atom_offset = atom_offset + angular_points

         end do

      end do
      !$omp end parallel do

   end subroutine complete_spherical


   subroutine read_angular(this)
      !!
      !! Written by Marco Scavino, May 2019
      !!

      implicit none

      class(molecule_grid_factory), intent(inout) :: this

      integer :: min_order, max_order

      min_order = 15
      max_order = 30

      call input%get_keyword('maximum angular order', 'grid info', max_order)
      call input%get_keyword('minimum angular order', 'grid info', min_order)

      this%angular = angular_grid(min_order, max_order)
      call this%angular%print_settings()

   end subroutine


   subroutine read_partitioning(this)
      !!
      !! Written by Marco Scavino, 2022
      !!
      implicit none

      class(molecule_grid_factory), intent(inout) :: this

      character(len=200) :: key

      key = "becke"
      call input%get_keyword("partitioning", "grid info", key)

      select case (key)
         case default

            call output%error_msg('Unknown partitioning method (a)!', chars=[key])

         case ("becke")

            this%partitioning = becke_partitioning()

      end select

      call this%partitioning%print_settings()

   end subroutine read_partitioning


   subroutine read_radial_quadrature(this)
      !!
      !! Written by Marco Scavino, 2022
      !!

      use gauss_chebyshev_class, only: gauss_chebyshev
      use treutler_ahlrichs_class, only: treutler_ahlrichs

      implicit none

      class(molecule_grid_factory) :: this
      character(len=200) :: key
      real(dp) :: threshold

      threshold = zero
      key = "gauss-chebyshev"

      call input%get_keyword("quadrature", "grid info", key)
      call input%get_keyword('radial threshold', 'grid info', threshold)

      select case (key)
         case default

            call output%error_msg('Unknown quadrature method "(a)"!', chars=[key])

         case ('gauss-chebyshev')

            this%quadrature = gauss_chebyshev(threshold)

         case ('treutler-ahlrics')

            this%quadrature = treutler_ahlrichs(threshold)

      end select

      call this%quadrature%print_settings()

   end subroutine read_radial_quadrature


   subroutine set_grid_atoms(grid, ao, selected)
      !!
      !! Written by Marco Scavino, 2022
      !!
      !! Set the atomic grid according to the selected
      !! centers. If not selected any centers, use all
      !! the available centers
      !!
      use atomic_center_class, only: atomic_center
      use parameters

      implicit none

      class(molecule_grid), intent(inout) :: grid
      type(ao_tool), intent(in) :: ao
      integer, intent(in), optional :: selected(:)

      type(atomic_center) :: center

      integer, allocatable :: selected_(:)
      integer :: atom

      if (present(selected)) then

         selected_ = selected

      else

         selected_ = [(atom, atom = 1, ao%n_centers)]

      end if

      ! Get the selected atoms and convert to bohr

      grid%num_atoms = size(selected_)
      allocate(grid%atoms(grid%num_atoms))

      do atom = 1, grid%num_atoms

         call ao%get_center(selected_(atom), center)

         grid%atoms(atom) = atom_grid(selected_(atom), &
                                      center%number_, &
                                      center%coordinates * angstrom_to_bohr)

      end do

   end subroutine set_grid_atoms


   subroutine build_cubic_molecule_grid_factory(grid, step, cube_offset)
      !!
      !! Written by Marco Scavino, June 2019
      !!
      !! Given the total number of points, construct a cubic grid, splitting up along each side.
      !! The number of points is computed as cubic root of the total number of points. Then, the
      !! the total number of points is re-computed as cubic side-points.
      !!
      !! The cube is computed respect the difference of x, y and z minimum/maximum value, with an
      !! extra cube_offset added to all direction
      !!
      implicit none

      type(molecule_grid), intent(inout) :: grid

      real(dp), intent(in) :: step, cube_offset

      integer :: atom, i, j, k
      real(dp), dimension(3) :: r_min, r_max
      integer :: offset, nx, ny, nz

      r_min = grid%atoms(1)%r_atom
      r_max = grid%atoms(1)%r_atom

      do atom = 2, grid%num_atoms

         r_min = min(r_min, grid%atoms(atom)%r_atom)
         r_max = max(r_max, grid%atoms(atom)%r_atom)

      end do

      r_min = r_min - cube_offset
      r_max = r_max + cube_offset

      nx = nint((r_max(1) - r_min(1)) / step)
      ny = nint((r_max(2) - r_min(2)) / step)
      nz = nint((r_max(3) - r_min(3)) / step)

      grid%n_points = nx * ny * nz

      call mem%alloc(grid%points, 3, grid%n_points)
      call mem%alloc(grid%weight, grid%n_points)

      grid%weight(:) = grid%n_points

      !$omp parallel do private(k, j, i, offset) collapse(3) schedule(static)
      do k = 1, nz

         do j = 1, ny

            do i = 1, nx

               offset = (k - 1) * nz * ny + (j - 1) * ny + i
               grid%points(1, offset) = r_min(1) + (i - 1) * step
               grid%points(2, offset) = r_min(2) + (j - 1) * step
               grid%points(3, offset) = r_min(3) + (k - 1) * step

            end do

         end do

      end do

   end subroutine build_cubic_molecule_grid_factory


   subroutine print_summary(this, grid)
      !!
      !! Written by Marco Scavino, May 2019
      !!
      implicit none

      class(molecule_grid_factory), intent(in) :: this
      type(molecule_grid), intent(in) :: grid

      integer :: atom

      call output%printf('n', 'Total points:  (i0)', ints=[grid%n_points], fs='(/t6,a)')

      if (this%is_cubic) return

      call output%printf('n', 'Atoms:', fs='(/t6,a)')

      do atom = 1, grid%num_atoms

         call output%printf('n', &
                            "Atom (i0) points: (i0) (radial (i0))", &
                            ints=[atom, grid%atoms(atom)%n_points, grid%atoms(atom)%radial_points], &
                            fs='(t9,a)')

      end do

   end subroutine print_summary

end module

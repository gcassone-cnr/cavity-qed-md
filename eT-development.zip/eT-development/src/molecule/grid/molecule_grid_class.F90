
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.

module molecule_grid_class
   !!
   !! Molecular grid class
   !! Written by Marco Scavino, 2022
   !!
   !! Grid of points build over a molecule. Each point has a corresponding weights
   !!
   use kinds
   use parameters

   use atom_grid_class, only: atom_grid

   use batching_index_class, only: batching_index

   use memory_manager_class, only: mem


   implicit none

   type :: molecule_grid

      type(atom_grid), allocatable :: atoms(:)

      integer :: n_points = 0
      integer :: num_atoms = 0

      integer :: n_cart_basis

      real(dp), allocatable :: points(:, :)
      real(dp), allocatable :: weight(:)

      ! Integrals block dimension
      type(batching_index) :: pt_batch
      type(batching_index) :: ao_batch

      integer, allocatable :: non_zeros(:, :)
      integer, allocatable :: non_zero_count(:)

   contains

      procedure :: set_batching => set_batching_molecule_grid

      procedure :: ao_density_contraction => ao_density_contraction_molecule_grid
      procedure :: ao_ao_contraction => ao_ao_contraction_molecule_grid

      procedure :: cleanup => cleanup_molecule_grid

   end type molecule_grid

contains


   subroutine cleanup_molecule_grid(this)
      !!
      !! Written by Marco Scavino, June 2019
      !!
      implicit none

      class(molecule_grid), intent(inout) :: this

      integer :: atom

      call mem%dealloc(this%non_zero_count)
      call mem%dealloc(this%non_zeros)

      call mem%dealloc(this%points)
      call mem%dealloc(this%weight)

      do atom = 1, this%num_atoms

         call this%atoms(atom)%cleanup()

      end do

      deallocate(this%atoms)

   end subroutine cleanup_molecule_grid


   subroutine ao_ao_contraction_molecule_grid(this, A, B, C)
      !!
      !! Written by Marco Scavino, Apr 2021
      !!
      !! Perform the following matrix multiplication:
      !!
      !! C = A^T * B + C
      !!
      !! using the screening array grid%non_zeros.
      !! The A and B are matrix of dimensions (k, m)
      !!
      !! The matrix multiplication is batched and each block is checked if null.
      !! DGEMM is performed only on non-zero elements.
      !!
      use omp_lib
      use array_initialization

      implicit none

      class(molecule_grid) :: this

      real(dp), dimension(this%n_points, this%n_cart_basis), intent(in) :: A, B
      real(dp), dimension(this%n_cart_basis, this%n_cart_basis), intent(inout) :: C

      integer :: n_threads, n_cart_basis, thread, i_m, i_n, i_k, tot_blocks
      real(dp), dimension(:, :, :), allocatable :: C_thread

      type(batching_index) :: m, n, k

      thread = 1
      n_threads = 1
      !$ n_threads = omp_get_max_threads()

      ! Get the current batches for grid points and basis

      m = this%ao_batch
      n = this%ao_batch
      k = this%pt_batch

      n_cart_basis = this%n_cart_basis

      call zero_array(C, n_cart_basis**2)

      call mem%alloc(C_thread, n_cart_basis, n_cart_basis, n_threads, set_zero=.true.)

      !$omp parallel do default(shared) private(i_k, i_m, i_n, thread, tot_blocks) &
      !$omp firstprivate(m, n, k)
      do i_k = 1, k%num_batches

         !$ thread = omp_get_thread_num() + 1

         call k%determine_limits(i_k)

         ! Get the total number of non-zero block for k-block of points.
         ! If number of blocks is lower than max number of blocks, we have some zero blocks

         tot_blocks = this%non_zero_count(i_k)

         if (tot_blocks < m%num_batches) then

            do i_m = 1, tot_blocks

               call m%determine_limits(this%non_zeros(i_m, i_k))

               do i_n = 1, tot_blocks

                  call n%determine_limits(this%non_zeros(i_n, i_k))

                  call dgemm("T", &
                             "N", &
                             m%length, &
                             n%length, &
                             k%length, &
                             one, &
                             A(k%first, m%first), &
                             k%index_dimension, &
                             B(k%first, n%first), &
                             k%index_dimension, &
                             one, &
                             C_thread(m%first, n%first, thread), &
                             n_cart_basis)

               end do

            end do

         else

            call dgemm("T", &
                       "N", &
                       n_cart_basis, &
                       n_cart_basis, &
                       k%length, &
                       one, &
                       A(k%first, 1), &
                       k%index_dimension, &
                       B(k%first, 1), &
                       k%index_dimension, &
                       one, &
                       C_thread(1, 1, thread), &
                       n_cart_basis)

         end if

      end do
      !$omp end parallel do

      ! Accumulate threads results into C matrix

      do thread = 1, n_threads

         call daxpy(n_cart_basis**2, one, C_thread(:, :, thread), 1, C, 1)

      end do

      call mem%dealloc(C_Thread)

   end subroutine ao_ao_contraction_molecule_grid


   subroutine ao_density_contraction_molecule_grid(grid, chi_pt_mu, D_cart, X_mu_r)
      !!
      !! Written by Marco Scavino, Apr 2021
      !!
      !! Perform the following operation:
      !!
      !! X_pt_nu = sum_mu chi_pt_mu D_nu_mu
      !!
      !! using the screening array grid%non_zeros.
      !!
      !! The matrix multiplication is batched and each block is checked if null.
      !! DGEMM is performed only on non-zero elements.
      !!
      implicit none

      class(molecule_grid) :: grid

      real(dp), dimension(grid%n_points, grid%n_cart_basis), intent(in) :: chi_pt_mu
      real(dp), dimension(grid%n_cart_basis, grid%n_cart_basis), intent(in) :: D_cart

      real(dp), dimension(grid%n_points, grid%n_cart_basis), intent(in) :: X_mu_r

      integer :: n_points, n_cart_basis
      integer :: tot_blocks, i_mu, i_pt
      real(dp) :: beta

      type(batching_index) :: mu_batch, pt_batch

      n_points = grid%n_points
      n_cart_basis = grid%n_cart_basis

      ! Set locally the batch dimensions

      pt_batch = grid%pt_batch
      mu_batch = grid%ao_batch

      !$omp parallel do default(shared) private(beta, i_pt, i_mu, tot_blocks) firstprivate(pt_batch, mu_batch)
      do i_pt = 1, pt_batch%num_batches

         call pt_batch%determine_limits(i_pt)

         tot_blocks = grid%non_zero_count(i_pt)

         beta = zero

         if (tot_blocks < mu_batch%num_batches) then

            do i_mu = 1, tot_blocks

               call mu_batch%determine_limits(grid%non_zeros(i_mu, i_pt))

               call dgemm("N", &
                          "T", &
                          pt_batch%length, &
                          n_cart_basis, &
                          mu_batch%length, &
                          one, &
                          chi_pt_mu(pt_batch%first, mu_batch%first), &
                          n_points, &
                          D_cart(1, mu_batch%first), &
                          n_cart_basis, &
                          beta, &
                          X_mu_r(pt_batch%first, 1), &
                          n_points)

               ! After the first loop, accumulate result
               beta = one

            end do

         else

            call dgemm("N", &
                       "T", &
                       pt_batch%length, &
                       n_cart_basis, &
                       n_cart_basis, &
                       one, &
                       chi_pt_mu(pt_batch%first, 1), &
                       n_points, &
                       D_cart, &
                       n_cart_basis, &
                       zero, &
                       X_mu_r(pt_batch%first, 1), &
                       n_points)


         end if

      end do

   end subroutine ao_density_contraction_molecule_grid


   subroutine set_batching_molecule_grid(this)
      !!
      !! Written by Marco Scavino, 2022
      !!
      !! Set the batching dimensions for the grid operations
      !!

      implicit none

      class(molecule_grid) :: this

      integer :: max_length

      max_length = 32
      this%ao_batch = batching_index(this%n_cart_basis)
      this%ao_batch%max_length = max_length
      this%ao_batch%num_batches = (this%ao_batch%index_dimension - 1) / max_length + 1

      max_length = 64
      this%pt_batch = batching_index(this%n_points)
      this%pt_batch%max_length = max_length
      this%pt_batch%num_batches = (this%pt_batch%index_dimension - 1) / max_length + 1

   end subroutine set_batching_molecule_grid


end module molecule_grid_class

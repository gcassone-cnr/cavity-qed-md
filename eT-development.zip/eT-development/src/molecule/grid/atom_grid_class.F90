

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module atom_grid_class

   !!
   !! Atom grid class
   !! Written by Marco Scavino, June 2019
   !!
   !! Class to manage the radial and angular part or a single atom
   !!

   use kinds
   use global_out, only: output
   use memory_manager_class, only: mem

   implicit none

   type :: atom_grid

      integer :: atom_id
      real(dp), dimension(3) :: r_atom
      integer :: Z
      integer, dimension(:), allocatable :: angular_index
      real(dp), dimension(:), allocatable :: radial
      real(dp), dimension(:), allocatable :: weight

      integer :: offset = 0
      integer :: radial_points = 0
      integer :: n_points = 0

   contains

      procedure :: pruning => pruning_atom_grid
      procedure :: set_radial => set_radial_atom_grid
      procedure :: cleanup => cleanup_atom_grid

   end type

   interface atom_grid
      procedure :: new_atom_grid
   end interface

contains

   function new_atom_grid(atom_id, number_, r) result(grid)
      !!
      !! Written by Marco Scavino, May 2019
      !!
      implicit none

      type(atom_grid) :: grid
      integer, intent(in) :: atom_id
      integer, intent(in) :: number_
      real(dp), dimension(3), intent(in) :: r

      grid%atom_id = atom_id
      grid%Z = number_
      grid%r_atom(:) = r
      grid%n_points = 0
      grid%offset = 0

   end function new_atom_grid


   subroutine set_radial_atom_grid(grid, radial_points)
      !!
      !! Written by Marco Scavino, May 2019
      !!
      !! Set the number of radial points, then allocate the class arrays.
      !!
      implicit none

      class(atom_grid), intent(inout) :: grid
      integer, intent(in) :: radial_points

      if (radial_points <= 0) then
         call output%error_msg("Radial grid point equal zero or negative!")
      end if

      grid%radial_points = radial_points

      call mem%alloc(grid%angular_index, grid%radial_points)
      call mem%alloc(grid%radial, grid%radial_points)
      call mem%alloc(grid%weight, grid%radial_points)

   end subroutine set_radial_atom_grid


   subroutine pruning_atom_grid(this, angular)
      !!
      !! Written by Marco Scavino, Jan 2023
      !!
      !! Given an angular grid, associated each radial point in the atom's grid
      !! to the proper angular grid.
      !!
      use angular_grid_class, only: angular_grid
      use parameters
      use bragg_radii_info

      implicit none

      class(atom_grid), intent(inout) :: this
      type(angular_grid), intent(in) :: angular

      real(dp) :: r_bragg, r_i
      integer :: i, angular_index, angular_points, n_points

      r_bragg = bragg_radii(this%Z) * angstrom_to_bohr / five
      n_points = 0

      !$omp parallel do private(i, r_i, angular_points, angular_index) reduction(+:n_points)
      do i = 1, this%radial_points

         r_i = this%radial(i)

         angular_points = int(angular%max_points * r_i / r_bragg)

         call angular%check_points(angular_points, angular_index)

         this%angular_index(i) = angular_index
         n_points = n_points + angular_points

      end do
      !$omp end parallel do

      this%n_points = n_points

   end subroutine pruning_atom_grid


   subroutine cleanup_atom_grid(grid)
      !!
      !! Written by Marco Scavino, May 2019
      !!
      !! Deconstruct atom_grid object and deallocate the arrays.
      !!
      implicit none

      class(atom_grid), intent(inout) :: grid

      call mem%dealloc(grid%angular_index)
      call mem%dealloc(grid%radial)
      call mem%dealloc(grid%weight)

   end subroutine cleanup_atom_grid

end module

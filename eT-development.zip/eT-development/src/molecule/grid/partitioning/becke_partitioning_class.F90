
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module becke_partitioning_class
   !!
   !! Becke partitioning class module
   !! Written by Marco Scavino, June 2019
   !!
   !! Becke original partitioning.
   !! Starting from a constructed molecular grid, it compute the weight as described
   !! by Becke in J. Chem. Phys. 88, 2547 (1988), https://doi.org/10.1063/1.454033
   !! using the partitioning.
   !!
   use parameters

   use atom_grid_class, only: atom_grid
   use molecule_grid_class, only: molecule_grid

   use memory_manager_class, only: mem
   use global_out, only: output
   use bragg_radii_info, only: bragg_radii

   implicit none

   type :: becke_partitioning

      character(len=200) :: description_

   contains

      procedure :: build => build_becke_partitioning
      procedure, nopass, private :: construct_distances

      procedure, nopass :: step_function => step_function_becke_partitioning

      procedure :: print_settings => print_settings_becke_partitioning

   end type

   interface becke_partitioning
      procedure :: new_becke_partitioning
   end interface

contains

   function new_becke_partitioning() result(becke)
      !!
      !! Written by Marco Scavino, June 2019
      !!
      implicit none

      type(becke_partitioning) :: becke

      becke%description_ = "Becke partitioning functions w(r)"

   end function new_becke_partitioning


   subroutine construct_distances(atoms, a_AB, r_AB)
      !!
      !! Written by Marco Scavino, June 2019
      !!

      implicit none

      type(atom_grid), intent(in) :: atoms(:)
      real(dp), dimension(:, :), intent(out) :: a_AB, r_AB

      integer :: Z_A, Z_B, atom_A, atom_B
      real(dp) :: dx, dy, dz
      real(dp) :: chi, a, r_AB_inv
      real(dp), dimension(3) :: r_A, r_B
      real(dp), parameter :: sqrt_2m1 = sqrt(two) - one, sqrt_2p1 = sqrt(two) + one  ! sqrt2+1  ! sqrt2-1

      !$omp parallel do default(shared) private(atom_A, atom_B, Z_A, Z_B, r_A, r_B, chi, a, dx, dy, dz)
      do atom_A = 1, size(atoms)

         a_AB(atom_A, atom_A) = zero
         r_AB(atom_A, atom_A) = zero

         Z_A = atoms(atom_A)%Z

         r_A(1) = atoms(atom_A)%r_atom(1)
         r_A(2) = atoms(atom_A)%r_atom(2)
         r_A(3) = atoms(atom_A)%r_atom(3)

         do atom_B = 1, atom_A - 1

            r_B(1) = atoms(atom_B)%r_atom(1)
            r_B(2) = atoms(atom_B)%r_atom(2)
            r_B(3) = atoms(atom_B)%r_atom(3)

            ! chi_AB = R_A/R_B (A4)

            Z_B = atoms(atom_B)%Z

            chi = bragg_radii(Z_A) / bragg_radii(Z_B)

            ! instead of comparing a, we compare directly chi and setup
            ! a value accordingly |a| <= 0.5 => |chi-sqrt2| <= 1

            if (chi <= sqrt_2m1) then
               a = half
            else if (chi >= sqrt_2p1) then
               a = - half
            else

               ! a = (1-chi**2)/(4chi) (A5) and (A6) togheter

               a = (one - chi * chi) / (four * chi)

            end if

            ! a_AB is an antisymmetric matrix

            a_AB(atom_A, atom_B) = a
            a_AB(atom_B, atom_A) = - a

            dx = r_A(1) - r_B(1)
            dy = r_A(2) - r_B(2)
            dz = r_A(3) - r_B(3)

            r_AB_inv = one / sqrt(dx * dx + dy * dy + dz * dz)

            ! r_AB is a symmetric matrix

            r_AB(atom_A, atom_B) = r_AB_inv
            r_AB(atom_B, atom_A) = r_AB_inv

         end do

      end do
      !$omp end parallel do

   end subroutine construct_distances


   subroutine build_becke_partitioning(this, grid)
      !!
      !! Written by Marco Scavino, June 2019
      !!
      !! Compute weight functions multiply current sphere/shell generated for specified atom by space
      !! partitioning weights as described by Becke.
      !!
      implicit none

      class(becke_partitioning), intent(in) :: this

      type(molecule_grid), intent(inout) :: grid

      real(dp) :: atomic_weight

      integer :: num_atoms, atom, atom_A, atom_B, offset, point
      real(dp) :: mu_AB, nu_AB, s_nu, dx, dy, dz
      real(dp) :: P_A, P_n, sum_P, r_iA, r_iB
      real(dp), dimension(3) :: r_i

      real(dp), dimension(:, :), allocatable :: a_AB, r_AB

      num_atoms = size(grid%atoms)

      call mem%alloc(a_AB, num_atoms, num_atoms)
      call mem%alloc(r_AB, num_atoms, num_atoms)

      call this%construct_distances(grid%atoms, a_AB, r_AB)

      ! No need if only one atoms

      if (num_atoms == 1) return

      !$omp parallel do default(shared) private(atom, point, atom_A, atom_B, atomic_weight, &
      !$omp    offset, P_A, P_n, sum_P, r_i, r_iA, r_iB, mu_AB, nu_AB, s_nu, dx, dy, dz)
      do atom = 1, num_atoms

         offset = grid%atoms(atom)%offset

         do point = offset + 1, offset + grid%atoms(atom)%n_points

            sum_P = zero
            P_n = one

            r_i(1) = grid%points(1, point)
            r_i(2) = grid%points(2, point)
            r_i(3) = grid%points(3, point)

            do atom_A = 1, num_atoms

               P_A = one

               dx = grid%atoms(atom_A)%r_atom(1) - r_i(1)
               dy = grid%atoms(atom_A)%r_atom(2) - r_i(2)
               dz = grid%atoms(atom_A)%r_atom(3) - r_i(3)

               r_iA = sqrt(dx * dx + dy * dy + dz * dz)

               do atom_B = 1, num_atoms

                  if (atom_B == atom_A) cycle

                  dx = grid%atoms(atom_B)%r_atom(1) - r_i(1)
                  dy = grid%atoms(atom_B)%r_atom(2) - r_i(2)
                  dz = grid%atoms(atom_B)%r_atom(3) - r_i(3)

                  r_iB = sqrt(dx * dx + dy * dy + dz * dz)

                  ! mu_AB = (r_iA-r_iB)*R_AB, eq.~(11)

                  mu_AB = (r_iA - r_iB) * r_AB(atom_A, atom_B)

                  ! nu_AB = mu_AB + a_AB*(1-mu_AB**2)

                  nu_AB = mu_AB + a_AB(atom_A, atom_B) * (one - mu_AB * mu_AB)

                  s_nu = this%step_function(nu_AB)

                  ! P_A(r) = product_{B != A} s(nu_AB)

                  P_A = P_A * s_nu

               end do

               if (atom_A == atom) P_n = P_A

               ! sum_A P_A(r)

               sum_P = sum_P + P_A

            end do

            ! w_n(r) = P_n(r)/(sum_A P_A(r))

            atomic_weight = P_n / sum_P

            grid%weight(point) = atomic_weight * grid%weight(point)

         end do
      end do
      !$omp end parallel do

      call mem%dealloc(a_AB)
      call mem%dealloc(r_AB)

   end subroutine build_becke_partitioning


   pure function step_function_becke_partitioning(mu_AB) result(s_mu)
      !!
      !! Written by Marco Scavino, August 2019
      !!
      !! Step function as described by Becke (3 recursive call of the function)
      !!
      implicit none

      real(dp), intent(in) :: mu_AB
      real(dp) :: p_mu, f_mu, s_mu

      ! p(mu_AB) = 0.5*mu_AB*(3-mu_AB**2)

      p_mu = mu_AB * (three - mu_AB * mu_AB) * half
      p_mu = p_mu * (three - p_mu * p_mu) * half

      ! f(mu_AB) = p(p(p(mu_AB)))

      f_mu = p_mu * (three - p_mu * p_mu) * half

      ! s(mu_AB) = 0.5(1-f(mu_AB))

      s_mu = (one - f_mu) * half

   end function step_function_becke_partitioning


   subroutine print_settings_becke_partitioning(becke)
      !!
      !! Written by Marco Scavino, June 2019
      !!
      implicit none

      class(becke_partitioning), intent(in) :: becke

      call output%printf('n', "Partitioning: " // trim(becke%description_), fs='(/t6,a)')

   end subroutine print_settings_becke_partitioning

end module becke_partitioning_class

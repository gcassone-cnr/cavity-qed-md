

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module bragg_radii_info
   !!
   !! Bragg radii module
   !! Written by Marco Scavino, June 2019
   !!
   !! Value taken from DALTON code. Modified by array written by Trond Saue:
   !!
   !! Original comment:
   !!
   !! Trond Sauce
   !! The below data gives atomic radii in Angstroms and stems from table I of
   !! J.C.Slater: "Atomic Radii in Crystals"
   !! J.Chem.Phys. 41(1964) 3199-3204
   !! Values for elements marked with an asterisk has been
   !! guessed/interpolated
   !!
   !! Modified by Marco Scavino, moved from C language to Fortran2008
   !!

   use kinds

   implicit none

   real(dp), parameter :: bragg_radii(0:103) = [ &
   ! dummy
   0.75D0, &
   ! H        He*
   0.35D0, 0.35D0, &
   ! Li       Be       B        C        N        O        F        Ne*
   1.45D0, 1.05D0, 0.85D0, 0.70D0, 0.65D0, 0.60D0, 0.50D0, 0.45D0, &
   ! Na       Mg       Al       Si       P        S        Cl       Ar*
   1.80D0, 1.50D0, 1.25D0, 1.10D0, 1.00D0, 1.00D0, 1.00D0, 1.00D0, &
   ! K        Ca       Sc       Ti       V        Cr       Mn       Fe       Co
   2.20D0, 1.80D0, 1.60D0, 1.40D0, 1.35D0, 1.40D0, 1.40D0, 1.40D0, 1.35D0, &
   ! Ni       Cu       Zn       Ga       Ge       As       Se       Br       Kr*
   1.35D0, 1.35D0, 1.35D0, 1.30D0, 1.25D0, 1.15D0, 1.15D0, 1.15D0, 1.10D0, &
   ! Rb       Sr       Y        Zr       Nb       Mo       Tc       Ru       Rh
   2.35D0, 2.00D0, 1.80D0, 1.55D0, 1.45D0, 1.45D0, 1.35D0, 1.30D0, 1.35D0, &
   ! Pd       Ag       Cd       In       Sn       Sb       Te       I        Xe*
   1.40D0, 1.60D0, 1.55D0, 1.55D0, 1.45D0, 1.45D0, 1.40D0, 1.40D0, 1.40D0, &
   ! Cs       Ba       La
   2.60D0, 2.15D0, 1.95D0, &
   ! Ce       Pr       Nd       Pm       Sm       Eu       Gd
   1.85D0, 1.85D0, 1.85D0, 1.85D0, 1.85D0, 1.85D0, 1.80D0, &
   ! Tb       Dy       Ho       Er       Tm       Yb       Lu
   1.75D0, 1.75D0, 1.75D0, 1.75D0, 1.75D0, 1.75D0, 1.75D0, &
   ! Hf       period     W        Re       Os       Ir       Pt       Au       Hg
   1.55D0, 1.45D0, 1.35D0, 1.30D0, 1.30D0, 1.35D0, 1.35D0, 1.35D0, 1.50D0, &
   ! Tl       Pb*      Bi       Po       At*      Rn*
   1.90D0, 1.75D0, 1.60D0, 1.90D0, 1.50D0, 1.50D0, &
   ! Fr*      Ra       Ac
   2.15D0, 2.15D0, 1.95D0, &
   ! rad(U): 1.75D0 --> 1.37D0D0
   !  Th       Pa       U        Np       Pu       Am       Cm*
   1.80D0, 1.80D0, 1.37D0, 1.75D0, 1.75D0, 1.75D0, 1.75D0, &
   ! Bk*      Cf*      Es*      Fm*      Md*      No*      Lw*
   1.75D0, 1.75D0, 1.75D0, 1.75D0, 1.75D0, 1.75D0, 1.75D0]


contains


end module bragg_radii_info

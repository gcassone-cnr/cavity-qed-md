

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module gauss_chebyshev_class
   !!
   !! Gauss_chebyshev class
   !! Written by Marco Scavino, June 2019
   !!
   !! Gauss-Chebyshev quadrature of second order as proposed by
   !! J. Chem. Phys. 108, 3226 (1998)
   !!
   use kinds
   use parameters
   use radial_quadrature_class, only: radial_quadrature
   use atom_grid_class, only: atom_grid

   use global_out, only: output

   implicit none

   type, extends(radial_quadrature) :: gauss_chebyshev

   contains

      procedure :: build => build_gauss_chebyshev

   end type

   interface gauss_chebyshev
      procedure :: new_gauss_chebyshev
   end interface

contains

   function new_gauss_chebyshev(threshold) result(this)
      !!
      !! Written by Marco Scavino, June 2019
      !!
      implicit none

      type(gauss_chebyshev) :: this
      real(dp) :: threshold

      this%description_ = "Gauss-Chebyshev radial quadrature of 2-nd order"

      this%threshold = threshold
      if (threshold < zero) call output%error_msg('Gauss-Chebyshev Quadrature: Threshold is < zero.')

   end function new_gauss_chebyshev


   subroutine build_gauss_chebyshev(this, grid)
      !!
      !! Written by Marco Scavino, June 2019
      !!
      !! Gauss-Chebyshev radial quadrature of second kind that we use to generate
      !! the radial grid. Requested number of points is in grid%radial_points.
      !! The grid%radial and grid%weight arrays are filled up.
      !!
      !! J. Chem. Phys. 108, 3226 (1998), equations (9), (10) and (11)
      !!
      !! x_i = ((n+1)-2)/(n+1) + 2/pi*(1+2/3*sin**2(ipi/(n+1)))
      !!      *cos(ipi/(n+1))*sin(ipi/(n+1))                       ( 9)
      !! w_i = 16/(3(n+1))*sin**4(ipi/(n+1))                        (10)
      !!
      !! To convert the x in [-1, 1] to r in [0, inf) we use the following parameter-free scale
      !!
      !! r(x_i) = 1/ln(2) * ln(2/(1-x_i)) = 1 - ln(1-x_i)/ln(2)  (11)
      !!
      implicit none

      class(gauss_chebyshev), intent(inout) :: this
      class(atom_grid), intent(inout) :: grid

      real(dp), parameter :: pi_2 = two / pi  ! 2/pi
      real(dp), parameter :: f23 = two / three  ! 2/3
      real(dp), parameter :: r_const = one / log(two)  ! 1/ln(2)
      real(dp) :: n_one, pi_n_one, w_const

      real(dp) :: x, angle, weight
      real(dp) :: sin_angle, sin_angle_2
      integer :: i, n_points

      n_points = this%radial_count(grid%Z)

      call grid%set_radial(n_points)

      n_one = real(grid%radial_points, dp) + one
      pi_n_one = pi / n_one  ! pi/(n+1)

      w_const = sixteen / (three * n_one)

      !$omp parallel do private(i, angle, sin_angle, sin_angle_2, x, weight)
      do i = 1, n_points

         angle = i * pi_n_one

         sin_angle = sin(angle)
         sin_angle_2 = sin_angle**2

         ! equation (9)
         x = one - two * i / n_one + pi_2 * (one + f23 * sin_angle_2) * cos(angle) * sin_angle

         ! Apply the equation (11) to scale
         grid%radial(i) = one - r_const * log(one - x)

         ! equation (10)
         weight = w_const * sin_angle_2 * sin_angle_2

         ! convert to spherical coords
         ! w_r = w_x * dr/dx * r**2

         grid%weight(i) = weight * r_const / (one - x) * grid%radial(i)**2

      end do
      !$omp end parallel do

   end subroutine build_gauss_chebyshev

end module

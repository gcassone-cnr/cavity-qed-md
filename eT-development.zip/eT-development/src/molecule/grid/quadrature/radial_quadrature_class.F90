

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module radial_quadrature_class
   !!
   !! Radial quadrature class
   !! Written by Marco Scavino, June 2019
   !!
   !! This class contains the inteface for the radial quadrature.
   !! J. Chem. Phys. 108, 3226 (1998)
   !!
   use parameters
   use atom_grid_class, only: atom_grid
   use global_out, only: output

   implicit none

   type, abstract :: radial_quadrature

      character(len=200) :: description_
      real(dp) :: threshold = 1.0E-6_dp

   contains

      procedure :: print_settings => print_settings_radial_quadrature
      procedure :: radial_count => radial_count_radial_quadrature

      procedure(build_radial_quadrature), deferred :: build

   end type

   abstract interface

      subroutine build_radial_quadrature(this, grid)

         import :: radial_quadrature, atom_grid

         implicit none

         class(radial_quadrature), intent(inout) :: this
         class(atom_grid), intent(inout) :: grid

      end subroutine

   end interface

contains


   function radial_count_radial_quadrature(quadrature, Z) result(n_points)
      !!
      !! Written by Marco Scavino, June 2019
      !!
      !! determinates number of radial points to be used for
      !! Gauss-Chebyshev radial quadrature of second kind needed to integrate atom
      !! of specified Z number to specified threshold epsilon_grid.
      !! the ordinary weights are multiplied by r^2
      !!
      !! J. Chem. Phys. 108, 3226 (1998), equations (13)
      !!
      implicit none

      class(radial_quadrature), intent(in) :: quadrature
      integer, intent(in) :: Z

      integer, parameter :: MIN_RADIAL_POINTS = 20
      integer :: period, n_points

      ! get the element period

      select case (Z)
         case (:2)
            period = 0
         case (3:10)
            period = 1
         case (11:18)
            period = 2
         case (19:36)
            period = 3
         case (37:54)
            period = 4
         case (55:86)
            period = 5
         case default
            period = 6
      end select

      ! n_A^r = max(20,-5*(3*log10(epsilon_grid)-t_A+8))

      n_points = nint(- five * (three * log10(quadrature%threshold) - period + eight))

      n_points = max(n_points, MIN_RADIAL_POINTS)

   end function radial_count_radial_quadrature


   subroutine print_settings_radial_quadrature(quadrature)
      !!
      !! Written by Marco Scavino, June 2019
      !!
      implicit none

      class(radial_quadrature), intent(in) :: quadrature

      call output%printf('n', 'Quadrature:   ' // trim(quadrature%description_), fs='(t6,a)')
      call output%printf('n', 'Threshold:    (e10.4)', reals=[quadrature%threshold], fs='(t6,a)')

   end subroutine print_settings_radial_quadrature


end module

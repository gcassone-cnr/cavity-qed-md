

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module treutler_ahlrichs_class
   !!
   !! Treutler Ahlrichs quadrature
   !! Written by Marco Scavino, June 2019
   !!
   !! Treutler-Ahlrichs quadrature as proposed by
   !! J. Chem. Phys. 102, 346 (1995)
   !!
   use kinds
   use parameters
   use radial_quadrature_class, only: radial_quadrature
   use atom_grid_class, only: atom_grid

   use global_out, only: output

   implicit none

   type, extends(radial_quadrature) :: treutler_ahlrichs

   contains

      procedure :: build => build_treutler_ahlrichs

   end type

   interface treutler_ahlrichs
      procedure :: new_treutler_ahlrichs
   end interface

   real(dp), dimension(0:36), parameter, private :: xi_vals = [ &
   ! xi values
   ! dummy
   0.8_dp, &
   ! H,                                                                                                     He,
   0.8_dp, 0.9_dp, &
   ! Li,     Be,                                                      B,      C,      N,      O,      F,     Ne,
   1.8_dp, 1.4_dp, 1.3_dp, 1.1_dp, 0.9_dp, 0.9_dp, 0.9_dp, 0.9_dp, &
   ! Na,     Mg,                                                     Al,     Si,      P,      S,     Cl,     Ar,
   1.4_dp, 1.3_dp, 1.3_dp, 1.2_dp, 1.1_dp, 1.0_dp, 1.0_dp, 1.0_dp, &
   ! K,     Ca,     Sc,     Ti,      V,     Cr,     Mn,     Fe,     Co,     Ni,     Cu,     Zn,     Ga,     Ge,
   1.5_dp, 1.4_dp, 1.3_dp, 1.2_dp, 1.2_dp, 1.2_dp, 1.2_dp, 1.2_dp, 1.2_dp, 1.1_dp, 1.1_dp, 1.1_dp, 1.1_dp, &
      1.0_dp, &
   ! As,     Se,     Br,     Kr,
   0.9_dp, 0.9_dp, 0.9_dp, 0.9_dp]

contains

   function new_treutler_ahlrichs(threshold) result(this)
      !!
      !! Written by Marco Scavino, June 2019
      !!
      implicit none

      real(dp), intent(in) :: threshold

      type(treutler_ahlrichs) :: this

      this%description_ = "Treutler-Ahlrichs radial quadrature"

      this%threshold = threshold
      if (threshold < zero) call output%error_msg('Treutler and Ahlrichs Quadrature: Threshold is < zero.')

   end function new_treutler_ahlrichs


   subroutine build_treutler_ahlrichs(this, grid)
      !!
      !! Written by Marco Scavino, Apr 2021
      !!
      !! Treutler and Ahlrichs radial quadrature of second kind that we use to generate
      !! the radial grid. Requested number of points is in grid%radial_points.
      !! The grid%radial and grid%weight arrays are filled up.
      !!
      !! J. Chem. Phys. 108, 3226 (1998), equations (9), (10) and (11)
      !!
      !! x_i = ((n+1)-2)/(n+1) + 2/pi*(1+2/3*sin**2(ipi/(n+1)))
      !!      *cos(ipi/(n+1))*sin(ipi/(n+1))                       ( 9)
      !! w_i = 16/(3(n+1))*sin**4(ipi/(n+1))                        (10)
      !!
      !! To convert the x in [-1, 1] to r in [0, inf) we use the following parameter scale
      !! denoted as M4 by the article (with alpha = 0.6)
      !!
      !! r(x_i) = (xi)/(ln 2) (a + x)^alpha  ln((a+1)/(1-x))
      !!
      !! a = 0, if 0 <= x <= 1
      !! a = 1, if -1 <= x < 0
      !!
      implicit none

      class(treutler_ahlrichs), intent(inout) :: this
      class(atom_grid), intent(inout) :: grid

      real(dp), parameter :: pi_2 = two / pi  ! 2/pi
      real(dp), parameter :: f23 = two / three  ! 2/3
      real(dp), parameter :: ln_2 = one / log(two)  ! 1/ln(2)
      real(dp), parameter :: alpha = 0.6_dp
      real(dp) :: n_one, pi_n_one, w_const

      real(dp) :: x, angle, w_x, r, dr
      real(dp) :: xi, one_x, log_x
      integer :: i, n_points

      n_points = this%radial_count(grid%Z)
      call grid%set_radial(n_points)

      n_one = real(grid%radial_points, dp) + one
      pi_n_one = pi / n_one  ! pi/(n+1)
      w_x = pi / n_one

      w_const = 16.0_dp / (three * n_one)

      !$omp parallel do private(i, xi, angle, x, one_x, log_x, r, dr)
      do i = 1, grid%radial_points

         xi = xi_vals(grid%Z)
         angle = i * pi_n_one

         x = cos(angle)

         one_x = (one + x)**alpha
         log_x = log(half * (one - x))

         ! Equation (19) and derivative wrt x

         r = - (xi * ln_2) * one_x * log_x
         dr = (xi * ln_2) * one_x * (- alpha / (one + x) * log_x + one / (one - x))

         ! convert to spherical coords
         ! w_r = w_x * dr/dx * r**2

         grid%weight(i) = w_x * sin(angle) * dr * r * r

         grid%radial(i) = r

      end do
      !$omp end parallel do

   end subroutine build_treutler_ahlrichs

end module

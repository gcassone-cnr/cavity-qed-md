

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module periodic_table

   !!
   !! Periodic table module
   !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2018
   !! Extended from Z=20 to Z=118 by Susi Lehtola, 2020
   !!
   use kinds

   implicit none

   integer, parameter :: size_periodic_table = 118
   character(len = 2), dimension(size_periodic_table) :: atomic_symbol = &
      ['H ', 'He', 'Li', 'Be', 'B ', 'C ', 'N ', 'O ', 'F ', 'Ne', 'Na', 'Mg', 'Al', 'Si', 'P ', 'S ', 'Cl', &
      'Ar', 'K ', 'Ca', 'Sc', 'Ti', 'V ', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn', 'Ga', 'Ge', 'As', 'Se', &
      'Br', 'Kr', 'Rb', 'Sr', 'Y ', 'Zr', 'Nb', 'Mo', 'Tc', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd', 'In', 'Sn', 'Sb', &
      'Te', 'I ', 'Xe', 'Cs', 'Ba', 'La', 'Ce', 'Pr', 'Nd', 'Pm', 'Sm', 'Eu', 'Gd', 'Tb', 'Dy', 'Ho', 'Er', &
      'Tm', 'Yb', 'Lu', 'Hf', 'Ta', 'W ', 'Re', 'Os', 'Ir', 'Pt', 'Au', 'Hg', 'Tl', 'Pb', 'Bi', 'Po', 'At', &
      'Rn', 'Fr', 'Ra', 'Ac', 'Th', 'Pa', 'U ', 'Np', 'Pu', 'Am', 'Cm', 'Bk', 'Cf', 'Es', 'Fm', 'Md', 'No', &
      'Lr', 'Rf', 'Db', 'Sg', 'Bh', 'Hs', 'Mt', 'Ds', 'Rg', 'Cn', 'Nh', 'Fl', 'Mc', 'Lv', 'Ts', 'Og']

   real(dp), dimension(112), parameter :: atomic_mass = &
      [1.00797, 4.00260, 6.941, 9.01218, 10.81, 12.011, 14.0067, 15.9994, 18.998403, 20.179, 22.98977, &
      24.305, 26.98154, 28.0855, 30.97376, 32.06, 35.453, 39.0983, 39.948, 40.08, 44.9559, 47.90, 50.9415, &
      51.996, 54.9380, 55.847, 58.70, 58.9332, 63.546, 65.38, 69.72, 72.59, 74.9216, 78.96, 79.904, 83.80, &
      85.4678, 87.62, 88.9059, 91.22, 92.9064, 95.94, 98.0, 101.07, 102.9055, 106.4, 107.868, 112.41, &
      114.82, 118.69, 121.75, 126.9045, 127.60, 131.30, 132.9054, 137.33, 138.9055, 140.12, 140.9077, &
      144.24, 145.0, 150.4, 151.96, 157.25, 158.9254, 162.50, 164.9304, 167.26, 168.9342, 173.04, 174.967, &
      178.49, 180.9479, 183.85, 186.207, 190.2, 192.22, 195.09, 196.9665, 200.59, 204.37, 207.2, 208.9804, &
      209.0, 210.0, 222.0, 223.0, 226.0254, 227.0278, 231.0359, 232.0381, 237.0482, 238.029, 242.0, 243.0, &
      247.0, 247.0, 250.0, 251.0, 252.0, 255.0, 256.0, 257.0, 258.0, 260.0, 261.0, 262.0, 262.0, 263.0, &
      269.0, 272.0, 277.0]

end module periodic_table



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module scf_solver_class

   !!
   !! Self-consistent field solver class module
   !! Written by Eirik F. Kjoenstad, Sarai D. Folkestad,
   !! Rosario R. Riso and Alexander C. Paul, 2018-2022
   !!
   !! Determines the wave function parameters self consistently
   !! such that the norm of the residual is lower than a
   !! given residual threshold and the change in the objective
   !! number is lower than a given objective threshold
   !!
   !! norm(residual) < residual_threshold
   !! \Delta objective < objective_threshold
   !!
   !! The equations are solved by
   !!
   !! 1. Setting an initial guess for the parameters
   !!
   !! --------- ITERATIVE LOOP ----------
   !!
   !! 2. Constructing the parameters to interpolate on
   !!    and computing the residual
   !!
   !! 3. Performing a convergence test on the residual
   !!
   !! 4. Extrapolating a new set of parameters from the
   !!    residual (convergence acceleration)
   !!
   !! 5. Updating the parameters
   !!
   !! -----------------------------------
   !!
   !! For HF related methods, the objective is the system energy
   !! and residual is the energy gradient with respect to the
   !! wave function parameters
   !!

   use parameters

   use abstract_solver_class, only: abstract_solver

   use memory_manager_class, only: mem
   use timings_class, only: timings
   use iteration_timings_class, only: iteration_timings
   use global_out, only: output

   use accelerator_tool_class, only: accelerator_tool
   use convergence_tool_class, only: convergence_tool
   use vector_getter_class, only: vector_getter
   use abstract_value_getter_class, only: abstract_value_getter
   use scf_print_tool_class, only: scf_print_tool
   use abstract_hf_parameter_updater_class, only: abstract_hf_parameter_updater

   implicit none

   type, extends(abstract_solver) :: scf_solver

      logical, private :: skip
      integer, private :: max_iterations
      integer, private :: n_parameters
      integer, private :: residual_dimension

      class(accelerator_tool), allocatable, private :: accelerator
      class(vector_getter), allocatable, private :: parameter_getter
      class(vector_getter), allocatable, private :: residual_getter
      class(abstract_value_getter), allocatable, private :: objective_getter
      class(abstract_hf_parameter_updater), allocatable, private :: parameter_updater
      class(scf_print_tool), allocatable, private :: printer
      class(convergence_tool), allocatable, private :: convergence_checker

   contains

      procedure :: run => run_scf_solver

      procedure :: check_and_print_convergence

      procedure, private :: skip_solver => skip_solver_scf_solver

   end type scf_solver

   interface scf_solver

      procedure :: new_scf_solver

   end interface scf_solver


contains

   function new_scf_solver(parameter_updater, &
                           accelerator, &
                           convergence_checker, &
                           parameter_getter, &
                           residual_getter, &
                           objective_getter, &
                           printer, &
                           skip, &
                           n_parameters, &
                           residual_dimension, &
                           max_iterations) result(this)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, 2022
      !!
      implicit none

      type(scf_solver) :: this
      class(abstract_hf_parameter_updater), intent(in) :: parameter_updater
      class(accelerator_tool), intent(in) :: accelerator
      type(convergence_tool), intent(in) :: convergence_checker
      class(vector_getter), intent(in) :: parameter_getter
      class(vector_getter), intent(in) :: residual_getter
      class(abstract_value_getter), intent(in) :: objective_getter
      class(scf_print_tool), intent(in) :: printer

      logical, intent(in) :: skip
      integer, intent(in) :: n_parameters
      integer, intent(in) :: residual_dimension
      integer, intent(in) :: max_iterations

      this%max_iterations = max_iterations
      this%skip = skip
      this%n_parameters = n_parameters
      this%residual_dimension = residual_dimension

      this%convergence_checker = convergence_checker
      this%parameter_getter = parameter_getter
      this%residual_getter = residual_getter
      this%objective_getter = objective_getter
      this%parameter_updater = parameter_updater
      this%accelerator = accelerator
      this%printer = printer

      call this%printer%print_banner()
      call this%printer%print_settings(this%max_iterations)
      call this%convergence_checker%print_settings()
      call this%accelerator%print_settings()

   end function new_scf_solver


   subroutine run_scf_solver(this)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018-2020
      !!
      use array_utilities, only: get_abs_max

      implicit none

      class(scf_solver), intent(inout) :: this

      logical :: converged
      real(dp) :: objective, previous_objective, max_residual
      integer :: iteration

      real(dp), dimension(:), allocatable :: parameters, residual

      type(timings) :: timer
      type(iteration_timings) :: iteration_timer

      timer = timings('SCF solver', pl='normal')
      call timer%turn_on()

      if (this%n_parameters == 1) return

      if (this%skip) then

         call this%skip_solver()
         call timer%turn_off()
         return

      end if

      call this%accelerator%initialize()

      converged = .false.
      iteration = 0
      objective = zero

      call mem%alloc(parameters, this%n_parameters)
      call mem%alloc(residual, this%residual_dimension)

      call this%printer%print_iteration_banner()

      iteration_timer = iteration_timings('SCF iteration', pl='normal')

      do while ((.not. converged) .and. (iteration < this%max_iterations))

         call iteration_timer%turn_on()

         iteration = iteration + 1

         call this%parameter_getter%get(parameters)
         call this%residual_getter%get(residual)

         previous_objective = objective
         objective = this%objective_getter%get()
         max_residual = get_abs_max(residual, this%residual_dimension)

         converged = this%convergence_checker%has_converged(max_residual, &
                                                            objective - previous_objective, &
                                                            iteration)

         call this%printer%print_iteration(iteration, objective, previous_objective, max_residual)

         if (.not. converged) then

            call this%accelerator%do_(parameters, residual)

            call this%parameter_updater%update(parameters)

         end if

         call iteration_timer%turn_off()

      end do

      call this%check_and_print_convergence(iteration, converged)

      call mem%dealloc(parameters)
      call mem%dealloc(residual)

      call this%accelerator%finalize()

      call timer%turn_off()

   end subroutine run_scf_solver


   subroutine check_and_print_convergence(this, iteration, converged)
      !!
      !! Written by Sarai D. Folkestad, Nov 2022
      !!

      use global_out, only: output

      implicit none

      class(scf_solver), intent(in) :: this
      integer, intent(in) :: iteration
      logical, intent(in) :: converged

      if (converged) then
         call this%printer%print_summary(iteration)
      else

         call output%error_msg( &
                 "Did not converge in the max number of iterations in SCF solver." &
              )

      end if

   end subroutine check_and_print_convergence


   subroutine skip_solver_scf_solver(this)
      !!
      !! Written by Sarai D. Folkestad.
      !!
      !! Prints energy and maximal gradient element when solver is skipped.
      !!
      use array_utilities, only: get_abs_max

      implicit none

      class(scf_solver), intent(inout) :: this

      real(dp) :: objective, max_residual
      real(dp), dimension(:), allocatable :: residual

      call output%warning_msg('skipping SCF solver!')

      call mem%alloc(residual, this%residual_dimension)
      call this%residual_getter%get(residual)

      objective = this%objective_getter%get()
      max_residual = get_abs_max(residual, this%residual_dimension)

      call mem%dealloc(residual)

      call this%printer%print_iteration_banner()

      call this%printer%print_iteration(iteration=1, &
                                        energy=objective, &
                                        previous_energy=zero, &
                                        max_residual=max_residual)

      call this%check_and_print_convergence(iteration=1, converged=.true.)

   end subroutine skip_solver_scf_solver


end module scf_solver_class

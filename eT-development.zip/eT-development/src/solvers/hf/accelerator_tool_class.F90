

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module accelerator_tool_class

   !!
   !! Accelerator tool
   !! Written by Sarai D. Folkestad, 2020-2021
   !!
   !! Abstract class for handling of convergence acceleration to solve equations
   !!

   use parameters

   implicit none

   type, abstract :: accelerator_tool

      integer :: x_dimension
      integer :: e_dimension

   contains

      procedure(initialize_finalize), deferred :: initialize
      procedure(print_settings), deferred :: print_settings
      procedure(do_), deferred :: do_
      procedure(initialize_finalize), deferred :: finalize

   end type accelerator_tool

   abstract interface

      subroutine do_(this, x, e)

         use kinds
         import accelerator_tool

         implicit none

         class(accelerator_tool), intent(inout) :: this
         real(dp), dimension(this%x_dimension), intent(inout) :: x
         real(dp), dimension(this%e_dimension), intent(in) :: e

      end subroutine do_


      subroutine initialize_finalize(this)

         import accelerator_tool

         implicit none

         class(accelerator_tool), intent(inout) :: this

      end subroutine initialize_finalize


      subroutine print_settings(this)

         import accelerator_tool

         implicit none

         class(accelerator_tool), intent(in) :: this

      end subroutine print_settings

   end interface

end module accelerator_tool_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module trust_region_solver_class

   !!
   !! Trust Region solver class
   !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
   !!

   use parameters
   use timings_class, only: timings
   use memory_manager_class, only: mem
   use global_out, only: output

   use abstract_solver_class, only: abstract_solver
   use convergence_tool_class, only: convergence_tool
   use parameters_tool_class, only: parameters_tool
   use abstract_value_getter_class, only: abstract_value_getter
   use trust_region_micro_solver_class, only: trust_region_micro_solver
   use transformation_class, only: transformation
   use vector_getter_class, only: vector_getter
   use trust_region_print_tool_class, only: trust_region_print_tool
   use abstract_projection_tool_class, only: abstract_projection_tool

   implicit none

   type, extends(abstract_solver) :: trust_region_solver

      logical, private :: records_in_memory

      integer, private :: max_iterations
      integer, private :: n_parameters
      real(dp) :: step_size_max, step_size_min

      class(convergence_tool), allocatable :: convergence_checker
      class(parameters_tool), allocatable :: parameters
      class(transformation), allocatable :: transformer
      class(abstract_value_getter), allocatable :: functional_getter
      class(vector_getter), allocatable :: gradient_getter
      class(vector_getter), allocatable :: preconditioner_getter
      class(trust_region_print_tool), allocatable :: printer
      class(abstract_projection_tool), allocatable :: projector


   contains

      procedure, public :: run => run_trust_region_solver

      procedure, private :: run_micro_iteration
      procedure, private :: get_predicted_energy_difference
      procedure, private :: update_step_size
      procedure, private :: line_search

   end type trust_region_solver

   interface trust_region_solver

      procedure :: new_trust_region_solver

   end interface trust_region_solver

contains

   function new_trust_region_solver(convergence_checker, &
                                    parameters, &
                                    gradient_getter, &
                                    functional_getter, &
                                    transformer, &
                                    preconditioner_getter, &
                                    printer, &
                                    projector, &
                                    max_iterations, &
                                    n_parameters) result(this)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      implicit none

      type(trust_region_solver) :: this

      type(convergence_tool), intent(in) :: convergence_checker
      class(parameters_tool), intent(in) :: parameters
      class(vector_getter), intent(in) :: gradient_getter
      class(abstract_value_getter), intent(in) :: functional_getter
      class(transformation), intent(in) :: transformer
      class(vector_getter), intent(in) :: preconditioner_getter
      class(trust_region_print_tool), intent(in) :: printer
      class(abstract_projection_tool), intent(in) :: projector

      integer, intent(in) :: max_iterations
      integer, intent(in) :: n_parameters

      this%convergence_checker = convergence_checker
      this%parameters = parameters
      this%gradient_getter = gradient_getter
      this%functional_getter = functional_getter
      this%transformer = transformer
      this%preconditioner_getter = preconditioner_getter
      this%printer = printer
      this%projector = projector
      this%max_iterations = max_iterations
      this%n_parameters = n_parameters
      this%step_size_max = pi / four
      this%step_size_min = 1.0D-4
      this%records_in_memory = .false.

   end function new_trust_region_solver


   subroutine run_trust_region_solver(this)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      use array_utilities, only: get_abs_max
      implicit none

      class(trust_region_solver), intent(inout) :: this

      logical :: converged, step_rejected, converged_micro

      integer :: macro_iteration, n_micro

      real(dp) :: previous_functional_value, functional_value, new_functional_value
      real(dp) :: max_gradient, step_size, difference_predicted
      real(dp), dimension(1) :: level_shift

      real(dp), dimension(:), allocatable :: minus_gradient
      real(dp), dimension(:), allocatable :: X

      converged = .false.
      converged_micro = .false.
      macro_iteration = 0
      n_micro = 0
      functional_value = this%functional_getter%get()
      previous_functional_value = zero
      step_size = pi / four
      difference_predicted = zero
      level_shift = zero

      call mem%alloc(minus_gradient, this%n_parameters)
      call mem%alloc(X, this%n_parameters, set_zero=.true.)

      call this%printer%print_settings()
      call this%convergence_checker%print_settings()

      call this%printer%print_macro_iteration_heading()

      do while ((.not. converged) .and. (macro_iteration < this%max_iterations))

         macro_iteration = macro_iteration + 1

         call this%gradient_getter%get(minus_gradient)
         call dscal(this%n_parameters, - one, minus_gradient, 1)

         max_gradient = get_abs_max(minus_gradient, this%n_parameters)

         converged = this%convergence_checker%has_converged(max_gradient, &
                                                            functional_value - previous_functional_value, &
                                                            macro_iteration)

         call this%printer%print_macro_iteration(macro_iteration, &
                                                 step_size, &
                                                 functional_value, &
                                                 previous_functional_value, &
                                                 max_gradient, &
                                                 n_micro, &
                                                 level_shift)

         if (.not. converged) then


            call this%run_micro_iteration(step_size, &
                                          minus_gradient, &
                                          X, &
                                          max_gradient, &
                                          converged_micro, &
                                          n_micro, &
                                          level_shift)

            if (converged_micro) then

               call this%parameters%set(X)
               new_functional_value = this%functional_getter%get()

               call this%update_step_size(step_size, &
                                          functional_value, &
                                          new_functional_value, &
                                          difference_predicted, &
                                          step_rejected)

               if (step_rejected) then
                  call this%parameters%set(- X)

                  call output%printf('m', &
                                     'Step rejected, resetting the step length (step_size)', &
                                     fs='(/t3, a)')

               else
                  call this%line_search(X, new_functional_value)
                  previous_functional_value = functional_value
                  functional_value = new_functional_value
               end if

               difference_predicted = this%get_predicted_energy_difference(minus_gradient, X)

            else

               step_size = step_size * 0.7

            end if

            if (step_size < this%step_size_min) then

               call output%error_msg('Step size in trust-region solver is too small ((e12.4))', &
                                     reals=[step_size])

            end if

         end if

      end do

      call mem%dealloc(X)
      call this%printer%print_summary(macro_iteration, converged)

      call mem%dealloc(minus_gradient)

   end subroutine run_trust_region_solver


   subroutine run_micro_iteration(this, &
                                  step_size, &
                                  minus_gradient, &
                                  X, &
                                  max_gradient, &
                                  converged_micro, &
                                  n_micro_iterations, &
                                  level_shift)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      use normalized_start_vector_tool_class, only: normalized_start_vector_tool
      use vector_copy_getter_class, only: vector_copy_getter
      use null_linear_storage_tool_class, only: null_linear_storage_tool
      use trust_region_micro_iterations_print_tool_class, only: trust_region_micro_iterations_print_tool

      implicit none

      class(trust_region_solver), intent(in) :: this

      class(trust_region_micro_solver), allocatable :: davidson_solver
      class(null_linear_storage_tool), allocatable :: storer
      class(vector_getter), allocatable :: rhs_getter
      class(vector_getter), allocatable :: start_vector
      class(trust_region_micro_iterations_print_tool), allocatable :: printer
      type(convergence_tool), allocatable :: micro_convergence_checker

      integer, intent(out) :: n_micro_iterations
      real(dp), intent(inout) :: step_size
      real(dp), intent(in) :: max_gradient

      real(dp), dimension(1), intent(out) :: level_shift

      real(dp), dimension(this%n_parameters), intent(in) :: minus_gradient
      real(dp), dimension(this%n_parameters), intent(inout) :: X

      type(timings) :: micro_iteration_time
      character(len=40) :: timer_name_micro

      logical, intent(out) :: converged_micro

      ! Mute prints for settings of micro iteration solver and its tools

      call output%mute()

      write(timer_name_micro, '(a,i0)')'Trust region solver: micro iteration '
      micro_iteration_time = timings(trim(timer_name_micro), pl="n")
      call micro_iteration_time%turn_on()

      start_vector = normalized_start_vector_tool(this%n_parameters, 1, minus_gradient)
      rhs_getter = vector_copy_getter(this%n_parameters, 1, minus_gradient)
      storer = null_linear_storage_tool()
      printer = trust_region_micro_iterations_print_tool(print_level='v')

      micro_convergence_checker = convergence_tool(1.0D-2 * max_gradient)
      davidson_solver = trust_region_micro_solver(transformer=this%transformer, &
                                                  convergence_checker=micro_convergence_checker, &
                                                  storer=storer, &
                                                  preconditioner_getter=this%preconditioner_getter, &
                                                  rhs_getter=rhs_getter, &
                                                  printer=printer, &
                                                  projector=this%projector, &
                                                  n_parameters=this%n_parameters, &
                                                  max_iterations=50, &
                                                  linear_dependence_threshold=1.0D-11, &
                                                  max_reduced_dimension=30, &
                                                  start_vector=start_vector, &
                                                  step_size=step_size)

      call output%unmute()

      ! Mute micro iterations

      call davidson_solver%run()

      n_micro_iterations = davidson_solver%iteration

      converged_micro = davidson_solver%has_converged

      call davidson_solver%get_solution(X, 1)

      level_shift = davidson_solver%get_level_shift()

      call davidson_solver%cleanup()

      call micro_iteration_time%turn_off()
      call micro_iteration_time%reset()

   end subroutine run_micro_iteration


   function get_predicted_energy_difference(this, minus_gradient, X) result(difference_predicted)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      !! Calculate predicted functional value according to
      !! difference_predicted = X^T * gradient + 1/2 * X^T * step_size * X = X * Y and
      !! Y = gradient + 1/2 * HX
      !!
      use array_initialization, only: copy_and_scale

      implicit none

      class(trust_region_solver), intent(in) :: this

      real(dp) :: ddot
      real(dp) :: difference_predicted

      real(dp), dimension(this%n_parameters), intent(in) :: minus_gradient, X

      real(dp), dimension(:), allocatable :: HX, Y

      call mem%alloc(HX, this%n_parameters)
      call mem%alloc(Y, this%n_parameters)

      call this%transformer%transform(X, HX)

      call copy_and_scale(- one, minus_gradient, Y, this%n_parameters)
      call daxpy(this%n_parameters, one / two, HX, 1, Y, 1)

      difference_predicted = ddot(this%n_parameters, X, 1, Y, 1)

      call mem%dealloc(HX)
      call mem%dealloc(Y)

   end function get_predicted_energy_difference


   subroutine update_step_size(this, &
                               step_size, &
                               previous_functional_value, &
                               functional_value, &
                               difference_predicted, &
                               step_rejected)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      !! Calculates the following ratio:
      !! ratio = (functional value - previous functional value)/difference predicted, where
      !! difference_predicted = X^T  gradient + 1/2  X^T  step_size  X = X * Y and
      !! Y = gradient + 1/2 * HX
      !!
      !! S. original publication J. Chem. Phys. 129, 124106
      !!
      implicit none

      class(trust_region_solver), intent(in) :: this

      real(dp), intent(inout) :: step_size
      real(dp), intent(in) :: functional_value, previous_functional_value, difference_predicted
      real(dp) :: ratio, difference

      logical, intent(out) :: step_rejected

      difference = (functional_value - previous_functional_value)

      step_rejected = .false.

      if (difference > 1.0d-12) then

         step_rejected = .true.
         step_size = 0.7d0 * step_size
         return

      else if ((abs(difference)) <= 1.0d-12) then
         return
      end if

      if (abs(difference_predicted) > 1.0d-8) then

         ratio = difference / difference_predicted

         if (ratio > three * quarter) then
            step_size = min(1.2d0 * step_size, this%step_size_max)
         else if (ratio < three * quarter .and. ratio > quarter) then
            step_size = step_size
         else if (ratio < quarter .and. ratio > zero) then
            step_size = 0.7d0 * step_size
         else if (ratio < zero) then
            step_size = 0.7d0 * step_size
            step_rejected = .true.
         end if

      end if

   end subroutine update_step_size


   subroutine line_search(this, X, functional_value)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Nov 2021
      !!
      !! Performes a line-search in the direction determined by the micro-iterations
      !! by applying the transformation C = C exp(kappa) several times, each time
      !! confirming that the functional value decreases
      !!
      implicit none

      class(trust_region_solver), intent(inout) :: this
      real(dp), dimension(this%n_parameters), intent(in) :: X
      real(dp), intent(inout) :: functional_value

      integer :: i

      real(dp) :: current_functional_value, previous_functional_value

      previous_functional_value = functional_value

      do i = 1, 10

         call this%parameters%set(X)

         current_functional_value = this%functional_getter%get()

         if ((current_functional_value - previous_functional_value) > - 1.0d-8) then
            call this%parameters%set(- X)
            exit
         end if

         previous_functional_value = current_functional_value

      end do

      functional_value = previous_functional_value

   end subroutine line_search


end module trust_region_solver_class

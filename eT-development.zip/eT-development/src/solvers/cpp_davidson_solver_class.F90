

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cpp_davidson_solver_class

   !!
   !! CPP Davidson solver
   !! Written by Anna Kristina Schnack-Pedersen, Torsha Moitra, and Sarai D. Folkestad, 2023-2024
   !!
   !! Solves [A - (omega + i gamma)I]x = g
   !! using the strategy outlined in J. Chem. Phys. 139, 211102 (2013)
   !!
   !! The reduced space equation is solved as described in
   !! J. Chem. Phys. 139, 211102 (2013), or with "residual minimization",
   !! as described in the SI of 10.26434/chemrxiv-2023-dgbdz.
   !!

   use parameters
   use memory_manager_class, only: mem
   use timings_class, only: timings
   use iteration_timings_class, only: iteration_timings

   use transformation_class, only: transformation
   use vector_getter_class, only: vector_getter
   use abstract_projection_tool_class, only: abstract_projection_tool
   use cpp_print_tool_class, only: cpp_print_tool
   use linear_equation_storage_tool_class, only: linear_equation_storage_tool

   use abstract_davidson_solver_class, only: abstract_davidson_solver

   use convergence_tool_class, only: convergence_tool
   use reduced_matrix_maker_class, only: reduced_matrix_maker
   use reduced_overlap_maker_class, only: reduced_overlap_maker
   use reduced_vector_maker_class, only: reduced_vector_maker
   use reduced_space_class, only: reduced_space
   use full_space_vector_maker_class, only: full_space_vector_maker
   use precondition_tool_class, only: precondition_tool

   implicit none

   type, extends(abstract_davidson_solver) :: cpp_davidson_solver

      logical :: residual_minimization

      integer, public :: n_frequencies

      real(dp), private :: linear_dependence_threshold

      type(full_space_vector_maker), public :: vector_maker
      class(convergence_tool), allocatable, public :: convergence_checker
      class(vector_getter), allocatable, public :: preconditioner_getter
      class(reduced_matrix_maker), allocatable, public :: A_red
      class(reduced_overlap_maker), allocatable, public :: T_red
      class(precondition_tool), allocatable, private :: preconditioner

      class(linear_equation_storage_tool), allocatable, public :: storer
      class(vector_getter), allocatable, public :: start_vector
      class(vector_getter), allocatable, public :: rhs_getter
      class(cpp_print_tool), allocatable, public :: printer
      class(reduced_vector_maker), allocatable, public :: F_red
      class(reduced_vector_maker), allocatable, public :: G_red

      real(dp), dimension(:), allocatable :: rhs, frequencies
      real(dp) :: damping
      integer :: sign

   contains

      procedure, public :: test_convergence_and_add_trials

      procedure, public :: initialize

      procedure, public :: solve_reduced_problem
      procedure, private :: solve_reduced_problem_standard
      procedure, private :: solve_reduced_problem_residual_minimization
      procedure, private :: check_if_rhs_is_zero
      procedure, private :: reset_reduced_space

      procedure, public :: calculate_reduced_space_quantities => calculate_reduced_space_quantities_linear
      procedure, public :: solve_reduced_problem_and_update_reduced_space => &
                           solve_reduced_problem_and_update_reduced_space_linear

      procedure, public :: cleanup => cleanup_cpp_davidson
      procedure, public :: print_iterative_loop_header => print_iterative_loop_header_linear
      procedure, public :: print_iterative_loop_footer => print_iterative_loop_footer_linear

      procedure, public :: print_banner => print_banner_linear
      procedure, public :: print_settings => print_settings_linear

   end type cpp_davidson_solver

   interface cpp_davidson_solver

      procedure :: new_cpp_davidson_solver

   end interface cpp_davidson_solver

contains

   function new_cpp_davidson_solver(transformer, &
                                    convergence_checker, &
                                    storer, &
                                    preconditioner_getter, &
                                    rhs_getter, &
                                    printer, &
                                    projector, &
                                    n_parameters, &
                                    n_frequencies, &
                                    max_iterations, &
                                    frequencies, &
                                    damping, &
                                    sign, &
                                    linear_dependence_threshold, &
                                    reduced_space_in_memory, &
                                    max_reduced_dimension, &
                                    start_vector, &
                                    residual_minimization) result(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      use array_initialization, only: copy_and_scale

      implicit none

      type(cpp_davidson_solver) :: this

      class(transformation), intent(in) :: transformer
      type(convergence_tool), intent(in) :: convergence_checker
      class(linear_equation_storage_tool), intent(in) :: storer
      class(vector_getter), intent(in) :: preconditioner_getter
      class(vector_getter), intent(in) :: rhs_getter
      class(cpp_print_tool), intent(in) :: printer
      class(abstract_projection_tool), intent(in) :: projector
      integer, intent(in) :: max_iterations, n_frequencies, sign
      integer, intent(in) :: max_reduced_dimension, n_parameters
      real(dp), dimension(n_frequencies), intent(in) :: frequencies
      real(dp), intent(in) :: linear_dependence_threshold, damping
      logical, intent(in) :: reduced_space_in_memory, residual_minimization
      class(vector_getter), intent(in) :: start_vector

      integer :: corrected_max_reduced_dimension


      this%skip_convergence_summary = .false.
      this%skip_banner = .false.

      this%residual_minimization = residual_minimization
      this%n_parameters = n_parameters
      this%transformer = transformer
      this%start_vector = start_vector
      this%storer = storer
      this%preconditioner_getter = preconditioner_getter
      this%rhs_getter = rhs_getter
      this%printer = printer
      this%projector = projector
      this%n_frequencies = n_frequencies
      this%n_solutions = n_frequencies
      this%max_iterations = max_iterations
      this%convergence_checker = convergence_checker
      this%damping = damping
      this%sign = sign

      call mem%alloc(this%frequencies, this%n_frequencies)
      call copy_and_scale(one, frequencies, this%frequencies, this%n_frequencies)

      corrected_max_reduced_dimension = min(max_reduced_dimension, this%n_parameters)
      this%trials = reduced_space('cpp_davidson_trials', &
                                  this%n_parameters, &
                                  corrected_max_reduced_dimension, &
                                  reduced_space_in_memory, &
                                  n_orthonormalizations=2, &
                                  linear_dependence_threshold=linear_dependence_threshold)

      this%transforms = reduced_space('cpp_davidson_transforms', &
                                      this%n_parameters, &
                                      corrected_max_reduced_dimension, &
                                      reduced_space_in_memory)

      this%A_red = reduced_matrix_maker()
      this%F_red = reduced_vector_maker(1)

      if (this%residual_minimization) then

         this%T_red = reduced_overlap_maker()
         this%G_red = reduced_vector_maker(1)

      end if

      this%total_timer = timings("CPP davidson solver total", pl='m')
      this%iteration_timer = iteration_timings("CPP davidson solver iteration", pl='m')

   end function new_cpp_davidson_solver


   subroutine test_convergence_and_add_trials(this, X_red, converged, iteration)
      !!
      !! Written by Anna Kristina Schnack Petersen, Torsha Moitra,
      !! and Sarai D. Folkestad, 2021-2023
      !!
      !! - Get residual
      !! - Test convergence
      !! - Add new trial if needed and residual norm is greater
      !!   than linear dependence threshold
      !!
      use array_utilities, only: extract_columns, l2_normalize

      implicit none

      class(cpp_davidson_solver), intent(inout) :: this
      logical, dimension(this%n_frequencies), intent(out) :: converged
      integer, intent(in) :: iteration

      real(dp), dimension(:, :), allocatable :: R_re, R_im
      real(dp), dimension(:), allocatable :: X, R
      real(dp), dimension(:, :), allocatable :: X_re, X_im
      real(dp), dimension(:), allocatable :: residual_norm

      complex(dp), dimension(this%trials%n_written_records, this%n_frequencies), intent(in) :: X_red

      logical, dimension(:), allocatable :: add_residual_as_trial

      integer :: i, n_new_trials
      real(dp) :: ddot

      call mem%alloc(residual_norm, this%n_frequencies)

      call mem%alloc(X_re, this%n_parameters, this%n_frequencies)
      call mem%alloc(X_im, this%n_parameters, this%n_frequencies)

      call this%vector_maker%construct_full_space_vector(this%trials, &
                                                         this%n_frequencies, &
                                                         this%trials%n_written_records, &
                                                         real(X_red), &
                                                         X_re)

      call this%vector_maker%construct_full_space_vector(this%trials, &
                                                         this%n_frequencies, &
                                                         this%trials%n_written_records, &
                                                         aimag(X_red), &
                                                         X_im)

      call mem%alloc(X, this%n_parameters * 2)
      do i = 1, this%n_frequencies

         call dcopy(this%n_parameters, X_re(:, i), 1, X, 1)
         call dcopy(this%n_parameters, X_im(:, i), 1, X(this%n_parameters + 1), 1)
         call this%storer%store(X, i)

      end do
      call mem%dealloc(X)

      call mem%alloc(R_re, this%n_parameters, this%n_frequencies)
      call mem%alloc(R_im, this%n_parameters, this%n_frequencies)

      call this%vector_maker%construct_full_space_vector(this%transforms, &
                                                         this%n_frequencies, &
                                                         this%trials%n_written_records, &
                                                         real(X_red), &
                                                         R_re)

      call this%vector_maker%construct_full_space_vector(this%transforms, &
                                                         this%n_frequencies, &
                                                         this%trials%n_written_records, &
                                                         aimag(X_red), &
                                                         R_im)

      do i = 1, this%n_frequencies

         call daxpy(this%n_parameters, - this%frequencies(i), X_re(:, i), 1, R_re(:, i), 1)
         call daxpy(this%n_parameters, this%damping, X_im(:, i), 1, R_re(:, i), 1)
         call daxpy(this%n_parameters, - one, this%rhs(:), 1, R_re(:, i), 1)

         call dscal(this%n_parameters, - one, R_im(:, i), 1)
         call daxpy(this%n_parameters, this%frequencies(i), X_im(:, i), 1, R_im(:, i), 1)
         call daxpy(this%n_parameters, this%damping, X_re(:, i), 1, R_im(:, i), 1)

      end do

      do i = 1, this%n_frequencies

         residual_norm(i) = &
            sqrt(ddot(this%n_parameters, R_re(:, i), 1, R_re(:, i), 1) &
            + ddot(this%n_parameters, R_im(:, i), 1, R_im(:, i), 1))

         call this%projector%project(R_re(:, i))
         call this%projector%project(R_im(:, i))

         converged(i) = this%convergence_checker%has_converged(residual_norm(i))

      end do

      if (.not. all(converged)) then
         if (this%trials%n_written_records &
             + 2 * count(.not. converged) > this%trials%get_max_reduced_dimension()) then

            call this%reset_reduced_space(X_re, X_im)

         else

            call mem%alloc(add_residual_as_trial, this%n_frequencies)
            add_residual_as_trial = (.not. converged)

            call extract_columns(this%n_parameters, this%n_frequencies, R_re, add_residual_as_trial)
            call extract_columns(this%n_parameters, this%n_frequencies, R_im, add_residual_as_trial)

            call mem%alloc(R, this%n_parameters * 2)
            do i = 1, this%n_frequencies

               call dcopy(this%n_parameters, R_re(:, i), 1, R, 1)
               call dcopy(this%n_parameters, R_im(:, i), 1, R(this%n_parameters + 1), 1)

               call this%preconditioner%do_(R, shift=this%frequencies(i), prefactor=- one)
               call dcopy(this%n_parameters, R, 1, R_re(:, i), 1)
               call dcopy(this%n_parameters, R(this%n_parameters + 1), 1, R_im(:, i), 1)

               call l2_normalize(R_re(:, i), this%n_parameters)
               call l2_normalize(R_im(:, i), this%n_parameters)

            end do
            call mem%dealloc(R)

            n_new_trials = count(add_residual_as_trial)

            if (n_new_trials > 0) then
               call this%trials%orthonormalize_and_add_vectors(n_new_trials, R_re)
               call this%trials%orthonormalize_and_add_vectors(n_new_trials, R_im)
            end if

            call mem%dealloc(add_residual_as_trial)

         end if
      end if

      call this%printer%print_iteration(this%n_frequencies, &
                                        residual_norm, &
                                        iteration, &
                                        this%frequencies, &
                                        this%transforms%n_written_records)

      call mem%dealloc(residual_norm)
      call mem%dealloc(R_re)
      call mem%dealloc(R_im)
      call mem%dealloc(X_re)
      call mem%dealloc(X_im)

   end subroutine test_convergence_and_add_trials


   subroutine reset_reduced_space(this, X_re, X_im)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      !! Resets the reduced space and sets new trials equal
      !! to orthonormalized solutions
      !!

      implicit none

      class(cpp_davidson_solver), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: X_re, X_im

      call this%trials%reset_written_records()
      call this%transforms%reset_written_records()

      call this%trials%orthonormalize_and_add_vectors(this%n_solutions, X_re)
      call this%trials%orthonormalize_and_add_vectors(this%n_solutions, X_im)
      call this%A_red%reset()
      call this%F_red%reset()

      if (this%residual_minimization) then

         call this%T_red%reset()
         call this%G_red%reset()

      end if

   end subroutine reset_reduced_space


   subroutine cleanup_cpp_davidson(this)
      !!
      !! Written by Regina Matveeva and Sarai D. Folkestad, 2021
      !!
      implicit none

      class(cpp_davidson_solver), intent(inout) :: this

      if (allocated(this%trials)) call this%trials%finalize()
      if (allocated(this%transforms)) call this%transforms%finalize()

      call mem%dealloc(this%rhs)
      call mem%dealloc(this%frequencies)

      call this%preconditioner%destruct_precondition_vector()

      call this%A_red%deallocate_matrix()
      call this%F_red%deallocate_matrix()

      if (this%residual_minimization) then

         call this%T_red%deallocate_matrix()
         call this%G_red%deallocate_matrix()

      end if

   end subroutine cleanup_cpp_davidson


   subroutine initialize(this, converged)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      use range_class, only: range_
      use cpp_precondition_tool_class, only: cpp_precondition_tool

      implicit none

      class(cpp_davidson_solver), intent(inout) :: this

      real(dp), dimension(:), allocatable :: preconditioner
      real(dp), dimension(:, :), allocatable :: start_vectors
      logical, dimension(this%n_solutions), intent(inout) :: converged

      call this%trials%initialize()
      call this%transforms%initialize()
      call this%transformer%initialize()

      call mem%alloc(preconditioner, this%n_parameters)
      call this%preconditioner_getter%get(preconditioner)

      this%preconditioner = cpp_precondition_tool(this%n_parameters, this%sign, this%damping)
      call this%preconditioner%initialize_and_set_precondition_vector(preconditioner)
      call mem%dealloc(preconditioner)

      call mem%alloc(this%rhs, this%n_parameters)
      call this%rhs_getter%get(this%rhs)

      call this%check_if_rhs_is_zero(converged)

      if (.not. all(converged)) then

         call mem%alloc(start_vectors, this%n_parameters, this%start_vector%n_vectors)
         call this%start_vector%get(start_vectors)
         call this%trials%copy_record_in(start_vectors, range_(1, this%start_vector%n_vectors))
         call mem%dealloc(start_vectors)
         call this%trials%orthonormalize()

      end if

   end subroutine initialize


   subroutine solve_reduced_problem(this, X_red)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      !! Solves (A^red - (omega+igamma)I) X^red = F
      !!

      implicit none

      class(cpp_davidson_solver), intent(inout) :: this
      complex(dp), dimension(this%trials%n_written_records, this%n_frequencies), intent(out) :: X_red

      if (this%residual_minimization) then

         call this%solve_reduced_problem_residual_minimization(X_red)

      else

         call this%solve_reduced_problem_standard(X_red)

      end if

   end subroutine solve_reduced_problem


   subroutine solve_reduced_problem_standard(this, X_red)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      !! Solves (A^red - (omega+igamma)I) X^red = F
      !!
      use global_out, only: output
      use array_initialization, only: copy_and_scale_real_to_complex

      implicit none

      class(cpp_davidson_solver), intent(inout) :: this
      complex(dp), dimension(this%trials%n_written_records, this%n_frequencies), intent(out) :: X_red

      complex(dp), dimension(:, :), allocatable :: M
      integer :: info
      integer, dimension(:), allocatable :: ipiv

      integer :: i, l

      call mem%alloc(ipiv, this%trials%n_written_records)
      call mem%alloc(M, this%trials%n_written_records, this%trials%n_written_records)

      do i = 1, this%n_frequencies

         call copy_and_scale_real_to_complex(one, this%A_red%matrix, M, this%trials%n_written_records**2)

         call copy_and_scale_real_to_complex(one, &
                                             this%F_red%matrix, &
                                             X_red(:, i), &
                                             this%trials%n_written_records)

         do l = 1, this%trials%n_written_records
            M(l, l) = M(l, l) - cmplx(this%frequencies(i), this%damping, kind=dp)
         end do

         ipiv = 0
         info = 0

         call zgesv(this%trials%n_written_records, &
                    1, &
                    M, &
                    this%trials%n_written_records, &
                    ipiv, &
                    X_red(:, i), &
                    this%trials%n_written_records, &
                    info)

         if (info /= 0) call output%error_msg('could not solve linear equation.')

      end do

      call mem%dealloc(ipiv)
      call mem%dealloc(M)

   end subroutine solve_reduced_problem_standard


   subroutine solve_reduced_problem_residual_minimization(this, X_red)
      !!
      !! Written by A.K. Schnack-Petersen, Mar 2023
      !!
      !! Solves the reduced space equations using residual minimization
      !!
      !! See the SI of DOI: 10.26434/chemrxiv-2023-dgbdz
      !!
      use global_out, only: output
      use array_initialization, only: copy_and_scale_real_to_complex, scale_and_add_real_to_complex

      implicit none

      class(cpp_davidson_solver), intent(inout) :: this
      complex(dp), dimension(this%trials%n_written_records, this%n_frequencies), intent(out) :: X_red

      complex(dp), dimension(:, :), allocatable :: M
      real(dp), dimension(:, :), allocatable :: A_transpose
      integer :: info
      integer, dimension(:), allocatable :: ipiv

      integer :: i, l

      complex(dp) :: complex_frequency

      call mem%alloc(ipiv, this%trials%n_written_records)
      call mem%alloc(M, this%trials%n_written_records, this%trials%n_written_records)
      call mem%alloc(A_transpose, this%trials%n_written_records, this%trials%n_written_records)
      A_transpose = transpose(this%A_red%matrix)

      do i = 1, this%n_frequencies

         complex_frequency = cmplx(this%frequencies(i), this%damping, kind=dp)

         call copy_and_scale_real_to_complex(one, this%T_red%matrix, M, this%trials%n_written_records**2)

         call copy_and_scale_real_to_complex(one, &
                                             this%G_red%matrix, &
                                             X_red(:, i), &
                                             this%trials%n_written_records)

         call scale_and_add_real_to_complex(- conjg(complex_frequency), &
                                            this%A_red%matrix, &
                                            M, &
                                            this%trials%n_written_records**2)

         call scale_and_add_real_to_complex(- complex_frequency, &
                                            A_transpose, &
                                            M, &
                                            this%trials%n_written_records**2)

         call scale_and_add_real_to_complex(- conjg(complex_frequency), &
                                            this%F_red%matrix, &
                                            X_red(:, i), &
                                            this%trials%n_written_records)

         do l = 1, this%trials%n_written_records
            M(l, l) = M(l, l) + this%frequencies(i)**2 + this%damping**2
         end do

         ipiv = 0
         info = 0

         call zgesv(this%trials%n_written_records, &
                    1, &
                    M, &
                    this%trials%n_written_records, &
                    ipiv, &
                    X_red(:, i), &
                    this%trials%n_written_records, &
                    info)

         if (info /= 0) call output%error_msg('could not solve linear equation.')

      end do

      call mem%dealloc(ipiv)
      call mem%dealloc(M)
      call mem%dealloc(A_transpose)

   end subroutine solve_reduced_problem_residual_minimization


   subroutine check_if_rhs_is_zero(this, converged)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      use global_out, only: output
      use array_utilities, only: get_l2_norm

      implicit none

      class(cpp_davidson_solver), intent(inout) :: this
      real(dp), dimension(:), allocatable :: solution
      logical, dimension(this%n_solutions), intent(inout) :: converged

      converged = this%convergence_checker%has_converged(get_l2_norm(this%rhs, this%n_parameters))

      if (all(converged)) then

         call output%printf('m', &
                            'Right hand side is zero to within threshold (e6.1).', &
                            reals=[this%convergence_checker%get_residual_threshold()], &
                            fs='(/t3,a)')

         call mem%alloc(solution, this%n_parameters, set_zero=.true.)
         call this%storer%store(solution, 1)
         call mem%dealloc(solution)

         return

      end if

   end subroutine check_if_rhs_is_zero


   subroutine calculate_reduced_space_quantities_linear(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(cpp_davidson_solver), intent(inout) :: this

      call this%A_red%construct(this%trials, this%transforms)
      call this%F_red%construct(this%trials, this%rhs)

      if (this%residual_minimization) then

         call this%T_red%construct(this%transforms)
         call this%G_red%construct(this%transforms, this%rhs)

      end if

   end subroutine calculate_reduced_space_quantities_linear


   subroutine print_iterative_loop_header_linear(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(cpp_davidson_solver), intent(inout) :: this

      call this%printer%print_iteration_header()

   end subroutine print_iterative_loop_header_linear


   subroutine print_iterative_loop_footer_linear(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(cpp_davidson_solver), intent(inout) :: this

      call this%printer%print_iteration_footer()

   end subroutine print_iterative_loop_footer_linear


   subroutine solve_reduced_problem_and_update_reduced_space_linear(this, converged, iteration)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(cpp_davidson_solver), intent(inout) :: this
      logical, dimension(this%trials%n_written_records), intent(inout) :: converged
      integer, intent(in) :: iteration

      complex(dp), dimension(:, :), allocatable :: X_red

      call mem%alloc(X_red, this%trials%n_written_records, this%n_frequencies)

      call this%solve_reduced_problem(X_red)
      call this%test_convergence_and_add_trials(X_red, converged, iteration)

      call mem%dealloc(X_red)

   end subroutine solve_reduced_problem_and_update_reduced_space_linear


   subroutine print_banner_linear(this)
      !!
      !! Written by Regina Matveeva, Dec 2021
      !!
      implicit none

      class(cpp_davidson_solver), intent(in) :: this

      call this%printer%print_banner()

   end subroutine print_banner_linear


   subroutine print_settings_linear(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      use global_out, only: output
      implicit none

      class(cpp_davidson_solver), intent(in) :: this

      call output%printf('m', '- Complex polarization propagator solver settings:', fs='(/t3,a)')

      call output%print_vector('m', &
                               'Frequencies:', &
                               this%n_frequencies, &
                               this%frequencies, &
                               columns=1, &
                               fs='(t6,a)', &
                               fn='(e11.4)')

      call output%printf('m', &
                         'Damping factor:               (e11.4)', &
                         reals=[this%damping], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Max number of iterations:     (i11)', &
                         ints=[this%max_iterations], &
                         fs='(t6,a)')

      call output%printf('m', &
                         'Max reduced space dimension:  (i11)', &
                         ints=[this%trials%get_max_reduced_dimension()], &
                         fs='(t6,a)')


      call this%trials%print_settings()
      call this%transforms%print_settings()
      if (this%residual_minimization) call output%printf('m', 'Residual minimization enabled!', fs='(/t6,a)')

      call this%convergence_checker%print_settings()

   end subroutine print_settings_linear


end module cpp_davidson_solver_class

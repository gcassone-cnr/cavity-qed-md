

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_davidson_solver_class

   !!
   !! Abstract Davidson solver class
   !! Written by Sarai D. Folkestad, 2023
   !!

   use parameters
   use memory_manager_class, only: mem
   use transformation_class, only: transformation
   use abstract_projection_tool_class, only: abstract_projection_tool
   use reduced_space_class, only: reduced_space
   use abstract_solver_class, only: abstract_solver

   implicit none

   type, extends(abstract_solver), abstract :: abstract_davidson_solver


      integer, public :: n_parameters, n_solutions
      integer, public :: max_iterations

      class(transformation), allocatable, public :: transformer
      class(abstract_projection_tool), allocatable, public :: projector
      type(reduced_space), allocatable, public :: trials
      type(reduced_space), allocatable, public :: transforms

      logical :: skip_convergence_summary, stop_if_not_converged, has_converged, skip_banner

      integer :: iteration

   contains

      procedure, public :: run

      procedure, public :: print_iterative_loop_header
      procedure, public :: print_iterative_loop_footer

      procedure, private :: check_and_print_convergence

      procedure(initialize), deferred, public :: initialize

      procedure(calculate_reduced_space_quantities), deferred, public :: calculate_reduced_space_quantities
      procedure(solve_reduced_problem_and_update_reduced_space), deferred, public :: &
         solve_reduced_problem_and_update_reduced_space
      procedure(print_banner), deferred :: print_banner
      procedure(print_settings), deferred :: print_settings

   end type abstract_davidson_solver

   abstract interface

      subroutine initialize(this, converged)

         import :: abstract_davidson_solver
         implicit none

         class(abstract_davidson_solver), intent(inout) :: this
         logical, dimension(this%n_solutions), intent(inout) :: converged

      end subroutine initialize


      subroutine calculate_reduced_space_quantities(this)

         import :: abstract_davidson_solver
         implicit none

         class(abstract_davidson_solver), intent(inout) :: this

      end subroutine calculate_reduced_space_quantities


      subroutine solve_reduced_problem_and_update_reduced_space(this, converged, iteration)

         import :: abstract_davidson_solver
         implicit none

         class(abstract_davidson_solver), intent(inout) :: this
         logical, dimension(this%trials%n_written_records), intent(inout) :: converged
         integer, intent(in) :: iteration

      end subroutine solve_reduced_problem_and_update_reduced_space


      subroutine print_banner(this)

         import :: abstract_davidson_solver
         implicit none

         class(abstract_davidson_solver), intent(in) :: this

      end subroutine print_banner


      subroutine print_settings(this)

         import :: abstract_davidson_solver
         implicit none

         class(abstract_davidson_solver), intent(in) :: this

      end subroutine print_settings

   end interface

contains


   recursive subroutine run(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(abstract_davidson_solver), intent(inout) :: this

      integer :: i

      real(dp), dimension(:), allocatable :: trial, transform

      logical, dimension(:), allocatable :: converged

      integer :: first_trial_to_transform, last_trial_to_transform

      call this%total_timer%turn_on()

      if (.not. this%skip_banner) then
         call this%print_banner()
         call this%print_settings()
      end if


      this%has_converged = .false.

      call mem%alloc(trial, this%n_parameters)
      call mem%alloc(transform, this%n_parameters)
      call mem%alloc(converged, this%n_solutions, set_to=.false.)

      call this%initialize(converged)


      call this%print_iterative_loop_header()


      this%iteration = 0
      do while (.not. all(converged) .and. (this%iteration <= this%max_iterations))

         this%iteration = this%iteration + 1
         call this%iteration_timer%turn_on()

         first_trial_to_transform = this%transforms%get_dim() + 1
         last_trial_to_transform = this%trials%get_dim()


         do i = first_trial_to_transform, last_trial_to_transform

            call this%trials%copy_record_out(trial, i)
            call this%transformer%transform(trial, transform)

            call this%projector%project(transform)
            call this%transforms%copy_record_in(transform, i)

         end do


         call this%calculate_reduced_space_quantities()
         call this%solve_reduced_problem_and_update_reduced_space(converged, this%iteration)

         call this%iteration_timer%turn_off()

      end do


      call this%print_iterative_loop_footer()

      call mem%dealloc(trial)
      call mem%dealloc(transform)


      if (.not. this%skip_convergence_summary) then
         call this%check_and_print_convergence(converged, this%iteration)
      end if

      this%has_converged = all(converged)

      call mem%dealloc(converged)

      call this%total_timer%turn_off()

   end subroutine run


   subroutine print_iterative_loop_header(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      use warning_suppressor, only: do_nothing
      implicit none

      class(abstract_davidson_solver), intent(inout) :: this

      call do_nothing(this)

   end subroutine print_iterative_loop_header


   subroutine print_iterative_loop_footer(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      use warning_suppressor, only: do_nothing
      implicit none

      class(abstract_davidson_solver), intent(inout) :: this

      call do_nothing(this)

   end subroutine print_iterative_loop_footer


   subroutine check_and_print_convergence(this, converged, iteration)
      !!
      !! Written by Sarai D. Folkestad, Nov 2022
      !!
      use global_out, only: output

      implicit none

      class(abstract_davidson_solver), intent(in) :: this
      logical, dimension(this%n_solutions), intent(in) :: converged
      integer, intent(in) :: iteration

      if (all(converged)) then

         call output%printf('m', &
                            'Convergence criterion met in (i0) iterations!', &
                            ints=[iteration], &
                            fs='(t3,a/)')

      else

         if (this%stop_if_not_converged) then

            call output%error_msg( &
                    "Did not converge in the max number of iterations in Davidson solver." &
                 )

         else

            call output%warning_msg( &
                    "Did not converge in the max number of iterations in Davidson solver." &
                 )

         end if

      end if

   end subroutine check_and_print_convergence


end module abstract_davidson_solver_class

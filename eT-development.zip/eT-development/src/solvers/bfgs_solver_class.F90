

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module bfgs_solver_class

   !!
   !! BFGS solver
   !! Written by Eirik F. Kjoenstad, 2019-2021 and Jan Haakon M. Trabski, June 2023
   !!

   use parameters
   use memory_manager_class, only: mem
   use global_out, only: output
   use objective_function_class, only: objective_function
   use bfgs_tool_class, only: bfgs_tool
   use geoopt_convergence_tool_class, only: geoopt_convergence_tool
   use redundant_internal_coordinates_class, only: redundant_internal_coords


   implicit none

   type :: bfgs_solver

      class(objective_function), allocatable, private :: energy_function

      class(redundant_internal_coords), pointer, private :: internals

      type(bfgs_tool), private :: bfgs

      class(geoopt_convergence_tool), allocatable, private :: convergence_checker

      integer, private :: n_cartesian, n_internal, iteration, max_iterations
      real(dp), private :: max_step

      real(dp), dimension(:, :), allocatable, private :: geometries
      real(dp), dimension(:, :), allocatable, private :: gradients
      real(dp), dimension(:), allocatable, private :: energies

      real(dp), dimension(:), allocatable, private :: energy_differences
      real(dp), dimension(:), allocatable, private :: gradient_max
      real(dp), dimension(:), allocatable, private :: gradient_rms
      real(dp), dimension(:), allocatable, private :: displacement_threshold
      real(dp), dimension(:), allocatable, private :: displacement_rms_threshold

      character(len=33) :: name_ = 'BFGS geometry optimization solver'

   contains

      procedure, public :: run => run_bfgs_solver

      procedure, public :: initialize => initialize_bfgs_solver

      procedure, public :: finalize => finalize_bfgs_solver

      procedure, private :: calculate_gradient_max
      procedure, private :: calculate_gradient_rms
      procedure, private :: calculate_displacement_rms_threshold
      procedure, private :: calculate_displacement_threshold
      procedure, private :: calculate_energy_difference
      procedure, private :: has_converged
      procedure, private :: update_geometry
      procedure, private :: update_bfgs_hessian_and_calculate_step
      procedure, private :: print_iteration
      procedure, private :: print_summary
      procedure, private :: project_bfgs_hessian
      procedure, private :: print_banner

   end type bfgs_solver


   interface bfgs_solver

      procedure :: new_bfgs_solver

   end interface bfgs_solver


contains


   function new_bfgs_solver(energy_function, &
                            internals, &
                            max_iterations, &
                            max_step, &
                            convergence_checker) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021 and Jan Haakon M. Trabski, June 2023
      !!
      implicit none

      class(objective_function) :: energy_function
      type(redundant_internal_coords), target :: internals

      type(bfgs_solver) :: this

      integer, intent(in) :: max_iterations
      real(dp), intent(in) :: max_step

      class(geoopt_convergence_tool), intent(in) :: convergence_checker

      this%energy_function = energy_function

      this%internals => internals

      this%n_cartesian = this%energy_function%n_parameters
      this%max_iterations = max_iterations
      this%max_step = max_step

      this%convergence_checker = convergence_checker

      call this%print_banner()

   end function new_bfgs_solver


   subroutine print_banner(this)
      !!
      !! Written by Alexander C. Paul, Dec 2023
      !!
      implicit none

      class(bfgs_solver), intent(in) :: this

      call output%printf('m', trim(this%name_), fs='(/t3,a)')
      call output%print_separator('m', len_trim(this%name_))

      call this%convergence_checker%print_settings()

   end subroutine print_banner


   subroutine initialize_bfgs_solver(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021, and Jan Haaon M. Trabski 2023
      !!
      implicit none

      class(bfgs_solver) :: this

      real(dp), dimension(:), allocatable :: Hessian_diagonal

      call mem%alloc(this%geometries, this%n_cartesian, this%max_iterations)
      call mem%alloc(this%gradients, this%n_cartesian, this%max_iterations)
      call mem%alloc(this%energies, this%max_iterations)
      call mem%alloc(this%energy_differences, this%max_iterations)
      call mem%alloc(this%gradient_max, this%max_iterations)
      call mem%alloc(this%gradient_rms, this%max_iterations)

      call mem%alloc(this%displacement_rms_threshold, this%max_iterations)
      call mem%alloc(this%displacement_threshold, this%max_iterations)

      this%n_internal = this%internals%get_n_internal()

      this%bfgs = bfgs_tool(this%n_internal, this%max_step)
      call this%bfgs%initialize_arrays()

      call mem%alloc(Hessian_diagonal, this%n_internal)

      call this%internals%get_approximate_diagonal_Hessian(Hessian_diagonal)
      call this%bfgs%set_initial_Hessian_diagonal(Hessian_diagonal)

      call this%project_bfgs_hessian()

      call mem%dealloc(Hessian_diagonal)

   end subroutine initialize_bfgs_solver


   subroutine project_bfgs_hessian(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(bfgs_solver), intent(inout) :: this

      real(dp), dimension(:, :), allocatable :: Hessian

      call mem%alloc(Hessian, this%n_internal, this%n_internal)

      call this%bfgs%get_hessian(Hessian)

      call this%internals%Wilson_project_matrix(Hessian)

      call this%bfgs%set_hessian(Hessian)

      call mem%dealloc(Hessian)

   end subroutine project_bfgs_hessian


   subroutine run_bfgs_solver(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021, and Jan Haaon M. Trabski 2023
      !!
      implicit none

      class(bfgs_solver) :: this

      logical :: converged

      converged = .false.
      this%iteration = 0

      call this%energy_function%initialize()

      do while (.not. converged .and. this%iteration < this%max_iterations)

         this%iteration = this%iteration + 1

         this%geometries(:, this%iteration) = this%energy_function%get_parameters()
         this%energies(this%iteration) = this%energy_function%get()
         this%gradients(:, this%iteration) = this%energy_function%get_gradient()

         converged = this%has_converged()

         call this%print_iteration()

         if (.not. converged) then

            call this%update_geometry()

         else

            call output%printf('m', &
                               'Geometry converged in (i0) iterations!', &
                               ints=[this%iteration], &
                               fs='(t6,a)')

         end if

      end do
      if (.not. converged) &
         call output%error_msg('Was not able to converge the geometry in (i0) iterations!', &
                               ints=[this%iteration])

      call this%print_summary()

   end subroutine run_bfgs_solver


   function has_converged(this) result(converged)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      use array_utilities, only: get_abs_max, get_root_mean_square
      implicit none

      class(bfgs_solver), intent(inout) :: this

      logical :: converged
      integer :: i

      i = this%iteration
      this%gradient_max(i) = get_abs_max(this%gradients(:, i), this%n_cartesian)
      this%gradient_rms(i) = get_root_mean_square(this%gradients(:, i), this%n_cartesian)

      this%gradient_max(this%iteration) = this%calculate_gradient_max()
      this%gradient_rms(this%iteration) = this%calculate_gradient_rms()
      this%displacement_threshold(this%iteration) = this%calculate_displacement_threshold()
      this%displacement_rms_threshold(this%iteration) = this%calculate_displacement_rms_threshold()
      this%energy_differences(this%iteration) = this%calculate_energy_difference()

      converged = this%convergence_checker%has_converged(this%gradient_max(this%iteration), &
                                                         this%gradient_rms(this%iteration), &
                                                         this%displacement_threshold(this%iteration), &
                                                         this%displacement_rms_threshold(this%iteration), &
                                                         this%energy_differences(this%iteration))

   end function has_converged


   function calculate_gradient_max(this) result(gradient_max)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      use array_utilities, only: get_abs_max

      implicit none

      class(bfgs_solver) :: this

      real(dp) :: gradient_max

      gradient_max = get_abs_max(this%gradients(:, this%iteration), &
                                 this%n_cartesian)

   end function calculate_gradient_max


   function calculate_gradient_rms(this) result(gradient_rms)
      !!
      !! Written by Jan Haakon M. Trabski, June 2023
      !!
      use array_utilities, only: get_root_mean_square

      implicit none

      class(bfgs_solver) :: this

      real(dp) :: gradient_rms

      gradient_rms = get_root_mean_square(this%gradients(:, this%iteration), &
                                          this%n_cartesian)

   end function calculate_gradient_rms


   function calculate_displacement_rms_threshold(this) result(displacement_rms_threshold)
      !!
      !! Written by Jan Haakon M. Trabski, June 2023
      !!
      use array_utilities, only: get_root_mean_square

      implicit none

      class(bfgs_solver) :: this

      real(dp) :: displacement_rms_threshold
      real(dp), dimension(this%n_internal) :: atomic_displacement

      call this%internals%get_internals_difference(atomic_displacement)
      displacement_rms_threshold = get_root_mean_square(atomic_displacement, this%n_internal)

   end function calculate_displacement_rms_threshold


   function calculate_displacement_threshold(this) result(displacement_threshold)
      !!
      !! Written by Jan Haakon M. Trabski, June 2023
      !!
      use array_utilities, only: get_abs_max

      implicit none

      class(bfgs_solver) :: this

      real(dp) :: displacement_threshold
      real(dp), dimension(this%n_internal) :: atomic_displacement

      call this%internals%get_internals_difference(atomic_displacement)
      displacement_threshold = get_abs_max(atomic_displacement, this%n_internal)

   end function calculate_displacement_threshold


   function calculate_energy_difference(this) result(energy_difference)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(bfgs_solver) :: this

      real(dp) :: energy_difference

      real(dp) :: current_energy, previous_energy

      current_energy = this%energies(this%iteration)

      previous_energy = zero

      if (this%iteration > 1) then

         previous_energy = this%energies(this%iteration - 1)

      end if

      energy_difference = abs(current_energy - previous_energy)

   end function calculate_energy_difference


   subroutine update_geometry(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(bfgs_solver) :: this

      real(dp), dimension(:), allocatable :: s_q, x

      call output%printf('m', &
                         'Geometry not yet converged. Updating geometry via BFGS-RFO step.', &
                         fs='(/t6,a)')

      call mem%alloc(x, this%n_cartesian)
      call mem%alloc(s_q, this%n_internal)

      call this%update_bfgs_hessian_and_calculate_step(s_q)

      x = this%geometries(:, this%iteration)
      call this%internals%compute_next_geometry(x, s_q)

      call output%printf('m', 'New and updated geometry identified!', fs='(/t6,a)')
      call this%internals%print_geometry()

      call this%energy_function%set_parameters(x)

      call mem%dealloc(x)
      call mem%dealloc(s_q)

   end subroutine update_geometry


   subroutine update_bfgs_hessian_and_calculate_step(this, s_q)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(bfgs_solver) :: this

      real(dp), dimension(this%n_internal), intent(out) :: s_q

      real(dp), dimension(:), allocatable :: g_x, g_q, dq

      call mem%alloc(g_x, this%n_cartesian)
      call mem%alloc(g_q, this%n_internal)
      call mem%alloc(dq, this%n_internal)

      g_x = this%gradients(:, this%iteration)

      call this%internals%calculate_internal_gradient(g_x, g_q)

      call this%internals%Wilson_project_vector(g_q)

      call this%internals%get_internals_difference(dq)

      call this%bfgs%update_hessian(dq, g_q)

      call this%project_bfgs_hessian()

      call this%bfgs%get_step(g_q, s_q)

      call this%internals%Wilson_project_vector(s_q)
      call this%internals%Wilson_project_vector(s_q)

      call mem%dealloc(g_x)
      call mem%dealloc(g_q)
      call mem%dealloc(dq)

   end subroutine update_bfgs_hessian_and_calculate_step


   subroutine print_iteration(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021 and Jan Haakon M. Trabski, June 2023
      !!
      implicit none

      class(bfgs_solver) :: this

      call output%printf('m', '- Geometry optimization iteration (i0):', ints=[this%iteration], fs='(/t3,a)')

      call output%printf('m', &
                         '                max(grad)         rms(grad)       dE              max(displ)&
                         &      rms(displ)', &
                         ll=100)

      call output%print_separator('m', 90, '-', fs='(t6,a)')

      call output%printf('m', &
                         '   Criterion:  (e11.4)       (e11.4)     (e11.4)     (e11.4)     (e11.4) ', &
                         reals=[this%convergence_checker%residual_threshold, &
                            this%convergence_checker%residual_rms_threshold, &
                            this%convergence_checker%energy_threshold, &
                            this%convergence_checker%displacement_threshold, &
                            this%convergence_checker%displacement_rms_threshold], &
                         ll=101)

      call output%printf('m', &
                         '   Value:      (e11.4)       (e11.4)     (e11.4)     (e11.4)     (e11.4)', &
                         reals=[this%gradient_max(this%iteration), &
                            this%gradient_rms(this%iteration), &
                            this%energy_differences(this%iteration), &
                            this%displacement_threshold(this%iteration), &
                            this%displacement_rms_threshold(this%iteration)], &
                         ll=101)

      call output%print_separator('m', 90, '-', fs='(t6,a)')

   end subroutine print_iteration


   subroutine print_summary(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021 and Jan Haakon M. Trabski, June 2023
      !!
      implicit none

      class(bfgs_solver) :: this

      integer :: i

      call output%printf('m', '- Summary of geometry optimization:', fs='(/t3,a/)')

      call output%printf('m', &
         '       max(grad)         rms(grad)       dE              max(displ)      rms(displ)', ll = 100)
      call output%print_separator('m', 81, '-', fs='(t6,a)')

      do i = 1, this%iteration

         call output%printf('m', &
                            '   (i2) (e11.4)       (e11.4)     (e11.4)     (e11.4)     (e11.4)', &
                            ints=[i], &
                            ll=100, &
                            reals=[this%gradient_max(i), &
                               this%gradient_rms(i), &
                               this%energy_differences(i), &
                               this%displacement_threshold(i), &
                               this%displacement_rms_threshold(i)])

      end do

      call output%print_separator('m', 81, '-', fs='(t6,a)')

      call this%internals%print_geometry()

   end subroutine print_summary


   subroutine finalize_bfgs_solver(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021 and Jan Haakon M. Trabski, June 2023
      !!
      implicit none

      class(bfgs_solver) :: this

      call mem%dealloc(this%geometries)
      call mem%dealloc(this%gradients)
      call mem%dealloc(this%energies)
      call mem%dealloc(this%energy_differences)
      call mem%dealloc(this%gradient_max)
      call mem%dealloc(this%gradient_rms)
      call mem%dealloc(this%displacement_threshold)
      call mem%dealloc(this%displacement_rms_threshold)
      call this%bfgs%cleanup()

   end subroutine finalize_bfgs_solver


end module bfgs_solver_class

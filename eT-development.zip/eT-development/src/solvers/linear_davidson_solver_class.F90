

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module linear_davidson_solver_class

   !!
   !! Linear Davidson solver class
   !! Written by Regina Matveeva, Ida-Marie Hoeyvik, and Sarai D. Folkestad, 2021-2023
   !!
   !! This solver uses the Davidson algorithm to solve the set of linear equations
   !!
   !!    (A - omega_k I) X_jk = F_j,
   !!
   !! There are three cases handled in this solver:
   !!
   !! 1. n_frequencies >= 1, n_rhs = 1
   !! 2. n_frequencies = 1, n_rhs > 1
   !! 3. n_frequencies = n_rhs
   !!
   !! Note that the solver cannot handle different frequencies for a set of
   !! RHS' (i.e., n_frequencies > 1, n_rhs > 1 and n_frequencies != n_rhs)
   !!
   !! The solver builds a shared reduced space for the set of linear equations.
   !!
   !! This solver is a generalization of the ground state multipliers Davidson
   !! solver (authors Eirik F. Kjoenstad, Sarai D. Folkestad) as well as the
   !! Davidson coupled cluster linear equations solver (authors Eirik F. Kjoenstad,
   !! Sarai D. Folkestad, Josefine H. Andersen)
   !!

   use parameters
   use memory_manager_class, only: mem
   use timings_class, only: timings
   use iteration_timings_class, only: iteration_timings

   use transformation_class, only: transformation
   use vector_getter_class, only: vector_getter
   use abstract_projection_tool_class, only: abstract_projection_tool
   use linear_davidson_print_tool_class, only: linear_davidson_print_tool
   use linear_equation_storage_tool_class, only: linear_equation_storage_tool

   use abstract_davidson_solver_class, only: abstract_davidson_solver

   use convergence_tool_class, only: convergence_tool
   use reduced_matrix_maker_class, only: reduced_matrix_maker
   use reduced_vector_maker_class, only: reduced_vector_maker
   use reduced_space_class, only: reduced_space
   use full_space_vector_maker_class, only: full_space_vector_maker
   use precondition_tool_class, only: precondition_tool


   implicit none

   type, extends(abstract_davidson_solver) :: linear_davidson_solver

      integer, public :: n_rhs, n_frequencies

      real(dp), private :: linear_dependence_threshold

      type(full_space_vector_maker), public :: vector_maker
      class(convergence_tool), allocatable, public :: convergence_checker
      class(vector_getter), allocatable, public :: preconditioner_getter
      type(reduced_matrix_maker), allocatable, public :: A_red
      class(precondition_tool), allocatable, private :: preconditioner

      class(linear_equation_storage_tool), allocatable, public :: storer
      class(vector_getter), allocatable, public :: start_vector
      class(vector_getter), allocatable, public :: rhs_getter
      class(linear_davidson_print_tool), allocatable, public :: printer
      type(reduced_vector_maker), allocatable, public :: F_red

      real(dp), dimension(:), allocatable :: frequencies
      real(dp), dimension(:, :), allocatable :: rhs, X

      logical, public :: multiple_rhs, multiple_frequencies, skip_frequency_print

   contains

      procedure, public :: get_solution
      procedure, public :: test_convergence_and_add_trials

      procedure, public :: initialize

      procedure, private :: solution_to_frequency_index
      procedure, private :: solution_to_rhs_index
      procedure, public :: solve_reduced_problem
      procedure, private :: check_if_rhs_is_zero

      procedure, public :: calculate_reduced_space_quantities => calculate_reduced_space_quantities_linear
      procedure, public :: solve_reduced_problem_and_update_reduced_space => &
                           solve_reduced_problem_and_update_reduced_space_linear
      procedure, private :: reset_reduced_space

      procedure, public :: cleanup => cleanup_linear_davidson
      procedure, public :: print_iterative_loop_header => print_iterative_loop_header_linear
      procedure, public :: print_iterative_loop_footer => print_iterative_loop_footer_linear

      procedure, public :: print_banner => print_banner_linear
      procedure, public :: print_settings => print_settings_linear

   end type linear_davidson_solver

   interface linear_davidson_solver

      procedure :: new_linear_davidson_solver

   end interface linear_davidson_solver

contains

   function new_linear_davidson_solver(transformer, &
                                       convergence_checker, &
                                       storer, &
                                       preconditioner_getter, &
                                       rhs_getter, &
                                       printer, &
                                       projector, &
                                       n_parameters, &
                                       n_rhs, &
                                       n_frequencies, &
                                       max_iterations, &
                                       frequencies, &
                                       linear_dependence_threshold, &
                                       reduced_space_in_memory, &
                                       max_reduced_dimension, &
                                       start_vector, &
                                       stop_if_not_converged, &
                                       skip_convergence_summary, &
                                       skip_banner, &
                                       skip_frequency_print) result(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      use global_out, only: output

      implicit none

      type(linear_davidson_solver) :: this

      class(transformation), intent(in) :: transformer
      type(convergence_tool), intent(in) :: convergence_checker
      class(linear_equation_storage_tool), intent(in) :: storer
      class(vector_getter), intent(in) :: preconditioner_getter
      class(vector_getter), intent(in) :: rhs_getter
      class(linear_davidson_print_tool), intent(in) :: printer
      class(abstract_projection_tool), intent(in) :: projector
      integer, intent(in) :: max_iterations, n_frequencies, n_rhs
      integer, intent(in) :: max_reduced_dimension, n_parameters
      real(dp), dimension(n_frequencies), intent(in) :: frequencies
      real(dp), intent(in) :: linear_dependence_threshold
      logical, intent(in) :: reduced_space_in_memory
      class(vector_getter), intent(in) :: start_vector

      logical, intent(in), optional :: stop_if_not_converged
      logical, intent(in), optional :: skip_convergence_summary
      logical, intent(in), optional :: skip_banner
      logical, intent(in), optional :: skip_frequency_print

      integer :: corrected_max_reduced_dimension

      this%multiple_rhs = n_rhs > 1
      this%multiple_frequencies = n_frequencies > 1

      if (this%multiple_rhs .and. .not. (n_frequencies == n_rhs .or. n_frequencies == 1)) &
         call output%error_msg('Mismatch in frequencies and RHS for linear davidson solver')

      this%n_parameters = n_parameters
      this%transformer = transformer
      this%start_vector = start_vector
      this%storer = storer
      this%preconditioner_getter = preconditioner_getter
      this%rhs_getter = rhs_getter
      this%printer = printer
      this%projector = projector
      this%n_solutions = max(n_rhs, n_frequencies)
      this%n_rhs = n_rhs
      this%n_frequencies = n_frequencies
      this%max_iterations = max_iterations
      this%convergence_checker = convergence_checker

      this%stop_if_not_converged = .true.
      if (present(stop_if_not_converged)) this%stop_if_not_converged = stop_if_not_converged

      call mem%alloc(this%frequencies, this%n_frequencies)
      call dcopy(this%n_frequencies, frequencies, 1, this%frequencies, 1)

      this%skip_convergence_summary = .false.
      if (present(skip_convergence_summary)) this%skip_convergence_summary = skip_convergence_summary

      this%skip_banner = .true.
      if (present(skip_banner)) this%skip_banner = skip_banner

      this%skip_frequency_print = .false.
      if (present(skip_frequency_print)) this%skip_frequency_print = skip_frequency_print

      corrected_max_reduced_dimension = min(max_reduced_dimension, this%n_parameters)

      this%trials = reduced_space('linear_davidson_trials', &
                                  this%n_parameters, &
                                  corrected_max_reduced_dimension, &
                                  reduced_space_in_memory, &
                                  n_orthonormalizations=2, &
                                  linear_dependence_threshold=linear_dependence_threshold)

      this%transforms = reduced_space('linear_davidson_transforms', &
                                      this%n_parameters, &
                                      corrected_max_reduced_dimension, &
                                      reduced_space_in_memory)

      this%A_red = reduced_matrix_maker()
      this%F_red = reduced_vector_maker(this%n_rhs)

      this%total_timer = timings("Linear davidson solver total", pl='m')
      this%iteration_timer = iteration_timings("Linear davidson solver iteration", pl='m')


   end function new_linear_davidson_solver


   subroutine test_convergence_and_add_trials(this, X_red, converged, iteration)
      !!
      !! Written by Regina Matveeva and Sarai D. Folkestad, 2021-2023
      !!
      !! - Get residual
      !! - Test convergence
      !! - Add new trial if needed and residual norm is greater
      !!   than linear dependence threshold
      !!
      use array_utilities, only: get_l2_norm, extract_columns, l2_normalize

      implicit none

      class(linear_davidson_solver), intent(inout) :: this
      logical, dimension(this%n_solutions), intent(out) :: converged
      integer, intent(in) :: iteration

      real(dp), dimension(:, :), allocatable :: R
      real(dp), dimension(:), allocatable :: residual_norm

      real(dp), dimension(this%trials%n_written_records, this%n_solutions), intent(in) :: X_red

      logical, dimension(:), allocatable :: add_residual_as_trial

      integer :: i, j, k, n_new_trials

      call mem%alloc(residual_norm, this%n_solutions)
      call mem%alloc(R, this%n_parameters, this%n_solutions)

      call this%vector_maker%construct_full_space_vector(this%trials, &
                                                         this%n_solutions, &
                                                         this%trials%n_written_records, &
                                                         X_red, &
                                                         this%X)

      do i = 1, this%n_solutions
         call this%storer%store(this%X(:, i), i)
      end do

      call this%vector_maker%construct_full_space_vector(this%transforms, &
                                                         this%n_solutions, &
                                                         this%trials%n_written_records, &
                                                         X_red, &
                                                         R)

      do i = 1, this%n_solutions

         j = this%solution_to_frequency_index(i)
         k = this%solution_to_rhs_index(i)

         call daxpy(this%n_parameters, - this%frequencies(j), this%X(:, i), 1, R(:, i), 1)
         call daxpy(this%n_parameters, - one, this%rhs(:, k), 1, R(:, i), 1)

      end do

      do i = 1, this%n_solutions

         residual_norm(i) = get_l2_norm(R(:, i), this%n_parameters)
         call this%projector%project(R(:, i))

         converged(i) = this%convergence_checker%has_converged(residual_norm(i))

      end do

      call mem%alloc(add_residual_as_trial, this%n_solutions)
      add_residual_as_trial = (.not. converged)

      call extract_columns(this%n_parameters, this%n_solutions, R, add_residual_as_trial)

      do i = 1, this%n_solutions

         j = this%solution_to_frequency_index(i)
         call this%preconditioner%do_(R(:, i), shift=this%frequencies(j), prefactor=- one)
         call l2_normalize(R(:, i), this%n_parameters)

      end do

      n_new_trials = count(add_residual_as_trial)

      if (n_new_trials > 0) then
         if (this%trials%n_written_records + n_new_trials > this%trials%get_max_reduced_dimension()) then
            call this%reset_reduced_space()
            n_new_trials = this%n_solutions
         else
            call this%trials%orthonormalize_and_add_vectors(n_new_trials, R)
         end if
      end if

      call this%printer%print_iteration(this%n_solutions, &
                                        residual_norm, &
                                        iteration, &
                                        this%frequencies, &
                                        this%trials%n_written_records)

      call mem%dealloc(add_residual_as_trial)
      call mem%dealloc(R)
      call mem%dealloc(residual_norm)

   end subroutine test_convergence_and_add_trials


   subroutine cleanup_linear_davidson(this)
      !!
      !! Written by Regina Matveeva and Sarai D. Folkestad, 2021
      !!
      implicit none

      class(linear_davidson_solver), intent(inout) :: this

      if (allocated(this%trials)) call this%trials%finalize()
      if (allocated(this%transforms)) call this%transforms%finalize()
      if (allocated(this%X)) call mem%dealloc(this%X)

      call mem%dealloc(this%rhs)
      call mem%dealloc(this%frequencies)

      call this%preconditioner%destruct_precondition_vector()

      call this%A_red%deallocate_matrix()
      call this%F_red%deallocate_matrix()

   end subroutine cleanup_linear_davidson


   subroutine initialize(this, converged)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      use range_class, only: range_

      implicit none

      class(linear_davidson_solver), intent(inout) :: this

      real(dp), dimension(:), allocatable :: preconditioner
      real(dp), dimension(:, :), allocatable :: start_vectors
      logical, dimension(this%n_solutions), intent(inout) :: converged

      call this%trials%initialize()
      call this%transforms%initialize()
      call this%transformer%initialize()


      call mem%alloc(preconditioner, this%n_parameters)
      call this%preconditioner_getter%get(preconditioner)

      this%preconditioner = precondition_tool(this%n_parameters)
      call this%preconditioner%initialize_and_set_precondition_vector(preconditioner)
      call mem%dealloc(preconditioner)

      call mem%alloc(this%rhs, this%n_parameters, this%n_rhs)
      call this%rhs_getter%get(this%rhs)

      call this%check_if_rhs_is_zero(converged)

      if (.not. all(converged)) then

         call mem%alloc(start_vectors, this%n_parameters, this%n_solutions)
         call this%start_vector%get(start_vectors)
         call this%trials%copy_record_in(start_vectors, range_(1, this%n_solutions))
         call mem%dealloc(start_vectors)
         call this%trials%orthonormalize()

      end if

      call mem%alloc(this%X, this%n_parameters, this%n_solutions, set_zero=.true.)

   end subroutine initialize


   pure function solution_to_frequency_index(this, solution_index) result(frequency_index)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(linear_davidson_solver), intent(in) :: this
      integer, intent(in) :: solution_index
      integer :: frequency_index

      frequency_index = 1
      if (this%multiple_frequencies) frequency_index = solution_index

   end function solution_to_frequency_index


   pure function solution_to_rhs_index(this, solution_index) result(rhs_index)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(linear_davidson_solver), intent(in) :: this
      integer, intent(in) :: solution_index
      integer :: rhs_index

      rhs_index = 1
      if (this%multiple_rhs) rhs_index = solution_index

   end function solution_to_rhs_index


   subroutine solve_reduced_problem(this, X_red)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      !! Solves (A^red - omega I) X^red = F
      !!
      use global_out, only: output

      implicit none

      class(linear_davidson_solver), intent(inout) :: this
      real(dp), dimension(this%trials%n_written_records, this%n_solutions), intent(out) :: X_red

      real(dp), dimension(:, :), allocatable :: M
      integer :: info
      integer, dimension(:), allocatable :: ipiv

      integer :: i, j, k, l

      call mem%alloc(ipiv, this%trials%n_written_records)
      call mem%alloc(M, this%trials%n_written_records, this%trials%n_written_records)

      do i = 1, this%n_solutions

         j = this%solution_to_frequency_index(i)
         k = this%solution_to_rhs_index(i)

         call dcopy(this%trials%n_written_records**2, this%A_red%matrix, 1, M, 1)
         do l = 1, this%trials%n_written_records

            M(l, l) = M(l, l) - this%frequencies(j)

         end do

         call dcopy(this%trials%n_written_records, this%F_red%matrix(:, k), 1, X_red(:, i), 1)

         ipiv = 0
         info = 0

         call dgesv(this%trials%n_written_records, &
                    1, &
                    M, &
                    this%trials%n_written_records, &
                    ipiv, &
                    X_red(:, i), &
                    this%trials%n_written_records, &
                    info)

         if (info /= 0) call output%error_msg('could not solve linear equation.')

      end do

      call mem%dealloc(ipiv)
      call mem%dealloc(M)

   end subroutine solve_reduced_problem


   subroutine check_if_rhs_is_zero(this, converged)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      use global_out, only: output
      use array_utilities, only: get_l2_norm

      implicit none

      class(linear_davidson_solver), intent(inout) :: this
      real(dp), dimension(:), allocatable :: solution
      logical, dimension(this%n_solutions), intent(inout) :: converged

      integer :: n

      do n = 1, this%n_rhs
         converged(n) = this%convergence_checker%has_converged(get_l2_norm(this%rhs(:, n), this%n_parameters))
      end do

      if (all(converged)) then

         call output%printf('m', &
                            'Right hand side is zero to within threshold (e6.1).', &
                            reals=[this%convergence_checker%get_residual_threshold()], &
                            fs='(/t3,a)')

         call mem%alloc(solution, this%n_parameters, set_zero=.true.)
         call this%storer%store(solution, 1)
         call mem%dealloc(solution)

         return

      else if (any(converged)) then

         call output%error_msg('Some of right hand side vectors are zero to within threshold (e6.1).', &
                               reals=[this%convergence_checker%get_residual_threshold()], &
                               fs='(/t3,a)')

      end if

   end subroutine check_if_rhs_is_zero


   subroutine get_solution(this, X, n)
      !!
      !! Written by Sarai D. Folkestad, Mar 2022
      !!
      implicit none

      class(linear_davidson_solver), intent(inout) :: this

      real(dp), dimension(this%n_parameters), intent(out) :: X
      integer, intent(in) :: n

      call dcopy(this%n_parameters, this%X(:, n), 1, X, 1)

   end subroutine get_solution


   subroutine calculate_reduced_space_quantities_linear(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(linear_davidson_solver), intent(inout) :: this

      call this%A_red%construct(this%trials, this%transforms)
      call this%F_red%construct(this%trials, this%rhs)

   end subroutine calculate_reduced_space_quantities_linear


   subroutine print_iterative_loop_header_linear(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(linear_davidson_solver), intent(inout) :: this

      call this%printer%print_iteration_header()

   end subroutine print_iterative_loop_header_linear


   subroutine print_iterative_loop_footer_linear(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(linear_davidson_solver), intent(inout) :: this

      call this%printer%print_iteration_footer()

   end subroutine print_iterative_loop_footer_linear


   subroutine solve_reduced_problem_and_update_reduced_space_linear(this, converged, iteration)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(linear_davidson_solver), intent(inout) :: this
      logical, dimension(this%trials%n_written_records), intent(inout) :: converged
      integer, intent(in) :: iteration

      real(dp), dimension(:, :), allocatable :: X_red

      call mem%alloc(X_red, this%trials%n_written_records, this%n_solutions)

      call this%solve_reduced_problem(X_red)
      call this%test_convergence_and_add_trials(X_red, converged, iteration)

      call mem%dealloc(X_red)

   end subroutine solve_reduced_problem_and_update_reduced_space_linear


   subroutine print_banner_linear(this)
      !!
      !! Written by Regina Matveeva, Dec 2021
      !!
      implicit none

      class(linear_davidson_solver), intent(in) :: this
      call this%printer%print_banner()

   end subroutine print_banner_linear


   subroutine print_settings_linear(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      use global_out, only: output
      implicit none

      class(linear_davidson_solver), intent(in) :: this

      call output%printf('m', '- Linear Davidson solver settings', fs='(/t3,a)')

      if (.not. this%skip_frequency_print) &
         call output%print_vector('m', &
                                  'Frequencies:', &
                                  this%n_frequencies, &
                                  this%frequencies, &
                                  columns=1, &
                                  fs='(t6,a)', &
                                  fn='(e11.4)')

      call output%printf('m', &
                         'Number of right-hand-sides:   (i11)', &
                         ints=[this%n_rhs], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Number of solutions:          (i11)', &
                         ints=[this%n_solutions], &
                         fs='(t6,a)')

      call output%printf('m', &
                         'Max number of iterations:     (i11)', &
                         ints=[this%max_iterations], &
                         fs='(t6,a)')

      call output%printf('m', &
                         'Max reduced space dimension:  (i11)', &
                         ints=[this%trials%get_max_reduced_dimension()], &
                         fs='(t6,a)')

      call this%trials%print_settings()
      call this%transforms%print_settings()

      call this%convergence_checker%print_settings()



   end subroutine print_settings_linear


   subroutine reset_reduced_space(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      !! Resets the reduced space and sets new trials equal
      !! to orthonormalized solutions
      !!
      implicit none

      class(linear_davidson_solver), intent(inout) :: this

      call this%trials%reset_written_records()
      call this%transforms%reset_written_records()

      call this%trials%orthonormalize_and_add_vectors(this%n_solutions, this%X)
      call this%A_red%reset()
      call this%F_red%reset()

   end subroutine reset_reduced_space


end module linear_davidson_solver_class


! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module band_lanczos_cc_es_class

   !! Band Lanczos coupled cluster excited state solver class module
   !!
   !! Written by Torsha Moitra, Sonia Coriani and Andreas S. Skeidsvoll
   !! 2021-2023
   !!
   !! Calculates the excitation energies by using an nonsymmetric band Lanczos
   !! procedure.
   !!
   !! A banded matrix T, of dimension n (= 'chain length') is constructed, such
   !! that
   !!
   !!    A*V(n) = V(n)*T(n) + E_R(n)
   !!    A^T*W(n) = W(n)*Ttilde(n) + E_L(n)
   !!
   !! where A is the asymmetric matrix of dimension greater than or equal to n.
   !!
   !! The left and right banded matrix are related by,
   !!
   !!    Ttilde(n) = (D(n))^{-1}*(T(n))*(D(n)) ; D(n) = W(n)^T*V(n)
   !!
   !! The eigenvalues of A are approximated as the eigenvalues of T as,
   !!
   !!    (L_n)^T*T*R_n = e
   !!
   !! For further details see:
   !!    Phys. Rev. A 105, 023103
   !!    Acta Numerica 12, 267-319
   !!    Phys. Chem. Chem. Phys. 15, 10035-10048
   !!
   use parameters

   use ccs_class, only: ccs
   use abstract_solver_class, only: abstract_solver

   use global_out, only: output

   use memory_manager_class, only: mem
   use timings_class, only: timings
   use iteration_timings_class, only: iteration_timings
   use string_utilities, only: convert_to_uppercase
   use convergence_tool_class, only: convergence_tool

   use start_vector_tool_class, only: start_vector_tool
   use es_operator_on_state_start_vector_tool_class, only: es_operator_on_state_start_vector_tool
   use abstract_projection_tool_class, only: abstract_projection_tool

   use lanczos_vector_tool_class, only: lanczos_vector_tool

   use state_descriptor_class, only: state_descriptor
   use cc_es_storage_tool_class, only: cc_es_storage_tool

   implicit none

   type, extends(abstract_solver) :: band_lanczos_cc_es

      character(len=100) :: name_
      character(len=100) :: tag
      character(len=300) :: description1
      character(len=200) :: description2

      real(dp) :: deflation_threshold, overlap_threshold, min_energy, max_energy, min_transition_strength

      integer :: n_lanczos_vectors, n_start_vectors, biorthogonalize_last, max_iterations, n_states

      logical :: skip_convergence, records_in_memory

      class(convergence_tool), allocatable :: convergence_checker
      class(start_vector_tool), allocatable :: start_vectors
      class(es_operator_on_state_start_vector_tool), allocatable :: left_start_vector_tool, &
                                                                    right_start_vector_tool
      class(abstract_projection_tool), allocatable :: projector
      class(lanczos_vector_tool), allocatable :: V, W

      class(cc_es_storage_tool), allocatable :: storer_L
      class(cc_es_storage_tool), allocatable :: storer_R

      class(ccs), pointer :: wf

      type(state_descriptor), allocatable :: descriptor_L, descriptor_R
   contains

      procedure :: run => run_band_lanczos_cc_es

      procedure :: cleanup => cleanup_band_lanczos_cc_es

      procedure, private :: print_settings

      procedure, private :: print_banner

      procedure, private, nopass :: print_iteration_header
      procedure, private :: print_iteration_info
      procedure, private :: print_deflation_info
      procedure, private :: print_iteration_footer

      procedure, private :: prepare_start_vector_arrays

      procedure, private :: calculate_first_candidate_norm_and_deflate_if_necessary

      procedure, private :: biorthogonalize_first_candidates_against_vectors_outside_band
      procedure, private :: biorthogonalize_other_candidates_against_first_candidates

      procedure, private :: generate_and_biorthogonalize_V_candidate
      procedure, private :: generate_and_biorthogonalize_W_candidate

      procedure, private :: diagonalize_T
      procedure, private :: print_energy_summary

      procedure, private :: calculate_and_print_transition_and_oscillator_strengths
      procedure, private :: calculate_transition_strengths
      procedure, private :: print_transition_strength_summary
      procedure, private :: calculate_and_print_oscillator_strengths
      procedure, private :: print_oscillator_strength_summary

      procedure, private :: construct_full_eigenvectors_and_store_converged_states
      procedure, private :: construct_full_eigenvectors_and_assess_convergence
      procedure, private :: calculate_residual_norms_red_unnormalized
      procedure, private :: red_to_full_eigenvector_transformation
      procedure, private :: calculate_residual_norm_full
      procedure, private :: print_convergence_summary

   end type band_lanczos_cc_es


   interface band_lanczos_cc_es

      procedure :: new_band_lanczos_cc_es

   end interface band_lanczos_cc_es


contains


   function new_band_lanczos_cc_es(wf, &
                                   convergence_checker, &
                                   left_start_vector_tool, &
                                   right_start_vector_tool, &
                                   projector, &
                                   records_in_memory, &
                                   max_iterations, &
                                   deflation_threshold, &
                                   overlap_threshold, &
                                   min_energy, &
                                   max_energy, &
                                   min_transition_strength, &
                                   biorthogonalize_last, &
                                   skip_convergence, &
                                   descriptor_L, &
                                   descriptor_R) result(this)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Constructor for the band Lanczos excited state solver. Sets printables
      !! and prints the banner, and sets defaults before reading and printing
      !! settings.
      !!

      implicit none

      type(band_lanczos_cc_es) :: this
      class(ccs), intent(inout), target :: wf

      class(abstract_projection_tool), intent(in) :: projector
      class(convergence_tool), intent(in) :: convergence_checker
      class(es_operator_on_state_start_vector_tool), intent(in) :: left_start_vector_tool, &
                                                                   right_start_vector_tool

      real(dp), intent(in) :: deflation_threshold, overlap_threshold, min_energy, max_energy, &
                              min_transition_strength

      logical, intent(in) :: records_in_memory, skip_convergence

      integer, intent(in) :: max_iterations, biorthogonalize_last
      type(state_descriptor), intent(in) :: descriptor_L, descriptor_R

      this%wf => wf
      this%descriptor_L = descriptor_L
      this%descriptor_R = descriptor_R

      this%iteration_timer = iteration_timings('Band Lanczos iteration', pl='normal')
      this%total_timer = timings(trim(convert_to_uppercase(this%wf%name_)) // ' excited state')
      call this%total_timer%turn_on()

      ! Set printables

      this%name_ = 'Asymmetric band Lanczos excited state solver'
      this%tag = 'Band Lanczos'

      this%description1 = &
         'The band Lanczos solver builds a reduced space banded representation of the CC Jacobian of&
         & dimension defined by the chain length. Diagonalization of this representation gives the&
         & eigenvalues and eigenvectors.'

      this%description2 = 'A complete description of the algorithm can be found in Phys. Rev. A 105, 023103'

      call this%print_banner()

      this%projector = projector
      this%convergence_checker = convergence_checker
      this%records_in_memory = records_in_memory

      this%max_iterations = max_iterations
      this%deflation_threshold = deflation_threshold
      this%overlap_threshold = overlap_threshold
      this%min_energy = min_energy
      this%max_energy = max_energy
      this%min_transition_strength = min_transition_strength
      this%biorthogonalize_last = biorthogonalize_last
      this%skip_convergence = skip_convergence

      this%left_start_vector_tool = left_start_vector_tool
      this%right_start_vector_tool = right_start_vector_tool

      this%V = lanczos_vector_tool(this%wf%n_es_amplitudes, &
                                   'V', &
                                   this%right_start_vector_tool%n_vectors, &
                                   this%left_start_vector_tool%n_vectors, &
                                   max_iterations, &
                                   records_in_memory)

      this%W = lanczos_vector_tool(this%wf%n_es_amplitudes, &
                                   'W', &
                                   this%left_start_vector_tool%n_vectors, &
                                   this%right_start_vector_tool%n_vectors, &
                                   max_iterations, &
                                   records_in_memory)

      call this%print_settings()

      this%storer_L = cc_es_storage_tool(this%max_iterations, wf, this%descriptor_L)
      this%storer_R = cc_es_storage_tool(this%max_iterations, wf, this%descriptor_R)

   end function new_band_lanczos_cc_es


   subroutine run_band_lanczos_cc_es(this)
      !!
      !! Written by Torsha Moitra, Sonia Coriani, Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Runs the asymmetric band Lanczos algorithm in Phys. Rev. A 105, 023103,
      !! based on the algorithm in Acta Numerica 12, 267-319.
      !!
      !! Since the Lanczos vectors can become linearly dependent and
      !! non-orthogonal, the solver includes deflation and biorthogonalization
      !! procedures.
      !!
      !! The starting vectors are based on operators acting on the ground state
      !! and/or states from previous excited state calculations. This allows for
      !! the construction of transition moments/strenghts and oscillator strenghts
      !! in the reduced space, which is generally of a much lower dimension than
      !! the full eigenproblem.
      !!
      !! The solver can assess the convergence of the excited states after the
      !! last band Lanczos iteration, and transform the vectors to the full space.
      !!
      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      integer :: iteration

      real(dp), dimension(:), allocatable :: delta, max_transition_strengths, initial_state_energies, &
                                             energies_re, energies_im
      real(dp), dimension(:), allocatable, target :: T_positive_indices, Ttilde_positive_indices
      real(dp), dimension(:, :), allocatable :: L_start, R_start, L_Dinv_red, R_red
      real(dp), dimension(:, :), pointer :: T, Ttilde

      logical :: no_remaining_deflations, breakdown

      real(dp), external :: ddot

      ! Indices of T and Ttilde can go below 1, use pointer bounds remapping for
      ! compability with mem%alloc and mem%dealloc.

      call mem%alloc(T_positive_indices, &
                     this%max_iterations * (this%max_iterations + this%V%max_deflations), &
                     set_zero=.true.)

      call mem%alloc(Ttilde_positive_indices, &
                     this%max_iterations * (this%max_iterations + this%W%max_deflations), &
                     set_zero=.true.)

      T(1:this%max_iterations, 1 - this%V%max_deflations:this%max_iterations) => T_positive_indices

      Ttilde(1:this%max_iterations, 1 - this%W%max_deflations:this%max_iterations) => Ttilde_positive_indices

      this%n_start_vectors = this%V%max_deflations
      call mem%alloc(initial_state_energies, this%n_start_vectors)

      call mem%alloc(L_start, this%wf%n_es_amplitudes, this%W%max_deflations, set_zero=.true.)
      call mem%alloc(R_start, this%wf%n_es_amplitudes, this%V%max_deflations, set_zero=.true.)

      call this%prepare_start_vector_arrays(L_start, R_start, initial_state_energies)

      ! V and W are the arrays of Lanczos vectors, while the band of m_c+p_c+1
      ! V and W Lanczos vectors adjacent to the first candidate V and W vectors
      ! are stored in V_band and W_band. When deflation occurs, the deflated
      ! vectors are stored in the freed columns of V_band and W_band

      call this%V%initialize(R_start)
      call this%W%initialize(L_start)

      call this%wf%prepare_for_Jacobians(this%descriptor_R)
      call this%wf%prepare_for_Jacobians(this%descriptor_L)

      call mem%alloc(delta, this%max_iterations, set_zero=.true.)

      iteration = 0

      no_remaining_deflations = .false.
      breakdown = .false.

      call this%print_iteration_header()

      do while (iteration < this%max_iterations)

         iteration = iteration + 1
         call this%iteration_timer%turn_on()

         ! Shift all non-deflated vectors down by one

         call this%V%shift_vector_band_indices_down_by_one( &
                 this%V%index_first_candidate_in_band - this%W%remaining_deflations, &
                 this%V%index_first_candidate_in_band + this%V%remaining_deflations &
              )

         call this%W%shift_vector_band_indices_down_by_one( &
                 this%W%index_first_candidate_in_band - this%V%remaining_deflations, &
                 this%W%index_first_candidate_in_band + this%W%remaining_deflations &
              )

         call this%biorthogonalize_first_candidates_against_vectors_outside_band(iteration, delta)

         call this%calculate_first_candidate_norm_and_deflate_if_necessary(iteration, &
                                                                           T, &
                                                                           this%V, &
                                                                           no_remaining_deflations)

         if (no_remaining_deflations) exit

         call this%calculate_first_candidate_norm_and_deflate_if_necessary(iteration, &
                                                                           Ttilde, &
                                                                           this%W, &
                                                                           no_remaining_deflations)

         if (no_remaining_deflations) exit

         ! Normalize the first candidate V and W vectors

         call dscal(this%wf%n_es_amplitudes, &
                    one / T(iteration, iteration - this%V%remaining_deflations), &
                    this%V%vector_band(:, this%V%index_first_candidate_in_band), &
                    1)

         call dscal(this%wf%n_es_amplitudes, &
                    one / Ttilde(iteration, iteration - this%W%remaining_deflations), &
                    this%W%vector_band(:, this%W%index_first_candidate_in_band), &
                    1)

         ! Compute delta(n) = w(n)^T * v(n)

         delta(iteration) = ddot(this%wf%n_es_amplitudes, &
                                 this%W%vector_band(:, this%W%index_first_candidate_in_band), &
                                 1, &
                                 this%V%vector_band(:, this%V%index_first_candidate_in_band), &
                                 1)

         call this%print_iteration_info(iteration, T, Ttilde, delta)

         ! Algorithm breaks down when delta(n) is smaller than overlap threshold

         if (abs(delta(iteration)) < this%overlap_threshold) then

            breakdown = .true.

            exit

         end if

         ! The first candidate vectors are now accepted as Lanczos vectors, and
         ! used for generating new candidate vectors

         call this%biorthogonalize_other_candidates_against_first_candidates(iteration, &
                                                                             T, &
                                                                             Ttilde, &
                                                                             delta)

         call this%generate_and_biorthogonalize_V_candidate(iteration, T, Ttilde, delta)
         call this%generate_and_biorthogonalize_W_candidate(iteration, T, Ttilde, delta)

         ! Store the first candidate vectors

         call this%V%vector_storer%copy_record_in( &
                 this%V%vector_band(:, this%V%index_first_candidate_in_band), &
                 iteration &
              )

         call this%W%vector_storer%copy_record_in( &
                 this%W%vector_band(:, this%W%index_first_candidate_in_band), &
                 iteration &
              )

         call this%iteration_timer%turn_off()

      end do

      if (no_remaining_deflations .or. breakdown) then

         this%n_lanczos_vectors = iteration - 1

      else

         this%n_lanczos_vectors = iteration

      end if

      call mem%dealloc(Ttilde_positive_indices)

      call this%print_iteration_footer(breakdown)

      call mem%alloc(energies_re, this%n_lanczos_vectors)
      call mem%alloc(energies_im, this%n_lanczos_vectors)

      call mem%alloc(L_Dinv_red, this%n_lanczos_vectors, this%n_lanczos_vectors)
      call mem%alloc(R_red, this%n_lanczos_vectors, this%n_lanczos_vectors)

      ! Diagonalize the matrix T to get the reduced space eigenvalues and eigenvectors

      call this%diagonalize_T(T, delta, L_Dinv_red, R_red, energies_re, energies_im)

      call mem%dealloc(T_positive_indices)
      call mem%dealloc(delta)

      call this%print_energy_summary(energies_re, energies_im)

      call mem%dealloc(energies_im)

      call mem%alloc(max_transition_strengths, this%n_lanczos_vectors)

      call this%calculate_and_print_transition_and_oscillator_strengths(max_transition_strengths, &
                                                                        L_start, &
                                                                        R_start, &
                                                                        L_Dinv_red, &
                                                                        R_red, &
                                                                        initial_state_energies, &
                                                                        energies_re)

      call mem%dealloc(initial_state_energies)
      call mem%dealloc(L_start)
      call mem%dealloc(R_start)

      call this%construct_full_eigenvectors_and_store_converged_states(max_transition_strengths, &
                                                                       L_Dinv_red, &
                                                                       R_red, &
                                                                       energies_re)

      call mem%dealloc(L_Dinv_red)
      call mem%dealloc(R_red)

      call mem%dealloc(energies_re)
      call mem%dealloc(max_transition_strengths)

      call this%V%cleanup()
      call this%W%cleanup()

   end subroutine run_band_lanczos_cc_es


   subroutine cleanup_band_lanczos_cc_es(this)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      call this%total_timer%turn_off()

      call output%printf('m', &
                         '- Finished solving the ' // trim(convert_to_uppercase(this%wf%name_)) // &
                            ' excited state equations (both)', &
                         fs='(/t3,a)')

      call this%total_timer%print_to_file(output)

   end subroutine cleanup_band_lanczos_cc_es


   subroutine print_settings(this)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      implicit none

      class(band_lanczos_cc_es) :: this

      call output%printf('m', &
                         '- Settings for coupled cluster excited state solver (' // trim(this%tag) // '):', &
                         fs='(/t3,a)')

      call output%printf('m', 'Excitation vectors: (a0)', chars=['both'], fs='(/t6,a)')

      call output%printf('m', &
                         'Max number of iterations: (i6)', &
                         ints=[this%max_iterations], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Number of right start vectors: m = (i3)', &
                         ints=[this%V%max_deflations], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Number of left start vectors:  p = (i3)', &
                         ints=[this%W%max_deflations], &
                         fs='(t6,a)')

      call this%convergence_checker%print_settings()

   end subroutine print_settings


   subroutine print_banner(this)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      implicit none

      class(band_lanczos_cc_es) :: this

      call output%printf('m', ' - ' // trim(this%name_), fs='(/t3,a)')
      call output%print_separator('m', len(trim(this%name_)) + 6, '-')

      call output%printf('n', this%description1, ffs='(/t3,a)', fs='(t3,a)')
      call output%printf('n', this%description2, ffs='(/t3,a)', fs='(t3,a)')

   end subroutine print_banner


   subroutine print_iteration_header()
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      implicit none

      call output%printf('m', '- Band Lanczos iterations:', fs='(/t3,a)')

      call output%printf('m', &
                         'Iteration  pc  mc   |Lanczos W|   |Lanczos V|   WV/(|W||V|)  Deflation', &
                         fs='(/t6,a)')

      call output%print_separator('m', 70, '-', fs='(t6,a)')

   end subroutine print_iteration_header


   subroutine print_iteration_info(this, iteration, T, Ttilde, delta)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Prints the iteration number, the remaining W and V deflations, the
      !! 2-norms of the first candidate W and V vectors, and their normalized overlaps.
      !!
      implicit none

      class(band_lanczos_cc_es) :: this

      integer, intent(in) :: iteration

      real(dp), dimension(this%max_iterations, 1 - this%V%max_deflations:this%max_iterations), intent(in) :: T
      real(dp), dimension(this%max_iterations, 1 &
         - this%W%max_deflations:this%max_iterations), intent(in) :: Ttilde
      real(dp), dimension(this%max_iterations), intent(in) :: delta

      call output%printf('m', &
                         '(i9) (i3) (i3) (e13.6) (e13.6) (e13.6)', &
                         ints=[iteration, this%W%remaining_deflations, this%V%remaining_deflations], &
                         reals=[Ttilde(iteration, iteration - this%W%remaining_deflations), &
                            T(iteration, iteration - this%V%remaining_deflations), &
                            delta(iteration)], &
                         fs='(t6,a)', &
                         ll=500)

   end subroutine print_iteration_info


   subroutine print_deflation_info(this, iteration, T_or_Ttilde, vector_tool)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Prints the iteration number, the remaining W and V deflations, the
      !! 2-norm of the deflated vector, and whether this vector belongs to W or V.
      !!
      implicit none

      class(band_lanczos_cc_es) :: this

      class(lanczos_vector_tool), intent(in) :: vector_tool

      integer, intent(in) :: iteration

      real(dp), dimension(this%max_iterations, 1 &
         - vector_tool%max_deflations:this%max_iterations), intent(in) :: T_or_Ttilde

      if (vector_tool%V_or_W == 'V') then

         call output%printf('m', &
                            '(i9) (i3) (i3)               (e13.6)                        V', &
                            ints=[iteration, this%W%remaining_deflations, this%V%remaining_deflations], &
                            reals=[T_or_Ttilde(iteration, iteration - vector_tool%remaining_deflations)], &
                            fs='(t6,a)', &
                            ll=500)

      elseif (vector_tool%V_or_W == 'W') then

         call output%printf('m', &
                            '(i9) (i3) (i3) (e13.6)                                      W', &
                            ints=[iteration, this%W%remaining_deflations, this%V%remaining_deflations], &
                            reals=[T_or_Ttilde(iteration, iteration - vector_tool%remaining_deflations)], &
                            fs='(t6,a)', &
                            ll=500)

      end if

   end subroutine print_deflation_info


   subroutine print_iteration_footer(this, breakdown)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      implicit none

      class(band_lanczos_cc_es), intent(in) :: this

      logical, intent(in) :: breakdown

      call output%print_separator('m', 70, '-', fs='(t6,a)')

      call output%printf('m', &
                         'Final reduced space dimension: (i0)', &
                         ints=[this%n_lanczos_vectors], &
                         fs='(/t6,a)')

      if (this%V%remaining_deflations == 0) &
         call output%printf('m', 'Note: early exit due to full V deflation.', fs='(/t6,a)')

      if (this%W%remaining_deflations == 0) &
         call output%printf('m', 'Note: early exit due to full W deflation.', fs='(/t6,a)')

      if (breakdown) &
         call output%warning_msg('breakdown, overlap value smaller than threshold (e11.4)', &
                                 reals=[this%overlap_threshold])

   end subroutine print_iteration_footer


   subroutine print_energy_summary(this, energies_re, energies_im)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021
      !!
      !! Prints the excited state energies that are between the minimum and
      !! maximum energies of the solver.
      !!
      implicit none

      class(band_lanczos_cc_es), intent(in) :: this

      real(dp), dimension(this%n_lanczos_vectors), intent(in) :: energies_re, energies_im

      integer :: f

      call output%printf('m', '- Energies:', fs='(/t3,a)')

      call output%print_separator('minimal', 81, '-', fs='(/t6,a)')

      call output%printf('m', &
         'State     Energy Re (eV)     Energy Im (eV)   Energy Re (a.u.)   Energy Im (a.u.)', fs = '(t6,a)', &
         ll = 500)

      call output%print_separator('minimal', 81, '-', fs='(t6,a)')

      do f = 1, this%n_lanczos_vectors
         if ((energies_re(f) >= this%min_energy) .and. (energies_re(f) <= this%max_energy)) then

            call output%printf('m', &
                               '(i5) (f18.12) (f18.12) (f18.12) (f18.12)', &
                               ints=[f], &
                               reals=[energies_re(f) * Hartree_to_eV, &
                                  energies_im(f) * Hartree_to_eV, &
                                  energies_re(f), &
                                  energies_im(f)], &
                               fs='(t6,a)', &
                               ll=500)

         end if
      end do

      call output%print_separator('minimal', 81, '-', fs='(t6,a)')

   end subroutine print_energy_summary


   subroutine print_transition_strength_summary(this, &
                                                transition_strengths, &
                                                initial_state_energies, &
                                                energies_re)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Prints the transition strenghts of the states with energies between the
      !! minimum and maximum energies of the solver.
      !!
      implicit none

      class(band_lanczos_cc_es), intent(in) :: this

      real(dp), dimension(this%n_lanczos_vectors, this%n_start_vectors), intent(in) :: transition_strengths

      real(dp), dimension(this%n_start_vectors), intent(in) :: initial_state_energies
      real(dp), dimension(this%n_lanczos_vectors), intent(in) :: energies_re

      integer :: i, o, f, start_vector

      character(len = 2), dimension(10) :: operator_string = &
         ['U ', 'X ', 'Y ', 'Z ', 'XX', 'XY', 'XZ', 'YY', 'YZ', 'ZZ']

      call output%printf('m', '- Transition strengths:', fs='(/t3,a)')

      call output%print_separator('minimal', 64, '-', fs='(/t6,a)')

      call output%printf('m', &
                         'State i  Operator  State f   Exc. energy (Ha)    Transition str.', &
                         fs='(t6,a)', &
                         ll=500)

      call output%print_separator('minimal', 64, '-', fs='(t6,a)')

      do start_vector = 1, this%n_start_vectors
         do f = 1, this%n_lanczos_vectors

            if ((energies_re(f) >= this%min_energy) .and. (energies_re(f) <= this%max_energy)) then

               i = this%right_start_vector_tool%restart_state_indices(start_vector)
               o = this%right_start_vector_tool%operator_indices(start_vector)

               call output%printf('m', &
                                  '(i7) (a9) (i8) (f18.12) (f18.12)', &
                                  ints=[i, f], &
                                  chars=[trim(operator_string(o + 1))], &
                                  reals=[energies_re(f) - initial_state_energies(start_vector), &
                                     transition_strengths(f, start_vector)], &
                                  fs='(t6,a)')

            end if
         end do
      end do

      call output%print_separator('minimal', 64, '-', fs='(t6,a)')

   end subroutine print_transition_strength_summary


   subroutine print_oscillator_strength_summary(this, &
                                                oscillator_strengths, &
                                                oscillator_strength_start_vectors, &
                                                n_oscillator_strengths, &
                                                initial_state_energies, &
                                                energies_re)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Prints the oscillator strenghts of the states with energies between the
      !! minimum and maximum energies of the solver.
      !!
      implicit none

      class(band_lanczos_cc_es), intent(in) :: this

      integer, intent(in) :: n_oscillator_strengths

      integer, dimension(n_oscillator_strengths), intent(in) :: oscillator_strength_start_vectors
      real(dp), dimension(this%n_lanczos_vectors, n_oscillator_strengths), intent(in) :: oscillator_strengths

      real(dp), dimension(this%n_start_vectors), intent(in) :: initial_state_energies
      real(dp), dimension(this%n_lanczos_vectors), intent(in) :: energies_re

      integer :: j, i, f, start_vector

      call output%printf('m', '- Oscillator strengths:', fs='(/t3,a)')

      call output%print_separator('minimal', 54, '-', fs='(/t6,a)')

      call output%printf('m', &
                         'State i  State f   Exc. energy (Ha)    Oscillator str.', &
                         fs='(t6,a)', &
                         ll=500)

      call output%print_separator('minimal', 54, '-', fs='(t6,a)')

      do j = 1, n_oscillator_strengths

         do f = 1, this%n_lanczos_vectors

            if ((energies_re(f) >= this%min_energy) .and. (energies_re(f) <= this%max_energy)) then

               start_vector = oscillator_strength_start_vectors(j)
               i = this%right_start_vector_tool%restart_state_indices(start_vector)

               call output%printf('m', &
                                  '(i7) (i8) (f18.12) (f18.12)', &
                                  ints=[i, f], &
                                  reals=[energies_re(f) - initial_state_energies(start_vector), &
                                     oscillator_strengths(f, j)], &
                                  fs='(t6,a)')

            end if
         end do
      end do

      call output%print_separator('minimal', 54, '-', fs='(t6,a)')

   end subroutine print_oscillator_strength_summary


   subroutine print_convergence_summary(this, &
                                        state_saved, &
                                        state_has_requested_properties, &
                                        L_residual_norms_red, &
                                        R_residual_norms_red, &
                                        L_residual_norms_full, &
                                        R_residual_norms_full, &
                                        max_transition_strengths, &
                                        energies_re)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Prints the reduced and full space residuals together with the excitation
      !! energies and maximum transition strengths of all states in the
      !! calculation, and whether the state has been saved or not.
      !!
      implicit none

      class(band_lanczos_cc_es), intent(in) :: this

      logical, dimension(this%n_lanczos_vectors), intent(in) :: state_saved, state_has_requested_properties

      integer :: n_converged_R, n_converged_L

      real(dp), dimension(this%n_lanczos_vectors), intent(in) :: L_residual_norms_red, R_residual_norms_red, &
                                                                 L_residual_norms_full, &
                                                                 R_residual_norms_full, &
                                                                 max_transition_strengths, energies_re

      integer :: f

      character(len=7) :: saved_string


      call output%printf('m', '- Convergence:', fs='(/t3,a)')
      call output%print_separator('m', 110, '-', fs='(/t6,a)')

      call output%printf('m', &
                         'State   Exc. energy (Ha)  |Red. L res.|  |Full L res.|  |Red. R res.|  |Full R res.&
                         &|    Max trans. str.  Saved', &
                         fs='(t6,a)', &
                         ll=500)

      call output%print_separator('m', 110, '-', fs='(t6,a)')

      n_converged_R = 0
      n_converged_L = 0

      do f = 1, this%n_lanczos_vectors

         if (state_saved(f)) then
            saved_string = '      X'
         else
            saved_string = '       '
         end if

         if (.not. state_has_requested_properties(f)) then

            call output%printf('m', &
                               '(i5) (f18.12)              -              -              -              - (&
                                  &f18.12)' &
                                  // saved_string, &
                               ints=[f], &
                               reals=[energies_re(f), max_transition_strengths(f)], &
                               fs='(t6,a)', &
                               ll=500)

         elseif (this%skip_convergence) then

            call output%printf('m', &
                               '(i5) (f18.12) (e14.6)              - (e14.6)              - (f18.12)' // &
                                  saved_string, &
                               ints=[f], &
                               reals=[energies_re(f), &
                                  L_residual_norms_red(f), &
                                  R_residual_norms_red(f), &
                                  max_transition_strengths(f)], &
                               fs='(t6,a)', &
                               ll=500)

         else

            call output%printf('m', &
                               '(i5) (f18.12) (e14.6) (e14.6) (e14.6) (e14.6) (f18.12)' // saved_string, &
                               ints=[f], &
                               reals=[energies_re(f), &
                                  L_residual_norms_red(f), &
                                  L_residual_norms_full(f), &
                                  R_residual_norms_red(f), &
                                  R_residual_norms_full(f), &
                                  max_transition_strengths(f)], &
                               fs='(t6,a)', &
                               ll=500)

         end if


         ! Count the number of converged states

         if (state_has_requested_properties(f) .and. .not. this%skip_convergence) then

            if (abs(R_residual_norms_full(f)) < this%convergence_checker%residual_threshold) then

               n_converged_R = n_converged_R + 1

            end if

            if (abs(L_residual_norms_full(f)) < this%convergence_checker%residual_threshold) then

               n_converged_L = n_converged_L + 1

            end if

         end if

      end do

      call output%print_separator('m', 110, '-', fs='(t6,a)')

      call output%printf('m', &
                         'Converged (i0) right and (i0) left vectors with the requested properties.', &
                         ints=[n_converged_R, n_converged_L], &
                         fs='(/t6,a)')

      if (n_converged_R /= n_converged_L) &
         call output%warning_msg('converged different numbers of right and left vectors.')

      if (this%n_states == 0) then

         call output%warning_msg( &
                 'no right and left vector pairs converged with the current chain length.' &
              )

      else

         call output%printf('m', &
                            'Saved (i0) states.', &
                            ints=[this%n_states], &
                            fs='(/t6,a)')

      end if

   end subroutine print_convergence_summary


   subroutine prepare_start_vector_arrays(this, L_start, R_start, initial_state_energies)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      real(dp), dimension(this%wf%n_es_amplitudes, this%W%max_deflations), intent(out) :: L_start
      real(dp), dimension(this%wf%n_es_amplitudes, this%V%max_deflations), intent(out) :: R_start

      real(dp), dimension(this%n_start_vectors), intent(out) :: initial_state_energies

      integer :: start_vector

      do start_vector = 1, this%n_start_vectors

         call this%left_start_vector_tool%get(L_start(:, start_vector), &
                                              start_vector, &
                                              initial_state_energies(start_vector))

         call this%right_start_vector_tool%get(R_start(:, start_vector), &
                                               start_vector, &
                                               initial_state_energies(start_vector))

         call this%projector%project(L_start(:, start_vector))
         call this%projector%project(R_start(:, start_vector))

      end do

   end subroutine prepare_start_vector_arrays


   subroutine calculate_first_candidate_norm_and_deflate_if_necessary(this, &
                                                                      iteration, &
                                                                      T_or_Ttilde, &
                                                                      vector_tool, &
                                                                      no_remaining_deflations)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      integer, intent(in) :: iteration

      class(lanczos_vector_tool), intent(inout) :: vector_tool
      logical, intent(out) :: no_remaining_deflations

      real(dp), dimension(1:this%max_iterations, 1 &
         - vector_tool%max_deflations:this%max_iterations), intent(inout) :: T_or_Ttilde

      ! Store norm of current vector in T or Ttilde

      T_or_Ttilde(iteration, iteration - vector_tool%remaining_deflations) = &
         get_l2_norm(vector_tool%vector_band(:, vector_tool%index_first_candidate_in_band), &
                     vector_tool%n_parameters)

      ! Deflate vector band if norm of current vector is smaller than deflation threshold

      do while (T_or_Ttilde(iteration, &
                iteration - vector_tool%remaining_deflations) < this%deflation_threshold)

         call this%print_deflation_info(iteration, T_or_Ttilde, vector_tool)

         call vector_tool%deflate_vector_band(iteration, no_remaining_deflations)

         if (no_remaining_deflations) exit

         ! Store norm of new current vector after deflation in T or Ttilde

         T_or_Ttilde(iteration, iteration - vector_tool%remaining_deflations) = &
            get_l2_norm(vector_tool%vector_band(:, vector_tool%index_first_candidate_in_band), &
                        vector_tool%n_parameters)

      end do

   end subroutine calculate_first_candidate_norm_and_deflate_if_necessary


   subroutine biorthogonalize_first_candidates_against_vectors_outside_band(this, iteration, delta)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Biorthogonalizes first candidate V and W vectors against vectors outside
      !! band.
      !!
      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      integer, intent(in) :: iteration

      real(dp), dimension(this%max_iterations), intent(in) :: delta

      integer :: k

      real(dp), dimension(:), allocatable :: V_k, W_k

      real(dp) :: overlap

      real(dp), external :: ddot

      call mem%alloc(V_k, this%wf%n_es_amplitudes)
      call mem%alloc(W_k, this%wf%n_es_amplitudes)

      do k = max(1, iteration - this%biorthogonalize_last + 1), &
             max(iteration - this%W%remaining_deflations, iteration - this%V%remaining_deflations, 1) - 1

         call this%W%vector_storer%copy_record_out(W_k, k)
         call this%V%vector_storer%copy_record_out(V_k, k)

         if (k <= max(1, iteration - this%W%remaining_deflations) - 1) then

            overlap = &
                      ddot(this%wf%n_es_amplitudes, W_k, 1, &
                      this%V%vector_band(:, this%V%index_first_candidate_in_band), 1) / delta(k)

            call daxpy(this%wf%n_es_amplitudes, &
                       - overlap, &
                       V_k, &
                       1, &
                       this%V%vector_band(:, this%V%index_first_candidate_in_band), &
                       1)

         end if

         if (k <= max(1, iteration - this%V%remaining_deflations) - 1) then

            overlap = &
                      ddot(this%wf%n_es_amplitudes, &
                      this%W%vector_band(:, this%W%index_first_candidate_in_band), 1, V_k, 1) / delta(k)

            call daxpy(this%wf%n_es_amplitudes, &
                       - overlap, &
                       W_k, &
                       1, &
                       this%W%vector_band(:, this%W%index_first_candidate_in_band), &
                       1)

         end if

      end do

      call mem%dealloc(V_k)
      call mem%dealloc(W_k)

   end subroutine biorthogonalize_first_candidates_against_vectors_outside_band


   subroutine biorthogonalize_other_candidates_against_first_candidates(this, &
                                                                        iteration, &
                                                                        T, &
                                                                        Ttilde, &
                                                                        delta)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Elements below the diagonal of T and Ttilde are constructed, and the
      !! other candidate vectors are biorthogonalized against the first candidate
      !! V and W vectors.
      !!
      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      integer, intent(in) :: iteration

      real(dp), dimension(this%max_iterations, 1 &
         - this%V%max_deflations:this%max_iterations), intent(inout) :: T
      real(dp), dimension(this%max_iterations, 1 &
         - this%W%max_deflations:this%max_iterations), intent(inout) :: Ttilde

      real(dp), dimension(this%max_iterations), intent(in) :: delta

      integer :: k

      real(dp), external :: ddot

      ! Elements below the diagonal of T are constructed, and other V candidates
      ! biorthogonalized against first candidate W vector

      do k = 1 - this%V%remaining_deflations, - 1

         T(iteration, iteration + k) = &
                                       ddot(this%wf%n_es_amplitudes, &
                                       this%W%vector_band(:, this%W%index_first_candidate_in_band), 1, &
                                       this%V%vector_band(:, &
                                       this%V%index_first_candidate_in_band + this%V%remaining_deflations &
                                       + k), 1) / delta(iteration)

         call daxpy(this%wf%n_es_amplitudes, &
                    - T(iteration, iteration + k), &
                    this%V%vector_band(:, this%V%index_first_candidate_in_band), &
                    1, &
                    this%V%vector_band(:, &
                       this%V%index_first_candidate_in_band + this%V%remaining_deflations + k), &
                    1)

      end do

      ! Elements below the diagonal of Ttilde are constructed, and other W
      ! candidates biorthogonalized against first candidate V vector

      do k = 1 - this%W%remaining_deflations, - 1

         Ttilde(iteration, iteration + k) = &
                                            ddot(this%wf%n_es_amplitudes, &
                                            this%W%vector_band(:, &
                                            this%W%index_first_candidate_in_band &
                                            + this%W%remaining_deflations + k), 1, &
                                            this%V%vector_band(:, this%V%index_first_candidate_in_band), 1) &
                                            / delta(iteration)

         call daxpy(this%wf%n_es_amplitudes, &
                    - Ttilde(iteration, iteration + k), &
                    this%W%vector_band(:, this%W%index_first_candidate_in_band), &
                    1, &
                    this%W%vector_band(:, &
                       this%W%index_first_candidate_in_band + this%W%remaining_deflations + k), &
                    1)

      end do

   end subroutine biorthogonalize_other_candidates_against_first_candidates


   subroutine generate_and_biorthogonalize_V_candidate(this, iteration, T, Ttilde, delta)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      integer, intent(in) :: iteration

      real(dp), dimension(this%max_iterations, 1 &
         - this%V%max_deflations:this%max_iterations), intent(inout) :: T
      real(dp), dimension(this%max_iterations, 1 &
         - this%W%max_deflations:this%max_iterations), intent(inout) :: Ttilde

      real(dp), dimension(this%max_iterations), intent(in) :: delta

      real(dp) :: sigmatilde

      integer :: k, deflation_index

      real(dp), external :: ddot

      ! Make new candidate V vector ^v(n+m_c) by the transformation
      !    ^v(n+m_c) = Av(n)

      call this%wf%jacobian_transformation(this%V%vector_band(:, this%V%index_first_candidate_in_band), &
                                           this%V%vector_band(:, &
                                              this%V%index_first_candidate_in_band &
                                              + this%V%remaining_deflations))

      call this%projector%project(this%V%vector_band(:, &
         this%V%index_first_candidate_in_band + this%V%remaining_deflations))

      ! Biorthogonalize the new V candidate against deflated vectors listed in
      ! deflation_locations

      do k = 1, this%max_iterations - 1
         if (.not. any(this%W%deflation_locations == k)) cycle

         deflation_index = findloc(this%W%deflation_locations, k, 1)

         ! Deflated W vectors are stored in the last columns of W%vector_band

         sigmatilde = ddot(this%wf%n_es_amplitudes, &
                           this%W%vector_band(:, this%W%band_length + 1 - deflation_index), &
                           1, &
                           this%V%vector_band(:, this%V%index_first_candidate_in_band), &
                           1)

         Ttilde(iteration, k) = sigmatilde / delta(iteration)

         ! Corresponding V vectors are stored in the first columns of V%vector_band

         T(k, iteration) = sigmatilde / delta(k)

         call daxpy(this%wf%n_es_amplitudes, &
                    - T(k, iteration), &
                    this%V%vector_band(:, deflation_index), &
                    1, &
                    this%V%vector_band(:, &
                       this%V%index_first_candidate_in_band + this%V%remaining_deflations), &
                    1)

      end do

      ! Elements above the diagonal of T are constructed, and the new V candidate
      ! is biorthogonalized against W vectors in the lower part of the band
      !    T(k,n) = (w(k)^T * ^v(n+m_c)) / delta(k)
      !    ^v(n+m_c) = ^v(n+m_c) - v(k)T(k,n)
      ! Note that the lower band vectors w(k) are biorthogonal to previous
      ! vectors, meaning that the equation for T(k,n) should still hold after
      ! future biorthogonalization of ^v(n+m_c) against the same vectors.

      do k = max(1 - iteration, - this%W%remaining_deflations), - 1

         T(iteration + k, iteration) = Ttilde(iteration, iteration + k) &
                                       * delta(iteration) / delta(iteration + k)

         call daxpy(this%wf%n_es_amplitudes, &
                    - T(iteration + k, iteration), &
                    this%V%vector_band(:, this%V%index_first_candidate_in_band + k), &
                    1, &
                    this%V%vector_band(:, &
                       this%V%index_first_candidate_in_band + this%V%remaining_deflations), &
                    1)

      end do

      T(iteration, iteration) = &
                                ddot(this%wf%n_es_amplitudes, &
                                this%W%vector_band(:, this%W%index_first_candidate_in_band), 1, &
                                this%V%vector_band(:, &
                                this%V%index_first_candidate_in_band + this%V%remaining_deflations), 1) / &
                                delta(iteration)

      call daxpy(this%wf%n_es_amplitudes, &
                 - T(iteration, iteration), &
                 this%V%vector_band(:, this%V%index_first_candidate_in_band), &
                 1, &
                 this%V%vector_band(:, this%V%index_first_candidate_in_band + this%V%remaining_deflations), &
                 1)

   end subroutine generate_and_biorthogonalize_V_candidate


   subroutine generate_and_biorthogonalize_W_candidate(this, iteration, T, Ttilde, delta)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      implicit none

      integer, intent(in) :: iteration

      class(band_lanczos_cc_es), intent(inout) :: this

      real(dp), dimension(this%max_iterations, 1 &
         - this%V%max_deflations:this%max_iterations), intent(inout) :: T
      real(dp), dimension(this%max_iterations, 1 &
         - this%W%max_deflations:this%max_iterations), intent(inout) :: Ttilde

      real(dp), dimension(this%max_iterations), intent(in) :: delta

      real(dp) :: sigma

      integer :: k, deflation_index

      real(dp), external :: ddot

      ! Make new W candidate vector ^w(n+p_c) by the transformation
      !    ^w(n+p_c) = A^T w(n)

      call this%wf%jacobian_transpose_transformation( &
              this%W%vector_band(:, this%W%index_first_candidate_in_band), &
              this%W%vector_band(:, this%W%index_first_candidate_in_band + this%W%remaining_deflations) &
           )

      call this%projector%project(this%W%vector_band(:, &
         this%W%index_first_candidate_in_band + this%W%remaining_deflations))

      ! Biorthogonalize the new W candidate against deflated vectors listed in
      ! deflation_locations

      do k = 1, this%max_iterations - 1
         if (.not. any(this%V%deflation_locations == k)) cycle

         deflation_index = findloc(this%V%deflation_locations, k, 1)

         ! Deflated V vectors are stored in the last columns of V%vector_band

         sigma = ddot(this%wf%n_es_amplitudes, &
                      this%W%vector_band(:, this%W%index_first_candidate_in_band), &
                      1, &
                      this%V%vector_band(:, this%V%band_length + 1 - deflation_index), &
                      1)

         T(iteration, k) = sigma / delta(iteration)

         ! Corresponding W vectors are stored in the first columns of W%vector_band

         Ttilde(k, iteration) = sigma / delta(k)

         call daxpy(this%wf%n_es_amplitudes, &
                    - Ttilde(k, iteration), &
                    this%W%vector_band(:, deflation_index), &
                    1, &
                    this%W%vector_band(:, &
                       this%W%index_first_candidate_in_band + this%W%remaining_deflations), &
                    1)

      end do

      ! Elements above the diagonal of Ttilde are constructed, and the new W
      ! candidate is biorthogonalized against V vectors in the lower part of the
      ! band
      !    ^T(k,n) = (^w(n+p_c)^T * v(k)) / delta(k)
      !    ^w(n+p_c) = ^w(n+p_c) - w(k) ^T(k,n)
      ! Note that the lower band vectors v(k) are biorthogonal to previous
      ! vectors, meaning that the equation for ^T(k,n) should still hold after
      ! future biorthogonalization of ^w(n+p_c)^T against the same vectors.

      do k = max(1 - iteration, - this%V%remaining_deflations), - 1

         Ttilde(iteration + k, iteration) = T(iteration, iteration + k) &
                                            * delta(iteration) / delta(iteration + k)

         call daxpy(this%wf%n_es_amplitudes, &
                    - Ttilde(iteration + k, iteration), &
                    this%W%vector_band(:, this%W%index_first_candidate_in_band + k), &
                    1, &
                    this%W%vector_band(:, &
                       this%W%index_first_candidate_in_band + this%W%remaining_deflations), &
                    1)

      end do

      Ttilde(iteration, iteration) = T(iteration, iteration)

      call daxpy(this%wf%n_es_amplitudes, &
                 - Ttilde(iteration, iteration), &
                 this%W%vector_band(:, this%W%index_first_candidate_in_band), &
                 1, &
                 this%W%vector_band(:, this%W%index_first_candidate_in_band + this%W%remaining_deflations), &
                 1)

   end subroutine generate_and_biorthogonalize_W_candidate


   subroutine diagonalize_T(this, T, delta, L_Dinv_red, R_red, energies_re, energies_im)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Diagonalize T(1:this%n_lanczos_vectors,1:this%n_lanczos_vectors) in
      !! order to get eigenvalues and reduced space eigenvectors from the band
      !! Lanczos calculation. The left reduced space eigenvectors are transformed
      !! by the inverse of the delta matrix and binormalized with the right
      !! reduced space vectors, in order to get vectors that can be transformed
      !! back to the full space.
      !!
      use array_utilities, only: quicksort_with_index_ascending

      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      real(dp), dimension(this%max_iterations, 1 - this%V%max_deflations:this%max_iterations), intent(in) :: T
      real(dp), dimension(this%max_iterations), intent(in) :: delta

      real(dp), dimension(this%n_lanczos_vectors, this%n_lanczos_vectors), intent(out) :: L_Dinv_red, R_red

      real(dp), dimension(this%n_lanczos_vectors), intent(out) :: energies_re, energies_im

      real(dp) :: overlap
      real(dp), dimension(:), allocatable :: energies_im_unsorted, work
      real(dp), dimension(:, :), allocatable :: L_red_unsorted, R_red_unsorted, T_pr

      integer :: lwork, info, i, k
      integer, dimension(:), allocatable :: index_list

      real(dp), external :: ddot

      call mem%alloc(energies_im_unsorted, this%n_lanczos_vectors)
      call mem%alloc(L_red_unsorted, this%n_lanczos_vectors, this%n_lanczos_vectors)
      call mem%alloc(R_red_unsorted, this%n_lanczos_vectors, this%n_lanczos_vectors)

      call mem%alloc(T_pr, this%n_lanczos_vectors, this%n_lanczos_vectors)
      T_pr = T(1:this%n_lanczos_vectors, 1:this%n_lanczos_vectors)

      lwork = 2 * this%n_lanczos_vectors**2
      call mem%alloc(work, lwork)

      call dgeev('V', &
                 'V', &
                 this%n_lanczos_vectors, &
                 T_pr, &
                 this%n_lanczos_vectors, &
                 energies_re, &
                 energies_im_unsorted, &
                 L_red_unsorted, &
                 this%n_lanczos_vectors, &
                 R_red_unsorted, &
                 this%n_lanczos_vectors, &
                 work, &
                 lwork, &
                 info)

      call mem%dealloc(T_pr)

      call output%printf('m', 'T matrix diagonalization done', fs='(/t6,a)')

      if (info /= 0) then

         call output%error_msg('Diagonalization of T ended with error: (i0)', ints=[info])

      end if

      call mem%dealloc(work)

      ! Sort eigenvalues and save an index list for later reference

      call mem%alloc(index_list, this%n_lanczos_vectors)
      call quicksort_with_index_ascending(energies_re, index_list, this%n_lanczos_vectors)

      do k = 1, this%n_lanczos_vectors
         energies_im(k) = energies_im_unsorted(index_list(k))
      end do

      call mem%dealloc(energies_im_unsorted)

      ! Binormalize before transforming back to orthonormalized basis

      do k = 1, this%n_lanczos_vectors

         overlap = ddot(this%n_lanczos_vectors, &
                        L_red_unsorted(:, index_list(k)), &
                        1, &
                        R_red_unsorted(:, index_list(k)), &
                        1)

         !$omp parallel do private(i)
         do i = 1, this%n_lanczos_vectors
            L_Dinv_red(i, k) = L_red_unsorted(i, index_list(k)) / (overlap * delta(i))
         end do
         !$omp end parallel do

         R_red(:, k) = R_red_unsorted(:, index_list(k))

      end do

      call mem%dealloc(L_red_unsorted)
      call mem%dealloc(R_red_unsorted)
      call mem%dealloc(index_list)

   end subroutine diagonalize_T


   subroutine calculate_and_print_transition_and_oscillator_strengths(this, &
                                                                      max_transition_strengths, &
                                                                      L_start, &
                                                                      R_start, &
                                                                      L_Dinv_red, &
                                                                      R_red, &
                                                                      initial_state_energies, &
                                                                      energies_re)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      real(dp), dimension(this%n_lanczos_vectors), intent(out) :: max_transition_strengths

      real(dp), dimension(:, :), allocatable :: transition_strengths

      real(dp), dimension(this%wf%n_es_amplitudes, this%W%max_deflations), intent(in) :: L_start
      real(dp), dimension(this%wf%n_es_amplitudes, this%V%max_deflations), intent(in) :: R_start

      real(dp), dimension(this%n_start_vectors), intent(in) :: initial_state_energies
      real(dp), dimension(this%n_lanczos_vectors), intent(in) :: energies_re

      real(dp), dimension(this%n_lanczos_vectors, this%n_lanczos_vectors), intent(in) :: L_Dinv_red, R_red

      call mem%alloc(transition_strengths, this%n_lanczos_vectors, this%n_start_vectors)

      call this%calculate_transition_strengths(transition_strengths, &
                                               max_transition_strengths, &
                                               L_start, &
                                               R_start, &
                                               L_Dinv_red, &
                                               R_red)

      call this%print_transition_strength_summary(transition_strengths, &
                                                  initial_state_energies, &
                                                  energies_re)

      call this%calculate_and_print_oscillator_strengths(transition_strengths, &
                                                         initial_state_energies, &
                                                         energies_re)

      call mem%dealloc(transition_strengths)

   end subroutine calculate_and_print_transition_and_oscillator_strengths


   subroutine calculate_transition_strengths(this, &
                                             transition_strengths, &
                                             max_transition_strengths, &
                                             L_start, &
                                             R_start, &
                                             L_Dinv_red, &
                                             R_red)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2021
      !!
      !! Constructs the transition strengths to the final states for the different
      !! initial state and operator combinations.
      !!
      use array_initialization, only: copy_subblock
      use range_class, only: range_

      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      real(dp), dimension(this%n_lanczos_vectors, this%n_start_vectors), intent(out) :: transition_strengths

      real(dp), dimension(this%n_lanczos_vectors), intent(out) :: max_transition_strengths

      real(dp), dimension(this%n_lanczos_vectors, this%n_lanczos_vectors), intent(in) :: L_Dinv_red, R_red

      real(dp), dimension(this%wf%n_es_amplitudes, this%W%max_deflations), intent(in) :: L_start
      real(dp), dimension(this%wf%n_es_amplitudes, this%V%max_deflations), intent(in) :: R_start

      real(dp), dimension(:, :), allocatable :: L_start_dot_first_V, first_W_dot_R_start

      real(dp), dimension(:, :), allocatable :: Lf_Ri_transition_moments, Li_Rf_transition_moments, subblock

      integer :: i, f, start_vector

      real(dp), dimension(:), allocatable :: vector

      real(dp), external :: ddot

      type(range_) :: p_range, q_range

      ! Overlaps of the first Lanczos vectors and start vectors are needed for
      ! calculating transition strengths from reduced space eigenvectors, since
      ! biorthogonalization implies that the first Lanczos vectors can be
      ! different from the starting vectors.

      call mem%alloc(L_start_dot_first_V, this%n_start_vectors, this%n_start_vectors)
      call mem%alloc(first_W_dot_R_start, this%n_start_vectors, this%n_start_vectors)

      call mem%alloc(vector, this%wf%n_es_amplitudes)

      do i = 1, this%n_start_vectors
         do f = 1, this%n_start_vectors

            call this%V%vector_storer%copy_record_out(vector, f)
            L_start_dot_first_V(i, f) = ddot(this%wf%n_es_amplitudes, L_start(:, i), 1, vector, 1)

            call this%W%vector_storer%copy_record_out(vector, f)
            first_W_dot_R_start(f, i) = ddot(this%wf%n_es_amplitudes, vector, 1, R_start(:, i), 1)

         end do
      end do

      call mem%dealloc(vector)

      call output%print_matrix('v', &
                               'Start L (row) dot first V (column) vectors', &
                               L_start_dot_first_V, &
                               this%n_start_vectors, &
                               this%n_start_vectors)

      call output%print_matrix('v', &
                               'First W (row) dot start R (column) vectors', &
                               L_start_dot_first_V, &
                               this%n_start_vectors, &
                               this%n_start_vectors)

      call mem%alloc(Lf_Ri_transition_moments, this%n_lanczos_vectors, this%n_start_vectors)
      call mem%alloc(Li_Rf_transition_moments, this%n_start_vectors, this%n_lanczos_vectors)

      ! Calculate transition moments

      p_range = range_(1, this%n_start_vectors)
      q_range = range_(1, this%n_lanczos_vectors)

      call mem%alloc(subblock, this%n_start_vectors, this%n_lanczos_vectors)
      call copy_subblock(L_Dinv_red, subblock, p_range, q_range)

      call dgemm('T', &
                 'N', &
                 this%n_lanczos_vectors, &
                 this%n_start_vectors, &
                 this%n_start_vectors, &
                 one, &
                 subblock, &
                 this%n_start_vectors, &
                 first_W_dot_R_start, &
                 this%n_start_vectors, &
                 zero, &
                 Lf_Ri_transition_moments, &
                 this%n_lanczos_vectors)

      call copy_subblock(R_red, subblock, p_range, q_range)

      call dgemm('N', &
                 'N', &
                 this%n_start_vectors, &
                 this%n_lanczos_vectors, &
                 this%n_start_vectors, &
                 one, &
                 L_start_dot_first_V, &
                 this%n_start_vectors, &
                 subblock, &
                 this%n_start_vectors, &
                 zero, &
                 Li_Rf_transition_moments, &
                 this%n_start_vectors)

      call mem%dealloc(subblock)
      call mem%dealloc(L_start_dot_first_V)
      call mem%dealloc(first_W_dot_R_start)

      ! Calculate transition strengths

      !$omp parallel do private(f, start_vector)
      do start_vector = 1, this%n_start_vectors
         do f = 1, this%n_lanczos_vectors

            transition_strengths(f, start_vector) = Lf_Ri_transition_moments(f, start_vector) &
                                                    * Li_Rf_transition_moments(start_vector, f)

         end do
      end do

      call mem%dealloc(Lf_Ri_transition_moments)
      call mem%dealloc(Li_Rf_transition_moments)

      ! Calculate max transition strength for each final state

      do f = 1, this%n_lanczos_vectors

         max_transition_strengths(f) = transition_strengths(f, maxloc(transition_strengths(f, :), 1))

      end do

   end subroutine calculate_transition_strengths


   subroutine calculate_and_print_oscillator_strengths(this, &
                                                       transition_strengths, &
                                                       initial_state_energies, &
                                                       energies_re)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Calculates the oscillator strengths between the initial and final states,
      !! for all initial states that take part in starting vectors with all three
      !! of the X, Y and Z operators. Prints the oscillator strengths.
      !!
      use array_utilities, only: quicksort_with_index_ascending_int

      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      real(dp), dimension(this%n_lanczos_vectors, this%n_start_vectors), intent(in) :: transition_strengths

      real(dp), dimension(this%n_start_vectors), intent(in) :: initial_state_energies
      real(dp), dimension(this%n_lanczos_vectors), intent(in) :: energies_re

      integer, dimension(:), allocatable :: index_list, operators_sorted, indices, &
                                            oscillator_strength_start_vectors, &
                                            oscillator_strength_start_vectors_temp

      integer :: n_oscillator_strengths, i, j, k, f

      real(dp), dimension(:, :), allocatable :: oscillator_strengths, oscillator_strengths_temp

      call mem%alloc(operators_sorted, 3)
      call mem%alloc(index_list, 3)
      call mem%alloc(indices, 3)

      n_oscillator_strengths = 0

      ! Avoid looping through the same three starting vectors more than once.

      do i = 1, this%n_start_vectors - 2
         do j = i + 1, this%n_start_vectors - 1
            do k = j + 1, this%n_start_vectors

               if (this%right_start_vector_tool%restart_state_indices(i) == &
                   this%right_start_vector_tool%restart_state_indices(j) .and. &
                   this%right_start_vector_tool%restart_state_indices(j) == &
                   this%right_start_vector_tool%restart_state_indices(k)) then

                  ! The operators are sorted so that the order of the X, Y and Z
                  ! starting vectors do not matter.

                  operators_sorted = [this%right_start_vector_tool%operator_indices(i &
                     ), this%right_start_vector_tool%operator_indices(j), &
                     this%right_start_vector_tool%operator_indices(k)]

                  call quicksort_with_index_ascending_int(operators_sorted, index_list, 3)

                  if (operators_sorted(1) == 1 .and. operators_sorted(2) == 2 .and. &
                      operators_sorted(3) == 3) then

                     indices = [i, j, k]

                     ! Append the oscillator strength to the list of oscillator strengths, and the
                     ! index of the first start vector to a list of start vector indices

                     if (n_oscillator_strengths > 0) then

                        call mem%alloc(oscillator_strengths_temp, &
                                       this%n_lanczos_vectors, &
                                       n_oscillator_strengths)

                        call dcopy(this%n_lanczos_vectors * n_oscillator_strengths, &
                                   oscillator_strengths, &
                                   1, &
                                   oscillator_strengths_temp, &
                                   1)

                        call mem%dealloc(oscillator_strengths)

                        call mem%alloc(oscillator_strength_start_vectors_temp, &
                                       n_oscillator_strengths)

                        oscillator_strength_start_vectors_temp = oscillator_strength_start_vectors
                        call mem%dealloc(oscillator_strength_start_vectors)

                     end if

                     n_oscillator_strengths = n_oscillator_strengths + 1

                     call mem%alloc(oscillator_strengths, &
                                    this%n_lanczos_vectors, &
                                    n_oscillator_strengths)

                     call mem%alloc(oscillator_strength_start_vectors, &
                                    n_oscillator_strengths)

                     if (n_oscillator_strengths > 1) then

                        oscillator_strengths(:, 1:n_oscillator_strengths - 1) = oscillator_strengths_temp
                        call mem%dealloc(oscillator_strengths_temp)

                        oscillator_strength_start_vectors(1:n_oscillator_strengths - 1) = &
                           oscillator_strength_start_vectors_temp
                        call mem%dealloc(oscillator_strength_start_vectors_temp)

                     end if

                     oscillator_strength_start_vectors(n_oscillator_strengths) = i

                     do f = 1, this%n_lanczos_vectors

                        oscillator_strengths(f, n_oscillator_strengths) = &
                                                                          two / three &
                                                                          * (energies_re(f) &
                                                                          - initial_state_energies(i)) &
                                                                          * (transition_strengths(f, &
                                                                          indices(index_list(1))) &
                                                                          + transition_strengths(f, &
                                                                          indices(index_list(2))) &
                                                                          + transition_strengths(f, &
                                                                          indices(index_list(3))))

                     end do

                  end if
               end if

            end do
         end do

      end do

      call mem%dealloc(operators_sorted)
      call mem%dealloc(index_list)
      call mem%dealloc(indices)

      if (n_oscillator_strengths > 0) then

         call this%print_oscillator_strength_summary(oscillator_strengths, &
                                                     oscillator_strength_start_vectors, &
                                                     n_oscillator_strengths, &
                                                     initial_state_energies, &
                                                     energies_re)

         call mem%dealloc(oscillator_strengths)
         call mem%dealloc(oscillator_strength_start_vectors)

      end if

   end subroutine calculate_and_print_oscillator_strengths


   subroutine calculate_residual_norms_red_unnormalized(this, &
                                                        L_Dinv_red, &
                                                        R_red, &
                                                        L_residual_norms_red_unnormalized, &
                                                        R_residual_norms_red_unnormalized)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Constructs unnormalized residual norms from the reduced space eigenvectors.
      !!
      use batching_index_class, only: batching_index
      use range_class, only: range_
      use array_utilities, only: get_l2_norm
      use array_initialization, only: copy_subblock

      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      real(dp), dimension(this%n_lanczos_vectors, this%n_lanczos_vectors), intent(in) :: L_Dinv_red, R_red

      real(dp), dimension(this%n_lanczos_vectors), intent(out) :: L_residual_norms_red_unnormalized, &
                                                                  R_residual_norms_red_unnormalized

      integer :: rec0, rec1, current_batch

      real(dp), dimension(:, :), allocatable :: residuals_unnormalized, red_subblock

      type(batching_index) :: batch

      type(range_) :: p_range, q_range

      integer :: f

      rec0 = 0
      rec1 = this%wf%n_es_amplitudes

      batch = batching_index(this%n_lanczos_vectors)
      call mem%batch_setup(batch, rec0, rec1, tag='run_band_lanczos_cc_es_1')

      do current_batch = 1, batch%num_batches

         call batch%determine_limits(current_batch)

         ! Right unnormalized residual norms

         call mem%alloc(residuals_unnormalized, this%wf%n_es_amplitudes, batch%length)

         if (this%V%remaining_deflations > 0) then

            p_range = range_(this%n_lanczos_vectors - this%V%remaining_deflations + 1, &
                             this%V%remaining_deflations)

            q_range = range_(batch%first, batch%get_last() - batch%first + 1)

            call mem%alloc(red_subblock, &
                           this%V%remaining_deflations, &
                           batch%get_last() - batch%first + 1)

            call copy_subblock(R_red, red_subblock, p_range, q_range)

            ! Residuals are calculated from candidate V vectors

            call dgemm('N', &
                       'N', &
                       this%wf%n_es_amplitudes, &
                       batch%length, &
                       this%V%remaining_deflations, &
                       one, &
                       this%V%vector_band(:, &
                          this%V%index_first_candidate_in_band + 1:this%V%index_first_candidate_in_band &
                          + this%V%remaining_deflations), &
                       this%wf%n_es_amplitudes, &
                       red_subblock, &
                       this%V%remaining_deflations, &
                       zero, &
                       residuals_unnormalized, &
                       this%wf%n_es_amplitudes)

            call mem%dealloc(red_subblock)

         else

            residuals_unnormalized = zero

         end if

         do f = batch%first, batch%get_last()

            R_residual_norms_red_unnormalized(f) = get_l2_norm( &
                                                      residuals_unnormalized(:, f - batch%first + 1), &
                                                      this%wf%n_es_amplitudes &
                                                   )

         end do

         ! Left unnormalized residual norms

         if (this%W%remaining_deflations > 0) then

            p_range = range_(this%n_lanczos_vectors - this%W%remaining_deflations + 1, &
                             this%W%remaining_deflations)

            q_range = range_(batch%first, batch%get_last() - batch%first + 1)

            call mem%alloc(red_subblock, &
                           this%W%remaining_deflations, &
                           batch%get_last() - batch%first + 1)

            call copy_subblock(L_Dinv_red, red_subblock, p_range, q_range)

            ! Residuals are calculated from candidate W vectors

            call dgemm('N', &
                       'N', &
                       this%wf%n_es_amplitudes, &
                       batch%length, &
                       this%W%remaining_deflations, &
                       one, &
                       this%W%vector_band(:, &
                          this%W%index_first_candidate_in_band + 1:this%W%index_first_candidate_in_band &
                          + this%W%remaining_deflations), &
                       this%wf%n_es_amplitudes, &
                       red_subblock, &
                       this%W%remaining_deflations, &
                       zero, &
                       residuals_unnormalized, &
                       this%wf%n_es_amplitudes)

            call mem%dealloc(red_subblock)

         else

            residuals_unnormalized = zero

         end if

         do f = batch%first, batch%get_last()

            L_residual_norms_red_unnormalized(f) = get_l2_norm( &
                                                      residuals_unnormalized(:, f - batch%first + 1), &
                                                      this%wf%n_es_amplitudes &
                                                   )

         end do

         call mem%dealloc(residuals_unnormalized)

      end do

      call mem%batch_finalize()

   end subroutine calculate_residual_norms_red_unnormalized


   subroutine calculate_residual_norm_full(this, vector, energy, left_or_right, residual_norm)
      !!
      !! Written by Andreas S. Skeidsvoll, May 2021
      !!
      !! Calculate the residual norm of full-space right or left vector by
      !! transforming it by the full-space Jacobian and subtracting the vector
      !! times the energy.
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(band_lanczos_cc_es) :: this

      real(dp), dimension(this%wf%n_es_amplitudes), intent(in) :: vector
      real(dp), intent(in) :: energy
      character(len=*), intent(in) :: left_or_right
      real(dp), intent(out) :: residual_norm

      real(dp), dimension(:), allocatable :: vector_normalized, residual

      call mem%alloc(vector_normalized, this%wf%n_es_amplitudes)
      call dcopy(this%wf%n_es_amplitudes, vector, 1, vector_normalized, 1)

      call dscal(this%wf%n_es_amplitudes, &
                 one / get_l2_norm(vector, this%wf%n_es_amplitudes), &
                 vector_normalized, &
                 1)

      ! Transform by Jacobian

      call mem%alloc(residual, this%wf%n_es_amplitudes)

      if (trim(left_or_right) == 'right') then
         call this%wf%jacobian_transformation(vector_normalized, residual)
      elseif (trim(left_or_right) == 'left') then
         call this%wf%jacobian_transpose_transformation(vector_normalized, residual)
      end if

      call this%projector%project(residual)

      ! Subtract energy times vector to get residual

      call daxpy(this%wf%n_es_amplitudes, - energy, vector_normalized, 1, residual, 1)
      call mem%dealloc(vector_normalized)

      residual_norm = get_l2_norm(residual, this%wf%n_es_amplitudes)
      call mem%dealloc(residual)

   end subroutine calculate_residual_norm_full


   subroutine construct_full_eigenvectors_and_store_converged_states(this, &
                                                                     max_transition_strengths, &
                                                                     L_Dinv_red, &
                                                                     R_red, &
                                                                     energies_re)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      implicit none

      class(band_lanczos_cc_es) :: this

      logical, dimension(:), allocatable :: state_saved, state_has_requested_properties
      real(dp), dimension(this%n_lanczos_vectors), intent(in) :: max_transition_strengths, energies_re

      real(dp), dimension(this%n_lanczos_vectors, this%n_lanczos_vectors), intent(in) :: L_Dinv_red, R_red

      real(dp), dimension(:), allocatable :: L_residual_norms_red, R_residual_norms_red, &
                                             L_residual_norms_full, R_residual_norms_full

      call mem%alloc(R_residual_norms_red, this%n_lanczos_vectors)
      call mem%alloc(L_residual_norms_red, this%n_lanczos_vectors)
      call mem%alloc(R_residual_norms_full, this%n_lanczos_vectors)
      call mem%alloc(L_residual_norms_full, this%n_lanczos_vectors)

      call mem%alloc(state_saved, this%n_lanczos_vectors)
      call mem%alloc(state_has_requested_properties, this%n_lanczos_vectors)

      call this%construct_full_eigenvectors_and_assess_convergence(state_saved, &
                                                                   state_has_requested_properties, &
                                                                   L_Dinv_red, &
                                                                   R_red, &
                                                                   L_residual_norms_red, &
                                                                   R_residual_norms_red, &
                                                                   L_residual_norms_full, &
                                                                   R_residual_norms_full, &
                                                                   max_transition_strengths, &
                                                                   energies_re)

      call this%print_convergence_summary(state_saved, &
                                          state_has_requested_properties, &
                                          L_residual_norms_red, &
                                          R_residual_norms_red, &
                                          L_residual_norms_full, &
                                          R_residual_norms_full, &
                                          max_transition_strengths, &
                                          energies_re)

      call mem%dealloc(R_residual_norms_red)
      call mem%dealloc(L_residual_norms_red)
      call mem%dealloc(R_residual_norms_full)
      call mem%dealloc(L_residual_norms_full)
      call mem%dealloc(state_has_requested_properties)

      call mem%dealloc(state_saved)

   end subroutine construct_full_eigenvectors_and_store_converged_states


   subroutine construct_full_eigenvectors_and_assess_convergence(this, &
                                                                 state_saved, &
                                                                 state_has_requested_properties, &
                                                                 L_Dinv_red, &
                                                                 R_red, &
                                                                 L_residual_norms_red, &
                                                                 R_residual_norms_red, &
                                                                 L_residual_norms_full, &
                                                                 R_residual_norms_full, &
                                                                 max_transition_strengths, &
                                                                 energies_re)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Transforms the eigenvectors with the requested properties to the full
      !! space. Calculates residual norms from the reduced space eigenvectors, and
      !! also calculates and checks the full space residual norms unless skipped
      !! with the 'skip convergence' keyword.
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(band_lanczos_cc_es) :: this

      logical, dimension(this%n_lanczos_vectors), intent(out) :: state_saved, state_has_requested_properties

      real(dp), dimension(this%n_lanczos_vectors, this%n_lanczos_vectors), intent(in) :: L_Dinv_red, R_red

      real(dp), dimension(this%n_lanczos_vectors), intent(out) :: L_residual_norms_red, &
                                                                  R_residual_norms_red, &
                                                                  L_residual_norms_full, R_residual_norms_full

      real(dp), dimension(this%n_lanczos_vectors), intent(in) :: max_transition_strengths, energies_re

      real(dp), dimension(:), allocatable :: L_full, R_full
      real(dp) :: L_full_norm, R_full_norm

      integer :: f

      logical :: converged_R, converged_L

      real(dp), dimension(:), allocatable :: L_residual_norms_red_unnormalized, &
                                             R_residual_norms_red_unnormalized

      ! Residual norms calculated from reduced space vectors are approximate,
      ! true norms can be obtained by scaling by full space vector norms.

      call mem%alloc(L_residual_norms_red_unnormalized, this%n_lanczos_vectors)
      call mem%alloc(R_residual_norms_red_unnormalized, this%n_lanczos_vectors)

      call this%calculate_residual_norms_red_unnormalized(L_Dinv_red, &
                                                          R_red, &
                                                          L_residual_norms_red_unnormalized, &
                                                          R_residual_norms_red_unnormalized)

      state_saved = .false.
      state_has_requested_properties = .false.

      this%n_states = 0

      call mem%alloc(R_full, this%wf%n_es_amplitudes)
      call mem%alloc(L_full, this%wf%n_es_amplitudes)

      do f = 1, this%n_lanczos_vectors

         state_has_requested_properties(f) = &
            ((max_transition_strengths(f) >= this%min_transition_strength) .and. &
            (energies_re(f) >= this%min_energy) .and. (energies_re(f) <= this%max_energy))

         if (state_has_requested_properties(f)) then

            call this%red_to_full_eigenvector_transformation(f, L_Dinv_red, R_red, L_full, R_full)

            R_full_norm = get_l2_norm(R_full, this%wf%n_es_amplitudes)
            L_full_norm = get_l2_norm(L_full, this%wf%n_es_amplitudes)

            R_residual_norms_red(f) = R_residual_norms_red_unnormalized(f) / R_full_norm
            L_residual_norms_red(f) = L_residual_norms_red_unnormalized(f) / L_full_norm

         end if

         ! Full space vector convergence tests

         converged_R = .false.
         converged_L = .false.

         if (state_has_requested_properties(f) .and. .not. this%skip_convergence) then

            call this%calculate_residual_norm_full(R_full, &
                                                   energies_re(f), &
                                                   'right', &
                                                   R_residual_norms_full(f))

            call this%calculate_residual_norm_full(L_full, &
                                                   energies_re(f), &
                                                   'left', &
                                                   L_residual_norms_full(f))

            if (abs(R_residual_norms_full(f)) < this%convergence_checker%residual_threshold) then

               converged_R = .true.

            end if

            if (abs(L_residual_norms_full(f)) < this%convergence_checker%residual_threshold) then

               converged_L = .true.

            end if

         end if

         ! Save full space vectors

         if (state_has_requested_properties(f) .and. &
             ((converged_L .and. converged_R) .or. this%skip_convergence)) then

            state_saved(f) = .true.

            this%n_states = this%n_states + 1

            call this%storer_L%store(energies_re(f), L_full, this%n_states)
            call this%storer_R%store(energies_re(f), R_full, this%n_states)

         end if

      end do

      call this%wf%add_es_states(this%descriptor_R, this%n_states)
      call this%wf%add_es_states(this%descriptor_L, this%n_states)

      call this%wf%print_es_summary(this%descriptor_L)

      call mem%dealloc(R_full)
      call mem%dealloc(L_full)

      call mem%dealloc(L_residual_norms_red_unnormalized)
      call mem%dealloc(R_residual_norms_red_unnormalized)

   end subroutine construct_full_eigenvectors_and_assess_convergence


   subroutine red_to_full_eigenvector_transformation(this, f, L_Dinv_red, R_red, L_full, R_full)
      !!
      !! Written by Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Transforms the left and right reduced space eigenvectors of the state
      !! with index f to the full space.
      !!
      use batching_index_class, only: batching_index
      use array_initialization, only: zero_array

      implicit none

      class(band_lanczos_cc_es), intent(inout) :: this

      type(batching_index) :: batch

      integer, intent(in) :: f

      integer :: rec0, rec1, current_batch

      real(dp), dimension(this%n_lanczos_vectors, this%n_lanczos_vectors), intent(in) :: L_Dinv_red, R_red

      real(dp), dimension(this%wf%n_es_amplitudes), intent(out) :: L_full, R_full

      real(dp), dimension(:, :), pointer, contiguous :: V_batch, W_batch

      ! Transform the right eigenvector to the full space

      rec0 = 0
      rec1 = this%V%vector_storer%required_to_load_record()

      batch = batching_index(this%n_lanczos_vectors)
      call mem%batch_setup(batch, rec0, rec1, tag='run_band_lanczos_cc_es_2')

      call this%V%vector_storer%prepare_records([batch])

      call zero_array(R_full, this%wf%n_es_amplitudes)

      do current_batch = 1, batch%num_batches

         call batch%determine_limits(current_batch)

         call this%V%vector_storer%load(V_batch, batch)

         call dgemv('N', &
                    this%wf%n_es_amplitudes, &
                    batch%length, &
                    one, &
                    V_batch, &
                    this%wf%n_es_amplitudes, &
                    R_red(batch%first:batch%get_last(), f), &
                    1, &
                    one, &
                    R_full, &
                    1)

      end do

      call mem%batch_finalize()

      call this%V%vector_storer%free_records()

      ! Transform the left eigenvector to the full space

      rec0 = 0
      rec1 = this%W%vector_storer%required_to_load_record()

      batch = batching_index(this%n_lanczos_vectors)
      call mem%batch_setup(batch, rec0, rec1, tag='run_band_lanczos_cc_es_3')

      call this%W%vector_storer%prepare_records([batch])

      call zero_array(L_full, this%wf%n_es_amplitudes)

      do current_batch = 1, batch%num_batches

         call batch%determine_limits(current_batch)

         call this%W%vector_storer%load(W_batch, batch)

         call dgemv('N', &
                    this%wf%n_es_amplitudes, &
                    batch%length, &
                    one, &
                    W_batch, &
                    this%wf%n_es_amplitudes, &
                    L_Dinv_red(batch%first:batch%get_last(), f), &
                    1, &
                    one, &
                    L_full, &
                    1)

      end do

      call mem%batch_finalize()

      call this%W%vector_storer%free_records()

   end subroutine red_to_full_eigenvector_transformation



end module band_lanczos_cc_es_class

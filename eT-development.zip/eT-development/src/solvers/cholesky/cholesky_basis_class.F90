module cholesky_basis_class

   !!
   !! Cholesky basis class
   !! Written by Eirik F. Kjoenstad, 2023
   !!
   !! Collects information about the Cholesky pivots.
   !!

   use parameters
   use stream_file_class, only: stream_file
   use memory_manager_class, only: mem

   implicit none

   type :: cholesky_basis_

      integer, public :: n_construct_shp
      integer, public :: n_construct_aop
      integer, public :: n_shp_in_basis
      integer, public :: max_n_basis_aops_in_shp

      logical, dimension(:), allocatable, public :: construct_shp
      integer, dimension(:, :), allocatable, public :: aops_in_basis
      integer, dimension(:, :), allocatable, public :: AB_info
      integer, dimension(:, :), allocatable, public :: basis_shell_info
      real(dp), dimension(:, :), allocatable, public :: Q_inverse

      type(stream_file), allocatable, public :: basis_shell_info_file
      type(stream_file), allocatable, public :: cauchy_schwarz_diagonal_file
      type(stream_file), allocatable, public :: Q_inverse_file

      integer, private :: n_J
      integer, private :: n_sh
      integer, private :: n_shp

      integer, dimension(:), allocatable :: new_J_to_old_J  ! new J: shell-pair reordered pivots
   ! old J: original pivot ordering

   contains

      procedure, public :: read_into_memory
      procedure, public :: delete_files
      procedure, public :: initialize_and_construct_new_J_to_old_J

      final :: destructor

   end type cholesky_basis_


   interface cholesky_basis_

      procedure :: new_cholesky_basis_

   end interface cholesky_basis_


contains


   function new_cholesky_basis_() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      type(cholesky_basis_) :: this

      this%Q_inverse_file = stream_file('Q_inverse_eri')
      this%cauchy_schwarz_diagonal_file = stream_file('cauchy_schwarz_diagonal_eri')
      this%basis_shell_info_file = stream_file('basis_shell_info')

   end function new_cholesky_basis_


   subroutine read_into_memory(this, n_J, n_sh)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(cholesky_basis_), intent(inout) :: this

      integer, intent(in) :: n_J, n_sh

      integer, dimension(:, :), allocatable :: cholesky_basis_array

      integer :: i, shp, AB_shp, A, B

      this%n_J = n_J
      this%n_sh = n_sh
      this%n_shp = n_sh * (n_sh + 1) / 2

      call mem%alloc(this%construct_shp, this%n_shp)

      call this%cauchy_schwarz_diagonal_file%open_('rewind')

      call this%cauchy_schwarz_diagonal_file%read_(this%n_construct_shp)
      call this%cauchy_schwarz_diagonal_file%read_(this%n_construct_aop)
      call this%cauchy_schwarz_diagonal_file%read_(this%construct_shp, this%n_shp)

      call this%cauchy_schwarz_diagonal_file%close_()

      call this%basis_shell_info_file%open_('rewind')
      call this%basis_shell_info_file%read_(this%n_shp_in_basis)

      call mem%alloc(this%basis_shell_info, this%n_shp_in_basis, 4)

      call this%basis_shell_info_file%read_(this%basis_shell_info, 4 * this%n_shp_in_basis)

      ! necessary dummy read of cholesky_basis array
      call mem%alloc(cholesky_basis_array, this%n_J, 3)
      call this%basis_shell_info_file%read_(cholesky_basis_array, 3 * this%n_J)
      call mem%dealloc(cholesky_basis_array)

      call this%basis_shell_info_file%read_(this%max_n_basis_aops_in_shp)

      call mem%alloc(this%aops_in_basis, this%n_shp_in_basis, 3 * this%max_n_basis_aops_in_shp)

      call this%basis_shell_info_file%read_(this%aops_in_basis, &
                                            this%n_shp_in_basis * 3 * this%max_n_basis_aops_in_shp)

      call this%basis_shell_info_file%close_()

      call this%Q_inverse_file%open_('rewind')

      call mem%alloc(this%Q_inverse, this%n_J, this%n_J, set_zero=.true.)

      do i = 1, this%n_J

         call this%Q_inverse_file%read_(this%Q_inverse(1 + (i - 1):this%n_J, i), this%n_J + 1 - i)

      end do

      call this%Q_inverse_file%close_()

      call mem%alloc(this%AB_info, this%n_construct_shp, 2)  ! [A, B]

      shp = 0
      AB_shp = 0

      do B = 1, this%n_sh
         do A = B, this%n_sh

            AB_shp = AB_shp + 1

            if (this%construct_shp(AB_shp)) then

               shp = shp + 1

               this%AB_info(shp, 1) = A
               this%AB_info(shp, 2) = B

            end if

         end do
      end do

   end subroutine read_into_memory


   subroutine initialize_and_construct_new_J_to_old_J(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      !! Old J: Original pivot ordering
      !! New J: Pivot ordering to pivots within shell-pairs
      !!
      use memory_manager_class, only: mem

      implicit none

      class(cholesky_basis_) :: this

      integer :: rec1, K_sp, J1, J2

      if (.not. allocated(this%new_J_to_old_J)) call mem%alloc(this%new_J_to_old_J, this%n_J)

      rec1 = 0

      do K_sp = 1, this%n_shp_in_basis
         do J1 = 1, this%basis_shell_info(K_sp, 4)

            J2 = this%aops_in_basis(K_sp, &
                                    2 * this%max_n_basis_aops_in_shp + J1)

            rec1 = rec1 + 1

            this%new_J_to_old_J(rec1) = J2

         end do
      end do

   end subroutine initialize_and_construct_new_J_to_old_J


   subroutine delete_files(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(cholesky_basis_) :: this

      call this%Q_inverse_file%delete_()
      call this%basis_shell_info_file%delete_()
      call this%cauchy_schwarz_diagonal_file%delete_()

   end subroutine delete_files


   subroutine destructor(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      type(cholesky_basis_) :: this

      if (allocated(this%construct_shp)) call mem%dealloc(this%construct_shp)
      if (allocated(this%aops_in_basis)) call mem%dealloc(this%aops_in_basis)
      if (allocated(this%AB_info)) call mem%dealloc(this%AB_info)
      if (allocated(this%basis_shell_info)) call mem%dealloc(this%basis_shell_info)
      if (allocated(this%Q_inverse)) call mem%dealloc(this%Q_inverse)
      if (allocated(this%new_J_to_old_J)) call mem%dealloc(this%new_J_to_old_J)

   end subroutine destructor


end module cholesky_basis_class

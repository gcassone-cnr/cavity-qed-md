

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module trust_region_micro_solver_class

   !!
   !! Trust region micro iteration solver
   !! Written by Regina Paul and Sarai D. Folkestad, 2022-2023
   !!
   !! Micro iterations that solve A(a)X(a) = m X(a) to identify the level shift
   !! m (see e.g. J. Chem. Theory Comput. 2022, 18, 8, 4733-4744).
   !! The parameter a is chosen such that the vector k = X(a)/a has a norm equal to
   !! the step size h and we have
   !!
   !!    (H-mI)k = -g
   !!
   !! where H is the hessian, g is the gradient and
   !! (H-mI) is positive definite.
   !!

   use parameters
   use memory_manager_class, only: mem
   use timings_class, only: timings
   use iteration_timings_class, only: iteration_timings

   use transformation_class, only: transformation
   use vector_getter_class, only: vector_getter
   use abstract_projection_tool_class, only: abstract_projection_tool
   use linear_davidson_print_tool_class, only: linear_davidson_print_tool
   use linear_equation_storage_tool_class, only: linear_equation_storage_tool

   use linear_davidson_solver_class, only: linear_davidson_solver

   use convergence_tool_class, only: convergence_tool
   use reduced_matrix_maker_class, only: reduced_matrix_maker
   use reduced_vector_maker_class, only: reduced_vector_maker
   use reduced_space_class, only: reduced_space

   implicit none

   type, extends(linear_davidson_solver) :: trust_region_micro_solver

      real(dp) :: step_size
      real(dp) :: step_size_max

   contains

      procedure, private :: compute_level_shift
      procedure, private :: get_solution_norm
      procedure, private :: construct_augmented_hessian
      procedure, private :: get_lowest_eigenvector_and_value
      procedure, public :: get_level_shift

      procedure, public :: solve_reduced_problem_and_update_reduced_space => &
                           solve_reduced_problem_and_update_reduced_space_trust_region

   end type trust_region_micro_solver

   interface trust_region_micro_solver

      procedure :: new_trust_region_micro_solver

   end interface trust_region_micro_solver

contains

   function new_trust_region_micro_solver(transformer, &
                                          convergence_checker, &
                                          storer, &
                                          preconditioner_getter, &
                                          rhs_getter, &
                                          printer, &
                                          projector, &
                                          n_parameters, &
                                          max_iterations, &
                                          linear_dependence_threshold, &
                                          max_reduced_dimension, &
                                          start_vector, &
                                          step_size) result(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      type(trust_region_micro_solver) :: this

      class(transformation), intent(in) :: transformer
      type(convergence_tool), intent(in) :: convergence_checker
      class(linear_equation_storage_tool), intent(in) :: storer
      class(vector_getter), intent(in) :: preconditioner_getter
      class(vector_getter), intent(in) :: rhs_getter
      class(linear_davidson_print_tool), intent(in) :: printer
      class(abstract_projection_tool), intent(in) :: projector
      integer, intent(in) :: max_iterations
      integer, intent(in) :: max_reduced_dimension, n_parameters
      class(vector_getter), intent(in) :: start_vector
      real(dp), intent(in) :: linear_dependence_threshold
      integer :: corrected_max_reduced_dimension
      real(dp) :: step_size

      this%stop_if_not_converged = .false.
      this%skip_convergence_summary = .true.
      this%skip_banner = .true.
      this%n_solutions = 1
      this%n_rhs = 1
      this%n_frequencies = 1
      this%n_parameters = n_parameters
      this%transformer = transformer
      this%storer = storer
      this%preconditioner_getter = preconditioner_getter
      this%rhs_getter = rhs_getter
      this%printer = printer
      this%projector = projector
      this%max_iterations = max_iterations
      this%step_size = step_size
      this%start_vector = start_vector
      this%convergence_checker = convergence_checker

      call mem%alloc(this%frequencies, this%n_frequencies)

      corrected_max_reduced_dimension = min(max_reduced_dimension, this%n_parameters)

      this%trials = reduced_space('linear_davidson_trials', &
                                  this%n_parameters, &
                                  corrected_max_reduced_dimension, &
                                  .true., &
                                  n_orthonormalizations=2, &
                                  linear_dependence_threshold=linear_dependence_threshold)

      this%transforms = reduced_space('eigen_davidson_transforms', &
                                      this%n_parameters, &
                                      corrected_max_reduced_dimension, &
                                      .true.)

      this%A_red = reduced_matrix_maker()
      this%F_red = reduced_vector_maker(this%n_solutions)

      this%total_timer = timings("Linear davidson solver total", pl='m')
      this%iteration_timer = iteration_timings("Linear davidson solver iteration", pl='m')

   end function new_trust_region_micro_solver


   function compute_level_shift(this, X_red) result(level_shift)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      !! Get the level shift through bisectional search
      !!
      implicit none

      class(trust_region_micro_solver), intent(inout) :: this
      real(dp), dimension(this%trials%n_written_records), intent(out) :: X_red


      real(dp) :: level_shift, lower_alpha, upper_alpha, middle_alpha

      real(dp) :: lower_mu, upper_mu, lower_norm, upper_norm, middle_norm, middle_mu

      logical :: positive

      lower_alpha = 1.0D-4
      upper_alpha = one

      call this%get_solution_norm(lower_alpha, lower_norm, lower_mu, X_red)
      call this%get_solution_norm(upper_alpha, upper_norm, upper_mu, X_red)

      positive = (lower_norm - this%step_size) * (upper_norm - this%step_size) > zero

      do while (positive .and. upper_alpha < 1.0D6)
         upper_alpha = ten * upper_alpha
         call this%get_solution_norm(upper_alpha, upper_norm, upper_mu, X_red)
         positive = (lower_norm - this%step_size) * (upper_norm - this%step_size) > zero
      end do

      if (positive) then
         level_shift = zero
         return
      end if

      middle_alpha = lower_alpha + (upper_alpha - lower_alpha) / two
      call this%get_solution_norm(middle_alpha, middle_norm, middle_mu, X_red)

      do while (abs(middle_norm - this%step_size) > 1.0D-3)  !NOTE

         positive = (lower_norm - this%step_size) * (middle_norm - this%step_size) > zero

         if (positive) then
            lower_alpha = middle_alpha
            lower_mu = middle_mu
            lower_norm = middle_norm
         else
            upper_alpha = middle_alpha
            upper_mu = middle_mu
            upper_norm = middle_norm
         end if

         middle_alpha = lower_alpha + (upper_alpha - lower_alpha) / two
         call this%get_solution_norm(middle_alpha, middle_norm, middle_mu, X_red)

      end do

      level_shift = middle_mu

   end function compute_level_shift


   subroutine get_solution_norm(this, alpha, solution_norm, mu, X_red)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      !! Gets the solution norm |X|, used for defining the level shift:
      !!
      !!    1) Construct the augmented Hessian for a given alpha value
      !!    2) Gets the lowest eigenvalue and the corresponding eigenvector
      !!    3) Scales the lowest eigenvector
      !!    4) Constructs full space solution X and gets its norm
      !!

      use array_utilities, only: get_l2_norm

      implicit none

      class(trust_region_micro_solver), intent(inout) :: this
      real(dp), dimension(this%trials%n_written_records), intent(inout) :: X_red

      real(dp), intent(out) :: solution_norm, mu
      real(dp), intent(in) :: alpha

      real(dp), dimension(:, :), allocatable :: augmented_Hessian
      real(dp), dimension(:), allocatable :: lowest_eigenvector
      real(dp), dimension(:), allocatable :: X

      call mem%alloc(augmented_Hessian, &
                     this%trials%n_written_records + 1, &
                     this%trials%n_written_records + 1, &
                     set_zero=.true.)

      call this%construct_augmented_hessian(augmented_Hessian, alpha)

      call mem%alloc(lowest_eigenvector, this%trials%n_written_records + 1)
      call this%get_lowest_eigenvector_and_value(augmented_Hessian, mu, lowest_eigenvector)

      call mem%dealloc(augmented_Hessian)

      call dscal(this%trials%n_written_records + 1, one / lowest_eigenvector(1), lowest_eigenvector, 1)
      call dscal(this%trials%n_written_records, one / alpha, lowest_eigenvector(2), 1)

      call dcopy(this%trials%n_written_records, lowest_eigenvector(2), 1, X_red, 1)
      call mem%dealloc(lowest_eigenvector)

      call mem%alloc(X, this%n_parameters)

      call this%vector_maker%construct_full_space_vector(this%trials, &
                                                         1, &
                                                         this%trials%n_written_records, &
                                                         X_red, &
                                                         X)

      solution_norm = get_l2_norm(X, this%n_parameters)

      call mem%dealloc(X)

   end subroutine get_solution_norm


   subroutine construct_augmented_hessian(this, augmented_Hessian, alpha)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      !! Constructs the Hessian augmented with one additional dimension, which
      !! contains the gradient multiplied with a parameter alpha.
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(trust_region_micro_solver), intent(inout) :: this

      real(dp), dimension(this%trials%n_written_records + 1, this%trials%n_written_records &
         + 1), intent(inout) :: augmented_Hessian

      real(dp), intent(in) :: alpha
      real(dp) :: F_norm

      integer :: i, j

      do i = 2, this%trials%n_written_records + 1
         do j = 2, this%trials%n_written_records + 1

            augmented_Hessian(j, i) = this%A_red%matrix(j - 1, i - 1)

         end do
      end do

      F_norm = get_l2_norm(this%rhs, this%n_parameters)
      augmented_Hessian(1, 2) = alpha * F_norm
      augmented_Hessian(2, 1) = alpha * F_norm

   end subroutine construct_augmented_hessian


   subroutine get_lowest_eigenvector_and_value(this, &
                                               augmented_Hessian, &
                                               lowest_eigenvalue, &
                                               lowest_eigenvector)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      !! Gets the lowest eigenvalue of the agmented Hessian (which is lower than the
      !! lowest eigenvalue of the Hessian itself) and the corresponding eigenvector
      !!
      implicit none

      class(trust_region_micro_solver), intent(inout) :: this

      real(dp), dimension(this%trials%n_written_records + 1, this%trials%n_written_records &
         + 1), intent(inout) :: augmented_Hessian

      real(dp), dimension(this%trials%n_written_records + 1), intent(inout) :: lowest_eigenvector

      real(dp), intent(out) :: lowest_eigenvalue

      real(dp), dimension(:), allocatable :: work, eigenvalues

      integer :: info

      call mem%alloc(work, 4 * (this%trials%n_written_records + 1))
      call mem%alloc(eigenvalues, this%trials%n_written_records + 1)

      call dsyev('V', &
                 'L', &
                 this%trials%n_written_records + 1, &
                 augmented_Hessian, &  ! augmented_Hessian on entry, eigenvectors on exit
                 this%trials%n_written_records + 1, &
                 eigenvalues, &
                 work, &
                 4 * (this%trials%n_written_records + 1), &
                 info)

      lowest_eigenvalue = eigenvalues(1)

      call dcopy(this%trials%n_written_records + 1, augmented_Hessian, 1, lowest_eigenvector, 1)

      call mem%dealloc(work)
      call mem%dealloc(eigenvalues)

   end subroutine get_lowest_eigenvector_and_value


   subroutine solve_reduced_problem_and_update_reduced_space_trust_region(this, converged, iteration)

      implicit none

      class(trust_region_micro_solver), intent(inout) :: this
      logical, dimension(this%trials%n_written_records), intent(inout) :: converged
      integer, intent(in) :: iteration

      real(dp), dimension(:, :), allocatable :: X_red

      call mem%alloc(X_red, this%trials%n_written_records, this%n_solutions)
      this%frequencies(1) = this%compute_level_shift(X_red)

      call this%solve_reduced_problem(X_red)
      call this%test_convergence_and_add_trials(X_red, converged, iteration)
      call mem%dealloc(X_red)

   end subroutine solve_reduced_problem_and_update_reduced_space_trust_region


   pure function get_level_shift(this) result(level_shift)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      implicit none

      class(trust_region_micro_solver), intent(in) :: this
      real(dp) :: level_shift

      level_shift = this%frequencies(1)

   end function get_level_shift


end module trust_region_micro_solver_class

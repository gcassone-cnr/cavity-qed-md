

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module linear_eigen_solver_class

   !!
   !! Linear eigen solver class module
   !! Written by Eirik F. Kjoenstad, Sarai D. Folkestad, Alexander C. Paul, Nov 2022
   !!
   !! Implements transform and initialize_transformer for the linear eigenvalue solver
   !!

   use eigen_solver_class, only: eigen_solver

   use parameters
   use timings_class, only: timings
   use iteration_timings_class, only: iteration_timings

   use transformation_class, only: transformation
   use convergence_tool_class, only: convergence_tool
   use start_vector_tool_class, only: start_vector_tool
   use eigen_storage_tool_class, only: eigen_storage_tool
   use eigenvector_updater_class, only: eigenvector_updater
   use abstract_projection_tool_class, only: abstract_projection_tool
   use abstract_eigen_print_tool_class, only: abstract_eigen_print_tool

   implicit none

   type, extends(eigen_solver) :: linear_eigen_solver

      class(transformation), allocatable, private :: transformer

   contains

      procedure :: initialize_transformer => initialize_transformer_linear_eigen_solver
      procedure :: transform => transform_linear_eigen_solver

   end type linear_eigen_solver


   interface linear_eigen_solver

      procedure :: new_linear_eigen_solver

   end interface linear_eigen_solver


contains


   function new_linear_eigen_solver(transformer, &
                                    parameter_updater, &
                                    convergence_checker, &
                                    storer, &
                                    start_vectors, &
                                    projector, &
                                    printer, &
                                    n_roots, &
                                    n_parameters, &
                                    max_iterations) result(this)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      type(linear_eigen_solver) :: this
      integer, intent(in) :: n_roots, n_parameters, max_iterations

      class(transformation), intent(in) :: transformer
      class(eigenvector_updater), intent(in) :: parameter_updater
      type(convergence_tool), intent(in) :: convergence_checker
      class(eigen_storage_tool), intent(in) :: storer
      class(start_vector_tool), intent(in) :: start_vectors
      class(abstract_projection_tool), intent(in) :: projector
      class(abstract_eigen_print_tool), intent(in) :: printer

      this%total_timer = timings('Eigenvalue solver total')
      this%iteration_timer = iteration_timings('Eigenvalue solver iteration')
      call this%total_timer%turn_on()

      this%n_roots = n_roots
      this%n_parameters = n_parameters
      this%max_iterations = max_iterations

      this%transformer = transformer
      this%parameter_updater = parameter_updater
      this%start_vectors = start_vectors
      this%projector = projector
      this%storer = storer
      this%printer = printer
      this%convergence_checker = convergence_checker

   end function new_linear_eigen_solver


   subroutine initialize_transformer_linear_eigen_solver(this)
      !!
      !! Written by Alexander C. Paul, Nov 2022
      !!
      implicit none

      class(linear_eigen_solver), intent(inout) :: this

      call this%transformer%initialize()

   end subroutine initialize_transformer_linear_eigen_solver


   subroutine transform_linear_eigen_solver(this, parameters, residuals)
      !!
      !! Written by Alexander C. Paul, Nov 2022
      !!
      implicit none

      class(linear_eigen_solver), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_roots), intent(in) :: parameters
      real(dp), dimension(this%n_parameters, this%n_roots), intent(out) :: residuals

      integer :: root

      do root = 1, this%n_roots

         if (this%converged(root)) cycle

         call this%transformer%transform(parameters(:, root), residuals(:, root))

      end do

   end subroutine transform_linear_eigen_solver


end module linear_eigen_solver_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module eigen_solver_class

   !!
   !! Eigen solver class module
   !! Written by Eirik F. Kjoenstad, Sarai D. Folkestad and Alexander C. Paul, 2018-2022
   !!
   !! Solves an eigenvalue problem
   !!
   !!    A R = omega R   or   L^T A = omega L^T
   !!
   !! for a set of left or right (L, R) eigenvectors
   !! and the corresponding eigenvalues omega
   !!
   !! This solver can also handle non-linear eigenvalue problems
   !!    A(omega) R = omega R   or   L^T A(omega) = omega L^T.
   !!
   !! The transformer and the instance of this class define if a linear or
   !! non-linear eigenvalue problem is solved.
   !!
   !! Different algorithms to solve for the eigenvalues are available
   !! by choosing an eigenvector_updater.
   !! The parameters can be updated using the direct inversion of the iterative
   !! subspace (DIIS) algorithm or the non-linear davidson algorithm.
   !!
   !! See the corresponding updaters for more information:
   !! nonlinear_davidson_eigenvector_updater_class.F90
   !! diis_eigenvector_updater_class.F90
   !!
   !! Note/warning for DIIS: if poor starting guesses for L and R,
   !! are used this solver often finds duplicate roots and may in some
   !! cases not converge.
   !!

   use abstract_solver_class, only: abstract_solver

   use parameters
   use global_out, only: output
   use memory_manager_class, only: mem

   use convergence_tool_class, only: convergence_tool
   use start_vector_tool_class, only: start_vector_tool
   use eigen_storage_tool_class, only: eigen_storage_tool
   use abstract_eigen_print_tool_class, only: abstract_eigen_print_tool
   use abstract_projection_tool_class, only: abstract_projection_tool
   use eigenvector_updater_class, only: eigenvector_updater

   implicit none

   type, abstract, extends(abstract_solver) :: eigen_solver

      class(eigen_storage_tool), allocatable :: storer
      class(abstract_eigen_print_tool), allocatable :: printer
      class(start_vector_tool), allocatable :: start_vectors
      class(abstract_projection_tool), allocatable :: projector
      class(convergence_tool), allocatable :: convergence_checker
      class(eigenvector_updater), allocatable :: parameter_updater

      integer :: n_parameters, n_roots, max_iterations

      real(dp), dimension(:), allocatable :: eigenvalues
      logical, dimension(:), allocatable :: converged

   contains

      procedure, public :: run

      procedure, private :: reorder_roots_by_eigenvalue
      procedure, private :: check_and_print_convergence

      procedure(transform), deferred :: transform
      procedure(initialize_transformer), deferred :: initialize_transformer

   end type eigen_solver


   abstract interface

      subroutine initialize_transformer(this)

         import eigen_solver

         implicit none

         class(eigen_solver), intent(inout) :: this

      end subroutine initialize_transformer


      subroutine transform(this, parameters, residuals)

         import eigen_solver, dp

         implicit none

         class(eigen_solver), intent(inout) :: this
         real(dp), dimension(this%n_parameters, this%n_roots), intent(in) :: parameters
         real(dp), dimension(this%n_parameters, this%n_roots), intent(out) :: residuals

      end subroutine transform

   end interface


contains


   subroutine run(this)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(eigen_solver), intent(inout) :: this

      real(dp), dimension(:), allocatable :: previous_eigenvalues
      real(dp), dimension(:), allocatable :: residual_norms
      real(dp), dimension(:, :), allocatable :: parameters, residuals

      real(dp) :: ddot, delta_eigenvalue
      integer :: iteration, root

      call this%initialize_transformer()

      call this%parameter_updater%initialize()

      call mem%alloc(this%eigenvalues, this%n_roots, set_zero=.true.)
      call mem%alloc(this%converged, this%n_roots, set_to=.false.)
      call mem%alloc(previous_eigenvalues, this%n_roots, set_zero=.true.)
      call mem%alloc(residual_norms, this%n_roots, set_zero=.true.)

      call mem%alloc(residuals, this%n_parameters, this%n_roots)
      call mem%alloc(parameters, this%n_parameters, this%n_roots)

      do root = 1, this%n_roots
         call this%start_vectors%get(parameters(:, root), root, this%eigenvalues(root))
         call this%projector%project(parameters(:, root))
      end do

      iteration = 0

      do while (.not. all(this%converged) .and. (iteration <= this%max_iterations))

         call this%iteration_timer%turn_on()

         iteration = iteration + 1

         ! Construct residuals as A parameters if parameters are not converged yet

         call this%transform(parameters, residuals)

         do root = 1, this%n_roots

            if (this%converged(root)) cycle

            ! Project if relevant

            call this%projector%project(residuals(:, root))

            ! Calculate energy E = parameters^T * residuals = parameters^T A parameters

            this%eigenvalues(root) = ddot(this%n_parameters, &
                                          parameters(:, root), &
                                          1, &
                                          residuals(:, root), &
                                          1)

            ! Construct residual, as (A  - eigenvalue I) parameters, and calculate its norm

            call daxpy(this%n_parameters, &
                       - this%eigenvalues(root), &
                       parameters(:, root), &
                       1, &
                       residuals(:, root), &
                       1)

            residual_norms(root) = get_l2_norm(residuals(:, root), this%n_parameters)

            delta_eigenvalue = this%eigenvalues(root) - previous_eigenvalues(root)

            this%converged(root) = this%convergence_checker%has_converged(residual_norms(root), &
                                                                          delta_eigenvalue, &
                                                                          iteration)

         end do

         call this%printer%print_iteration(this%n_roots, &
                                           this%eigenvalues, &
                                           previous_eigenvalues, &
                                           residual_norms, &
                                           iteration)

         if (.not. all(this%converged)) &
            call this%parameter_updater%update(parameters, residuals, this%eigenvalues, this%converged)

         do root = 1, this%n_roots
            call this%storer%store(this%eigenvalues(root), parameters(:, root), root)
         end do

         call dcopy(this%n_roots, this%eigenvalues, 1, previous_eigenvalues, 1)

         call this%iteration_timer%turn_off()

      end do

      call this%reorder_roots_by_eigenvalue(parameters)

      call this%check_and_print_convergence(iteration)

      call mem%dealloc(this%converged)
      call mem%dealloc(this%eigenvalues)
      call mem%dealloc(residual_norms)
      call mem%dealloc(previous_eigenvalues)

      call mem%dealloc(parameters)
      call mem%dealloc(residuals)

      call this%parameter_updater%finalize()

   end subroutine run


   subroutine check_and_print_convergence(this, iteration)
      !!
      !! Written by Sarai D. Folkestad, Nov 2022
      !!
      implicit none

      class(eigen_solver), intent(in) :: this
      integer, intent(in) :: iteration

      if (all(this%converged)) then
         call this%printer%print_summary(iteration)
      else

         call output%error_msg( &
                 "Did not converge in the max number of iterations in eigenvalue solver." &
              )

      end if

   end subroutine check_and_print_convergence


   subroutine reorder_roots_by_eigenvalue(this, vectors)
      !!
      !! Written by Alexander C. Paul, 2020
      !!
      use array_utilities, only: quicksort_with_index_ascending

      implicit none

      class(eigen_solver), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%n_roots), intent(in) :: vectors

      integer, dimension(:), allocatable :: old_indices
      integer :: new_index, old_index

      call output%printf('n', &
                         '- Resorting roots according to eigenvalue.', &
                         fs='(/t3,a)')

      ! Sort eigenvalues and store the original root number in old_indices

      call mem%alloc(old_indices, this%n_roots)

      call quicksort_with_index_ascending(this%eigenvalues, old_indices, this%n_roots)

      do new_index = 1, this%n_roots

         old_index = old_indices(new_index)
         if (old_index /= new_index) then

            call output%printf('v', &
                               'Root number (i0) renamed to number (i0)', &
                               ints=[old_index, new_index], &
                               fs='(t5,a)')

         end if

         call this%storer%store(this%eigenvalues(new_index), &
                                vectors(:, old_index), &
                                new_index)

      end do

      call mem%dealloc(old_indices)

   end subroutine reorder_roots_by_eigenvalue


end module eigen_solver_class

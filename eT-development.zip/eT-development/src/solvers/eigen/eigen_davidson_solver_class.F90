

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module eigen_davidson_solver_class

   !!
   !! Eigen Davidson solver class
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, and Alexander C. Paul 2021-2023
   !!

   use parameters
   use memory_manager_class, only: mem
   use timings_class, only: timings
   use iteration_timings_class, only: iteration_timings

   use abstract_davidson_solver_class, only: abstract_davidson_solver
   use convergence_tool_class, only: convergence_tool
   use transformation_class, only: transformation
   use eigen_storage_tool_class, only: eigen_storage_tool
   use start_vector_tool_class, only: start_vector_tool
   use vector_getter_class, only: vector_getter
   use abstract_projection_tool_class, only: abstract_projection_tool

   use reduced_matrix_maker_class, only: reduced_matrix_maker
   use reduced_space_class, only: reduced_space
   use full_space_vector_maker_class, only: full_space_vector_maker
   use multistate_precondition_tool_class, only: multistate_precondition_tool
   use parameters


   implicit none

   type, extends(abstract_davidson_solver) :: eigen_davidson_solver

      real(dp), private :: linear_dependence_threshold
      type(full_space_vector_maker), private :: vector_maker
      class(convergence_tool), allocatable, private :: convergence_checker
      class(vector_getter), allocatable, private :: preconditioner_getter
      class(reduced_matrix_maker), allocatable, private :: A_red
      class(eigen_storage_tool), allocatable, private :: storer
      class(start_vector_tool), allocatable, private :: start_vector
      complex(dp), dimension(:), allocatable, private :: omega, old_omega
      class(multistate_precondition_tool), allocatable, private :: preconditioner

   contains

      procedure, public :: cleanup
      procedure, public :: initialize

      procedure, public :: solve_reduced_problem_and_update_reduced_space => &
                           solve_reduced_problem_and_update_reduced_space_eigen

      procedure, public :: calculate_reduced_space_quantities => calculate_reduced_space_quantities_eigen

      procedure, private :: test_convergence_and_add_trials
      procedure, private :: reset_reduced_space
      procedure, private :: construct_solutions_and_residuals
      procedure, private :: store_solutions
      procedure, private :: determine_convergence_and_print_iteration
      procedure, private :: add_vectors_to_trial_space
      procedure, private :: construct_new_trials
      procedure, private :: print_iteration
      procedure, private :: solve_reduced_problem

      procedure, public :: print_banner
      procedure, public :: print_settings

   end type eigen_davidson_solver

   interface eigen_davidson_solver

      procedure :: new_eigen_davidson_solver

   end interface eigen_davidson_solver

contains


   function new_eigen_davidson_solver(transformer, &
                                      convergence_checker, &
                                      storer, &
                                      start_vector, &
                                      preconditioner, &
                                      projector, &
                                      n_solutions, &
                                      n_parameters, &
                                      max_reduced_dimension, &
                                      max_iterations, &
                                      reduced_space_in_memory, &
                                      linear_dependence_threshold) result(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      type(eigen_davidson_solver) :: this

      class(transformation), intent(in) :: transformer
      type(convergence_tool), intent(in) :: convergence_checker
      class(eigen_storage_tool), intent(in) :: storer
      class(start_vector_tool), intent(in) :: start_vector
      class(multistate_precondition_tool), intent(in) :: preconditioner
      class(abstract_projection_tool), intent(in) :: projector
      integer, intent(in) :: max_iterations, n_solutions
      integer, intent(in) :: max_reduced_dimension, n_parameters
      real(dp), intent(in) :: linear_dependence_threshold
      logical, intent(in) :: reduced_space_in_memory

      integer :: corrected_max_reduced_dimension

      this%skip_convergence_summary = .false.
      this%skip_banner = .false.
      this%transformer = transformer
      this%convergence_checker = convergence_checker
      this%storer = storer
      this%start_vector = start_vector
      this%preconditioner = preconditioner
      this%projector = projector
      this%n_solutions = n_solutions
      this%n_parameters = n_parameters
      this%linear_dependence_threshold = linear_dependence_threshold
      this%max_iterations = max_iterations

      corrected_max_reduced_dimension = min(max_reduced_dimension, this%n_parameters)

      this%trials = reduced_space('eigen_davidson_trials', &
                                  this%n_parameters, &
                                  corrected_max_reduced_dimension, &
                                  reduced_space_in_memory, &
                                  n_orthonormalizations=2, &
                                  linear_dependence_threshold=linear_dependence_threshold)

      this%transforms = reduced_space('eigen_davidson_t_transforms', &
                                      this%n_parameters, &
                                      corrected_max_reduced_dimension, &
                                      reduced_space_in_memory)

      this%A_red = reduced_matrix_maker()

      this%total_timer = timings("Eigen davidson solver total", pl='m')
      this%iteration_timer = iteration_timings("Eigen davidson solver iteration", pl='m')

   end function new_eigen_davidson_solver


   subroutine initialize(this, converged)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(eigen_davidson_solver), intent(inout) :: this
      logical, dimension(this%n_solutions), intent(inout) :: converged

      real(dp), dimension(:), allocatable :: tmp
      integer :: trial

      real(dp) :: o

      converged = .false.

      call mem%alloc(this%omega, this%trials%get_max_reduced_dimension(), set_zero=.true.)
      call mem%alloc(this%old_omega, this%n_solutions, set_zero=.true.)

      call this%trials%initialize()
      call this%transforms%initialize()
      call this%transformer%initialize()

      call this%preconditioner%initialize()

      call mem%alloc(tmp, this%n_parameters)

      do trial = 1, this%n_solutions

         call this%start_vector%get(tmp, trial, o)
         call this%trials%set_vector(tmp, trial)

         this%old_omega(trial) = cmplx(o, 0.0d0, kind=dp)

      end do
      call mem%dealloc(tmp)

      call this%trials%orthonormalize()

   end subroutine initialize


   subroutine test_convergence_and_add_trials(this, &
                                              X_red, &
                                              converged, &
                                              iteration)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!

      implicit none

      class(eigen_davidson_solver), intent(inout) :: this
      real(dp), dimension(this%trials%n_written_records, this%trials%n_written_records), intent(in) :: X_red
      logical, dimension(this%n_solutions), intent(out) :: converged
      integer, intent(in) :: iteration

      logical, dimension(:), allocatable :: residual_gt_lindep

      real(dp), dimension(:, :), allocatable :: R
      real(dp), dimension(:, :), allocatable :: X

      integer :: n_solutions_to_construct

      ! To make residuals for complex solutions, we potentially need an extra solution vector
      n_solutions_to_construct = min(this%n_solutions + 1, this%trials%n_written_records)

      call mem%alloc(X, this%n_parameters, n_solutions_to_construct)
      call mem%alloc(R, this%n_parameters, this%n_solutions)

      call this%construct_solutions_and_residuals(X_red, X, R, this%omega, n_solutions_to_construct)
      call this%store_solutions(X(:, 1:this%n_solutions), this%omega)

      call mem%alloc(residual_gt_lindep, this%n_solutions, set_to=.false.)

      call this%determine_convergence_and_print_iteration(R, &
                                                          residual_gt_lindep, &
                                                          converged, &
                                                          this%old_omega, &
                                                          this%omega, &
                                                          iteration)

      if (.not. all(converged)) then
         if (this%trials%n_written_records &
             + count(.not. converged) > this%trials%get_max_reduced_dimension()) then

            call this%reset_reduced_space(X)

         else

            call this%add_vectors_to_trial_space(X, R, this%omega, residual_gt_lindep, converged)

         end if
      end if

      call mem%dealloc(X)
      call mem%dealloc(R)
      call mem%dealloc(residual_gt_lindep)

   end subroutine test_convergence_and_add_trials


   subroutine add_vectors_to_trial_space(this, X, R, omega, residual_gt_lindep, converged)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      !! Adds preconditioned residuals to the trial space when
      !! they have norm higher than both residual convergence criterion and
      !! the linear dependence threshold
      !!
      use global_out, only: output

      implicit none

      class(eigen_davidson_solver), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%n_solutions), intent(in) :: X
      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: R
      complex(dp), dimension(this%n_solutions), intent(in) :: omega
      logical, dimension(this%n_solutions), intent(inout) :: residual_gt_lindep, converged
      logical, dimension(:), allocatable :: add_residual_as_trial

      integer :: n, n_new_trials

      do n = 1, this%n_solutions

         ! Residual norm lower than linear dependence threshold but ENERGY not converged
         if (.not. residual_gt_lindep(n) .and. .not. converged(n)) &
            call output%warning_msg( &
                    'Residual norm for root (i0) smaller than linear ' // &
                       'dependence threshold, but energy ' // &
                       'threshold have not yet been met. No new trial ' // 'added for this root.', &
                    ints=[n] &
                 )

      end do

      call mem%alloc(add_residual_as_trial, this%n_solutions)
      add_residual_as_trial = .not. converged .and. residual_gt_lindep

      n_new_trials = count(add_residual_as_trial)

      if (n_new_trials > 0) then

         call this%construct_new_trials(X, &
                                        R, &
                                        omega, &
                                        n_new_trials, &
                                        add_residual_as_trial)

      end if

      call mem%dealloc(add_residual_as_trial)

   end subroutine add_vectors_to_trial_space


   subroutine construct_new_trials(this, &
                                   X, &
                                   R, &
                                   omega, &
                                   n_new_trials, &
                                   add_residual_as_trial)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2021-2023
      !!
      use array_utilities, only: extract_columns

      implicit none

      class(eigen_davidson_solver), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%n_solutions), intent(in) :: X
      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: R
      complex(dp), dimension(this%n_solutions), intent(in) :: omega
      logical, dimension(this%n_solutions), intent(in) :: add_residual_as_trial

      integer, intent(in) :: n_new_trials

      integer, dimension(this%n_solutions) :: trial_to_solution

      integer :: n, counter

      ! Get indices for the residuals that should be preconditioned (trial_to_solution)
      trial_to_solution = 0

      counter = 0
      do n = 1, this%n_solutions

         if (add_residual_as_trial(n)) then

            counter = counter + 1
            trial_to_solution(counter) = n

         end if

      end do

      call this%preconditioner%precondition(X, &
                                            R, &
                                            real(omega, kind=dp), &
                                            trial_to_solution, &
                                            n_new_trials, &
                                            this%n_solutions)

      call extract_columns(this%n_parameters, this%n_solutions, R, add_residual_as_trial)
      call this%trials%orthonormalize_and_add_vectors(n_new_trials, R)

   end subroutine construct_new_trials


   subroutine determine_convergence_and_print_iteration(this, &
                                                        R, &
                                                        residual_gt_lindep, &
                                                        converged, &
                                                        omega, &
                                                        new_omega, &
                                                        iteration)
      !!
      !! Written by Sarai D. Folkestad, 2021-2023
      !!
      use global_out, only: output
      use array_utilities, only: get_l2_norm
      implicit none

      class(eigen_davidson_solver), intent(in) :: this
      real(dp), dimension(this%n_parameters, this%n_solutions), intent(in) :: R
      complex(dp), dimension(this%n_solutions), intent(in) :: omega
      complex(dp), dimension(this%n_solutions), intent(in) :: new_omega

      integer, intent(in) :: iteration

      logical, dimension(this%n_solutions), intent(inout) :: residual_gt_lindep, converged

      real(dp), dimension(:), allocatable :: residual_norm
      integer :: n

      call mem%alloc(residual_norm, this%n_solutions)

      do n = 1, this%n_solutions

         residual_norm(n) = get_l2_norm(R(:, n), this%n_parameters)
         residual_gt_lindep(n) = residual_norm(n) > this%trials%linear_dependence_threshold

         converged(n) = this%convergence_checker%has_converged(residual_norm(n), &
                                                               real(new_omega(n)) - real(omega(n)), &
                                                               iteration)

      end do

      call this%print_iteration(omega, new_omega(1:this%n_solutions), residual_norm, iteration)

      call mem%dealloc(residual_norm)

      ! Special case when residuals are below linear dependence threshold, but energy has not converged
      ! This occurs if equations are solved in the first iteration
      if (.not. any(residual_gt_lindep) .and. .not. all(converged)) then

         converged = .true.

         call output%printf('m', &
                            'Note: all residuals are converged and have norms that are smaller than linear&
                            & dependence threshold. Energy convergence therefore not tested in this&
                            & calculation.')

      end if

   end subroutine determine_convergence_and_print_iteration


   subroutine construct_solutions_and_residuals(this, X_red, X, R, omega, n_construct)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      use eigenvector_residual_class, only: eigenvector_residual

      implicit none

      class(eigen_davidson_solver), intent(inout) :: this

      integer, intent(in) :: n_construct
      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: R
      real(dp), dimension(this%n_parameters, n_construct), intent(inout) :: X
      real(dp), dimension(this%trials%n_written_records, this%trials%n_written_records), intent(in) :: X_red
      complex(dp), dimension(this%n_solutions), intent(in) :: omega

      class(eigenvector_residual), allocatable :: residual_calculator

      call this%vector_maker%construct_full_space_vector(this%trials, &
                                                         n_construct, &
                                                         this%trials%n_written_records, &
                                                         X_red, &
                                                         X)

      call this%vector_maker%construct_full_space_vector(this%transforms, &
                                                         this%n_solutions, &
                                                         this%trials%n_written_records, &
                                                         X_red, &
                                                         R)

      residual_calculator = eigenvector_residual(this%n_parameters, this%n_solutions)
      call residual_calculator%construct(R, X, omega)

   end subroutine construct_solutions_and_residuals


   subroutine store_solutions(this, X, omega)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none


      class(eigen_davidson_solver), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%n_solutions), intent(in) :: X
      complex(dp), dimension(this%n_solutions), intent(in) :: omega

      integer :: n

      do n = 1, this%n_solutions
         call this%storer%store(real(omega(n)), X(:, n), n)
      end do

   end subroutine store_solutions


   subroutine reset_reduced_space(this, X)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      !! Resets the reduced space and sets new trials equal
      !! to orthonormalized solutions
      !!
      implicit none

      class(eigen_davidson_solver), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: X

      call this%trials%reset_written_records()
      call this%transforms%reset_written_records()

      call this%trials%orthonormalize_and_add_vectors(this%n_solutions, X)
      call this%A_red%reset()

   end subroutine reset_reduced_space


   subroutine print_iteration(this, omega, new_omega, residual_norm, iteration)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      use parameters
      use global_out, only: output

      implicit none

      class(eigen_davidson_solver), intent(in) :: this

      integer, intent(in) :: iteration
      real(dp), dimension(this%n_solutions), intent(in) :: residual_norm
      complex(dp), dimension(this%n_solutions), intent(in) :: new_omega, omega

      integer :: n

      call output%printf('n', 'Iteration:               (i4)', ints=[iteration], fs='(/t3,a)')
      call output%printf('n', 'Reduced space dimension: (i4)', ints=[this%trials%n_written_records])

      call output%printf('n', &
                         'Root  Eigenvalue (Re)   Eigenvalue (Im)    |residual|   Delta E (Re)', &
                         fs='(/t3,a)', &
                         ll=120)

      call output%print_separator('n', 68, '-')

      do n = 1, this%n_solutions

         call output%printf('n', &
                            '(i4) (f16.8) (f16.8)   (e11.4)  (e11.4) ', &
                            ints=[n], &
                            reals=[real(new_omega(n)), &
                               aimag(new_omega(n)), &
                               residual_norm(n), &
                               abs(real(new_omega(n)) - real(omega(n)))], &
                            ll=120)

      end do

      call output%print_separator('n', 68, '-')

   end subroutine print_iteration


   subroutine print_banner(this)
      !!
      !! Written by Regina Matveeva, Dec 2021
      !!
      use global_out, only: output
      use warning_suppressor, only: do_nothing

      implicit none

      class(eigen_davidson_solver), intent(in) :: this

      character(len=100) :: name_
      character(len=500) :: description

      call do_nothing(this)

      name_ = 'Davidson eigenvalue equation solver'

      description = &
         'A Davidson solver that solves an eigenvalue equation: M x = omega x. This equation is solved in a&
         & reduced space. A description of the algorithm can be found in E. R. Davidson, J. Comput. Phys. 17,&
         & 87 (1975).'

      call output%printf('m', trim(name_), fs='(/t3,a)')
      call output%print_separator('m', len_trim(name_), '-')

      call output%printf('n', description, ffs='(/t3,a)', fs='(t3,a)')

   end subroutine print_banner


   subroutine print_settings(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      use global_out, only: output

      implicit none

      class(eigen_davidson_solver), intent(in) :: this

      call output%printf('m', '- Eigenvalue Davidson solver settings', fs='(/t3,a)')

      call output%printf('m', &
                         'Number of states:             (i11)', &
                         ints=[this%n_solutions], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Max number of iterations:     (i11)', &
                         ints=[this%max_iterations], &
                         fs='(t6,a)')

      call output%printf('m', &
                         'Max reduced space dimension:  (i11)', &
                         ints=[this%trials%get_max_reduced_dimension()], &
                         fs='(t6,a)')

      call this%trials%print_settings()
      call this%transforms%print_settings()

      call this%convergence_checker%print_settings()


   end subroutine print_settings


   subroutine calculate_reduced_space_quantities_eigen(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      class(eigen_davidson_solver), intent(inout) :: this

      call this%A_red%construct(this%trials, this%transforms)

   end subroutine calculate_reduced_space_quantities_eigen


   subroutine solve_reduced_problem(this, X_red)
      !!
      !! Written by Sarai D. Folkestad, Oct 2023
      !!
      use lapack_wrappers, only: diagonalize_non_symmetric
      use global_out, only: output

      implicit none

      class(eigen_davidson_solver), intent(inout) :: this
      real(dp), dimension(this%trials%n_written_records, this%trials%n_written_records), intent(inout) :: &
         X_red

      call zcopy(this%n_solutions, this%omega(1:this%n_solutions), 1, this%old_omega, 1)

      call output%print_matrix("v", &
                               "A reduced", &
                               this%A_red%matrix, &
                               this%trials%n_written_records, &
                               this%trials%n_written_records)

      call diagonalize_non_symmetric(this%trials%n_written_records, &
                                     this%A_red%matrix, &
                                     X_red, &
                                     this%omega)

   end subroutine solve_reduced_problem


   subroutine cleanup(this)
      !!
      !! Written by Sarai D. Folkestad, Oct 2023
      !!
      implicit none

      class(eigen_davidson_solver), intent(inout) :: this


      if (allocated(this%trials)) call this%trials%finalize()
      if (allocated(this%transforms)) call this%transforms%finalize()

      if (allocated(this%omega)) call mem%dealloc(this%omega)
      if (allocated(this%old_omega)) call mem%dealloc(this%old_omega)

      call this%A_red%deallocate_matrix()

   end subroutine cleanup


   subroutine solve_reduced_problem_and_update_reduced_space_eigen(this, converged, iteration)
      !!
      !! Written by Sarai D. Folkestad, Oct 2023
      !!
      implicit none

      class(eigen_davidson_solver), intent(inout) :: this
      logical, dimension(this%trials%n_written_records), intent(inout) :: converged
      integer, intent(in) :: iteration

      real(dp), dimension(:, :), allocatable :: X_red

      call mem%alloc(X_red, this%trials%n_written_records, this%trials%n_written_records)

      call this%solve_reduced_problem(X_red)
      call this%test_convergence_and_add_trials(X_red, converged, iteration)

      call mem%dealloc(X_red)

   end subroutine solve_reduced_problem_and_update_reduced_space_eigen


end module eigen_davidson_solver_class

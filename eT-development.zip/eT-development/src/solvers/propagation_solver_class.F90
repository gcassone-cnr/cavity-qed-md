

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module propagation_solver_class

   !!
   !! Propagation solver class
   !! Written by Alice Balbi, Andreas Skeidsvoll, 2018-2022
   !!
   !! Module containing the type propagation_solver. An object of this type
   !! can be used to propagate a molecular system interacting with time-dependent
   !! fields. Currently, the time-dependent wavefuction can parametrized by the
   !! TDCC, diagonal TD-EOM-CC or elementary basis TD-EOM-CC parametrizations.
   !! Differential equations are integrated using various one-step (Runge-Kutta)
   !! algorithms.
   !!
   !! During the propagation, time-dependent properties can be calculated, and
   !! written as time series to files. See read_settings for more details.
   !!

   use parameters
   use memory_manager_class, only: mem
   use global_out, only: output
   use output_file_class, only: output_file
   use iteration_timings_class, only: iteration_timings
   use abstract_integrator_class, only: abstract_integrator
   use td_state_class, only: td_state
   use time_variable_tool_class, only: time_variable_tool

   implicit none

   type :: propagation_solver

      character(len=100) :: tag
      character(len=100) :: name_
      character(len=500) :: description

      integer :: steps_between_output

      real(dp) :: implicit_threshold, max_error, min_error

      logical :: energy_output, dipole_moment_output, electric_field_output, td_parameters_output, &
                 mo_density_matrix_output, restart

      type(output_file) :: energy_file, dipole_moment_file, electric_field_file, td_parameters_file, &
                           mo_density_matrix_real_file, mo_density_matrix_imag_file

      class(abstract_integrator), allocatable :: integrator
      class(td_state), allocatable :: state
      class(time_variable_tool), allocatable :: time

   contains

      procedure, public :: run => run_propagation_solver

      procedure, private :: print_banner => print_banner_propagation_solver
      procedure, private :: print_summary => print_summary_propagation_solver

      procedure, private :: write_energy_to_file => write_energy_to_file_propagation_solver
      procedure, private :: write_dipole_moment_to_file => write_dipole_moment_to_file_propagation_solver
      procedure, private :: write_electric_field_to_file => write_electric_field_to_file_propagation_solver
      procedure, private :: write_td_parameters_to_file => write_td_parameters_to_file_propagation_solver
      procedure, private :: write_mo_density_matrix_to_file => &
                            write_mo_density_matrix_to_file_propagation_solver

      procedure, private :: open_files => open_files_propagation_solver
      procedure, private :: close_files => close_files_propagation_solver

   end type propagation_solver


   interface propagation_solver

      procedure :: new_propagation_solver

   end interface propagation_solver


contains


   function new_propagation_solver(tag, &
                                   state, &
                                   time, &
                                   integrator, &
                                   max_error, &
                                   min_error, &
                                   implicit_threshold, &
                                   energy_output, &
                                   dipole_moment_output, &
                                   electric_field_output, &
                                   td_parameters_output, &
                                   mo_density_matrix_output, &
                                   restart) result(this)
      !!
      !! Written by Andreas Skeidsvoll, Alice Balbi, 2018-2022
      !!
      implicit none

      type(propagation_solver) :: this

      character(*), intent(in) :: tag

      class(td_state), intent(in) :: state
      class(time_variable_tool), intent(in) :: time
      class(abstract_integrator), intent(in) :: integrator

      real(dp), intent(in) :: max_error, min_error, implicit_threshold

      logical, intent(in) :: energy_output, dipole_moment_output, electric_field_output, &
                             td_parameters_output, mo_density_matrix_output, restart

      this%state = state
      this%time = time
      this%integrator = integrator
      this%max_error = max_error
      this%min_error = min_error
      this%implicit_threshold = implicit_threshold
      this%energy_output = energy_output
      this%dipole_moment_output = dipole_moment_output
      this%electric_field_output = electric_field_output
      this%td_parameters_output = td_parameters_output
      this%mo_density_matrix_output = mo_density_matrix_output
      this%restart = restart

      ! Set printables

      this%tag = trim(tag)
      this%name_ = 'Propagation solver'
      this%description = 'A solver that propagates a time-dependent state'

      call this%print_banner()

   end function new_propagation_solver


   subroutine run_propagation_solver(this)
      !!
      !! Written by Alice Balbi, Andreas Skeidsvoll, 2018-2022
      !!
      !! Propagate the time-dependent state from the initial to the final time.
      !! Properties are calculated and written to file if requested in settings.
      !!
      implicit none

      class(propagation_solver), intent(inout) :: this

      type(iteration_timings) :: step_timer

      complex(dp), dimension(:), allocatable :: td_parameters_current

      real(dp) :: error_estimate
      logical :: step_reduction

      ! Propagation

      step_timer = iteration_timings('propagation step', pl='verbose')

      call this%integrator%initialize()

      call this%time%initialize()

      call this%open_files()

      call this%state%initialize()

      call mem%alloc(td_parameters_current, this%state%get_n_td_parameters())

      do

         call output%printf('v', 'Time: (f10.4) au', reals=[this%time%current], fs='(/t3,a)')

         ! Write properties to file
         if (this%time%output_at_current()) then
            if (.not. (this%restart .and. (this%time%current == this%time%restart_time))) then

               call this%state%update(this%time%current)
               call this%state%prepare_output(this%energy_output, this%dipole_moment_output)

               if (this%energy_output) call this%write_energy_to_file()
               if (this%dipole_moment_output) call this%write_dipole_moment_to_file()
               if (this%electric_field_output) call this%write_electric_field_to_file()
               if (this%td_parameters_output) call this%write_td_parameters_to_file()
               if (this%mo_density_matrix_output) call this%write_mo_density_matrix_to_file()

               call this%state%real_state_storer%save_(real(this%state%td_parameters), &
                                                       real(this%state%energy))

               call this%state%imag_state_storer%save_(aimag(this%state%td_parameters), &
                                                       aimag(this%state%energy))

               call output%printf('n', &
                                  'Properties written at time: (f10.4) au', &
                                  reals=[this%time%current], &
                                  fs='(t3,a)')

            end if
         end if

         call this%time%count_step()

         if (this%time%last_step) exit

         call this%time%calculate_next()

         ! Do a propagation step

         step_reduction = .false.

         call zcopy(this%state%get_n_td_parameters(), &
                    this%state%td_parameters, &
                    1, &
                    td_parameters_current, &
                    1)

         do

            call step_timer%turn_on()

            call this%integrator%do_step(this%state, &
                                         this%time%current, &
                                         this%time%next - this%time%current, &
                                         td_parameters_current, &
                                         step_reduction, &
                                         error_estimate)

            call step_timer%turn_off()

            if (error_estimate <= this%max_error) then

               exit

            else

               call this%time%reduce_step_size()
               step_reduction = .true.

               call this%time%calculate_next()

            end if

         end do

         call this%time%update_current()

         if (error_estimate < this%min_error) call this%time%try_increasing_step_size()

      end do

      call mem%dealloc(td_parameters_current)

      call this%state%update(this%time%current)
      call this%state%prepare_output(this%energy_output, this%dipole_moment_output)

      call this%close_files()

      call output%printf('m', &
                         'Finished propagating for (f10.4) au', &
                         reals=[this%time%final_], &
                         fs='(/t3,a)')

      call this%print_summary()

      call this%state%cleanup()

      call this%integrator%cleanup()

      call this%time%cleanup()

   end subroutine run_propagation_solver


   subroutine print_banner_propagation_solver(this)
      !!
      !! Written by Andreas Skeidsvoll, Oct 2018
      !!
      !! Print banner of solver.
      !!
      implicit none

      class(propagation_solver) :: this

      call output%printf('m', ' - ' // trim(this%name_), fs='(/t3,a)')
      call output%print_separator('m', len_trim(this%name_) + 6, '-')

      call output%printf('n', this%description, ffs='(/t3,a)', fs='(t3,a)')

   end subroutine print_banner_propagation_solver


   subroutine write_energy_to_file_propagation_solver(this)
      !!
      !! Written by Andreas Skeidsvoll, Oct 2018
      !!
      !! Write energy to file together with the time t.
      !!
      implicit none

      class(propagation_solver) :: this

      real(dp), dimension(3) :: values

      values = [this%time%current, real(this%state%energy), aimag(this%state%energy)]
      call this%energy_file%printf('m', '(f21.16)   (f21.16)  (e25.16)', reals=values, ll=200)

   end subroutine write_energy_to_file_propagation_solver


   subroutine write_dipole_moment_to_file_propagation_solver(this)
      !!
      !! Written by Andreas Skeidsvoll, Alice Balbi, Oct 2018
      !!
      !! Write the dipole moment vector to file together with the time t.
      !!
      implicit none

      class(propagation_solver) :: this

      real(dp), dimension(7) :: values

      values = [this%time%current, real(this%state%dipole_moment(1) &
         ), aimag(this%state%dipole_moment(1)), real(this%state%dipole_moment(2)), &
         aimag(this%state%dipole_moment(2)), real(this%state%dipole_moment(3)), &
         aimag(this%state%dipole_moment(3))]


      call this%dipole_moment_file%printf('m', '(f21.16)   6(e25.16)', reals=values, ll=200)

   end subroutine write_dipole_moment_to_file_propagation_solver


   subroutine write_electric_field_to_file_propagation_solver(this)
      !!
      !! Written by Andreas Skeidsvoll, Oct 2018
      !!
      !! Write the electric field vector to file together with the time t.
      !!
      implicit none

      class(propagation_solver) :: this

      real(dp), dimension(7) :: values

      values = [this%time%current, this%state%field%vector(1 &
         ), zero, this%state%field%vector(2), zero, this%state%field%vector(3), zero]

      call this%electric_field_file%printf('m', '(f21.16)   6(e25.16)', reals=values, ll=200)

   end subroutine write_electric_field_to_file_propagation_solver


   subroutine write_td_parameters_to_file_propagation_solver(this)
      !!
      !! Written by Alice Balbi, Andreas Skeidsvoll, Mar 2019
      !!
      !! Write the real part of the vector of parameters to file.
      !!

      implicit none

      class(propagation_solver) :: this

      call this%td_parameters_file%write_([this%time%current, real(this%state%td_parameters)], &
                                          this%state%get_n_td_parameters() + 1)

   end subroutine write_td_parameters_to_file_propagation_solver


   subroutine write_mo_density_matrix_to_file_propagation_solver(this)
      !!
      !! Written by Andreas Skeidsvoll, Dec 2019
      !!
      !! Write the real and imaginary parts of the time-dependent MO density matrix to separate files
      !!
      implicit none

      class(propagation_solver) :: this

      call this%mo_density_matrix_real_file%write_(real(this%state%mo_density_matrix), &
                                                   this%state%n_mo**2)

      call this%mo_density_matrix_imag_file%write_(aimag(this%state%mo_density_matrix), &
                                                   this%state%n_mo**2)

   end subroutine write_mo_density_matrix_to_file_propagation_solver


   subroutine print_summary_propagation_solver(this)
      !!
      !! Written by Andreas Skeidsvoll, Oct 2018
      !!
      !! Print the summary of the solver.
      !!
      implicit none

      class(propagation_solver) :: this

      call output%printf('m', '- ' // trim(this%name_) // ' summary', fs='(/t3,a)')

      if (this%energy_output) then

         call output%printf('m', 'Energy after propagation [au]:', fs='(/t6,a)')
         call output%print_separator('minimal', 42, '-', fs='(t6,a)')
         call output%printf('m', '    Real part         Imaginary part      ', fs='(t6,a)')
         call output%print_separator('minimal', 42, '-', fs='(t6,a)')

         call output%printf('m', &
                            '    (f16.10)  (f16.10)', &
                            reals=[real(this%state%energy), aimag(this%state%energy)], &
                            fs='(t6,a)')

         call output%print_separator('minimal', 42, '-', fs='(t6,a)')

      end if

      if (this%dipole_moment_output) then

         call output%printf('m', 'Dipole moment after propagation [au]:', fs='(/t6,a)')
         call output%print_separator('minimal', 45, '-', fs='(t6,a)')
         call output%printf('m', '       Real part         Imaginary part      ', fs='(t6,a)')
         call output%print_separator('minimal', 45, '-', fs='(t6,a)')

         call output%printf('m', &
                            '    x  (f16.10)  (f16.10)', &
                            reals=[real(this%state%dipole_moment(1)), aimag(this%state%dipole_moment(1))], &
                            fs='(t6,a)')

         call output%printf('m', &
                            '    y  (f16.10)  (f16.10)', &
                            reals=[real(this%state%dipole_moment(2)), aimag(this%state%dipole_moment(2))], &
                            fs='(t6,a)')

         call output%printf('m', &
                            '    z  (f16.10)  (f16.10)', &
                            reals=[real(this%state%dipole_moment(3)), aimag(this%state%dipole_moment(3))], &
                            fs='(t6,a)')

         call output%print_separator('minimal', 42, '-', fs='(t6,a)')

      end if

   end subroutine print_summary_propagation_solver


   subroutine open_files_propagation_solver(this)
      !!
      !! Written by Andreas Skeidsvoll, Apr 2019
      !!
      !! Open the files where the property time series should be written.
      !!
      implicit none

      class(propagation_solver) :: this

      logical :: exist
      character(len=500) :: out_

      if (this%energy_output) then
         out_ = 'eT.' // trim(this%tag) // '_energy.out'
         this%energy_file = output_file(out_)
         if (this%restart) then
            inquire(file=out_, exist=exist)
            if (exist) then
               call this%energy_file%open_('append')
            else
               call output%warning_msg('Asked for restart but no energy output file found')
               call this%energy_file%open_('rewind')
            end if
         else
            call this%energy_file%open_('rewind')
         end if
      end if

      if (this%dipole_moment_output) then
         out_ = 'eT.' // trim(this%tag) // '_dipole_moment.out'
         this%dipole_moment_file = output_file(out_)
         if (this%restart) then
            inquire(file=out_, exist=exist)
            if (exist) then
               call this%dipole_moment_file%open_('append')
            else
               call output%warning_msg('Asked for restart but no dipole moment output file found')
               call this%dipole_moment_file%open_('rewind')
            end if
         else
            call this%dipole_moment_file%open_('rewind')
         end if
      end if

      if (this%electric_field_output) then
         out_ = 'eT.' // trim(this%tag) // '_electric_field.out'
         this%electric_field_file = output_file(out_)
         if (this%restart) then
            inquire(file=out_, exist=exist)
            if (exist) then
               call this%electric_field_file%open_('append')
            else
               call output%warning_msg('Asked for restart but no electric field output file found')
               call this%electric_field_file%open_('rewind')
            end if
         else
            call this%electric_field_file%open_('rewind')
         end if
      end if

      if (this%td_parameters_output) then
         out_ = 'eT.' // trim(this%tag) // '_parameters.out'
         this%td_parameters_file = output_file(out_)
         if (this%restart) then
            inquire(file=out_, exist=exist)
            if (exist) then
               call this%td_parameters_file%open_('append')
            else
               call output%warning_msg('Asked for restart but no parameters output file found')
               call this%td_parameters_file%open_('rewind')
            end if
         else
            call this%td_parameters_file%open_('rewind')
         end if
      end if

      if (this%mo_density_matrix_output) then

         out_ = 'eT.' // trim(this%tag) // '_mo_density_matrix_real.out'
         this%mo_density_matrix_real_file = output_file(out_)
         if (this%restart) then
            inquire(file=out_, exist=exist)
            if (exist) then
               call this%mo_density_matrix_real_file%open_('append')
            else
               call output%warning_msg('Asked for restart but no real density matrix output file found')
               call this%mo_density_matrix_real_file%open_('rewind')
            end if
         else
            call this%mo_density_matrix_real_file%open_('rewind')
         end if

         out_ = 'eT.' // trim(this%tag) // '_mo_density_matrix_imaginary.out'
         this%mo_density_matrix_imag_file = output_file(out_)
         if (this%restart) then
            inquire(file=out_, exist=exist)
            if (exist) then
               call this%mo_density_matrix_imag_file%open_('append')
            else
               call output%warning_msg('Asked for restart but no imag density matrix output file found')
               call this%mo_density_matrix_imag_file%open_('rewind')
            end if
         else
            call this%mo_density_matrix_imag_file%open_('rewind')
         end if

      end if

   end subroutine open_files_propagation_solver


   subroutine close_files_propagation_solver(this)
      !!
      !! Written by Andreas Skeidsvoll, Apr 2019
      !!
      !! Close the files where the property time series have been written.
      !!
      implicit none

      class(propagation_solver) :: this

      if (this%energy_output) then
         call this%energy_file%close_
      end if

      if (this%dipole_moment_output) then
         call this%dipole_moment_file%close_
      end if

      if (this%electric_field_output) then
         call this%electric_field_file%close_
      end if

      if (this%td_parameters_output) then
         call this%td_parameters_file%close_
      end if

      if (this%mo_density_matrix_output) then
         call this%mo_density_matrix_real_file%close_
         call this%mo_density_matrix_imag_file%close_
      end if

   end subroutine close_files_propagation_solver


end module propagation_solver_class

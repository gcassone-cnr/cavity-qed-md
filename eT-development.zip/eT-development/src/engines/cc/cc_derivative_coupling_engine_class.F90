

! eT - a coupled cluster program
! Copyright (C) 2016-2022 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_derivative_coupling_engine_class

   !!
   !! Written by Eirik F. Kjoenstad, 2024
   !!
   !! CC derivative coupling engine class
   !!

   use parameters
   use global_in, only: input
   use ccs_class, only: ccs
   use cc_engine_class, only: cc_engine
   use cc_amplitudes_task_class, only: cc_amplitudes_task
   use cc_es_amplitudes_task_class, only: cc_es_amplitudes_task
   use eri_approximator_task_class, only: eri_approximator_task
   use cc_wavefunctions_class, only: cc_wavefunctions
   use biorthonormalization_task_class, only: biorthonormalization_task
   use output_file_class, only: output_file

   implicit none

   type, extends(cc_engine) :: cc_derivative_coupling_engine

      type(eri_approximator_task), private :: eri_approximator
      type(cc_amplitudes_task), allocatable, private :: ground_state_amplitudes
      type(cc_es_amplitudes_task), allocatable, private :: excited_state_amplitudes
      type(biorthonormalization_task), allocatable, private :: biorthonormalization

      integer, dimension(2), private :: states

      logical, private :: enforce_sum_rule

      logical, private :: restart

      type(output_file), private :: derivative_coupling_file

   contains

      procedure, public :: ignite => ignite_cc_derivative_coupling_engine

      procedure, public :: set_allowed_wfs => set_allowed_wfs_cc_derivative_coupling_engine

      procedure, private :: print_derivative_coupling

   end type cc_derivative_coupling_engine


   interface cc_derivative_coupling_engine

      procedure :: new_cc_derivative_coupling_engine

   end interface

contains


   function new_cc_derivative_coupling_engine() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      use global_in, only: input
      use global_out, only: output

      implicit none

      type(cc_derivative_coupling_engine) :: this

      if (input%is_keyword_present('derivative coupling', 'cc response')) then

         call input%get_array_for_keyword('derivative coupling', &
                                          'cc response', &
                                          2, &
                                          this%states)

         this%enforce_sum_rule = input%is_keyword_present('enforce sum rule', &
                                                          'cc response')

      else

         call output%error_msg("Asked for derivative coupling, but did not specify states!")

      end if

      this%restart = input%is_keyword_present('restart', 'solver cc es') .or. &
                     input%is_keyword_present('restart', 'do')

   end function new_cc_derivative_coupling_engine


   subroutine ignite_cc_derivative_coupling_engine(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2021-2022
      !!
      use parameters
      use global_in, only: input
      use state_descriptor_class, only: state_descriptor, es_type
      use memory_manager_class, only: mem
      use ccsd_class, only: ccsd
      use citation_printer_class, only: eT_citations

      implicit none

      class(cc_derivative_coupling_engine), intent(inout) :: this
      class(ccs), intent(inout) :: wf
      type(state_descriptor), allocatable :: descriptor
      type(es_type), dimension(:), allocatable :: types

      integer :: i, n
      integer, dimension(:), allocatable :: n_states
      real(dp), dimension(:, :), allocatable :: d_mn

      call this%set_allowed_wfs()
      call this%check_wavefunctions(wf)
      call eT_citations%add('CCSD derivative couplings')

      this%derivative_coupling_file = output_file('eT.derivative_coupling.out')
      call this%derivative_coupling_file%open_('rewind')

      call mem%alloc(d_mn, 3, wf%n_atomic_centers, set_zero=.true.)

      call this%eri_approximator%execute(wf)

      this%ground_state_amplitudes = cc_amplitudes_task()
      call this%ground_state_amplitudes%execute(wf)

      n = input%get_n_es_types()

      allocate(types(n))
      call mem%alloc(n_states, n)

      call input%get_es_types(n, types)
      call input%get_n_es_states(n, n_states, 'singlet')

      do i = 1, n

         descriptor = state_descriptor('right', types(i), 'singlet')

         this%excited_state_amplitudes = cc_es_amplitudes_task(descriptor, this%restart, n_states(i))
         call this%excited_state_amplitudes%execute(wf)

         deallocate(this%excited_state_amplitudes)
         deallocate(descriptor)

         descriptor = state_descriptor('left', types(i), 'singlet')

         this%excited_state_amplitudes = cc_es_amplitudes_task(descriptor, .true., n_states(i))
         call this%excited_state_amplitudes%execute(wf)

         deallocate(this%excited_state_amplitudes)
         deallocate(descriptor)

      end do

      call mem%dealloc(n_states)
      this%biorthonormalization = biorthonormalization_task()
      call this%biorthonormalization%execute(wf)

      call wf%initialize_density_intermediates(wf%R_es_states%n_total)
      call wf%prepare_for_molecular_gradients()

      call wf%calculate_derivative_coupling(d_mn, this%states(1), this%states(2), this%enforce_sum_rule)

      call this%print_derivative_coupling(wf, d_mn, this%states(1), this%states(2))

      call wf%destruct_density_intermediates()
      call wf%finalize_for_molecular_gradients()

      call mem%dealloc(d_mn)

      call this%derivative_coupling_file%close_()

   end subroutine ignite_cc_derivative_coupling_engine


   subroutine print_derivative_coupling(this, wf, d_mn, m, n)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      !! Prints the derivative coupling vector.
      !!
      use atomic_center_class, only: atomic_center

      implicit none

      class(cc_derivative_coupling_engine), intent(inout) :: this

      class(ccs), intent(in) :: wf

      real(dp), dimension(3, wf%ao%n_centers), intent(in) :: d_mn

      integer, intent(in) :: m, n

      type(atomic_center) :: center

      integer :: i

      call this%derivative_coupling_file%newline('m')

      call this%derivative_coupling_file%printf('m', &
                                                '- Derivative coupling (Hartree/bohr) for states (i0) and (i0&
                                                &)', &
                                                ints=[m, n])

      call this%derivative_coupling_file%printf('m', &
                                                '     Center                 x                y&
                                                &                z', &
                                                fs='(/t3,a)')

      call this%derivative_coupling_file%print_separator(pl='m', n=70, symbol='-')

      do i = 1, wf%ao%n_centers

         call wf%ao%get_center(i, center)

         call this%derivative_coupling_file%printf('m', &
                                                   '  (i4) (b4)       3(f17.12)', &
                                                   chars=[center%symbol], &
                                                   ints=[i], &
                                                   reals=[d_mn(:, i)])

      end do

      call this%derivative_coupling_file%print_separator(pl='m', n=70, symbol='-')

   end subroutine print_derivative_coupling


   subroutine set_allowed_wfs_cc_derivative_coupling_engine(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      class(cc_derivative_coupling_engine), intent(inout) :: this

      this%allowed_cc_wfs = cc_wavefunctions()

      call this%allowed_cc_wfs%set('ccsd', allowed=.true.)

   end subroutine set_allowed_wfs_cc_derivative_coupling_engine


end module cc_derivative_coupling_engine_class

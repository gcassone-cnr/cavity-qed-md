

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_es_engine_class

   !!
   !! CC excited state engine class
   !! Written by Eirik F. Kjoenstad, Alexander Paul, and Sarai D. Folkestad, 2021-2022
   !!

   use global_in, only: input
   use ccs_class, only: ccs
   use cc_engine_class, only: cc_engine
   use cc_amplitudes_task_class, only: cc_amplitudes_task
   use cc_es_amplitudes_task_class, only: cc_es_amplitudes_task
   use cc_visualization_task_class, only: cc_visualization_task
   use eri_approximator_task_class, only: eri_approximator_task
   use cc_wavefunctions_class, only: cc_wavefunctions
   use state_descriptor_class, only: state_descriptor, es_type

   implicit none

   type, extends(cc_engine) :: cc_es_engine

      type(eri_approximator_task), private :: eri_approximator
      type(cc_amplitudes_task), allocatable, private :: ground_state_amplitudes
      type(cc_es_amplitudes_task), allocatable, private :: excited_state_amplitudes
      type(cc_visualization_task), allocatable, private :: visualization

      logical, dimension(2) :: do_left_or_right
      logical, dimension(2) :: do_spin


   contains

      procedure, public :: ignite => ignite_cc_es_engine
      procedure, public :: set_allowed_wfs => set_allowed_wfs_cc_es_engine

      procedure, private :: determine_left_or_right
      procedure, private :: determine_spin

   end type cc_es_engine

contains


   subroutine ignite_cc_es_engine(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2021-2022
      !!
      use memory_manager_class, only: mem
      implicit none

      class(cc_es_engine), intent(inout) :: this
      class(ccs), intent(inout) :: wf

      logical :: restart

      integer :: left_or_right, spin

      type(state_descriptor) :: descriptor
      type(es_type), dimension(:), allocatable :: types

      integer :: i, n
      integer, dimension(:), allocatable :: n_states

      character(len = 10), dimension(2), parameter :: left_or_right_string = &
         [character(len = 10) :: 'right', 'left']
      character(len=10), dimension(2), parameter :: spin_string = [character(len=10) :: 'singlet', 'triplet']

      call this%set_allowed_wfs()
      call this%check_wavefunctions(wf)

      call this%eri_approximator%execute(wf)

      this%ground_state_amplitudes = cc_amplitudes_task()
      call this%ground_state_amplitudes%execute(wf)

      restart = input%is_keyword_present('restart', 'solver cc es') .or. &
                input%is_keyword_present('restart', 'do')

      call this%determine_left_or_right()
      call this%determine_spin()

      n = input%get_n_es_types()

      allocate(types(n))
      call mem%alloc(n_states, n)

      call input%get_es_types(n, types)

      do spin = 1, 2

         if (.not. this%do_spin(spin)) cycle

         call input%get_n_es_states(n, n_states, trim(spin_string(spin)))

         do i = 1, n

            do left_or_right = 1, 2

               if (.not. this%do_left_or_right(left_or_right)) cycle
               if (left_or_right == 2 .and. this%do_left_or_right(1)) restart = .true.


               descriptor = state_descriptor(trim(left_or_right_string(left_or_right)), &
                                             types(i), &
                                             spin_symmetry=trim(spin_string(spin)))

               this%excited_state_amplitudes = cc_es_amplitudes_task(descriptor, restart, n_states(i))
               call this%excited_state_amplitudes%execute(wf)

            end do
         end do
      end do

      call mem%dealloc(n_states)

      this%visualization = cc_visualization_task()
      call this%visualization%execute(wf)

   end subroutine ignite_cc_es_engine


   subroutine determine_left_or_right(this)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      !! Determines the transformation
      !!
      !! this%do_left_or_right(k)
      !!
      !! k = 1 -> right
      !! k = 2 -> left
      !!
      implicit none

      class(cc_es_engine), intent(inout) :: this

      this%do_left_or_right = input%get_es_left_or_right()

      ! Default is to do right
      if (.not. any(this%do_left_or_right)) this%do_left_or_right(1) = .true.

   end subroutine determine_left_or_right


   subroutine determine_spin(this)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      !! Determines the spin symmetry to run
      !!
      !! this%do_spin(k)
      !!
      !! k = 1 -> singlet
      !! k = 2 -> triplet
      !!
      implicit none

      class(cc_es_engine), intent(inout) :: this

      this%do_spin = input%get_es_spin_symmetry()

      ! In case of Lanczos, where the chain length,
      ! and not the number of states is specified, always do singlet only.
      if (.not. any(this%do_spin)) this%do_spin(1) = .true.

   end subroutine determine_spin


   subroutine set_allowed_wfs_cc_es_engine(this)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      class(cc_es_engine), intent(inout) :: this

      this%allowed_cc_wfs = cc_wavefunctions()

      call this%allowed_cc_wfs%set('ccs', allowed=.true.)
      call this%allowed_cc_wfs%set('cc2', allowed=.true.)
      call this%allowed_cc_wfs%set('low memory cc2', allowed=.true.)
      call this%allowed_cc_wfs%set('ccsd', allowed=.true.)
      call this%allowed_cc_wfs%set('cc3', allowed=.true.)
      call this%allowed_cc_wfs%set('mlcc2', allowed=.true.)
      call this%allowed_cc_wfs%set('mlccsd', allowed=.true.)
      call this%allowed_cc_wfs%set('qed-ccsd', allowed=.true.)
      call this%allowed_cc_wfs%set('ccsdt', allowed=.true.)

   end subroutine set_allowed_wfs_cc_es_engine

end module cc_es_engine_class

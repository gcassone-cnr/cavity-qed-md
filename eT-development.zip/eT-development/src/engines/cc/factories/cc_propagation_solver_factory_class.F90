

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_propagation_solver_factory_class

   !!
   !! CC propagation solver factory class
   !! Written by Eirik F. Kjoenstad, Alice Balbi, Andreas S. Skeidsvoll, 2021-2022
   !!

   use parameters
   use ccs_class, only: ccs
   use global_in, only: input
   use global_out, only: output

   use propagation_solver_class, only: propagation_solver

   implicit none

   type :: cc_propagation_solver_factory

      character(len=200), private :: method, integration_method

      integer, private :: steps_between_output

      real(dp), private :: implicit_threshold, max_error, min_error

      logical, private :: energy_output, dipole_moment_output, electric_field_output
      logical, private :: td_parameters_output, mo_density_matrix_output, restart

   contains

      procedure, public :: create

      procedure, private :: read_settings

   end type cc_propagation_solver_factory


   interface cc_propagation_solver_factory

      procedure :: new_cc_propagation_solver_factory

   end interface cc_propagation_solver_factory


contains


   function new_cc_propagation_solver_factory() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, Alice Balbi, 2021-2022
      !!
      implicit none

      type(cc_propagation_solver_factory) :: this

      ! Set default settings

      this%steps_between_output = 1

      this%implicit_threshold = 1.0e-11_dp

      this%energy_output = .false.
      this%dipole_moment_output = .false.
      this%electric_field_output = .false.
      this%td_parameters_output = .false.
      this%mo_density_matrix_output = .false.
      this%restart = .false.
      this%method = 'tdcc'
      this%integration_method = 'rk4'

      this%max_error = 1.0e-10
      this%min_error = 1.0e-12

      call this%read_settings()

   end function new_cc_propagation_solver_factory


   subroutine read_settings(this)
      !!
      !! Written by Andreas Skeidsvoll, Feb 2019
      !!
      !! Read the settings required to do the real-time propagation.
      !!
      !! Settings:
      !!
      !! method:                   the type of theory that the propagation is based on. The current
      !!                           options are 'tdcc', 'elementary td-eom-cc' and 'diagonal td-eom-cc'
      !! integrator:               first order integration method to be used for the propagation.
      !!                           The options are euler (Euler method), rk4 (RK4 method),
      !!                           gl2 (second order Gauss-Legendre mehtod), gl4 (fourth order
      !!                           Gauss-Legendre method), gl6 (sixth order Gauss-Legendre method),
      !!                           dopri5 (Dormand-Prince 5(4) method) and dop853
      !!                           (Dormand-Prince 8(5,3) method)
      !! max error:                maximum value of error estimate for embedded methods
      !! min error:                minimum value of error estimate for embedded methods
      !! implicit threshold:       convergence threshold for the solution of equations in implicit
      !!                           integrators
      !! energy output:            writes energy time series to file if this is specified
      !! dipole moment output:     writes dipole moment vector time series to file if this is
      !!                           specified
      !! electric field output:    writes electric field vector time series to file if this is
      !!                           specified
      !! parameters output:        writes real part of the vector of parameters time series to file if
      !!                           this is specified
      !! mo density matrix output: writes real and imaginary parts of the molecular orbital density
      !!                           matrix to a new set of files at each output step if this is
      !!                           specified
      !!
      implicit none

      class(cc_propagation_solver_factory) :: this

      call input%get_keyword('method', 'solver cc propagation', this%method)
      call input%get_keyword('integrator', 'solver cc propagation', this%integration_method)
      call input%get_keyword('max error', 'solver cc propagation', this%max_error)
      call input%get_keyword('min error', 'solver cc propagation', this%min_error)

      call input%get_keyword('implicit threshold', &
                             'solver cc propagation', &
                             this%implicit_threshold)

      this%energy_output = input%is_keyword_present('energy output', 'solver cc propagation')

      this%dipole_moment_output = input%is_keyword_present('dipole moment output', 'solver cc propagation')

      this%electric_field_output = input%is_keyword_present('electric field output', 'solver cc propagation')

      this%td_parameters_output = input%is_keyword_present('parameters output', 'solver cc propagation')

      this%mo_density_matrix_output = input%is_keyword_present('mo density matrix output', &
                                                               'solver cc propagation')

      this%restart = input%is_keyword_present('restart', 'solver cc propagation') .or. &
                     input%is_keyword_present('restart', 'do')

   end subroutine read_settings


   subroutine create(this, wf, field, solver)
      !!
      !! Written by Eirik F. Kjoenstad, Andreas S. Skeidsvoll, Alice Balbi, 2021-2022
      !!
      use citation_printer_class, only: eT_citations

      use electric_field_class, only: electric_field

      use td_state_class, only: td_state
      use tdcc_state_class, only: tdcc_state
      use elementary_tdeomcc_state_class, only: elementary_tdeomcc_state
      use diagonal_tdeomcc_state_class, only: diagonal_tdeomcc_state

      use time_variable_tool_class, only: time_variable_tool

      use abstract_integrator_class, only: abstract_integrator
      use explicit_integrator_class, only: explicit_integrator
      use implicit_integrator_class, only: implicit_integrator

      use butcher_tables
      use continuous_output_coefficients

      implicit none

      class(cc_propagation_solver_factory), intent(inout) :: this

      class(propagation_solver), allocatable, intent(out) :: solver

      class(ccs), intent(inout), target :: wf
      class(electric_field), intent(inout), target :: field

      class(td_state), allocatable :: state
      class(time_variable_tool), allocatable :: time
      class(abstract_integrator), allocatable :: integrator
      integer :: n_states

      if (trim(this%method) == 'tdcc') then

         state = tdcc_state(wf, field, this%restart)

         call eT_citations%add("Time-dependent CC")

      elseif (trim(this%method) == 'elementary td-eom-cc') then

         state = elementary_tdeomcc_state(wf, field, this%mo_density_matrix_output, this%restart)

         call eT_citations%add("Elementary basis TD-EOM-CC")

      elseif (trim(this%method) == 'diagonal td-eom-cc') then

         call input%get_keyword('singlet states', 'solver cc es', n_states)
         state = diagonal_tdeomcc_state(wf, field, n_states, this%mo_density_matrix_output, this%restart)

         call eT_citations%add("Diagonal basis TD-EOM-CC")

      else

         call output%error_msg('did not recognize real-time CC method')

      end if

      time = time_variable_tool()
      call time%print_settings()

      if (trim(this%integration_method) == 'euler') then

         integrator = explicit_integrator(state%get_n_td_parameters(), 1, A_euler, c_euler, 1, b_euler)

      elseif (trim(this%integration_method) == 'rk4') then

         integrator = explicit_integrator(state%get_n_td_parameters(), 4, A_rk4, c_rk4, 1, b_rk4)

      elseif (trim(this%integration_method) == 'gl2') then

         integrator = implicit_integrator(state%get_n_td_parameters(), &
                                          1, &
                                          A_gl2, &
                                          c_gl2, &
                                          1, &
                                          b_gl2, &
                                          this%implicit_threshold, &
                                          beta_gl2)

      elseif (trim(this%integration_method) == 'gl4') then

         integrator = implicit_integrator(state%get_n_td_parameters(), &
                                          2, &
                                          A_gl4, &
                                          c_gl4, &
                                          1, &
                                          b_gl4, &
                                          this%implicit_threshold, &
                                          beta_gl4)

      elseif (trim(this%integration_method) == 'gl6') then

         integrator = implicit_integrator(state%get_n_td_parameters(), &
                                          3, &
                                          A_gl6, &
                                          c_gl6, &
                                          1, &
                                          b_gl6, &
                                          this%implicit_threshold, &
                                          beta_gl6)

      elseif (trim(this%integration_method) == 'egl4') then

         integrator = implicit_integrator(state%get_n_td_parameters(), &
                                          2, &
                                          A_gl4, &
                                          c_gl4, &
                                          2, &
                                          b_egl4, &
                                          this%implicit_threshold, &
                                          beta_gl4)

      elseif (trim(this%integration_method) == 'egl6') then

         integrator = implicit_integrator(state%get_n_td_parameters(), &
                                          3, &
                                          A_gl6, &
                                          c_gl6, &
                                          2, &
                                          b_egl6, &
                                          this%implicit_threshold, &
                                          beta_gl6)

      elseif (trim(this%integration_method) == 'lob3c4') then

         integrator = implicit_integrator(state%get_n_td_parameters(), &
                                          3, &
                                          A_lob3c4, &
                                          c_lob3c4, &
                                          2, &
                                          b_lob3c4, &
                                          this%implicit_threshold)

      elseif (trim(this%integration_method) == 'dopri5') then

         integrator = explicit_integrator(state%get_n_td_parameters(), &
                                          7, &
                                          A_dopri5, &
                                          c_dopri5, &
                                          2, &
                                          b_dopri5, &
                                          .true.)

      elseif (trim(this%integration_method) == 'cashkarp') then

         integrator = explicit_integrator(state%get_n_td_parameters(), &
                                          6, &
                                          A_cashkarp, &
                                          c_cashkarp, &
                                          2, &
                                          b_cashkarp)

      elseif (trim(this%integration_method) == 'heuneuler') then

         integrator = explicit_integrator(state%get_n_td_parameters(), &
                                          2, &
                                          A_heuneuler, &
                                          c_heuneuler, &
                                          2, &
                                          b_heuneuler)

      elseif (trim(this%integration_method) == 'dop853') then

         integrator = explicit_integrator(state%get_n_td_parameters(), &
                                          12, &
                                          A_dop853, &
                                          c_dop853, &
                                          3, &
                                          b_dop853)
      else

         call output%error_msg('did not recognize real-time CC integrator.')

      end if

      solver = propagation_solver('cc_real_time', &
                                  state, &
                                  time, &
                                  integrator, &
                                  this%max_error, &
                                  this%min_error, &
                                  this%implicit_threshold, &
                                  this%energy_output, &
                                  this%dipole_moment_output, &
                                  this%electric_field_output, &
                                  this%td_parameters_output, &
                                  this%mo_density_matrix_output, &
                                  this%restart)

   end subroutine create


end module cc_propagation_solver_factory_class

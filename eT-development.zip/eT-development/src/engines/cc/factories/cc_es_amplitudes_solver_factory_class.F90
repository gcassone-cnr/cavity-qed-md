
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_es_amplitudes_solver_factory_class

   !!
   !! CC excited state amplitudes solver factory class
   !! Written by Eirik F. Kjoenstad, 2021
   !!

   use parameters
   use ccs_class, only: ccs
   use global_in, only: input
   use global_out, only: output

   use transformation_class, only: transformation
   use abstract_solver_class, only: abstract_solver
   use convergence_tool_class, only: convergence_tool
   use start_vector_tool_class, only: start_vector_tool
   use eigen_storage_tool_class, only: eigen_storage_tool
   use abstract_projection_tool_class, only: abstract_projection_tool
   use cc_jacobian_preconditioner_getter_class, only: cc_jacobian_preconditioner_getter
   use multistate_precondition_tool_class, only: multistate_precondition_tool
   use state_descriptor_class, only: state_descriptor
   use vector_getter_class, only: vector_getter

   implicit none


   type :: cc_es_amplitudes_solver_factory

      class(transformation), allocatable :: transformer
      class(convergence_tool), allocatable :: convergence_checker
      class(start_vector_tool), allocatable :: start_vectors
      class(eigen_storage_tool), allocatable :: storer
      class(abstract_projection_tool), allocatable :: projector
      class(vector_getter), allocatable :: preconditioner_getter
      class(multistate_precondition_tool), allocatable :: preconditioner
      class(state_descriptor), allocatable :: descriptor

      character(len=200), private :: algorithm

      integer, private :: n_states, max_iterations
      logical, private :: energy_convergence, restart, records_in_memory
      real(dp), private :: energy_threshold, residual_threshold

   contains

      procedure, public :: create

      procedure, private :: read_settings
      procedure, private :: create_common_es_solver_components
      procedure, nopass, private :: create_folded_jacobian_transformer
      procedure, private :: create_davidson_es_solver
      procedure, private :: create_diis_es_solver
      procedure, private :: create_nonlinear_davidson_es_solver


   end type cc_es_amplitudes_solver_factory


   interface cc_es_amplitudes_solver_factory

      procedure :: new_cc_es_amplitudes_solver_factory

   end interface cc_es_amplitudes_solver_factory


contains


   function new_cc_es_amplitudes_solver_factory(method, descriptor, n_states, restart) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      type(cc_es_amplitudes_solver_factory) :: this
      type(state_descriptor) :: descriptor
      integer, intent(in) :: n_states

      character(len=*), intent(in) :: method

      logical, intent(in) :: restart

      this%descriptor = descriptor
      this%restart = restart
      this%n_states = n_states

      if (method == 'cc3' .or. method == 'low memory cc2') then

         this%algorithm = 'non-linear davidson'

      else

         this%algorithm = 'davidson'

      end if

      call input%get_keyword('algorithm', 'solver cc es', this%algorithm)

   end function new_cc_es_amplitudes_solver_factory


   subroutine create(this, wf, solver)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(cc_es_amplitudes_solver_factory), intent(inout) :: this

      class(ccs), intent(inout) :: wf

      class(abstract_solver), allocatable, intent(out) :: solver

      if (trim(wf%name_) == 'ccsdt' .and. trim(this%descriptor%get_left_or_right()) == 'left') then

         call output%error_msg( &
                 'Could not create excited state solver. The algorithm allowing left excitation for CCSDT&
                 & method is not implemented.' &
              )

      end if

      call this%read_settings()
      call wf%prepare_for_excited_states(this%descriptor)
      call this%create_common_es_solver_components(wf)

      if (this%algorithm == 'diis') then

         call this%create_diis_es_solver(wf, solver)

      elseif (this%algorithm == 'davidson') then

         call this%create_davidson_es_solver(wf, solver)

      elseif (this%algorithm == 'non-linear davidson') then

         call this%create_nonlinear_davidson_es_solver(wf, solver)

      else

         call output%error_msg( &
                 'Could not create excited state solver. It may be that the algorithm is not implemented for&
                 & the method specified.' &
              )

      end if

   end subroutine create


   subroutine read_settings(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      use global_in, only: input

      implicit none

      class(cc_es_amplitudes_solver_factory), intent(inout) :: this

      this%max_iterations = 100
      this%records_in_memory = .false.

      call input%get_keyword('max iterations', 'solver cc es', this%max_iterations)

      call input%get_keyword('residual threshold', 'solver cc es', this%residual_threshold)

      this%energy_convergence = input%is_keyword_present('energy threshold', 'solver cc es')

      ! Note: value may be set to a default but may be unused due to "this%energy_convergence" being false
      call input%get_keyword('energy threshold', 'solver cc es', this%energy_threshold)

      call input%place_records_in_memory('solver cc es', this%records_in_memory)

   end subroutine read_settings


   subroutine create_common_es_solver_components(this, wf)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      use cc_es_start_vector_factory_class, only: cc_es_start_vector_factory
      use cc_es_projector_factory_class, only: cc_es_projector_factory
      use cc_es_storage_tool_class, only: cc_es_storage_tool
      use diagonal_eigen_preconditioner_tool_class, only: diagonal_eigen_preconditioner_tool
      use cc_es_olsen_preconditioner_tool_class, only: cc_es_olsen_preconditioner_tool
      use cc_triplet_jacobian_preconditioner_getter_class, only: cc_triplet_jacobian_preconditioner_getter

      implicit none

      class(cc_es_amplitudes_solver_factory), intent(inout) :: this
      class(ccs), intent(in) :: wf
      integer :: n_parameters

      class(cc_es_start_vector_factory), allocatable :: start_vector_factory
      class(cc_es_projector_factory), allocatable :: projector_factory

      n_parameters = wf%get_n_es_parameters(this%descriptor)

      start_vector_factory = cc_es_start_vector_factory(this%descriptor, this%n_states, this%restart)
      call start_vector_factory%create(wf, this%start_vectors)

      projector_factory = cc_es_projector_factory(this%descriptor)
      call projector_factory%create(wf, this%projector)

      this%convergence_checker = convergence_tool(this%energy_threshold, &
                                                  this%residual_threshold, &
                                                  this%energy_convergence)

      if (this%descriptor%get_spin_symmetry() == 'singlet') then

         this%preconditioner_getter = cc_jacobian_preconditioner_getter(wf, n_parameters)

      else if (this%descriptor%get_spin_symmetry() == 'triplet') then

         this%preconditioner_getter = cc_triplet_jacobian_preconditioner_getter(wf)

      else

         call output%error_msg( &
                 "Could not recognize the spin symmetry in cc_es_amplitude_solver_factory_class.F90!" &
              )

      end if

      if (input%is_keyword_present('olsen', 'solver cc es')) then

         this%preconditioner = cc_es_olsen_preconditioner_tool(wf, &
                                                               n_parameters, &
                                                               this%descriptor%get_left_or_right(), &
                                                               this%projector, &
                                                               this%records_in_memory)

      else

         this%preconditioner = diagonal_eigen_preconditioner_tool(this%preconditioner_getter)

      end if

      this%storer = cc_es_storage_tool(this%n_states, wf, this%descriptor)

   end subroutine create_common_es_solver_components


   subroutine create_folded_jacobian_transformer(wf, transformer, descriptor)
      !!
      !! Written by Alexander C. Paul, Jan 2023
      !!
      use state_descriptor_class, only: state_descriptor
      use folded_cc_jacobian_transformation_class, only: folded_cc_jacobian_transformation

      implicit none

      class(ccs), intent(in) :: wf
      class(folded_cc_jacobian_transformation), allocatable, intent(out) :: transformer

      type(state_descriptor), intent(in) :: descriptor

      transformer = folded_cc_jacobian_transformation(wf, descriptor)

   end subroutine create_folded_jacobian_transformer


   subroutine create_davidson_es_solver(this, wf, solver)
      !!
      !! Written by Sarai D. Folkestad, 2020
      !!
      !! Initializes the davidson solver with the correct tools
      !! for the determination of CC excitation energies
      !!
      use eigen_davidson_solver_class, only: eigen_davidson_solver
      use cc_jacobian_transformation_class, only: cc_jacobian_transformation

      implicit none

      class(cc_es_amplitudes_solver_factory), intent(inout) :: this
      class(ccs), intent(inout) :: wf
      class(abstract_solver), allocatable, intent(out) :: solver

      class(cc_jacobian_transformation), allocatable :: transformer

      real(dp) :: lindep_threshold
      integer :: max_dim_red

      if (trim(wf%name_) == 'low memory cc2' .or. trim(wf%name_) == 'cc3') &
         call output%error_msg('Excited state Davidson not implemented for (a0).', chars=[trim(wf%name_)])

      max_dim_red = max(100, 10 * this%n_states)
      call input%get_keyword('max reduced dimension', 'solver cc es', max_dim_red)

      transformer = cc_jacobian_transformation(wf, this%descriptor)

      lindep_threshold = min(1.0d-11, 0.1d0 * this%residual_threshold)

      solver = eigen_davidson_solver(transformer=transformer, &
                                     convergence_checker=this%convergence_checker, &
                                     storer=this%storer, &
                                     start_vector=this%start_vectors, &
                                     preconditioner=this%preconditioner, &
                                     projector=this%projector, &
                                     n_solutions=this%n_states, &
                                     n_parameters=wf%get_n_es_parameters(this%descriptor), &
                                     max_reduced_dimension=max_dim_red, &
                                     max_iterations=this%max_iterations, &
                                     reduced_space_in_memory=this%records_in_memory, &
                                     linear_dependence_threshold=lindep_threshold)

   end subroutine create_davidson_es_solver


   subroutine create_diis_es_solver(this, wf, solver)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      use linear_eigen_solver_class, only: linear_eigen_solver
      use nonlinear_eigen_solver_class, only: nonlinear_eigen_solver

      use diis_tool_class, only: diis_tool
      use diis_eigenvector_updater_class, only: diis_eigenvector_updater
      use eigen_diis_print_tool_class, only: eigen_diis_print_tool
      use cc_jacobian_transformation_class, only: cc_jacobian_transformation
      use folded_cc_jacobian_transformation_class, only: folded_cc_jacobian_transformation

      implicit none

      class(cc_es_amplitudes_solver_factory), intent(inout) :: this
      class(ccs), intent(inout) :: wf
      class(abstract_solver), allocatable, intent(out) :: solver

      type(diis_tool), dimension(:), allocatable :: diis_tools
      class(diis_eigenvector_updater), allocatable :: diis_updater
      class(cc_jacobian_transformation), allocatable :: transformer
      class(folded_cc_jacobian_transformation), allocatable :: folded_transformer
      type(eigen_diis_print_tool) :: printer

      integer :: diis_dimension, state
      logical :: crop
      character(len=21) :: storer_name

      diis_dimension = 20
      call input%get_keyword('diis dimension', 'solver cc es', diis_dimension)
      crop = input%is_keyword_present('crop', 'solver cc es')

      call printer%print_banner()
      call printer%print_settings(this%n_states, this%max_iterations)

      allocate(diis_tools(this%n_states))

      do state = 1, this%n_states

         write(storer_name, '(a,i3.3)')'diis_cc_es_singlet', state

         diis_tools(state) = diis_tool(name_=storer_name, &
                                       n_parameters=wf%get_n_es_parameters(this%descriptor), &
                                       n_equations=wf%get_n_es_parameters(this%descriptor), &
                                       dimension_=diis_dimension, &
                                       crop=crop, &
                                       records_in_memory=this%records_in_memory)

      end do

      diis_updater = diis_eigenvector_updater(diis_tools, &
                                              this%preconditioner_getter, &
                                              wf%get_n_es_parameters(this%descriptor), &
                                              this%n_states)

      if (trim(wf%name_) == 'low memory cc2' .or. trim(wf%name_) == 'cc3') then

         call this%create_folded_jacobian_transformer(wf, folded_transformer, this%descriptor)

         solver = nonlinear_eigen_solver(transformer=folded_transformer, &
                                         parameter_updater=diis_updater, &
                                         convergence_checker=this%convergence_checker, &
                                         storer=this%storer, &
                                         start_vectors=this%start_vectors, &
                                         projector=this%projector, &
                                         printer=printer, &
                                         n_roots=this%n_states, &
                                         n_parameters=wf%get_n_es_parameters(this%descriptor), &
                                         max_iterations=this%max_iterations)

      else

         transformer = cc_jacobian_transformation(wf, this%descriptor)

         solver = linear_eigen_solver(transformer=transformer, &
                                      parameter_updater=diis_updater, &
                                      convergence_checker=this%convergence_checker, &
                                      storer=this%storer, &
                                      start_vectors=this%start_vectors, &
                                      projector=this%projector, &
                                      printer=printer, &
                                      n_roots=this%n_states, &
                                      n_parameters=wf%get_n_es_parameters(this%descriptor), &
                                      max_iterations=this%max_iterations)

      end if

      deallocate(diis_tools)

   end subroutine create_diis_es_solver


   subroutine create_nonlinear_davidson_es_solver(this, wf, solver)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      !! Initializes the non-linear davidson solver with the correct tools
      !! for the determination of CC excitation energies
      !!
      use nonlinear_eigen_solver_class, only: nonlinear_eigen_solver

      use nonlinear_davidson_print_tool_class, only: nonlinear_davidson_print_tool
      use folded_cc_jacobian_transformation_class, only: folded_cc_jacobian_transformation
      use nonlinear_davidson_eigenvector_updater_class, only: nonlinear_davidson_eigenvector_updater

      implicit none

      class(cc_es_amplitudes_solver_factory), intent(inout) :: this
      class(ccs), intent(inout) :: wf
      class(abstract_solver), allocatable, intent(out) :: solver

      class(folded_cc_jacobian_transformation), allocatable :: transformer
      class(nonlinear_davidson_eigenvector_updater), allocatable :: updater

      type(nonlinear_davidson_print_tool) :: printer

      integer :: max_dim_red, max_micro_iterations
      real(dp) :: relative_micro_residual_threshold, lindep_threshold

      max_micro_iterations = 100
      max_dim_red = max(100, 10 * this%n_states)
      relative_micro_residual_threshold = 1.0d-1

      call input%get_keyword('max reduced dimension', 'solver cc es', max_dim_red)
      call input%get_keyword('max micro iterations', 'solver cc es', max_micro_iterations)
      call input%get_keyword('rel micro threshold', 'solver cc es', relative_micro_residual_threshold)

      call this%create_folded_jacobian_transformer(wf, transformer, this%descriptor)

      call printer%print_banner()
      call printer%print_settings(this%n_states, this%max_iterations)

      lindep_threshold = min(1.0d-11, 0.1d0 * this%residual_threshold)

      updater = nonlinear_davidson_eigenvector_updater(transformer, &
                                                       this%preconditioner, &
                                                       this%projector, &
                                                       wf%get_n_es_parameters(this%descriptor), &
                                                       this%n_states, &
                                                       this%residual_threshold, &
                                                       relative_micro_residual_threshold, &
                                                       max_micro_iterations, &
                                                       max_dim_red, &
                                                       lindep_threshold, &
                                                       this%records_in_memory)

      solver = nonlinear_eigen_solver(transformer=transformer, &
                                      parameter_updater=updater, &
                                      convergence_checker=this%convergence_checker, &
                                      storer=this%storer, &
                                      start_vectors=this%start_vectors, &
                                      projector=this%projector, &
                                      printer=printer, &
                                      n_roots=this%n_states, &
                                      n_parameters=wf%get_n_es_parameters(this%descriptor), &
                                      max_iterations=this%max_iterations)

   end subroutine create_nonlinear_davidson_es_solver


end module cc_es_amplitudes_solver_factory_class

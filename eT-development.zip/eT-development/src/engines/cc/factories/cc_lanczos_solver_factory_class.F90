

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_lanczos_solver_factory_class

   !!
   !! CC Lanczos amplitudes solver factory class
   !! Written by Andreas S. Skeidsvoll, Apr 2023
   !!

   use parameters
   use ccs_class, only: ccs
   use global_in, only: input
   use global_out, only: output

   use transformation_class, only: transformation
   use abstract_solver_class, only: abstract_solver
   use convergence_tool_class, only: convergence_tool
   use start_vector_tool_class, only: start_vector_tool
   use abstract_projection_tool_class, only: abstract_projection_tool
   use es_operator_on_state_start_vector_tool_class, only: es_operator_on_state_start_vector_tool
   use state_descriptor_class, only: state_descriptor
   use state_descriptor_class, only: es_type


   implicit none


   type :: cc_lanczos_solver_factory

      class(transformation), allocatable, private :: transformer
      class(convergence_tool), allocatable, private :: convergence_checker
      class(abstract_projection_tool), allocatable, private :: projector
      class(es_operator_on_state_start_vector_tool), allocatable, private :: left_start_vector_tool, &
                                                                             right_start_vector_tool

      character(len=200), private :: algorithm
      integer, private :: max_iterations, biorthogonalize_last, n_states
      logical, private :: records_in_memory, skip_convergence
      real(dp), private :: residual_threshold, deflation_threshold, overlap_threshold, min_energy, &
                           max_energy, min_transition_strength

      class(state_descriptor), allocatable :: descriptor_L, descriptor_R

   contains

      procedure, public :: create

      procedure, private :: read_settings
      procedure, private :: create_asymmetric_lanczos_solver
      procedure, private :: create_band_lanczos_solver


   end type cc_lanczos_solver_factory


   interface cc_lanczos_solver_factory

      procedure :: new_cc_lanczos_solver_factory

   end interface cc_lanczos_solver_factory


contains


   function new_cc_lanczos_solver_factory(type_) result(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2023
      !!
      implicit none

      type(es_type) :: type_
      type(cc_lanczos_solver_factory) :: this

      call input%get_keyword('algorithm', 'solver cc es', this%algorithm)

      this%descriptor_L = state_descriptor(left_or_right='left', &
                                           type_=type_, &
                                           spin_symmetry='singlet')

      this%descriptor_R = state_descriptor(left_or_right='right', &
                                           type_=type_, &
                                           spin_symmetry='singlet')

   end function new_cc_lanczos_solver_factory


   subroutine create(this, wf, solver)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2023
      !!
      implicit none

      class(cc_lanczos_solver_factory), intent(inout) :: this

      class(ccs), intent(inout) :: wf

      class(abstract_solver), allocatable, intent(out) :: solver

      integer :: max_iterations

      call this%read_settings()

      if (this%algorithm == 'asymmetric lanczos') then

         call this%create_asymmetric_lanczos_solver(wf, solver)

      elseif (this%algorithm == 'asymmetric band lanczos') then

         call input%get_keyword('max iterations', 'solver cc es', max_iterations)
         call wf%prepare_for_excited_states(this%descriptor_R)
         call this%create_band_lanczos_solver(wf, solver)

      else

         call output%error_msg( &
                 'Could not create Lanczos solver. It may be that the algorithm is not implemented for the&
                 & method specified.' &
              )

      end if

   end subroutine create


   subroutine read_settings(this)
      !!
      !! Written by Sarai D. Folkestad, Torsha Moitra,
      !! Andreas S. Skeidsvoll, 2021-2023
      !!
      use global_in, only: input

      implicit none

      class(cc_lanczos_solver_factory), intent(inout) :: this

      this%residual_threshold = 1.0d-3
      this%records_in_memory = .false.

      this%skip_convergence = .false.
      this%biorthogonalize_last = 0
      this%max_energy = 1000.0_dp
      this%min_energy = - 1000.0_dp
      this%min_transition_strength = 0.0_dp
      this%deflation_threshold = 1e-12_dp
      this%overlap_threshold = 1e-14_dp
      this%n_states = 1

      call input%get_keyword('max iterations', 'solver cc es', this%max_iterations)

      call input%get_keyword('residual threshold', 'solver cc es', this%residual_threshold)

      call input%place_records_in_memory('solver cc es', this%records_in_memory)

      call input%get_keyword('min energy', 'lanczos', this%min_energy)
      call input%get_keyword('max energy', 'lanczos', this%max_energy)

      call input%get_keyword('min transition strength', 'lanczos', this%min_transition_strength)

      if (input%is_keyword_present('skip convergence', 'lanczos')) this%skip_convergence = .true.

      this%biorthogonalize_last = this%max_iterations

      call input%get_keyword('biorthogonalize last', 'lanczos', this%biorthogonalize_last)

      call input%get_keyword('deflation threshold', 'lanczos', this%deflation_threshold)
      call input%get_keyword('overlap threshold', 'lanczos', this%overlap_threshold)

   end subroutine read_settings


   subroutine create_asymmetric_lanczos_solver(this, wf, solver)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2023
      !!
      !! Initializes the asymmetric Lanczos solver with the correct tools for the
      !! determination of CC excitation energies and transition properties.
      !!
      use asymmetric_lanczos_cc_es_class, only: asymmetric_lanczos_cc_es

      implicit none

      class(cc_lanczos_solver_factory), intent(inout) :: this
      class(ccs), intent(inout) :: wf
      class(abstract_solver), allocatable, intent(out) :: solver

      solver = asymmetric_lanczos_cc_es(wf=wf, descriptor=this%descriptor_L)

   end subroutine create_asymmetric_lanczos_solver


   subroutine create_band_lanczos_solver(this, wf, solver)
      !!
      !! Written by Andreas S. Skeidsvoll, Jan 2023
      !!
      !! Initializes the band Lanczos solver with the correct tools for the
      !! determination of CC excited states and transition properties.
      !!
      use cc_es_start_vector_factory_class, only: cc_es_start_vector_factory
      use cc_es_projector_factory_class, only: cc_es_projector_factory
      use band_lanczos_cc_es_class, only: band_lanczos_cc_es

      implicit none

      class(cc_lanczos_solver_factory), intent(inout) :: this

      class(ccs), intent(inout) :: wf
      class(abstract_solver), allocatable, intent(out) :: solver

      class(cc_es_start_vector_factory), allocatable :: left_restart_vector_factory, &
                                                        right_restart_vector_factory

      class(start_vector_tool), allocatable :: left_restart_vector_tool, right_restart_vector_tool

      class(cc_es_projector_factory), allocatable :: projector_factory

      left_restart_vector_factory = cc_es_start_vector_factory(this%descriptor_L, &
                                                               this%n_states, &
                                                               restart=.true.)
      right_restart_vector_factory = cc_es_start_vector_factory(this%descriptor_R, &
                                                                this%n_states, &
                                                                restart=.true.)

      call left_restart_vector_factory%create(wf, left_restart_vector_tool)
      call right_restart_vector_factory%create(wf, right_restart_vector_tool)

      this%left_start_vector_tool = es_operator_on_state_start_vector_tool(wf, &
                                                                           this%n_states, &
                                                                           left_restart_vector_tool, &
                                                                           this%descriptor_L)

      this%right_start_vector_tool = es_operator_on_state_start_vector_tool(wf, &
                                                                            this%n_states, &
                                                                            right_restart_vector_tool, &
                                                                            this%descriptor_R)

      projector_factory = cc_es_projector_factory(this%descriptor_L)
      call projector_factory%create(wf, this%projector)

      this%convergence_checker = convergence_tool(0.0_dp, &
                                                  this%residual_threshold, &
                                                  .false.)

      solver = band_lanczos_cc_es(wf=wf, &
                                  convergence_checker=this%convergence_checker, &
                                  left_start_vector_tool=this%left_start_vector_tool, &
                                  right_start_vector_tool=this%right_start_vector_tool, &
                                  projector=this%projector, &
                                  records_in_memory=this%records_in_memory, &
                                  max_iterations=this%max_iterations, &
                                  deflation_threshold=this%deflation_threshold, &
                                  overlap_threshold=this%overlap_threshold, &
                                  min_energy=this%min_energy, &
                                  max_energy=this%max_energy, &
                                  min_transition_strength=this%min_transition_strength, &
                                  biorthogonalize_last=this%biorthogonalize_last, &
                                  skip_convergence=this%skip_convergence, &
                                  descriptor_L=this%descriptor_L, &
                                  descriptor_R=this%descriptor_R)

   end subroutine create_band_lanczos_solver


end module cc_lanczos_solver_factory_class

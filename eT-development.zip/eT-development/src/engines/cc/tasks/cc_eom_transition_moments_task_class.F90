

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_eom_transition_moments_task_class

   !!
   !! CC EOM transition moments task class
   !! Written by Alexander C. Paul, Jan 2022
   !!

   use parameters
   use ccs_class, only: ccs
   use cc_transition_moments_task_class, only: cc_transition_moments_task
   use memory_manager_class, only: mem
   use global_out, only: output

   implicit none

   type, extends(cc_transition_moments_task) :: cc_eom_transition_moments_task

      integer, private :: n_initial_states
      integer, dimension(:), allocatable, private :: initial_states
      logical, private :: transition_moments, permanent_moments, dipole_length, dipole_velocity, &
                          rotatory_strength, all_initial_states, dipole_matrix_storage
      integer :: n_states


   contains

      procedure, public :: execute => execute_cc_eom_transition_moments_task

      procedure, public :: cleanup => cleanup_cc_eom_transition_moments_task

      procedure, private :: initialize_transition_moment_calculation
      procedure, private :: print_permanent_moments_summary
      procedure, private :: print_operator_for_initial_states
      procedure, private :: set_initial_states
      procedure, private :: read_settings

      procedure, private, nopass :: save_dipole_matrix

   end type cc_eom_transition_moments_task


   interface cc_eom_transition_moments_task

      procedure :: new_cc_eom_transition_moments_task

   end interface cc_eom_transition_moments_task


contains


   function new_cc_eom_transition_moments_task() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2022
      !!
      implicit none

      type(cc_eom_transition_moments_task) :: this

      this%name_ = 'Determining CC EOM transition moments'

   end function new_cc_eom_transition_moments_task


   subroutine execute_cc_eom_transition_moments_task(this, wf)
      !!
      !! Written by Josefine H. Andersen, Sarai D. Folkestad and Alexander C. Paul,
      !! Jacob Pedersen and Sonia Coriani, 2019-2023
      !!
      !! Computes EOM transition moments using transition densities
      !! and OEIs.
      !!

      implicit none

      class(cc_eom_transition_moments_task), intent(inout) :: this

      class(ccs), intent(inout), target :: wf

      integer :: n_operators, n_components, l, n_l, n_r
      character(len=18), dimension(:), allocatable :: operator_name
      character(len=1), dimension(:), allocatable :: operator_label
      real(dp), dimension(:, :, :, :), allocatable :: operator_matrix, transition_moment_matrix
      real(dp), dimension(:), allocatable :: energy_L, energy_R

      call this%print_header()
      call this%start_timer()

      call output%printf('m', ':: EOM properties calculation', fs='(/t3,a)')

      call this%read_settings()

      call wf%prepare_for_properties()

      call wf%initialize_gs_density()
      call wf%construct_gs_density()

      n_r = wf%R_es_states%n_total
      n_l = wf%L_es_states%n_total

      call mem%alloc(energy_L, n_r)
      call mem%alloc(energy_R, n_L)

      call wf%L_es_states%read_energies(energy_L)
      call wf%R_es_states%read_energies(energy_R)

      if (n_r /= n_l) &
         call output%error_msg("Different number of left and right states in transition moment calculation")

      this%n_states = n_r

      call this%set_initial_states()
      if (wf%R_es_states%n_es_types > 1 .and. any(this%initial_states > 0)) &
         call wf%diagonalize_subspace_jacobian(this%n_states)

      ! Energies may have changed due to subspace diagonalization
      call wf%L_es_states%read_energies(energy_L)
      call wf%R_es_states%read_energies(energy_R)

      call wf%initialize_density_intermediates(this%n_states)
      call wf%initialize_density_storer(this%n_states)

      call wf%density_storage%copy_density_in(wf%density, left_state=0, right_state=0)

      call wf%construct_eom_densities(this%n_initial_states, &
                                      this%initial_states, &
                                      this%transition_moments, &
                                      this%permanent_moments)

      call this%initialize_transition_moment_calculation(n_operators, &
                                                         n_components, &
                                                         operator_name, &
                                                         operator_label)

      call mem%alloc(operator_matrix, wf%n_mo, wf%n_mo, n_components, n_operators)

      call mem%alloc(transition_moment_matrix, &
                     this%n_states + 1, &
                     this%n_states + 1, &
                     n_components, &
                     n_operators, &
                     set_zero=.true.)

      do l = 1, n_operators

         call wf%get_t1_oei(trim(operator_name(l)), operator_matrix(:, :, :, l))

         call wf%compute_eom_operator_matrix(n_components, &
                                             operator_matrix(:, :, :, l), &
                                             transition_moment_matrix(:, :, :, l), &
                                             this%n_states)

      end do

      if (this%transition_moments) then

         call this%print_transition_moment_summary(wf, &
                                                   operator_label, &
                                                   n_operators, &
                                                   n_components, &
                                                   transition_moment_matrix, &
                                                   this%initial_states, &
                                                   calculation_type='EOM')

      else

         call this%print_transition_moment_summary(wf, &
                                                   operator_label, &
                                                   n_operators, &
                                                   n_components, &
                                                   transition_moment_matrix, &
                                                   initial_states=[0], &
                                                   calculation_type='EOM')

      end if

      if (this%permanent_moments) &
         call this%print_permanent_moments_summary(wf, &
                                                   'dipole', &
                                                   transition_moment_matrix(:, :, :, 1), &
                                                   n_components)

      call mem%dealloc(operator_matrix)

      if (this%dipole_matrix_storage) &
         call this%save_dipole_matrix(transition_moment_matrix(:, :, :, 1), this%n_states + 1)

      call mem%dealloc(transition_moment_matrix)

      deallocate(operator_name)
      deallocate(operator_label)

      call wf%destruct_density_intermediates

      call this%end_timer()

      call mem%dealloc(energy_L)
      call mem%dealloc(energy_R)

   end subroutine execute_cc_eom_transition_moments_task


   subroutine set_initial_states(this)
      !!
      !! Written Alexander C. Paul and Sarai D. Folkestad, Apr 2021
      !!
      !! Determine the states for which properties shall be calculated
      !! if we are doing transition moments or permanent moments:
      !!
      !!    Example of usage:
      !!    initial states: {0, 1, 2}
      !!    or: [0,2]
      !!
      !!    gives all transitions from the ground state
      !!       0 -> 1, 2, 3, ..
      !!    and excitations between excited state 1 and 2 (ordered according to energy)
      !!    to all other excited states
      !!       1 -> 2, 3, ...
      !!       2 -> 3, 4, ...
      !!    or properties of the excited states 1 and 2
      !!
      use global_in, only: input

      implicit none

      class(cc_eom_transition_moments_task), intent(inout) :: this

      integer, dimension(:), allocatable :: initial_states

      integer :: i

      if (input%is_keyword_present('initial states', 'cc response')) then

         this%n_initial_states = input%get_n_elements_for_keyword('initial states', &
                                                                  'cc response')

         call mem%alloc(initial_states, this%n_initial_states)

         call input%get_array_for_keyword('initial states', &
                                          'cc response', &
                                          this%n_initial_states, &
                                          initial_states)

         ! Transitions from the ground state shall always be considered
         if (any(initial_states == 0)) then

            call mem%alloc(this%initial_states, this%n_initial_states)

            this%initial_states = initial_states

            call mem%dealloc(initial_states)

         else

            ! Copy and add 0 as initial state

            call mem%alloc(this%initial_states, this%n_initial_states + 1)

            this%initial_states(1) = 0
            this%initial_states(2:) = initial_states

            call mem%dealloc(initial_states)

            this%n_initial_states = this%n_initial_states + 1

         end if

         if (this%n_initial_states > this%n_states + 1) then

            call output%error_msg( &
                    'Requested properties for more states than requested in the calculation.' &
                 )

         end if

         if (any(this%initial_states > this%n_states)) then

            call output%error_msg( &
                    'Requested properties for state with a number larger than the number of states' &
                 )

         end if

         if (any(this%initial_states < 0)) then
            call output%error_msg('Requested properties of state with a negative number.')
         end if

      elseif (this%all_initial_states) then

         this%n_initial_states = this%n_states + 1

         call mem%alloc(this%initial_states, this%n_initial_states)

         do i = 1, this%n_initial_states

            this%initial_states(i) = i - 1

         end do

      else

         ! Only calculate transitions from ground state (state 0)

         this%n_initial_states = 1

         call mem%alloc(this%initial_states, this%n_initial_states)

         this%initial_states(1) = 0

      end if

   end subroutine set_initial_states


   subroutine print_permanent_moments_summary(this, &
                                              wf, &
                                              operator_type, &
                                              electronic, &
                                              n_components)
      !!
      !! Written by Alexander C. Paul, May 2020
      !!
      use global_out, only: output

      implicit none

      class(cc_eom_transition_moments_task), intent(in) :: this

      class(ccs), intent(in) :: wf

      character(len=*), intent(in) :: operator_type
      integer, intent(in) :: n_components

      real(dp), dimension(this%n_states + 1, this%n_states + 1, n_components), intent(in) :: electronic

      real(dp), dimension(:), allocatable :: nuclear

      character(len=5), dimension(n_components) :: components

      call output%printf('m', '- Summary of EOM permanent moments calculation:', fs='(/t3,a)')

      call mem%alloc(nuclear, n_components)

      if (operator_type == 'dipole') then

         call output%printf('m', 'Total permanent dipole moments in [a.u.]:', fs='(/t6,a)')
         call output%print_separator('m', 41, '=', fs='(t6,a)')

         call output%printf('m', &
                            'Conversion factor from au to Debye: (f11.9)', &
                            reals=[au_to_debye], &
                            fs='(/t6,a)')

         nuclear = wf%get_nuclear_dipole()

         components = ['X', 'Y', 'Z']

      end if

      call this%print_operator_for_initial_states(nuclear, &
                                                  electronic, &
                                                  components, &
                                                  n_components)

      call mem%dealloc(nuclear)

   end subroutine print_permanent_moments_summary


   subroutine print_operator_for_initial_states(this, &
                                                nuclear, &
                                                electronic, &
                                                components, &
                                                n_components)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      implicit none

      class(cc_eom_transition_moments_task), intent(in) :: this

      integer, intent(in) :: n_components

      real(dp), dimension(this%n_states + 1, this%n_states + 1, n_components), intent(in) :: electronic

      real(dp), dimension(n_components), intent(in) :: nuclear

      character(len=5), dimension(n_components), intent(in) :: components

      character(len=18), dimension(this%n_initial_states + 1) :: column_labels

      real(dp), dimension(:, :), allocatable :: data_

      integer :: state_i, i, c

      call mem%alloc(data_, n_components, this%n_initial_states + 1)

      column_labels(1) = "Nuclear"
      data_(:, 1) = nuclear

      ! Select only the states that shall be printed

      do i = 1, this%n_initial_states

         state_i = this%initial_states(i)

         write(column_labels(i + 1), '(a,1x,i0)')"State", state_i

         do c = 1, n_components

            data_(c, i + 1) = nuclear(c) + electronic(state_i + 1, state_i + 1, c)

         end do

      end do

      call output%print_table("Comp.", &
                              components, &
                              column_labels, &
                              data_, &
                              n_components, &
                              this%n_initial_states + 1)

      call mem%dealloc(data_)

   end subroutine print_operator_for_initial_states


   subroutine read_settings(this)
      !!
      !! Written by Alexander C. Paul, Jan 2022
      !!
      use global_in, only: input

      implicit none

      class(cc_eom_transition_moments_task) :: this

      character(len=200) :: method

      this%dipole_length = input%is_keyword_present('dipole length', 'cc response')
      this%dipole_velocity = input%is_keyword_present('dipole velocity', 'cc response')
      this%rotatory_strength = input%is_keyword_present('rotatory strength', 'cc response')
      this%permanent_moments = input%is_keyword_present('permanent moments', 'cc response')
      this%transition_moments = input%is_keyword_present('transition moments', 'cc response')

      this%all_initial_states = .false.
      this%dipole_matrix_storage = .false.

      call input%get_keyword('method', 'solver cc propagation', method)

      if (trim(method) == 'diagonal td-eom-cc') then

         this%all_initial_states = .true.
         this%permanent_moments = .true.
         this%transition_moments = .true.
         this%dipole_matrix_storage = .true.

      end if

   end subroutine read_settings


   subroutine initialize_transition_moment_calculation(this, &
                                                       n_operators, &
                                                       n_components, &
                                                       operator_name, &
                                                       operator_label)
      !!
      !! Written by Jacob Pedersen and Sonia Coriani, Jan 2023
      !!
      implicit none

      class(cc_eom_transition_moments_task) :: this

      integer, intent(out) :: n_operators, n_components
      character(len=18) :: dipole, linear_momentum, angular_momentum
      character(len=18), dimension(:), allocatable, intent(inout) :: operator_name
      character(len=1), dimension(:), allocatable, intent(inout) :: operator_label

      dipole = 'dipole'
      linear_momentum = 'momentum'
      angular_momentum = 'angular momentum'

      n_components = 3

      if (this%rotatory_strength) then

         n_operators = 3
         operator_name = [dipole, linear_momentum, angular_momentum]
         operator_label = ['r', 'p', 'L']

      else if (this%dipole_velocity) then

         n_operators = 2
         operator_name = [dipole, linear_momentum]
         operator_label = ['r', 'p']

      else if (this%dipole_length) then

         n_operators = 1
         operator_name = [dipole]
         operator_label = ['r']

      else

         call output%error_msg('no operator selected in response calculation')

      end if

   end subroutine initialize_transition_moment_calculation


   subroutine cleanup_cc_eom_transition_moments_task(this)
      !!
      !! Written by Alexander C. Paul, Jan 2022
      !!
      implicit none

      class(cc_eom_transition_moments_task), intent(inout) :: this

      call mem%dealloc(this%initial_states)

   end subroutine cleanup_cc_eom_transition_moments_task


   subroutine save_dipole_matrix(electronic, n_states)
      !!
      !! Written by Andreas S. Skeidsvoll, Jul 2023
      !!
      use stream_file_class, only: stream_file

      implicit none

      integer, intent(in) :: n_states

      real(dp), dimension(n_states, n_states, 3), intent(in) :: electronic

      type(stream_file) :: dipole_matrix_file

      dipole_matrix_file = stream_file('cc_eom_dipole_matrix')

      call dipole_matrix_file%open_('rewind')
      call dipole_matrix_file%write_(n_states)
      call dipole_matrix_file%write_(electronic, 3 * n_states**2)
      call dipole_matrix_file%close_('keep')

   end subroutine save_dipole_matrix


end module cc_eom_transition_moments_task_class

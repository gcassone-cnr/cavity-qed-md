

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_lr_transition_moments_task_class

   !!
   !! CC linear response transition moments task class
   !! Written by Alexander C. Paul, Jan 2022
   !!

   use parameters
   use ccs_class, only: ccs
   use cc_transition_moments_task_class, only: cc_transition_moments_task
   use memory_manager_class, only: mem
   use global_out, only: output
   use stream_file_class, only: stream_file
   use cc_eta_xi_calculator_class, only: cc_eta_xi_calculator
   use cc_lr_eta_xi_calculator_class, only: cc_lr_eta_xi_calculator


   implicit none

   type, extends(cc_transition_moments_task) :: cc_lr_transition_moments_task

      logical, private :: dipole_length
      integer :: n_states

      real(dp), dimension(:, :), allocatable, private :: xiX
      real(dp), dimension(:, :), allocatable, private :: etaX

      type(stream_file), dimension(:), allocatable :: M_vectors

      class(cc_eta_xi_calculator), allocatable, private :: eta_xi_calculator

   contains

      procedure, public :: execute => execute_cc_lr_transition_moments_task

      procedure, private :: determine_M_vectors
      procedure, private :: solve_M_vector_equations

   end type cc_lr_transition_moments_task

   interface cc_lr_transition_moments_task

      procedure :: new_cc_lr_transition_moments_task

   end interface cc_lr_transition_moments_task


contains


   function new_cc_lr_transition_moments_task() result(this)
      !!
      !! Written by Alexander C. Paul, Jan 2022
      !!
      use global_in, only: input

      implicit none

      type(cc_lr_transition_moments_task) :: this

      this%name_ = 'Determining CC LR transition moments'

      this%dipole_length = input%is_keyword_present('dipole length', 'cc response')

      if (.not. this%dipole_length) call output%error_msg('No operator selected in response calculation')

   end function new_cc_lr_transition_moments_task


   subroutine execute_cc_lr_transition_moments_task(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad, Nov 2019
      !!
      !! Adapted from routines written by Josefine H. Andersen, spring 2019.
      !!
      !! Routine that performs three tasks:
      !!
      !!    - Calls routine to determine the M vectors, which are needed to compute the
      !!      transition moments in response theory
      !!
      !!    - Calls wavefunction routine that computes the moments and strengths from
      !!      the etaX, xiX and M vectors.
      !!
      !!    - Calls routine to print the transition moments / strengths to output
      !!
      !! This routine was based on a deprecated routine for EOM moments
      !! (Josefine H. Andersen, Sarai D. Folkestad, June 2019). Reintroduced
      !! with M vector contributions and making use of skip_states array
      !! (Eirik F. Kjoenstad, Nov 2019).
      !! Removed skip_states array as the parallel states are removed by the engine
      !! (Alexander C. Paul Sep 2020)
      !!
      implicit none

      class(cc_lr_transition_moments_task), intent(inout) :: this
      class(ccs), intent(inout), target :: wf

      real(dp), dimension(:, :, :, :), allocatable :: transition_moments

      integer :: state, component, n_operators, n_components
      character(len=1), dimension(1) :: operator_label

      integer :: n_r, n_l

      real(dp), dimension(:), allocatable :: M  ! M vector associated with state

      call this%print_header()
      call this%start_timer()

      call wf%prepare_for_properties

      ! CCLR currently only for dipole operator
      n_operators = 1
      n_components = 3
      operator_label = ['q']

      n_r = wf%R_es_states%n_total
      n_l = wf%L_es_states%n_total

      if (n_r /= n_l) &
         call output%error_msg("Different number of left and right states in transition moment calculation")

      this%n_states = n_r

      ! Dipole matrix: only first row and column will be computed for TM from the GS
      call mem%alloc(transition_moments, this%n_states + 1, this%n_states + 1, n_components, n_operators)

      ! Currently for singlet states only.
      call mem%alloc(this%xiX, wf%n_es_amplitudes, n_components)
      call mem%alloc(this%etaX, wf%n_es_amplitudes, n_components)

      this%eta_xi_calculator = cc_lr_eta_xi_calculator(wf)
      call this%eta_xi_calculator%calculate(this%xiX, this%etaX)

      call this%determine_M_vectors(wf)

      call mem%alloc(M, wf%n_es_amplitudes)

      do state = 1, this%n_states

         call this%M_vectors(state)%open_('rewind')
         call this%M_vectors(state)%read_(M, wf%n_es_amplitudes)
         call this%M_vectors(state)%close_("delete")




         do component = 1, n_components

            call wf%calculate_lr_transition_strength(this%etaX(:, component), &
                                                     this%xiX(:, component), &
                                                     state, &
                                                     transition_moments(state + 1, 1, component, &
                                                        n_operators), &
                                                     transition_moments(1, state + 1, component, &
                                                        n_operators), &
                                                     M)

         end do

      end do


      call mem%dealloc(M)

      call mem%dealloc(this%xiX)
      call mem%dealloc(this%etaX)

      call this%print_transition_moment_summary(wf, &
                                                operator_label, &
                                                n_operators, &
                                                n_components, &
                                                transition_moments, &
                                                initial_states=[0], &
                                                calculation_type='LR')

      call mem%dealloc(transition_moments)

      call this%end_timer()

   end subroutine execute_cc_lr_transition_moments_task


   subroutine determine_M_vectors(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad and Josefine H. Andersen, 2019
      !!
      !! Determines the solutions to the equations
      !!
      !!    (A^T + omega_k I) M_k = -F R_k,
      !!
      !! where F is the so-called F transformation,
      !! (F_mu,nu = < Lambda | [[H-bar,tau_mu],tau_nu] | HF > ), and
      !! the omega_k are the excitation energies.
      !!
      !! The M vectors are required to compute the transition moments
      !! using CC response theory.
      !!
      !! On exit, the converged M vectors are stored in the file array
      !! this%M_vectors.
      !!
      !! This solver wrapper routine, and the file storage for M vectors, was made by
      !! Eirik F. Kjoenstad, Nov 2019. It is adapted/based on the general structure set up
      !! to determine M vectors originally written by Josefine H. Andersen, spring 2019.
      !!
      implicit none

      class(cc_lr_transition_moments_task), intent(inout) :: this

      class(ccs) :: wf

      integer :: k

      real(dp), dimension(:), allocatable :: R  ! Stores R_k temporarily
      real(dp), dimension(:, :), allocatable :: minus_FR  ! [-F R_k], k = 1, 2, ..., n_singlet_states

      character(len=200) :: file_name

      real(dp) :: energy_R

      ! Build the matrix FR of right-hand-sides, -FR = [-F R_k], k = 1, 2, ..., n_singlet_states

      call mem%alloc(R, wf%n_es_amplitudes)
      call mem%alloc(minus_FR, wf%n_es_amplitudes, this%n_states)

      do k = 1, this%n_states

         call wf%R_es_states%read_(k, R, energy_R)
         call wf%F_transformation(R, minus_FR(:, k))

      end do

      call mem%dealloc(R)

      call dscal(wf%n_es_amplitudes * this%n_states, - one, minus_FR, 1)

      ! Initialize file array to store the converged M_vectors

      allocate(this%M_vectors(this%n_states))

      do k = 1, this%n_states

         write(file_name, '(a, i3.3)')'M_vector_state_', k
         this%M_vectors(k) = stream_file(trim(file_name))

      end do

      ! Converge and store M vectors
      call this%solve_M_vector_equations(wf, minus_FR, this%M_vectors)

      call mem%dealloc(minus_FR)

   end subroutine determine_M_vectors


   subroutine solve_M_vector_equations(this, wf, minus_FR, M_files)
      !!
      !! Written by Eirik Kjoenstad, Oct 2022
      !!
      use global_in, only: input

      use file_linear_equation_storage_tool_class, only: file_linear_equation_storage_tool
      use vector_copy_getter_class, only: vector_copy_getter
      use linear_davidson_multiple_solutions_print_tool_class, &
         only: linear_davidson_multiple_solutions_print_tool
      use null_projection_tool_class, only: null_projection_tool

      use cc_jacobian_transformation_class, only: cc_jacobian_transformation
      use linear_davidson_solver_class, only: linear_davidson_solver
      use cc_jacobian_preconditioner_getter_class, only: cc_jacobian_preconditioner_getter
      use convergence_tool_class, only: convergence_tool
      use vector_getter_class, only: vector_getter
      use preconditioned_rhs_class, only: preconditioned_rhs

      implicit none

      class(cc_lr_transition_moments_task), intent(in) :: this
      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_es_amplitudes, this%n_states), intent(in), target :: minus_FR

      class(stream_file), dimension(this%n_states), intent(inout), target :: M_files

      class(linear_davidson_solver), allocatable :: solver
      class(cc_jacobian_transformation), allocatable :: transformer
      class(file_linear_equation_storage_tool), allocatable :: storer
      class(vector_copy_getter), allocatable :: rhs_getter
      class(cc_jacobian_preconditioner_getter), allocatable :: preconditioner_getter
      class(linear_davidson_multiple_solutions_print_tool), allocatable :: printer
      class(null_projection_tool), allocatable :: projector
      type(convergence_tool), allocatable :: convergence_checker
      class(vector_getter), allocatable :: start_vector



      real(dp), dimension(:), allocatable :: frequencies

      integer :: max_iterations
      logical :: records_in_memory
      real(dp) :: threshold


      threshold = 1.0d-3
      max_iterations = 100
      records_in_memory = .false.

      call input%get_keyword('threshold', 'solver cc response', threshold)
      call input%get_keyword('max iterations', 'solver cc response', max_iterations)
      call input%place_records_in_memory('solver cc response', records_in_memory)

      printer = linear_davidson_multiple_solutions_print_tool(print_level='n')

      transformer = cc_jacobian_transformation(wf, left_or_right='left')

      storer = file_linear_equation_storage_tool(n_parameters=wf%n_es_amplitudes, &
                                                 n_solutions=this%n_states, &
                                                 files=M_files)

      preconditioner_getter = cc_jacobian_preconditioner_getter(wf, wf%n_es_amplitudes)

      rhs_getter = vector_copy_getter(n_parameters=wf%n_es_amplitudes, &
                                      n_vectors=this%n_states, &
                                      vectors=minus_FR)

      projector = null_projection_tool(wf%n_es_amplitudes)


      call mem%alloc(frequencies, this%n_states)

      call wf%R_es_states%read_energies(frequencies)
      call dscal(this%n_states, - one, frequencies, 1)

      start_vector = preconditioned_rhs(wf%n_es_amplitudes, &
                                        this%n_states, &
                                        rhs_getter, &
                                        preconditioner_getter, &
                                        this%n_states, &
                                        frequencies)

      convergence_checker = convergence_tool(threshold)

      solver = linear_davidson_solver(transformer=transformer, &
                                      convergence_checker=convergence_checker, &
                                      storer=storer, &
                                      preconditioner_getter=preconditioner_getter, &
                                      rhs_getter=rhs_getter, &
                                      printer=printer, &
                                      projector=projector, &
                                      n_parameters=wf%n_es_amplitudes, &
                                      n_rhs=this%n_states, &
                                      n_frequencies=this%n_states, &
                                      max_iterations=max_iterations, &
                                      frequencies=frequencies, &
                                      linear_dependence_threshold=min(1.0d-11, threshold), &
                                      reduced_space_in_memory=records_in_memory, &
                                      max_reduced_dimension=100, &
                                      start_vector=start_vector)

      call solver%run()
      call solver%cleanup()
      call mem%dealloc(frequencies)

   end subroutine solve_M_vector_equations


end module cc_lr_transition_moments_task_class

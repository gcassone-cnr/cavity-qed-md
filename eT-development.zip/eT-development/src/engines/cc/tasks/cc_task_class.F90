

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_task_class

   !!
   !! CC task class
   !! Written by Eirik F. Kjoenstad, 2021
   !!

   use abstract_task_class, only: abstract_task
   use ccs_class, only: ccs

   implicit none

   type, abstract, extends(abstract_task) :: cc_task

   contains

      procedure(execute), public, deferred :: execute

   end type cc_task


   abstract interface

      subroutine execute(this, wf)

         import :: ccs, cc_task

         implicit none

         class(cc_task), intent(inout) :: this

         class(ccs), intent(inout), target :: wf

      end subroutine execute

   end interface


contains

end module cc_task_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_eom_dyson_orbitals_task_class

   !!
   !! CC EOM dyson orbitals task class
   !! Written by Alexander C. Paul, 2022-2023
   !!
   !! Construct Dyson orbitals which are defined as overlaps between
   !! initial (N-electron) states and final states with N + 1 electrons.
   !! The Dyson orbitals can be expanded in MO basis
   !!    phi_Dyson = sum_p gamma_p MO_p,
   !! where
   !!    gamma_p = < Psi_N-1 | a_p | Psi_N > for left dyson orbitals
   !! and
   !!    gamma_p = < Psi_N | a_p | Psi_N-1 > for right dyson orbitals
   !!

   use parameters
   use ccs_class, only: ccs
   use global_out, only: output
   use cc_task_class, only: cc_task
   use memory_manager_class, only: mem

   implicit none

   type, extends(cc_task) :: cc_eom_dyson_orbitals_task

   contains

      procedure, public :: execute => execute_cc_eom_dyson_orbitals_task

      procedure, private, nopass :: print_dyson_summary

   end type cc_eom_dyson_orbitals_task


   interface cc_eom_dyson_orbitals_task

      procedure :: new_cc_eom_dyson_orbitals_task

   end interface cc_eom_dyson_orbitals_task


contains


   function new_cc_eom_dyson_orbitals_task() result(this)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      implicit none

      type(cc_eom_dyson_orbitals_task) :: this

      this%name_ = 'Determining CC EOM dyson orbitals'

   end function new_cc_eom_dyson_orbitals_task


   subroutine execute_cc_eom_dyson_orbitals_task(this, wf)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      implicit none

      class(cc_eom_dyson_orbitals_task), intent(inout) :: this
      class(ccs), intent(inout), target :: wf

      real(dp), dimension(:), allocatable :: dyson_L_dot_R
      real(dp), dimension(:, :), allocatable :: left_dyson_orbitals, right_dyson_orbitals
      real(dp), dimension(:), allocatable :: energies
      integer :: n_states

      call this%print_header()
      call this%start_timer()

      call wf%prepare_for_properties()
      call wf%initialize_gs_density()
      call wf%construct_gs_density()

      call output%printf('m', ':: EOM Dyson calculation', fs='(/t3,a)')

      n_states = wf%L_es_states%n_total
      call mem%alloc(energies, n_states)
      call wf%L_es_states%read_energies(energies)

      call mem%alloc(dyson_L_dot_R, n_states)
      call mem%alloc(right_dyson_orbitals, wf%n_mo, n_states)
      call mem%alloc(left_dyson_orbitals, wf%n_mo, n_states)

      call wf%initialize_density_intermediates(n_states)

      call wf%initialize_dyson_files()

      call wf%construct_dyson_orbitals(left_dyson_orbitals, &
                                       right_dyson_orbitals, &
                                       dyson_L_dot_R, &
                                       n_states)

      call this%print_dyson_summary(n_states, energies, dyson_L_dot_R)

      call mem%dealloc(energies)

      call mem%dealloc(dyson_L_dot_R)
      call mem%dealloc(right_dyson_orbitals)
      call mem%dealloc(left_dyson_orbitals)

      call wf%destruct_density_intermediates()

   end subroutine execute_cc_eom_dyson_orbitals_task


   subroutine print_dyson_summary(n, ip, dyson_L_dot_R)
      !!
      !! Written by Alexander C. Paul, May 2021
      !!
      implicit none

      integer, intent(in) :: n
      real(dp), dimension(n), intent(in) :: ip, dyson_L_dot_R

      integer :: p

      call output%printf('m', '- Summary of Dyson orbital calculation:', fs='(/t3,a)', ll=90)
      call output%printf('m', 'State    IP [eV]    Left*Right', fs='(/t6,a)', ll=90)
      call output%print_separator('m', 32, '-', fs='(t6,a)')

      do p = 1, n

         call output%printf('m', &
                            '(i4)   (f9.4)(f16.10)', &
                            ints=[p], &
                            fs='(t6,a)', &
                            reals=[ip(p) * Hartree_to_eV, dyson_L_dot_R(p)], &
                            ll=90)

      end do

      call output%print_separator('m', 32, '-', fs='(t6,a)')

   end subroutine print_dyson_summary


end module cc_eom_dyson_orbitals_task_class

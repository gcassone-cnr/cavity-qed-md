

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_propagation_task_class

   !!
   !! CC propagation task class
   !! Written by Eirik F. Kjoenstad, Alice Balbi, Andreas S. Skeidsvoll 2021-2022
   !!

   use ccs_class, only: ccs
   use cc_task_class, only: cc_task
   use cc_propagation_solver_factory_class, only: cc_propagation_solver_factory

   implicit none

   type, extends(cc_task) :: cc_propagation_task

      type(cc_propagation_solver_factory), allocatable, private :: propagation_solver_factory

   contains

      procedure, public :: execute => execute_cc_propagation_task

   end type cc_propagation_task


   interface cc_propagation_task

      procedure :: new_cc_propagation_task

   end interface cc_propagation_task


contains


   function new_cc_propagation_task() result(this)
      !!
      !! Written by Alexander C. Paul, Jan 2022
      !!
      implicit none

      type(cc_propagation_task) :: this

      this%name_ = 'Real-time propagation of CC state'

   end function new_cc_propagation_task


   subroutine execute_cc_propagation_task(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad, Alice Balbi, Andreas S. Skeidsvoll, 2021-2022
      !!
      use propagation_solver_class, only: propagation_solver
      use electric_field_class, only: electric_field

      implicit none

      class(cc_propagation_task), intent(inout) :: this

      class(ccs), intent(inout), target :: wf

      class(electric_field), allocatable :: field
      class(propagation_solver), allocatable :: solver

      this%propagation_solver_factory = cc_propagation_solver_factory()

      field = electric_field()
      call field%read_settings()

      call this%propagation_solver_factory%create(wf, field, solver)
      call solver%run()

      call field%cleanup()

   end subroutine execute_cc_propagation_task


end module cc_propagation_task_class

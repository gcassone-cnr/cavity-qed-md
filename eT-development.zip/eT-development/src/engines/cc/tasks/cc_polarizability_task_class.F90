

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_polarizability_task_class

   !!
   !! CC polarizability task class
   !! Written by Alexander C. Paul, Sarai D. Folkestad, and Eirik F. Kjoenstad, 2022
   !!

   use parameters
   use global_out, only: output
   use memory_manager_class, only: mem
   use ccs_class, only: ccs
   use cc_task_class, only: cc_task
   use stream_file_class, only: stream_file
   use cc_eta_xi_calculator_class, only: cc_eta_xi_calculator
   use cc_eom_eta_xi_calculator_class, only: cc_eom_eta_xi_calculator
   use cc_lr_eta_xi_calculator_class, only: cc_lr_eta_xi_calculator
   use cc_F_transformation_class, only: cc_F_transformation
   use cc_null_F_transformation_class, only: cc_null_F_transformation
   use cc_lr_F_transformation_class, only: cc_lr_F_transformation

   implicit none

   type, extends(cc_task) :: cc_polarizability_task

      logical, public :: eom
      logical, public :: asymmetric

      real(dp), dimension(:, :), allocatable, public :: xiX
      real(dp), dimension(:, :), allocatable, public :: etaX

      type(stream_file), dimension(:, :, :), allocatable :: t_response_files
      type(stream_file), dimension(:, :, :), allocatable :: tbar_response_files

      integer, public :: n_frequencies = 0
      real(dp), dimension(:), allocatable, public :: frequencies

      logical, dimension(:), allocatable, public :: compute_t_response
      logical, dimension(:, :), allocatable, public :: compute_polarizability

      class(cc_eta_xi_calculator), allocatable, private :: eta_xi_calculator
      class(cc_F_transformation), allocatable, private :: F_transformation

   contains

      procedure, public :: execute => execute_cc_polarizability_task

      procedure, public :: calculate_polarizability => calculate_polarizability_cc_polarizability_task
      procedure, public :: initialize_response_files => initialize_response_files_cc_polarizability_task
      procedure, public :: determine_t_or_tbar_responses => &
                           determine_t_or_tbar_responses_cc_polarizability_task

      procedure, private :: read_and_initialize_frequencies
      procedure, private :: solve_response_equations

      procedure, private :: set_polarizability_components_to_compute
      procedure, private :: set_t_response_components_to_compute
      procedure, private :: set_symmetric_response_components_to_compute
      procedure, private :: set_asymmetric_response_components_to_compute
      procedure, private :: compute_symmetric_polarizability_component
      procedure, private :: compute_asymmetric_polarizability_component
      procedure, private :: read_response_vector

      final :: destructor

   end type cc_polarizability_task


   interface cc_polarizability_task

      procedure :: new_cc_polarizability_task

   end interface cc_polarizability_task


contains


   function new_cc_polarizability_task() result(this)
      !!
      !! Written by Alexander C. Paul, Jan 2022
      !!
      use global_in, only: input

      implicit none

      type(cc_polarizability_task) :: this

      this%name_ = 'Determining CC polarizabilities'

      this%eom = input%is_keyword_present('eom', 'cc response')

      this%asymmetric = input%is_keyword_present('asymmetric', 'cc response')

      if (this%asymmetric) then

         if (.not. input%is_keyword_present('response components', 'cc response')) then

            call output%error_msg('Requested asymmetric polarizabilities, but no ' // &
               'response components were specified!')

         else if (.not. this%eom) then

            call output%error_msg('LR asymmetric polarizabilities are not yet implemented!')

         end if

      end if

   end function new_cc_polarizability_task


   subroutine execute_cc_polarizability_task(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !! Revised by Anna Kristina Schnack-Petersen, Oct 2022
      !! to include asymmetric EOM polarizabilities
      !!
      implicit none

      class(cc_polarizability_task), intent(inout) :: this
      class(ccs), intent(inout), target :: wf

      call this%print_header()
      call this%start_timer()

      call this%read_and_initialize_frequencies()

      call this%initialize_response_files('dipole_t', this%t_response_files)

      allocate(this%compute_polarizability(3, 3))
      allocate(this%compute_t_response(3))

      call this%set_polarizability_components_to_compute()
      call this%set_t_response_components_to_compute()

      call mem%alloc(this%xiX, wf%n_es_amplitudes, 3)
      call mem%alloc(this%etaX, wf%n_es_amplitudes, 3)

      call wf%prepare_for_properties()

      if (this%eom) then

         this%eta_xi_calculator = cc_eom_eta_xi_calculator(wf)
         this%F_transformation = cc_null_F_transformation(wf)

      else

         this%eta_xi_calculator = cc_lr_eta_xi_calculator(wf)
         this%F_transformation = cc_lr_F_transformation(wf)

      end if

      call this%eta_xi_calculator%calculate(this%xiX, this%etaX)

      call this%determine_t_or_tbar_responses(wf, this%xiX, 'amplitude', 'right', this%t_response_files)

      if (this%asymmetric) then

         call this%initialize_response_files('dipole_tbar', this%tbar_response_files)

         call this%determine_t_or_tbar_responses(wf, &
                                                 this%etaX, &
                                                 'multiplier', &
                                                 'left', &
                                                 this%tbar_response_files)

      end if

      call this%calculate_polarizability(wf)

      call mem%dealloc(this%xiX)
      call mem%dealloc(this%etaX)

      call this%end_timer()

   end subroutine execute_cc_polarizability_task


   subroutine read_and_initialize_frequencies(this)
      !!
      !! Written Eirik F. Kjoenstad, 2022
      !!
      use global_in, only: input

      implicit none

      class(cc_polarizability_task) :: this

      if (input%is_keyword_present('frequencies', 'cc response')) then

         this%n_frequencies = input%get_n_elements_for_keyword('frequencies', 'cc response')

         call mem%alloc(this%frequencies, this%n_frequencies)

         call input%get_array_for_keyword('frequencies', &
                                          'cc response', &
                                          this%n_frequencies, &
                                          this%frequencies)

      else

         call output%error_msg( &
                 'Requested polarizabilities, but no frequencies were provided!' &
              )


      end if

   end subroutine read_and_initialize_frequencies


   subroutine initialize_response_files_cc_polarizability_task(this, operator_type, response_files)
      !!
      !! Written Eirik F. Kjoenstad, 2022
      !! Generalized to any operator and to use for either t or tbar response
      !! by T. Moitra and A. K. Schnack-Petersen, 2022
      !!
      !! Note that only the dipole operator is available so far.

      implicit none

      class(cc_polarizability_task) :: this

      integer :: component, freq, sign_
      character(len=*), intent(in) :: operator_type
      character(len=200) :: file_name

      type(stream_file), dimension(:, :, :), allocatable, intent(out) :: response_files

      allocate(response_files(this%n_frequencies, 3, 2))

      ! We have t or tbar responses for a given frequency, component (x,y,z), and sign (+,-)

      do component = 1, 3
         do freq = 1, this%n_frequencies
            do sign_ = 1, 2

               write(file_name, '(3(a, i3.3))') trim(operator_type) // '_', component, '_frequency_', freq, &
                  '_sign_', sign_

               response_files(freq, component, sign_) = stream_file(file_name)

            end do
         end do
      end do

   end subroutine initialize_response_files_cc_polarizability_task


   subroutine determine_t_or_tbar_responses_cc_polarizability_task(this, &
                                                                   wf, &
                                                                   unscaled_rhs, &
                                                                   response_type, &
                                                                   left_or_right, &
                                                                   response_file)
      !!
      !! Written by Eirik F. Kjoenstad, Anna Kristina Schnack-Petersen and Torsha Moitra, 2021-2022
      !!
      use array_initialization, only: copy_and_scale

      implicit none

      class(cc_polarizability_task) :: this

      class(ccs) :: wf

      real(dp), dimension(wf%n_es_amplitudes, 3), intent(in) :: unscaled_rhs
      real(dp), dimension(:), allocatable :: rhs

      integer :: q, sign_

      real(dp) :: prefactor

      character(len=1) :: sign_character
      character(len=*), intent(in) :: response_type
      character(len=*), intent(in) :: left_or_right

      type(stream_file), dimension(this%n_frequencies, 3, 2) :: response_file

      call wf%prepare_for_jacobian()

      call mem%alloc(rhs, wf%n_es_amplitudes)

      do q = 1, 3

         if (.not. this%compute_t_response(q)) cycle

         call copy_and_scale(- one, unscaled_rhs(:, q), rhs, wf%n_es_amplitudes)

         do sign_ = 1, 2

            sign_character = '-'
            if (sign_ == 2) sign_character = '+'

            call output%printf('v', 'Determining ' // trim(response_type), fs='(/t3,a)')

            call output%printf('v', &
                               'Asking solver to get response for ' // &
                                  'component (i0) and ((a1))-frequencies.', &
                               ints=[q], &
                               chars=[sign_character], &
                               fs='(t3,a)')

            prefactor = real((- 1)**sign_, kind=dp)  ! for frequencies

            call this%solve_response_equations(wf=wf, &
                                               frequencies=prefactor * this%frequencies, &
                                               rhs=rhs, &
                                               solution_files=response_file(:, q, sign_), &
                                               left_or_right=left_or_right)

         end do
      end do

      call mem%dealloc(rhs)

   end subroutine determine_t_or_tbar_responses_cc_polarizability_task


   subroutine solve_response_equations(this, wf, frequencies, rhs, solution_files, left_or_right)
      !!
      !! Written by Eirik Kjoenstad, Oct 2022
      !!
      !! Solves (A - freq_k) X_k = rhs and stores result in solution_files(k).
      !!
      use global_in, only: input

      use file_linear_equation_storage_tool_class, only: file_linear_equation_storage_tool
      use vector_copy_getter_class, only: vector_copy_getter
      use linear_davidson_multiple_solutions_print_tool_class, &
         only: linear_davidson_multiple_solutions_print_tool
      use null_projection_tool_class, only: null_projection_tool
      use convergence_tool_class, only: convergence_tool

      use cc_jacobian_transformation_class, only: cc_jacobian_transformation
      use linear_davidson_solver_class, only: linear_davidson_solver
      use cc_jacobian_preconditioner_getter_class, only: cc_jacobian_preconditioner_getter

      use vector_getter_class, only: vector_getter
      use preconditioned_rhs_class, only: preconditioned_rhs

      implicit none

      class(cc_polarizability_task), intent(inout) :: this

      class(ccs), intent(in) :: wf

      real(dp), dimension(this%n_frequencies), intent(in) :: frequencies

      real(dp), dimension(wf%n_es_amplitudes), intent(in) :: rhs

      character(len=*), intent(in) :: left_or_right

      class(stream_file), dimension(this%n_frequencies), intent(inout) :: solution_files

      class(linear_davidson_solver), allocatable :: solver
      class(cc_jacobian_transformation), allocatable :: transformer
      class(file_linear_equation_storage_tool), allocatable :: storer
      class(vector_copy_getter), allocatable :: rhs_getter
      class(cc_jacobian_preconditioner_getter), allocatable :: preconditioner_getter
      class(linear_davidson_multiple_solutions_print_tool), allocatable :: printer
      class(null_projection_tool), allocatable :: projector
      type(convergence_tool), allocatable :: convergence_checker
      class(vector_getter), allocatable :: start_vector

      integer :: max_iterations
      logical :: records_in_memory
      real(dp) :: threshold

      threshold = 1.0d-3
      max_iterations = 100
      records_in_memory = .false.

      call input%get_keyword('threshold', 'solver cc response', threshold)
      call input%get_keyword('max iterations', 'solver cc response', max_iterations)
      call input%place_records_in_memory('solver cc response', records_in_memory)

      printer = linear_davidson_multiple_solutions_print_tool(print_level='n')

      transformer = cc_jacobian_transformation(wf, left_or_right=trim(left_or_right))

      storer = file_linear_equation_storage_tool(n_parameters=wf%n_es_amplitudes, &
                                                 n_solutions=this%n_frequencies, &
                                                 files=solution_files)

      preconditioner_getter = cc_jacobian_preconditioner_getter(wf, wf%n_es_amplitudes)

      rhs_getter = vector_copy_getter(n_parameters=wf%n_es_amplitudes, &
                                      n_vectors=1, &
                                      vectors=rhs)

      projector = null_projection_tool(wf%n_es_amplitudes)
      convergence_checker = convergence_tool(threshold)

      start_vector = preconditioned_rhs(wf%n_es_amplitudes, &
                                        1, &
                                        rhs_getter, &
                                        preconditioner_getter, &
                                        this%n_frequencies, &
                                        frequencies)

      solver = linear_davidson_solver(transformer=transformer, &
                                      convergence_checker=convergence_checker, &
                                      storer=storer, &
                                      preconditioner_getter=preconditioner_getter, &
                                      rhs_getter=rhs_getter, &
                                      printer=printer, &
                                      projector=projector, &
                                      n_parameters=wf%n_es_amplitudes, &
                                      n_rhs=1, &
                                      n_frequencies=this%n_frequencies, &
                                      max_iterations=max_iterations, &
                                      frequencies=frequencies, &
                                      linear_dependence_threshold=min(1.0d-11, threshold), &
                                      reduced_space_in_memory=records_in_memory, &
                                      max_reduced_dimension=100, &
                                      start_vector=start_vector)


      call solver%run()
      call solver%cleanup()

   end subroutine solve_response_equations


   subroutine set_polarizability_components_to_compute(this)
      !!
      !! Written by Alexander C. Paul and A. K. Schnack-Petersen, 2021-2022
      !!
      use global_in, only: input

      implicit none

      class(cc_polarizability_task), intent(inout) :: this

      character(len=200), dimension(:), allocatable :: polarizabilities

      integer :: k, n_polarizabilities

      this%compute_polarizability = .false.

      n_polarizabilities = input%get_n_elements_for_keyword('polarizabilities', 'cc response')

      if (n_polarizabilities == 0) then

         ! Not specified means you get all components (xx, xy, xz, ...)
         ! of the polarizability

         this%compute_polarizability(:, :) = .true.

      else

         ! Figure out which polarizabilities-components have been requested
         ! to set true/false in the compute_polarizability array

         allocate(polarizabilities(n_polarizabilities))

         call input%get_array_for_keyword('polarizabilities', &
                                          'cc response', &
                                          n_polarizabilities, &
                                          polarizabilities)

         do k = 1, n_polarizabilities

            if (trim(polarizabilities(k)) == 'xx') then

               this%compute_polarizability(1, 1) = .true.

            elseif (trim(polarizabilities(k)) == 'xy' .or. trim(polarizabilities(k)) == 'yx') then

               this%compute_polarizability(1, 2) = .true.
               this%compute_polarizability(2, 1) = .true.

            elseif (trim(polarizabilities(k)) == 'xz' .or. trim(polarizabilities(k)) == 'zx') then

               this%compute_polarizability(1, 3) = .true.
               this%compute_polarizability(3, 1) = .true.

            elseif (trim(polarizabilities(k)) == 'yy') then

               this%compute_polarizability(2, 2) = .true.

            elseif (trim(polarizabilities(k)) == 'yz' .or. trim(polarizabilities(k)) == 'zy') then

               this%compute_polarizability(2, 3) = .true.
               this%compute_polarizability(3, 2) = .true.

            elseif (trim(polarizabilities(k)) == 'zz') then

               this%compute_polarizability(3, 3) = .true.

            end if

         end do

         deallocate(polarizabilities)

      end if

   end subroutine set_polarizability_components_to_compute


   subroutine set_t_response_components_to_compute(this)
      !!
      !! Written by Alexander C. Paul, and Anna Kristina Schnack-Petersen 2021-2022
      !!
      !! Determine which components of the response amplitudes and multipliers
      !! will be necessary to compute the requested polarizabilities
      !!
      implicit none

      class(cc_polarizability_task), intent(inout) :: this

      this%compute_t_response = .false.

      if (this%asymmetric) then

         call this%set_asymmetric_response_components_to_compute()

      else

         call this%set_symmetric_response_components_to_compute()

      end if

   end subroutine set_t_response_components_to_compute


   subroutine set_symmetric_response_components_to_compute(this)
      !!
      !! Written by Alexander C. Paul and Anna Kristina Schnack-Petersen, 2021-2022
      !!
      !! Determine which components of the response amplitudes will be
      !! necessary to compute the requested polarizabilities,
      !!
      implicit none

      class(cc_polarizability_task), intent(inout) :: this

      integer :: k, l

      do k = 1, 3
         do l = 1, k

            if (this%compute_polarizability(k, l)) then

               this%compute_t_response(k) = .true.
               this%compute_t_response(l) = .true.

            end if

         end do
      end do

   end subroutine set_symmetric_response_components_to_compute


   subroutine set_asymmetric_response_components_to_compute(this)
      !!
      !! Written by Anna Kristina Schnack-Petersen, Oct 2022
      !!
      !! Determine which components of the response amplitudes and multipliers
      !! will be necessary to compute the requested polarizabilities (read input)
      !!
      use global_in, only: input

      implicit none

      class(cc_polarizability_task), intent(inout) :: this

      integer :: k, n_components

      character(len=200), dimension(:), allocatable :: components

      n_components = input%get_n_elements_for_keyword('response components', 'cc response')

      allocate(components(n_components))

      call input%get_array_for_keyword('response components', &
                                       'cc response', &
                                       n_components, &
                                       components)

      do k = 1, n_components

         if (trim(components(k)) == 'x') this%compute_t_response(1) = .true.
         if (trim(components(k)) == 'y') this%compute_t_response(2) = .true.
         if (trim(components(k)) == 'z') this%compute_t_response(3) = .true.

      end do

      deallocate(components)

   end subroutine set_asymmetric_response_components_to_compute


   subroutine calculate_polarizability_cc_polarizability_task(this, wf)
      !!
      !! Written by Josefine H. Andersen, spring 2019
      !!
      !!    << X, Y >>(omega) = 1/2*[ eta^X (t^Y(omega) + t^Y(-omega))
      !!                            + eta^Y (t^X(omega) + t^X(-omega))
      !!                            + t^X(-omega) F t^Y(omega)
      !!                            + t^X(omega) F t^Y(-omega) ], (*)
      !!
      !! for the set of requested frequencies omega. Note that only components
      !! requested by the user are computed; see keyword "polarizabilities".
      !!
      !! This routine is called after the amplitude response
      !! vectors (t^X, t^Y)  needed for the polarizability components
      !! have been converged. These are solutions to the equations
      !!
      !!    (A - omega_k I) t^X(omega_k) = -xi^X
      !!
      !! Currently, X and Y are components of the dipole operator.
      !!
      !! The terms involving the F matrix (terms 3 and 4 in (*)) are only
      !! added in LR theory. These are thus ignored if EOM polarizabilities
      !! are requested.
      !!
      !! New storage of t response and adapted to late-2019
      !! program structure by Eirik F. Kjoenstad, Nov 2019.
      !!
      !! Revision of cross terms June 2021 by Anna Kristina Schnack-Petersen
      !!
      !! Addition of asymmetric polarizability October 2022 by Anna Kristina
      !! Schnack-Petersen
      !!
      !! The asymmetric expression allows us to avoid calculating the response
      !! for a component, and instead calculate both t and tbar response for
      !! the other component.
      !!
      !! Asymmetric EOM polarizabilities are defined as:
      !!
      !!    << X, Y >>(omega) = 1/2*[ eta^X (t^Y(omega) + t^Y(-omega))
      !!                            + xi^X (tbar^Y(omega) + tbar^Y(-omega))
      !!
      !! Asymmetric polarizabilities are not implemented for LR
      !!
      implicit none

      class(cc_polarizability_task) :: this

      class(ccs) :: wf

      real(dp), dimension(:, :), allocatable :: tk, tl  ! holds amplitude response, components k,l
      ! columns: [+, -] (positive/negative frequency)

      real(dp), dimension(:, :), allocatable :: Ftk  ! holds F tk
      ! columns: [+ -]

      integer :: k, l, freq, sign_

      real(dp) :: polarizability

      character(len=4), dimension(3) :: operator_ = ['mu_x', 'mu_y', 'mu_z']

      call output%printf('m', &
                         'The convention applied here defines the polarizabilities as the response functions,&
                         & without negative sign.', &
                         fs='(t6,a)')

      ! Allocate arrays to hold amplitude response vectors as well as
      ! F-transformed response vectors (if LR)

      call mem%alloc(tk, wf%n_es_amplitudes, 2)
      call mem%alloc(tl, wf%n_es_amplitudes, 2)
      call mem%alloc(Ftk, wf%n_es_amplitudes, 2)

      ! Compute polarizabilities

      do freq = 1, this%n_frequencies

         do k = 1, 3

            if (.not. any(this%compute_polarizability(k, :))) cycle

            if (this%compute_t_response(k)) then

               call this%read_response_vector(wf, tk, freq, k, this%t_response_files)

               do sign_ = 1, 2  ! +, -

                  call this%F_transformation%transform(tk(:, sign_), Ftk(:, sign_))

               end do

            end if

            do l = 1, k

               if (this%compute_polarizability(k, l)) then

                  polarizability = zero

                  if (.not. this%asymmetric) then

                     call this%compute_symmetric_polarizability_component(wf, &
                                                                          freq, &
                                                                          k, &
                                                                          l, &
                                                                          tk, &
                                                                          tl, &
                                                                          Ftk, &
                                                                          polarizability)

                  else

                     if (this%compute_t_response(k)) then

                        call this%compute_asymmetric_polarizability_component(wf, &
                                                                              freq, &
                                                                              k, &
                                                                              l, &
                                                                              tk, &
                                                                              tl, &
                                                                              polarizability)

                     else

                        call this%compute_asymmetric_polarizability_component(wf, &
                                                                              freq, &
                                                                              l, &
                                                                              k, &
                                                                              tk, &
                                                                              tl, &
                                                                              polarizability)

                     end if

                  end if


                  call output%printf('m', &
                                     '<< ' // operator_(k) // ', ' // operator_(l) // ' >>' // &
                                        '((e8.2)): (f19.12)', &
                                     reals=[this%frequencies(freq), polarizability], &
                                     fs='(t6,a)')

               end if

            end do

         end do

      end do

      call mem%dealloc(tk)
      call mem%dealloc(tl)
      call mem%dealloc(Ftk)

   end subroutine calculate_polarizability_cc_polarizability_task


   subroutine compute_symmetric_polarizability_component(this, wf, freq, k, l, tk, tl, Ftk, polarizability)

      !! Written by Josefine H. Andersen and
      !! Anna Kristina Schnack-Petersen, Dec. 2022

      implicit none

      class(cc_polarizability_task) :: this

      class(ccs) :: wf

      integer, intent(in) :: k, l, freq
      integer :: sign_

      real(dp), intent(inout) :: polarizability
      real(dp) :: ddot
      ! holds amplitude response, components k, l
      real(dp), dimension(wf%n_es_amplitudes, 2), intent(in) :: tk, tl
      ! columns: [+, -] (positive/negative frequency)
      real(dp), dimension(wf%n_es_amplitudes, 2), intent(in) :: Ftk

      call this%read_response_vector(wf, tl, freq, l, this%t_response_files)

      do sign_ = 1, 2  ! +, -

         polarizability = &
                          polarizability &
                          + half * ddot(wf%n_es_amplitudes, this%etaX(:, k), 1, tl(:, sign_), 1) &
                          + half * ddot(wf%n_es_amplitudes, this%etaX(:, l), 1, tk(:, sign_), 1)

      end do

      polarizability = polarizability + half * ddot(wf%n_es_amplitudes, Ftk(:, 1), 1, tl(:, 2), 1) &
                       + half * ddot(wf%n_es_amplitudes, Ftk(:, 2), 1, tl(:, 1), 1)

   end subroutine compute_symmetric_polarizability_component


   subroutine compute_asymmetric_polarizability_component(this, wf, freq, k, l, tk, tl, polarizability)

      !! Written by Anna Kristina Schnack-Petersen and
      !! Torsha Moitra, Dec. 2022

      implicit none

      class(cc_polarizability_task) :: this

      class(ccs) :: wf

      integer, intent(in) :: k, l, freq
      integer :: sign_

      real(dp), intent(inout) :: polarizability
      real(dp) :: ddot
      ! holds amplitude response, components k, l
      real(dp), dimension(wf%n_es_amplitudes, 2), intent(in) :: tk, tl
      ! columns: [+, -] (positive/negative frequency)

      character(len=4), dimension(3) :: operator_ = ['mu_x', 'mu_y', 'mu_z']

      call output%printf('m', &
                         'Asymmetric polarisability determined from response of operator ' // operator_(k), &
                         fs='(/t3,a)')

      call this%read_response_vector(wf, tl, freq, k, this%tbar_response_files)

      ! If t response for component k was not read already, we read it now

      if (k < l) then  !the component of larger index has been read

         call this%read_response_vector(wf, tk, freq, k, this%t_response_files)

      end if


      do sign_ = 1, 2  ! +, -

         polarizability = &
                          polarizability &
                          + half * ddot(wf%n_es_amplitudes, this%xiX(:, l), 1, tl(:, sign_), 1) &
                          + half * ddot(wf%n_es_amplitudes, this%etaX(:, l), 1, tk(:, sign_), 1)

      end do

   end subroutine compute_asymmetric_polarizability_component


   subroutine read_response_vector(this, wf, t, freq, k, response_file)

      !! Written by Eirik Kjoenstad and Anna Kristina Schnack-Petersen, 2022
      !!
      implicit none

      class(cc_polarizability_task) :: this

      class(ccs) :: wf

      type(stream_file), dimension(this%n_frequencies, 3, 2) :: response_file

      real(dp), dimension(wf%n_es_amplitudes, 2) :: t

      integer :: k, sign_, freq

      do sign_ = 1, 2

         call response_file(freq, k, sign_)%open_('rewind')
         call response_file(freq, k, sign_)%read_(t(:, sign_), wf%n_es_amplitudes)
         call response_file(freq, k, sign_)%close_()

      end do

   end subroutine read_response_vector


   subroutine destructor(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2022
      !!
      implicit none

      type(cc_polarizability_task) :: this

      if (allocated(this%frequencies)) call mem%dealloc(this%frequencies)

   end subroutine destructor


end module cc_polarizability_task_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_es_amplitudes_task_class

   !!
   !! CC excited state amplitudes task class
   !! Written by Alexander C. Paul, Sarai D. Folkestad, and Eirik F. Kjoenstad, 2022
   !!

   use ccs_class, only: ccs
   use abstract_solver_class, only: abstract_solver
   use cc_task_class, only: cc_task
   use cc_es_amplitudes_solver_factory_class, only: cc_es_amplitudes_solver_factory
   use state_descriptor_class, only: state_descriptor

   implicit none

   type, extends(cc_task) :: cc_es_amplitudes_task

      class(abstract_solver), allocatable, private :: solver

      character(len=:), allocatable, private :: left_or_right, spin_symmetry
      logical, private :: restart
      type(state_descriptor), pointer :: descriptor
      integer :: n_states

   contains

      procedure, public :: execute => execute_cc_es_amplitudes_task

      procedure, private :: create_solver

   end type cc_es_amplitudes_task


   interface cc_es_amplitudes_task

      procedure :: new_cc_es_amplitudes_task

   end interface cc_es_amplitudes_task


contains


   function new_cc_es_amplitudes_task(descriptor, restart, n_states) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!

      implicit none

      type(state_descriptor), intent(in), target :: descriptor
      logical, intent(in) :: restart
      integer, intent(in) :: n_states

      type(cc_es_amplitudes_task) :: this

      this%name_ = 'Determining CC excited state amplitudes'

      this%descriptor => descriptor
      this%restart = restart
      this%n_states = n_states


   end function new_cc_es_amplitudes_task


   subroutine execute_cc_es_amplitudes_task(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(cc_es_amplitudes_task), intent(inout) :: this

      class(ccs), intent(inout), target :: wf

      call this%print_header()
      call this%start_timer()

      call wf%add_es_states(this%descriptor, this%n_states)

      call this%create_solver(wf)

      call wf%construct_fock(task='es')

      call this%solver%run()

      call wf%print_es_summary(this%descriptor)

      call this%solver%cleanup()

      deallocate(this%solver)

      call this%end_timer()

   end subroutine execute_cc_es_amplitudes_task


   subroutine create_solver(this, wf)
      !!
      !! Written by Sarai D. Folkestad, 2022
      !!
      implicit none

      class(cc_es_amplitudes_task), intent(inout) :: this

      class(ccs), intent(inout), target :: wf
      type(cc_es_amplitudes_solver_factory), allocatable :: solver_factory

      solver_factory = cc_es_amplitudes_solver_factory(wf%name_, &
                                                       this%descriptor, &
                                                       this%n_states, &
                                                       this%restart)
      call solver_factory%create(wf, this%solver)

   end subroutine create_solver

end module cc_es_amplitudes_task_class

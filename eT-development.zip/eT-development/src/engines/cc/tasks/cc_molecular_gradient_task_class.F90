

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_molecular_gradient_task_class

   !!
   !! CC molecular gradients task class
   !! Written by Marcus T. Lexander, 2025
   !!

   use parameters
   use cc_task_class, only: cc_task
   use ccs_class, only: ccs
   use memory_manager_class, only: mem
   use global_out, only: output
   use output_file_class, only: output_file

   implicit none

   type, extends(cc_task) :: cc_molecular_gradient_task

      integer, private :: n_states
      integer, dimension(:), allocatable, private :: states

      type(output_file), private :: gradient_file

   contains

      procedure, public :: execute => execute_cc_molecular_gradient_task

      procedure, public :: cleanup => cleanup_cc_molecular_gradient_task

      procedure, private :: read_settings

      procedure, private :: print_gradient

   end type cc_molecular_gradient_task


   interface cc_molecular_gradient_task

      procedure :: new_cc_molecular_gradient_task

   end interface cc_molecular_gradient_task


contains


   function new_cc_molecular_gradient_task() result(this)
      !!
      !! Written by Marcus T. Lexander, 2025
      !!
      implicit none

      type(cc_molecular_gradient_task) :: this

      this%name_ = 'Computing excited state molecular gradients'

   end function new_cc_molecular_gradient_task


   subroutine execute_cc_molecular_gradient_task(this, wf)
      !!
      !! Written by Marcus T. Lexander, 2025
      !!
      use cc_multipliers_task_class, only: cc_multipliers_task

      implicit none

      class(cc_molecular_gradient_task), intent(inout) :: this

      class(ccs), intent(inout), target :: wf

      type(cc_multipliers_task), allocatable :: ground_state_multipliers

      real(dp), dimension(:, :), allocatable :: g

      integer :: i, state

      call this%print_header()
      call this%start_timer()

      this%gradient_file = output_file('eT.molecular_gradient.out')
      call this%gradient_file%open_('rewind')

      call this%read_settings()

      ! Excited state gradient initialization:
      call wf%initialize_density_intermediates(this%n_states)
      call wf%prepare_for_molecular_gradients()

      call mem%alloc(g, 3, wf%ao%n_centers)

      do i = 1, this%n_states
         state = this%states(i)

         call output%newline('m')
         call output%printf('m', '- Calculating molecular gradient for state: (i5)', ints=[state])

         if (state == 0) then

            ground_state_multipliers = cc_multipliers_task()
            call ground_state_multipliers%execute(wf)

            call wf%save_tbar_intermediates()

            call wf%prepare_for_properties()
            call wf%initialize_gs_density()
            call wf%construct_gs_density()

         end if

         call wf%calculate_molecular_gradient(g, state)

         call this%print_gradient(wf, g, state)

      end do

      call mem%dealloc(g)

      call wf%finalize_for_molecular_gradients()

      call this%gradient_file%close_()

      call this%end_timer()

   end subroutine execute_cc_molecular_gradient_task


   subroutine print_gradient(this, wf, g, state)
      !!
      !! Written by Marcus T. Lexander, 2025
      !!
      use atomic_center_class, only: atomic_center

      implicit none

      class(cc_molecular_gradient_task) :: this

      class(ccs), intent(in) :: wf

      real(dp), dimension(3, wf%ao%n_centers), intent(in) :: g

      integer, intent(in) :: state

      type(atomic_center) :: center

      integer :: i

      call this%gradient_file%newline('m')

      call this%gradient_file%printf('m', '- Molecular gradient (Hartree/bohr) for state (i5)', ints=[state])

      call this%gradient_file%printf('m', &
                                     '     Center                 x                y                z', &
                                     fs='(/t3,a)')

      call this%gradient_file%print_separator(pl='m', n=70, symbol='-')

      do i = 1, wf%ao%n_centers

         call wf%ao%get_center(i, center)

         call this%gradient_file%printf('m', &
                                        '  (i4) (b4)       3(f17.12)', &
                                        chars=[center%symbol], &
                                        ints=[i], &
                                        reals=[g(:, i)])

      end do

      call this%gradient_file%print_separator(pl='m', n=70, symbol='-')

   end subroutine print_gradient


   subroutine read_settings(this)
      !!
      !! Written by Marcus T. Lexander, 2025
      !!
      use global_in, only: input

      implicit none

      class(cc_molecular_gradient_task) :: this

      this%n_states = input%get_n_elements_for_keyword('initial states', &
                                                       'cc response')

      call mem%alloc(this%states, this%n_states)

      call input%get_array_for_keyword('initial states', &
                                       'cc response', &
                                       this%n_states, &
                                       this%states)

   end subroutine read_settings


   subroutine cleanup_cc_molecular_gradient_task(this)
      !!
      !! Written by Marcus T. Lexander, 2025
      !!
      implicit none

      class(cc_molecular_gradient_task), intent(inout) :: this

      call mem%dealloc(this%states)

   end subroutine cleanup_cc_molecular_gradient_task


end module cc_molecular_gradient_task_class

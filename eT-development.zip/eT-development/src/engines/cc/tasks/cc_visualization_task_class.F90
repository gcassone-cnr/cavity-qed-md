

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_visualization_task_class

   !!
   !! CC visualization task class
   !! Written by Eirik F. Kjoenstad, 2021
   !!

   use parameters
   use ccs_class, only: ccs
   use cc_task_class, only: cc_task
   use visualization_class, only: visualization
   use memory_manager_class, only: mem
   use cc_es_states_handler_class, only: cc_es_states_handler

   implicit none

   type, extends(cc_task) :: cc_visualization_task

      logical, private :: plot_densities, plot_ntos, plot_cntos
      logical, private :: plot_mos, plot_dyson

      real(dp), private :: nto_threshold

      integer :: n_states_to_plot_densities, n_states_to_plot_ntos
      integer, dimension(:), allocatable :: states_to_plot_densities, states_to_plot_ntos


      class(visualization), allocatable, private :: visualizer

   contains

      procedure, public :: execute => execute_cc_visualization_task

      procedure, private :: set_states_to_plot_densities
      procedure, private :: set_states_to_plot_ntos
      procedure, private :: construct_and_visualize_ntos
      procedure, private :: visualize_ntos
      procedure, private :: visualize_molecular_orbitals
      procedure, private :: visualize_densities
      procedure, private :: visualize_dyson_orbitals

      procedure, private :: cleanup

   end type cc_visualization_task


   interface cc_visualization_task

      procedure :: new_cc_visualization_task

   end interface cc_visualization_task


contains


   function new_cc_visualization_task() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      use global_in, only: input

      implicit none

      type(cc_visualization_task) :: this
      logical :: plot_gs_density, plot_mn_densities, plot_es_densities

      this%name_ = 'Plotting orbitals and/or CC densities'

      this%plot_mos = input%is_keyword_present('plot cc orbitals', 'visualization')

      plot_gs_density = input%is_keyword_present('plot cc density', 'visualization')

      plot_mn_densities = input%is_keyword_present('plot transition densities', 'visualization')

      plot_es_densities = input%is_keyword_present('plot es densities', 'visualization')

      this%plot_densities = any([plot_gs_density, plot_mn_densities, plot_es_densities])

      this%plot_dyson = input%is_keyword_present('plot dyson orbitals', 'visualization')
      this%plot_ntos = input%is_keyword_present('plot ntos', 'visualization')
      this%plot_cntos = input%is_keyword_present('plot cntos', 'visualization')

      this%nto_threshold = 0.1d0
      call input%get_keyword('nto threshold', 'visualization', this%nto_threshold)

   end function new_cc_visualization_task


   subroutine execute_cc_visualization_task(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      use global_in, only: input
      use global_out, only: output
      implicit none

      class(cc_visualization_task), intent(inout) :: this

      class(ccs), intent(inout), target :: wf

      logical :: plot_anything
      character(len=4) :: tag


      plot_anything = &
         any([this%plot_densities, this%plot_mos, this%plot_dyson, this%plot_ntos, this%plot_cntos])

      if (.not. plot_anything) return

      call this%print_header()

      if (input%is_section_present('active space')) then

         call output%warning_msg( &
                 'Only the active density is plotted - the frozen core and inactive densities are not&
                 & visualized.' &
              )

      end if

      call this%start_timer()

      call this%set_states_to_plot_densities()

      this%visualizer = visualization(wf%ao)
      call this%visualizer%initialize(wf%ao)

      if (this%plot_mos) call this%visualize_molecular_orbitals(wf)

      if (this%plot_densities) call this%visualize_densities(wf)

      if (this%plot_dyson) call this%visualize_dyson_orbitals(wf)


      if (this%plot_ntos) then

         if (this%plot_ntos) tag = 'nto'
         call this%set_states_to_plot_ntos(trim(tag), wf)
         call this%construct_and_visualize_ntos(wf, trim(tag), wf%R_es_states)
         call this%construct_and_visualize_ntos(wf, trim(tag), wf%L_es_states)


      end if

      if (this%plot_cntos) then

         if (this%plot_cntos) tag = 'cnto'
         call this%set_states_to_plot_ntos(trim(tag), wf)
         call this%construct_and_visualize_ntos(wf, trim(tag), wf%R_es_states)
         call this%construct_and_visualize_ntos(wf, trim(tag), wf%L_es_states)

      end if

      call this%visualizer%cleanup()

      call this%cleanup()

      call this%end_timer()

   end subroutine execute_cc_visualization_task


   subroutine visualize_molecular_orbitals(this, wf)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, 2019-2022
      !!
      use global_out, only: output
      use global_in, only: input

      implicit none

      class(cc_visualization_task), intent(inout) :: this
      class(ccs), intent(in) :: wf

      integer :: i, n_orbitals_to_plot, orbital_i

      integer, dimension(:), allocatable :: orbitals_to_plot

      real(dp), dimension(:, :), allocatable :: coefficients

      character(len=200), dimension(:), allocatable :: orbital_file_tags

      n_orbitals_to_plot = input%get_n_elements_for_keyword('plot cc orbitals', 'visualization')

      call mem%alloc(orbitals_to_plot, n_orbitals_to_plot)

      call input%get_array_for_keyword('plot cc orbitals', &
                                       'visualization', &
                                       n_orbitals_to_plot, &
                                       orbitals_to_plot)

      call mem%alloc(coefficients, wf%ao%n, n_orbitals_to_plot)
      allocate(orbital_file_tags(n_orbitals_to_plot))

      do i = 1, n_orbitals_to_plot

         orbital_i = orbitals_to_plot(i)

         if (orbital_i > wf%n_mo .or. orbital_i <= 0) then

            call output%error_msg( &
                    'Plotting of CC MOs failed. Index (i0) is invalid, expected number between 1 and (i0).', &
                    ints=[orbital_i, wf%n_mo] &
                 )

         end if

         call dcopy(wf%ao%n, &
                    wf%orbital_coefficients(1, orbital_i), &
                    1, &
                    coefficients(1, i), &
                    1)

         write(orbital_file_tags(i), '(a, i4.4)')'CC_MO_', orbital_i

      end do

      call mem%dealloc(orbitals_to_plot)

      call this%visualizer%plot_orbitals(wf%ao, &
                                         coefficients, &
                                         n_orbitals_to_plot, &
                                         orbital_file_tags)

      call mem%dealloc(coefficients)

      deallocate(orbital_file_tags)

   end subroutine visualize_molecular_orbitals


   subroutine construct_and_visualize_ntos(this, wf, tag, handler)
      !!
      !! Written by Sarai D. Folkestad, May 2020
      !!
      use global_out, only: output

      implicit none

      class(cc_visualization_task), intent(inout) :: this
      class(ccs), intent(in) :: wf
      character(len=*), intent(in) :: tag
      type(cc_es_states_handler), intent(inout) :: handler

      integer :: state, n_significant_v, n_significant_o, p

      real(dp), dimension(:, :), allocatable :: orbitals

      if (handler%n_total == 0) return

      if (this%nto_threshold > one .or. this%nto_threshold < zero) then

         call output%error_msg('illegal threshold given for NTO/CNTO plotting, (e8.4)', &
                               reals=[this%nto_threshold])

      end if

      call mem%alloc(orbitals, wf%ao%n, wf%n_mo)

      do p = 1, this%n_states_to_plot_ntos

         state = this%states_to_plot_ntos(p)

         call wf%construct_ntos_or_cntos(orbitals, &
                                         state, &
                                         n_significant_v, &
                                         n_significant_o, &
                                         handler, &
                                         tag, &
                                         this%nto_threshold)

         call this%visualize_ntos(wf, &
                                  n_significant_o, &
                                  n_significant_v, &
                                  orbitals, &
                                  tag, &
                                  state, &
                                  trim(handler%left_or_right))

      end do

      call mem%dealloc(orbitals)

   end subroutine construct_and_visualize_ntos


   subroutine visualize_ntos(this, wf, n_sig_o, n_sig_v, orbitals, tag, state, left_or_right)
      !!
      !! Written by Sarai D. Folkestad, May 2020
      !!
      implicit none

      class(cc_visualization_task), intent(inout) :: this
      class(ccs), intent(in) :: wf
      integer, intent(in) :: n_sig_o, n_sig_v, state
      real(dp), dimension(wf%ao%n, wf%n_mo), intent(in) :: orbitals
      character(len=*), intent(in) :: tag, left_or_right

      character(len=200), dimension(:), allocatable :: file_tags

      integer :: i
      character(len=2) :: l_or_r

      l_or_r = left_or_right(1:1) // '_'

      allocate(file_tags(max(n_sig_o, n_sig_v)))

      do i = 1, n_sig_o

         write(file_tags(i), '(a,i3.3,3a,i3.3)') l_or_r, state, '_', tag, '_o_', i

      end do

      call this%visualizer%plot_orbitals(wf%ao, &
                                         orbitals(:, 1:n_sig_o), &
                                         n_sig_o, &
                                         file_tags)

      do i = 1, n_sig_v

         write(file_tags(i), '(a,i3.3,3a,i3.3)') l_or_r, state, '_', tag, '_v_', i

      end do

      call this%visualizer%plot_orbitals(wf%ao, &
                                         orbitals(:, wf%n_o + 1:n_sig_v), &
                                         n_sig_v, &
                                         file_tags)

      deallocate(file_tags)

   end subroutine visualize_ntos


   subroutine visualize_densities(this, wf)
      !!
      !! Written by Alexander C. Paul, Dec 2020
      !!
      implicit none

      class(cc_visualization_task), intent(inout) :: this
      class(ccs), intent(inout) :: wf

      real(dp), dimension(:, :), allocatable :: c_D_ct, density

      integer :: state_p, state_q
      logical :: density_found
      character(len=200) :: tag

      call mem%alloc(density, wf%n_mo, wf%n_mo)
      call mem%alloc(c_D_ct, wf%ao%n, wf%ao%n)

      do state_p = 0, wf%L_es_states%n_total
         do state_q = 0, wf%L_es_states%n_total

            if (.not. any(state_p == this%states_to_plot_densities)) cycle
            if (.not. any(state_q == this%states_to_plot_densities)) cycle

            call wf%get_density_for_plotting(c_D_ct, density, state_p, state_q, density_found)

            if (density_found) then
               write(tag, '(a, i3.3, a, i3.3)')'dm_', state_p, '_', state_q
               call this%visualizer%plot_density(wf%ao, c_D_ct, tag)
            end if

         end do
      end do

      call mem%dealloc(density)
      call mem%dealloc(c_D_ct)

   end subroutine visualize_densities


   subroutine visualize_dyson_orbitals(this, wf)
      !!
      !! Written by Alexander C. Paul, Dec 2020
      !!
      implicit none

      class(cc_visualization_task), intent(inout) :: this
      class(ccs), intent(inout) :: wf

      real(dp), dimension(:, :), allocatable :: ao_dysons

      character(len=200), dimension(:), allocatable :: labels


      allocate(labels(wf%L_es_states%n_total))

      call mem%alloc(ao_dysons, wf%ao%n, wf%L_es_states%n_total)

      call wf%get_dyson_orbitals_for_plotting(ao_dysons, &
                                              labels, &
                                              wf%left_dyson_file, &
                                              'left', &
                                              wf%L_es_states%n_total)

      call this%visualizer%plot_orbitals(wf%ao, ao_dysons, wf%L_es_states%n_total, labels)

      call wf%get_dyson_orbitals_for_plotting(ao_dysons, &
                                              labels, &
                                              wf%right_dyson_file, &
                                              'right', &
                                              wf%R_es_states%n_total)

      call this%visualizer%plot_orbitals(wf%ao, ao_dysons, wf%L_es_states%n_total, labels)

      deallocate(labels)
      call mem%dealloc(ao_dysons)

   end subroutine visualize_dyson_orbitals


   subroutine set_states_to_plot_densities(this)
      !!
      !! Written Alexander C. Paul, Apr 2021
      !!
      !! Determine the states for which densities shall be plotted.
      !! If not present the densities for all initial states are requested
      !!
      use global_in, only: input

      implicit none

      class(cc_visualization_task), intent(inout) :: this

      if (input%is_keyword_present('states to plot', 'visualization')) then

         this%n_states_to_plot_densities = input%get_n_elements_for_keyword('states to plot', &
                                                                            'visualization')

         call mem%alloc(this%states_to_plot_densities, this%n_states_to_plot_densities)

         call input%get_array_for_keyword('states to plot', &
                                          'visualization', &
                                          this%n_states_to_plot_densities, &
                                          this%states_to_plot_densities)

      else if (input%is_keyword_present('initial states', 'cc response')) then

         this%n_states_to_plot_densities = input%get_n_elements_for_keyword('initial states', &
                                                                            'cc response')

         call mem%alloc(this%states_to_plot_densities, this%n_states_to_plot_densities)

         call input%get_array_for_keyword('initial states', &
                                          'cc response', &
                                          this%n_states_to_plot_densities, &
                                          this%states_to_plot_densities)

      else if (input%is_keyword_present('mean value', 'do')) then

         this%n_states_to_plot_densities = 1

         call mem%alloc(this%states_to_plot_densities, this%n_states_to_plot_densities)
         this%states_to_plot_densities(1) = 0

      end if

   end subroutine set_states_to_plot_densities


   subroutine set_states_to_plot_ntos(this, tag, wf)
      !!
      !! Written Alexander C. Paul, Apr 2021
      !!
      !! Sets number of states for which to plot ntos/cntos
      !! Default: plot ntos for all orbitals
      !!
      !! tag: either nto or cnto
      !!
      use global_in, only: input

      implicit none

      class(cc_visualization_task), intent(inout) :: this
      class(ccs), intent(inout) :: wf
      character(len=*), intent(in) :: tag
      integer :: default_n_states

      integer :: i
      character(len=:), allocatable :: keyword

      allocate(keyword, source = 'plot ' // trim(tag) // 's')

      this%n_states_to_plot_ntos = input%get_n_elements_for_keyword(keyword, 'visualization')

      default_n_states = max(wf%R_es_states%n_total, wf%L_es_states%n_total)

      if (default_n_states == 0) return

      if (this%n_states_to_plot_ntos == 0) then

         this%n_states_to_plot_ntos = default_n_states

         call mem%alloc(this%states_to_plot_ntos, this%n_states_to_plot_ntos)
         this%states_to_plot_ntos = [(i, i = 1, default_n_states)]
         return

      end if

      call mem%alloc(this%states_to_plot_ntos, this%n_states_to_plot_ntos)

      call input%get_array_for_keyword(keyword, &
                                       'visualization', &
                                       this%n_states_to_plot_ntos, &
                                       this%states_to_plot_ntos)

   end subroutine set_states_to_plot_ntos


   subroutine cleanup(this)
      !!
      !! Written Alexander C. Paul, Apr 2021
      !!
      implicit none

      class(cc_visualization_task), intent(inout) :: this

      if (allocated(this%states_to_plot_densities)) call mem%dealloc(this%states_to_plot_densities)

      if (allocated(this%states_to_plot_ntos)) call mem%dealloc(this%states_to_plot_ntos)

   end subroutine cleanup


end module cc_visualization_task_class

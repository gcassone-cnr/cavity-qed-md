

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_damped_polarizability_task_class

   !!
   !! CC damped polarizability task class
   !! Written by Alexander C. Paul, Sarai D. Folkestad, and Eirik F. Kjoenstad, 2022
   !!

   use parameters
   use global_out, only: output
   use memory_manager_class, only: mem
   use ccs_class, only: ccs
   use cc_polarizability_task_class, only: cc_polarizability_task
   use stream_file_class, only: stream_file

   implicit none

   type, extends(cc_polarizability_task) :: cc_damped_polarizability_task

      character(len=5), private :: transformation

   contains

      procedure, public :: calculate_polarizability => calculate_polarizability_damped_polarizability_task
      procedure, public :: initialize_response_files => initialize_response_files_damped_polarizability_task
      procedure, public :: determine_t_or_tbar_responses => &
                           determine_t_or_tbar_responses_dampled_polarizability_task

      procedure, private :: construct_propagator
      procedure, private :: solve_damped_response_equations
      procedure, private, nopass :: read_cpp_response_vector

      final :: destructor

   end type cc_damped_polarizability_task


   interface cc_damped_polarizability_task

      procedure :: new_cc_damped_polarizability_task

   end interface cc_damped_polarizability_task


contains


   function new_cc_damped_polarizability_task() result(this)
      !!
      !! Written by Anna Kristina Schnack-Petersen, Oct 2022
      !!
      use global_in, only: input

      implicit none

      type(cc_damped_polarizability_task) :: this

      this%asymmetric = input%is_keyword_present('asymmetric', 'cc response')

      if (this%asymmetric) then

         this%transformation = 'both'

      else

         this%transformation = 'right'

      end if

      this%name_ = 'Determining CC polarizabilities with damped response solver'

      this%eom = input%is_keyword_present('eom', 'cc response')

      if (.not. this%eom) &
         call output%error_msg('Polarizabilities computed with ' // &
            'damped response solver only available for EOM!')

   end function new_cc_damped_polarizability_task


   subroutine initialize_response_files_damped_polarizability_task(this, operator_type, response_files)
      !!
      !! Written by T. Moitra and A. K. Schnack-Petersen, 2022
      !!
      !! Note that only the dipole operator is available so far.

      implicit none

      class(cc_damped_polarizability_task) :: this

      integer :: component, frequency, sign_
      character(len=*), intent(in) :: operator_type
      character(len=200) :: file_name

      integer :: n_cartesian, n_signs

      type(stream_file), dimension(:, :, :), allocatable, intent(out) :: response_files

      n_cartesian = 3
      n_signs = 2
      allocate(response_files(this%n_frequencies, n_cartesian, n_signs))

      ! We have t or tbar responses for a given frequency, component (x,y,z) and sign_ (+,-)
      do sign_ = 1, 2
         do component = 1, 3
            do frequency = 1, this%n_frequencies

               write(file_name, '(3(a, i3.3))')'cpp_' // trim(operator_type), component, '_frequency_', &
                  frequency, '_sign_', sign_

               response_files(frequency, component, sign_) = stream_file(trim(file_name))

            end do
         end do
      end do

   end subroutine initialize_response_files_damped_polarizability_task


   subroutine solve_damped_response_equations(this, wf, rhs, solution_files, transformation, sign_)
      !!
      !! Written by A. K. Schnack-Petersen and T. Moitra, Dec 2022
      !!
      !! Solves damped response equations and stores result in solution_Re_files(k)
      !! and solution_Im_files(k).
      !!
      use global_in, only: input
      use file_linear_equation_storage_tool_class, only: file_linear_equation_storage_tool
      use vector_copy_getter_class, only: vector_copy_getter
      use cpp_print_tool_class, only: cpp_print_tool
      use cc_jacobian_transformation_class, only: cc_jacobian_transformation
      use cpp_davidson_solver_class, only: cpp_davidson_solver
      use cpp_start_vector_tool_class, only: cpp_start_vector_tool
      use cc_jacobian_preconditioner_getter_class, only: cc_jacobian_preconditioner_getter
      use convergence_tool_class, only: convergence_tool
      use null_projection_tool_class, only: null_projection_tool
      use cpp_restart_start_vector_tool_class, only: cpp_restart_start_vector_tool
      use vector_getter_class, only: vector_getter
      use abstract_projection_tool_class, only: abstract_projection_tool

      implicit none

      class(cc_damped_polarizability_task), intent(inout) :: this

      class(ccs), intent(in) :: wf

      real(dp), dimension(wf%n_es_amplitudes), intent(in) :: rhs

      character(len=*), intent(in) :: transformation

      integer, intent(in) :: sign_
      class(stream_file), dimension(this%n_frequencies), intent(inout) :: solution_files

      class(cpp_davidson_solver), allocatable :: solver
      class(cpp_print_tool), allocatable :: printer
      class(cc_jacobian_transformation), allocatable :: transformer
      class(file_linear_equation_storage_tool), allocatable :: storer
      class(vector_copy_getter), allocatable :: rhs_getter
      class(vector_getter), allocatable :: preconditioner_getter
      class(abstract_projection_tool), allocatable :: projector
      class(vector_getter), allocatable :: start_vector
      type(convergence_tool), allocatable :: convergence_checker

      integer :: max_iterations, max_reduced_dimension, preconditioner_sign
      logical :: records_in_memory, restart, residual_minimization
      real(dp) :: threshold, damping, ld_threshold, sign_factor

      max_iterations = 100
      threshold = 1.0d-6
      max_reduced_dimension = 200
      damping = zero
      residual_minimization = .false.

      call input%get_keyword('max iterations', 'solver cpp', max_iterations)
      call input%get_keyword('residual threshold', 'solver cpp', threshold)
      call input%place_records_in_memory('solver cpp', records_in_memory)
      call input%get_keyword('max reduced dimension', 'solver cpp', max_reduced_dimension)
      call input%get_keyword('damping', 'cc response', damping)

      restart = input%is_keyword_present('restart', 'solver cpp')
      residual_minimization = input%is_keyword_present('residual minimization', 'solver cpp')

      printer = cpp_print_tool(print_level='n')
      transformer = cc_jacobian_transformation(wf, transformation)
      preconditioner_getter = cc_jacobian_preconditioner_getter(wf, wf%n_es_amplitudes)
      projector = null_projection_tool(wf%n_es_amplitudes)
      convergence_checker = convergence_tool(threshold)

      storer = file_linear_equation_storage_tool( &  !Re and then Im solution
                  n_parameters=wf%n_es_amplitudes * 2, &
                  n_solutions=this%n_frequencies, &
                  files=solution_files &
               )

      rhs_getter = vector_copy_getter(n_parameters=wf%n_es_amplitudes, &
                                      n_vectors=1, &
                                      vectors=rhs)

      preconditioner_sign = 1

      if (restart) then
         start_vector = cpp_restart_start_vector_tool(this%n_frequencies, &
                                                      wf%n_es_amplitudes, &
                                                      solution_files)
      else

         start_vector = cpp_start_vector_tool(wf%n_es_amplitudes, &
                                              rhs, &
                                              preconditioner_getter, &
                                              this%n_frequencies, &
                                              preconditioner_sign, &
                                              this%frequencies, &
                                              damping)
      end if

      sign_factor = real((- 1)**sign_, kind=dp)

      ld_threshold = min(1.0d-16, threshold)

      solver = cpp_davidson_solver(transformer=transformer, &
                                   convergence_checker=convergence_checker, &
                                   storer=storer, &
                                   preconditioner_getter=preconditioner_getter, &
                                   rhs_getter=rhs_getter, &
                                   printer=printer, &
                                   projector=projector, &
                                   n_parameters=wf%n_es_amplitudes, &
                                   n_frequencies=this%n_frequencies, &
                                   max_iterations=max_iterations, &
                                   frequencies=sign_factor * this%frequencies, &
                                   damping=sign_factor * damping, &
                                   sign=preconditioner_sign, &
                                   linear_dependence_threshold=ld_threshold, &
                                   reduced_space_in_memory=records_in_memory, &
                                   max_reduced_dimension=max_reduced_dimension, &
                                   start_vector=start_vector, &
                                   residual_minimization=residual_minimization)

      call solver%run()
      call solver%cleanup()

   end subroutine solve_damped_response_equations


   subroutine determine_t_or_tbar_responses_dampled_polarizability_task(this, &
                                                                        wf, &
                                                                        unscaled_rhs, &
                                                                        response_type, &
                                                                        left_or_right, &
                                                                        response_file)
      !!
      !! Written by Anna Kristina Schnack-Petersen and Torsha Moitra, 2021-2022
      !!
      use array_initialization, only: copy_and_scale

      implicit none

      class(cc_damped_polarizability_task) :: this

      class(ccs) :: wf

      real(dp), dimension(wf%n_es_amplitudes, 3), intent(in) :: unscaled_rhs
      real(dp), dimension(:), allocatable :: rhs

      integer :: q, sign_

      character(len=1) :: sign_character
      character(len=*), intent(in) :: response_type
      character(len=*), intent(in) :: left_or_right

      type(stream_file), dimension(this%n_frequencies, 3, 2) :: response_file

      call wf%prepare_for_jacobian()

      call mem%alloc(rhs, wf%n_es_amplitudes)

      do q = 1, 3

         if (.not. this%compute_t_response(q)) cycle

         call copy_and_scale(- one, unscaled_rhs(:, q), rhs, wf%n_es_amplitudes)

         do sign_ = 1, 2

            sign_character = '-'
            if (sign_ == 2) sign_character = '+'

            call output%printf('v', 'Determining CPP ' // adjustl(response_type), fs='(/t3,a)')

            call output%printf('v', &
                               'Asking solver to get response for ' // &
                                  'component (i0) and ((a1))-frequencies.', &
                               ints=[q], &
                               chars=[sign_character], &
                               fs='(t3,a)')

            call this%solve_damped_response_equations(wf, &
                                                      rhs, &
                                                      response_file(:, q, sign_), &
                                                      left_or_right, &
                                                      sign_)

         end do
      end do

      call mem%dealloc(rhs)

   end subroutine determine_t_or_tbar_responses_dampled_polarizability_task


   subroutine calculate_polarizability_damped_polarizability_task(this, wf)
      !!
      !! Written by A. K. Schnack-Petersen and T. Moitra Spring 2020
      !!
      !! Determines the polarizability and linear absorption cross section
      !! from the polarization propagator calculated with the damped
      !! response solver (CPP) and print output.
      !!
      implicit none

      class(cc_damped_polarizability_task) :: this
      class(ccs) :: wf

      real(dp) :: alpha_Re, alpha_Im, cross_section

      integer :: i, j, frequency, rhs_index = 0, amplitude_index = 0

      character(len=1), dimension(3) :: cartesian_symbol = ['x', 'y', 'z']

      ! Construct the polarizability -<<X;Y>> (alpha)

      call output%print_separator('n', 79, '-', fs='(/t3,a)')

      call output%printf('m', &
                         'Frequency/a.u. Comp.  Re(alpha)/a.u.     Im(alpha)/a.u.      Cross section/a.u.', &
                         fs='(t3,a)')

      call output%print_separator('n', 79, '-', fs='(t3,a)')

      do frequency = 1, this%n_frequencies
         do i = 1, 3
            do j = 1, i

               if (.not. this%compute_polarizability(i, j)) cycle

               if (.not. this%asymmetric) then

                  call this%construct_propagator(wf, &
                                                 alpha_Re, &
                                                 alpha_Im, &
                                                 this%etaX(:, i), &
                                                 this%etaX(:, j), &
                                                 this%t_response_files(frequency, i, 1), &
                                                 this%t_response_files(frequency, i, 2), &
                                                 this%t_response_files(frequency, j, 1), &
                                                 this%t_response_files(frequency, j, 2))


               else

                  if (this%compute_t_response(i)) then
                     rhs_index = j
                     amplitude_index = i
                  else if (this%compute_t_response(j)) then
                     rhs_index = i
                     amplitude_index = j
                  else

                     call output%error_msg( &
                             "Trying to compute (i0)-(i0) polarizability, but amplitude response not&
                             & calculated.", &
                             ints=[i, j] &
                          )

                  end if


                  call this%construct_propagator(wf, &
                                                 alpha_Re, &
                                                 alpha_Im, &
                                                 this%etaX(:, rhs_index), &
                                                 this%xiX(:, rhs_index), &
                                                 this%tbar_response_files(frequency, amplitude_index, 1), &
                                                 this%tbar_response_files(frequency, amplitude_index, 2), &
                                                 this%t_response_files(frequency, amplitude_index, 1), &
                                                 this%t_response_files(frequency, amplitude_index, 2))

               end if


               cross_section = 4 * pi * this%frequencies(frequency) * alpha_Im / speed_of_light_au

               call output%printf('m', &
                                  '(f10.5)      (a1)(a1)    (e15.8)    (e15.8)     (e15.8)', &
                                  reals=[this%frequencies(frequency), alpha_Re, alpha_Im, cross_section], &
                                  chars=[cartesian_symbol(i), cartesian_symbol(j)], &
                                  fs='(t3,a)')

            end do
         end do

      end do

      call output%print_separator('n', 79, '-', fs='(t3,a)')


   end subroutine calculate_polarizability_damped_polarizability_task


   subroutine construct_propagator(this, &
                                   wf, &
                                   alpha_Re, &
                                   alpha_Im, &
                                   rhs_1, &
                                   rhs_2, &
                                   response_file_left_1, &
                                   response_file_left_2, &
                                   response_file_right_1, &
                                   response_file_right_2)
      !!
      !! Written by A. K. Schnack-Petersen and T. Moitra spring 2020
      !!
      !! Constructs the polarization propagator from damped response solutions (-<<X,Y>>)
      !! Note: only implemented for EOM
      !!
      !!  In EOM:
      !!     <<X;Y>> = C^{+/-omega}[eta^X*t_sol^Y(omega+igamma)+eta^Y*t_sol^X(-omega-igamma)]
      !!             = 1/2(eta^X*t_sol^Y(omega+igamma)+eta^Y*t_sol^X(-omega-igamma)
      !!                   + eta^X*[t_sol^Y(-omega+igamma)]^*+eta^Y*[t_sol^X(omega-igamma)]^*)
      !!
      !!  hence:
      !!       Im(<<x,y>>)=1/2[Re(eta^X)*Im(t_sol^Y(omega+igamma))+Re(eta^Y)*Im(t_sol^X(-omega-igamma))
      !!                   -Re(eta^X)*Im(t_sol^Y(-omega+igamma)-Re(eta^Y)*Im(t_sol^X(omega-igamma))]
      !!
      !!       Re(<<x,y>>)=1/2[Re(eta^X)*Re(t_sol^Y(omega+igamma))+Re(eta^Y)*Re(t_sol^X(-omega-igamma))
      !1                        +Re(eta^X)*Re(t_sol^Y(-omega+igamma)+Re(eta^Y)*Re(t_sol^X(omega-igamma))]
      !!
      !! alpha_Re, alpha_Im (output): the real and imaginary part of the polarization propagator
      !!
      !! operator1, operator2: integer indicating if the operators for X and Y are real, imaginary or complex
      !!                       - so far only real operators exist!
      !!
      !! rhs_1, rhs_2: the component of the rhs vector corresponding to X and Y.
      !!               ONLY the real part is passed so far as only real operators are available,
      !!               thus yielding imaginary parts that are zero!
      !!
      implicit none

      class(cc_damped_polarizability_task), intent(inout) :: this
      class(ccs), intent(inout) :: wf

      class(stream_file), intent(inout) :: response_file_left_1, response_file_left_2
      class(stream_file), intent(inout) :: response_file_right_1, response_file_right_2

      real(dp) :: ddot, alpha_Re, alpha_Im
      real(dp), dimension(wf%n_es_amplitudes), intent(in) :: rhs_1, rhs_2

      real(dp), dimension(:, :), allocatable :: p_t_solution1, p_t_solution2
      real(dp), dimension(:, :), allocatable :: m_t_solution1, m_t_solution2

      call mem%alloc(p_t_solution1, wf%n_es_amplitudes, 2)
      call mem%alloc(p_t_solution2, wf%n_es_amplitudes, 2)
      call mem%alloc(m_t_solution1, wf%n_es_amplitudes, 2)
      call mem%alloc(m_t_solution2, wf%n_es_amplitudes, 2)

      call this%read_cpp_response_vector(wf, response_file_left_1, m_t_solution1)
      call this%read_cpp_response_vector(wf, response_file_left_2, p_t_solution1)
      call this%read_cpp_response_vector(wf, response_file_right_1, m_t_solution2)
      call this%read_cpp_response_vector(wf, response_file_right_2, p_t_solution2)

      ! Construct alpha = -<<X;Y>>

      ! We assume real (dipole) operator, hence, real eta and xi.
      ! Sign on m_t_solution2 and p_t_solution1 has been accounted for either by symmetry or scaling

      alpha_Im = - half &
                 * (ddot(wf%n_es_amplitudes, rhs_1, 1, p_t_solution2(:, 2), 1) &
                 + ddot(wf%n_es_amplitudes, rhs_1, 1, m_t_solution2(:, 2), 1) &
                 + ddot(wf%n_es_amplitudes, rhs_2, 1, m_t_solution1(:, 2), 1) &
                 + ddot(wf%n_es_amplitudes, rhs_2, 1, p_t_solution1(:, 2), 1))

      alpha_Re = - half &
                 * (ddot(wf%n_es_amplitudes, rhs_1, 1, p_t_solution2(:, 1), 1) &
                 + ddot(wf%n_es_amplitudes, rhs_1, 1, m_t_solution2(:, 1), 1) &
                 + ddot(wf%n_es_amplitudes, rhs_2, 1, m_t_solution1(:, 1), 1) &
                 + ddot(wf%n_es_amplitudes, rhs_2, 1, p_t_solution1(:, 1), 1))

      call mem%dealloc(p_t_solution1)
      call mem%dealloc(p_t_solution2)
      call mem%dealloc(m_t_solution1)
      call mem%dealloc(m_t_solution2)

   end subroutine construct_propagator


   subroutine read_cpp_response_vector(wf, response_file, vector)
      !!
      !! Written by Anna Kristina Schnack-Petersen Apr 2021
      !!
      !! Reads the cpp response vectors for component x
      !!
      !! minus_t_response_x_Re, minus_t_response_x_Im : response vector
      !!                                                - 'minus' refers to gamma having a minus sign
      !!                                                We have t^x(-omega-i*gamma)
      !!
      !! plus_t_response_x_Re, plus_t_response_x_Im : response vector
      !!                                              - 'plus' refers to gamma having a plus sign
      !!                                              We have t^x(omega+i*gamma)
      !!
      !! x: the cartesian component to get the response vector for
      !!
      !! omega: frequency of the excitation
      !!
      implicit none

      class(ccs) :: wf

      type(stream_file), intent(inout) :: response_file
      real(dp), dimension(wf%n_es_amplitudes, 2), intent(out) :: vector

      call response_file%open_('rewind')
      call response_file%read_(vector, 2 * wf%n_es_amplitudes)
      call response_file%close_()

   end subroutine read_cpp_response_vector


   subroutine destructor(this)
      !!
      !! Written by by A. K. Schnack-Petersen, Oct 2022
      !!
      implicit none

      type(cc_damped_polarizability_task) :: this

      if (allocated(this%frequencies)) call mem%dealloc(this%frequencies)

   end subroutine destructor


end module cc_damped_polarizability_task_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_transition_moments_task_class

   !!
   !! CC transition moment task class
   !! Written by Alexander C. Paul, Jan 2022
   !!

   use parameters
   use cc_task_class, only: cc_task
   use ccs_class, only: ccs

   implicit none

   type, extends(cc_task), abstract :: cc_transition_moments_task

   contains

      procedure, nopass :: print_transition_moment_summary

   end type cc_transition_moments_task


contains


   subroutine print_transition_moment_summary(wf, &
                                              operator_label, &
                                              n_operators, &
                                              n_components, &
                                              transition_moment_matrix, &
                                              initial_states, &
                                              calculation_type)
      !!
      !! Written by Josefine H. Andersen, Sarai D. Folkestad,
      !! Jacob Pedersen and Sonia Coriani, 2019-2023
      !!
      use global_out, only: output
      use memory_manager_class, only: mem

      implicit none

      class(ccs), intent(inout) :: wf

      integer, dimension(:), intent(in) :: initial_states
      character(len=*), intent(in) :: calculation_type
      character(len=1), dimension(:), intent(in) :: operator_label
      integer, intent(in) :: n_operators, n_components
      real(dp), dimension(:, :, :, :), intent(in) :: transition_moment_matrix

      integer :: i, state_i, state_f
      real(dp) :: excitation_energy_i, excitation_energy_f, excitation_energy_difference

      real(dp), dimension(:), allocatable :: energies

      call output%printf('m', &
                         '- Summary of (a0) transition properties calculation:', &
                         fs='(/t3,a)', &
                         chars=[calculation_type])

      call mem%alloc(energies, wf%R_es_states%n_total)
      call wf%R_es_states%read_energies(energies)

      do i = 1, size(initial_states)

         state_i = initial_states(i)

         excitation_energy_i = zero
         if (state_i > 0) then
            excitation_energy_i = energies(state_i)
         end if

         do state_f = 1, wf%R_es_states%n_total

            if (state_i == state_f) cycle
            if (any(initial_states == state_f) .and. state_i > state_f) cycle

            excitation_energy_f = energies(state_f)

            excitation_energy_difference = excitation_energy_f - excitation_energy_i

            call print_transition_info(calculation_type, &
                                       state_i, &
                                       state_f, &
                                       excitation_energy_i, &
                                       excitation_energy_f)

            call print_transition_moment_table(n_operators, &
                                               n_components, &
                                               operator_label, &
                                               state_i, &
                                               state_f, &
                                               transition_moment_matrix)

            call calculate_and_print_oscillator_and_rotatory_strengths(n_operators, &
                                                                       n_components, &
                                                                       state_i, &
                                                                       state_f, &
                                                                       operator_label, &
                                                                       excitation_energy_difference, &
                                                                       transition_moment_matrix)

         end do

      end do

      call mem%dealloc(energies)

   end subroutine print_transition_moment_summary


   subroutine print_transition_info(calculation_type, &
                                    state_i, &
                                    state_f, &
                                    excitation_energy_i, &
                                    excitation_energy_f)
      !!
      !! Written by Josefine H. Andersen, Sarai D. Folkestad,
      !! Jacob Pedersen and Sonia Coriani, 2019-2023

      use global_out, only: output

      implicit none

      integer, intent(in) :: state_i, state_f
      real(dp), intent(in) :: excitation_energy_i, excitation_energy_f
      character(len=*), intent(in) :: calculation_type

      call output%printf('m', &
                         'States n = (i0) and m = (i0):', &
                         fs='(/t6,a)', &
                         ints=[state_i, state_f])

      call output%print_separator('m', 25, '-', fs='(t6,a)')

      call output%printf('m', &
                         'Calculation type:               (a19)', &
                         chars=[calculation_type], &
                         fs='(t6,a)')

      call output%printf('m', &
                         'Excitation energy (n->m) [E_h]: (f19.12)', &
                         reals=[excitation_energy_f - excitation_energy_i], &
                         fs='(t6,a)')

      call output%printf('m', &
                         'Excitation energy (n->m) [eV]:  (f19.12)', &
                         reals=[(excitation_energy_f - excitation_energy_i) * Hartree_to_eV], &
                         fs='(t6,a)')

      call output%printf('m', &
                         'Hartree-to-eV (CODATA 2014):   (f19.8)', &
                         reals=[Hartree_to_eV], &
                         fs='(t6,a)')

   end subroutine print_transition_info


   subroutine print_transition_moment_table(n_operators, &
                                            n_components, &
                                            operator_label, &
                                            state_i, &
                                            state_f, &
                                            transition_moment_matrix)
      !!
      !! Written by Josefine H. Andersen, Sarai D. Folkestad,
      !! Jacob Pedersen, Sonia Coriani and Leo Stoll, 2019-2023
      !!
      use global_out, only: output

      implicit none

      integer, intent(in) :: n_operators, n_components, state_i, state_f
      character(len=1), dimension(:), intent(in) :: operator_label
      real(dp), dimension(:, :, :, :), intent(in) :: transition_moment_matrix

      integer :: operator_, component
      character(len=100) :: string
      character(len=1), dimension(3) :: components
      real(dp) :: transition_moment_fi, transition_moment_if, transition_strength

      if (n_components == 3) components = ['X', 'Y', 'Z']

      call output%printf('m', &
                         'Transition moments [a.u.]        Transition strength [a.u.]', &
                         ll=74, &
                         fs='(/t6,14X,a)')

      call output%print_separator('m', 74, '-', fs='(t6,a)')

      do operator_ = 1, n_operators

         string = 'Comp.      < m | ' // operator_label(operator_) // &
            ' | n >     < n | ' // operator_label(operator_) // ' | m >    < m | ' // &
            operator_label(operator_) // ' | n > < n | ' // operator_label(operator_) // ' | m >'

         call output%printf('m', string, ll=79, fs='(t6,a)')
         call output%print_separator('m', 74, '-', fs='(t6,a)')

         do component = 1, n_components

            transition_moment_fi = transition_moment_matrix(state_f + 1, state_i + 1, component, operator_)
            transition_moment_if = transition_moment_matrix(state_i + 1, state_f + 1, component, operator_)
            transition_strength = transition_moment_fi * transition_moment_if

            call output%printf('m', &
                               '(a0)      (f17.10) (f17.10)       (f17.10)', &
                               reals=[transition_moment_fi, transition_moment_if, transition_strength], &
                               chars=[components(component)], &
                               fs='(t6,a)')

         end do

         call output%print_separator('m', 74, '-', fs='(t6,a)')

      end do

   end subroutine print_transition_moment_table


   subroutine calculate_and_print_oscillator_and_rotatory_strengths(n_operators, &
                                                                    n_components, &
                                                                    state_i, &
                                                                    state_f, &
                                                                    operator_label, &
                                                                    excitation_energy_difference, &
                                                                    transition_moment_matrix)
      !!
      !! Written by Jacob Pedersen and Sonia Coriani, 2023
      !!
      implicit none

      integer, intent(in) :: n_operators, n_components, state_i, state_f
      real(dp), dimension(:, :, :, :), intent(in) :: transition_moment_matrix
      character(len=1), dimension(:), intent(in) :: operator_label
      real(dp), intent(in) :: excitation_energy_difference
      real(dp), dimension(:, :, :), pointer :: dipole_transition_moment, linear_momentum_transition_moment, &
                                               angular_momentum_transition_moment

      call read_and_extract_operator_transition_moments(n_operators, &
                                                        transition_moment_matrix, &
                                                        dipole_transition_moment, &
                                                        linear_momentum_transition_moment, &
                                                        angular_momentum_transition_moment)

      call calculate_and_print_oscillator_strength_length(n_components, &
                                                          state_i, &
                                                          state_f, &
                                                          excitation_energy_difference, &
                                                          dipole_transition_moment)

      if (any(operator_label == 'p')) then

         call calculate_and_print_oscillator_strength_velocity(n_components, &
                                                               state_i, &
                                                               state_f, &
                                                               excitation_energy_difference, &
                                                               linear_momentum_transition_moment)

         call calculate_and_print_oscillator_strength_mixed(n_components, &
                                                            state_i, &
                                                            state_f, &
                                                            dipole_transition_moment, &
                                                            linear_momentum_transition_moment)

      end if

      if (any(operator_label == 'L')) then

         call calculate_and_print_rotatory_strength_length(n_components, &
                                                           state_i, &
                                                           state_f, &
                                                           dipole_transition_moment, &
                                                           angular_momentum_transition_moment)

         call calculate_and_print_rotatory_strength_velocity(n_components, &
                                                             state_i, &
                                                             state_f, &
                                                             excitation_energy_difference, &
                                                             linear_momentum_transition_moment, &
                                                             angular_momentum_transition_moment)

      end if

   end subroutine calculate_and_print_oscillator_and_rotatory_strengths


   subroutine calculate_and_print_oscillator_strength_length(n_components, &
                                                             state_i, &
                                                             state_f, &
                                                             excitation_energy_difference, &
                                                             transition_moment_matrix_dipole)
      !!
      !! Written by Josefine H. Andersen, Sarai D. Folkestad,
      !! Jacob Pedersen and Sonia Coriani, 2019-2023
      !!
      !! Oscillator strength in length gauge:
      !! f_lenght = (2/3) * \omega_{if} \sum_{\alpha} < i | \mu_{\alpha} | f > < f | \mu_{\alpha} | i >
      !!
      use global_out, only: output

      implicit none

      integer, intent(in) :: n_components, state_i, state_f
      real(dp), dimension(:, :, :), intent(in) :: transition_moment_matrix_dipole
      real(dp), intent(in) :: excitation_energy_difference
      real(dp) :: strength, oscillator_strength_length

      call calculate_symmetrized_transition_strength(n_components, &
                                                     state_i, &
                                                     state_f, &
                                                     transition_moment_matrix_dipole, &
                                                     transition_moment_matrix_dipole, &
                                                     strength, &
                                                     sign=one)

      oscillator_strength_length = (two / three) * excitation_energy_difference * strength

      call output%printf('m', &
                         'Oscillator strength (length gauge):(f19.12)', &
                         fs='(t6,a)', &
                         reals=[oscillator_strength_length])

   end subroutine calculate_and_print_oscillator_strength_length


   subroutine calculate_and_print_oscillator_strength_velocity(n_components, &
                                                               state_i, &
                                                               state_f, &
                                                               excitation_energy_difference, &
                                                               transition_moment_matrix_linear_momentum)
      !!
      !! Written by Jacob Pedersen and Sonia Coriani, Jan 2023
      !!
      !! Oscillator strength in velocity gauge:
      !! f_velocity = [2/(3 \omega_{if})] \sum_{\alpha} < i | p_{\alpha} | f > < f | p_{\alpha} | i >
      !!
      use global_out, only: output

      implicit none

      integer, intent(in) :: n_components, state_i, state_f
      real(dp), dimension(:, :, :), intent(in) :: transition_moment_matrix_linear_momentum
      real(dp), intent(in) :: excitation_energy_difference

      real(dp) :: strength, oscillator_strength_velocity

      call calculate_symmetrized_transition_strength(n_components, &
                                                     state_i, &
                                                     state_f, &
                                                     transition_moment_matrix_linear_momentum, &
                                                     transition_moment_matrix_linear_momentum, &
                                                     strength, &
                                                     sign=one)

      if (abs(excitation_energy_difference) > 1.d-8) then

         oscillator_strength_velocity = - (two / three) * (one / excitation_energy_difference) * strength

         call output%printf('m', &
                            'Oscillator strength (velocity gauge):(f17.12)', &
                            fs='(t6,a)', &
                            reals=[oscillator_strength_velocity])

      else

         call output%printf('m', &
                            'Warning: energy difference too small; velocity gauge calculation skipped', &
                            fs='(t6,a)')

      end if

   end subroutine calculate_and_print_oscillator_strength_velocity


   subroutine calculate_and_print_oscillator_strength_mixed(n_components, &
                                                            state_i, &
                                                            state_f, &
                                                            transition_moment_matrix_dipole, &
                                                            transition_moment_matrix_linear_momentum)
      !!
      !! Written by Jacob Pedersen and Sonia Coriani, Jan 2023
      !!
      !! Oscillator strength in mixed gauge:
      !! f_mixed = (2i/3) sum_{\alpha} < i | \mu_{\alpha} | f > < f | p_{\alpha} | i >
      !!
      use global_out, only: output

      implicit none

      integer, intent(in) :: n_components, state_i, state_f
      real(dp), dimension(:, :, :), intent(in) :: transition_moment_matrix_dipole, &
                                                  transition_moment_matrix_linear_momentum

      real(dp) :: strength, oscillator_strength_mixed

      call calculate_symmetrized_transition_strength(n_components, &
                                                     state_i, &
                                                     state_f, &
                                                     transition_moment_matrix_dipole, &
                                                     transition_moment_matrix_linear_momentum, &
                                                     strength, &
                                                     sign=- one)

      oscillator_strength_mixed = - (two / three) * strength

      call output%printf('m', &
                         'Oscillator strength (mixed gauge): (f19.12)', &
                         fs='(t6,a)', &
                         reals=[oscillator_strength_mixed])

   end subroutine calculate_and_print_oscillator_strength_mixed


   subroutine calculate_and_print_rotatory_strength_length(n_components, &
                                                           state_i, &
                                                           state_f, &
                                                           transition_moment_matrix_dipole, &
                                                           transition_moment_matrix_angular_momentum)
      !!
      !! Written by Jacob Pedersen and Sonia Coriani, Jan 2023
      !!
      !! Rotatory strength in length gauge:
      !! R_length = -(1/2) sum_{\alpha} Im[ < i | \mu_{\alpha} | f > < f | L_{\alpha} | i > ]
      !!
      use global_out, only: output
      use parameters, only: au_to_cgs_R

      implicit none

      integer, intent(in) :: n_components, state_i, state_f
      real(dp), dimension(:, :, :), intent(in) :: transition_moment_matrix_dipole, &
                                                  transition_moment_matrix_angular_momentum

      real(dp) :: strength, rotatory_strength_length

      call calculate_symmetrized_transition_strength(n_components, &
                                                     state_i, &
                                                     state_f, &
                                                     transition_moment_matrix_dipole, &
                                                     transition_moment_matrix_angular_momentum, &
                                                     strength, &
                                                     sign=- one)

      rotatory_strength_length = - (one / two) * strength

      call output%printf('m', &
                         'Rotatory strength (length gauge):  (f19.12) a.u.', &
                         fs='(t6,a)', &
                         reals=[rotatory_strength_length])

      call output%printf('m', &
                         'Rotatory strength (length gauge):  (f19.12)E-40 cm^-5 g s^-2', &
                         ll=79, &
                         fs='(t6,a)', &
                         reals=[rotatory_strength_length * au_to_cgs_R])

   end subroutine calculate_and_print_rotatory_strength_length


   subroutine calculate_and_print_rotatory_strength_velocity(n_components, &
                                                             state_i, &
                                                             state_f, &
                                                             excitation_energy_difference, &
                                                             transition_moment_matrix_linear_momentum, &
                                                             transition_moment_matrix_angular_momentum)
      !!
      !! Written by Jacob Pedersen and Sonia Coriani, Jan 2023
      !!
      !! Rotatory strength in velocity gauge:
      !! R_velocity = -[1/(2 \omega_{if})]] sum_{\alpha} Re[ < i | p_{\alpha} | f > < f | L_{\alpha} | i > ]
      !!
      use global_out, only: output
      use parameters, only: au_to_cgs_R

      implicit none

      integer, intent(in) :: n_components, state_i, state_f
      real(dp), intent(in) :: excitation_energy_difference
      real(dp), dimension(:, :, :), intent(in) :: transition_moment_matrix_linear_momentum, &
                                                  transition_moment_matrix_angular_momentum

      real(dp) :: strength, rotatory_strength_velocity

      call calculate_symmetrized_transition_strength(n_components, &
                                                     state_i, &
                                                     state_f, &
                                                     transition_moment_matrix_linear_momentum, &
                                                     transition_moment_matrix_angular_momentum, &
                                                     strength, &
                                                     sign=one)

      if (abs(excitation_energy_difference) > 1.d-8) then

         rotatory_strength_velocity = - (one / two) * (one / excitation_energy_difference) * strength

         call output%printf('m', &
                            'Rotatory strength (velocity gauge):(f19.12) a.u.', &
                            fs='(t6,a)', &
                            reals=[rotatory_strength_velocity])

         call output%printf('m', &
                            'Rotatory strength (velocity gauge):(f19.12)E-40 cm^-5 g s^-2', &
                            ll=79, &
                            fs='(t6,a)', &
                            reals=[rotatory_strength_velocity * au_to_cgs_R])

      else

         call output%printf('m', &
                            'Warning: energy difference too small; velocity gauge calculation skipped', &
                            fs='(t6,a)')

      end if

      call output%printf('m', 'Conversion factor for rotatory strengths (CODATA 2018):', fs='(/t6,a)')
      call output%printf('m', '1 a.u. = (f16.12)E-40 cm^-5 g s^-2', reals=[au_to_cgs_R], ll=79, fs='(t6,a)')

   end subroutine calculate_and_print_rotatory_strength_velocity


   subroutine read_and_extract_operator_transition_moments(n_operators, &
                                                           transition_moment_matrix, &
                                                           dipole_transition_moment, &
                                                           linear_momentum_transition_moment, &
                                                           angular_momentum_transition_moment)
      !!
      !! Written by Jacob Pedersen and Sonia Coriani, Feb 2023
      !!
      implicit none

      integer, intent(in) :: n_operators
      real(dp), dimension(:, :, :, :), intent(in), target :: transition_moment_matrix
      real(dp), dimension(:, :, :), pointer, intent(out) :: dipole_transition_moment, &
                                                            linear_momentum_transition_moment, &
                                                            angular_momentum_transition_moment

      dipole_transition_moment => transition_moment_matrix(:, :, :, 1)

      if (n_operators > 1) linear_momentum_transition_moment => transition_moment_matrix(:, :, :, 2)

      if (n_operators > 2) angular_momentum_transition_moment => transition_moment_matrix(:, :, :, 3)

   end subroutine read_and_extract_operator_transition_moments


   subroutine calculate_symmetrized_transition_strength(n_components, &
                                                        state_i, &
                                                        state_f, &
                                                        A, &
                                                        B, &
                                                        strength, &
                                                        sign)
      !!
      !! Written by Jacob Pedersen and Sonia Coriani, Feb 2023
      !!
      !! strength^{if}_{AB} = (1/2) \sum { <i|A|f><f|B|i> + sign(<i|B|f><f|A|i>) }
      !!
      implicit none

      integer :: component
      integer, intent(in) :: n_components, state_i, state_f
      real(dp), dimension(:, :, :), intent(in) :: A, B
      real(dp), intent(in) :: sign
      real(dp) :: transition_strength, A_fi, A_if, B_fi, B_if
      real(dp), intent(out) :: strength

      strength = zero

      do component = 1, n_components

         A_fi = A(state_f + 1, state_i + 1, component)
         A_if = A(state_i + 1, state_f + 1, component)
         B_fi = B(state_f + 1, state_i + 1, component)
         B_if = B(state_i + 1, state_f + 1, component)

         transition_strength = A_fi * B_if + sign * B_fi * A_if

         strength = strength + transition_strength

      end do

      strength = half * strength

   end subroutine calculate_symmetrized_transition_strength


end module cc_transition_moments_task_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_mean_values_task_class

   !!
   !! CC mean value task class
   !! Written by Eirik F. Kjoenstad, 2021
   !!

   use ccs_class, only: ccs
   use cc_task_class, only: cc_task
   use global_in, only: input

   implicit none

   type, extends(cc_task) :: cc_mean_values_task

      logical, private :: dipole
      logical, private :: quadrupole
      logical, private :: molecular_gradient
      logical, private :: plot_gs_density
      logical, private :: occupation_numbers

   contains

      procedure, public :: execute => execute_cc_mean_values_task

   end type cc_mean_values_task


   interface cc_mean_values_task

      procedure :: new_cc_mean_values_task

   end interface cc_mean_values_task


contains


   function new_cc_mean_values_task() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      type(cc_mean_values_task) :: this

      this%name_ = 'Determining CC mean values'

      this%dipole = input%is_keyword_present('dipole', 'cc mean value')
      this%quadrupole = input%is_keyword_present('quadrupole', 'cc mean value')
      this%molecular_gradient = input%is_keyword_present('molecular gradient', 'cc mean value')
      this%plot_gs_density = input%is_keyword_present('plot cc density', 'visualization')
      this%occupation_numbers = input%is_keyword_present('occupation numbers', 'cc mean value')

   end function new_cc_mean_values_task


   subroutine execute_cc_mean_values_task(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(cc_mean_values_task), intent(inout) :: this

      class(ccs), intent(inout), target :: wf

      call this%print_header()
      call this%start_timer()

      call wf%initialize_gs_density()
      call wf%prepare_for_properties()
      call wf%construct_gs_density()

      if (this%plot_gs_density) then
         call wf%initialize_density_storer(n_es_states=0)
         call wf%density_storage%copy_density_in(wf%density, left_state=0, right_state=0)
      end if

      if (this%dipole) call wf%calculate_and_print_dipole(wf%density)
      if (this%quadrupole) call wf%calculate_and_print_quadrupole(wf%density)
      if (this%molecular_gradient) call wf%calculate_and_print_molecular_gradient()
      if (this%occupation_numbers) call wf%calculate_and_print_occupation_numbers(wf%density)

      call this%end_timer()

   end subroutine execute_cc_mean_values_task


end module cc_mean_values_task_class

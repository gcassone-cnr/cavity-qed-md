

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_molecular_gradient_engine_class

   !!
   !! EOM molecular gradient engine class
   !! Written by Marcus T. Lexander, 2025
   !!

   use ccs_class, only: ccs
   use cc_engine_class, only: cc_engine
   use cc_amplitudes_task_class, only: cc_amplitudes_task
   use cc_es_amplitudes_task_class, only: cc_es_amplitudes_task
   use biorthonormalization_task_class, only: biorthonormalization_task
   use cc_molecular_gradient_task_class, only: cc_molecular_gradient_task
   use eri_approximator_task_class, only: eri_approximator_task
   use cc_wavefunctions_class, only: cc_wavefunctions

   implicit none

   type, extends(cc_engine) :: cc_molecular_gradient_engine

   contains

      procedure, public :: ignite => ignite_cc_molecular_gradient_engine
      procedure, public :: set_allowed_wfs => set_allowed_wfs_cc_molecular_gradient_engine

   end type cc_molecular_gradient_engine


contains


   subroutine ignite_cc_molecular_gradient_engine(this, wf)
      !!
      !! Written by Marcus T. Lexander, 2025
      !!
      use global_in, only: input
      use state_descriptor_class, only: state_descriptor, es_type
      use memory_manager_class, only: mem

      implicit none

      class(cc_molecular_gradient_engine), intent(inout) :: this
      type(eri_approximator_task) :: eri_approximator
      type(cc_amplitudes_task), allocatable :: ground_state_amplitudes
      type(cc_es_amplitudes_task), allocatable :: excited_state_amplitudes
      type(biorthonormalization_task), allocatable :: biorthonormalization
      type(cc_molecular_gradient_task), allocatable :: molecular_gradient


      class(ccs), intent(inout) :: wf

      logical :: restart

      type(state_descriptor), allocatable :: descriptor
      type(es_type), dimension(:), allocatable :: types

      integer :: i, n

      integer, dimension(:), allocatable :: n_states

      call this%set_allowed_wfs()
      call this%check_wavefunctions(wf)

      restart = input%is_keyword_present('restart', 'solver cc es') .or. &
                input%is_keyword_present('restart', 'do')

      call eri_approximator%execute(wf)

      ground_state_amplitudes = cc_amplitudes_task()
      call ground_state_amplitudes%execute(wf)

      n = input%get_n_es_types()

      allocate(types(n))
      call mem%alloc(n_states, n)

      call input%get_es_types(n, types)

      call input%get_n_es_states(n, n_states, 'singlet')

      do i = 1, n

         descriptor = state_descriptor('right', types(i), 'singlet')

         excited_state_amplitudes = cc_es_amplitudes_task(descriptor, restart, n_states(i))
         call excited_state_amplitudes%execute(wf)

         deallocate(excited_state_amplitudes)
         deallocate(descriptor)

         descriptor = state_descriptor('left', types(i), 'singlet')

         excited_state_amplitudes = cc_es_amplitudes_task(descriptor, .true., n_states(i))
         call excited_state_amplitudes%execute(wf)

         deallocate(excited_state_amplitudes)
         deallocate(descriptor)

      end do

      call mem%dealloc(n_states)

      biorthonormalization = biorthonormalization_task()
      call biorthonormalization%execute(wf)

      molecular_gradient = cc_molecular_gradient_task()
      call molecular_gradient%execute(wf)
      call molecular_gradient%cleanup()

   end subroutine ignite_cc_molecular_gradient_engine


   subroutine set_allowed_wfs_cc_molecular_gradient_engine(this)
      !!
      !! Written by Marcus T. Lexander, 2025
      !!
      implicit none

      class(cc_molecular_gradient_engine), intent(inout) :: this

      this%allowed_cc_wfs = cc_wavefunctions()

      call this%allowed_cc_wfs%set('ccsd', allowed=.true.)

   end subroutine set_allowed_wfs_cc_molecular_gradient_engine


end module cc_molecular_gradient_engine_class

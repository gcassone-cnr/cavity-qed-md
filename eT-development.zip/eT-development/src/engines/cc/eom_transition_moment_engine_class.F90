

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module eom_transition_moment_engine_class

   !!
   !! EOM transition moment engine class
   !! Written by Alexander C. Paul, Dec 2021
   !!

   use ccs_class, only: ccs
   use cc_engine_class, only: cc_engine
   use cc_amplitudes_task_class, only: cc_amplitudes_task
   use cc_multipliers_task_class, only: cc_multipliers_task
   use cc_es_amplitudes_task_class, only: cc_es_amplitudes_task
   use biorthonormalization_task_class, only: biorthonormalization_task
   use cc_eom_transition_moments_task_class, only: cc_eom_transition_moments_task
   use cc_visualization_task_class, only: cc_visualization_task
   use eri_approximator_task_class, only: eri_approximator_task
   use cc_wavefunctions_class, only: cc_wavefunctions
   use state_descriptor_class, only: state_descriptor, es_type

   implicit none

   type, extends(cc_engine) :: eom_transition_moment_engine

   contains

      procedure, public :: ignite => ignite_eom_transition_moment_engine
      procedure, public :: set_allowed_wfs => set_allowed_wfs_eom_transition_moment_engine

   end type eom_transition_moment_engine


contains


   subroutine ignite_eom_transition_moment_engine(this, wf)
      !!
      !! Written by Alexander C. Paul, Jan 2022
      !!
      use global_in, only: input
      use memory_manager_class, only: mem

      implicit none

      class(eom_transition_moment_engine), intent(inout) :: this

      class(ccs), intent(inout) :: wf

      logical :: restart

      type(state_descriptor), allocatable :: descriptor
      type(es_type), dimension(:), allocatable :: types

      integer :: i, n

      integer, dimension(:), allocatable :: n_states

      type(eri_approximator_task) :: eri_approximator
      type(cc_amplitudes_task), allocatable :: ground_state_amplitudes
      type(cc_multipliers_task), allocatable :: ground_state_multipliers
      type(cc_es_amplitudes_task), allocatable :: excited_state_amplitudes
      type(biorthonormalization_task), allocatable :: biorthonormalization
      type(cc_eom_transition_moments_task), allocatable :: eom_transition_moments
      type(cc_visualization_task), allocatable :: visualization

      call this%set_allowed_wfs()
      call this%check_wavefunctions(wf)

      restart = input%is_keyword_present('restart', 'solver cc es') .or. &
                input%is_keyword_present('restart', 'do')

      call eri_approximator%execute(wf)

      ground_state_amplitudes = cc_amplitudes_task()
      call ground_state_amplitudes%execute(wf)

      ground_state_multipliers = cc_multipliers_task()
      call ground_state_multipliers%execute(wf)

      call wf%save_tbar_intermediates()

      n = input%get_n_es_types()

      allocate(types(n))
      call mem%alloc(n_states, n)

      call input%get_es_types(n, types)

      call input%get_n_es_states(n, n_states, 'singlet')

      do i = 1, n

         descriptor = state_descriptor('right', types(i), 'singlet')

         excited_state_amplitudes = cc_es_amplitudes_task(descriptor, restart, n_states(i))
         call excited_state_amplitudes%execute(wf)

         deallocate(excited_state_amplitudes)
         deallocate(descriptor)

         descriptor = state_descriptor('left', types(i), 'singlet')

         excited_state_amplitudes = cc_es_amplitudes_task(descriptor, .true., n_states(i))
         call excited_state_amplitudes%execute(wf)

      end do

      call mem%dealloc(n_states)
      biorthonormalization = biorthonormalization_task()
      call biorthonormalization%execute(wf)

      if (input%is_keyword_present('variational energy', 'cc response')) &
         call wf%calculate_and_print_variational_es_energies()


      eom_transition_moments = cc_eom_transition_moments_task()
      call eom_transition_moments%execute(wf)
      call eom_transition_moments%cleanup()

      visualization = cc_visualization_task()
      call visualization%execute(wf)

   end subroutine ignite_eom_transition_moment_engine


   subroutine set_allowed_wfs_eom_transition_moment_engine(this)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      class(eom_transition_moment_engine), intent(inout) :: this

      this%allowed_cc_wfs = cc_wavefunctions()

      call this%allowed_cc_wfs%set('ccs', allowed=.true.)
      call this%allowed_cc_wfs%set('cc2', allowed=.true.)
      call this%allowed_cc_wfs%set('ccsd', allowed=.true.)
      call this%allowed_cc_wfs%set('qed-ccsd', allowed=.true.)
      call this%allowed_cc_wfs%set('cc3', allowed=.true.)
      call this%allowed_cc_wfs%set('mlccsd', allowed=.true.)
      call this%allowed_cc_wfs%set('mlcc2', allowed=.true.)

   end subroutine set_allowed_wfs_eom_transition_moment_engine


end module eom_transition_moment_engine_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_real_time_diagonal_engine_class

   !!
   !! CC real-time diagonal engine class
   !!
   !! Written by Andreas S. Skeidsvoll, Aug 2023
   !!
   !! Engine that prepares and propagates a time-dependent coupled-cluster state
   !! in real time. The propagation is done by expressing the time-dependent state
   !! in a basis of eigenstates obtained by diagonalizing the field-free
   !! Hamiltonian. The propagation requires the calculation of the matrix elements
   !! of the operators taking part in the time-dependent Hamiltonian, for all
   !! combinations of eigenstates including the ground state.
   !!

   use kinds
   use ccs_class, only: ccs
   use cc_real_time_engine_class, only: cc_real_time_engine
   use cc_es_amplitudes_task_class, only: cc_es_amplitudes_task
   use biorthonormalization_task_class, only: biorthonormalization_task
   use cc_eom_transition_moments_task_class, only: cc_eom_transition_moments_task
   use cc_propagation_task_class, only: cc_propagation_task
   use global_in, only: input
   use cc_lanczos_task_class, only: cc_lanczos_task

   implicit none

   type, extends(cc_real_time_engine) :: cc_real_time_diagonal_engine

   contains

      procedure, public :: ignite => ignite_cc_real_time_diagonal_engine

      procedure, nopass, private :: hamiltonian_and_dipole_matrix_generation

   end type cc_real_time_diagonal_engine


contains


   subroutine ignite_cc_real_time_diagonal_engine(this, wf)
      !!
      !! Written by Andreas S. Skeidsvoll, Aug 2023
      !!
      implicit none

      class(cc_real_time_diagonal_engine), intent(inout) :: this

      class(ccs), intent(inout) :: wf

      call this%prepare_ground_state(wf)

      call this%hamiltonian_and_dipole_matrix_generation(wf)

      this%propagation = cc_propagation_task()
      call this%propagation%execute(wf)

      call this%post_processing(wf)

   end subroutine ignite_cc_real_time_diagonal_engine


   subroutine hamiltonian_and_dipole_matrix_generation(wf)
      !!
      !! Written by Andreas S. Skeidsvoll, Aug 2023
      !!
      use state_descriptor_class, only: state_descriptor
      implicit none

      type(cc_es_amplitudes_task), allocatable :: excited_state_amplitudes
      type(biorthonormalization_task), allocatable :: biorthonormalization
      type(cc_eom_transition_moments_task), allocatable :: eom_transition_moments
      type(cc_lanczos_task), allocatable :: lanczos


      class(ccs), intent(inout) :: wf

      character(len=200) :: algorithm

      logical :: restart

      integer :: n_states

      type(state_descriptor), allocatable :: descriptor

      restart = input%is_keyword_present('restart', 'solver cc es') .or. &
                input%is_keyword_present('restart', 'do')

      call input%get_keyword('algorithm', 'solver cc es', algorithm)
      call input%get_n_es_states(n_states, 'singlet')

      if (trim(algorithm) == 'asymmetric band lanczos') then

         lanczos = cc_lanczos_task()
         call lanczos%execute(wf)

      else

         descriptor = state_descriptor('right', &
                                       .false., &
                                       .false., &
                                       .false., &
                                       .false., &
                                       'singlet')

         excited_state_amplitudes = cc_es_amplitudes_task(descriptor, restart, n_states)

         call excited_state_amplitudes%execute(wf)

         deallocate(excited_state_amplitudes)
         deallocate(descriptor)

         descriptor = state_descriptor('left', &
                                       .false., &
                                       .false., &
                                       .false., &
                                       .false., &
                                       'singlet')

         excited_state_amplitudes = cc_es_amplitudes_task(descriptor, .true., n_states)
         call excited_state_amplitudes%execute(wf)

      end if

      call wf%diagonalize_subspace_jacobian(n_states)

      biorthonormalization = biorthonormalization_task()
      call biorthonormalization%execute(wf)

      call wf%construct_and_save_subspace_hamiltonian(n_states)

      eom_transition_moments = cc_eom_transition_moments_task()
      call eom_transition_moments%execute(wf)
      call eom_transition_moments%cleanup()

   end subroutine hamiltonian_and_dipole_matrix_generation


end module cc_real_time_diagonal_engine_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_gs_engine_class

   !!
   !! CC ground state engine class
   !! Written by Tor S. Haugland, Eirik F. Kjoenstad,
   !! Alexander Paul, and Sarai D. Folkestad, 2019-2022
   !!

   use ccs_class, only: ccs
   use cc_engine_class, only: cc_engine
   use cc_amplitudes_task_class, only: cc_amplitudes_task
   use eri_approximator_task_class, only: eri_approximator_task
   use cc_wavefunctions_class, only: cc_wavefunctions
   use cc_visualization_task_class, only: cc_visualization_task

   implicit none

   type, extends(cc_engine) :: cc_gs_engine

      type(cc_amplitudes_task), allocatable, private :: ground_state_amplitudes
      type(cc_visualization_task), allocatable, private :: visualization
      type(eri_approximator_task), private :: eri_approximator

   contains

      procedure, public :: ignite => ignite_cc_gs_engine
      procedure, public :: set_allowed_wfs => set_allowed_wfs_cc_gs_engine

   end type cc_gs_engine

contains


   subroutine ignite_cc_gs_engine(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad, 2021

      implicit none

      class(cc_gs_engine), intent(inout) :: this
      class(ccs), intent(inout) :: wf

      call this%set_allowed_wfs()
      call this%check_wavefunctions(wf)

      call this%eri_approximator%execute(wf)

      this%ground_state_amplitudes = cc_amplitudes_task()
      call this%ground_state_amplitudes%execute(wf)

      this%visualization = cc_visualization_task()
      call this%visualization%execute(wf)

   end subroutine ignite_cc_gs_engine


   subroutine set_allowed_wfs_cc_gs_engine(this)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      class(cc_gs_engine), intent(inout) :: this


      this%allowed_cc_wfs = cc_wavefunctions()

      call this%allowed_cc_wfs%set('mp2', allowed=.true.)
      call this%allowed_cc_wfs%set('ccs', allowed=.true.)
      call this%allowed_cc_wfs%set('cc2', allowed=.true.)
      call this%allowed_cc_wfs%set('low memory cc2', allowed=.true.)
      call this%allowed_cc_wfs%set('ccsd', allowed=.true.)
      call this%allowed_cc_wfs%set('ccsd(t)', allowed=.true.)
      call this%allowed_cc_wfs%set('ccsdt', allowed=.true.)
      call this%allowed_cc_wfs%set('cc3', allowed=.true.)
      call this%allowed_cc_wfs%set('mlcc2', allowed=.true.)
      call this%allowed_cc_wfs%set('mlccsd', allowed=.true.)
      call this%allowed_cc_wfs%set('qed-ccsd', allowed=.true.)

   end subroutine set_allowed_wfs_cc_gs_engine


end module cc_gs_engine_class

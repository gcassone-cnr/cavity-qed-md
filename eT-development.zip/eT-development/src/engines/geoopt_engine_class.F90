

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module geoopt_engine_class
   !!
   !! Geometry optimization engine class module
   !! Written by Eirik F. Kjoenstad, 2019, 2022, 2023
   !!
   use parameters
   use timings_class, only: timings
   use bfgs_solver_class, only: bfgs_solver
   use redundant_internal_coordinates_class, only: redundant_internal_coords
   use geoopt_solver_factory_class, only: geoopt_solver_factory
   use hf_class, only: hf
   use output_file_class, only: output_file

   type :: geoopt_engine

      type(timings), allocatable, private :: timer
      class(bfgs_solver), allocatable, private :: solver

      character(len=200), private :: header

   contains

      generic, public :: run => run_cc_geoopt_engine, run_hf_geoopt_engine

      procedure, private :: run_hf_geoopt_engine
      procedure, private :: run_cc_geoopt_engine

      procedure, private :: print_banner

   end type geoopt_engine


   interface geoopt_engine

      procedure :: new_geoopt_engine

   end interface geoopt_engine


contains


   function new_geoopt_engine() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      type(geoopt_engine) :: this

      this%timer = timings('Geometry optimization', 'm')

   end function new_geoopt_engine


   subroutine run_hf_geoopt_engine(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad, 2019
      !!
      implicit none

      class(geoopt_engine), intent(inout) :: this

      class(hf), intent(inout) :: wf

      type(redundant_internal_coords), allocatable :: internals
      type(geoopt_solver_factory), allocatable :: solver_factory

      this%header = 'Geometry optimization (HF)'
      call this%print_banner()

      this%timer = timings(trim(this%header), 'm')
      call this%timer%turn_on()

      internals = redundant_internal_coords(3 * wf%n_atomic_centers)
      call wf%initialize_redundant_internal_coordinates(internals)

      solver_factory = geoopt_solver_factory()
      call solver_factory%create(wf, internals, this%solver)

      call this%solver%initialize()
      call this%solver%run()
      call this%solver%finalize()

      call wf%save_geometry_to_xyz(output_file("eT.optimized_geometry.xyz"))

      call this%timer%turn_off()

   end subroutine run_hf_geoopt_engine


   subroutine run_cc_geoopt_engine(this, cc_wf, ref_wf)
      !!
      !! Written by Eirik F. Kjoenstad, 2019
      !!
      use ccs_class, only: ccs

      implicit none

      class(geoopt_engine), intent(inout) :: this

      class(ccs), intent(inout) :: cc_wf
      class(hf), intent(inout) :: ref_wf

      type(redundant_internal_coords), allocatable :: internals
      type(geoopt_solver_factory), allocatable :: solver_factory

      this%header = 'Geometry optimization (CC)'
      call this%print_banner()

      this%timer = timings(trim(this%header), 'm')
      call this%timer%turn_on()

      internals = redundant_internal_coords(3 * cc_wf%n_atomic_centers)
      call cc_wf%initialize_redundant_internal_coordinates(internals)

      solver_factory = geoopt_solver_factory()
      call solver_factory%create(cc_wf, ref_wf, internals, this%solver)

      call this%solver%initialize()
      call this%solver%run()
      call this%solver%finalize()

      call cc_wf%save_geometry_to_xyz(output_file("eT.optimized_geometry.xyz"))

      call this%timer%turn_off()

   end subroutine run_cc_geoopt_engine


   subroutine print_banner(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2022
      !!
      use banner_printer_class, only: banner_printer

      implicit none

      class(geoopt_engine), intent(inout) :: this
      type(banner_printer) :: banner

      call banner%print_(trim(this%header))

   end subroutine print_banner


end module geoopt_engine_class

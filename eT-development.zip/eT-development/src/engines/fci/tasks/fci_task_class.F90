

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module fci_task_class

   !!
   !! FCI task class module
   !! Written by Eirik F. Kjoenstad, Alexander C. Paul, May 2022
   !!

   use abstract_task_class, only: abstract_task
   use fci_class, only: fci

   implicit none

   type, abstract, extends(abstract_task) :: fci_task

   contains

      procedure(execute), public, deferred :: execute

   end type fci_task


   abstract interface

      subroutine execute(this, wf)

         import :: fci, fci_task

         implicit none

         class(fci_task), intent(inout) :: this

         class(fci), intent(inout), target :: wf

      end subroutine execute

   end interface

end module fci_task_class

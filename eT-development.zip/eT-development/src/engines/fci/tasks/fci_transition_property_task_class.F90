

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module fci_transition_property_task_class

   !!
   !! FCI transition properties task class
   !! Written by Rosario R. Riso, March 2023
   !!

   use parameters
   use memory_manager_class, only: mem
   use global_in, only: input
   use global_out, only: output
   use fci_class, only: fci
   use fci_task_class, only: fci_task

   implicit none

   type, extends(fci_task) :: fci_transition_property_task

      logical :: dipole, quadrupole, task_requested

      integer :: n_transition_densities, n_final_states, n_initial_states
      integer, dimension(:), allocatable :: initial_states, final_states

   contains

      procedure, public :: execute => execute_fci_transition_property_task

      procedure, private :: read_settings

   end type fci_transition_property_task


   interface fci_transition_property_task

      procedure :: new_fci_transition_property_task

   end interface fci_transition_property_task


contains


   function new_fci_transition_property_task() result(this)
      !!
      !! Written by Rosario R. Riso, 2023
      !!
      implicit none

      type(fci_transition_property_task) :: this

      this%name_ = 'Determining CI transition properties'

   end function new_fci_transition_property_task


   subroutine execute_fci_transition_property_task(this, wf)
      !!
      !! Written by Rosario R. Riso and Matteo Rinaldi, 2023
      !!
      implicit none

      class(fci_transition_property_task), intent(inout) :: this
      class(fci), intent(inout), target :: wf

      real(dp), dimension(:, :), allocatable :: density

      integer :: n, m, state_i, state_f

      real(dp) :: omega

      call this%print_header()
      call this%start_timer()

      call this%read_settings(wf)

      call mem%alloc(density, wf%n_mo, wf%n_mo)

      call output%printf('m', '- Summary of CI transition properties calculation:', fs='(/t3,a)')

      do n = 1, this%n_initial_states
         do m = 1, this%n_final_states

            state_i = this%initial_states(n)
            state_f = this%final_states(m)

            call output%printf('m', 'States n = (i0) and m = (i0):', fs='(/t6,a)', ints=[state_i, state_f])
            call output%print_separator('m', 25, '-', fs='(t6,a)')

            call wf%construct_transition_density(state_f, state_i, density)

            omega = wf%energies(state_f) - wf%energies(state_i)

            call output%printf('m', &
                               'Transition energy (n -> m) [E_h]: (f19.12)', &
                               reals=[omega], &
                               fs='(t6,a)')

            call output%printf('m', &
                               'Transition energy (n -> m) [eV]:  (f19.12)', &
                               reals=[(omega) * Hartree_to_eV], &
                               fs='(t6,a)')

            if (state_i == state_f) then
               if (this%dipole) call wf%calculate_and_print_dipole(density)

               if (this%quadrupole) call wf%calculate_and_print_quadrupole(density)
            else
               if (this%dipole) call wf%calculate_and_print_transition_dipole(density, omega)

               if (this%quadrupole) call wf%calculate_and_print_transition_quadrupole(density)
            end if

         end do

      end do

      call mem%dealloc(density)
      call mem%dealloc(this%final_states)
      call mem%dealloc(this%initial_states)

      call this%end_timer()

   end subroutine execute_fci_transition_property_task


   subroutine read_settings(this, wf)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      use global_in, only: input

      implicit none

      class(fci_transition_property_task), intent(inout) :: this
      class(fci), intent(in) :: wf

      this%dipole = input%is_keyword_present('dipole', 'ci transition property')
      this%quadrupole = input%is_keyword_present('quadrupole', 'ci transition property')

      this%n_initial_states = input%get_n_elements_for_keyword('initial states', 'ci transition property')
      this%n_final_states = input%get_n_elements_for_keyword('final states', 'ci transition property')

      call mem%alloc(this%initial_states, this%n_initial_states)
      call mem%alloc(this%final_states, this%n_final_states)

      call input%get_array_for_keyword('initial states', &
                                       'ci transition property', &
                                       this%n_initial_states, &
                                       this%initial_states)

      call input%get_array_for_keyword('final states', &
                                       'ci transition property', &
                                       this%n_final_states, &
                                       this%final_states)

      if (any(this%initial_states > wf%n_states) .or. any(this%final_states > wf%n_states)) &
         call output%error_msg("Requested transition density for state that has not been calculated")

   end subroutine read_settings


end module fci_transition_property_task_class

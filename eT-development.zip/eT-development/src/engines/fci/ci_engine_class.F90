

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module ci_engine_class

   !!
   !! FCI engine class
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, and Alexander C. Paul, 2018-2022
   !!

   use abstract_ci_engine_class, only: abstract_ci_engine
   use fci_class, only: fci

   use fci_eigenproblem_task_class, only: fci_eigenproblem_task
   use fci_mean_value_task_class, only: fci_mean_value_task
   use fci_transition_property_task_class, only: fci_transition_property_task

   implicit none

   type, extends(abstract_ci_engine) :: ci_engine

      type(fci_eigenproblem_task), allocatable, private :: eigenproblem
      type(fci_mean_value_task), allocatable, private :: mean_value
      type(fci_transition_property_task), allocatable, private :: transition_property

   contains

      procedure, public :: ignite => ignite_ci_engine

   end type ci_engine

contains


   subroutine ignite_ci_engine(this, wf)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      use global_in, only: input

      implicit none

      class(ci_engine), intent(inout) :: this
      class(fci), intent(inout) :: wf

      this%eigenproblem = fci_eigenproblem_task()
      call this%eigenproblem%execute(wf)

      if (input%is_section_present('ci mean value')) then

         this%mean_value = fci_mean_value_task()
         call this%mean_value%execute(wf)

      elseif (input%is_section_present('ci transition property')) then

         this%transition_property = fci_transition_property_task()
         call this%transition_property%execute(wf)

      end if

   end subroutine ignite_ci_engine


end module ci_engine_class

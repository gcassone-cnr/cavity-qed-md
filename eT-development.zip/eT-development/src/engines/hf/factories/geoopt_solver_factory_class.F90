

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module geoopt_solver_factory_class

   !!
   !! Geoopt solver factory class
   !! Written by Alexander C. Paul,Eirik F. Kjoenstad,
   !! and Jan Haakon M. Trasbki, 2022-2023
   !!

   use parameters
   use redundant_internal_coordinates_class, only: redundant_internal_coords
   use objective_function_class, only: objective_function
   use bfgs_solver_class, only: bfgs_solver

   implicit none

   type :: geoopt_solver_factory

      integer, private :: max_iterations
      real(dp), private :: max_step, step_size, energy_threshold, gradient_threshold
      real(dp), private :: gradient_rms_threshold, atomic_displacement_threshold
      real(dp), private :: atomic_displacement_rms_threshold

      character(len=200), private :: gradient_method

      integer, private :: state

      class(objective_function), allocatable, private :: energy_function

   contains

      generic, public :: create => create_solver_with_hf_wavefunction, create_solver_with_cc_wavefunction

      procedure, private :: create_solver_with_hf_wavefunction
      procedure, private :: create_solver_with_cc_wavefunction
      procedure, private :: read_settings
      procedure, private :: create_bfgs_solver

   end type geoopt_solver_factory

   interface geoopt_solver_factory

      procedure :: new_geoopt_solver_factory

   end interface geoopt_solver_factory


contains


   function new_geoopt_solver_factory() result(this)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      implicit none

      type(geoopt_solver_factory) :: this

      call this%read_settings()

   end function new_geoopt_solver_factory


   subroutine create_solver_with_hf_wavefunction(this, wf, internals, solver)
      !!
      !! Written by Alexander C. Paul, Eirik F. Kjoenstad and Jan Haakon M. Trasbki, 2022-2023
      !!
      use hf_class, only: hf
      use hf_energy_function_class, only: hf_energy_function

      implicit none

      class(geoopt_solver_factory), intent(inout) :: this
      class(hf), intent(in) :: wf
      class(bfgs_solver), allocatable, intent(out) :: solver
      type(redundant_internal_coords), intent(inout) :: internals

      this%energy_function = hf_energy_function(wf, trim(this%gradient_method), this%step_size)

      call this%create_bfgs_solver(solver, internals)

   end subroutine create_solver_with_hf_wavefunction


   subroutine create_solver_with_cc_wavefunction(this, cc_wf, ref_wf, internals, solver)
      !!
      !! Written by Alexander C. Paul and Eirik F. Kjoenstad, May 2022 and Mar 2023
      !! and Jan Haakon M. Trasbki, June 2023
      !!
      use hf_class, only: hf
      use ccs_class, only: ccs

      use cc_gs_energy_function_class, only: cc_gs_energy_function
      use cc_es_energy_function_class, only: cc_es_energy_function

      implicit none

      class(geoopt_solver_factory), intent(inout) :: this
      class(hf), intent(in) :: ref_wf
      class(ccs), intent(in) :: cc_wf
      class(bfgs_solver), allocatable, intent(out) :: solver
      type(redundant_internal_coords), intent(inout) :: internals

      if (this%state > 0) then

         this%energy_function = cc_es_energy_function(cc_wf, &
                                                      ref_wf, &
                                                      this%state, &
                                                      trim(this%gradient_method), &
                                                      this%step_size)

      else

         this%energy_function = cc_gs_energy_function(cc_wf, &
                                                      ref_wf, &
                                                      trim(this%gradient_method), &
                                                      this%step_size)


      end if

      call this%create_bfgs_solver(solver, internals)

   end subroutine create_solver_with_cc_wavefunction


   subroutine create_bfgs_solver(this, solver, internals)
      !!
      !! Written by Alexander C. Paul, Dec 2023
      !!
      use geoopt_convergence_tool_class, only: geoopt_convergence_tool

      implicit none

      class(geoopt_solver_factory), intent(inout) :: this
      class(bfgs_solver), allocatable, intent(out) :: solver
      type(redundant_internal_coords), intent(inout) :: internals

      type(geoopt_convergence_tool), allocatable :: convergence_checker

      convergence_checker = geoopt_convergence_tool(this%energy_threshold, &
                                                    this%gradient_threshold, &
                                                    this%gradient_rms_threshold, &
                                                    this%atomic_displacement_threshold, &
                                                    this%atomic_displacement_rms_threshold, &
                                                    energy_convergence=.true.)

      solver = bfgs_solver(this%energy_function, &
                           internals, &
                           this%max_iterations, &
                           this%max_step, &
                           convergence_checker)

   end subroutine create_bfgs_solver


   subroutine read_settings(this)
      !!
      !! Written by Sarai D. Folkestad and Jan Haakon M. Trasbki, 2021-2023
      !!
      use global_in, only: input
      use global_out, only: output

      implicit none

      class(geoopt_solver_factory), intent(inout) :: this
      character(len=200) :: algorithm

      algorithm = "bfgs"

      call input%get_keyword('algorithm', 'solver geometry optimization', algorithm)

      if (trim(algorithm) == 'bfgs') then

         this%max_iterations = 100
         call input%get_keyword('max iterations', 'solver geometry optimization', this%max_iterations)

         this%max_step = half
         call input%get_keyword('max step', 'solver geometry optimization', this%max_step)

         this%energy_threshold = 1.0d-6
         call input%get_keyword('energy threshold', 'solver geometry optimization', this%energy_threshold)

         this%gradient_threshold = 3.0d-4
         call input%get_keyword('residual threshold', 'solver geometry optimization', this%gradient_threshold)

         this%gradient_rms_threshold = 1.2d-4

         call input%get_keyword('residual rms threshold', &
                                'solver geometry optimization', &
                                this%gradient_rms_threshold)

         this%atomic_displacement_threshold = 1.2d-4

         call input%get_keyword('displacement threshold', &
                                'solver geometry optimization', &
                                this%atomic_displacement_threshold)

         this%atomic_displacement_rms_threshold = 1.2d-4

         call input%get_keyword('displacement rms threshold', &
                                'solver geometry optimization', &
                                this%atomic_displacement_rms_threshold)

      else

         call output%error_msg('did not recognize scf geoopt algorithm: (a0)', &
                               chars=[algorithm])

      end if

      this%gradient_method = "analytical"
      call input%get_keyword("gradient method", "solver geometry optimization", this%gradient_method)

      if (trim(this%gradient_method) /= "analytical") then
         this%step_size = 1.0d-4
         call input%get_keyword('step size', 'solver geometry optimization', this%step_size)
      end if

      this%state = 0
      call input%get_keyword('state', 'solver geometry optimization', this%state)

   end subroutine read_settings


end module geoopt_solver_factory_class

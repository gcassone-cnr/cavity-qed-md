

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_geoopt_solver_factory_class

   !!
   !! HF geoopt solver factory class
   !! Written by Alexander C. Paul, May 2022
   !!

   use parameters
   use hf_class, only: hf
   use bfgs_solver_class, only: bfgs_solver
   use objective_function_class, only: objective_function

   implicit none

   type :: hf_geoopt_solver_factory

      integer :: max_iterations
      real(dp) :: max_step, energy_threshold, gradient_threshold

      class(objective_function), allocatable :: energy_function

   contains

      procedure, public :: create => create_hf_geoopt_solver_factory

      procedure, private :: read_settings
      procedure :: create_energy_function

   end type hf_geoopt_solver_factory

   interface hf_geoopt_solver_factory

      procedure :: new_hf_geoopt_solver_factory

   end interface hf_geoopt_solver_factory

contains


   function new_hf_geoopt_solver_factory() result(this)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      implicit none

      type(hf_geoopt_solver_factory) :: this

      call this%read_settings()

   end function new_hf_geoopt_solver_factory


   subroutine create_hf_geoopt_solver_factory(this, wf, internals, solver)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      use redundant_internal_coordinates_class, only: redundant_internal_coords

      implicit none

      class(hf_geoopt_solver_factory), intent(inout) :: this
      class(hf), intent(in) :: wf
      type(redundant_internal_coords), intent(in) :: internals
      class(bfgs_solver), allocatable, intent(out) :: solver

      call this%create_energy_function(wf)

      solver = bfgs_solver(this%energy_function, &
                           internals, &
                           this%max_iterations, &
                           this%max_step, &
                           this%energy_threshold, &
                           this%gradient_threshold)

   end subroutine create_hf_geoopt_solver_factory


   subroutine create_energy_function(this, wf)
      !!
      !! Written by Alexander C. Paul, Feb 2023
      !!
      use global_in, only: input
      use hf_energy_function_class, only: hf_energy_function

      implicit none

      class(hf_geoopt_solver_factory), intent(inout) :: this
      class(hf), intent(in) :: wf

      character(len=200) :: gradient_method
      real(dp) :: step_size

      gradient_method = "analytical"
      call input%get_keyword("gradient method", "solver geometry optimization", gradient_method)

      if (trim(gradient_method) /= "analytical") then
         step_size = - one
         call input%get_required_keyword('step size', 'solver geometry optimization', step_size)
      end if

      this%energy_function = hf_energy_function(wf, trim(gradient_method), step_size)

   end subroutine create_energy_function


   subroutine read_settings(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      use global_in, only: input
      use global_out, only: output

      implicit none

      class(hf_geoopt_solver_factory), intent(inout) :: this
      character(len=200) :: algorithm

      algorithm = "bfgs"

      call input%get_keyword('algorithm', 'solver geometry optimization', algorithm)

      if (trim(algorithm) == 'bfgs') then

         this%max_iterations = 100
         call input%get_keyword('max iterations', 'solver geometry optimization', this%max_iterations)

         this%max_step = half
         call input%get_keyword('max step', 'solver geometry optimization', this%max_step)

         this%energy_threshold = 1.0d-6
         call input%get_keyword('energy threshold', 'solver geometry optimization', this%energy_threshold)

         this%gradient_threshold = 3.0d-4
         call input%get_keyword('residual threshold', 'solver geometry optimization', this%gradient_threshold)

      else

         call output%error_msg('did not recognize scf geoopt algorithm: (a0)', &
                               chars=[algorithm])

      end if

   end subroutine read_settings

end module hf_geoopt_solver_factory_class

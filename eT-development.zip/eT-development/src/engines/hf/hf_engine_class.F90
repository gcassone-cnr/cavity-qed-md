

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_engine_class

   !!
   !! Hartree-Fock engine class
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, and Alexander C. Paul, 2018-2022
   !!

   use hf_class, only: hf
   use hf_wavefunctions_class, only: hf_wavefunctions
   use global_out, only: output

   implicit none

   type, abstract :: hf_engine

      class(hf_wavefunctions), allocatable :: allowed_hf_wfs

   contains

      procedure(ignite), deferred, public :: ignite
      procedure(set_allowed_wfs), deferred, public :: set_allowed_wfs

      procedure, public :: check_wavefunctions

   end type hf_engine


   abstract interface

      subroutine ignite(this, wf)

         import :: hf, hf_engine

         implicit none

         class(hf_engine), intent(inout) :: this

         class(hf), intent(inout) :: wf

      end subroutine ignite


      subroutine set_allowed_wfs(this)

         import :: hf_engine

         implicit none

         class(hf_engine), intent(inout) :: this

      end subroutine set_allowed_wfs


   end interface

contains

   subroutine check_wavefunctions(this, wf)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      class(hf_engine), intent(in) :: this
      class(hf), intent(in) :: wf

      logical :: allowed

      allowed = this%allowed_hf_wfs%is_allowed(wf%name_)

      if (.not. allowed) &
         call output%error_msg('wave function ' // trim(wf%name_) // &
            ' is not allowed for the selected engine!')

   end subroutine check_wavefunctions


end module hf_engine_class

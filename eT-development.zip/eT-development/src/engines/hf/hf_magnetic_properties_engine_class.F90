
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_magnetic_properties_engine_class

   !!
   !! HF magnetic properties engine class
   !! Written by Alberto Barlini, Feb 2023
   !!

   use hf_engine_class, only: hf_engine
   use hf_class, only: hf
   use hf_wavefunctions_class, only: hf_wavefunctions

   use hf_magnetic_properties_task_class, only: hf_magnetic_properties_task

   implicit none

   type, extends(hf_engine) :: hf_magnetic_properties_engine

      type(hf_magnetic_properties_task), allocatable, private :: hf_magnetic_properties

   contains

      procedure, public :: ignite => ignite_hf_magnetic_properties_engine
      procedure, public :: set_allowed_wfs => set_allowed_wfs_hf_magnetic_properties_engine

   end type hf_magnetic_properties_engine

contains


   subroutine ignite_hf_magnetic_properties_engine(this, wf)
      !!
      !! Written by Alberto Barlini, October 2022
      !!
      use hf_gs_engine_class, only: hf_gs_engine

      implicit none

      class(hf), intent(inout) :: wf
      class(hf_magnetic_properties_engine), intent(inout) :: this

      type(hf_gs_engine), allocatable :: gs_engine

      call this%set_allowed_wfs()
      call this%check_wavefunctions(wf)

      gs_engine = hf_gs_engine()
      call gs_engine%ignite(wf)

      this%hf_magnetic_properties = hf_magnetic_properties_task()
      call this%hf_magnetic_properties%execute(wf)

   end subroutine ignite_hf_magnetic_properties_engine


   subroutine set_allowed_wfs_hf_magnetic_properties_engine(this)
      !!
      !! Written by Matteo Castagnola, Feb. 2025
      !!
      implicit none

      class(hf_magnetic_properties_engine), intent(inout) :: this


      this%allowed_hf_wfs = hf_wavefunctions()

      call this%allowed_hf_wfs%set('rhf', allowed=.true.)
      call this%allowed_hf_wfs%set('qed-rhf', allowed=.true.)

   end subroutine set_allowed_wfs_hf_magnetic_properties_engine


end module hf_magnetic_properties_engine_class

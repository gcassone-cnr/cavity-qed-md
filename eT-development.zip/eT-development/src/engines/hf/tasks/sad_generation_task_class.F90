

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module sad_generation_task_class

   !!
   !! SAD generation task class
   !! Written by Alexander C. Paul, Sarai D. Folkestad, and Eirik F. Kjoenstad, 2022
   !!

   use kinds
   use hf_class, only: hf
   use hf_task_class, only: hf_task

   implicit none

   type, extends(hf_task) :: sad_generation_task

      integer :: diis_dimension
      real(dp) :: threshold
      logical :: do_diis

   contains

      procedure, public :: execute => execute_sad_generation_task

      procedure, private :: read_settings

   end type sad_generation_task


   interface sad_generation_task

      procedure :: new_sad_generation_task

   end interface sad_generation_task


contains


   function new_sad_generation_task() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2022
      !!
      implicit none

      type(sad_generation_task) :: this

      this%name_ = 'Generating initial SAD density'

   end function new_sad_generation_task


   subroutine execute_sad_generation_task(this, wf)
      !!
      !! Written by Sarai D. Folkestad, Oct 2021
      !!
      use sad_tool_class, only: sad_tool
      use atomic_center_class, only: atomic_center

      implicit none

      class(sad_generation_task), intent(inout) :: this
      class(hf), intent(inout), target :: wf

      type(atomic_center), dimension(:), allocatable :: centers

      type(sad_tool) :: sad

      call this%print_header()
      call this%start_timer()

      call this%read_settings()
      sad = sad_tool(this%threshold, do_diis=this%do_diis, diis_dimension=this%diis_dimension)

      allocate(centers(wf%ao%get_n_centers()))
      call wf%ao%get_centers(centers, 1, wf%ao%get_n_centers())

      call sad%generate(wf%ao%get_n_centers(), centers)

      deallocate(centers)

      ! Integral library is overwritten by SAD. Re-initialize.
      call wf%ao%export_centers_to_integral_libraries()

      ! Re-determine status of a file because SAD may have deleted it
      ! (so the status must go from "old" -> "new")
      call wf%orbital_file%determine_status()

      call this%end_timer()

   end subroutine execute_sad_generation_task


   subroutine read_settings(this)
      !!
      !! Written by Sarai D. Folkestad, 2026
      !!
      use global_in, only: input

      implicit none

      class(sad_generation_task), intent(inout) :: this
      character(len=200) :: algorithm

      this%diis_dimension = 8
      if (input%is_keyword_present('diis dimension', 'solver scf')) &
         call input%get_keyword('diis dimension', 'solver scf', this%diis_dimension)

      this%threshold = 1.0d-6
      call input%get_keyword('residual threshold', 'solver scf', this%threshold)

      algorithm = 'scf-diis'
      call input%get_keyword('algorithm', 'solver scf', algorithm)

      this%do_diis = (trim(algorithm) == 'scf-diis') .and. &
                     .not. input%is_keyword_present('crop', 'solver scf')


   end subroutine read_settings

end module sad_generation_task_class

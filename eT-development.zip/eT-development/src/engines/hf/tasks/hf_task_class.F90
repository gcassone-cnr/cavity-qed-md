

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_task_class

   !!
   !! HF task class module
   !! Written by Eirik F. Kjoenstad, 2021
   !!

   use abstract_task_class, only: abstract_task
   use hf_class, only: hf

   implicit none

   type, abstract, extends(abstract_task) :: hf_task

   contains

      procedure(execute), public, deferred :: execute

   end type hf_task


   abstract interface

      subroutine execute(this, wf)

         import :: hf, hf_task

         implicit none

         class(hf_task), intent(inout) :: this

         class(hf), intent(inout), target :: wf

      end subroutine execute

   end interface


contains


end module hf_task_class

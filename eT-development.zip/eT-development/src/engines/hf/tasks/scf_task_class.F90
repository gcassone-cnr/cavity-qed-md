

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module scf_task_class

   !!
   !! SCF task class
   !! Written by Alexander C. Paul, Sarai D. Folkestad, and Eirik F. Kjoenstad, 2022
   !!

   use hf_class, only: hf
   use hf_task_class, only: hf_task

   implicit none

   type, extends(hf_task) :: scf_task

      logical :: restart, skip_scf, write_mo_info, write_molden_file

      ! Population analysis variables

      character(len=200), private :: population_analysis
      logical :: mulliken = .false.
      logical :: loewdin = .false.

   contains

      procedure, public :: execute => execute_scf_task

      procedure, private :: read_settings

      procedure, private :: read_population_analysis_settings

   end type scf_task


   interface scf_task

      procedure :: new_scf_task

   end interface scf_task


contains


   function new_scf_task() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2022
      !!
      implicit none

      type(scf_task) :: this

      this%name_ = 'Determining reference state'

   end function new_scf_task


   subroutine execute_scf_task(this, wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      use global_in, only: input
      use abstract_solver_class, only: abstract_solver
      use hf_solver_factory_class, only: hf_solver_factory

      implicit none

      class(scf_task), intent(inout) :: this
      class(hf), intent(inout), target :: wf

      type(hf_solver_factory), allocatable :: factory
      class(abstract_solver), allocatable :: solver

      call this%print_header()
      call this%start_timer()

      call this%read_settings(wf)

      call wf%prepare_for_scf(this%restart, this%skip_scf)

      factory = hf_solver_factory()
      call factory%create(wf, solver, this%skip_scf)

      call solver%run()

      if (trim(factory%algorithm) == 'level-shift-newton-raphson') then

         call wf%diagonalize_fock()

      end if

      call wf%finalize_gs()

      call wf%print_summary()

      if (input%is_keyword_present('population analysis', 'solver scf')) then
         call this%read_population_analysis_settings()
         if (this%mulliken) call wf%mulliken_population_analysis()
         if (this%loewdin) call wf%loewdin_population_analysis()
      end if

      if (this%write_mo_info) call wf%write_orbital_info()
      if (this%write_molden_file) call wf%write_molden_file()

      call this%end_timer()

   end subroutine execute_scf_task


   subroutine read_settings(this, wf)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      use global_in, only: input

      implicit none

      class(scf_task), intent(inout) :: this
      class(hf), intent(in) :: wf

      this%restart = .false.

      if (input%is_keyword_present('restart', 'solver scf') .or. input%is_keyword_present('restart', 'do')) &
          then

         this%restart = wf%is_restart_possible()

      end if

      this%skip_scf = input%is_keyword_present('skip', 'solver scf')

      this%write_mo_info = input%is_keyword_present('write orbitals', 'solver scf')
      if (input%is_keyword_present('write orbitals', 'system')) then
         this%write_mo_info = .true.
      end if

      this%write_molden_file = input%is_keyword_present('write molden', 'solver scf')

   end subroutine read_settings


   subroutine read_population_analysis_settings(this)
      !!
      !! Written by Matteo Castagnola and Regina Matveeva, Dec 2022
      !!
      !! Reads which population analysis (Mulliken or/and Loewdin) should be performed.
      !!
      use global_in, only: input
      use global_out, only: output

      implicit none

      class(scf_task), intent(inout) :: this

      call input%get_keyword('population analysis', 'solver scf', this%population_analysis)

      this%loewdin = .false.
      this%mulliken = .false.

      if (trim(this%population_analysis) == 'mulliken') then

         this%mulliken = .true.

      else if (trim(this%population_analysis) == 'loewdin') then

         this%loewdin = .true.

      else if (trim(this%population_analysis) == 'all') then

         this%mulliken = .true.
         this%loewdin = .true.

      else

         call output%error_msg('did not recognize the population analysis type')

      end if

   end subroutine read_population_analysis_settings

end module scf_task_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module tdhf_es_task_class

   !!
   !! TDHF es task class
   !! Written by Alexander C. Paul, Sarai D. Folkestad, May 2022
   !!
   use hf_class, only: hf
   use hf_task_class, only: hf_task

   implicit none

   type, extends(hf_task) :: tdhf_es_task

   contains

      procedure, public :: execute => execute_tdhf_es_task

   end type tdhf_es_task


   interface tdhf_es_task

      procedure :: new_tdhf_es_task

   end interface tdhf_es_task


contains


   function new_tdhf_es_task() result(this)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      implicit none

      type(tdhf_es_task) :: this

      this%name_ = ''

   end function new_tdhf_es_task


   subroutine execute_tdhf_es_task(this, wf)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      use eigen_davidson_solver_class, only: eigen_davidson_solver
      use tdhf_solver_factory_class, only: tdhf_solver_factory
      use global_in, only: input

      use string_utilities, only: convert_to_uppercase

      implicit none

      class(tdhf_es_task), intent(inout) :: this
      class(hf), intent(inout), target :: wf

      class(eigen_davidson_solver), allocatable :: solver
      type(tdhf_solver_factory) :: solver_factory

      logical :: tamm_dancoff, velocity_dipole, rotatory_strength

      this%name_ = 'Determining TD' // trim(convert_to_uppercase(wf%name_)) // ' excitation energies'

      call this%print_header()
      call this%start_timer()

      call wf%set_n_tdhf_parameters()

      tamm_dancoff = .false.
      velocity_dipole = .false.
      rotatory_strength = .false.

      tamm_dancoff = input%is_keyword_present('tamm-dancoff', 'solver scf es') .or. &
                     input%is_keyword_present('tamm-dancoff', 'solver hf es')

      velocity_dipole = input%is_keyword_present('dipole velocity', 'hf response')
      rotatory_strength = input%is_keyword_present('rotatory strength', 'hf response')

      call solver_factory%create(wf, solver, tamm_dancoff)

      call wf%initialize_tdhf_quantities(solver%n_solutions)

      call solver%run()
      call solver%cleanup()

      call wf%compute_tdhf_transition_properties(tamm_dancoff, velocity_dipole, rotatory_strength)

      call wf%tdhf_summary(velocity_dipole, rotatory_strength)

      call this%end_timer()

   end subroutine execute_tdhf_es_task


end module tdhf_es_task_class

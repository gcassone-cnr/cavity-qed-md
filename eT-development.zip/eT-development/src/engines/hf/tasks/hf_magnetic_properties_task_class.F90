! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_magnetic_properties_task_class

   !!
   !! HF magnetic properties task class
   !! Written by Alberto Barlini, October 2022.
   !!

   use hf_class, only: hf
   use hf_task_class, only: hf_task

   implicit none

   type, extends(hf_task) :: hf_magnetic_properties_task

   contains

      procedure, public :: execute => execute_hf_magnetic_properties_task

   end type hf_magnetic_properties_task


   interface hf_magnetic_properties_task

      procedure :: new_hf_magnetic_properties_task

   end interface hf_magnetic_properties_task


contains


   function new_hf_magnetic_properties_task() result(this)
      !!
      !! Written by Alberto Barlini, October 2022
      !!
      implicit none

      type(hf_magnetic_properties_task) :: this

      this%name_ = 'Determining HF magnetic properties'

   end function new_hf_magnetic_properties_task


   subroutine execute_hf_magnetic_properties_task(this, wf)
      !!
      !! Written by Alberto Barlini, October 2022
      !!
      use linear_davidson_solver_class, only: linear_davidson_solver
      use hf_magnetic_properties_solver_factory_class, only: hf_magnetic_properties_solver_factory

      implicit none

      class(hf_magnetic_properties_task), intent(inout) :: this
      class(hf), intent(inout), target :: wf

      class(linear_davidson_solver), allocatable :: solver
      type(hf_magnetic_properties_solver_factory) :: solver_factory

      call this%print_header()
      call this%start_timer()

      call solver_factory%create(wf, solver)

      call wf%initialize_magnetic_properties_quantities()

      call solver%run()

      call solver%cleanup()

      call wf%nuclear_shielding_tensors_summary()

      call this%end_timer()

   end subroutine execute_hf_magnetic_properties_task


end module hf_magnetic_properties_task_class

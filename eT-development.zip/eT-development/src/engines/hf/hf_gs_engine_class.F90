

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_gs_engine_class

   !!
   !! HF ground state engine class
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, and Alexander C. Paul, 2018-2022
   !!

   use hf_engine_class, only: hf_engine
   use hf_class, only: hf

   use scf_task_class, only: scf_task
   use sad_generation_task_class, only: sad_generation_task
   use hf_mean_value_task_class, only: hf_mean_value_task
   use hf_visualization_task_class, only: hf_visualization_task
   use hf_wavefunctions_class, only: hf_wavefunctions
   use orbital_localization_task_class, only: orbital_localization_task

   implicit none

   type, extends(hf_engine) :: hf_gs_engine

      type(sad_generation_task), allocatable, private :: sad_generation
      type(scf_task), allocatable, private :: scf
      type(hf_mean_value_task), allocatable, private :: mean_value
      type(hf_visualization_task), allocatable, private :: visualization
      type(orbital_localization_task), allocatable, private :: orbital_localization

   contains

      procedure, public :: ignite => ignite_hf_gs_engine
      procedure, public :: set_allowed_wfs => set_allowed_wfs_hf_gs_engine

      procedure, private, nopass :: do_sad

   end type hf_gs_engine

contains


   subroutine ignite_hf_gs_engine(this, wf)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      use global_in, only: input

      implicit none

      class(hf_gs_engine), intent(inout) :: this
      class(hf), intent(inout) :: wf

      call this%set_allowed_wfs()
      call this%check_wavefunctions(wf)

      if (this%do_sad(wf)) then
         this%sad_generation = sad_generation_task()
         call this%sad_generation%execute(wf)
      end if

      this%scf = scf_task()
      call this%scf%execute(wf)

      this%mean_value = hf_mean_value_task()
      call this%mean_value%execute(wf)

      if (input%is_section_present('orbital localization')) then
         this%orbital_localization = orbital_localization_task()
         call this%orbital_localization%execute(wf)
      end if

      this%visualization = hf_visualization_task()
      call this%visualization%execute(wf)

   end subroutine ignite_hf_gs_engine


   function do_sad(wf) result(do_)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      use global_in, only: input

      implicit none

      class(hf), intent(inout) :: wf
      logical :: do_
      character(len=200) :: start_guess

      do_ = .true.

      start_guess = "sad"
      call input%get_keyword('ao density guess', 'solver scf', start_guess)

      if (start_guess == "core") then

         do_ = .false.
         return

      end if

      if (input%is_keyword_present('restart', 'solver scf') .or. &
          input%is_keyword_present('restart', 'do') .or. &
          input%is_keyword_present('skip', 'solver scf')) then

         do_ = .not. wf%is_restart_possible()
         return

      end if

   end function do_sad


   subroutine set_allowed_wfs_hf_gs_engine(this)
      !!
      !! Written by Matteo Castagnola, Feb. 2025
      !!
      implicit none

      class(hf_gs_engine), intent(inout) :: this

      this%allowed_hf_wfs = hf_wavefunctions()

      call this%allowed_hf_wfs%set('rhf', allowed=.true.)
      call this%allowed_hf_wfs%set('dft', allowed=.true.)
      call this%allowed_hf_wfs%set('uhf', allowed=.true.)
      call this%allowed_hf_wfs%set('mlhf', allowed=.true.)
      call this%allowed_hf_wfs%set('cuhf', allowed=.true.)
      call this%allowed_hf_wfs%set('rohf', allowed=.true.)
      call this%allowed_hf_wfs%set('qed-rhf', allowed=.true.)
      call this%allowed_hf_wfs%set('sc-qed-rhf', allowed=.true.)

   end subroutine set_allowed_wfs_hf_gs_engine


end module hf_gs_engine_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module tdhf_polarizability_engine_class

   !!
   !! TDHF polarizability engine class
   !! Written by Sarai D. Folkestad, Alexander C. Paul, 2018-2022
   !!

   use hf_engine_class, only: hf_engine
   use hf_class, only: hf
   use hf_wavefunctions_class, only: hf_wavefunctions

   use tdhf_polarizability_task_class, only: tdhf_polarizability_task

   implicit none

   type, extends(hf_engine) :: tdhf_polarizability_engine

      type(tdhf_polarizability_task), allocatable, private :: tdhf

   contains

      procedure, public :: ignite => ignite_tdhf_polarizability_engine
      procedure, public :: set_allowed_wfs => set_allowed_wfs_hf_polarizability_engine

   end type tdhf_polarizability_engine

contains


   subroutine ignite_tdhf_polarizability_engine(this, wf)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      use hf_gs_engine_class, only: hf_gs_engine

      implicit none

      class(tdhf_polarizability_engine), intent(inout) :: this
      class(hf), intent(inout) :: wf

      type(hf_gs_engine), allocatable :: gs_engine

      call this%set_allowed_wfs()
      call this%check_wavefunctions(wf)

      gs_engine = hf_gs_engine()
      call gs_engine%ignite(wf)

      this%tdhf = tdhf_polarizability_task()
      call this%tdhf%execute(wf)

   end subroutine ignite_tdhf_polarizability_engine


   subroutine set_allowed_wfs_hf_polarizability_engine(this)
      !!
      !! Written by Matteo Castagnola, Feb. 2025
      !!
      implicit none

      class(tdhf_polarizability_engine), intent(inout) :: this


      this%allowed_hf_wfs = hf_wavefunctions()

      call this%allowed_hf_wfs%set('rhf', allowed=.true.)

   end subroutine set_allowed_wfs_hf_polarizability_engine


end module tdhf_polarizability_engine_class

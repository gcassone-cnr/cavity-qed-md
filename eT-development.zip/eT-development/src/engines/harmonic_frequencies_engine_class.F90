

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module harmonic_frequencies_engine_class
   !!
   !! Harmonic frequencies engine class module
   !! Written by Eirik F. Kjoenstad, 2023
   !!
   !! Calculates the molecular Hessian (at HF or CC level) and uses it to:
   !!
   !!    - Compute vibrational frequencies (cm-1) according to harmonic normal mode approximation
   !!
   !!    - Compute/visualize vibrational normal modes
   !!
   !!    - Classify stationary point (minimum, saddle, transition)
   !!
   !!    - Produce a set of Wigner samples of positions and momenta for
   !!      the ground state vibrational wavefunctions at T = 0 K
   !!      (can be used, e.g., as initial conditions for trajectories in excited state dynamics)
   !!
   use parameters
   use timings_class, only: timings
   use objective_function_class, only: objective_function
   use memory_manager_class, only: mem
   use global_out, only: output
   use output_file_class, only: output_file

   type :: harmonic_frequencies_engine

      integer, private :: state  ! 0 = ground state, 1 = first excited state, ...

      ! Hessian is (so far) always numerical
      real(dp), private :: Hessian_displacement

      ! Gradient is analytical or numerical
      character(len=200) :: gradient_method
      real(dp), private :: gradient_displacement

      ! Energy function is used to calculate gradients
      class(objective_function), allocatable, private :: energy_function

      ! Reference geometry
      real(dp), dimension(:, :), allocatable, private :: r0

      real(dp), dimension(:, :, :, :), allocatable, private :: hessian
      real(dp), dimension(:, :, :, :), allocatable, private :: hessian_mass_weighted

      real(dp), dimension(:), allocatable, private :: eigenvalues
      real(dp), dimension(:, :), allocatable, private :: eigenvectors

      complex(dp), dimension(:), allocatable, private :: frequencies

      real(dp), private :: translation_rotation_threshold  ! in cm-1
      ! If frequency is below this value, the mode
      ! is classified as rotational or translational.
      ! Values above the threshold signifies numerical
      ! noise in Hessian and/or non-stationary reference
      ! geometry

      integer, private :: n_normal_modes
      real(dp), dimension(:, :, :), allocatable, private :: normal_modes

      integer, private :: n_atoms
      real(dp), dimension(:), allocatable, private :: masses  ! atomic masses in au (not amu!)
      character(len=2), dimension(:), allocatable, private :: symbols  ! atomic symbols

      integer, private :: n_wigner_samples
      integer, private :: wigner_seed  ! seed for random sampling of Wigner distribution

      type(timings), allocatable, private :: timer

   contains

      procedure, public :: initialize
      procedure, public :: run

      procedure, private :: general_preparations
      procedure, private :: set_defaults_and_read_settings

      procedure, private :: print_Hessian_settings
      procedure, private :: construct_unweighted_Hessian
      procedure, private :: construct_mass_weighted_Hessian
      procedure, private :: sort_eigenvectors_according_to_absolute_eigenvalue
      procedure, private :: calculate_harmonic_frequencies_cm_inverse
      procedure, private :: construct_normal_modes
      procedure, private :: animate_normal_modes_xyz
      procedure, private :: animate_normal_mode_xyz

      procedure, private :: generate_wigner_samples

      procedure, private :: initialize_random_number_generator
      procedure, private :: generate_wigner_sample
      procedure, private :: print_wigner_sample
      procedure, private :: save_wigner_sample_to_fms90_file
      procedure, private :: print_wigner_summary

      procedure, private :: print_normal_mode_summary
      procedure, private :: print_frequencies
      procedure, private :: print_normal_mode_coordinates
      procedure, private :: print_frequency_analysis
      procedure, private :: is_geometry_stationary
      procedure, private :: classify_stationary_point

   end type harmonic_frequencies_engine


   interface harmonic_frequencies_engine

      procedure :: new_harmonic_frequencies_engine_hf
      procedure :: new_harmonic_frequencies_engine_cc

   end interface harmonic_frequencies_engine


contains


   function new_harmonic_frequencies_engine_hf(ref_wf) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use hf_class, only: hf
      use hf_energy_function_class, only: hf_energy_function

      implicit none

      class(hf), intent(inout), target :: ref_wf

      type(harmonic_frequencies_engine) :: this

      call this%set_defaults_and_read_settings()

      this%energy_function = hf_energy_function(ref_wf, &
                                                trim(this%gradient_method), &
                                                this%gradient_displacement)

      call this%general_preparations(ref_wf)

   end function new_harmonic_frequencies_engine_hf


   function new_harmonic_frequencies_engine_cc(ref_wf, cc_wf) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use hf_class, only: hf
      use ccs_class, only: ccs
      use cc_es_energy_function_class, only: cc_es_energy_function
      use cc_gs_energy_function_class, only: cc_gs_energy_function

      implicit none

      class(hf), intent(inout), target :: ref_wf
      class(ccs), intent(inout), target :: cc_wf

      type(harmonic_frequencies_engine) :: this

      call this%set_defaults_and_read_settings()

      if (this%state > 0) then

         this%energy_function = cc_es_energy_function(cc_wf, &
                                                      ref_wf, &
                                                      this%state, &
                                                      trim(this%gradient_method), &
                                                      this%gradient_displacement, &
                                                      first_iteration=.false.)

      else

         this%energy_function = cc_gs_energy_function(cc_wf, &
                                                      ref_wf, &
                                                      trim(this%gradient_method), &
                                                      this%gradient_displacement, &
                                                      first_iteration=.false.)

      end if

      call this%general_preparations(cc_wf)

   end function new_harmonic_frequencies_engine_cc


   subroutine set_defaults_and_read_settings(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use global_in, only: input

      implicit none

      class(harmonic_frequencies_engine) :: this

      this%gradient_method = 'analytical'
      call input%get_keyword('gradient method', 'harmonic frequencies', this%gradient_method)

      if (trim(this%gradient_method) /= 'analytical') then

         call output%warning_msg( &
                 'Numerical Hessian based on numerical gradient may be inaccurate and highly sensitive to&
                 & thresholds. Make sure to use tight thresholds and choose gradient/Hessian displacements&
                 & with care.' &
              )

      end if

      this%hessian_displacement = 1.0d-4
      call input%get_keyword('hessian displacement', 'harmonic frequencies', this%Hessian_displacement)

      this%gradient_displacement = 1.0d-3
      call input%get_keyword('gradient displacement', 'harmonic frequencies', this%gradient_displacement)

      this%state = 0
      call input%get_keyword('state', 'harmonic frequencies', this%state)

      this%n_wigner_samples = 0
      call input%get_keyword('wigner samples', 'harmonic frequencies', this%n_wigner_samples)

      this%wigner_seed = 0
      call input%get_keyword('wigner seed', 'harmonic frequencies', this%wigner_seed)

      this%translation_rotation_threshold = ten  ! 10 cm-1

   end subroutine set_defaults_and_read_settings


   subroutine general_preparations(this, wf)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use wavefunction_class, only: wavefunction

      implicit none

      class(harmonic_frequencies_engine) :: this

      class(wavefunction) :: wf

      this%n_atoms = wf%ao%get_n_centers()

      if (this%n_atoms == 1) &
         call output%error_msg("Requested vibrational frequency calculation with a single atom.")

      if (wf%ao%is_molecule_linear()) then

         call output%printf('m', 'The molecule is detected as linear. Assuming 3N-5 modes.')
         this%n_normal_modes = 3 * this%n_atoms - 5

      else

         call output%printf('m', 'The molecule is detected as non-linear. Assuming 3N-6 modes.')
         this%n_normal_modes = 3 * this%n_atoms - 6

      end if

      allocate(this%masses(this%n_atoms))
      allocate(this%symbols(this%n_atoms))

      call wf%ao%get_center_masses(this%masses)  ! in atomic mass units
      this%masses = this%masses * au_per_amu  ! in Hartree atomic units (m_e = 1)

      call wf%ao%get_center_symbols(this%symbols)

      this%timer = timings('Harmonic vibrational frequencies', 'm')

   end subroutine general_preparations


   subroutine initialize(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      call this%energy_function%initialize()

   end subroutine initialize


   subroutine run(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use lapack_wrappers, only: diagonalize_symmetric_not_in_place

      implicit none

      class(harmonic_frequencies_engine), intent(inout) :: this

      call this%timer%turn_on()

      call output%printf('m', &
                         'Requested harmonic frequencies. Will construct molecular Hessian.', &
                         fs='(/t3,a)')

      call this%print_Hessian_settings()

      call mem%alloc(this%hessian, 3, this%n_atoms, 3, this%n_atoms)
      call mem%alloc(this%hessian_mass_weighted, 3, this%n_atoms, 3, this%n_atoms)

      call mem%alloc(this%eigenvectors, 3 * this%n_atoms, 3 * this%n_atoms)

      call mem%alloc(this%eigenvalues, 3 * this%n_atoms)
      call mem%alloc(this%frequencies, 3 * this%n_atoms)

      call mem%alloc(this%normal_modes, this%n_atoms, 3, this%n_normal_modes)

      call this%construct_unweighted_Hessian(this%hessian)

      call this%construct_mass_weighted_Hessian(this%hessian, &
                                                this%hessian_mass_weighted)

      call diagonalize_symmetric_not_in_place(dim=3 * this%n_atoms, &
                                              A=this%hessian_mass_weighted, &
                                              X=this%eigenvectors, &
                                              omega=this%eigenvalues)

      call this%sort_eigenvectors_according_to_absolute_eigenvalue(this%eigenvectors, this%eigenvalues)

      this%frequencies = this%calculate_harmonic_frequencies_cm_inverse(this%eigenvalues)

      call this%construct_normal_modes(this%eigenvectors, this%normal_modes)

      call this%animate_normal_modes_xyz(this%normal_modes)

      if (this%n_wigner_samples > 0) call this%generate_wigner_samples()

      call this%print_normal_mode_summary()

      call mem%dealloc(this%hessian)
      call mem%dealloc(this%hessian_mass_weighted)
      call mem%dealloc(this%eigenvectors)
      call mem%dealloc(this%eigenvalues)
      call mem%dealloc(this%frequencies)
      call mem%dealloc(this%normal_modes)

      call this%timer%turn_off()

   end subroutine run


   subroutine print_Hessian_settings(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      call output%printf('m', 'Electronic state:           (i0)', ints=[this%state], fs='(/t6,a)')

      if (trim(this%gradient_method) == 'analytical') then

         call output%printf('m', 'Gradient:                   analytical', fs='(/t6,a)')

      else

         call output%printf('m', &
                            'Gradient:                   (a0)', &
                            chars=[trim(this%gradient_method)], &
                            fs='(/t6,a)')

         call output%printf('m', &
                            'Displacement for gradient: (e11.4)', &
                            reals=[this%gradient_displacement], &
                            fs='(t6,a)')

      end if

      call output%printf('m', 'Hessian:                    numerical', fs='(/t6,a)')

      call output%printf('m', &
                         'Displacement for Hessian:  (e11.4) au', &
                         reals=[this%Hessian_displacement], &
                         fs='(t6,a)')

      call output%printf('m', 'Numerical method:           central difference', fs='(t6,a)')

      call output%printf('m', &
                         'Note: the atomic masses used are the most common isotopes for the specified&
                         & elements.', &
                         fs='(/t6,a)')

   end subroutine print_Hessian_settings


   subroutine construct_unweighted_Hessian(this, H)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      !! Construct H_ij = d^2 E / dx_i dx_j, where E is the electronic energy
      !! and x_i/x_j are nuclear components.
      !!
      !! Construction is based on central differences of gradients (dE / dx_i).
      !! The gradient may be evaluated numerically or analytically.
      !!
      use array_initialization, only: zero_array

      implicit none

      class(harmonic_frequencies_engine) :: this

      real(dp), dimension(3 * this%n_atoms, 3 * this%n_atoms), intent(out) :: H

      integer :: i, j

      real(dp), dimension(:), allocatable, target :: r0
      real(dp), dimension(:), allocatable :: r0_plus, r0_minus, g_plus, g_minus

      real(dp), dimension(:, :), pointer :: r0_p

      call mem%alloc(r0, 3 * this%n_atoms)

      call mem%alloc(r0_plus, 3 * this%n_atoms)
      call mem%alloc(r0_minus, 3 * this%n_atoms)

      call mem%alloc(g_plus, 3 * this%n_atoms)
      call mem%alloc(g_minus, 3 * this%n_atoms)

      r0 = this%energy_function%get_parameters()

      call zero_array(H, (3 * this%n_atoms)**2)

      do i = 1, 3 * this%n_atoms

         ! Displace and calculate gradients (for +dr and -dr)
         call dcopy(3 * this%n_atoms, r0, 1, r0_plus, 1)
         r0_plus(i) = r0_plus(i) + this%Hessian_displacement
         call this%energy_function%set_parameters(r0_plus)

         g_plus = this%energy_function%get_gradient()

         call dcopy(3 * this%n_atoms, r0, 1, r0_minus, 1)
         r0_minus(i) = r0_minus(i) - this%Hessian_displacement
         call this%energy_function%set_parameters(r0_minus)

         g_minus = this%energy_function%get_gradient()

         ! Use gradient at +dr and -dr to construct ith row of Hessian
         do j = 1, 3 * this%n_atoms

            H(i, j) = (g_plus(j) - g_minus(j)) / (two * this%Hessian_displacement)

         end do

      end do

      ! Extract reordered r0 for later

      ! The ordering according to the energy function is q,atom and not atom,q
      ! We want the latter for printing geometries, so convenient to reorder
      r0_p(1:3, 1:this%n_atoms) => r0

      allocate(this%r0(this%n_atoms, 3))
      this%r0 = transpose(r0_p)

      call mem%dealloc(r0)
      call mem%dealloc(r0_plus)
      call mem%dealloc(r0_minus)

      call mem%dealloc(g_plus)
      call mem%dealloc(g_minus)

   end subroutine construct_unweighted_Hessian


   subroutine construct_mass_weighted_Hessian(this, H, H_mass_weighted)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use array_initialization, only: zero_array

      implicit none

      class(harmonic_frequencies_engine) :: this

      real(dp), dimension(3, this%n_atoms, 3, this%n_atoms), intent(in) :: H
      real(dp), dimension(3, this%n_atoms, 3, this%n_atoms), intent(out) :: H_mass_weighted

      integer :: k, q, l, r

      call zero_array(H_mass_weighted, (3 * this%n_atoms)**2)

      !$omp parallel do private(l,r,k,q)
      do l = 1, this%n_atoms
         do r = 1, 3
            do k = 1, this%n_atoms
               do q = 1, 3

                  H_mass_weighted(q, k, r, l) = H(q, k, r, l) / sqrt(this%masses(k) * this%masses(l))

               end do
            end do
         end do
      end do
      !$omp end parallel do

   end subroutine construct_mass_weighted_Hessian


   subroutine sort_eigenvectors_according_to_absolute_eigenvalue(this, eigenvectors, eigenvalues)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      !! Sorts eigenvectors and eigenvalues of Hessian in descending order according to
      !! absolute value of frequency. This places the 3N-6 modes/internal coordinates
      !! as the first 3N-6 elements in the eigenvectors and eigenvalues arrays.
      !!
      !! Eigenvectors corresponding to translations and rotations have eigenvalues close
      !! zero at stationary points on the potential energy surface. These come after
      !! the vectors associated with internal vibrational motion.
      !!
      use array_utilities, only: quicksort_with_index_descending

      implicit none

      class(harmonic_frequencies_engine) :: this

      real(dp), dimension(3 * this%n_atoms, 3 * this%n_atoms), intent(inout) :: eigenvectors
      real(dp), dimension(3 * this%n_atoms), intent(inout) :: eigenvalues

      real(dp), dimension(:, :), allocatable :: unordered_eigenvectors
      real(dp), dimension(:), allocatable :: unordered_eigenvalues
      real(dp), dimension(:), allocatable :: unordered_abs_eigenvalues

      integer, dimension(:), allocatable :: new_indices

      integer :: k

      call mem%alloc(unordered_abs_eigenvalues, 3 * this%n_atoms)
      unordered_abs_eigenvalues = abs(eigenvalues)

      call mem%alloc(new_indices, 3 * this%n_atoms)
      call quicksort_with_index_descending(unordered_abs_eigenvalues, new_indices, 3 * this%n_atoms)

      call mem%dealloc(unordered_abs_eigenvalues)

      call mem%alloc(unordered_eigenvalues, 3 * this%n_atoms)
      call mem%alloc(unordered_eigenvectors, 3 * this%n_atoms, 3 * this%n_atoms)

      call dcopy(3 * this%n_atoms, eigenvalues, 1, unordered_eigenvalues, 1)
      call dcopy((3 * this%n_atoms)**2, eigenvectors, 1, unordered_eigenvectors, 1)

      !$omp parallel do private(k)
      do k = 1, 3 * this%n_atoms

         eigenvalues(k) = unordered_eigenvalues(new_indices(k))
         eigenvectors(:, k) = unordered_eigenvectors(:, new_indices(k))

      end do
      !$omp end parallel do

      call mem%dealloc(new_indices)

      call mem%dealloc(unordered_eigenvalues)
      call mem%dealloc(unordered_eigenvectors)

   end subroutine sort_eigenvectors_according_to_absolute_eigenvalue


   function calculate_harmonic_frequencies_cm_inverse(this, eigenvalues) result(frequencies)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      !! eigenvalues: Eigenvalues of the mass-weighted Hessian in units Hartree/(bohr^2 * amu)
      !! frequencies: Frequencies in units of cm-1
      !!
      use parameters

      implicit none

      class(harmonic_frequencies_engine) :: this

      real(dp), dimension(3 * this%n_atoms), intent(in) :: eigenvalues
      complex(dp), dimension(3 * this%n_atoms) :: frequencies

      integer :: i

      !$omp parallel do private(i)
      do i = 1, 3 * this%n_atoms

         ! extract frequency^2 and convert it to s^(-2)
         frequencies(i) = eigenvalues(i)
         frequencies(i) = frequencies(i) * (J_per_Hartree / (kg_per_amu / au_per_amu * m_per_bohr**2))

         ! s^(-1)
         frequencies(i) = sqrt(frequencies(i))

         ! convert to angular frequency in m^(-1)
         frequencies(i) = frequencies(i) / (two * pi * speed_of_light)

         ! convert to cm^(-1)
         frequencies(i) = frequencies(i) / cm_per_m

      end do
      !$omp end parallel do

   end function calculate_harmonic_frequencies_cm_inverse


   subroutine construct_normal_modes(this, eigenvectors, normal_modes)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!

      implicit none

      class(harmonic_frequencies_engine) :: this

      real(dp), dimension(3 * this%n_atoms, 3 * this%n_atoms), intent(in), target :: eigenvectors

      real(dp), dimension(this%n_atoms, 3, this%n_normal_modes), intent(out) :: normal_modes

      integer :: mode_, k, r

      real(dp), dimension(:, :, :), pointer :: eigenvectors_p

      eigenvectors_p(1:3, 1:this%n_atoms, 1:3 * this%n_atoms) => eigenvectors

      !$omp parallel do private(mode_, k, r)
      do mode_ = 1, this%n_normal_modes

         ! Copy eigenvector and reorder (component, center) -> (center, component)
         normal_modes(:, :, mode_) = transpose(eigenvectors_p(:, :, mode_))

         ! Mode is in mass-weighted coordinates; remove mass-weight and normalize mode
         do k = 1, this%n_atoms
            do r = 1, 3

               normal_modes(k, r, mode_) = normal_modes(k, r, mode_) / sqrt(this%masses(k))

            end do
         end do

         ! Enforce sign convention: sum of mode values should be positive
         if (sum(normal_modes(:, :, mode_)) < 0) normal_modes(:, :, mode_) = - normal_modes(:, :, mode_)

      end do
      !$omp end parallel do

   end subroutine construct_normal_modes


   subroutine animate_normal_modes_xyz(this, normal_modes)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      real(dp), dimension(this%n_atoms, 3, this%n_normal_modes), intent(in) :: normal_modes

      integer :: mode_

      call output%printf('m', '- Animating normal modes (as xyz)', fs='(/t3,a/)')

      do mode_ = 1, this%n_normal_modes

         call this%animate_normal_mode_xyz(normal_modes(:, :, mode_), mode_)

      end do

   end subroutine animate_normal_modes_xyz


   subroutine print_normal_mode_summary(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      call this%print_frequencies()
      call this%print_normal_mode_coordinates()
      call this%print_frequency_analysis()

   end subroutine print_normal_mode_summary


   subroutine print_frequencies(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      integer :: i

      call output%printf('m', '- Harmonic frequencies (cm-1)', fs='(/t3,a/)')

      do i = 1, 3 * this%n_atoms

         call output%printf('m', &
                            '(i3) (c19.12)', &
                            fs='(t6,a)', &
                            ints=[i], &
                            complexs=[this%frequencies(i)])

      end do

   end subroutine print_frequencies


   subroutine print_normal_mode_coordinates(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(harmonic_frequencies_engine) :: this

      integer :: mode_, atom

      real(dp), dimension(:, :), allocatable :: Q

      call output%printf('m', '- Normal modes', fs='(/t3,a/)')

      call output%printf('m', &
                         'Note: this prints the modes associated with the 3N - 6  largest frequencies (3N - 5&
                         & for diatomic systems).', &
                         fs='(t6,a)')

      call mem%alloc(Q, this%n_atoms, 3)

      do mode_ = 1, this%n_normal_modes

         call output%printf('m', 'Mode: (i0)', ints=[mode_], fs='(/t6,a)')

         call output%printf('m', &
                            'Frequency (cm-1): (c17.12)', &
                            complexs=[this%frequencies(mode_)], &
                            fs='(t6,a/)')

         call output%printf('m', 'Normal mode geometry:', fs='(t6,a/)')

         Q = this%normal_modes(:, :, mode_)
         Q = Q / get_l2_norm(Q, 3 * this%n_atoms)

         do atom = 1, this%n_atoms

            call output%printf('m', &
                               '(b2)3(f19.12)', &
                               chars=[this%symbols(atom)], &
                               reals=[Q(atom, :)], &
                               fs='(t6,a)')

         end do

      end do

      call mem%dealloc(Q)

   end subroutine print_normal_mode_coordinates


   subroutine print_frequency_analysis(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      logical :: stationary

      call output%printf('m', '- Frequency analysis', fs='(/t3,a/)')

      stationary = this%is_geometry_stationary(frequencies=this%frequencies, &
                                               threshold=this%translation_rotation_threshold)

      if (stationary) then

         call output%printf('m', 'Geometry is stationary!', fs='(t6,a/)')

         call this%classify_stationary_point(frequencies=this%frequencies)

      end if

   end subroutine print_frequency_analysis


   function is_geometry_stationary(this, frequencies, threshold) result(stationary)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      !! Checks whether geometry is stationary. Frequencies are in cm-1
      !! and the threshold is also in cm-1.
      !!
      !! It is assumed that the translation/rotation frequencies are the last elements
      !! of the frequency array (the elements that follow after the first 3N-6).
      !!
      !! If a translational or rotational mode has frequency > threshold, the geometry
      !! is not stationary. This indicates a noisy Hessian or evaluation at a non-stationary
      !! point on the potential energy surface.
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      complex(dp), dimension(3 * this%n_atoms), intent(in) :: frequencies
      real(dp), intent(in) :: threshold

      integer :: i

      logical :: stationary

      stationary = .true.

      do i = this%n_normal_modes + 1, 3 * this%n_atoms

         if (abs(frequencies(i)) > threshold) then

            stationary = .false.

            call output%warning_msg( &
                    'Frequency (i0) is large (> (e11.4)) but is not associated with internal vibrational&
                    & modes. Geometry is not stationary! Harmonic frequncies/modes may be inaccurate or&
                    & incorrect. Please check whether the geometry is stationary (gradient is zero) or try to&
                    & tighten thresholds for optimization and/or Hessian calculation.', &
                    ints=[i], &
                    reals=[threshold] &
                 )

         end if

      end do

   end function is_geometry_stationary


   subroutine classify_stationary_point(this, frequencies)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      !! Decides if and prints whether the point is a minimum, a saddle point, transition state
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      complex(dp), dimension(3 * this%n_atoms), intent(in) :: frequencies

      integer :: n_imaginary_frequencies, mode_

      n_imaginary_frequencies = 0

      do mode_ = 1, this%n_normal_modes

         if (abs(frequencies(mode_)%im) > abs(frequencies(mode_)%re)) then

            n_imaginary_frequencies = n_imaginary_frequencies + 1

            call output%printf('m', &
                               'Detected imaginary frequency! Mode (i0) lowers the energy.', &
                               ints=[mode_], &
                               fs='(t6,a/)')

         end if

      end do


      if (n_imaginary_frequencies == 0) then

         call output%printf('m', &
                            'All frequencies are real. Reference/optimized geometry is a minimum on the&
                            & potential energy surface.', &
                            fs='(t6,a)')

      else

         if (n_imaginary_frequencies == 1) then

            call output%printf('m', &
                               'One frequency is imaginary. Reference/optimized geometry is a transition&
                               & state on the potential energy surface.', &
                               fs='(t6,a)')

         else

            call output%printf('m', &
                               'Two or more frequencies are imaginary. Reference/optimized geometry is a&
                               & saddle point on the potential energy surface. Order: (i0)', &
                               ints=[n_imaginary_frequencies], &
                               fs='(t6,a)')

         end if

      end if

   end subroutine classify_stationary_point


   subroutine animate_normal_mode_xyz(this, Q, mode_)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use parameters
      use array_utilities, only: get_l2_norm

      implicit none

      class(harmonic_frequencies_engine), intent(in) :: this

      real(dp), dimension(this%n_atoms, 3), intent(in) :: Q

      integer, intent(in) :: mode_

      real(dp), dimension(:, :), allocatable :: r

      integer :: snapshot

      integer, parameter :: n_snapshots = 20
      real(dp), parameter :: dTheta = two * pi / real(n_snapshots)
      real(dp), parameter :: amplitude = half

      real(dp) :: Theta

      class(output_file), allocatable :: mode_file
      character(len=200) :: mode_filename

      integer :: atom

      write(mode_filename, '(a15,i0,a4)')'animation_mode_', mode_, '.xyz'
      mode_file = output_file(trim(mode_filename))

      call output%printf('m', &
                         'Creating animation for normal mode (i0) in file (a0)', &
                         ints=[mode_], &
                         chars=[trim(mode_filename)], &
                         fs='(t6,a)')

      call mode_file%open_()

      call mem%alloc(r, this%n_atoms, 3)

      do snapshot = 1, n_snapshots

         Theta = dTheta * real(snapshot - 1, kind=dp)

         r = this%r0 + amplitude * sin(Theta) * (Q / get_l2_norm(Q, 3 * this%n_atoms))

         r = r * bohr_to_angstrom

         call mode_file%printf('m', '(i0)', ints=[this%n_atoms], fs='(t1,a/)')

         do atom = 1, this%n_atoms

            call mode_file%printf('m', &
                                  '(b2)3(f19.12)', &
                                  chars=[trim(this%symbols(atom))], &
                                  reals=[r(atom, :)], &
                                  fs='(t6,a)')

         end do

      end do

      call mem%dealloc(r)

      call mode_file%close_()

   end subroutine animate_normal_mode_xyz


   subroutine generate_wigner_samples(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      integer :: sample

      real(dp), dimension(:, :), allocatable :: r, p

      real(dp) :: average_potential_energy, average_kinetic_energy

      real(dp) :: sample_potential_energy, sample_kinetic_energy

      call output%printf('m', '- Wigner sampling (0 K, harmonic)', fs='(/t3,a)')

      call output%printf('m', 'Will generate (i0) Wigner samples', ints=[this%n_wigner_samples], fs='(/t6,a)')

      call this%initialize_random_number_generator()

      call mem%alloc(r, this%n_atoms, 3)
      call mem%alloc(p, this%n_atoms, 3)

      average_potential_energy = zero
      average_kinetic_energy = zero

      do sample = 1, this%n_wigner_samples

         call output%printf('m', 'Wigner sample (i0)', ints=[sample], fs='(/t6,a)')

         call this%generate_wigner_sample(r, p, sample_kinetic_energy, sample_potential_energy)

         call output%printf('m', &
                            'Sample potential energy: (e11.4)', &
                            reals=[sample_potential_energy], &
                            fs='(/t9,a)')

         call output%printf('m', &
                            'Sample kinetic energy:   (e11.4)', &
                            reals=[sample_kinetic_energy], &
                            fs='(t9,a)')

         average_kinetic_energy = average_kinetic_energy + sample_kinetic_energy / real(this%n_wigner_samples)

         average_potential_energy = &
                                    average_potential_energy &
                                    + sample_potential_energy / real(this%n_wigner_samples)

         call this%print_wigner_sample(r, p)
         call this%save_wigner_sample_to_fms90_file(r, p, sample)

      end do

      call mem%dealloc(r)
      call mem%dealloc(p)

      call output%printf('m', 'Finished Wigner sampling!', fs='(/t6,a)')

      call this%print_wigner_summary(average_kinetic_energy, average_potential_energy)

   end subroutine generate_wigner_samples


   subroutine initialize_random_number_generator(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      !! Sets the seed used by random-number generation with RANDOM_NUMBER.
      !! This makes sure that we get reproducible Wigner samples.
      !!
      !! Note: same seed gives different random numbers if compiled with --int32
      !! and --int64. We can only reproduce samples when compiled with same integer type.
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      ! Standard seed
      integer, dimension(8) :: seed = &
         [8795314, 220209753, 214585011, 199164205, 247109094, 31112782, 2429038, 218093973]

      ! User may specify a seed integer => we shift default seed array elements by this number
      seed = seed + this%wigner_seed

      ! Initializes Fortran random generator to use our seed
      call random_seed(put=seed)

   end subroutine initialize_random_number_generator


   subroutine generate_wigner_sample(this, r, p, sample_kinetic_energy, sample_potential_energy)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      use math_utilities, only: random_x_from_normal_distribution

      implicit none

      class(harmonic_frequencies_engine) :: this

      real(dp), dimension(this%n_atoms, 3), intent(out) :: r
      real(dp), dimension(this%n_atoms, 3), intent(out) :: p

      real(dp), intent(out) :: sample_kinetic_energy
      real(dp), intent(out) :: sample_potential_energy

      integer :: mode_, atom, q

      real(dp) :: frequency, r_sample, p_sample, sigma_r, sigma_p

      r = this%r0
      p = zero

      sample_potential_energy = zero
      sample_kinetic_energy = zero

      do mode_ = 1, this%n_normal_modes

         ! Extract frequency and convert to Hartree
         frequency = this%frequencies(mode_)%re / cm_inv_per_Hartree

         ! Compute standard deviations (position, momentum)
         sigma_r = sqrt(one / (two * frequency))
         sigma_p = sqrt(frequency / two)

         ! Random sample normal distribution with standard deviations
         r_sample = random_x_from_normal_distribution(mu=zero, sigma=sigma_r)
         p_sample = random_x_from_normal_distribution(mu=zero, sigma=sigma_p)

         r = r + r_sample * this%normal_modes(:, :, mode_)
         p = p + p_sample * this%normal_modes(:, :, mode_)  ! wait with mass-scaling
         ! of the momenta until after mode sum

         sample_potential_energy = sample_potential_energy + half * r_sample**2 * frequency**2
         sample_kinetic_energy = sample_kinetic_energy + half * p_sample**2

      end do

      ! Mass-scale momenta
      do atom = 1, this%n_atoms
         do q = 1, 3

            p(atom, q) = p(atom, q) * this%masses(atom)

         end do
      end do

   end subroutine generate_wigner_sample


   subroutine save_wigner_sample_to_fms90_file(this, r, p, sample)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      !! Writes the initial condition (r, p) in the format expected by the FMS90
      !! dynamics program (in FMS90, the filename is Geometry.dat)
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      real(dp), dimension(this%n_atoms, 3), intent(in) :: r
      real(dp), dimension(this%n_atoms, 3), intent(in) :: p

      integer, intent(in) :: sample

      class(output_file), allocatable :: wigner_file
      character(len=200) :: wigner_filename

      integer :: atom

      write(wigner_filename, '(a14,i0,a4)')'wigner_sample_', sample, '.dat'
      wigner_file = output_file(trim(wigner_filename))

      call wigner_file%open_()

      call wigner_file%printf('m', 'UNITS=BOHR', fs='(t1,a)')
      call wigner_file%printf('m', '(i0)', ints=[this%n_atoms], fs='(t1,a)')

      do atom = 1, this%n_atoms

         call wigner_file%printf('m', &
                                 '(b2)3(f19.12)', &
                                 chars=[trim(this%symbols(atom))], &
                                 reals=[r(atom, :)], &
                                 fs='(t1,a)')

      end do

      call wigner_file%printf('m', '# momenta', fs='(t1,a)')

      do atom = 1, this%n_atoms

         call wigner_file%printf('m', &
                                 '(f19.12) (f19.12) (f19.12)', &
                                 reals=[p(atom, :)], &
                                 fs='(t1,a)')

      end do

      call wigner_file%close_()
      deallocate(wigner_file)

   end subroutine save_wigner_sample_to_fms90_file


   subroutine print_wigner_sample(this, r, p)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      real(dp), dimension(this%n_atoms, 3), intent(in) :: r
      real(dp), dimension(this%n_atoms, 3), intent(in) :: p

      integer :: atom

      call output%printf('m', 'Positions (atomic units)', fs='(/t9,a/)')

      do atom = 1, this%n_atoms

         call output%printf('m', &
                            '(b2)3(f19.12)', &
                            chars=[trim(this%symbols(atom))], &
                            reals=[r(atom, :)], &
                            fs='(t9,a)')

      end do

      call output%printf('m', 'Momenta (atomic units)', fs='(/t9,a/)')

      do atom = 1, this%n_atoms

         call output%printf('m', &
                            '(b2)3(f19.12)', &
                            chars=[trim(this%symbols(atom))], &
                            reals=[p(atom, :)], &
                            fs='(t9,a)')

      end do

   end subroutine print_wigner_sample


   subroutine print_wigner_summary(this, average_kinetic_energy, average_potential_energy)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(harmonic_frequencies_engine) :: this

      real(dp), intent(in) :: average_kinetic_energy, average_potential_energy

      real(dp) :: average_energy, zero_point_vibrational_energy

      average_energy = average_kinetic_energy + average_potential_energy
      zero_point_vibrational_energy = half * sum(this%frequencies%re) / cm_inv_per_Hartree

      call output%printf('m', &
                         'Zero-point vibrational energy: (e11.4)', &
                         reals=[zero_point_vibrational_energy], &
                         fs='(/t9,a)')

      call output%printf('m', &
                         'Average potential energy:      (e11.4)', &
                         reals=[average_potential_energy], &
                         fs='(t9,a)')

      call output%printf('m', &
                         'Average kinetic energy:        (e11.4)', &
                         reals=[average_kinetic_energy], &
                         fs='(t9,a)')

      call output%printf('m', &
                         'Deviation from virial theorem: (e11.4)', &
                         reals=[average_kinetic_energy - average_potential_energy], &
                         fs='(/t9,a)')

      call output%printf('m', &
                         'Deviation from energy expectation value: (e11.4)', &
                         reals=[abs(average_energy - zero_point_vibrational_energy)], &
                         fs='(t9,a)')

   end subroutine print_wigner_summary


end module harmonic_frequencies_engine_class

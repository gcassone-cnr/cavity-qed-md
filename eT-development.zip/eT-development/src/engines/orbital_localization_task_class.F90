

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module orbital_localization_task_class

   !!
   !! Orbital_localization task class
   !! Written by Sarai D. Folkestad and Regina Matveeva, 2022-2023
   !!

   use parameters
   use abstract_task_class, only: abstract_task
   use timings_class, only: timings
   use wavefunction_class, only: wavefunction
   use eri_cholesky_disk_class, only: eri_cholesky_disk

   implicit none

   type, extends(abstract_task) :: orbital_localization_task

      character(len=200), private :: orbital_localization_type
      character(len=200), private :: print_to

      class(eri_cholesky_disk), allocatable, private :: L_o, L_v

      logical, private :: occupied = .false.
      logical, private :: virtual = .false.
      real(dp) :: threshold

   contains

      procedure, public :: execute => execute_orbital_localization_task

      procedure, public :: print_header

      procedure, public :: start_timer
      procedure, public :: end_timer

      procedure, private :: read_settings

      procedure, private, nopass :: write_orbital_analysis_to_file
      procedure, private :: integral_preparations
      procedure, private :: initialize_orbital_localization_tool
      procedure, private :: do_orbital_localization
      procedure, private :: create_solver
      procedure, private, nopass :: order_localized_orbitals_by_center

   end type orbital_localization_task


   interface orbital_localization_task

      procedure :: new_orbital_localization_task

   end interface orbital_localization_task


contains


   function new_orbital_localization_task() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2022
      !!
      implicit none

      type(orbital_localization_task) :: this

      this%name_ = 'Orbital localization'

      this%occupied = .false.
      this%virtual = .false.

   end function new_orbital_localization_task


   subroutine execute_orbital_localization_task(this, wf)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, 2021-2023
      !!

      use citation_printer_class, only: eT_citations

      implicit none

      class(orbital_localization_task), intent(inout) :: this
      class(wavefunction), intent(inout), target :: wf

      call eT_citations%add("Edmiston-Ruedenberg and Foster-Boys orbitals")

      call this%print_header()
      call this%start_timer()

      call this%read_settings()
      call this%integral_preparations(wf)

      if (this%occupied) then

         call this%do_orbital_localization(wf, &
                                           wf%orbital_coefficients(:, 1:wf%n_o), &
                                           wf%n_o, &
                                           current_type='occupied')

         call this%order_localized_orbitals_by_center(wf%n_o, wf%orbital_coefficients(:, 1:wf%n_o), wf%ao)

      end if

      if (this%virtual) then

         call this%do_orbital_localization(wf, &
                                           wf%orbital_coefficients(:, wf%n_o + 1:wf%n_mo), &
                                           wf%n_v, &
                                           current_type='virtual')

         call this%order_localized_orbitals_by_center(wf%n_v, &
                                                      wf%orbital_coefficients(:, wf%n_o + 1:wf%n_mo), &
                                                      wf%ao)

      end if

   end subroutine execute_orbital_localization_task


   subroutine write_orbital_analysis_to_file(current_type, n, spread_)
      !!
      !! Written by Regina Matveeva and Sarai D. Folkestad, 2021-2023
      !!
      use output_file_class, only: output_file

      implicit none

      real(dp), dimension(:), intent(inout) :: spread_
      integer, intent(in) :: n
      character(len=*), intent(in) :: current_type

      integer :: i

      type(output_file), allocatable :: spread_file

      spread_file = output_file('eT.' // current_type // '_orbital_spread_info')
      call spread_file%open_()

      call spread_file%printf('n', 'orbital number       spread [a.u.]', fs='(/t6, a)')

      do i = 1, n

         call spread_file%printf('n', '(i0)   (f15.5)', ints=[i], reals=[spread_(i)])

      end do

      call spread_file%close_()

   end subroutine write_orbital_analysis_to_file


   subroutine order_localized_orbitals_by_center(n_orbitals, coefficients, ao)
      !!
      !! Written by Sarai D. Folkestad, 2021-2022
      !!
      use memory_manager_class, only: mem

      use ao_tool_class, only: ao_tool
      use array_utilities, only: symmetric_sandwich

      implicit none

      class(ao_tool), intent(inout) :: ao
      integer, intent(in) :: n_orbitals
      real(dp), dimension(ao%n, n_orbitals), intent(inout) :: coefficients

      real(dp), dimension(:, :, :), allocatable :: d_ao, d_mo
      real(dp), dimension(:, :), allocatable :: coefficients_copy, distances, R_qk
      integer, dimension(:), allocatable :: center_for_orbital

      integer :: counter, i, j, k, center

      ! Compute average position of orbitals

      call mem%alloc(d_ao, ao%n, ao%n, 3)
      call mem%alloc(d_mo, n_orbitals, n_orbitals, 3)

      call ao%get_oei('dipole', d_ao)

      do k = 1, 3

         call symmetric_sandwich(d_mo(:, :, k), &
                                 d_ao(:, :, k), &
                                 coefficients, &
                                 ao%n, &
                                 n_orbitals)

      end do

      call mem%alloc(R_qk, 3, ao%get_n_centers())
      R_qk = ao%get_center_coordinates()

      call mem%alloc(distances, ao%get_n_centers(), n_orbitals, set_zero=.true.)

      do i = 1, n_orbitals

         ! dipole integrals have -1 compared to cartesian moments
         ! therefore add rather than subract to get difference
         do center = 1, ao%get_n_centers()


            do k = 1, 3

               distances(center, i) = distances(center, i) &
                                      + (d_mo(i, i, k) + R_qk(k, center) * angstrom_to_bohr)**2

            end do

            distances(center, i) = sqrt(distances(center, i))

         end do
      end do

      call mem%dealloc(d_ao)
      call mem%dealloc(d_mo)
      call mem%dealloc(R_qk)

      ! Assign orbitals to center

      call mem%alloc(center_for_orbital, n_orbitals)

      do i = 1, n_orbitals

         center_for_orbital(i) = minloc(distances(:, i), 1)

      end do

      call mem%dealloc(distances)

      call mem%alloc(coefficients_copy, ao%n, n_orbitals)
      call dcopy(ao%n * n_orbitals, coefficients, 1, coefficients_copy, 1)

      counter = 0

      do i = 1, ao%get_n_centers()
         do j = 1, n_orbitals

            if (center_for_orbital(j) == i) then

               counter = counter + 1
               coefficients(:, counter) = coefficients_copy(:, j)

            end if

         end do
      end do

      call mem%dealloc(center_for_orbital)
      call mem%dealloc(coefficients_copy)

   end subroutine order_localized_orbitals_by_center


   subroutine integral_preparations(this, wf)
      !!
      !! Written by Regina Matveeva and Sarai D. Folkestad, 2022-2023
      !!
      use eri_cholesky_disk_class, only: eri_cholesky_disk
      use eri_cd_class, only: eri_cd

      implicit none

      class(orbital_localization_task), intent(inout) :: this
      class(wavefunction) :: wf

      type(eri_cd), allocatable :: eri_cholesky_solver

      if (this%orbital_localization_type /= 'edmiston-ruedenberg') return

      eri_cholesky_solver = eri_cd(wf%ao, wf%ao_eri)
      call eri_cholesky_solver%run(wf%ao)

      if (this%occupied) then

         this%L_o = eri_cholesky_disk('ER_cholesky_o')
         call this%L_o%initialize(eri_cholesky_solver%get_n_cholesky(), 1, [wf%n_o])

         call eri_cholesky_solver%construct_cholesky_mo_vectors(wf%ao, &
                                                                wf%ao%n, &
                                                                wf%n_o, &
                                                                wf%orbital_coefficients(:, 1:wf%n_o), &
                                                                this%L_o)

      end if

      if (this%virtual) then

         this%L_v = eri_cholesky_disk('ER_cholesky_v')
         call this%L_v%initialize(eri_cholesky_solver%get_n_cholesky(), 1, [wf%n_v])

         call eri_cholesky_solver%construct_cholesky_mo_vectors(wf%ao, &
                                                                wf%ao%n, &
                                                                wf%n_v, &
                                                                wf%orbital_coefficients(:, &
                                                                   wf%n_o + 1:wf%n_mo), &
                                                                this%L_v)

      end if


   end subroutine integral_preparations


   subroutine initialize_orbital_localization_tool(this, &
                                                   wf, &
                                                   current_type, &
                                                   orbitals, &
                                                   orbital_localization_tool)
      !!
      !! Written by Regina Matveeva and Sarai D. Folkestad, 2022-2023
      !!

      use abstract_orbital_localization_class, only: abstract_orbital_localization
      use edmiston_ruedenberg_class, only: edmiston_ruedenberg
      use foster_boys_class, only: foster_boys
      use orbital_rotation_class, only: orbital_rotation

      implicit none

      class(orbital_localization_task), intent(inout) :: this
      class(wavefunction), intent(inout) :: wf
      class(abstract_orbital_localization), allocatable, intent(inout) :: orbital_localization_tool
      type(orbital_rotation), intent(in) :: orbitals

      character(len=*), intent(in) :: current_type

      if (this%orbital_localization_type == 'edmiston-ruedenberg') then

         if (current_type == 'occupied') then

            orbital_localization_tool = edmiston_ruedenberg(this%L_o, orbitals)

         else if (current_type == 'virtual') then

            orbital_localization_tool = edmiston_ruedenberg(this%L_v, orbitals)

         end if

      else if (this%orbital_localization_type == 'foster-boys') then

         orbital_localization_tool = foster_boys(wf%ao, orbitals)

      end if

      call orbital_localization_tool%initialize()

   end subroutine initialize_orbital_localization_tool


   subroutine do_orbital_localization(this, wf, C, n, current_type)
      !!
      !! Written by Regina Matveeva and Sarai D. Folkestad, 2022-2023
      !!
      !!
      use global_out, only: output
      use timings_class, only: timings
      use orbital_rotation_class, only: orbital_rotation

      use memory_manager_class, only: mem

      use abstract_orbital_localization_class, only: abstract_orbital_localization

      use orbital_rotation_class, only: orbital_rotation
      use abstract_solver_class, only: abstract_solver


      implicit none

      class(orbital_localization_task), intent(inout) :: this
      class(wavefunction) :: wf

      integer, intent(in) :: n

      real(dp), dimension(wf%ao%n, n), intent(inout) :: C
      character(len=*), intent(in) :: current_type

      class(abstract_solver), allocatable :: solver
      class(abstract_orbital_localization), allocatable :: orbital_localization_tool

      real(dp), dimension(:), allocatable :: spread_initial, spread_final

      type(timings) :: timer

      type(orbital_rotation), allocatable :: orbitals

      timer = timings(current_type // ' orbital localization', pl='m')
      call timer%turn_on()

      orbitals = orbital_rotation(n, wf%ao%n)
      call orbitals%initialize(C)

      call mem%alloc(spread_initial, n)
      call mem%alloc(spread_final, n)

      call wf%get_orbital_spread(C, spread_initial, n)

      call this%initialize_orbital_localization_tool(wf, &
                                                     current_type, &
                                                     orbitals, &
                                                     orbital_localization_tool)

      call this%create_solver(orbital_localization_tool, solver)

      call solver%run()

      call orbitals%get_orbitals(C)
      call orbitals%cleanup()

      call wf%get_orbital_spread(C, spread_final, n)
      call this%write_orbital_analysis_to_file(current_type, n, spread_final)

      call output%printf('m', '- Summary of orbital localization procedure:', fs='(/t3, a)')
      call output%print_separator('m', 50, '-', fs='(t3, a)')

      call output%printf('m', &
                         'Localization type:    (a0)', &
                         chars=[this%orbital_localization_type], &
                         fs='(t6, a)')

      call output%printf('m', 'Orbitals:             (a0)', chars=[current_type], fs='(t6, a)')
      call output%printf('m', 'Initial max spread: (e12.4)', reals=[maxval(spread_initial)], fs='(t6, a)')
      call output%printf('m', 'Final max spread:   (e12.4)', reals=[maxval(spread_final)], fs='(t6, a)')
      call output%print_separator('m', 50, '-', fs='(t3, a)')

      call mem%dealloc(spread_initial)
      call mem%dealloc(spread_final)

      call timer%turn_off()

   end subroutine do_orbital_localization


   subroutine start_timer(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2022
      !!
      implicit none

      class(orbital_localization_task) :: this

      this%timer = timings(this%name_, pl='m')
      call this%timer%turn_on()

   end subroutine start_timer


   subroutine end_timer(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2022
      !!
      implicit none

      class(orbital_localization_task) :: this

      call this%timer%turn_off()

   end subroutine end_timer


   subroutine print_header(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2022
      !!
      implicit none

      class(orbital_localization_task) :: this

      call this%banner%print_(this%name_)

   end subroutine print_header


   subroutine read_settings(this)
      !!
      !! Written by Regina Matveeva, Dec 2022
      !!
      use global_in, only: input
      use global_out, only: output

      implicit none

      class(orbital_localization_task), intent(inout) :: this
      character(len=200) :: orbital_type

      this%orbital_localization_type = ''

      call input%get_keyword('type', 'orbital localization', this%orbital_localization_type)

      if (.not. (trim(this%orbital_localization_type) == 'edmiston-ruedenberg' .or. &
          trim(this%orbital_localization_type) == 'foster-boys')) then

         call output%error_msg('did not recognize the orbital localization type')

      end if

      call input%get_keyword('orbitals', 'orbital localization', orbital_type)

      if (trim(orbital_type) == 'occupied') then

         this%occupied = .true.

      else if (trim(orbital_type) == 'virtual') then

         this%virtual = .true.

      else if (trim(orbital_type) == 'both') then

         this%occupied = .true.
         this%virtual = .true.

      else

         call output%error_msg('did not recognize the orbital localization type')

      end if

      this%threshold = 1.0d-6
      call input%get_keyword('threshold', 'orbital localization', this%threshold)

   end subroutine read_settings


   subroutine create_solver(this, orbital_localization_tool, solver)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Dec 2022
      !!

      use abstract_orbital_localization_class, only: abstract_orbital_localization
      use orbital_localization_energy_getter_class, only: orbital_localization_energy_getter
      use orbital_localization_gradient_getter_class, only: orbital_localization_gradient_getter
      use orbital_localization_hessian_transformation_class, only: orbital_localization_hessian_transformation
      use orbital_localization_preconditioner_getter_class, only: orbital_localization_preconditioner_getter
      use orbital_rotation_parameters_tool_class, only: orbital_rotation_parameters_tool

      use convergence_tool_class, only: convergence_tool
      use null_projection_tool_class, only: null_projection_tool
      use trust_region_solver_class, only: trust_region_solver
      use trust_region_print_tool_class, only: trust_region_print_tool
      use abstract_solver_class, only: abstract_solver


      implicit none


      class(orbital_localization_task), intent(in) :: this
      class(abstract_orbital_localization), intent(in) :: orbital_localization_tool
      class(abstract_solver), allocatable, intent(out) :: solver

      class(convergence_tool), allocatable :: convergence_checker

      class(orbital_localization_energy_getter), allocatable :: energy_getter
      class(orbital_localization_gradient_getter), allocatable :: gradient_getter
      class(orbital_localization_hessian_transformation), allocatable :: transformer
      class(orbital_localization_preconditioner_getter), allocatable :: preconditioner_getter
      class(orbital_rotation_parameters_tool), allocatable :: parameters
      class(trust_region_print_tool), allocatable :: printer
      class(null_projection_tool), allocatable :: projector

      integer, parameter :: max_iterations = 200
      integer :: n_parameters

      n_parameters = orbital_localization_tool%packed_gradient_dimension

      parameters = orbital_rotation_parameters_tool(orbital_localization_tool)
      gradient_getter = orbital_localization_gradient_getter(orbital_localization_tool)
      energy_getter = orbital_localization_energy_getter(orbital_localization_tool)
      transformer = orbital_localization_hessian_transformation(orbital_localization_tool)
      preconditioner_getter = orbital_localization_preconditioner_getter(orbital_localization_tool)
      printer = trust_region_print_tool(max_iterations)
      projector = null_projection_tool(n_parameters)

      convergence_checker = convergence_tool(this%threshold, this%threshold, energy_convergence=.false.)

      solver = trust_region_solver(convergence_checker, &
                                   parameters, &
                                   gradient_getter, &
                                   energy_getter, &
                                   transformer, &
                                   preconditioner_getter, &
                                   printer, &
                                   projector, &
                                   max_iterations, &
                                   n_parameters)

   end subroutine create_solver


end module orbital_localization_task_class

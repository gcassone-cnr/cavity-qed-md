

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module ci_wavefunction_factory_class

   !!
   !! FCI wavefunction factory class
   !! Written by Eirik F. Kjoenstad, May 2022
   !!

   use hf_class, only: hf
   use fci_class, only: fci
   use density_environment_class, only: density_environment

   implicit none

   type :: ci_wavefunction_factory

      character(len=30), private :: wf_name

   contains

      procedure, public :: create => create_ci_wavefunction_factory

      procedure, private :: allocate_wavefunction

   end type ci_wavefunction_factory


   interface ci_wavefunction_factory

      procedure :: new_ci_wavefunction_factory

   end interface ci_wavefunction_factory


contains


   function new_ci_wavefunction_factory() result(this)
      !!
      !! Written by Eirik F. Kjoenstad, May 2022
      !!
      use global_in, only: input

      implicit none

      type(ci_wavefunction_factory) :: this

      this%wf_name = input%get_ci_wavefunction()

   end function new_ci_wavefunction_factory


   subroutine create_ci_wavefunction_factory(this, ref_wf, ci_wf, embedding)
      !!
      !! Written by Eirik F. Kjoenstad, May 2022
      !!
      implicit none

      class(ci_wavefunction_factory), intent(in) :: this

      class(hf), intent(in) :: ref_wf
      class(fci), allocatable, intent(out) :: ci_wf
      type(density_environment), allocatable :: embedding

      call this%allocate_wavefunction(ci_wf)

      if (allocated(embedding)) then
         call ci_wf%initialize_from_hf(ref_wf, embedding)
      else
         call ci_wf%initialize_from_hf(ref_wf)
      end if


   end subroutine create_ci_wavefunction_factory


   subroutine allocate_wavefunction(this, ci_wf)
      !!
      !! Written by Eirik F. Kjoenstad, May 2022
      !!
      use fci_class, only: fci
      use qed_fci_class, only: qed_fci
      use global_out, only: output

      implicit none

      class(ci_wavefunction_factory), intent(in) :: this

      class(fci), allocatable, intent(out) :: ci_wf

      select case (trim(this%wf_name))

         case ('fci')

            allocate(fci :: ci_wf)

         case ('casci')

            allocate(fci :: ci_wf)

         case ('qed-fci')

            allocate(qed_fci :: ci_wf)

         case ('qed-casci')

            allocate(qed_fci :: ci_wf)

         case default

            call output%error_msg('could not recognize FCI method ' // trim(this%wf_name) // '.')

      end select

   end subroutine allocate_wavefunction


end module ci_wavefunction_factory_class

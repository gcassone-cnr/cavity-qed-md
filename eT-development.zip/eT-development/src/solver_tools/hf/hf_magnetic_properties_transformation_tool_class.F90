

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

module hf_magnetic_properties_transformation_class

   !!
   !! HF magnetic properties transformation class module
   !! Written by Alberto Barlini, Feb 2023

   use kinds

   use hf_class, only: hf
   use transformation_class, only: transformation

   implicit none

   type, extends(transformation) :: hf_magnetic_properties_transformation

      class(hf), pointer, private :: wf

   contains

      procedure, public :: transform => transform_hf_magnetic_properties
      procedure, public :: initialize => initialize_hf_magnetic_properties

   end type hf_magnetic_properties_transformation

   interface hf_magnetic_properties_transformation

      procedure :: new_hf_magnetic_properties_transformation

   end interface hf_magnetic_properties_transformation

contains

   function new_hf_magnetic_properties_transformation(wf) result(this)
      !!
      !! Written by Alberto Barlini, October 2022
      !!
      implicit none

      class(hf), intent(in), target :: wf
      type(hf_magnetic_properties_transformation) :: this

      this%wf => wf
      this%n_parameters = wf%n_v * wf%n_o * 3

   end function new_hf_magnetic_properties_transformation


   subroutine transform_hf_magnetic_properties(this, trial, transform)
      !!
      !! Written by Alberto Barlini, July 2022
      !!
      implicit none

      class(hf_magnetic_properties_transformation), intent(in) :: this
      real(dp), dimension(this%n_parameters) :: trial, transform

      call this%wf%magnetic_properties_transformation(trial, transform)

   end subroutine transform_hf_magnetic_properties


   subroutine initialize_hf_magnetic_properties(this)
      !!
      !! Written by Alberto Barlini, July 2022
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(hf_magnetic_properties_transformation), intent(in) :: this

      call do_nothing(this)

   end subroutine initialize_hf_magnetic_properties


end module hf_magnetic_properties_transformation_class

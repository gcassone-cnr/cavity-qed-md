

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module tdhf_rhs_tool_class

   !!
   !! TDHF right-hand side class module
   !! Written by Regina Matveeva, Sept 2021
   !!

   use parameters
   use vector_getter_class, only: vector_getter
   use hf_class, only: hf

   implicit none

   type, extends(vector_getter) :: tdhf_rhs_tool

      class(hf), pointer, private :: wf
      integer :: component

   contains

      procedure, public :: get => get_tdhf_rhs_tool

   end type tdhf_rhs_tool


   interface tdhf_rhs_tool

      procedure :: new_tdhf_rhs_tool

   end interface tdhf_rhs_tool


contains

   function new_tdhf_rhs_tool(wf, component) result(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(hf), intent(in), target :: wf
      type(tdhf_rhs_tool) :: this
      integer :: component

      this%wf => wf
      this%n_parameters = 2 * wf%n_o * wf%n_v
      this%n_vectors = 1
      this%component = component

   end function new_tdhf_rhs_tool


   subroutine get_tdhf_rhs_tool(this, vectors)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(tdhf_rhs_tool), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      call this%wf%get_dipole_gradient(vectors, this%component)
      call dscal(this%n_parameters, - one, vectors, 1)

   end subroutine get_tdhf_rhs_tool


end module tdhf_rhs_tool_class

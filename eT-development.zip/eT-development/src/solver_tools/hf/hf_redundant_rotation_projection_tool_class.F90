

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_redundant_rotation_projection_tool_class

   !!
   !! HF rotation projection tool class module
   !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018-2019
   !!

   use parameters
   use hf_class, only: hf
   use reordering_r, only: squareup_anti, packin_anti
   use memory_manager_class, only: mem
   use abstract_projection_tool_class, only: abstract_projection_tool

   implicit none

   type, extends(abstract_projection_tool) :: hf_redundant_rotation_projection_tool

      class(hf), pointer, private :: wf

   contains

      procedure :: project => project_hf_redundant_rotation_projection_tool

   end type hf_redundant_rotation_projection_tool


   interface hf_redundant_rotation_projection_tool

      procedure :: new_hf_redundant_rotation_projection_tool

   end interface hf_redundant_rotation_projection_tool


contains


   function new_hf_redundant_rotation_projection_tool(wf) result(this)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018-2019
      !!
      implicit none

      type(hf_redundant_rotation_projection_tool) :: this

      class(hf), target :: wf

      this%wf => wf

      this%n_parameters = wf%packed_gradient_dimension

   end function new_hf_redundant_rotation_projection_tool


   subroutine project_hf_redundant_rotation_projection_tool(this, vector)
      !!
      !! Written by Regina Matveeva, June 2022
      !!
      implicit none

      class(hf_redundant_rotation_projection_tool), intent(in) :: this
      real(dp), dimension(this%n_parameters), intent(inout) :: vector

      real(dp), dimension(:, :), allocatable :: K

      call mem%alloc(K, this%wf%n_mo, this%wf%n_mo, set_zero=.true.)

      call squareup_anti(vector, K, this%wf%n_mo)
      call this%wf%project_redundant_rotations(K)
      call packin_anti(vector, K, this%wf%n_mo)

      call mem%dealloc(K)

   end subroutine project_hf_redundant_rotation_projection_tool


end module hf_redundant_rotation_projection_tool_class

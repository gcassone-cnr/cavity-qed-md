
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_magnetic_properties_preconditioner_getter_class

   !!
   !! HF magnetic properties preconditioner getter class module
   !! Written by Alberto Barlini, Feb 2023
   !!

   use parameters
   use vector_getter_class, only: vector_getter
   use hf_class, only: hf

   implicit none

   type, extends(vector_getter) :: hf_magnetic_properties_preconditioner_getter

      class(hf), pointer, private :: wf

   contains

      procedure, public :: get => get_hf_magnetic_properties_preconditioner_getter

   end type hf_magnetic_properties_preconditioner_getter

   interface hf_magnetic_properties_preconditioner_getter

      procedure :: new_hf_magnetic_properties_preconditioner_getter

   end interface hf_magnetic_properties_preconditioner_getter

contains

   function new_hf_magnetic_properties_preconditioner_getter(wf) result(this)
      !!
      !! Written by Alberto Barlini, June 2022
      !!
      implicit none

      class(hf), intent(in), target :: wf
      type(hf_magnetic_properties_preconditioner_getter) :: this

      this%wf => wf
      this%n_vectors = 1
      this%n_parameters = wf%n_v * wf%n_o * 3

   end function new_hf_magnetic_properties_preconditioner_getter


   subroutine get_hf_magnetic_properties_preconditioner_getter(this, vectors)
      !!
      !! Written by Alberto Barlini, June 2022
      !!
      implicit none

      class(hf_magnetic_properties_preconditioner_getter), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      call this%wf%get_magnetic_properties_preconditioner(vectors)

   end subroutine get_hf_magnetic_properties_preconditioner_getter

end module hf_magnetic_properties_preconditioner_getter_class

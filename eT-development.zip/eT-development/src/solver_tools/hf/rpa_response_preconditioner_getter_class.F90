

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module rpa_response_preconditioner_getter_class

   !!
   !! RPA response preconditioner getter class module
   !! Written by Sarai D. Folkestad, May 2021
   !!

   use parameters
   use vector_getter_class, only: vector_getter
   use hf_class, only: hf

   implicit none

   type, extends(vector_getter) :: rpa_response_preconditioner_getter

      class(hf), pointer, private :: wf
      real(dp) :: frequency

   contains

      procedure, public :: get => get_rpa_response_preconditioner_getter

   end type rpa_response_preconditioner_getter

   interface rpa_response_preconditioner_getter

      procedure :: new_rpa_response_preconditioner_getter

   end interface rpa_response_preconditioner_getter

contains

   function new_rpa_response_preconditioner_getter(wf, frequency) result(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      class(hf), intent(in), target :: wf
      type(rpa_response_preconditioner_getter) :: this
      real(dp), intent(in) :: frequency

      this%wf => wf
      this%n_parameters = 2 * wf%n_o * wf%n_v
      this%frequency = frequency
      this%n_vectors = 1

   end function new_rpa_response_preconditioner_getter


   subroutine get_rpa_response_preconditioner_getter(this, vectors)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      class(rpa_response_preconditioner_getter), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      call this%wf%get_rpa_response_preconditioner(vectors, this%frequency)

   end subroutine get_rpa_response_preconditioner_getter

end module rpa_response_preconditioner_getter_class

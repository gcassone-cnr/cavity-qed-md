
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module sc_orbitals_and_eta_updater_class

   !!
   !! SC orbitals and eta updater class module
   !! Written by Rosario R. Riso and Alexander C. Paul, Oct 2022
   !!

   use parameters
   use hf_class, only: hf
   use memory_manager_class, only: mem
   use abstract_hf_parameter_updater_class, only: abstract_hf_parameter_updater

   implicit none

   type, extends(abstract_hf_parameter_updater) :: sc_orbitals_and_eta_updater

   contains

      procedure, public :: update => update_sc_orbitals_and_eta_updater

   end type sc_orbitals_and_eta_updater


   interface sc_orbitals_and_eta_updater

      procedure :: new_sc_orbitals_and_eta_updater

   end interface sc_orbitals_and_eta_updater


contains

   function new_sc_orbitals_and_eta_updater(wf) result(this)
      !!
      !! Written by Rosario R. Riso, Oct 2022
      !!
      implicit none

      type(sc_orbitals_and_eta_updater) :: this

      class(hf), intent(in), target :: wf

      this%wf => wf
      this%n_parameters = wf%packed_parameter_dimension
      this%n_equations = wf%n_densities

   end function new_sc_orbitals_and_eta_updater


   subroutine update_sc_orbitals_and_eta_updater(this, parameters)
      !!
      !! Written by Rosario R. Riso, Oct 2022
      !!
      !! The parameters contain both the packed fock matrix and eta.
      !! This routine diagonalizes the fock matrix
      !! (first n_mo**2 components of parameters) and sets the
      !! orbital coefficients, energies and eta in the wave function
      !!
      use array_utilities, only: diagonalize_symmetric
      use reordering_r, only: squareup
      use timings_class, only: timings

      implicit none

      class(sc_orbitals_and_eta_updater), intent(in) :: this

      !Packed Fock Matrix + eta
      real(dp), dimension(this%n_parameters, this%n_equations), intent(inout) :: parameters

      real(dp), dimension(:, :), allocatable :: orbital_coefficients_and_eta
      real(dp), dimension(:, :), allocatable :: orbital_energies

      real(dp), dimension(:, :), allocatable :: tmp_unpacked

      integer :: i

      type(timings), allocatable :: timer

      timer = timings('SCF diagonalization', pl='normal')
      call timer%turn_on()

      call mem%alloc(orbital_coefficients_and_eta, this%wf%n_scf_parameters, this%n_equations)
      call mem%alloc(orbital_energies, this%wf%n_mo, this%n_equations)
      call mem%alloc(tmp_unpacked, this%wf%n_mo, this%wf%n_mo)

      do i = 1, this%n_equations

         call squareup(parameters(:, i), tmp_unpacked, this%wf%n_mo)

         call diagonalize_symmetric(tmp_unpacked, this%wf%n_mo, orbital_energies)

         call dcopy(this%wf%n_mo**2, tmp_unpacked, 1, orbital_coefficients_and_eta(:, i), 1)

         call dcopy(this%wf%n_mo, &
                    parameters(this%wf%n_mo * (this%wf%n_mo + 1) / 2 + 1:, i), &
                    1, &
                    orbital_coefficients_and_eta(this%wf%n_mo**2 + 1:, i), &
                    1)

      end do

      call this%wf%set_hf_parameters_and_orbital_energies(orbital_coefficients_and_eta, orbital_energies)

      call mem%dealloc(orbital_coefficients_and_eta)
      call mem%dealloc(orbital_energies)
      call mem%dealloc(tmp_unpacked)

      call timer%turn_off()

   end subroutine update_sc_orbitals_and_eta_updater


end module sc_orbitals_and_eta_updater_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_magnetic_properties_linear_equation_storage_tool_class

   !!
   !! HF magnetic properties linear equation storage class module
   !! Written by Alberto Barlini, Sept 2022
   !!

   use kinds, only: dp
   use linear_equation_storage_tool_class, only: linear_equation_storage_tool
   use hf_class, only: hf

   implicit none

   type, extends(linear_equation_storage_tool) :: hf_magnetic_properties_linear_equation_storage_tool

      class(hf), pointer, private :: wf

   contains

      procedure, public :: store => store_hf_magnetic_properties_linear_equation_storage_tool

   end type hf_magnetic_properties_linear_equation_storage_tool


   interface hf_magnetic_properties_linear_equation_storage_tool

      procedure :: new_hf_magnetic_properties_linear_equation_storage_tool

   end interface hf_magnetic_properties_linear_equation_storage_tool


contains

   function new_hf_magnetic_properties_linear_equation_storage_tool(wf) result(this)
      !!
      !! Written by Alberto Barlini, Feb 2023
      !!
      implicit none

      class(hf), intent(in), target :: wf
      type(hf_magnetic_properties_linear_equation_storage_tool) :: this

      this%wf => wf
      this%n_parameters = wf%n_v * wf%n_o * 3

   end function new_hf_magnetic_properties_linear_equation_storage_tool


   subroutine store_hf_magnetic_properties_linear_equation_storage_tool(this, solution_vector, n)
      !!
      !! Written by Alberto Barlini, June 2022
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(hf_magnetic_properties_linear_equation_storage_tool), intent(inout) :: this
      integer, intent(in) :: n
      real(dp), dimension(this%n_parameters), intent(in) :: solution_vector

      call do_nothing(n)

      call this%wf%save_magnetic_properties_solution(solution_vector)

   end subroutine store_hf_magnetic_properties_linear_equation_storage_tool


end module hf_magnetic_properties_linear_equation_storage_tool_class

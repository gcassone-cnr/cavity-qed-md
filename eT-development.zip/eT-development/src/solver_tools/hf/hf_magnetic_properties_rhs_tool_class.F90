
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

module hf_magnetic_properties_rhs_tool_class

   !!
   !! HF magnetic properties right-hand side class module
   !! Written by Alberto Barlini, Feb 2023
   !!

   use kinds, only: dp
   use vector_getter_class, only: vector_getter
   use hf_class, only: hf

   implicit none

   type, extends(vector_getter) :: hf_magnetic_properties_rhs_tool

      class(hf), pointer, private :: wf

   contains

      procedure, public :: get => get_hf_magnetic_properties_rhs_tool

   end type hf_magnetic_properties_rhs_tool


   interface hf_magnetic_properties_rhs_tool

      procedure :: new_hf_magnetic_properties_rhs_tool

   end interface hf_magnetic_properties_rhs_tool


contains

   function new_hf_magnetic_properties_rhs_tool(wf) result(this)
      !!
      !! Written by Alberto Barlini, July 2022
      !!
      implicit none

      class(hf), intent(in), target :: wf
      type(hf_magnetic_properties_rhs_tool) :: this

      this%wf => wf
      this%n_parameters = wf%n_v * wf%n_o * 3
      this%n_vectors = 1

   end function new_hf_magnetic_properties_rhs_tool


   subroutine get_hf_magnetic_properties_rhs_tool(this, vectors)
      !!
      !! Written by Alberto Barlini, June 2022
      !!
      implicit none

      class(hf_magnetic_properties_rhs_tool), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      call this%wf%get_magnetic_properties_rhs()
      call dcopy(this%n_parameters * this%n_vectors, this%wf%magnetic_properties_rhs, 1, vectors, 1)

   end subroutine get_hf_magnetic_properties_rhs_tool


end module hf_magnetic_properties_rhs_tool_class

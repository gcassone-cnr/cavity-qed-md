

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_hf_parameter_updater_class

   !!
   !! Abstract HF parameter updater class module
   !! Written by Rosario R. Riso and Alexander C. Paul, Oct 2022
   !!

   use kinds
   use hf_class, only: hf

   implicit none

   type, abstract :: abstract_hf_parameter_updater

      class(hf), pointer :: wf

      integer :: n_parameters, n_equations

   contains

      procedure(update), deferred, public :: update

   end type abstract_hf_parameter_updater


   abstract interface

      subroutine update(this, parameters)

         import abstract_hf_parameter_updater, dp

         implicit none

         class(abstract_hf_parameter_updater), intent(in) :: this

         real(dp), dimension(this%n_parameters, this%n_equations), intent(inout) :: parameters

      end subroutine update

   end interface


end module abstract_hf_parameter_updater_class

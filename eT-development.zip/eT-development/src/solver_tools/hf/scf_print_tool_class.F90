

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module scf_print_tool_class

   !!
   !! SCF print tool class module
   !! Written by Alexander C. Paul and Rosario R. Riso, Nov 2022
   !!

   use global_out, only: output

   implicit none

   type :: scf_print_tool

      character(len=200) :: acceleration_type

   contains

      procedure, public, nopass :: print_banner
      procedure, public :: print_settings
      procedure, public, nopass :: print_iteration_banner
      procedure, public, nopass :: print_iteration
      procedure, public, nopass :: print_summary

   end type scf_print_tool


   interface scf_print_tool
      procedure :: new_scf_print_tool
   end interface scf_print_tool


contains


   function new_scf_print_tool(acceleration_type) result(this)
      !!
      !! Written by Alexander C. Paul and Rosario R. Riso, Nov 2022
      !!
      implicit none

      type(scf_print_tool) :: this

      character(len=*), intent(in) :: acceleration_type

      this%acceleration_type = acceleration_type

   end function new_scf_print_tool


   subroutine print_banner()
      !!
      !! Written by Regina Matveeva, Dec 2021
      !!

      implicit none

      character(len=50) :: name_
      character(len=100) :: description

      name_ = 'Self-consistent field solver'

      description = 'A Self-consistent field solver that solves an eigenvalue equations: F(C) C = C e.'

      call output%printf('m', trim(name_), fs='(/t3,a)')
      call output%print_separator('m', len(trim(name_)), '-')

      call output%printf('n', trim(description), ffs='(/t3,a)', fs='(t3,a)')

   end subroutine print_banner


   subroutine print_settings(this, max_iterations)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      class(scf_print_tool), intent(in) :: this
      integer, intent(in) :: max_iterations

      call output%printf('m', '- SCF solver settings:', fs='(/t3,a)')

      call output%printf('m', &
                         'Maximum iterations:           (i11)', &
                         ints=[max_iterations], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Acceleration type:            (a11)', &
                         chars=[trim(this%acceleration_type)], &
                         fs='(t6,a)')

   end subroutine print_settings


   subroutine print_iteration_banner()
      !!
      !! Written by Sarai D. Folkestad
      !!
      implicit none

      call output%printf('n', &
                         'Iteration       Energy (a.u.)      Max(grad.)    Delta E (a.u.)', &
                         fs='(/t3,a)')

      call output%print_separator('n', 63, '-')

   end subroutine print_iteration_banner


   subroutine print_iteration(iteration, energy, previous_energy, max_residual)
      !!
      !! Written by Sarai D. Folkestad
      !!
      use kinds, only: dp

      implicit none

      integer, intent(in) :: iteration
      real(dp), intent(in) :: energy
      real(dp), intent(in) :: previous_energy
      real(dp), intent(in) :: max_residual

      call output%printf('n', &
                         '(i4)  (f25.12)    (e11.4)    (e11.4)', &
                         ints=[iteration], &
                         reals=[energy, max_residual, abs(energy - previous_energy)], &
                         fs='(t3,a)')

   end subroutine print_iteration


   subroutine print_summary(iteration)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      integer, intent(in) :: iteration

      call output%print_separator('n', 63, '-')

      call output%printf('m', &
                         'Convergence criterion met in (i0) iterations!', &
                         ints=[iteration])

   end subroutine print_summary


end module scf_print_tool_class


! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_magnetic_properties_start_vector_tool_class

   !!
   !! HF magnetic properties start vector tool class module
   !! Written by Alberto Barlini, Feb 2023
   !!

   use kinds
   use hf_class, only: hf
   use vector_getter_class, only: vector_getter

   implicit none

   type, extends(vector_getter) :: hf_magnetic_properties_start_vector_tool

      logical, private :: restart
      class(hf), pointer, private :: wf

   contains

      procedure, public :: get => get_hf_magnetic_properties_start_vector_tool

   end type hf_magnetic_properties_start_vector_tool

   interface hf_magnetic_properties_start_vector_tool

      procedure :: new_hf_magnetic_properties_start_vector_tool

   end interface hf_magnetic_properties_start_vector_tool

contains


   function new_hf_magnetic_properties_start_vector_tool(wf, restart) result(this)
      !!
      !! Written by Alberto Barlini, April 2022
      !!
      implicit none

      class(hf), intent(in), target :: wf
      logical, intent(in) :: restart
      type(hf_magnetic_properties_start_vector_tool) :: this

      this%wf => wf
      this%n_parameters = wf%n_v * wf%n_o * 3
      this%restart = restart
      this%n_vectors = 1

   end function new_hf_magnetic_properties_start_vector_tool


   subroutine get_hf_magnetic_properties_start_vector_tool(this, vectors)
      !!
      !! Written by Alberto Barlini, April 2022
      !!

      implicit none

      class(hf_magnetic_properties_start_vector_tool), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors


      call this%wf%get_magnetic_properties_start_vector(vectors, this%restart)

   end subroutine


end module hf_magnetic_properties_start_vector_tool_class

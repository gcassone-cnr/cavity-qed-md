
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_orbitals_updater_class

   !!
   !! HF orbital updater class module
   !! Written by Rosario R. Riso and Alexander C. Paul, Oct 2022
   !!

   use parameters
   use hf_class, only: hf
   use memory_manager_class, only: mem
   use abstract_hf_parameter_updater_class, only: abstract_hf_parameter_updater

   implicit none

   type, extends(abstract_hf_parameter_updater) :: hf_orbitals_updater

   contains

      procedure, public :: update => update_hf_orbitals_updater

   end type hf_orbitals_updater


   interface hf_orbitals_updater

      procedure :: new_hf_orbitals_updater

   end interface hf_orbitals_updater


contains

   function new_hf_orbitals_updater(wf) result(this)
      !!
      !! Written by Rosario R. Riso and Alexander C. Paul, Oct 2022
      !!
      implicit none

      type(hf_orbitals_updater) :: this

      class(hf), intent(in), target :: wf

      this%wf => wf
      this%n_parameters = wf%packed_parameter_dimension
      this%n_equations = wf%n_densities

   end function new_hf_orbitals_updater


   subroutine update_hf_orbitals_updater(this, parameters)
      !!
      !! Written by Rosario R. Riso and Alexander C. Paul, Oct 2022
      !!
      use array_utilities, only: diagonalize_symmetric
      use reordering_r, only: squareup
      use timings_class, only: timings

      implicit none

      class(hf_orbitals_updater), intent(in) :: this

      ! Packed Fock Matrix
      real(dp), dimension(this%n_parameters, this%n_equations), intent(inout) :: parameters

      real(dp), dimension(:, :), allocatable :: orbital_coefficients
      real(dp), dimension(:, :), allocatable :: orbital_energies

      integer :: i

      type(timings), allocatable :: timer

      timer = timings('SCF diagonalization', pl='normal')
      call timer%turn_on()

      call mem%alloc(orbital_coefficients, this%wf%n_mo**2, this%n_equations)
      call mem%alloc(orbital_energies, this%wf%n_mo, this%n_equations)

      do i = 1, this%n_equations

         call squareup(parameters(:, i), orbital_coefficients(:, i), this%wf%n_mo)

         call diagonalize_symmetric(orbital_coefficients(:, i), this%wf%n_mo, orbital_energies(:, i))

      end do

      call this%wf%set_hf_parameters_and_orbital_energies(orbital_coefficients, orbital_energies)

      call mem%dealloc(orbital_coefficients)
      call mem%dealloc(orbital_energies)

      call timer%turn_off()

   end subroutine update_hf_orbitals_updater


end module hf_orbitals_updater_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_orbital_rotation_parameters_tool_class

   !!
   !! HF orbital rotation parameters tool class module
   !! Written Regina Matveeva, Sept 2021
   !!

   use parameters
   use parameters_tool_class, only: parameters_tool
   use hf_class, only: hf

   implicit none

   type, extends(parameters_tool) :: hf_orbital_rotation_parameters_tool

      class(hf), pointer, private :: wf

   contains

      procedure, public :: set => set_hf_orbital_rotation_parameters_tool

   end type hf_orbital_rotation_parameters_tool

   interface hf_orbital_rotation_parameters_tool

      procedure :: new_hf_orbital_rotation_parameters_tool

   end interface hf_orbital_rotation_parameters_tool

contains

   function new_hf_orbital_rotation_parameters_tool(wf) result(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(hf), intent(in), target :: wf
      type(hf_orbital_rotation_parameters_tool) :: this

      this%wf => wf
      this%n_parameters = wf%packed_gradient_dimension

   end function new_hf_orbital_rotation_parameters_tool


   subroutine set_hf_orbital_rotation_parameters_tool(this, X)
      !!
      !! Written by by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(hf_orbital_rotation_parameters_tool), intent(inout) :: this
      real(dp), dimension(this%n_parameters), intent(in) :: X

      call this%wf%rotate_orbital_coefficients(X)
      call this%wf%update_ao_density()
      call this%wf%update_fock_and_energy(cumulative=.true.)
      call this%wf%mo_transform(this%wf%ao_fock, this%wf%mo_fock)

   end subroutine set_hf_orbital_rotation_parameters_tool


end module hf_orbital_rotation_parameters_tool_class

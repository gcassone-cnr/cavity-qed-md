

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_hessian_transformation_class

   !!
   !! HF transformation class
   !! Written by Regina Matveeva, Sept 2021
   !!

   use kinds

   use hf_class, only: hf
   use transformation_class, only: transformation

   implicit none

   type, extends(transformation) :: hf_hessian_transformation

      class(hf), pointer, private :: wf

   contains

      procedure, public :: transform => transform_linear_equation
      procedure, public :: initialize => initialize_linear_equation

   end type hf_hessian_transformation

   interface hf_hessian_transformation

      procedure :: new_hf_hessian_transformation

   end interface hf_hessian_transformation

contains

   function new_hf_hessian_transformation(wf) result(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(hf), intent(in), target :: wf
      type(hf_hessian_transformation) :: this

      this%wf => wf
      this%n_parameters = wf%packed_gradient_dimension

   end function new_hf_hessian_transformation


   subroutine transform_linear_equation(this, trial, transform)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(hf_hessian_transformation), intent(in) :: this
      real(dp), dimension(this%n_parameters) :: trial, transform

      call this%wf%construct_linear_transformation(trial, transform)

   end subroutine transform_linear_equation


   subroutine initialize_linear_equation(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(hf_hessian_transformation), intent(in) :: this

      call do_nothing(this)

   end subroutine initialize_linear_equation

end module hf_hessian_transformation_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_energy_getter_class

   !!
   !! HF energy getter class module
   !! Written by Regina Matveeva, Sept 2021
   !!

   use kinds
   use hf_class, only: hf
   use abstract_value_getter_class, only: abstract_value_getter

   implicit none

   type, extends(abstract_value_getter) :: hf_energy_getter

      class(hf), pointer, private :: wf

   contains

      procedure, public :: get => get_hf_energy_getter

   end type hf_energy_getter


   interface hf_energy_getter

      procedure :: new_hf_energy_getter

   end interface hf_energy_getter


contains


   function new_hf_energy_getter(wf) result(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(hf), intent(in), target :: wf
      type(hf_energy_getter) :: this

      this%wf => wf

   end function new_hf_energy_getter


   function get_hf_energy_getter(this) result(value_)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(hf_energy_getter), intent(in) :: this

      real(dp) :: value_

      value_ = this%wf%get_energy()

   end function get_hf_energy_getter


end module hf_energy_getter_class

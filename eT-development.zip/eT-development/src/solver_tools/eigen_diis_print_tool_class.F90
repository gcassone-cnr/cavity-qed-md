

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module eigen_diis_print_tool_class

   !!
   !! Eigen diis print tool class module
   !! Written by Alexander C. Paul, Oct 2022
   !!

   use global_out, only: output
   use global_in, only: input

   use abstract_eigen_print_tool_class, only: abstract_eigen_print_tool

   implicit none

   type, extends(abstract_eigen_print_tool) :: eigen_diis_print_tool

   contains

      procedure, public, nopass :: print_banner => print_banner_eigen_diis_print_tool

      procedure, public, nopass :: print_settings => print_settings_eigen_diis_print_tool

   end type eigen_diis_print_tool

contains


   subroutine print_banner_eigen_diis_print_tool()
      !!
      !! Written by Alexander C. Paul, Oct 2022
      !!
      use global_out, only: output

      implicit none

      character(len=100) :: name_
      character(len=500) :: description

      name_ = 'DIIS eigenvalue equation solver'

      description = &
         'A DIIS solver that solves an eigenvalue equation: M x = omega x. The eigenvalue problem is solved&
         & by DIIS extrapolation of residuals for each eigenvector. More on the DIIS algorithm can be found&
         & in P. Pulay, Chemical Physics Letters, 73(2), 393-398 (1980).'

      call output%printf('m', trim(name_), fs='(/t3,a)')
      call output%print_separator('m', len_trim(name_), '-')

      call output%printf('n', description, ffs='(/t3,a)', fs='(t3,a)')

      call output%warning_msg( &
              "This DIIS algorithm does not guarantee convergence to the lowest eigenvalues, and may yield&
              & duplicate roots." &
           )

   end subroutine print_banner_eigen_diis_print_tool


   subroutine print_settings_eigen_diis_print_tool(n_solutions, max_iterations)
      !!
      !! Written by Alexander C. Paul, Oct 2022
      !!
      !! Modified by Jacob Pedersen and Bendik Stoea Sannes, Dec 2022
      !!
      !! Adapted to distinguish between singlet and triplet states
      !!
      implicit none

      integer, intent(in) :: n_solutions, max_iterations
      character(len=7) :: spin_state

      call output%printf('m', '- DIIS solver settings', fs='(/t3,a)')

      if (input%is_keyword_present('singlet states', 'solver cc es')) spin_state = 'singlet'
      if (input%is_keyword_present('triplet states', 'solver cc es')) spin_state = 'triplet'

      call output%printf('m', &
                         'Number of (a0) states:     (i11)', &
                         ints=[n_solutions], &
                         chars=[spin_state], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Max number of iterations:     (i11)', &
                         ints=[max_iterations], &
                         fs='(t6,a)')

   end subroutine print_settings_eigen_diis_print_tool


end module eigen_diis_print_tool_class

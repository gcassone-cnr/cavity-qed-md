

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module orbital_localization_hessian_transformation_class

   !!
   !! Orbital localization transformation class
   !! Written by Sarai D. Folkestad, 2022
   !!

   use kinds, only: dp
   use warning_suppressor, only: do_nothing

   use transformation_class, only: transformation
   use abstract_orbital_localization_class, only: abstract_orbital_localization

   implicit none

   type, extends(transformation) :: orbital_localization_hessian_transformation

      class(abstract_orbital_localization), pointer :: orbital_localization_tool

   contains

      procedure :: transform => transform_orbital_localization_hessian_transformation
      procedure :: initialize => initialize_orbital_localization_hessian_transformation

   end type orbital_localization_hessian_transformation


   interface orbital_localization_hessian_transformation

      procedure :: new_orbital_localization_hessian_transformation

   end interface orbital_localization_hessian_transformation


contains


   function new_orbital_localization_hessian_transformation(orbital_localization_tool) result(this)
      !!
      !! Written by Sarai D. Folkestad, 2022
      !!
      implicit none

      class(abstract_orbital_localization), target :: orbital_localization_tool
      type(orbital_localization_hessian_transformation) :: this

      this%orbital_localization_tool => orbital_localization_tool
      this%n_parameters = this%orbital_localization_tool%packed_gradient_dimension

   end function new_orbital_localization_hessian_transformation


   subroutine transform_orbital_localization_hessian_transformation(this, trial, transform)
      !!
      !! Written by Sarai D. Folkestad, 2022
      !!
      implicit none

      class(orbital_localization_hessian_transformation), intent(in) :: this
      real(dp), dimension(this%n_parameters) :: trial, transform

      call this%orbital_localization_tool%get_hessian_transformation(trial, transform)

   end subroutine transform_orbital_localization_hessian_transformation


   subroutine initialize_orbital_localization_hessian_transformation(this)
      !!
      !! Written by Sarai D. Folkestad, 2022
      !!
      implicit none

      class(orbital_localization_hessian_transformation), intent(in) :: this

      call do_nothing(this)

   end subroutine initialize_orbital_localization_hessian_transformation


end module orbital_localization_hessian_transformation_class

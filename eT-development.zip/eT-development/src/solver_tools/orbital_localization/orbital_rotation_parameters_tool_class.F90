

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module orbital_rotation_parameters_tool_class

   !!
   !! Orbital rotation parameters tool class module
   !! Written by Sarai D. Folkestad, 2022
   !!

   use kinds, only: dp
   use parameters_tool_class, only: parameters_tool
   use abstract_orbital_localization_class, only: abstract_orbital_localization

   implicit none

   type, extends(parameters_tool) :: orbital_rotation_parameters_tool

      class(abstract_orbital_localization), pointer :: orbital_localization_tool

   contains

      procedure, public :: set => set_orbital_rotation_parameters_tool

   end type orbital_rotation_parameters_tool

   interface orbital_rotation_parameters_tool

      procedure :: new_orbital_rotation_parameters_tool

   end interface orbital_rotation_parameters_tool

contains


   function new_orbital_rotation_parameters_tool(orbital_localization_tool) result(this)
      !!
      !! Written by Sarai D. Folkestad, 2022
      !!
      implicit none

      class(abstract_orbital_localization), target :: orbital_localization_tool
      type(orbital_rotation_parameters_tool) :: this

      this%orbital_localization_tool => orbital_localization_tool
      this%n_parameters = this%orbital_localization_tool%packed_gradient_dimension

   end function new_orbital_rotation_parameters_tool


   subroutine set_orbital_rotation_parameters_tool(this, X)
      !!
      !! Written by Sarai D. Folkestad, 2022
      !!
      implicit none

      class(orbital_rotation_parameters_tool), intent(inout) :: this
      real(dp), dimension(this%n_parameters), intent(in) :: X

      call this%orbital_localization_tool%update_parameters(X)

   end subroutine set_orbital_rotation_parameters_tool


end module orbital_rotation_parameters_tool_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module orbital_localization_gradient_getter_class

   !!
   !! Orbital localization gradient getter class module
   !! Written by Sarai D. Folkestad and Regina Matveeva, 2022
   !!

   use kinds, only: dp
   use vector_getter_class, only: vector_getter
   use abstract_orbital_localization_class, only: abstract_orbital_localization

   implicit none

   type, extends(vector_getter) :: orbital_localization_gradient_getter

      class(abstract_orbital_localization), pointer :: orbital_localization_tool

   contains

      procedure, public :: get => get_gradient_orbital_localization_gradient_getter

   end type orbital_localization_gradient_getter

   interface orbital_localization_gradient_getter

      procedure :: new_orbital_localization_gradient_getter

   end interface orbital_localization_gradient_getter

contains


   function new_orbital_localization_gradient_getter(orbital_localization_tool) result(this)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, 2022
      !!
      implicit none

      class(abstract_orbital_localization), target :: orbital_localization_tool
      type(orbital_localization_gradient_getter) :: this

      this%orbital_localization_tool => orbital_localization_tool
      this%n_parameters = this%orbital_localization_tool%packed_gradient_dimension
      this%n_vectors = 1

   end function new_orbital_localization_gradient_getter


   subroutine get_gradient_orbital_localization_gradient_getter(this, vectors)
      !!
      !! Wriiten by Sarai D. Folkestad
      !!
      implicit none

      class(orbital_localization_gradient_getter), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      call this%orbital_localization_tool%get_gradient(vectors)

   end subroutine get_gradient_orbital_localization_gradient_getter


end module orbital_localization_gradient_getter_class

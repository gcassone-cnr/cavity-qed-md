

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module orbital_localization_energy_getter_class

   !!
   !! Orbital localization energy getter class module
   !! Written by Regina Matveeva, Dec 2022
   !!

   use kinds, only: dp
   use abstract_value_getter_class, only: abstract_value_getter
   use abstract_orbital_localization_class, only: abstract_orbital_localization

   implicit none

   type, extends(abstract_value_getter) :: orbital_localization_energy_getter

      class(abstract_orbital_localization), pointer :: orbital_localization_tool

   contains

      procedure, public :: get => get_orbital_localization_energy_getter

   end type orbital_localization_energy_getter


   interface orbital_localization_energy_getter

      procedure :: new_orbital_localization_energy_getter

   end interface orbital_localization_energy_getter


contains


   function new_orbital_localization_energy_getter(orbital_localization_tool) result(this)
      !!
      !! Written by Regina Matveeva, Dec 2022
      !!
      implicit none

      class(abstract_orbital_localization), target :: orbital_localization_tool
      type(orbital_localization_energy_getter) :: this

      this%orbital_localization_tool => orbital_localization_tool

   end function new_orbital_localization_energy_getter


   function get_orbital_localization_energy_getter(this) result(value_)
      !!
      !! Written by Regina Matveeva, Dec 2022
      !!
      implicit none

      class(orbital_localization_energy_getter), intent(in) :: this

      real(dp) :: value_

      value_ = this%orbital_localization_tool%get_functional_value()

   end function get_orbital_localization_energy_getter


end module orbital_localization_energy_getter_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module geoopt_convergence_tool_class

   !!
   !! Geoopt convergence tool class module
   !! Written by Sarai D. Folkestad 2020, and Jan Haakon M. Trabski 2023
   !!
   !! Convergence for geometry optimization (follows convergence criterions by Baker, 1996)
   !!
   !! displacement
   !! displacement_rms
   !! gradient_rms
   !!

   use kinds
   use global_out, only: output

   implicit none

   type :: geoopt_convergence_tool

      real(dp) :: residual_threshold
      real(dp) :: residual_rms_threshold
      real(dp) :: displacement_threshold
      real(dp) :: displacement_rms_threshold
      real(dp) :: energy_threshold
      logical :: energy_convergence

   contains

      procedure, public :: has_converged
      procedure, public :: print_settings

   end type geoopt_convergence_tool

   interface geoopt_convergence_tool

      procedure :: new_geoopt_convergence_tool

   end interface geoopt_convergence_tool

contains

   function new_geoopt_convergence_tool(energy_threshold, &
                                        residual_threshold, &
                                        residual_rms_threshold, &
                                        displacement_threshold, &
                                        displacement_rms_threshold, &
                                        energy_convergence) result(this)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad,
      !! Rolf H. Myhre, Alexander C. Paul, 2020,
      !! and Jan Haakon M. Trasbki, June 2023
      !!
      implicit none

      type(geoopt_convergence_tool) :: this

      real(dp), intent(in) :: residual_threshold
      real(dp), intent(in) :: energy_threshold
      real(dp), intent(in) :: residual_rms_threshold
      real(dp), intent(in) :: displacement_threshold
      real(dp), intent(in) :: displacement_rms_threshold
      logical, intent(in) :: energy_convergence

      this%residual_threshold = residual_threshold
      this%residual_rms_threshold = residual_rms_threshold
      this%displacement_threshold = displacement_threshold
      this%displacement_rms_threshold = displacement_rms_threshold
      this%energy_threshold = energy_threshold
      this%energy_convergence = energy_convergence

   end function new_geoopt_convergence_tool


   function has_converged(this, &
                          residual_norm, &
                          residual_norm_rms, &
                          displacement, &
                          displacement_rms, &
                          dE, &
                          iteration) result(converged)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad,
      !! Rolf H. Myhre and Alexander C. Paul, 2020,
      !! and Jan Haakon M.Trasbki, June 2023
      !!
      !! Returns true if equations are converged according to the residual
      !! norm and, if requested, the energy change (dE)
      !!
      !! If the iteration number is passed, convergence can be
      !! reached in the first iteration if the residual norm is
      !! below the threshold, even though dE > energy threshold.
      !!
      implicit none

      class(geoopt_convergence_tool), intent(in) :: this

      real(dp), intent(in) :: residual_norm
      real(dp), intent(in) :: residual_norm_rms
      real(dp), intent(in) :: displacement
      real(dp), intent(in) :: displacement_rms
      real(dp), intent(in) :: dE
      integer, intent(in), optional :: iteration

      logical :: converged

      logical :: converged_energy
      logical :: converged_residual
      logical :: converged_residual_norm_rms
      logical :: converged_displacement
      logical :: converged_displacement_rms

      converged_energy = (abs(dE) < this%energy_threshold)
      converged_residual = residual_norm < this%residual_threshold
      converged_residual_norm_rms = residual_norm_rms < this%residual_rms_threshold
      converged_displacement = displacement < this%displacement_threshold
      converged_displacement_rms = displacement_rms < this%displacement_rms_threshold

      if (this%energy_convergence) then

         converged = &
                     converged_energy .and. converged_residual .and. converged_residual_norm_rms .and. &
                     converged_displacement .and. converged_displacement_rms

      else

         converged = converged_residual

      end if

      if (present(iteration)) then
         if (converged_residual .and. iteration == 1) converged = .true.
      end if

   end function has_converged


   subroutine print_settings(this)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2018-2020 and
      !! Jan Haakon M. Trabski, 2023
      !!
      implicit none

      class(geoopt_convergence_tool), intent(in) :: this

      call output%printf('m', '- Convergence thresholds', fs='(/t3,a)')

      call output%printf('m', &
                         'Residual threshold:                (e11.4)', &
                         reals=[this%residual_threshold], &
                         fs='(t5,a)')

      call output%printf('m', &
                         'Residual rms threshold:            (e11.4)', &
                         reals=[this%residual_rms_threshold], &
                         fs='(t5,a)')

      if (this%energy_convergence) &
         call output%printf('m', &
                            'Energy threshold:                  (e11.4)', &
                            reals=[this%energy_threshold], &
                            fs='(t5,a)')

      call output%printf('m', &
                         'Atomic displacement threshold:     (e11.4)', &
                         reals=[this%displacement_threshold], &
                         fs='(t5,a)')

      call output%printf('m', &
                         'Atomic displacement RMS threshold: (e11.4)', &
                         reals=[this%displacement_rms_threshold], &
                         fs='(t5,a)')

   end subroutine print_settings

end module geoopt_convergence_tool_class

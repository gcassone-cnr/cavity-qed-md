

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cpp_start_vector_tool_class

   !!
   !! CPP start vector tool class module
   !! Written by Regina Matveeva and Sarai D. Folkestad, 2021-2023
   !!

   use parameters
   use vector_getter_class, only: vector_getter
   use normalized_start_vector_tool_class, only: normalized_start_vector_tool

   implicit none

   type, extends(normalized_start_vector_tool) :: cpp_start_vector_tool

      class(vector_getter), pointer, private :: preconditioner_getter
      real(dp), dimension(:), pointer, private :: frequencies
      real(dp), private :: damping, sign_
      integer, private :: n_frequencies

   contains

      procedure, public :: get => get_cpp_start_vector_tool

   end type cpp_start_vector_tool

   interface cpp_start_vector_tool

      procedure :: new_cpp_start_vector_tool

   end interface cpp_start_vector_tool

contains


   function new_cpp_start_vector_tool(n_parameters, &
                                      start_vector, &
                                      preconditioner_getter, &
                                      n_frequencies, &
                                      sign_, &
                                      frequencies, &
                                      damping) result(this)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      implicit none

      type(cpp_start_vector_tool) :: this

      integer, intent(in) :: n_frequencies, sign_, n_parameters
      real(dp), intent(in) :: damping
      real(dp), dimension(n_frequencies), intent(in), target :: frequencies
      class(vector_getter), intent(in), target :: preconditioner_getter
      real(dp), dimension(n_parameters), target :: start_vector

      this%sign_ = real(sign_, kind=dp)
      this%damping = damping
      this%n_parameters = n_parameters
      this%n_vectors = n_frequencies
      this%start_vectors(1:this%n_parameters, 1:1) => start_vector
      this%preconditioner_getter => preconditioner_getter
      this%frequencies(1:this%n_vectors) => frequencies

   end function new_cpp_start_vector_tool


   subroutine get_cpp_start_vector_tool(this, vectors)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      use array_utilities, only: l2_normalize
      use memory_manager_class, only: mem

      implicit none

      class(cpp_start_vector_tool), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      real(dp), dimension(:), allocatable :: preconditioner

      real(dp) :: denominator
      integer :: i, j

      call mem%alloc(preconditioner, this%n_parameters)
      call this%preconditioner_getter%get(preconditioner)

      !$omp parallel do private(i, j, denominator)
      do i = 1, this%n_parameters
         do j = 1, this%n_vectors

            denominator = (preconditioner(i) - this%sign_ * this%frequencies(j))**2 + this%damping**2

            vectors(i, j) = this%start_vectors(i, 1) &
                            * (preconditioner(i) - this%sign_ * this%frequencies(j)) / denominator

         end do
      end do
      !$omp end parallel do

      call mem%dealloc(preconditioner)

      do j = 1, this%n_vectors

         call l2_normalize(vectors(:, j), this%n_parameters)

      end do

   end subroutine get_cpp_start_vector_tool


end module cpp_start_vector_tool_class

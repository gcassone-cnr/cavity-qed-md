

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module normalized_start_vector_tool_class

   !!
   !! Normalized start vector tool class module
   !! Written by Regina Matveeva and Sarai D. Folkestad, 2021-2023
   !!

   use parameters
   use vector_getter_class, only: vector_getter

   implicit none

   type, extends(vector_getter) :: normalized_start_vector_tool

      real(dp), dimension(:, :), pointer :: start_vectors

   contains

      procedure, public :: get => get_normalized_start_vector_tool

   end type normalized_start_vector_tool

   interface normalized_start_vector_tool

      procedure :: new_normalized_start_vector_tool

   end interface normalized_start_vector_tool

contains


   function new_normalized_start_vector_tool(n_parameters, n_start_vectors, start_vectors) result(this)
      !!
      !! Written by Regina Matveeva and Sarai D. Folkestad, Sept 2021
      !!
      implicit none

      type(normalized_start_vector_tool) :: this

      integer, intent(in) :: n_parameters, n_start_vectors
      real(dp), dimension(n_parameters * n_start_vectors), target :: start_vectors

      this%n_parameters = n_parameters
      this%n_vectors = n_start_vectors
      this%start_vectors(1:this%n_parameters, 1:this%n_vectors) => start_vectors

   end function new_normalized_start_vector_tool


   subroutine get_normalized_start_vector_tool(this, vectors)
      !!
      !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
      !!
      use array_utilities, only: get_l2_norm
      use array_initialization, only: copy_and_scale

      implicit none

      class(normalized_start_vector_tool), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      real(dp) :: vector_norm
      integer :: i

      do i = 1, this%n_vectors
         vector_norm = get_l2_norm(this%start_vectors(:, i), this%n_parameters)
         call copy_and_scale(one / vector_norm, this%start_vectors(:, i), vectors(:, i), this%n_parameters)
      end do

   end subroutine get_normalized_start_vector_tool


end module normalized_start_vector_tool_class

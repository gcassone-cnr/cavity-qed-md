

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_reduced_matrix_maker_class

   !!
   !! Abstract reduced matrix maker class module
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, and Alexander C. Paul, 2018-2023
   !!

   use parameters

   use memory_manager_class, only: mem

   type, abstract :: abstract_reduced_matrix_maker

      real(dp), dimension(:, :), allocatable, public :: matrix
      integer, public :: dim

   contains

      procedure, public :: reset
      procedure, public :: get_dimension

      procedure, public :: deallocate_matrix

   end type abstract_reduced_matrix_maker


contains


   subroutine reset(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(abstract_reduced_matrix_maker), intent(inout) :: this

      if (allocated(this%matrix)) call mem%dealloc(this%matrix)
      this%dim = 0

   end subroutine reset


   subroutine deallocate_matrix(this)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Aug 2018
      !!
      implicit none

      class(abstract_reduced_matrix_maker), intent(inout) :: this

      if (allocated(this%matrix)) call mem%dealloc(this%matrix)

   end subroutine deallocate_matrix


   pure function get_dimension(this) result(dim)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(abstract_reduced_matrix_maker), intent(in) :: this
      integer :: dim

      dim = this%dim

   end function get_dimension


end module abstract_reduced_matrix_maker_class

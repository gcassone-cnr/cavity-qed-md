
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module full_space_vector_maker_class

   !!
   !! Full space vector maker class module
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, and Alexander C. Paul, 2018-2023
   !!

   use parameters

   use record_storer_class, only: record_storer
   use memory_manager_class, only: mem
   use batching_index_class, only: batching_index

   type :: full_space_vector_maker

   contains

      procedure, public, nopass :: construct_full_space_vector

   end type full_space_vector_maker


contains


   subroutine construct_full_space_vector(c, n, reduced_dimension, X_red, X)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, Aug 2018
      !!
      !! Constructs the first n full space vectors
      !!
      !!    X_k = sum_i c_i (X_red_k)_i, for k = 1, n
      !!

      use array_initialization, only: zero_array

      implicit none

      class(record_storer), intent(inout) :: c

      integer, intent(in) :: reduced_dimension, n

      real(dp), dimension(c%record_length, n), intent(out) :: X
      real(dp), dimension(reduced_dimension, reduced_dimension), intent(in) :: X_red

      real(dp), dimension(:, :), pointer, contiguous :: c_i

      integer :: current_i_batch, req_0, req_1

      type(batching_index), allocatable :: batch_i

      call zero_array(X, c%record_length * n)

      req_0 = 0
      req_1 = c%required_to_load_record()

      batch_i = batching_index(reduced_dimension)

      call mem%batch_setup(batch_i, req_0, req_1, 'construct_full_space_vector')

      call c%prepare_records([batch_i])

      do current_i_batch = 1, batch_i%num_batches

         call batch_i%determine_limits(current_i_batch)

         call c%load(c_i, batch_i)

         call dgemm('N', &
                    'N', &
                    c%record_length, &
                    n, &
                    batch_i%length, &
                    one, &
                    c_i, &
                    c%record_length, &
                    X_red(batch_i%first, 1), &
                    reduced_dimension, &
                    one, &
                    X, &
                    c%record_length)

      end do

      call mem%batch_finalize()
      call c%free_records()

   end subroutine construct_full_space_vector


end module full_space_vector_maker_class

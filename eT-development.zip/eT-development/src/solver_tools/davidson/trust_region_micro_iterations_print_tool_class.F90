

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module trust_region_micro_iterations_print_tool_class

   !!
   !! Trust region micro iterations print tool class module
   !! Written by Regina Matveeva, Dec 2021
   !!

   use global_out, only: output
   use linear_davidson_print_tool_class, only: linear_davidson_print_tool

   implicit none

   type, extends(linear_davidson_print_tool) :: trust_region_micro_iterations_print_tool

   contains

      procedure, public :: print_iteration_header => &
                           print_iteration_header_trust_region_micro_iterations_print_tool

      procedure, public :: print_iteration_footer => &
                           print_iteration_footer_trust_region_micro_iterations_print_tool

      procedure, public :: print_iteration => print_iteration_trust_region_micro_iterations_print_tool

   end type trust_region_micro_iterations_print_tool

   interface trust_region_micro_iterations_print_tool

      procedure :: new_trust_region_micro_iterations_print_tool

   end interface trust_region_micro_iterations_print_tool

contains


   function new_trust_region_micro_iterations_print_tool(print_level) result(this)
      !!
      !! Written by Regina Matveeva, 2022
      !!
      implicit none

      type(trust_region_micro_iterations_print_tool) :: this

      character(len=1), intent(in) :: print_level

      this%print_level = print_level

   end function new_trust_region_micro_iterations_print_tool


   subroutine print_iteration_header_trust_region_micro_iterations_print_tool(this)
      !!
      !! Written by Regina Matveeva, Dec 2021
      !!
      implicit none

      class(trust_region_micro_iterations_print_tool), intent(in) :: this

      call output%printf(this%print_level, ' Iteration       Residual norm       Level shift', fs='(/t3,a)')
      call output%print_separator(this%print_level, 49, '-')

   end subroutine print_iteration_header_trust_region_micro_iterations_print_tool


   subroutine print_iteration_footer_trust_region_micro_iterations_print_tool(this)
      !!
      !! Written by Regina Matveeva, Dec 2021
      !!
      implicit none

      class(trust_region_micro_iterations_print_tool), intent(in) :: this

      call output%print_separator(this%print_level, 49, '-')

   end subroutine print_iteration_footer_trust_region_micro_iterations_print_tool


   subroutine print_iteration_trust_region_micro_iterations_print_tool(this, &
                                                                       n_solutions, &
                                                                       residual_norm, &
                                                                       iteration, &
                                                                       frequencies, &
                                                                       reduced_dimension)
      !!
      !! Written by Regina Matveeva, Sep 2021
      !!
      use parameters
      use warning_suppressor, only: do_nothing

      implicit none

      class(trust_region_micro_iterations_print_tool), intent(in) :: this

      integer, intent(in) :: n_solutions, iteration, reduced_dimension
      real(dp), dimension(n_solutions), intent(in) :: residual_norm, frequencies

      call do_nothing(reduced_dimension)

      call output%printf(this%print_level, &
                         ' (i3)              (e11.4)       (e11.4)', &
                         ints=[iteration], &
                         reals=[residual_norm(1), frequencies(1)])

   end subroutine print_iteration_trust_region_micro_iterations_print_tool


end module trust_region_micro_iterations_print_tool_class

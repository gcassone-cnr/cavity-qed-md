

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module reduced_matrix_maker_class

   !!
   !! Reduced matrix maker class module
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, and Alexander C. Paul, 2018-2023
   !!
   !! Constructs a reduced matrix from two reduced spaces c and d:
   !!
   !! A_ij = c_i^T d_j
   !!

   use parameters

   use abstract_reduced_matrix_maker_class
   use record_storer_class, only: record_storer
   use memory_manager_class, only: mem
   use global_out, only: output
   use batching_index_class, only: batching_index
   use timings_class, only: timings

   type, extends(abstract_reduced_matrix_maker) :: reduced_matrix_maker

   contains

      procedure, public :: construct
      procedure, private :: construct_reduced_submatrix

   end type reduced_matrix_maker


   interface reduced_matrix_maker

      procedure :: new_reduced_matrix_maker

   end interface reduced_matrix_maker


contains


   function new_reduced_matrix_maker() result(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      type(reduced_matrix_maker) :: this

      this%dim = 0

   end function new_reduced_matrix_maker


   subroutine construct(this, c, d)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, Aug 2018 - Mar 2023
      !!
      !! Constructs the reduced matrix
      !!
      !!    A_ij = c_i^T d_j.
      !!
      !! Elements computed in previous iterations are not recomputed.
      !!
      implicit none

      class(reduced_matrix_maker), intent(inout) :: this

      class(record_storer), intent(inout) :: c, d

      real(dp), dimension(:, :), allocatable :: matrix_copy

      integer :: req_0, req_1_i, req_1_j, req_2

      type(batching_index), allocatable :: batch_i, batch_j

      type(timings), allocatable :: timer

      integer :: n_new_vectors, n_old_vectors

      timer = timings('Reduced matrix matrix: time to construct reduced matrix', 'v')
      call timer%turn_on()

      if (c%n_written_records /= d%n_written_records) &
         call output%error_msg('Inconsistent subspace vector dimensions in the reduced matrix maker')

      if (c%record_length /= d%record_length) &
         call output%error_msg('Inconsistent subspace vector length in the reduced matrix maker')

      n_new_vectors = c%n_written_records - this%dim
      n_old_vectors = this%dim

      req_0 = 0
      req_1_i = c%required_to_load_record()
      req_1_j = d%required_to_load_record()
      req_2 = 0

      this%dim = c%n_written_records

      if (n_old_vectors == 0) then

         ! First iteration or reset of space: calculate all elements

         call mem%alloc(this%matrix, this%dim, this%dim)

         batch_i = batching_index(c%n_written_records)
         batch_j = batching_index(d%n_written_records)

         call mem%batch_setup(batch_i, &
                              batch_j, &
                              req_0, &
                              req_1_i, &
                              req_1_j, &
                              req_2, &
                              'Reduced matrix construction 1')

         call this%construct_reduced_submatrix(batch_i, batch_j, c, d)

         call mem%batch_finalize()


      else


         ! Not first iteration: calculate new elements only

         ! Transfer previously calculated elements and
         ! extend the dimensionality of the reduced matrix

         call mem%alloc(matrix_copy, n_old_vectors, n_old_vectors)

         call dcopy(n_old_vectors**2, this%matrix, 1, matrix_copy, 1)

         call mem%dealloc(this%matrix)

         call mem%alloc(this%matrix, this%dim, this%dim)
         this%matrix(1:n_old_vectors, 1:n_old_vectors) = matrix_copy
         call mem%dealloc(matrix_copy)

         ! Compute the new blocks in the reduced matrix

         ! i index new, j index all

         batch_i = batching_index(dimension_=n_new_vectors, offset=n_old_vectors)

         batch_j = batching_index(dimension_=this%dim, offset=0)

         call mem%batch_setup(batch_i, &
                              batch_j, &
                              req_0, &
                              req_1_i, &
                              req_1_j, &
                              req_2, &
                              'Reduced matrix construction 2')

         call this%construct_reduced_submatrix(batch_i, batch_j, c, d)

         call mem%batch_finalize()

         ! i index old, j index new

         batch_i = batching_index(dimension_=n_old_vectors, offset=0)

         batch_j = batching_index(dimension_=n_new_vectors, offset=n_old_vectors)

         call mem%batch_setup(batch_i, &
                              batch_j, &
                              req_0, &
                              req_1_i, &
                              req_1_j, &
                              req_2, &
                              'Reduced matrix construction 3')

         call this%construct_reduced_submatrix(batch_i, batch_j, c, d)

         call mem%batch_finalize()

      end if

      call timer%turn_off()

   end subroutine construct


   subroutine construct_reduced_submatrix(this, batch_i, batch_j, c, d)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2018-2020
      !!
      !! Constructs parts of the reduced matrix A_ij based on the prepared
      !! batching indices batch_i and batch_j.
      !!
      implicit none

      class(reduced_matrix_maker), intent(inout) :: this

      type(batching_index), intent(inout) :: batch_i, batch_j
      class(record_storer), intent(inout) :: c, d

      integer :: current_i_batch, current_j_batch

      real(dp), dimension(:, :), pointer, contiguous :: c_i, d_j

      call c%prepare_records([batch_i])
      call d%prepare_records([batch_j])

      do current_i_batch = 1, batch_i%num_batches

         call batch_i%determine_limits(current_i_batch)

         call c%load(c_i, batch_i)

         do current_j_batch = 1, batch_j%num_batches

            call batch_j%determine_limits(current_j_batch)

            call d%load(d_j, batch_j)

            call dgemm('T', &
                       'N', &
                       batch_i%length, &
                       batch_j%length, &
                       c%record_length, &
                       one, &
                       c_i, &
                       c%record_length, &
                       d_j, &
                       d%record_length, &
                       zero, &
                       this%matrix(batch_i%first, batch_j%first), &
                       this%dim)

         end do  ! end of j batches
      end do  ! end of i batches

      call c%free_records()
      call d%free_records()


   end subroutine construct_reduced_submatrix


end module reduced_matrix_maker_class

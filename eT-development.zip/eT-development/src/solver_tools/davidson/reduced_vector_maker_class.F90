

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module reduced_vector_maker_class

   !!
   !! Reduced vector maker class module
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, and Alexander C. Paul, 2018-2023
   !!
   !! Constructs a reduced space vector from a reduced space, c, and a set of full space vector(s), F:
   !!
   !! A_i = c_i^T F
   !!

   use parameters

   use abstract_reduced_matrix_maker_class, only: abstract_reduced_matrix_maker
   use record_storer_class, only: record_storer
   use memory_manager_class, only: mem
   use batching_index_class, only: batching_index
   use timings_class, only: timings

   type, extends(abstract_reduced_matrix_maker) :: reduced_vector_maker

      integer :: n_vectors

   contains

      procedure, public :: construct

   end type reduced_vector_maker


   interface reduced_vector_maker

      procedure :: new_reduced_vector_maker

   end interface reduced_vector_maker


contains


   function new_reduced_vector_maker(n_vectors) result(this)
      !!
      !! New eigen Davidson tool
      !!
      implicit none

      type(reduced_vector_maker) :: this
      integer, intent(in) :: n_vectors

      this%dim = 0
      this%n_vectors = n_vectors

   end function new_reduced_vector_maker


   subroutine construct(this, c, F)
      !!
      !! Construct reduced matrix
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, Aug 2018 - Mar 2023
      !!
      !! Constructs the reduced matrix
      !!
      !!    F_i = c_i^T F.
      !!
      !! Elements computed in previous iterations are not recomputed.
      !!
      implicit none

      class(reduced_vector_maker), intent(inout) :: this

      class(record_storer), intent(inout) :: c
      real(dp), dimension(c%record_length, this%n_vectors), intent(in) :: F

      real(dp), dimension(:, :), allocatable :: matrix_copy
      real(dp), dimension(:, :), pointer, contiguous :: c_i

      integer :: current_i_batch, req_0, req_1, n_new_vectors, n_old_vectors, i

      type(batching_index), allocatable :: batch_i

      type(timings), allocatable :: timer

      timer = timings('Reduced vector maker: time to construct reduced vector', 'v')
      call timer%turn_on()

      ! Prepare reduced F by allocating over copying previously calculated elements

      n_new_vectors = c%n_written_records - this%dim
      n_old_vectors = this%dim

      this%dim = c%n_written_records

      if (n_old_vectors == 0) then

         call mem%alloc(this%matrix, this%dim, this%n_vectors)

      else

         ! Not first iteration. Copy over previously calculated elements.

         call mem%alloc(matrix_copy, n_old_vectors, this%n_vectors)

         call dcopy(n_old_vectors * this%n_vectors, this%matrix, 1, matrix_copy, 1)

         call mem%dealloc(this%matrix)

         call mem%alloc(this%matrix, this%dim, this%n_vectors)

         do i = 1, this%n_vectors
            call dcopy(n_old_vectors, matrix_copy(1, i), 1, this%matrix(1, i), 1)
         end do

         call mem%dealloc(matrix_copy)

      end if

      ! Set up batching of trial vectors to compute new elements to the gradient

      req_0 = 0
      req_1 = c%required_to_load_record()

      batch_i = batching_index(dimension_=n_new_vectors, offset=n_old_vectors)

      call mem%batch_setup(batch_i, req_0, req_1, 'construct_reduced_gradient')

      call c%prepare_records([batch_i])

      do current_i_batch = 1, batch_i%num_batches

         call batch_i%determine_limits(current_i_batch)

         call c%load(c_i, batch_i)


         call dgemm('T', &
                    'N', &
                    batch_i%length, &
                    this%n_vectors, &
                    c%record_length, &
                    one, &
                    c_i, &
                    c%record_length, &
                    F, &
                    c%record_length, &
                    one, &
                    this%matrix(batch_i%first, 1), &
                    this%dim)

      end do

      call mem%batch_finalize()
      call c%free_records()
      call timer%turn_off()

   end subroutine construct


end module reduced_vector_maker_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module linear_davidson_print_tool_class

   !!
   !! Linear Davidson print tool class module
   !! Written by Regina Matveeva, Dec 2021
   !!

   use kinds
   use global_out, only: output

   implicit none

   type, abstract :: linear_davidson_print_tool

      character(len=1) :: print_level

   contains

      procedure, public, nopass :: print_banner => print_banner_linear_davidson_print_tool

      procedure(print_iteration_header), deferred, public :: print_iteration_header
      procedure(print_iteration_footer), deferred, public :: print_iteration_footer
      procedure(print_iteration), deferred, public :: print_iteration

   end type linear_davidson_print_tool

   abstract interface

      subroutine print_iteration_header(this)

         import linear_davidson_print_tool

         implicit none
         class(linear_davidson_print_tool), intent(in) :: this

      end subroutine print_iteration_header


      subroutine print_iteration_footer(this)

         import linear_davidson_print_tool

         implicit none
         class(linear_davidson_print_tool), intent(in) :: this

      end subroutine print_iteration_footer


      subroutine print_iteration(this, &
                                 n_solutions, &
                                 residual_norm, &
                                 iteration, &
                                 frequencies, &
                                 reduced_dimension)

         use kinds
         import linear_davidson_print_tool

         implicit none
         class(linear_davidson_print_tool), intent(in) :: this

         integer, intent(in) :: n_solutions, iteration, reduced_dimension
         real(dp), dimension(n_solutions), intent(in) :: residual_norm, frequencies

      end subroutine print_iteration

   end interface

contains

   subroutine print_banner_linear_davidson_print_tool()
      !!
      !! Written by Regina Matveeva, Dec 2021
      !!
      implicit none

      character(len=100) :: name_
      character(len=500) :: description

      name_ = 'Davidson linear equation solver'

      description = &
         'A Davidson solver that solves a linear equation: (A - freq_k) X_k = F. This equation is solved in a&
         & reduced space. A description of the algorithm can be found in E. R. Davidson, J. Comput. Phys. 17,&
         & 87 (1975).'

      call output%printf('m', ' - ' // trim(name_), fs='(/t3,a)')
      call output%print_separator('m', len_trim(name_) + 6, '-')

      call output%printf('m', description, ffs='(/t3,a)', fs='(t3,a)')

   end subroutine print_banner_linear_davidson_print_tool


end module linear_davidson_print_tool_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module reduced_space_class

   !!
   !! Reduced space class module
   !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, and Alexander C. Paul, 2018-2023
   !!

   use parameters

   use record_storer_class, only: record_storer

   use range_class, only: range_
   use memory_manager_class, only: mem
   use global_out, only: output
   use batching_index_class, only: batching_index
   use timings_class, only: timings

   type, extends(record_storer) :: reduced_space

      integer, private :: n_orthonormalizations
      real(dp), public :: linear_dependence_threshold

   contains

      procedure, public :: orthonormalize_and_add_vectors
      procedure, public :: orthonormalize
      procedure, public :: set_linear_dependence_threshold
      procedure, public :: get_max_reduced_dimension
      procedure, public :: get_vector
      procedure, public :: set_vector
      procedure, public :: get_dim

   end type reduced_space

   interface reduced_space

      procedure :: new_reduced_space
      procedure :: new_reduced_space_no_orthonormalization

   end interface reduced_space


contains


   function new_reduced_space(name_, &
                              record_length, &
                              max_n_records, &
                              records_in_mem, &
                              n_orthonormalizations, &
                              linear_dependence_threshold) result(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      type(reduced_space) :: this

      integer, intent(in) :: n_orthonormalizations
      real(dp), intent(in) :: linear_dependence_threshold

      character(len=*), intent(in) :: name_

      integer, intent(in) :: record_length
      integer, intent(in) :: max_n_records
      logical, intent(in) :: records_in_mem

      call this%set_basic_variables(name_, records_in_mem)

      this%record_length = record_length
      this%max_n_records = max_n_records

      this%n_blocks = 0

      this%n_orthonormalizations = n_orthonormalizations
      this%linear_dependence_threshold = linear_dependence_threshold

   end function new_reduced_space


   function new_reduced_space_no_orthonormalization(name_, &
                                                    record_length, &
                                                    max_n_records, &
                                                    records_in_mem) result(this)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      type(reduced_space) :: this

      character(len=*), intent(in) :: name_

      integer, intent(in) :: record_length
      integer, intent(in) :: max_n_records
      logical, intent(in) :: records_in_mem

      call this%set_basic_variables(name_, records_in_mem)

      this%record_length = record_length
      this%max_n_records = max_n_records

      this%n_blocks = 0

      this%n_orthonormalizations = 0
      this%linear_dependence_threshold = 1.0d-20

   end function new_reduced_space_no_orthonormalization


   subroutine orthonormalize_and_add_vectors(this, n_new_vectors, c_new)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2019-2023
      !!
      !! Orthonormalizes the new trial vectors against the existing
      !! trial vectors using the modified Gram-Schmidt (MGS) procedure.
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(reduced_space), intent(inout) :: this

      integer, intent(in) :: n_new_vectors

      real(dp), dimension(this%record_length, n_new_vectors), intent(inout) :: c_new

      real(dp), dimension(:, :), pointer, contiguous :: c_i

      real(dp) :: norm_c_new, r_ji, ddot

      integer :: i, j, k, req_0, req_1_i, n_old_vectors

      integer :: current_i_batch

      type(batching_index), allocatable :: batch_i

      type(timings), allocatable :: timer

      logical :: perform_batching
      integer(i64) :: memory_needed
      character(len=17) :: memory_needed_char, additional_memory_char

      timer = timings('Reduced vector extender: orthonormalization of new vectors', 'v')
      call timer%turn_on()

      req_0 = 0
      req_1_i = this%required_to_load_record()

      n_old_vectors = this%n_written_records

      memory_needed = (min(n_old_vectors, 1)) * this%record_length * dp

      perform_batching = .true.
      if (memory_needed <= mem%get_available()) then

         ! Can keep all new vectors and at least one old vector
         ! => hold all new vectors (j) & batch over old vectors (i)

         call output%printf('debug', &
                            'Reduced space extender orthogonalization: batching over old vectors')


         batch_i = batching_index(dimension_=n_old_vectors, offset=0)

         if (batch_i%index_dimension == 0) then

            ! No old vectors; no batches over i

            call batch_i%do_not_batch()
            perform_batching = .false.

         else

            ! Set up batching over old vectors i

            req_0 = 0
            call mem%batch_setup(batch_i, req_0, req_1_i, 'orthonormalize_trial_vecs')

         end if

      else

         call output%printf('m', &
                            'Davidson orthogonalization: Not enough memory to hold (i0) new trials and at&
                            & least one old trial.', &
                            ints=[n_new_vectors])

         memory_needed = this%record_length * dp
         memory_needed_char = mem%get_memory_as_character(memory_needed)
         additional_memory_char = mem%get_memory_as_character(memory_needed - mem%get_available())

         call output%error_msg("Require total memory of (a0) - missing (a0).", &
                               chars=[trim(memory_needed_char), trim(additional_memory_char)])

      end if

      ! Modified Gram-Schmidt loops

      do k = 1, this%n_orthonormalizations

         if (perform_batching) then

            ! Remove components along old vectors for all new vectors

            call this%prepare_records([batch_i])

            do current_i_batch = 1, batch_i%num_batches

               call batch_i%determine_limits(current_i_batch)

               call this%load(c_i, batch_i)

               ! Remove i components along j vectors

               do j = 1, n_new_vectors
                  do i = batch_i%first, batch_i%get_last()

                     r_ji = ddot(this%record_length, &
                                 c_new(:, j), &
                                 1, &
                                 c_i(:, i - batch_i%first + 1), &
                                 1)

                     call daxpy(this%record_length, &
                                - r_ji, &
                                c_i(:, i - batch_i%first + 1), &
                                1, &
                                c_new(:, j), &
                                1)

                  end do
               end do
            end do  ! end of i batches

            call this%free_records()

         end if

         ! Remove components within the j batch and normalize

         do j = 1, n_new_vectors

            do i = 1, j - 1

               r_ji = ddot(this%record_length, &
                           c_new(:, j), &
                           1, &
                           c_new(:, i), &
                           1)

               call daxpy(this%record_length, &
                          - r_ji, &
                          c_new(:, i), &
                          1, &
                          c_new(:, j), &
                          1)

            end do

            norm_c_new = get_l2_norm(c_new(:, j), this%record_length)

            if (norm_c_new < this%linear_dependence_threshold) &
               call output%warning_msg( &
                       'detected linear dependence. Will not add new vector to reduced space.' &
                    )

            call dscal(this%record_length, one / norm_c_new, c_new(:, j), 1)

         end do

         ! Make sure the normalized batch of j vectors are stored

         call this%copy_record_in(c_new, range_(n_old_vectors + 1, n_new_vectors))

      end do  ! end of normalization loops

      if (perform_batching) call mem%batch_finalize()

      call timer%turn_off()

   end subroutine orthonormalize_and_add_vectors


   subroutine orthonormalize(this)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2019-2023
      !!
      !! Note: orthonormalizes in memory
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(reduced_space), intent(inout) :: this

      real(dp), dimension(:, :), pointer, contiguous :: c_i

      real(dp) :: norm_c_new, r_ji, ddot

      integer :: i, j, k, n_vectors

      type(batching_index), allocatable :: batch_i

      type(timings), allocatable :: timer

      timer = timings('Reduced vector extender: orthonormalization of start', 'v')
      call timer%turn_on()

      n_vectors = this%n_written_records

      batch_i = batching_index(dimension_=n_vectors, offset=0)
      call batch_i%do_single_batch()

      ! Modified Gram-Schmidt loops
      do k = 1, this%n_orthonormalizations

         call this%prepare_records([batch_i])
         call this%load(c_i, batch_i)

         ! Remove i components along j vectors
         do j = 1, n_vectors
            do i = 1, j - 1

               r_ji = ddot(this%record_length, &
                           c_i(:, j), &
                           1, &
                           c_i(:, i), &
                           1)

               call daxpy(this%record_length, &
                          - r_ji, &
                          c_i(:, i), &
                          1, &
                          c_i(:, j), &
                          1)

            end do

            norm_c_new = get_l2_norm(c_i(:, j), this%record_length)

            if (norm_c_new < this%linear_dependence_threshold) &
               call output%error_msg('detected linear dependence in start vectors.')

            call dscal(this%record_length, one / norm_c_new, c_i(:, j), 1)
            call this%store(c_i, batch_i)

         end do

         call this%free_records()

      end do  ! end of normalization loops

      call timer%turn_off()

   end subroutine orthonormalize


   subroutine set_linear_dependence_threshold(this, linear_dependence_threshold)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(reduced_space), intent(inout) :: this
      real(dp), intent(in) :: linear_dependence_threshold
      this%linear_dependence_threshold = linear_dependence_threshold

   end subroutine set_linear_dependence_threshold


   pure function get_max_reduced_dimension(this) result(dim_)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      implicit none

      class(reduced_space), intent(in) :: this
      integer :: dim_

      dim_ = this%max_n_records

   end function get_max_reduced_dimension


   subroutine set_vector(this, vector, n)
      !!
      !!
      implicit none

      class(reduced_space), intent(inout) :: this
      real(dp), dimension(this%record_length), intent(in) :: vector
      integer, intent(in) :: n

      call this%copy_record_in(vector, n)

   end subroutine set_vector


   subroutine get_vector(this, vector, n)
      !!
      !!
      implicit none

      class(reduced_space), intent(inout) :: this
      real(dp), dimension(this%record_length), intent(out) :: vector
      integer, intent(in) :: n

      call this%copy_record_out(vector, n)

   end subroutine get_vector


   pure function get_dim(this) result(dim)
      !!
      !!
      implicit none

      class(reduced_space), intent(in) :: this
      integer :: dim

      dim = this%n_written_records

   end function get_dim
end module reduced_space_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module trust_region_print_tool_class

   !!
   !! Trust region print tool class module
   !! Written by Regina Matveeva, Dec 2021
   !!

   use parameters
   use global_out, only: output

   implicit none

   type :: trust_region_print_tool

      integer :: max_iterations

   contains

      procedure, public, nopass :: print_macro_iteration_heading => &
                                   print_macro_iteration_heading_trust_region_print_tool
      procedure, public, nopass :: print_macro_iteration => print_macro_iteration_trust_region_print_tool
      procedure, public :: print_settings => print_settings_trust_region_print_tool
      procedure, public, nopass :: print_summary => print_summary_trust_region_print_tool

   end type trust_region_print_tool


   interface trust_region_print_tool

      procedure :: new_trust_region_print_tool

   end interface trust_region_print_tool

contains


   function new_trust_region_print_tool(max_iterations) result(this)
      !!
      !! Written by Regina Matveeva, Dec 2021
      !!
      implicit none

      integer, intent(in) :: max_iterations

      type(trust_region_print_tool) :: this

      this%max_iterations = max_iterations

   end function new_trust_region_print_tool


   subroutine print_macro_iteration_heading_trust_region_print_tool()
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      use global_out, only: output
      implicit none

      call output%printf('n', &
                         'Iter.   Step length      Energy (a.u.)       Max(grad.)     Delta E (a.u.)   Level&
                         & shift    #micro', &
                         fs='(/t3,a)', &
                         ll=120)

      call output%print_separator('n', 98, '-')

   end subroutine print_macro_iteration_heading_trust_region_print_tool


   subroutine print_macro_iteration_trust_region_print_tool(macro_iteration, &
                                                            step_length, &
                                                            functional_value, &
                                                            previous_functional_value, &
                                                            max_gradient, &
                                                            n_micro, &
                                                            level_shift)
      !!
      !! Written by Sarai D. Folkestad
      !!
      implicit none

      integer, intent(in) :: macro_iteration, n_micro
      real(dp), intent(in) :: functional_value
      real(dp), intent(in) :: previous_functional_value
      real(dp), intent(in) :: max_gradient
      real(dp), intent(in) :: step_length
      real(dp), dimension(1), intent(in) :: level_shift

      call output%printf('n', &
                         '(i4)     (e10.4) (f20.12)    (e11.4)    (e11.4)     (e11.3)     (i4)', &
                         ints=[macro_iteration, n_micro], &
                         reals=[step_length, &
                            functional_value, &
                            max_gradient, &
                            abs(functional_value - previous_functional_value), &
                            level_shift], &
                         fs='(t3,a)', &
                         ll=120)

   end subroutine print_macro_iteration_trust_region_print_tool


   subroutine print_summary_trust_region_print_tool(macro_iteration, converged)
      !!
      !! Written by Sarai D. Folkestad
      !!
      implicit none

      integer, intent(in) :: macro_iteration
      logical, intent(in) :: converged

      call output%print_separator('n', 98, '-')

      if (converged) then

         call output%printf('n', 'Convergence criterion met in (i0) iterations!', ints=[macro_iteration])

      else

         call output%error_msg( &
                 'Was not able to converge the equations in the given number of maximum iterations.' &
              )

      end if

   end subroutine print_summary_trust_region_print_tool


   subroutine print_settings_trust_region_print_tool(this)
      !!
      !! Written by Sarai D. Folkestad
      !!
      implicit none

      class(trust_region_print_tool), intent(in) :: this

      call output%printf('m', '- Trust region solver settings:', fs='(/t3,a)')

      call output%printf('m', &
                         'Maximum iterations:           (i11)', &
                         ints=[this%max_iterations], &
                         fs='(t6,a)')

   end subroutine print_settings_trust_region_print_tool


end module trust_region_print_tool_class

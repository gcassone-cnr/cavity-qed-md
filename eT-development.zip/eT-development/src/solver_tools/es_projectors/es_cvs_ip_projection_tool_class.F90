

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module es_cvs_ip_projection_tool_class

   !!
   !! Excited state CVS IP projection tool class module
   !! Written by Alexander C. Paul, Sarai D. Folkestad, 2020
   !!

   use abstract_projection_tool_class, only: abstract_projection_tool
   use kinds, only: dp
   use ccs_class, only: ccs

   implicit none

   type, extends(abstract_projection_tool) :: es_cvs_ip_projection_tool

      class(ccs), pointer, private :: wf

   contains

      procedure :: project => project_es_cvs_ip_projection_tool

   end type es_cvs_ip_projection_tool


   interface es_cvs_ip_projection_tool

      procedure :: new_es_cvs_ip_projection_tool

   end interface es_cvs_ip_projection_tool


contains


   function new_es_cvs_ip_projection_tool(wf) result(tool)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      implicit none

      type(es_cvs_ip_projection_tool) :: tool

      class(ccs), target :: wf

      tool%n_parameters = wf%n_es_amplitudes

      tool%wf => wf

   end function new_es_cvs_ip_projection_tool


   subroutine project_es_cvs_ip_projection_tool(this, vector)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      implicit none

      class(es_cvs_ip_projection_tool), intent(in) :: this
      real(dp), dimension(this%n_parameters), intent(inout) :: vector

      call this%wf%cvs_ip_projection(vector)

   end subroutine project_es_cvs_ip_projection_tool


end module es_cvs_ip_projection_tool_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module es_ea_projection_tool_class

   !!
   !! Excited state EA projection tool class module
   !! Written by Marcus T. Lexander, Ylva Os, 2024
   !!

   use abstract_projection_tool_class, only: abstract_projection_tool
   use kinds, only: dp
   use ccs_class, only: ccs

   implicit none

   type, extends(abstract_projection_tool) :: es_ea_projection_tool

      class(ccs), pointer, private :: wf

   contains


      procedure :: project => project_es_ea_projection_tool


   end type es_ea_projection_tool


   interface es_ea_projection_tool

      procedure :: new_es_ea_projection_tool

   end interface es_ea_projection_tool


contains


   function new_es_ea_projection_tool(wf) result(this)
      !!
      !! Written by Marcus T. Lexander, Ylva Os, 2024
      !!
      implicit none

      type(es_ea_projection_tool) :: this

      class(ccs), target :: wf

      this%n_parameters = wf%n_es_amplitudes

      this%wf => wf

   end function new_es_ea_projection_tool


   subroutine project_es_ea_projection_tool(this, vector)
      !!
      !! Written by Marcus T. Lexander, Ylva Os, 2024
      !!
      implicit none

      class(es_ea_projection_tool), intent(in) :: this
      real(dp), dimension(this%n_parameters), intent(inout) :: vector

      call this%wf%ea_projection(vector)

   end subroutine project_es_ea_projection_tool


end module es_ea_projection_tool_class

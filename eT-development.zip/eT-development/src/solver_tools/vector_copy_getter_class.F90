

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module vector_copy_getter_class

   !!
   !! Vector copy getter tool
   !! Written by Eirik Kjoenstad, Oct 2022
   !!
   !! Tool is set up with a pointer to some vectors
   !! which can be copied out using the get routine
   !!

   use parameters
   use vector_getter_class, only: vector_getter

   implicit none

   type, extends(vector_getter) :: vector_copy_getter

      real(dp), dimension(:, :), pointer, contiguous :: vectors

   contains

      procedure, public :: get => get_vector_copy_getter

   end type vector_copy_getter


   interface vector_copy_getter

      procedure :: new_vector_copy_getter

   end interface vector_copy_getter


contains

   function new_vector_copy_getter(n_parameters, n_vectors, vectors) result(this)
      !!
      !! Written by Eirik Kjoenstad, Oct 2022
      !!
      implicit none

      type(vector_copy_getter) :: this

      integer, intent(in) :: n_parameters, n_vectors

      real(dp), dimension(n_parameters * n_vectors), intent(in), target :: vectors

      this%n_parameters = n_parameters
      this%n_vectors = n_vectors

      this%vectors(1:n_parameters, 1:n_vectors) => vectors

   end function new_vector_copy_getter


   subroutine get_vector_copy_getter(this, vectors)
      !!
      !! Written by Eirik Kjoenstad, Oct 2022
      !!
      implicit none

      class(vector_copy_getter), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      call dcopy(this%n_parameters * this%n_vectors, this%vectors, 1, vectors, 1)

   end subroutine get_vector_copy_getter


end module vector_copy_getter_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module elementary_tdeomcc_state_class

   !!
   !! Elementary TD-EOM-CC state class
   !! Written by Andreas S. Skeidsvoll, Nov 2020
   !!
   !! In elementary basis TD-EOM-CC, time-dependent right and left state
   !! coefficients evolve according to the equation
   !!
   !!    d/dt r_mu(t)    = -i H_mu nu(t) r_nu
   !!    d/dt l_nu(t)    = -i l_mu H_mu nu(t)
   !!
   !! The right and left coefficients are linear (CI) expansion coefficients.
   !!

   use parameters
   use memory_manager_class, only: mem
   use ccs_class, only: ccs
   use electric_field_class, only: electric_field
   use array_utilities, only: zdotu_
   use array_initialization, only: zero_array_complex, zero_array
   use global_out, only: output
   use td_state_class, only: td_state
   use amplitude_file_storer_class, only: amplitude_file_storer

   implicit none

   type, extends(td_state) :: elementary_tdeomcc_state

      class(ccs), pointer :: wf

      real(dp), dimension(:, :, :), allocatable :: dipole_integrals_t1
      real(dp), dimension(:, :), allocatable :: xiX, etaX_ref, V
      real(dp), dimension(:), allocatable :: xiV, eta, etaH
      real(dp), dimension(3) :: two_trace_X_oo
      real(dp) :: two_trace_V_oo

      complex(dp), dimension(:), pointer :: td_left, td_right

   contains

      procedure, public :: initialize => initialize_elementary_tdeomcc_state
      procedure, public :: cleanup => cleanup_elementary_tdeomcc_state

      procedure, public :: update => update_elementary_tdeomcc_state

      procedure, public :: construct_time_derivative => construct_time_derivative_elementary_tdeomcc_state

      procedure, public :: calculate_energy => calculate_energy_elementary_tdeomcc_state
      procedure, public :: calculate_dipole_moment => calculate_dipole_moment_elementary_tdeomcc_state
      procedure, public :: calculate_mo_density_matrix => calculate_mo_density_matrix_elementary_tdeomcc_state

      procedure, private :: calculate_mo_density_matrix_t1_term => &
                            calculate_mo_density_matrix_t1_term_elementary_tdeomcc_state

      procedure, private :: calculate_dipole_moment_no_density => &
                            calculate_dipole_moment_no_density_elementary_tdeomcc_state

      procedure, private :: update_interaction_term_arrays => &
                            update_interaction_term_arrays_elementary_tdeomcc_state

      procedure, private :: shifted_H_transformation => shifted_H_transformation_elementary_tdeomcc_state
      procedure, private :: shifted_H_transpose_transformation => &
                            shifted_H_transpose_transformation_elementary_tdeomcc_state

   end type elementary_tdeomcc_state


   interface elementary_tdeomcc_state

      procedure :: new_elementary_tdeomcc_state

   end interface elementary_tdeomcc_state


contains


   function new_elementary_tdeomcc_state(wf, field, mo_density_matrix_required, restart) result(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      implicit none

      class(ccs), target :: wf
      class(electric_field), target :: field

      type(elementary_tdeomcc_state) :: this

      logical, intent(in) :: mo_density_matrix_required, restart

      this%wf => wf
      this%field => field

      this%mo_density_matrix_required = mo_density_matrix_required
      this%restart = restart

      this%n_td_parameters = 2 * (wf%n_gs_amplitudes + 1)
      this%n_mo = this%wf%n_mo

      this%name_ = 'elementary td-eom-cc'

   end function new_elementary_tdeomcc_state


   subroutine initialize_elementary_tdeomcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      use array_initialization, only: copy_subblock, zero_array_complex
      use range_class, only: range_
      use array_utilities, only: get_trace

      implicit none

      class(elementary_tdeomcc_state), intent(inout), target :: this

      real(dp), dimension(:, :), allocatable :: X_oo
      real(dp), dimension(:), allocatable :: multipliers
      real(dp) :: energy_real, energy_imag

      integer :: i, read_n

      real(dp), dimension(:, :, :), allocatable :: dipole_integrals_ao

      type(range_) :: o_range

      logical :: try_to_restart

      real(dp), dimension(:), allocatable :: real_t, imag_t

      call mem%alloc(this%td_parameters, this%n_td_parameters)

      this%td_right => this%td_parameters(1:this%n_td_parameters / 2)
      this%td_left => this%td_parameters(this%n_td_parameters / 2 + 1:this%n_td_parameters)

      this%real_state_storer = amplitude_file_storer('td_state_real', this%n_td_parameters)
      this%imag_state_storer = amplitude_file_storer('td_state_imag', this%n_td_parameters)

      try_to_restart = this%restart .and. this%real_state_storer%file_exists() .and. &
                       this%imag_state_storer%file_exists()

      if (try_to_restart) then

         call output%printf('m', 'Requested restart. Reading in solution from file.', fs='(/t3,a)')

         call mem%alloc(real_t, this%n_td_parameters)
         call mem%alloc(imag_t, this%n_td_parameters)

         call this%real_state_storer%read_(real_t, energy_real, read_n)
         if (read_n /= this%n_td_parameters) &
            call output%error_msg( &
                    'mismatch between number of parameters and read elements on td_state_real file' &
                 )

         call this%imag_state_storer%read_(imag_t, energy_imag, read_n)
         if (read_n /= this%n_td_parameters) &
            call output%error_msg( &
                    'mismatch between number of parameters and read elements on td_state_imag file' &
                 )

         this%td_parameters = cmplx(real_t, imag_t, dp)

         call mem%dealloc(real_t)
         call mem%dealloc(imag_t)

      else
         ! Start from the CC ground state

         this%td_right(1) = one_complex
         call zero_array_complex(this%td_right(2:this%n_td_parameters / 2), this%n_td_parameters / 2 - 1)

         this%td_left(1) = one_complex

         call mem%alloc(multipliers, this%wf%n_gs_amplitudes)
         call this%wf%get_multipliers(multipliers)

         this%td_left(2:this%n_td_parameters / 2) = cmplx(multipliers, zero, dp)

         call mem%dealloc(multipliers)

      end if

      ! Transform the AO integrals to the MO and t1-transformed bases

      call mem%alloc(dipole_integrals_ao, this%wf%ao%n, this%wf%ao%n, 3)

      call this%wf%ao%get_oei('dipole', dipole_integrals_ao)

      call mem%alloc(this%dipole_integrals, this%wf%n_mo, this%wf%n_mo, 3)
      call mem%alloc(this%dipole_integrals_t1, this%n_mo, this%n_mo, 3)

      do i = 1, 3

         call this%wf%mo_transform(dipole_integrals_ao(:, :, i), this%dipole_integrals(:, :, i))

         call dcopy(this%wf%n_mo**2, &
                    this%dipole_integrals(:, :, i), &
                    1, &
                    this%dipole_integrals_t1(:, :, i), &
                    1)

         call this%wf%t1_transform(this%dipole_integrals_t1(:, :, i))

      end do

      call mem%dealloc(dipole_integrals_ao)

      ! Construct other intermediates

      call mem%alloc(this%xiX, this%n_td_parameters / 2 - 1, 3)
      call mem%alloc(this%etaX_ref, this%wf%n_t1, 3, set_zero=.true.)

      o_range = range_(1, this%wf%n_o)

      call mem%alloc(X_oo, this%wf%n_o, this%wf%n_o)

      do i = 1, 3

         call this%wf%construct_xiX(this%dipole_integrals_t1(:, :, i), this%xiX(:, i))
         call this%wf%etaX_ref(this%dipole_integrals_t1(:, :, i), this%etaX_ref(:, i))

         call copy_subblock(this%dipole_integrals_t1(:, :, i), X_oo, o_range, o_range)

         this%two_trace_X_oo(i) = two * get_trace(X_oo, this%wf%n_o)

      end do

      call mem%dealloc(X_oo)

      call mem%alloc(this%xiV, this%n_td_parameters / 2 - 1)
      call mem%alloc(this%etaH, this%n_td_parameters / 2 - 1)

      call this%wf%construct_fock()
      call this%wf%calculate_energy()
      call this%wf%prepare_for_jacobian()
      call this%wf%prepare_for_jacobian_transpose()

      call mem%alloc(this%eta, this%n_td_parameters / 2 - 1)
      call this%wf%construct_eta(this%eta)

      call mem%alloc(this%V, this%n_mo, this%n_mo)

      if (this%mo_density_matrix_required) call mem%alloc(this%mo_density_matrix, this%n_mo, this%n_mo)

   end subroutine initialize_elementary_tdeomcc_state


   subroutine cleanup_elementary_tdeomcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      implicit none

      class(elementary_tdeomcc_state) :: this

      call mem%dealloc(this%td_parameters)

      call mem%dealloc(this%dipole_integrals)
      call mem%dealloc(this%dipole_integrals_t1)

      call mem%dealloc(this%V)
      call mem%dealloc(this%xiX)
      call mem%dealloc(this%xiV)

      call mem%dealloc(this%eta)
      call mem%dealloc(this%etaX_ref)
      call mem%dealloc(this%etaH)

      if (this%mo_density_matrix_required) call mem%dealloc(this%mo_density_matrix)

   end subroutine cleanup_elementary_tdeomcc_state


   subroutine update_elementary_tdeomcc_state(this, t)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      implicit none

      class(elementary_tdeomcc_state) :: this

      real(dp), intent(in) :: t

      call this%field%update(t)

      call this%update_interaction_term_arrays()

   end subroutine update_elementary_tdeomcc_state


   subroutine update_interaction_term_arrays_elementary_tdeomcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Apr 2021
      !!
      !! Update arrays taking part in the transformation by the time-dependent interaction term V(t)
      !! of the time-dependent Hamiltonian matrix H(t) = H_0 + V(t)
      !!
      implicit none

      class(elementary_tdeomcc_state) :: this

      integer :: i

      call zero_array(this%V, this%n_mo**2)
      call zero_array(this%xiV, this%n_td_parameters / 2 - 1)

      this%two_trace_V_oo = zero

      call dcopy(this%n_td_parameters / 2 - 1, this%eta, 1, this%etaH, 1)

      do i = 1, 3

         call daxpy(this%n_mo**2, &
                    - this%field%vector(i), &
                    this%dipole_integrals_t1(:, :, i), &
                    1, &
                    this%V, &
                    1)

         call daxpy(this%n_td_parameters / 2 - 1, - this%field%vector(i), this%xiX(:, i), 1, this%xiV, 1)

         call daxpy(this%wf%n_t1, - this%field%vector(i), this%etaX_ref(:, i), 1, this%etaH, 1)

         this%two_trace_V_oo = this%two_trace_V_oo - this%field%vector(i) * this%two_trace_X_oo(i)

      end do

   end subroutine update_interaction_term_arrays_elementary_tdeomcc_state


   subroutine construct_time_derivative_elementary_tdeomcc_state(this, ddt_parameters, t)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      !! Returns the complex time derivative of the elementary basis TD-EOM-CC state.
      !!
      implicit none

      class(elementary_tdeomcc_state) :: this

      complex(dp), dimension(this%n_td_parameters), intent(out) :: ddt_parameters
      real(dp), intent(in) :: t

      call this%update(t)

      ! dr(t)/dt = -i (H(t) - I <HF|e^(-T)H(t)e^T|HF>) r(t)

      call this%shifted_H_transformation(this%td_right, ddt_parameters(1:this%n_td_parameters / 2))

      call zscal(this%n_td_parameters / 2, - one_imag, ddt_parameters(1:this%n_td_parameters / 2), 1)

      ! dl(t)/dt = i l^T(t) (H(t) - I <HF|e^(-T)H(t)e^T|HF>)

      call this%shifted_H_transpose_transformation(this%td_left, &
                                                   ddt_parameters(this%n_td_parameters / 2 &
                                                      + 1:this%n_td_parameters))

      call zscal(this%n_td_parameters / 2, &
                 one_imag, &
                 ddt_parameters(this%n_td_parameters / 2 + 1:this%n_td_parameters), &
                 1)

   end subroutine construct_time_derivative_elementary_tdeomcc_state


   subroutine shifted_H_transformation_elementary_tdeomcc_state(this, c, H_c)
      !!
      !! Written by Andreas S. Skeidsvoll, Nov 2020
      !!
      !! Transforms right vector c by the time-dependent Hamiltonian matrix with
      !! the diagonal reference term removed (from global time-dependent phase).
      !!
      !!    (H c)_n = sum_n (H_mn - delta_mn <HF|e^(-T)He^T|HF>) c_n
      !!
      implicit none

      class(elementary_tdeomcc_state) :: this

      complex(dp), dimension(this%n_td_parameters / 2), intent(in) :: c
      complex(dp), dimension(this%n_td_parameters / 2), intent(out) :: H_c

      real(dp), dimension(:), allocatable :: excited_c_real, excited_c_imag, X_excited_c_real, &
                                             X_excited_c_imag

      real(dp), external :: ddot

      call zero_array_complex(H_c, this%n_td_parameters / 2)

      call mem%alloc(excited_c_real, this%n_td_parameters / 2 - 1)
      call mem%alloc(excited_c_imag, this%n_td_parameters / 2 - 1)

      excited_c_real = real(c(2:this%n_td_parameters / 2))
      excited_c_imag = aimag(c(2:this%n_td_parameters / 2))

      ! (H c)_0 = sum_mu eta^T_mu(t) r_mu(t)

      H_c(1) = cmplx(ddot(this%n_td_parameters / 2 - 1, this%etaH, 1, excited_c_real, 1), &
                     ddot(this%n_td_parameters / 2 - 1, this%etaH, 1, excited_c_imag, 1), &
                     dp)

      ! (H c)_mu = sum_nu A_mu,nu(t) c_nu(t) + xiV_mu(t) c_0(t)

      ! <nu|e^(-T)[H_0, tau_mu]e^T|HF> term of A_nu,mu(t)

      call mem%alloc(X_excited_c_real, this%n_td_parameters / 2 - 1)
      call this%wf%jacobian_transformation(excited_c_real, X_excited_c_real)

      call mem%alloc(X_excited_c_imag, this%n_td_parameters / 2 - 1)
      call this%wf%jacobian_transformation(excited_c_imag, X_excited_c_imag)

      call zaxpy(this%n_td_parameters / 2 - 1, &
                 one_complex, &
                 cmplx(X_excited_c_real, X_excited_c_imag, dp), &
                 1, &
                 H_c(2:this%n_td_parameters / 2), &
                 1)

      ! <nu|e^(-T)[V(t), tau_mu]e^T|HF> term of A_nu,mu(t)

      call this%wf%jacobianX_eom_transformation(excited_c_real, X_excited_c_real, this%V, this%xiV)
      call mem%dealloc(excited_c_real)

      call this%wf%jacobianX_eom_transformation(excited_c_imag, X_excited_c_imag, this%V, this%xiV)
      call mem%dealloc(excited_c_imag)

      call zaxpy(this%n_td_parameters / 2 - 1, &
                 one_complex, &
                 cmplx(X_excited_c_real, X_excited_c_imag, dp), &
                 1, &
                 H_c(2:this%n_td_parameters / 2), &
                 1)

      call mem%dealloc(X_excited_c_real)
      call mem%dealloc(X_excited_c_imag)

      call zaxpy(this%n_td_parameters / 2 - 1, &
                 c(1), &
                 cmplx(this%xiV, zero, dp), &
                 1, &
                 H_c(2:this%n_td_parameters / 2), &
                 1)

   end subroutine shifted_H_transformation_elementary_tdeomcc_state


   subroutine shifted_H_transpose_transformation_elementary_tdeomcc_state(this, c, c_H)
      !!
      !! Written by Andreas S. Skeidsvoll, Nov 2020
      !!
      !! Transforms left vector c by the transposed time-dependent Hamiltonian
      !! matrix with the diagonal reference term removed (from global
      !! time-dependent phase).
      !!
      !!    (H^T c)_m = (c^T (H - I <HF|e^(-T)He^T|HF>))_m
      !!              = sum_n c_n (H_nm - delta_mn <HF|e^(-T)He^T|HF>)
      !!
      implicit none

      class(elementary_tdeomcc_state) :: this

      complex(dp), dimension(this%n_td_parameters / 2), intent(in) :: c
      complex(dp), dimension(this%n_td_parameters / 2), intent(out) :: c_H

      real(dp), dimension(:), allocatable :: excited_c_real, excited_c_imag, excited_c_X_real, &
                                             excited_c_X_imag

      real(dp), external :: ddot

      call zero_array_complex(c_H, this%n_td_parameters / 2)

      call mem%alloc(excited_c_real, this%n_td_parameters / 2 - 1)
      call mem%alloc(excited_c_imag, this%n_td_parameters / 2 - 1)

      excited_c_real = real(c(2:this%n_td_parameters / 2))
      excited_c_imag = aimag(c(2:this%n_td_parameters / 2))

      ! (c H)_0 = sum_mu c_mu(t)(t) xiV_mu(t)

      c_H(1) = cmplx(ddot(this%n_td_parameters / 2 - 1, excited_c_real, 1, this%xiV, 1), &
                     ddot(this%n_td_parameters / 2 - 1, excited_c_imag, 1, this%xiV, 1), &
                     dp)

      ! (c H)_mu = sum_nu c_nu(t) A_nu,mu(t) + c_0(t) eta_mu(t)

      ! <nu|e^(-T)[H_0, tau_mu]e^T|HF> term of A_nu,mu(t)

      call mem%alloc(excited_c_X_real, this%n_td_parameters / 2 - 1)
      call this%wf%jacobian_transpose_transformation(excited_c_real, excited_c_X_real)

      call mem%alloc(excited_c_X_imag, this%n_td_parameters / 2 - 1)
      call this%wf%jacobian_transpose_transformation(excited_c_imag, excited_c_X_imag)

      call zaxpy(this%n_td_parameters / 2 - 1, &
                 one_complex, &
                 cmplx(excited_c_X_real, excited_c_X_imag, dp), &
                 1, &
                 c_H(2:this%n_td_parameters / 2), &
                 1)

      ! <nu|e^(-T)[V(t), tau_mu]e^T|HF> term of A_nu,mu(t)

      call this%wf%jacobianX_eom_transpose_transformation(excited_c_real, &
                                                          excited_c_X_real, &
                                                          this%V, &
                                                          this%xiV)

      call mem%dealloc(excited_c_real)

      call this%wf%jacobianX_eom_transpose_transformation(excited_c_imag, &
                                                          excited_c_X_imag, &
                                                          this%V, &
                                                          this%xiV)

      call mem%dealloc(excited_c_imag)

      call zaxpy(this%n_td_parameters / 2 - 1, &
                 one_complex, &
                 cmplx(excited_c_X_real, excited_c_X_imag, dp), &
                 1, &
                 c_H(2:this%n_td_parameters / 2), &
                 1)

      call mem%dealloc(excited_c_X_real)
      call mem%dealloc(excited_c_X_imag)

      call zaxpy(this%n_td_parameters / 2 - 1, &
                 c(1), &
                 cmplx(this%etaH, zero, dp), &
                 1, &
                 c_H(2:this%n_td_parameters / 2), &
                 1)

   end subroutine shifted_H_transpose_transformation_elementary_tdeomcc_state


   subroutine calculate_energy_elementary_tdeomcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      implicit none

      class(elementary_tdeomcc_state) :: this

      complex(dp), dimension(:), allocatable :: H_c

      ! Calculate l(t) H(t) r(t)

      call mem%alloc(H_c, this%n_td_parameters / 2)

      ! Shifted Hamiltonian elements are H_nm - delta_mn <HF|e^(-T)He^T|HF>

      call this%shifted_H_transformation(this%td_right, H_c)

      ! Add delta_mn <HF|e^(-T)He^T|HF>

      call zaxpy(this%n_td_parameters / 2, &
                 cmplx(this%wf%energy + this%two_trace_V_oo, zero, dp), &
                 this%td_parameters(1:this%n_td_parameters / 2), &
                 1, &
                 H_c, &
                 1)

      this%energy = zdotu_(this%n_td_parameters / 2, this%td_left, 1, H_c, 1)

      call mem%dealloc(H_c)

   end subroutine calculate_energy_elementary_tdeomcc_state


   subroutine calculate_dipole_moment_elementary_tdeomcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      !! Calculates the time-dependent dipole moment.
      !!
      implicit none

      class(elementary_tdeomcc_state) :: this

      if (this%mo_density_matrix_required) then

         call this%calculate_dipole_moment_from_mo_density_matrix(this%wf%get_nuclear_dipole())

      else

         call this%calculate_dipole_moment_no_density()

      end if

   end subroutine calculate_dipole_moment_elementary_tdeomcc_state


   subroutine calculate_mo_density_matrix_t1_term_elementary_tdeomcc_state(this, &
                                                                           mo_density_matrix_term, &
                                                                           td_parameters_left, &
                                                                           td_parameters_right)
      !!
      !! Written by Andreas S. Skeidsvoll, Jun 2021
      !!
      !! Calculates a real term of the time-dependent density
      !!

      use state_descriptor_class, only: state_descriptor
      implicit none

      class(elementary_tdeomcc_state) :: this
      real(dp), dimension(this%n_mo, this%n_mo), intent(out) :: mo_density_matrix_term
      real(dp), dimension(this%n_td_parameters / 2), intent(in) :: td_parameters_left, td_parameters_right

      real(dp), dimension(:, :), allocatable :: intermediate
      real(dp) :: minus_LR

      type(state_descriptor), allocatable :: descriptor_L, descriptor_R

      call zero_array(mo_density_matrix_term, this%n_mo**2)

      ! Reference-reference part

      call this%wf%density_ccs_ref_ref_oo(mo_density_matrix_term)

      call dscal(this%n_mo**2, &
                 td_parameters_left(1) * td_parameters_right(1), &
                 mo_density_matrix_term, &
                 1)

      ! Reference-excited part

      descriptor_L = state_descriptor('left', &
                                      .false., &
                                      .false., &
                                      .false., &
                                      .false., &
                                      'singlet')
      descriptor_R = state_descriptor('right', &
                                      .false., &
                                      .false., &
                                      .false., &
                                      .false., &
                                      'singlet')

      call this%wf%density_ccs_ref_mu_ov(mo_density_matrix_term, &
                                         td_parameters_right(2:this%n_td_parameters / 2), &
                                         td_parameters_left(1))

      ! Excited-reference part

      call mem%alloc(intermediate, this%n_mo, this%n_mo)

      call this%wf%mu_ref_density_terms(intermediate, &
                                        0, &
                                        td_parameters_left(2:this%n_td_parameters / 2), &
                                        descriptor_L)

      call this%wf%density_mu_ref(mo_density_matrix_term, intermediate, td_parameters_right(1))

      ! Excited-excited part

      call this%wf%mu_nu_density_terms(intermediate, &
                                       0, &
                                       td_parameters_left(2:this%n_td_parameters / 2), &
                                       0, &
                                       minus_LR, &
                                       td_parameters_right(2:this%n_td_parameters / 2), &
                                       descriptor_L, &
                                       descriptor_R)

      call this%wf%density_mu_mu_oo(intermediate, - minus_LR)

      call daxpy(this%n_mo**2, one, intermediate, 1, mo_density_matrix_term, 1)

      call mem%dealloc(intermediate)

   end subroutine calculate_mo_density_matrix_t1_term_elementary_tdeomcc_state


   subroutine calculate_mo_density_matrix_elementary_tdeomcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Jan 2023
      !!
      !! Calculates the complex time-dependent density matrix
      !!
      !!    D^R_pq(t) = <L(t)| E_pq |R(t)>
      !!
      !! in the real t1 basis, and transforms it to the MO basis.
      !!
      implicit none

      class(elementary_tdeomcc_state) :: this


      real(dp), dimension(:, :), allocatable :: mo_density_matrix_term
      real(dp), dimension(:, :), allocatable :: mo_density_matrix_real, mo_density_matrix_imag

      call mem%alloc(mo_density_matrix_term, this%n_mo, this%n_mo)

      ! Real-real term

      call this%calculate_mo_density_matrix_t1_term(mo_density_matrix_term, &
                                                    real(this%td_left), &
                                                    real(this%td_right))

      call mem%alloc(mo_density_matrix_real, this%n_mo, this%n_mo)
      call dcopy(this%n_mo**2, mo_density_matrix_term, 1, mo_density_matrix_real, 1)

      ! Imaginary-imaginary term

      call this%calculate_mo_density_matrix_t1_term(mo_density_matrix_term, &
                                                    aimag(this%td_left), &
                                                    aimag(this%td_right))

      call daxpy(this%n_mo**2, - one, mo_density_matrix_term, 1, mo_density_matrix_real, 1)

      ! Real-imaginary term

      call this%calculate_mo_density_matrix_t1_term(mo_density_matrix_term, &
                                                    real(this%td_left), &
                                                    aimag(this%td_right))

      call mem%alloc(mo_density_matrix_imag, this%n_mo, this%n_mo)
      call dcopy(this%n_mo**2, mo_density_matrix_term, 1, mo_density_matrix_imag, 1)

      ! Imaginary-real term

      call this%calculate_mo_density_matrix_t1_term(mo_density_matrix_term, &
                                                    aimag(this%td_left), &
                                                    real(this%td_right))

      call daxpy(this%n_mo**2, one, mo_density_matrix_term, 1, mo_density_matrix_imag, 1)

      call mem%dealloc(mo_density_matrix_term)

      call this%wf%add_t1_terms(mo_density_matrix_real)
      call this%wf%add_t1_terms(mo_density_matrix_imag)

      this%mo_density_matrix = cmplx(mo_density_matrix_real, mo_density_matrix_imag, dp)

      call mem%dealloc(mo_density_matrix_real)
      call mem%dealloc(mo_density_matrix_imag)

   end subroutine calculate_mo_density_matrix_elementary_tdeomcc_state


   subroutine calculate_dipole_moment_no_density_elementary_tdeomcc_state(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Jan 2023
      !!
      implicit none

      class(elementary_tdeomcc_state) :: this

      real(dp), dimension(3) :: nuclear

      real(dp), dimension(:), allocatable :: X_R_real, X_R_imag
      complex(dp), dimension(:), allocatable :: X_R

      real(dp), external :: ddot

      complex(dp) :: etaX_ref_R, L_xiX, L_X_R

      integer :: i

      call mem%alloc(X_R_real, this%wf%n_es_amplitudes, set_zero=.true.)
      call mem%alloc(X_R_imag, this%wf%n_es_amplitudes, set_zero=.true.)
      call mem%alloc(X_R, this%wf%n_es_amplitudes)

      do i = 1, 3

         ! Calculate etaX_ref_R = sum_mu <HF|e^(-T)[X, tau_nu]e^T|HF> r_mu(t)

         etaX_ref_R = zdotu_(this%wf%n_t1, &
                             cmplx(this%etaX_ref(:, i), zero, dp), &
                             1, &
                             this%td_right(2:this%wf%n_t1 + 1), &
                             1)

         ! Calculate L_xiX = sum_mu l_mu(t) <mu|e^(-T)Xe^T|HF>

         L_xiX = zdotu_(this%wf%n_es_amplitudes, &
                        this%td_left(2:this%n_td_parameters / 2), &
                        1, &
                        cmplx(this%xiX(:, i), zero, dp), &
                        1)

         ! Construct X_R_mu = sum_nu X_mu,nu r_nu(t)
         !                  = sum_nu (A^EOM,X_mu,nu + <HF|e^(-T)Xe^T|HF> delta_mu,nu) r_mu(t)

         call this%wf%jacobianX_eom_transformation(real(this%td_right(2:this%n_td_parameters / 2)), &
                                                   X_R_real, &
                                                   this%dipole_integrals_t1(:, :, i), &
                                                   this%xiX(:, i))

         call this%wf%jacobianX_eom_transformation(aimag(this%td_right(2:this%n_td_parameters / 2)), &
                                                   X_R_imag, &
                                                   this%dipole_integrals_t1(:, :, i), &
                                                   this%xiX(:, i))

         X_R = cmplx(X_R_real, X_R_imag, dp)

         call zaxpy(this%wf%n_es_amplitudes, &
                    cmplx(this%two_trace_X_oo(i), zero, dp), &
                    this%td_right(2:this%n_td_parameters / 2), &
                    1, &
                    X_R, &
                    1)

         ! Calculate L_X_R = sum_mu,nu l_mu(t) X_mu,nu r_nu(t)

         L_X_R = zdotu_(this%wf%n_es_amplitudes, this%td_left(2:this%n_td_parameters / 2), 1, X_R, 1)

         ! Use quantities to construct
         !    sum_kappa,lambda l_kappa(t) <kappa|e^(-T)Xe^T|lambda> r_lambda(t)

         this%dipole_moment(i) = this%td_left(1) &
                                 * this%td_right(1) * cmplx(this%two_trace_X_oo(i), zero, dp) &
                                 + this%td_left(1) * etaX_ref_R + L_xiX * this%td_right(1) + L_X_R

      end do

      call mem%dealloc(X_R_real)
      call mem%dealloc(X_R_imag)
      call mem%dealloc(X_R)

      ! Add the nuclear contribution

      nuclear = this%wf%get_nuclear_dipole()

      this%dipole_moment = this%dipole_moment + cmplx(nuclear, zero, dp)

   end subroutine calculate_dipole_moment_no_density_elementary_tdeomcc_state


end module elementary_tdeomcc_state_class

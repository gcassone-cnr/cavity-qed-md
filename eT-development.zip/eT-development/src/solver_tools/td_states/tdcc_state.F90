

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module tdcc_state_class

   !!
   !! TDCC state class
   !! Written by Andreas S. Skeidsvoll, Alice Balbi, 2018-2020
   !!
   !! In TDCC, time-dependent amplitudes and multipliers evolve according to the
   !! equations
   !!
   !!    d/dt t_mu(t)    = -i*Omega_mu(t)
   !!    d/dt tbar_nu(t) = i*<Lambda(t)|[H(t),tau_nu]|CC(t)>
   !!
   !! See J. Chem. Phys. 93, 3333 (1990) for more details.
   !!

   use parameters
   use memory_manager_class, only: mem
   use ccs_class, only: ccs
   use electric_field_class, only: electric_field
   use td_state_class, only: td_state
   use global_out, only: output
   use amplitude_file_storer_class, only: amplitude_file_storer

   implicit none

   type, extends(td_state) :: tdcc_state

      class(ccs), pointer :: wf

      complex(dp), dimension(:, :, :), allocatable :: dipole_integrals_t1

      complex(dp), dimension(:), pointer :: td_amplitudes, td_multipliers
      complex(dp), pointer :: td_phase, td_left_reference

   contains

      procedure, public :: initialize => initialize_tdcc_state
      procedure, public :: cleanup => cleanup_tdcc_state

      procedure, public :: update => update_tdcc_state
      procedure, public :: construct_time_derivative => construct_time_derivative_tdcc_state

      procedure, public :: calculate_energy => calculate_energy_tdcc_state
      procedure, public :: calculate_dipole_moment => calculate_dipole_moment_tdcc_state
      procedure, public :: calculate_mo_density_matrix => calculate_mo_density_matrix_tdcc_state

   end type tdcc_state


   interface tdcc_state

      procedure :: new_tdcc_state

   end interface tdcc_state


contains


   function new_tdcc_state(wf, field, restart) result(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      implicit none

      class(ccs), target :: wf
      class(electric_field), target :: field

      logical, intent(in) :: restart

      type(tdcc_state) :: this

      this%wf => wf
      this%field => field

      this%mo_density_matrix_required = .true.
      this%restart = restart

      this%n_td_parameters = 2 * (this%wf%n_gs_amplitudes + 1)
      this%n_mo = this%wf%n_mo

      this%name_ = 'tdcc'

   end function new_tdcc_state


   subroutine initialize_tdcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      implicit none

      class(tdcc_state), intent(inout), target :: this

      real(dp), dimension(:, :, :), allocatable :: dipole_integrals_ao
      real(dp) :: energy_real, energy_imag

      integer :: i

      logical :: try_to_restart

      real(dp), dimension(:), allocatable :: real_t, imag_t
      integer :: read_n

      ! The time-dependent parameters are the amplitudes and multipliers, which
      ! become complex

      call this%wf%make_complex()

      call mem%alloc(this%td_parameters, this%n_td_parameters)

      this%td_phase => this%td_parameters(1)
      this%td_amplitudes => this%td_parameters(2:this%n_td_parameters / 2)
      this%td_left_reference => this%td_parameters(this%n_td_parameters / 2 + 1)
      this%td_multipliers => this%td_parameters(this%n_td_parameters / 2 + 2:this%n_td_parameters)

      this%real_state_storer = amplitude_file_storer('td_state_real', this%n_td_parameters)
      this%imag_state_storer = amplitude_file_storer('td_state_imag', this%n_td_parameters)

      try_to_restart = this%restart .and. this%real_state_storer%file_exists() .and. &
                       this%imag_state_storer%file_exists()

      if (try_to_restart) then

         call output%printf('m', 'Requested restart. Reading in solution from file.', fs='(/t3,a)')

         call mem%alloc(real_t, this%n_td_parameters)
         call mem%alloc(imag_t, this%n_td_parameters)

         call this%real_state_storer%read_(real_t, energy_real, read_n)
         if (read_n /= this%n_td_parameters) &
            call output%error_msg( &
                    'mismatch between number of parameters and read elements on td_state_real file' &
                 )

         call this%imag_state_storer%read_(imag_t, energy_imag, read_n)
         if (read_n /= this%n_td_parameters) &
            call output%error_msg( &
                    'mismatch between number of parameters and read elements on td_state_imag file' &
                 )

         this%td_parameters = cmplx(real_t, imag_t, dp)

         call mem%dealloc(real_t)
         call mem%dealloc(imag_t)

      else
         ! Start from the CC ground state

         this%td_phase = zero_complex
         call this%wf%get_amplitudes_complex(this%td_amplitudes)

         this%td_left_reference = one_complex
         call this%wf%get_multipliers_complex(this%td_multipliers)

      end if

      call this%wf%initialize_gs_density_complex()
      call mem%alloc(this%mo_density_matrix, this%n_mo, this%n_mo)

      ! Transform the AO integrals to the MO basis

      call mem%alloc(dipole_integrals_ao, this%wf%ao%n, this%wf%ao%n, 3)

      call this%wf%ao%get_oei('dipole', dipole_integrals_ao)

      call mem%alloc(this%dipole_integrals, this%wf%n_mo, this%wf%n_mo, 3)

      do i = 1, 3

         call this%wf%mo_transform(dipole_integrals_ao(:, :, i), this%dipole_integrals(:, :, i))

      end do

      call mem%dealloc(dipole_integrals_ao)

      call mem%alloc(this%dipole_integrals_t1, this%n_mo, this%n_mo, 3)

   end subroutine initialize_tdcc_state


   subroutine cleanup_tdcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      implicit none

      class(tdcc_state) :: this

      call this%wf%cleanup_complex()

      call mem%dealloc(this%td_parameters)
      call mem%dealloc(this%mo_density_matrix)
      call mem%dealloc(this%dipole_integrals)
      call mem%dealloc(this%dipole_integrals_t1)

   end subroutine cleanup_tdcc_state


   subroutine update_tdcc_state(this, t)
      !!
      !! Written by Andreas Skeidsvoll, Oct 2018
      !!
      !! Update amplitudes, multipliers, t1 transformed quantities and Fock matrix.
      !!
      use warning_suppressor

      implicit none

      class(tdcc_state) :: this

      real(dp), intent(in) :: t

      integer :: i

      call this%wf%set_amplitudes_complex(this%td_amplitudes)
      call this%wf%set_multipliers_complex(this%td_multipliers)

      call this%field%update(t)

      call this%wf%construct_t1_cholesky_complex(this%wf%t1_complex, this%wf%L_mo_c, this%wf%L_t1_c)

      this%dipole_integrals_t1 = cmplx(this%dipole_integrals, zero, dp)

      do i = 1, 3

         call this%wf%t1_transform_complex(this%dipole_integrals_t1(:, :, i))

      end do

      call this%wf%construct_fock_complex()

      ! Contribution to Fock matrix corresponding to the interaction with the electric field.

      call this%wf%add_t1_fock_length_dipole_term_complex(cmplx(this%field%vector, zero, dp), &
                                                          this%dipole_integrals_t1)

   end subroutine update_tdcc_state


   subroutine construct_time_derivative_tdcc_state(this, ddt_parameters, t)
      !!
      !! Written by Alice Balbi, Andreas Skeidsvoll, Oct 2018
      !!
      !! Returns the complex time derivative of the amplitudes and multipliers.
      !!
      implicit none

      class(tdcc_state) :: this

      complex(dp), dimension(this%n_td_parameters), intent(out) :: ddt_parameters
      real(dp), intent(in) :: t

      call this%update(t)

      call this%wf%calculate_energy_complex()
      ddt_parameters(1) = - one_imag * this%wf%energy_complex

      call this%wf%construct_complex_time_derivative_amplitudes(ddt_parameters(2:this%n_td_parameters / 2))

      ddt_parameters(this%n_td_parameters / 2 + 1) = zero_complex

      call this%wf%construct_complex_time_derivative_multipliers(ddt_parameters(this%n_td_parameters / 2 &
         + 2:this%n_td_parameters))

   end subroutine construct_time_derivative_tdcc_state


   subroutine calculate_energy_tdcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Oct 2018
      !!
      implicit none

      class(tdcc_state) :: this
      complex(dp), dimension(:), allocatable :: omega

      ! Total energy with interaction term, <Lambda| e^-T H(t) e^T |R>

      call this%wf%calculate_energy_complex()

      call mem%alloc(omega, this%wf%n_gs_amplitudes)
      call this%wf%construct_omega_complex(omega)
      call this%wf%calculate_energy_omega_term_complex(omega)
      call mem%dealloc(omega)

      call this%wf%calculate_energy_length_dipole_term_complex(cmplx(this%field%vector, zero, dp), &
                                                               this%dipole_integrals_t1)

      this%energy = this%wf%energy_complex

   end subroutine calculate_energy_tdcc_state


   subroutine calculate_dipole_moment_tdcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Alice Balbi, Oct 2018
      !!
      implicit none

      class(tdcc_state) :: this

      if (this%mo_density_matrix_required) then

         call this%calculate_dipole_moment_from_mo_density_matrix(this%wf%get_nuclear_dipole())

      else

         call output%error_msg('need MO density matrix for TDCC dipole moment')

      end if

   end subroutine calculate_dipole_moment_tdcc_state


   subroutine calculate_mo_density_matrix_tdcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Jan 2023
      !!
      !! Calculates the complex time-dependent density matrix
      !!
      !!    D^R_pq(t) = <Lambda(t)| E_pq |CC(t)>
      !!
      !! in the complex t1 basis, and transforms it to the MO basis.
      !!
      implicit none

      class(tdcc_state) :: this

      call this%wf%construct_gs_density_complex()

      call zcopy(this%n_mo**2, this%wf%density_complex, 1, this%mo_density_matrix, 1)

      call this%wf%add_t1_terms_complex(this%mo_density_matrix)

   end subroutine calculate_mo_density_matrix_tdcc_state


end module tdcc_state_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module td_state_class

   !!
   !! TD state class
   !! Written by Andreas S. Skeidsvoll, Nov 2020
   !!
   !! Framework for the class of time-dependent state objects, which contain
   !! functionality for handling the time-dependent wave function parameters.
   !! This includes functionality for the calculation of the parameter time
   !! derivatives and the energy, dipole moment and MO density matrix for a
   !! given set of parameters.
   !!

   use electric_field_class, only: electric_field
   use parameters
   use amplitude_file_storer_class, only: amplitude_file_storer

   implicit none

   type, abstract :: td_state

      complex(dp), dimension(:), allocatable :: td_parameters

      type(amplitude_file_storer) :: real_state_storer, imag_state_storer

      integer :: n_td_parameters, n_mo

      character(len=40) :: name_

      class(electric_field), pointer :: field

      logical :: mo_density_matrix_required, restart

      real(dp), dimension(:, :, :), allocatable :: dipole_integrals

      complex(dp), dimension(:, :), allocatable :: mo_density_matrix
      complex(dp), dimension(3) :: dipole_moment
      complex(dp) :: energy

   contains

      procedure(initialize_td_state), deferred, public :: initialize
      procedure(cleanup_td_state), deferred, public :: cleanup

      procedure(update_td_state), deferred, public :: update
      procedure(construct_time_derivative_td_state), deferred, public :: construct_time_derivative

      procedure(calculate_energy_td_state), deferred, public :: calculate_energy
      procedure(calculate_dipole_moment_td_state), deferred, public :: calculate_dipole_moment
      procedure(calculate_mo_density_matrix_td_state), deferred, public :: calculate_mo_density_matrix

      procedure, public :: get_n_td_parameters => get_n_td_parameters_td_state

      procedure, public :: prepare_output => prepare_output_td_state

      procedure, public :: calculate_dipole_moment_from_mo_density_matrix => &
                           calculate_dipole_moment_from_mo_density_matrix_td_state

   end type td_state

   abstract interface

      subroutine initialize_td_state(this)

         import :: td_state, dp

         implicit none

         class(td_state), intent(inout), target :: this

      end subroutine initialize_td_state


      subroutine cleanup_td_state(this)

         import :: td_state

         implicit none

         class(td_state) :: this

      end subroutine cleanup_td_state


      subroutine update_td_state(this, t)

         import :: td_state, dp

         implicit none

         class(td_state) :: this

         real(dp), intent(in) :: t

      end subroutine update_td_state


      subroutine construct_time_derivative_td_state(this, ddt_parameters, t)

         import :: td_state, dp

         implicit none

         class(td_state) :: this

         complex(dp), dimension(this%n_td_parameters), intent(out) :: ddt_parameters
         real(dp), intent(in) :: t

      end subroutine construct_time_derivative_td_state


      subroutine calculate_energy_td_state(this)

         import :: td_state

         implicit none

         class(td_state) :: this

      end subroutine calculate_energy_td_state


      subroutine calculate_dipole_moment_td_state(this)

         import :: td_state

         implicit none

         class(td_state) :: this

      end subroutine calculate_dipole_moment_td_state


      subroutine calculate_mo_density_matrix_td_state(this)

         import :: td_state

         implicit none

         class(td_state) :: this

      end subroutine calculate_mo_density_matrix_td_state

   end interface


contains


   subroutine prepare_output_td_state(this, energy_output, dipole_moment_output)
      !!
      !! Written by Andreas Skeidsvoll, Dec 2022
      !!
      implicit none

      logical, intent(in) :: energy_output, dipole_moment_output

      class(td_state) :: this

      if (this%mo_density_matrix_required) call this%calculate_mo_density_matrix()

      if (energy_output) call this%calculate_energy()

      if (dipole_moment_output) call this%calculate_dipole_moment()

   end subroutine prepare_output_td_state


   function get_n_td_parameters_td_state(this) result(n_td_parameters)
      !!
      !! Written by Andreas S. Skeidsvoll, Jun 2021
      !!
      implicit none

      class(td_state) :: this
      integer :: n_td_parameters

      n_td_parameters = this%n_td_parameters

   end function get_n_td_parameters_td_state


   subroutine calculate_dipole_moment_from_mo_density_matrix_td_state(this, nuclear)
      !!
      !! Written by Andreas Skeidsvoll, Alice Balbi 2018-2021
      !!

      implicit none

      class(td_state) :: this

      real(dp), dimension(3), intent(in) :: nuclear

      integer :: i

      real(dp), external :: ddot

      ! Contract MO integrals with MO density matrix to get electronic part of
      ! the dipole moment

      do i = 1, 3

         this%dipole_moment(i) = cmplx( &
                                    ddot(this%n_mo**2, real(this%mo_density_matrix), 1, &
                                       this%dipole_integrals(:, :, i), 1), &
                                    ddot(this%n_mo**2, aimag(this%mo_density_matrix), 1, &
                                       this%dipole_integrals(:, :, i), 1), &
                                    dp &
                                 )

      end do

      this%dipole_moment = this%dipole_moment + cmplx(nuclear, zero, dp)

   end subroutine calculate_dipole_moment_from_mo_density_matrix_td_state


end module td_state_class

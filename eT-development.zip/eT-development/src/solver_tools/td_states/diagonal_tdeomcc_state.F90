

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module diagonal_tdeomcc_state_class

   !!
   !! Diagonal TD-EOM-CC state class
   !! Written by Andreas S. Skeidsvoll, Nov 2020
   !!
   !! In diagonal basis TD-EOM-CC, time-dependent right and left state
   !! coefficients evolve according to the equation
   !!
   !!    d/dt r_n(t)    = -i H_nm(t) r_m(t)
   !!    d/dt l_m(t)    = i l_n(t) H_nm(t)
   !!
   !! The right and left coefficients are the coefficients of the biorthogonal
   !! EOM-CC eigenbasis.
   !!

   use parameters
   use memory_manager_class, only: mem
   use ccs_class, only: ccs
   use electric_field_class, only: electric_field
   use array_utilities, only: zdotu_
   use global_out, only: output
   use amplitude_file_storer_class, only: amplitude_file_storer

   use td_state_class, only: td_state

   implicit none

   type, extends(td_state) :: diagonal_tdeomcc_state

      class(ccs), pointer :: wf

      integer :: n_states

      real(dp), dimension(:, :), allocatable :: hamiltonian_matrix, H
      real(dp), dimension(:, :, :), allocatable :: dipole_matrix

      complex(dp), dimension(:), pointer :: td_left, td_right

   contains

      procedure :: initialize => initialize_diagonal_tdeomcc_state
      procedure :: cleanup => cleanup_diagonal_tdeomcc_state

      procedure :: update => update_diagonal_tdeomcc_state
      procedure :: construct_time_derivative => construct_time_derivative_diagonal_tdeomcc_state

      procedure :: calculate_energy => calculate_energy_diagonal_tdeomcc_state
      procedure :: calculate_dipole_moment => calculate_dipole_moment_diagonal_tdeomcc_state

      procedure :: calculate_mo_density_matrix => calculate_mo_density_matrix_diagonal_tdeomcc_state

      procedure :: update_hamiltonian => update_hamiltonian_diagonal_tdeomcc_state
      procedure :: hamiltonian_transformation => hamiltonian_transformation_diagonal_tdeomcc_state
      procedure :: hamiltonian_transpose_transformation => &
                   hamiltonian_transpose_transformation_diagonal_tdeomcc_state

      procedure :: save_dipole_matrix_diagonal_tdeomcc_state

   end type diagonal_tdeomcc_state

   interface diagonal_tdeomcc_state

      procedure :: new_diagonal_tdeomcc_state

   end interface diagonal_tdeomcc_state


contains


   function new_diagonal_tdeomcc_state(wf, field, n_states, mo_density_matrix_required, restart) result(this)
      !!
      !! Written by Andreas Skeidsvoll, Oct 2018
      !!
      implicit none

      class(ccs), target :: wf
      class(electric_field), target :: field
      logical, intent(in) :: mo_density_matrix_required, restart
      integer :: n_states

      type(diagonal_tdeomcc_state) :: this

      this%wf => wf
      this%field => field
      this%n_states = n_states

      this%mo_density_matrix_required = mo_density_matrix_required
      this%restart = restart

      this%n_td_parameters = 2 * (n_states + 1)
      this%n_mo = wf%n_mo

      this%name_ = 'diagonal td-eom-cc'

   end function new_diagonal_tdeomcc_state


   subroutine initialize_diagonal_tdeomcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      use array_initialization, only: zero_array_complex
      use stream_file_class, only: stream_file

      implicit none

      class(diagonal_tdeomcc_state), intent(inout), target :: this

      integer :: n_states, i, state_l, state_r

      real(dp), dimension(:, :, :), allocatable :: dipole_integrals_ao

      type(stream_file), allocatable :: dipole_matrix_file, hamiltonian_matrix_file

      type(stream_file), dimension(:, :), allocatable :: density_file
      character(len=200) :: file_name

      logical :: try_to_restart

      integer :: read_n

      real(dp), dimension(:), allocatable :: real_t, imag_t
      real(dp) :: energy_real, energy_imag
      real(dp), dimension(:, :), allocatable :: density

      if (this%mo_density_matrix_required) call mem%alloc(this%mo_density_matrix, this%n_mo, this%n_mo)

      call mem%alloc(this%td_parameters, this%n_td_parameters)

      this%td_right => this%td_parameters(1:this%n_td_parameters / 2)
      this%td_left => this%td_parameters(this%n_td_parameters / 2 + 1:this%n_td_parameters)


      this%real_state_storer = amplitude_file_storer('td_state_real', this%n_td_parameters)
      this%imag_state_storer = amplitude_file_storer('td_state_imag', this%n_td_parameters)

      try_to_restart = this%restart .and. this%real_state_storer%file_exists() .and. &
                       this%imag_state_storer%file_exists()

      if (try_to_restart) then

         call output%printf('m', 'Requested restart. Reading in solution from file.', fs='(/t3,a)')

         call mem%alloc(real_t, this%n_td_parameters)
         call mem%alloc(imag_t, this%n_td_parameters)

         call this%real_state_storer%read_(real_t, energy_real, read_n)
         if (read_n /= this%n_td_parameters) &
            call output%error_msg( &
                    'mismatch between number of parameters and read elements on td_state_real file' &
                 )

         call this%imag_state_storer%read_(imag_t, energy_imag, read_n)
         if (read_n /= this%n_td_parameters) &
            call output%error_msg( &
                    'mismatch between number of parameters and read elements on td_state_imag file' &
                 )

         this%td_parameters = cmplx(real_t, imag_t, dp)

         call mem%dealloc(real_t)
         call mem%dealloc(imag_t)

         dipole_matrix_file = stream_file('cc_eom_dipole_matrix_diagonal_tdeomcc')
         call dipole_matrix_file%open_('rewind')

         call dipole_matrix_file%read_(n_states)
         if (n_states /= this%n_td_parameters / 2) &
            call output%error_msg('mismatch between number of singlet states and transition moments on file')

         call mem%alloc(this%dipole_matrix, this%n_td_parameters / 2, this%n_td_parameters / 2, 3)
         call dipole_matrix_file%read_(this%dipole_matrix, 3 * (this%n_td_parameters / 2)**2)

         call dipole_matrix_file%close_('keep')
         deallocate(dipole_matrix_file)

         call mem%alloc(density, this%n_mo, this%n_mo, set_zero=.true.)
         allocate(density_file(this%n_states + 1, this%n_states + 1))

         do state_l = 0, this%n_states
            do state_r = 0, this%n_states

               write(file_name, '(2(a, i3.3))')'density_matrix_l_', state_l, '_r_', state_r
               density_file(state_l + 1, state_r + 1) = stream_file(file_name)
               call density_file(state_l + 1, state_r + 1)%open_('rewind')

               call density_file(state_l + 1, state_r + 1)%read_(density, this%n_mo**2)
               call density_file(state_l + 1, state_r + 1)%close_('keep')

               call this%wf%density_storage%copy_density_in(density, state_l, state_r)

            end do
         end do

         deallocate(density_file)
         call mem%dealloc(density)

      else
         ! Start from the CC ground state

         this%td_right(1) = one_complex
         call zero_array_complex(this%td_right(2:this%n_td_parameters / 2), this%n_td_parameters / 2 - 1)

         this%td_left(1) = one_complex
         call zero_array_complex(this%td_left(2:this%n_td_parameters / 2), this%n_td_parameters / 2 - 1)

         dipole_matrix_file = stream_file('cc_eom_dipole_matrix')
         call dipole_matrix_file%open_('rewind')

         call dipole_matrix_file%read_(n_states)
         if (n_states /= this%n_td_parameters / 2) &
            call output%error_msg('mismatch between number of singlet states and transition moments on file')

         call mem%alloc(this%dipole_matrix, this%n_td_parameters / 2, this%n_td_parameters / 2, 3)
         call dipole_matrix_file%read_(this%dipole_matrix, 3 * (this%n_td_parameters / 2)**2)

         call dipole_matrix_file%close_('keep')
         deallocate(dipole_matrix_file)

         call this%save_dipole_matrix_diagonal_tdeomcc_state()

         call mem%alloc(density, this%n_mo, this%n_mo, set_zero=.true.)
         allocate(density_file(this%n_states + 1, this%n_states + 1))

         do state_l = 0, this%n_states
            do state_r = 0, this%n_states

               call this%wf%density_storage%copy_density_out(density, state_l, state_r)

               write(file_name, '(2(a, i3.3))')'density_matrix_l_', state_l, '_r_', state_r
               density_file(state_l + 1, state_r + 1) = stream_file(file_name)
               call density_file(state_l + 1, state_r + 1)%open_('rewind')

               call density_file(state_l + 1, state_r + 1)%write_(density, this%n_mo**2)
               call density_file(state_l + 1, state_r + 1)%close_('keep')

            end do
         end do

         deallocate(density_file)
         call mem%dealloc(density)

      end if

      hamiltonian_matrix_file = stream_file('cc_eom_hamiltonian_matrix')
      call hamiltonian_matrix_file%open_('rewind')

      call hamiltonian_matrix_file%read_(n_states)
      if (n_states /= this%n_td_parameters / 2) &
         call output%error_msg('mismatch between number of singlet states and Hamiltonian elements on file')

      call mem%alloc(this%hamiltonian_matrix, this%n_td_parameters / 2, this%n_td_parameters / 2)
      call hamiltonian_matrix_file%read_(this%hamiltonian_matrix, (this%n_td_parameters / 2)**2)

      call hamiltonian_matrix_file%close_('keep')
      deallocate(hamiltonian_matrix_file)

      call mem%alloc(this%H, this%n_td_parameters / 2, this%n_td_parameters / 2)

      ! Transform the AO integrals to the MO basis

      call mem%alloc(dipole_integrals_ao, this%wf%ao%n, this%wf%ao%n, 3)

      call this%wf%ao%get_oei('dipole', dipole_integrals_ao)

      call mem%alloc(this%dipole_integrals, this%wf%n_mo, this%wf%n_mo, 3)

      do i = 1, 3

         call this%wf%mo_transform(dipole_integrals_ao(:, :, i), this%dipole_integrals(:, :, i))

      end do

      call mem%dealloc(dipole_integrals_ao)

   end subroutine initialize_diagonal_tdeomcc_state


   subroutine cleanup_diagonal_tdeomcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      implicit none

      class(diagonal_tdeomcc_state) :: this

      call mem%dealloc(this%td_parameters)

      call mem%dealloc(this%dipole_integrals)

      call mem%dealloc(this%dipole_matrix)
      call mem%dealloc(this%hamiltonian_matrix)
      call mem%dealloc(this%H)

      if (this%mo_density_matrix_required) call mem%dealloc(this%mo_density_matrix)

   end subroutine cleanup_diagonal_tdeomcc_state


   subroutine update_diagonal_tdeomcc_state(this, t)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      implicit none

      class(diagonal_tdeomcc_state) :: this

      real(dp), intent(in) :: t

      call this%field%update(t)

      call this%update_hamiltonian()

   end subroutine update_diagonal_tdeomcc_state


   subroutine construct_time_derivative_diagonal_tdeomcc_state(this, ddt_parameters, t)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      !! Returns the complex time derivative of the TD-EOM-CC state.
      !!
      implicit none

      class(diagonal_tdeomcc_state) :: this

      complex(dp), dimension(this%n_td_parameters), intent(out) :: ddt_parameters
      real(dp), intent(in) :: t

      call this%update(t)

      call this%hamiltonian_transformation(this%td_right, &
                                           ddt_parameters(1:this%n_td_parameters / 2))

      call zscal(this%n_td_parameters / 2, - one_imag, ddt_parameters(1:this%n_td_parameters / 2), 1)

      call this%hamiltonian_transpose_transformation(this%td_left, &
                                                     ddt_parameters(this%n_td_parameters / 2 &
                                                        + 1:this%n_td_parameters))

      call zscal(this%n_td_parameters / 2, &
                 one_imag, &
                 ddt_parameters(this%n_td_parameters / 2 + 1:this%n_td_parameters), &
                 1)

   end subroutine construct_time_derivative_diagonal_tdeomcc_state


   subroutine hamiltonian_transformation_diagonal_tdeomcc_state(this, c, H_c)
      !!
      !! Written by Andreas S. Skeidsvoll, Jun 2020
      !!
      !! Constructs vector
      !!
      !!    H_c_n = sum_m H_nm c_m^R
      !!
      implicit none

      class(diagonal_tdeomcc_state) :: this

      complex(dp), dimension(this%n_td_parameters / 2), intent(in) :: c
      complex(dp), dimension(this%n_td_parameters / 2), intent(out) :: H_c

      real(dp), dimension(:), allocatable :: H_c_real, H_c_imag

      call mem%alloc(H_c_real, this%n_td_parameters / 2)
      call mem%alloc(H_c_imag, this%n_td_parameters / 2)

      call dgemv('N', &
                 this%n_td_parameters / 2, &
                 this%n_td_parameters / 2, &
                 one, &
                 this%H, &
                 this%n_td_parameters / 2, &
                 real(c), &
                 1, &
                 zero, &
                 H_c_real, &
                 1)

      call dgemv('N', &
                 this%n_td_parameters / 2, &
                 this%n_td_parameters / 2, &
                 one, &
                 this%H, &
                 this%n_td_parameters / 2, &
                 aimag(c), &
                 1, &
                 zero, &
                 H_c_imag, &
                 1)

      H_c = cmplx(H_c_real, H_c_imag, dp)

      call mem%dealloc(H_c_real)
      call mem%dealloc(H_c_imag)

   end subroutine hamiltonian_transformation_diagonal_tdeomcc_state


   subroutine hamiltonian_transpose_transformation_diagonal_tdeomcc_state(this, c, c_H)
      !!
      !! Written by Andreas S. Skeidsvoll, Jun 2020
      !!
      !! Constructs vector
      !!
      !!    c_H_m = sum_n c_n^L H_nm
      !!
      implicit none

      class(diagonal_tdeomcc_state) :: this

      complex(dp), dimension(this%n_td_parameters / 2), intent(in) :: c
      complex(dp), dimension(this%n_td_parameters / 2), intent(out) :: c_H

      real(dp), dimension(:), allocatable :: c_H_real, c_H_imag

      call mem%alloc(c_H_real, this%n_td_parameters / 2)
      call mem%alloc(c_H_imag, this%n_td_parameters / 2)

      call dgemv('T', &
                 this%n_td_parameters / 2, &
                 this%n_td_parameters / 2, &
                 one, &
                 this%H, &
                 this%n_td_parameters / 2, &
                 real(c), &
                 1, &
                 zero, &
                 c_H_real, &
                 1)

      call dgemv('T', &
                 this%n_td_parameters / 2, &
                 this%n_td_parameters / 2, &
                 one, &
                 this%H, &
                 this%n_td_parameters / 2, &
                 aimag(c), &
                 1, &
                 zero, &
                 c_H_imag, &
                 1)

      c_H = cmplx(c_H_real, c_H_imag, dp)

      call mem%dealloc(c_H_real)
      call mem%dealloc(c_H_imag)

   end subroutine hamiltonian_transpose_transformation_diagonal_tdeomcc_state


   subroutine update_hamiltonian_diagonal_tdeomcc_state(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Jun 2020
      !!
      !! Constructs the length gauge EOM-CC time-dependent Hamiltonian in the
      !! Schrodinger picture
      !!
      !!    H_nm = < n| (H_0 + V) |m >
      !!
      implicit none

      class(diagonal_tdeomcc_state) :: this

      integer :: i

      call dcopy((this%n_td_parameters / 2)**2, this%hamiltonian_matrix, 1, this%H, 1)

      do i = 1, 3

         call daxpy((this%n_td_parameters / 2)**2, &
                    - this%field%vector(i), &
                    this%dipole_matrix(:, :, i), &
                    1, &
                    this%H, &
                    1)

      end do

   end subroutine update_hamiltonian_diagonal_tdeomcc_state


   subroutine calculate_energy_diagonal_tdeomcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      !! Calculate the TD-EOM-CC energy.
      !!
      implicit none

      class(diagonal_tdeomcc_state) :: this

      complex(dp), dimension(:), allocatable :: H_c

      ! Calculate c^L H(t) c^R

      call mem%alloc(H_c, this%n_td_parameters / 2)

      call this%hamiltonian_transformation(this%td_right, H_c)

      this%energy = zdotu_(this%n_td_parameters / 2, this%td_left, 1, H_c, 1)

      call mem%dealloc(H_c)

   end subroutine calculate_energy_diagonal_tdeomcc_state


   subroutine calculate_dipole_moment_diagonal_tdeomcc_state(this)
      !!
      !! Written by Andreas Skeidsvoll, Nov 2020
      !!
      !! Calculate the TD-EOM-CC dipole moment vector.
      !!

      implicit none

      class(diagonal_tdeomcc_state) :: this

      real(dp), dimension(3) :: nuclear

      real(dp), dimension(:), allocatable :: X_c_real, X_c_imag

      integer :: i

      if (this%mo_density_matrix_required) then

         call this%calculate_dipole_moment_from_mo_density_matrix(this%wf%get_nuclear_dipole())

      else

         call mem%alloc(X_c_imag, this%n_td_parameters / 2)
         call mem%alloc(X_c_real, this%n_td_parameters / 2)

         do i = 1, 3

            call dgemv('N', &
                       this%n_td_parameters / 2, &
                       this%n_td_parameters / 2, &
                       one, &
                       this%dipole_matrix(:, :, i), &
                       this%n_td_parameters / 2, &
                       real(this%td_right), &
                       1, &
                       zero, &
                       X_c_real, &
                       1)

            call dgemv('N', &
                       this%n_td_parameters / 2, &
                       this%n_td_parameters / 2, &
                       one, &
                       this%dipole_matrix(:, :, i), &
                       this%n_td_parameters / 2, &
                       aimag(this%td_right), &
                       1, &
                       zero, &
                       X_c_imag, &
                       1)

            this%dipole_moment(i) = zdotu_(this%n_td_parameters / 2, &
                                           this%td_left, &
                                           1, &
                                           cmplx(X_c_real, X_c_imag, dp), &
                                           1)

         end do

         call mem%dealloc(X_c_real)
         call mem%dealloc(X_c_imag)

         ! Add the nuclear contribution

         nuclear = this%wf%get_nuclear_dipole()

         this%dipole_moment = this%dipole_moment + cmplx(nuclear, zero, dp)

      end if

   end subroutine calculate_dipole_moment_diagonal_tdeomcc_state


   subroutine calculate_mo_density_matrix_diagonal_tdeomcc_state(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Aug 2023
      !!
      implicit none

      class(diagonal_tdeomcc_state) :: this

      integer :: state_l, state_r

      real(dp), dimension(:, :), allocatable :: density, mo_density_matrix_real, mo_density_matrix_imag

      complex(dp) :: coefficient

      call mem%alloc(density, this%n_mo, this%n_mo)
      call mem%alloc(mo_density_matrix_real, this%n_mo, this%n_mo, set_zero=.true.)
      call mem%alloc(mo_density_matrix_imag, this%n_mo, this%n_mo, set_zero=.true.)

      do state_l = 0, this%n_states
         do state_r = 0, this%n_states

            call this%wf%density_storage%copy_density_out(density, state_l, state_r)

            coefficient = this%td_right(state_r + 1) * this%td_left(state_l + 1)

            call daxpy(this%n_mo**2, real(coefficient), density, 1, mo_density_matrix_real, 1)
            call daxpy(this%n_mo**2, aimag(coefficient), density, 1, mo_density_matrix_imag, 1)

         end do
      end do

      call mem%dealloc(density)

      call this%wf%add_t1_terms(mo_density_matrix_real)
      call this%wf%add_t1_terms(mo_density_matrix_imag)

      this%mo_density_matrix = cmplx(mo_density_matrix_real, mo_density_matrix_imag, dp)

      call mem%dealloc(mo_density_matrix_real)
      call mem%dealloc(mo_density_matrix_imag)

   end subroutine calculate_mo_density_matrix_diagonal_tdeomcc_state


   subroutine save_dipole_matrix_diagonal_tdeomcc_state(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Jul 2023
      !!
      use stream_file_class, only: stream_file

      implicit none
      class(diagonal_tdeomcc_state), intent(in) :: this

      type(stream_file) :: dipole_matrix_file

      dipole_matrix_file = stream_file('cc_eom_dipole_matrix_diagonal_tdeomcc')

      call dipole_matrix_file%open_('rewind')
      call dipole_matrix_file%write_(this%n_td_parameters / 2)
      call dipole_matrix_file%write_(this%dipole_matrix, 3 * (this%n_td_parameters / 2)**2)
      call dipole_matrix_file%close_('keep')

   end subroutine save_dipole_matrix_diagonal_tdeomcc_state

end module diagonal_tdeomcc_state_class

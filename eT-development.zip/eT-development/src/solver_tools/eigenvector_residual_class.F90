

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module eigenvector_residual_class

   !!
   !! Eigenvector residual class
   !! Written by Sarai D. Folkestad, 2023
   !!

   use parameters

   implicit none

   type :: eigenvector_residual

      integer, private :: n_solutions, n_parameters

   contains

      procedure, public :: construct
      procedure, private :: construct_real_residual
      procedure, private :: construct_complex_residual
      procedure, private :: construct_complex_residual_pair

   end type eigenvector_residual

   interface eigenvector_residual

      procedure :: new_eigenvector_residual

   end interface eigenvector_residual

contains

   function new_eigenvector_residual(n_parameters, n_solutions) result(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      type(eigenvector_residual) :: this

      integer, intent(in) :: n_parameters, n_solutions

      this%n_parameters = n_parameters
      this%n_solutions = n_solutions

   end function new_eigenvector_residual


   subroutine construct(this, AX, X, omega)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Aug 2018
      !!
      !! Constructs the nth full space residual.
      !! Expressions differ for real or complex eigenvalues
      !!
      !! Note: Residual is stored in AX on exit!
      !!
      use math_utilities, only: is_real

      implicit none

      class(eigenvector_residual), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: AX
      real(dp), dimension(this%n_parameters, this%n_solutions + 1), intent(in) :: X
      complex(dp), dimension(this%n_solutions + 1), intent(in) :: omega

      integer :: n

      do n = 1, this%n_solutions

         if (is_real(omega(n))) then

            call this%construct_real_residual(omega(n), X(:, n), AX(:, n))

         else

            call this%construct_complex_residual_pair(omega, X, AX, n)

         end if
      end do

   end subroutine construct


   subroutine construct_real_residual(this, omega, X, R)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018-2023
      !!
      !! Constructs the real residual
      !!
      !!    R = AX - omega X
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(eigenvector_residual), intent(in) :: this

      real(dp), dimension(this%n_parameters), intent(inout) :: R
      real(dp), dimension(this%n_parameters), intent(in) :: X
      complex(dp), intent(in) :: omega

      real(dp) :: norm_X

      call daxpy(this%n_parameters, - real(omega), X, 1, R, 1)
      norm_X = get_l2_norm(X, this%n_parameters)
      call dscal(this%n_parameters, one / norm_X, R, 1)

   end subroutine construct_real_residual


   subroutine construct_complex_residual_pair(this, omega, X, R, n)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018-2023
      !!
      !! For a complex pair,
      !!
      !!    X+ = X_re + i X_im
      !!    X- = X_re - i X_im,
      !!
      !! From DGEEV, X_re and X_im are solutions l, and l + 1, respectively
      !! and omega_l and omega_(l+1) are complex conjugates.
      !!
      !! The residuals are:
      !!
      !!    R_re = [(A X_re - omega_re X_re) + omega_im X_im]/|X+|
      !!    R_im = [(A X_im - omega_re X_im) - omega_im X_re]/|X+|
      !!

      implicit none

      class(eigenvector_residual), intent(in) :: this

      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: R
      real(dp), dimension(this%n_parameters, this%n_solutions + 1), intent(in) :: X
      complex(dp), dimension(this%n_solutions + 1), intent(in) :: omega
      integer :: n

      if (real(omega(n)) == real(omega(n + 1))) then

         ! First root of complex pair  => construct the real residual
         call this%construct_complex_residual(omega(n), X(:, n), X(:, n + 1), R(:, n))

      elseif (n > 1) then

         ! Second root of complex pair => construct the imaginary residual
         call this%construct_complex_residual(omega(n), X(:, n), X(:, n - 1), R(:, n))

      end if

   end subroutine construct_complex_residual_pair


   subroutine construct_complex_residual(this, omega, X_re, X_im, R)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018-2023
      !!
      !! R = [(A X_re - omega_re X_re) + omega_im X_im]/|X+|
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(eigenvector_residual), intent(in) :: this

      complex(dp), intent(in) :: omega
      real(dp), dimension(this%n_parameters) :: R
      real(dp), dimension(this%n_parameters), intent(in) :: X_re
      real(dp), dimension(this%n_parameters), intent(in) :: X_im

      real(dp) :: norm_X_re, norm_X_im

      call daxpy(this%n_parameters, - real(omega), X_re, 1, R, 1)
      call daxpy(this%n_parameters, aimag(omega), X_im, 1, R, 1)

      norm_X_re = get_l2_norm(X_re, this%n_parameters)
      norm_X_im = get_l2_norm(X_im, this%n_parameters)

      call dscal(this%n_parameters, one / (sqrt(norm_X_re**2 + norm_X_im**2)), R, 1)

   end subroutine construct_complex_residual


end module eigenvector_residual_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module es_ea_start_vector_tool_class

   !!
   !! Excited state EA start vector tool class module
   !! Marcus T. Lexander, Ylva Os, 2024
   !!

   use ccs_class, only: ccs
   use es_start_vector_tool_class, only: es_start_vector_tool
   use state_descriptor_class, only: state_descriptor

   implicit none

   type, extends(es_start_vector_tool) :: es_ea_start_vector_tool

   contains

   end type es_ea_start_vector_tool


   interface es_ea_start_vector_tool

      procedure :: new_es_ea_start_vector_tool

   end interface es_ea_start_vector_tool


contains


   function new_es_ea_start_vector_tool(wf, descriptor, n_vectors) result(this)
      !!
      !! Written by Marcus T. Lexander, Ylva Os, 2024
      !!
      implicit none

      class(ccs), intent(in), target :: wf
      type(state_descriptor), intent(in) :: descriptor

      integer, intent(in) :: n_vectors

      type(es_ea_start_vector_tool) :: this

      this%n_vectors = n_vectors
      this%n_parameters = wf%get_n_es_parameters(descriptor)
      this%wf => wf

      allocate(this%indices(this%n_vectors))
      call wf%set_ea_start_indices(this%indices, this%n_vectors)

   end function new_es_ea_start_vector_tool


end module es_ea_start_vector_tool_class

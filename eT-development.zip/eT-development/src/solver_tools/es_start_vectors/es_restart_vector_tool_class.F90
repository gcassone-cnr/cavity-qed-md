

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module es_restart_vector_tool_class

   !!
   !! Excited state restart start vector tool class module
   !! Written by Andreas S. Skeidsvoll, Nov 2022
   !!

   use parameters
   use start_vector_tool_class, only: start_vector_tool
   use ccs_class, only: ccs

   use global_out, only: output
   use global_in, only: input
   use state_descriptor_class, only: state_descriptor

   implicit none

   type, extends(start_vector_tool) :: es_restart_vector_tool

      class(start_vector_tool), allocatable :: default_start_vector_tool
      integer, dimension(:), allocatable :: restart_state_indices
      integer :: n_vectors
      class(ccs), pointer :: wf
      type(state_descriptor) :: descriptor

   contains

      procedure, public :: get => get_es_restart_vector_tool

      procedure, public :: generate_restart_state_indices => &
                           generate_restart_state_indices_es_restart_vector_tool

   end type es_restart_vector_tool


   interface es_restart_vector_tool

      procedure :: new_es_restart_vector_tool

   end interface es_restart_vector_tool


contains


   function new_es_restart_vector_tool(wf, default_start_vector_tool, descriptor, n_vectors) result(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Nov 2022
      !!
      implicit none

      class(ccs), intent(in), target :: wf
      class(start_vector_tool), intent(in) :: default_start_vector_tool
      type(state_descriptor) :: descriptor

      type(es_restart_vector_tool) :: this
      integer, intent(in) :: n_vectors

      this%default_start_vector_tool = default_start_vector_tool
      this%wf => wf

      this%n_vectors = n_vectors
      this%n_parameters = wf%get_n_es_parameters(descriptor)
      this%descriptor = descriptor

      call this%generate_restart_state_indices()

   end function new_es_restart_vector_tool


   subroutine generate_restart_state_indices_es_restart_vector_tool(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Jan 2023
      !!
      implicit none

      class(es_restart_vector_tool) :: this

      integer :: i


      if (input%is_keyword_present('restart states', 'lanczos')) then

         this%n_vectors = input%get_n_elements_for_keyword('restart states', 'lanczos')

         allocate(this%restart_state_indices(this%n_vectors))

         call input%get_array_for_keyword('restart states', &
                                          'lanczos', &
                                          this%n_vectors, &
                                          this%restart_state_indices)

      else

         allocate(this%restart_state_indices(this%n_vectors))

         do i = 1, this%n_vectors

            this%restart_state_indices(i) = i

         end do

      end if

   end subroutine generate_restart_state_indices_es_restart_vector_tool


   subroutine get_es_restart_vector_tool(this, start_vector, I, energy)
      !!
      !! Written by Andreas S. Skeidsvoll, 2022-2023

      !! Returns a normalized state vector from a previous calculation if it
      !! exists on file. Otherwise, generate a start vector with the standard
      !! start vector tool passed as an argument during restart vector tool
      !! construction.
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(es_restart_vector_tool), intent(in) :: this
      real(dp), dimension(this%n_parameters), intent(out) :: start_vector
      integer, intent(in) :: I
      real(dp), intent(out) :: energy

      logical :: found_restart_vector
      real(dp) :: norm_


      call this%wf%check_and_get_restart_vector(start_vector, &
                                                energy, &
                                                this%restart_state_indices(I), &
                                                this%descriptor, &
                                                found_restart_vector)

      if (found_restart_vector) then

         norm_ = get_l2_norm(start_vector, this%n_parameters)
         call dscal(this%n_parameters, one / norm_, start_vector, 1)

      else

         call output%warning_msg('state (i0) does not exist on file, using standard start vector instead', &
                                 ints=[this%restart_state_indices(I)])

         call this%default_start_vector_tool%get(start_vector, &
                                                 this%restart_state_indices(I), &
                                                 energy)

      end if

   end subroutine get_es_restart_vector_tool


end module es_restart_vector_tool_class

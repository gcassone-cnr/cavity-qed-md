

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module es_operator_on_state_start_vector_tool_class

   !!
   !! Excited state operator on state start vector tool class module
   !! Written by Andreas S. Skeidsvoll, 2022-2023
   !!
   !! Generates right c and left b starting vectors from operators and ground
   !! and/or excited EOM-CC states. Contracting these starting vectors with
   !! the left L_j and right R_j vectors of another excited EOM-CC state gives
   !! the EOM-CC transition moments to this state, that is
   !!
   !!    L_j^T c_i = < psi_j | X | psi_i >
   !!    b_i^T R_j = < psi_i | X | psi_j >
   !!
   !! where c_i and b_i are constructed from the operator X and the parameters
   !! of | psi_i > and < psi_i |, respectively. For further details and
   !! derivations of expressions, see Appendix A of Phys. Rev. A 105, 023103.
   !!

   use parameters
   use es_restart_vector_tool_class, only: es_restart_vector_tool
   use ccs_class, only: ccs

   use memory_manager_class, only: mem
   use global_out, only: output
   use global_in, only: input

   use start_vector_tool_class, only: start_vector_tool

   implicit none

   type, extends(es_restart_vector_tool) :: es_operator_on_state_start_vector_tool

      integer, dimension(:), allocatable :: operator_indices
      real(dp), dimension(:, :, :), allocatable, private :: operators
      real(dp), dimension(:, :), allocatable, private :: xiX
      real(dp), dimension(9), private :: two_trace_X_oo

   contains

      procedure, public :: get => get_es_operator_on_state_start_vector_tool

      procedure, private :: generate_operator_indices

      procedure, private :: construct_operator_on_gs_vector
      procedure, private :: construct_operator_on_es_vector

   end type es_operator_on_state_start_vector_tool


   interface es_operator_on_state_start_vector_tool

      procedure :: new_es_operator_on_state_start_vector_tool

   end interface es_operator_on_state_start_vector_tool


contains


   function new_es_operator_on_state_start_vector_tool(wf, &
                                                       n_states, &
                                                       default_start_vector_tool, &
                                                       descriptor) result(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Nov 2022
      !!
      use array_initialization, only: copy_subblock
      use range_class, only: range_
      use array_utilities, only: get_trace
      use state_descriptor_class, only: state_descriptor

      implicit none

      class(ccs), intent(in), target :: wf
      class(start_vector_tool), intent(in) :: default_start_vector_tool
      type(state_descriptor), intent(in) :: descriptor
      integer, intent(in) :: n_states

      type(es_operator_on_state_start_vector_tool) :: this

      real(dp), dimension(:, :), allocatable :: X_oo

      type(range_) :: o_range

      integer :: i, j

      logical, dimension(:), allocatable :: operator_requested

      this%default_start_vector_tool = default_start_vector_tool
      this%n_vectors = n_states

      this%descriptor = descriptor
      this%n_parameters = wf%get_n_es_parameters(this%descriptor)

      this%wf => wf

      call this%generate_restart_state_indices()
      call this%generate_operator_indices()

      call mem%alloc(operator_requested, 9)

      operator_requested = .false.

      do i = 1, this%n_vectors
         do j = 1, 9
            if (j == this%operator_indices(i)) then

               operator_requested(j) = .true.

            end if
         end do
      end do

      if (any(operator_requested)) then

         o_range = range_(1, this%wf%n_o)

         allocate(this%operators(this%wf%n_mo, this%wf%n_mo, 9))

         call this%wf%get_t1_oei('dipole', this%operators(:, :, 1:3))
         call this%wf%get_t1_oei('quadrupole', this%operators(:, :, 4:9))

         allocate(this%xiX(this%n_parameters, 9))

         call mem%alloc(X_oo, this%wf%n_o, this%wf%n_o)

         do i = 1, 9

            if (operator_requested(i)) then

               call this%wf%construct_xiX(this%operators(:, :, i), this%xiX(:, i))
               call copy_subblock(this%operators(:, :, i), X_oo, o_range, o_range)
               this%two_trace_X_oo(i) = two * get_trace(X_oo, this%wf%n_o)

            end if

         end do

         call mem%dealloc(X_oo)

      end if

      call mem%dealloc(operator_requested)

   end function new_es_operator_on_state_start_vector_tool


   subroutine generate_operator_indices(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Jan 2023
      !!
      use array_initialization, only: zero_array_int

      implicit none

      class(es_operator_on_state_start_vector_tool) :: this

      allocate(this%operator_indices(this%n_vectors))

      if (input%is_keyword_present('operators', 'lanczos')) then

         if (this%n_vectors /= input%get_n_elements_for_keyword('operators', 'lanczos')) &
            call output%error_msg('the numbers of initial states and operators do not match.')

         call input%get_array_for_keyword('operators', &
                                          'lanczos', &
                                          this%n_vectors, &
                                          this%operator_indices)

      else

         call zero_array_int(this%operator_indices, this%n_vectors)

      end if

   end subroutine generate_operator_indices


   subroutine get_es_operator_on_state_start_vector_tool(this, start_vector, I, energy)
      !!
      !! Written by Andreas S. Skeidsvoll, Dec 2022
      !!
      !! Returns a start vector based on a ground or an excited state. If the
      !! operator specified in input is 0, the excited state vector is returned.
      !! If the operator is 1, 2 or 3, the ground or excited state vector is
      !! operated by a x, y or z dipole operator in a way that returns the
      !! transition moment when contracted with another excited state.
      !!
      implicit none

      class(es_operator_on_state_start_vector_tool), intent(in) :: this
      real(dp), dimension(this%n_parameters), intent(out) :: start_vector
      integer, intent(in) :: I

      real(dp), intent(out) :: energy

      if (this%operator_indices(I) == 0) then

         ! Read excited state vector file

         call this%es_restart_vector_tool%get(start_vector, I, energy)

      elseif ((this%operator_indices(I) >= 1) .and. (this%operator_indices(I) <= 9)) then

         if (this%restart_state_indices(I) == 0) then

            call this%construct_operator_on_gs_vector(I, start_vector, energy)

         else

            call this%construct_operator_on_es_vector(I, start_vector, energy)

         end if

      else

         call output%error_msg('cannot create start vector with operator index (i0).', &
                               ints=[this%operator_indices(I)])

      end if

   end subroutine get_es_operator_on_state_start_vector_tool


   subroutine construct_operator_on_gs_vector(this, I, start_vector, excitation_energy)
      !!
      !! Written by Andreas S. Skeidsvoll and Torsha Moitra, 2021-2023
      !!
      !! Start vector based on the ground state and operator X
      !!
      implicit none

      class(es_operator_on_state_start_vector_tool), intent(in) :: this
      real(dp), dimension(this%n_parameters), intent(out) :: start_vector
      integer, intent(in) :: I
      real(dp), intent(out) :: excitation_energy


      if (trim(this%descriptor%get_left_or_right()) == 'right') then

         ! Let c = xi^X

         call dcopy(this%n_parameters, this%xiX(:, this%operator_indices(I)), 1, start_vector, 1)

      elseif (trim(this%descriptor%get_left_or_right()) == 'left') then

         ! Construct b = eta^X,EOM - <HF|e^(-T)Xe^T|HF> tbar

         call this%wf%construct_eom_etaX(this%operators(:, :, this%operator_indices(I)), &
                                         this%xiX(:, this%operator_indices(I)), &
                                         start_vector)

      end if

      excitation_energy = zero

   end subroutine construct_operator_on_gs_vector


   subroutine construct_operator_on_es_vector(this, I, start_vector, excitation_energy)
      !!
      !! Written by Andreas S. Skeidsvoll and Torsha Moitra, 2021-2022
      !!
      !! Start vector based on an excited state and operator X
      !!
      implicit none

      class(es_operator_on_state_start_vector_tool), intent(in) :: this
      real(dp), dimension(this%n_parameters), intent(out) :: start_vector
      integer, intent(in) :: I
      real(dp), intent(out) :: excitation_energy

      real(dp), dimension(:), allocatable :: tbar, state_vector

      real(dp), external :: ddot


      call mem%alloc(state_vector, this%n_parameters)
      call mem%alloc(tbar, this%n_parameters)
      call this%wf%get_full_multipliers(tbar)

      call this%es_restart_vector_tool%get(state_vector, I, excitation_energy)

      ! Construct excited state start vector

      if (trim(this%descriptor%get_left_or_right()) == 'right') then

         ! Construct c = EOM A^X R(i) - xi^X (tbar . R(i))

         call this%wf%jacobianX_eom_transformation(state_vector, &
                                                   start_vector, &
                                                   this%operators(:, :, this%operator_indices(I)), &
                                                   this%xiX(:, this%operator_indices(I)))

         call this%wf%minus_xiX_tbar_transformation(state_vector, &
                                                    start_vector, &
                                                    this%xiX(:, this%operator_indices(I)), &
                                                    tbar)

      elseif (trim(this%descriptor%get_left_or_right()) == 'left') then

         ! Construct b = L(i) EOM A^X - (L(i) . xi^X) tbar

         call this%wf%jacobianX_eom_transpose_transformation(state_vector, &
                                                             start_vector, &
                                                             this%operators(:, :, this%operator_indices(I)), &
                                                             this%xiX(:, this%operator_indices(I)))

         call this%wf%minus_xiX_tbar_transpose_transformation(state_vector, &
                                                              start_vector, &
                                                              this%xiX(:, this%operator_indices(I)), &
                                                              tbar)

      end if

      call mem%dealloc(tbar)

      ! Add diagonal contribution c += 2 <HF|X^T|HF> R(i), b += 2 <HF|X^T|HF> L(i)

      call daxpy(this%n_parameters, &
                 this%two_trace_X_oo(this%operator_indices(I)), &
                 state_vector, &
                 1, &
                 start_vector, &
                 1)

      call mem%dealloc(state_vector)

   end subroutine construct_operator_on_es_vector


end module es_operator_on_state_start_vector_tool_class

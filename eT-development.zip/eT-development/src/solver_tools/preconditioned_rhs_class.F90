

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module preconditioned_rhs_class

   !!
   !! Preconditioned right-hand-side class module
   !! Written by Regina Matveeva, Sept 2021
   !!
   !! Generates start vectors for linear equation (Ax = rhs) solvers by
   !! preconditioning the right-hand-side
   !!

   use parameters
   use vector_getter_class, only: vector_getter
   use memory_manager_class, only: mem

   implicit none

   type, extends(vector_getter) :: preconditioned_rhs

      class(vector_getter), allocatable :: rhs_getter
      class(vector_getter), allocatable :: preconditioner_getter
      real(dp), dimension(:), allocatable :: frequencies
      integer :: n_frequencies, n_rhs

   contains

      procedure, public :: get => get_preconditioned_rhs

   end type preconditioned_rhs


   interface preconditioned_rhs

      procedure :: new_preconditioned_rhs

   end interface preconditioned_rhs


contains

   function new_preconditioned_rhs(n_parameters, &
                                   n_rhs, &
                                   rhs_getter, &
                                   preconditioner_getter, &
                                   n_frequencies, &
                                   frequencies) result(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      type(preconditioned_rhs) :: this

      integer, intent(in) :: n_frequencies, n_rhs, n_parameters
      class(vector_getter), intent(in) :: rhs_getter
      class(vector_getter), intent(in) :: preconditioner_getter
      real(dp), dimension(n_frequencies), intent(in) :: frequencies

      this%n_parameters = n_parameters
      this%n_frequencies = n_frequencies
      this%n_rhs = n_rhs

      allocate(this%frequencies(this%n_frequencies))
      call dcopy(this%n_frequencies, frequencies, 1, this%frequencies, 1)

      this%rhs_getter = rhs_getter
      this%preconditioner_getter = preconditioner_getter

      this%n_vectors = max(n_rhs, n_frequencies)

   end function new_preconditioned_rhs


   subroutine get_preconditioned_rhs(this, vectors)
      !!
      !! Written by Sarai D. Folkestad, 2023
      !!
      use precondition_tool_class, only: precondition_tool

      implicit none

      class(preconditioned_rhs), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      real(dp), dimension(:), allocatable :: vector
      real(dp), dimension(:, :), allocatable :: rhs
      type(precondition_tool), allocatable :: preconditioner

      integer :: i, j, k

      call mem%alloc(vector, this%n_parameters)
      call this%preconditioner_getter%get(vector)

      preconditioner = precondition_tool(this%n_parameters)
      call preconditioner%initialize_and_set_precondition_vector(vector)
      call mem%dealloc(vector)

      call mem%alloc(rhs, this%n_parameters, this%n_rhs)
      call this%rhs_getter%get(rhs)

      do k = 1, this%n_vectors

         i = 1
         if (this%n_frequencies > 1) i = k

         j = 1
         if (this%n_rhs > 1) j = k

         call dcopy(this%n_parameters, rhs(:, j), 1, vectors(:, k), 1)
         call preconditioner%do_(vectors(:, k), shift=this%frequencies(i), prefactor=one)

      end do

      call mem%dealloc(rhs)
      call preconditioner%destruct_precondition_vector()

   end subroutine get_preconditioned_rhs


end module preconditioned_rhs_class

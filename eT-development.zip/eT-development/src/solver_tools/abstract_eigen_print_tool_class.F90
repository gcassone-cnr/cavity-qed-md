

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_eigen_print_tool_class

   !!
   !! Abstract eigen print tool class module
   !! Written by Alexander C. Paul, Oct 2022
   !!

   use global_out, only: output

   implicit none

   type, abstract :: abstract_eigen_print_tool

   contains

      procedure, public, nopass :: print_iteration => print_iteration_abstract_eigen_print_tool

      procedure, public, nopass :: print_summary => print_summary_abstract_eigen_print_tool

      procedure(print_banner), public, nopass, deferred :: print_banner
      procedure(print_settings), public, nopass, deferred :: print_settings

   end type abstract_eigen_print_tool

   abstract interface

      subroutine print_banner()

         implicit none

      end subroutine print_banner


      subroutine print_settings(n_solutions, max_iterations)

         implicit none

         integer, intent(in) :: n_solutions, max_iterations

      end subroutine print_settings

   end interface

contains


   subroutine print_iteration_abstract_eigen_print_tool(n_solutions, &
                                                        eigenvalues, &
                                                        previous_eigenvalues, &
                                                        residual_norms, &
                                                        iteration)
      !!
      !! Written by Alexander C. Paul, Oct 2022
      !!
      use parameters

      implicit none

      integer, intent(in) :: n_solutions, iteration
      real(dp), dimension(n_solutions), intent(in) :: residual_norms, eigenvalues
      real(dp), dimension(n_solutions), intent(in) :: previous_eigenvalues

      real(dp) :: delta_eigenvalue

      integer :: n
      character(len=54) :: header

      header = 'Root          Eigenvalue     |residual|        Delta E'

      call output%printf('n', 'Iteration: (i5)', ints=[iteration], fs='(/t3,a)')

      call output%printf('n', header, fs='(/t3,a)')
      call output%print_separator('n', len(header), '-')

      do n = 1, n_solutions

         delta_eigenvalue = eigenvalues(n) - previous_eigenvalues(n)

         call output%printf('n', &
                            '(i4)  (f18.12)    (e11.4)    (e11.4)', &
                            reals=[eigenvalues(n), residual_norms(n), abs(delta_eigenvalue)], &
                            ints=[n], &
                            ll=120)

      end do

      call output%print_separator('n', len(header), '-')

   end subroutine print_iteration_abstract_eigen_print_tool


   subroutine print_summary_abstract_eigen_print_tool(iteration)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      integer, intent(in) :: iteration

      call output%printf('m', &
                         'Convergence criterion met in (i0) iterations!', &
                         ints=[iteration], &
                         fs='(t3,a)')

   end subroutine print_summary_abstract_eigen_print_tool


end module abstract_eigen_print_tool_class

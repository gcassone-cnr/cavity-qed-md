

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module nonlinear_davidson_print_tool_class

   !!
   !! Non-linear davidson print tool class module
   !! Written by Alexander C. Paul, Dec 2022
   !!

   use global_out, only: output
   use abstract_eigen_print_tool_class, only: abstract_eigen_print_tool

   implicit none

   type, extends(abstract_eigen_print_tool) :: nonlinear_davidson_print_tool

   contains

      procedure, public, nopass :: print_banner => print_banner_nonlinear_davidson_print_tool

      procedure, public, nopass :: print_settings => print_settings_nonlinear_davidson_print_tool

   end type nonlinear_davidson_print_tool

contains


   subroutine print_banner_nonlinear_davidson_print_tool()
      !!
      !! Written by Alexander C. Paul, Oct 2022
      !!
      use global_out, only: output

      implicit none

      character(len=100) :: name_
      character(len=500) :: description

      name_ = 'Non-linear Davidson eigenvalue equation solver'

      description = &
         'A non-linear Davidson solver that solves an eigenvalue equation: M(omega) x = omega x. The&
         & eigenvalue problem is solved in a reduced space for fixed energies, before the energies are&
         & updated and a new reduced space is built. See C. Hattig and F. Weigend, J. Chem. Phys. 113, 5154 (&
         &2000).'

      call output%printf('m', trim(name_), fs='(/t3,a)')
      call output%print_separator('m', len_trim(name_), '-')

      call output%printf('n', description, ffs='(/t3,a)', fs='(t3,a)')

   end subroutine print_banner_nonlinear_davidson_print_tool


   subroutine print_settings_nonlinear_davidson_print_tool(n_solutions, max_iterations)
      !!
      !! Written by Alexander C. Paul, Oct 2022
      !!
      implicit none

      integer, intent(in) :: n_solutions, max_iterations

      call output%printf('m', '- Non-linear davidson solver settings', fs='(/t3,a)')

      call output%printf('m', &
                         'Number of singlet states:     (i11)', &
                         ints=[n_solutions], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Max number of iterations:     (i11)', &
                         ints=[max_iterations], &
                         fs='(t6,a)')

   end subroutine print_settings_nonlinear_davidson_print_tool


end module nonlinear_davidson_print_tool_class

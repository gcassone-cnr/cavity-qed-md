

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cpp_restart_start_vector_tool_class

   !!
   !! CPP restart start vector tool class module
   !! Written by A. K. Schnack-Petersen and T. Moitra, Feb. 2023
   !! Based on tdhf start vector tool by Sarai D. Folkestad, May 2021
   !!

   use parameters
   use vector_getter_class, only: vector_getter
   use stream_file_class, only: stream_file

   implicit none

   type, extends(vector_getter) :: cpp_restart_start_vector_tool

      integer, private :: n_frequencies
      type(stream_file), dimension(:), pointer, private :: restart_files

   contains

      procedure, public :: get => get_cpp_restart_start_vector_tool

   end type cpp_restart_start_vector_tool

   interface cpp_restart_start_vector_tool

      procedure :: new_cpp_restart_start_vector_tool

   end interface cpp_restart_start_vector_tool

contains


   function new_cpp_restart_start_vector_tool(n_frequencies, &
                                              n_parameters, &
                                              restart_files) result(this)
      !!
      !! Written by A. K. Schnack-Petersen, Feb. 2023
      !!
      implicit none

      integer, intent(in) :: n_parameters, n_frequencies
      class(stream_file), dimension(n_frequencies), target :: restart_files
      type(cpp_restart_start_vector_tool) :: this

      this%n_parameters = n_parameters
      this%n_vectors = n_frequencies * 2
      this%n_frequencies = n_frequencies
      this%restart_files => restart_files

   end function new_cpp_restart_start_vector_tool


   subroutine get_cpp_restart_start_vector_tool(this, vectors)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      class(cpp_restart_start_vector_tool), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      integer :: i

      do i = 1, this%n_frequencies
         call this%restart_files(i)%open_('rewind')
         call this%restart_files(i)%read_(vectors(:, i), this%n_parameters)
         call this%restart_files(i)%read_(vectors(:, i + this%n_frequencies), this%n_parameters)
         call this%restart_files(i)%close_()
      end do

   end subroutine


end module cpp_restart_start_vector_tool_class

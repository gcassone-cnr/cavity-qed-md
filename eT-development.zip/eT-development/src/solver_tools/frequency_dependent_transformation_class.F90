

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module frequency_dependent_transformation_class

   !!
   !! Frequency-dependent transformation class
   !! Written by Sarai D. Folkestad, May 2022
   !!

   use kinds, only: dp
   use transformation_class, only: transformation

   implicit none

   type, abstract, extends(transformation) :: frequency_dependent_transformation

   contains

      procedure(set_frequency), deferred :: set_frequency

   end type frequency_dependent_transformation


   abstract interface
      subroutine set_frequency(this, frequency)

         import frequency_dependent_transformation
         import dp

         implicit none

         class(frequency_dependent_transformation), intent(inout) :: this
         real(dp), intent(in) :: frequency

      end subroutine set_frequency

   end interface


end module frequency_dependent_transformation_class

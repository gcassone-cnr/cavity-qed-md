

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module implicit_integrator_class

   !!
   !! Implicit integrator class
   !! Written by Alice Balbi, Andreas Skeidsvoll, 2019-2021
   !!

   use parameters
   use memory_manager_class, only: mem

   use td_state_class, only: td_state

   use abstract_integrator_class, only: abstract_integrator

   use global_out, only: output
   use array_initialization, only: zero_array_complex

   implicit none

   type, extends(abstract_integrator) :: implicit_integrator

      real(dp) :: implicit_threshold
      logical :: embedded

      ! Initial guess used to accelerate the convergence of equations in implicit methods, see
      ! Section VIII.6.1 (A) in Hairer et. al., Geometric Numerical Integration

      logical :: continuous_output
      real(dp), dimension(:, :), allocatable :: beta
      complex(dp), dimension(:, :), allocatable :: z_guess

   contains

      procedure, public :: do_step => do_step_implicit_integrator

      procedure, public :: initialize => initialize_implicit_integrator
      procedure, public :: cleanup => cleanup_implicit_integrator

   end type implicit_integrator


   interface implicit_integrator

      procedure :: new_implicit_integrator

   end interface implicit_integrator


contains


   function new_implicit_integrator(n_parameters, &
                                    n_stages, &
                                    A, &
                                    c, &
                                    n_solution_estimates, &
                                    b, &
                                    implicit_threshold, &
                                    beta) result(this)
      !!
      !! Written by Andreas Skeidsvoll, Sep 2019
      !!
      implicit none

      type(implicit_integrator) :: this

      integer, intent(in) :: n_parameters, n_stages, n_solution_estimates

      real(dp), dimension(n_stages, n_stages), intent(in) :: A
      real(dp), dimension(n_stages), intent(in) :: c
      real(dp), dimension(n_stages, n_solution_estimates), intent(in) :: b
      real(dp), intent(in) :: implicit_threshold
      real(dp), dimension(n_stages, n_stages), intent(in), optional :: beta

      this%n_parameters = n_parameters
      this%n_stages = n_stages
      this%n_solution_estimates = n_solution_estimates

      allocate(this%A, source = A)
      allocate(this%c, source = c)
      allocate(this%b, source = b)

      this%implicit_threshold = implicit_threshold

      this%continuous_output = present(beta)
      if (this%continuous_output) this%beta = beta

   end function new_implicit_integrator


   subroutine initialize_implicit_integrator(this)
      !!
      !! Written by Andreas Skedsvoll, 2019-2022
      !!
      implicit none

      class(implicit_integrator), intent(inout) :: this

      call mem%alloc(this%k, this%n_parameters, this%n_stages, set_zero=.true.)

      this%first_step = .true.

      if (this%continuous_output) &
         call mem%alloc(this%z_guess, this%n_parameters, this%n_stages, set_zero=.true.)

   end subroutine initialize_implicit_integrator


   subroutine cleanup_implicit_integrator(this)
      !!
      !! Written by Andreas Skedsvoll, 2019-2022
      !!
      implicit none

      class(implicit_integrator), intent(inout) :: this

      call mem%dealloc(this%k)

      if (this%continuous_output) call mem%dealloc(this%z_guess)

   end subroutine cleanup_implicit_integrator


   subroutine do_step_implicit_integrator(this, state, ti, dt, y, step_reduction, error_estimate)
      !!
      !! Written by Alice Balbi, Andreas Skeidsvoll, 2019-2021
      !!
      !! Takes a single implicit step, by calculating solution estimates of the form
      !!
      !!    y_next = y + dt*(sum_{i=1}^n_stages b_i k_i)
      !!
      !! where k_i is the time derivative of the function
      !!
      !!    y + dt*(sum_{j=1}^n_stages A_ij k_j)
      !!
      !! evaluated at time ti + c_i*dt. Note that each k_i can have an implicit dependence on all
      !! other k_j, where j = 1, n_stages, implying that a system of equations have to be solved
      !! for each step.
      !!
      !! For embedded methods, multiple solution estimates are calculated, and the error is estimated
      !! from the differences of the different solution estimates.
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(implicit_integrator), intent(inout) :: this
      class(td_state), intent(inout) :: state

      real(dp), intent(in) :: dt
      real(dp), intent(in) :: ti
      complex(dp), dimension(this%n_parameters), intent(in) :: y
      logical, intent(in) :: step_reduction
      real(dp), intent(out) :: error_estimate

      complex(dp), dimension(:, :), allocatable :: z, z_next, y_next_estimates
      complex(dp), dimension(:), allocatable :: residual
      real(dp) :: t
      integer :: iteration_count, i, j
      logical :: converged

      call do_nothing(step_reduction)

      ! Get guess of z vectors

      call mem%alloc(z, this%n_parameters, this%n_stages)

      if (this%continuous_output) then
         call zcopy(this%n_parameters * this%n_stages, this%z_guess, 1, z, 1)
      else
         call zero_array_complex(z, this%n_parameters * this%n_stages)
      end if

      ! Iterate until convergence

      iteration_count = 0
      converged = .false.

      call mem%alloc(z_next, this%n_parameters, this%n_stages)
      call mem%alloc(residual, this%n_parameters)

      do

         ! Construct derivative of the different stages

         do i = 1, this%n_stages

            t = ti + this%c(i) * dt

            ! Create td_parameters = y + z

            call zcopy(this%n_parameters, y, 1, state%td_parameters, 1)
            call zaxpy(this%n_parameters, one_complex, z(:, i), 1, state%td_parameters, 1)

            ! Construct k, the time derivative of td_parameters

            call state%construct_time_derivative(this%k(:, i), t)

         end do

         if (converged) exit
         iteration_count = iteration_count + 1

         ! Construct z vectors

         call zero_array_complex(z_next, this%n_parameters * this%n_stages)

         do i = 1, this%n_stages
            do j = 1, this%n_stages
               if (abs(this%A(i, j)) > 1.0e-14_dp) then

                  call zaxpy(this%n_parameters, &
                             cmplx(dt * this%A(i, j), zero, dp), &
                             this%k(:, j), &
                             1, &
                             z_next(:, i), &
                             1)

               end if
            end do
         end do

         ! Determine whether convergence is reached or not

         do i = 1, this%n_stages

            call zcopy(this%n_parameters, z_next(:, i), 1, residual, 1)
            call zaxpy(this%n_parameters, - one_complex, z(:, i), 1, residual, 1)

            if (norm2(real(residual)) <= this%implicit_threshold .and. &
                norm2(aimag(residual)) <= this%implicit_threshold) &
               converged = .true.

         end do

         ! Update z vectors

         call zcopy(this%n_parameters * this%n_stages, z_next, 1, z, 1)

      end do

      call mem%dealloc(z)
      call mem%dealloc(z_next)
      call mem%dealloc(residual)

      call output%printf('v', 'implicit iterations: (i6)', ints=[iteration_count], fs='(t3,a)')

      ! Use the ks to estimate the solution at time t = ti + dt

      call mem%alloc(y_next_estimates, this%n_parameters, this%n_solution_estimates)
      call this%construct_solution_estimates(y, y_next_estimates, dt)

      call zcopy(this%n_parameters, y_next_estimates(:, 1), 1, state%td_parameters, 1)

      call this%calculate_error_estimate(state%td_parameters, y_next_estimates, error_estimate)

      call mem%dealloc(y_next_estimates)

      ! Calculate guess of next z vectors

      if (this%continuous_output) then

         call zero_array_complex(this%z_guess, this%n_parameters * this%n_stages)
         do i = 1, this%n_stages
            do j = 1, this%n_stages

               call zaxpy(this%n_parameters, &
                          cmplx((this%b(j, 1) + this%beta(i, j)) * dt, zero, dp), &
                          this%k(:, j), &
                          1, &
                          this%z_guess(:, i), &
                          1)

            end do
         end do

      end if

   end subroutine do_step_implicit_integrator


end module implicit_integrator_class

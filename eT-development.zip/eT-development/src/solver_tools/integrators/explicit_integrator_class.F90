

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module explicit_integrator_class

   !!
   !! Explicit integrator class
   !! Written by Alice Balbi, Andreas Skeidsvoll, 2018-2021
   !!

   use parameters
   use memory_manager_class, only: mem

   use td_state_class, only: td_state

   use abstract_integrator_class, only: abstract_integrator

   implicit none

   type, extends(abstract_integrator) :: explicit_integrator

      logical :: first_same_as_last

   contains

      procedure, public :: do_step => do_step_explicit_integrator

   end type explicit_integrator


   interface explicit_integrator

      procedure :: new_explicit_integrator

   end interface explicit_integrator


contains


   function new_explicit_integrator(n_parameters, &
                                    n_stages, &
                                    A, &
                                    c, &
                                    n_solution_estimates, &
                                    b, &
                                    first_same_as_last) result(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Sep 2018
      !!
      implicit none

      type(explicit_integrator) :: this

      integer, intent(in) :: n_parameters, n_stages, n_solution_estimates

      real(dp), dimension(n_stages, n_stages), intent(in) :: A
      real(dp), dimension(n_stages), intent(in) :: c
      real(dp), dimension(n_stages, n_solution_estimates), intent(in) :: b
      logical, optional :: first_same_as_last

      this%n_parameters = n_parameters
      this%n_stages = n_stages
      this%n_solution_estimates = n_solution_estimates

      allocate(this%A, source = A)
      allocate(this%c, source = c)
      allocate(this%b, source = b)

      this%first_same_as_last = .false.
      if (present(first_same_as_last)) this%first_same_as_last = first_same_as_last

   end function new_explicit_integrator


   subroutine do_step_explicit_integrator(this, state, ti, dt, y, step_reduction, error_estimate)
      !!
      !! Written by Alice Balbi, Andreas Skeidsvoll, 2018-2021
      !!
      !! Takes a single explicit step, by calculating solution estimates of the form
      !!
      !!    y_next = y + dt*(sum_{i=1}^n_stages b_i k_i)
      !!
      !! where k_i is the time derivative of the function
      !!
      !!    y + dt*(sum_{j=1}^{i-1} A_ij k_j)
      !!
      !! evaluated at time ti + c_i*dt.
      !!
      !! For embedded methods, multiple solution estimates are calculated, and the error is estimated
      !! from the differences of the different solution estimates.
      !!
      implicit none

      class(explicit_integrator), intent(inout) :: this
      class(td_state), intent(inout) :: state

      real(dp), intent(in) :: dt
      real(dp), intent(in) :: ti
      complex(dp), dimension(this%n_parameters), intent(in) :: y
      logical, intent(in) :: step_reduction
      real(dp), intent(out) :: error_estimate

      complex(dp), dimension(:, :), allocatable :: y_next_estimates

      real(dp) :: t
      integer :: i, j

      do i = 1, this%n_stages

         t = ti + this%c(i) * dt

         ! Create td_parameters = y + Ak

         call zcopy(this%n_parameters, y, 1, state%td_parameters, 1)

         do j = 1, i - 1
            if (abs(this%A(i, j)) > 1.0e-14_dp) &
               call zaxpy(this%n_parameters, &
                          cmplx(this%A(i, j) * dt, zero, dp), &
                          this%k(:, j), &
                          1, &
                          state%td_parameters, &
                          1)
         end do

         ! Construct k, the time derivative of td_parameters

         if ((i == 1) .and. (.not. step_reduction)) then
            if (this%first_same_as_last .and. (.not. this%first_step)) then
               call zcopy(this%n_parameters, this%k(:, this%n_stages), 1, this%k(:, i), 1)
            else
               call state%construct_time_derivative(this%k(:, i), t)
               this%first_step = .false.
            end if

         ! Do nothing if i = 1 and step_reduction, as the first k is already calculated

         elseif (i /= 1) then
            call state%construct_time_derivative(this%k(:, i), t)
         end if

      end do

      ! Use the ks to estimate the solution at time t = ti + dt

      call mem%alloc(y_next_estimates, this%n_parameters, this%n_solution_estimates)
      call this%construct_solution_estimates(y, y_next_estimates, dt)

      call zcopy(this%n_parameters, y_next_estimates(:, 1), 1, state%td_parameters, 1)

      call this%calculate_error_estimate(state%td_parameters, y_next_estimates, error_estimate)

      call mem%dealloc(y_next_estimates)

   end subroutine do_step_explicit_integrator


end module explicit_integrator_class

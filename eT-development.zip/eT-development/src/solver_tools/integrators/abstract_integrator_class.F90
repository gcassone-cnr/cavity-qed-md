

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_integrator_class

   !!
   !! Abstract integrator class
   !! Written by Andreas S. Skeidsvoll, Nov 2020
   !!

   use parameters
   use memory_manager_class, only: mem

   use td_state_class, only: td_state

   implicit none

   type, abstract :: abstract_integrator

      integer :: n_parameters, n_stages, n_solution_estimates

      logical :: first_step

      ! A, b and c are given in the Butcher tables module, and specify the
      ! Runge-Kutta method

      real(dp), dimension(:, :), allocatable :: A  ! Runge-Kutta matrix
      real(dp), dimension(:, :), allocatable :: b  ! Weights
      real(dp), dimension(:), allocatable :: c  ! Nodes

      ! Intermediates used for constructing solution at next time step

      complex(dp), dimension(:, :), allocatable :: k

      ! Error estimates, used in embedded Runge-Kutta methods

      real(dp) :: error_estimate

   contains

      procedure(do_step_abstract_integrator), deferred, public :: do_step

      procedure, public :: initialize => initialize_abstract_integrator
      procedure, public :: cleanup => cleanup_abstract_integrator

      procedure, public :: construct_solution_estimates => construct_solution_estimates_abstract_integrator

      procedure, public :: calculate_error_estimate => calculate_error_estimate_abstract_integrator

   end type abstract_integrator

   abstract interface

      subroutine do_step_abstract_integrator(this, &
                                             state, &
                                             ti, &
                                             dt, &
                                             y, &
                                             step_reduction, &
                                             error_estimate)

         import abstract_integrator, td_state, dp

         implicit none

         class(abstract_integrator), intent(inout) :: this
         class(td_state), intent(inout) :: state

         real(dp), intent(in) :: dt
         real(dp), intent(in) :: ti
         complex(dp), dimension(this%n_parameters), intent(in) :: y
         logical, intent(in) :: step_reduction
         real(dp), intent(out) :: error_estimate

      end subroutine do_step_abstract_integrator

   end interface


contains


   subroutine initialize_abstract_integrator(this)
      !!
      !! Written by Andreas Skedsvoll, 2019-2022
      !!
      implicit none

      class(abstract_integrator), intent(inout) :: this

      call mem%alloc(this%k, this%n_parameters, this%n_stages, set_zero=.true.)

      this%first_step = .true.

   end subroutine initialize_abstract_integrator


   subroutine cleanup_abstract_integrator(this)
      !!
      !! Written by Andreas Skedsvoll, 2019-2022
      !!
      implicit none

      class(abstract_integrator), intent(inout) :: this

      call mem%dealloc(this%k)

   end subroutine cleanup_abstract_integrator


   subroutine construct_solution_estimates_abstract_integrator(this, y, y_next_estimates, dt)
      !!
      !! Written by Andreas Skeidsvoll, Apr 2020
      !!
      implicit none

      class(abstract_integrator), intent(inout) :: this

      complex(dp), dimension(this%n_parameters), intent(in) :: y
      complex(dp), dimension(this%n_parameters, this%n_solution_estimates), intent(out) :: y_next_estimates
      real(dp), intent(in) :: dt

      complex(dp) :: factor
      integer :: i, j

      ! Use the ks to estimate the solution at time t = ti + dt

      do j = 1, this%n_solution_estimates

         call zcopy(this%n_parameters, y, 1, y_next_estimates(:, j), 1)

         do i = 1, this%n_stages
            if (abs(this%b(i, j)) > 1.0e-14_dp) then
               factor = cmplx(this%b(i, j) * dt, zero, dp)
               call zaxpy(this%n_parameters, factor, this%k(:, i), 1, y_next_estimates(:, j), 1)
            end if
         end do

      end do

   end subroutine construct_solution_estimates_abstract_integrator


   subroutine calculate_error_estimate_abstract_integrator(this, y_next, y_next_estimates, error_estimate)
      !!
      !! Written by Andreas Skeidsvoll, Apr 2020
      !!
      use array_utilities, only: get_l2_norm_complex

      implicit none

      class(abstract_integrator), intent(in) :: this

      real(dp), dimension(:), allocatable :: residual_norms
      complex(dp), dimension(this%n_parameters), intent(in) :: y_next
      complex(dp), dimension(this%n_parameters, this%n_solution_estimates), intent(in) :: y_next_estimates

      real(dp), intent(out) :: error_estimate

      integer :: i

      call mem%alloc(residual_norms, this%n_solution_estimates, set_zero=.true.)

      ! Subtract solution from estimates to get residuals, calculate residual norms

      do i = 1, this%n_solution_estimates

         call zaxpy(this%n_parameters, - one_complex, y_next, 1, y_next_estimates(:, i), 1)

         residual_norms(i) = get_l2_norm_complex(y_next_estimates(:, i), this%n_parameters)

      end do

      error_estimate = residual_norms(this%n_solution_estimates)

      ! Estimate error for methods with three solution estimates in accordance with Eq. (10.17) in
      ! Harrier (1993), Solving Ordinary Differential Equations I

      if (this%n_solution_estimates > 2) then
         error_estimate = residual_norms(2)**2 / sqrt(residual_norms(2)**2 + 0.01_dp * residual_norms(3)**2)
      end if

      call mem%dealloc(residual_norms)

   end subroutine calculate_error_estimate_abstract_integrator


end module abstract_integrator_class

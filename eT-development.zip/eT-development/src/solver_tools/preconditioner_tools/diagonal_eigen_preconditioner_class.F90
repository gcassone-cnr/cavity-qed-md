

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module diagonal_eigen_preconditioner_tool_class

   !!
   !! Diagonal eigen preconditioner tool
   !! Written by Eirik Kjoenstad, Apr 2023
   !!

   use parameters
   use memory_manager_class, only: mem
   use vector_getter_class, only: vector_getter
   use multistate_precondition_tool_class, only: multistate_precondition_tool

   implicit none

   type, extends(multistate_precondition_tool) :: diagonal_eigen_preconditioner_tool

      class(vector_getter), allocatable, private :: diagonal_preconditioner_getter
      real(dp), dimension(:), allocatable, private :: diagonal

   contains

      procedure, public :: precondition => precondition_diagonal_eigen_preconditioner_tool

      procedure, public :: initialize => initialize_diagonal_eigen_preconditioner_tool

      final :: destructor

   end type diagonal_eigen_preconditioner_tool


   interface diagonal_eigen_preconditioner_tool

      procedure :: new_diagonal_eigen_preconditioner_tool

   end interface diagonal_eigen_preconditioner_tool


contains


   function new_diagonal_eigen_preconditioner_tool(preconditioner_getter) result(this)
      !!
      !! Written by Eirik Kjoenstad, Apr 2023
      !!
      implicit none

      type(diagonal_eigen_preconditioner_tool) :: this

      class(vector_getter), intent(in) :: preconditioner_getter

      this%diagonal_preconditioner_getter = preconditioner_getter
      this%n_parameters = preconditioner_getter%n_parameters

   end function new_diagonal_eigen_preconditioner_tool


   subroutine initialize_diagonal_eigen_preconditioner_tool(this)
      !!
      !! Written by Eirik Kjoenstad, Apr 2023
      !!
      implicit none

      class(diagonal_eigen_preconditioner_tool) :: this

      call mem%alloc(this%diagonal, this%n_parameters)
      this%diagonal = zero
      call this%diagonal_preconditioner_getter%get(this%diagonal)

   end subroutine initialize_diagonal_eigen_preconditioner_tool


   subroutine precondition_diagonal_eigen_preconditioner_tool(this, &
                                                              X, &
                                                              R, &
                                                              frequencies, &
                                                              state_index, &
                                                              n_vectors_to_precondition, &
                                                              n_vectors)
      !!
      !! Written by Eirik Kjoenstad, Apr 2023
      !!
      use warning_suppressor

      implicit none

      class(diagonal_eigen_preconditioner_tool) :: this

      integer, intent(in) :: n_vectors_to_precondition, n_vectors

      integer, dimension(n_vectors_to_precondition), intent(in) :: state_index

      real(dp), dimension(n_vectors), intent(in) :: frequencies

      real(dp), dimension(this%n_parameters, n_vectors), intent(in) :: X
      real(dp), dimension(this%n_parameters, n_vectors), intent(inout) :: R

      integer :: n, k, current_vector

      real(dp) :: denominator

      call do_nothing(X)

      do n = 1, n_vectors_to_precondition

         current_vector = state_index(n)

         !$omp parallel do private(k, denominator)
         do k = 1, this%n_parameters

            denominator = this%diagonal(k) - frequencies(current_vector)

            if (abs(denominator) < 1.0d-8) then

               denominator = one

            end if

            R(k, current_vector) = - R(k, current_vector) / denominator

         end do
         !$omp end parallel do

      end do

   end subroutine precondition_diagonal_eigen_preconditioner_tool


   subroutine destructor(this)
      !!
      !! Written by Eirik Kjoenstad, Apr 2023
      !!
      implicit none

      type(diagonal_eigen_preconditioner_tool) :: this

      if (allocated(this%diagonal)) call mem%dealloc(this%diagonal)

   end subroutine destructor


end module diagonal_eigen_preconditioner_tool_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module multistate_precondition_tool_class

   !!
   !! Multistate preconditioner tool
   !! Written by Eirik Kjoenstad, Apr 2023
   !!
   !! Used to precondition residuals (R) in linear and eigenvalue
   !! equations where multiple roots are simultaneously preconditioned,
   !! and the preconditioning can depend on the solutions (X)
   !!

   use kinds, only: dp

   implicit none

   type, abstract :: multistate_precondition_tool

      integer :: n_parameters

   contains

      procedure(precondition), deferred, public :: precondition
      procedure(initialize), deferred, public :: initialize

   end type multistate_precondition_tool


   abstract interface

      subroutine initialize(this)

         import :: multistate_precondition_tool

         implicit none

         class(multistate_precondition_tool) :: this

      end subroutine initialize


      subroutine precondition(this, X, R, frequencies, state_index, n_vectors_to_precondition, n_vectors)

         ! X: solutions
         ! R: residuals

         ! R is passed because the preconditioning of X may depend on R.
         ! (e.g.: Olsen preconditioner.)

         import :: multistate_precondition_tool, dp

         implicit none

         class(multistate_precondition_tool) :: this

         integer, intent(in) :: n_vectors_to_precondition, n_vectors

         integer, dimension(n_vectors_to_precondition), intent(in) :: state_index

         real(dp), dimension(n_vectors), intent(in) :: frequencies

         real(dp), dimension(this%n_parameters, n_vectors), intent(in) :: X
         real(dp), dimension(this%n_parameters, n_vectors), intent(inout) :: R

      end subroutine precondition


   end interface


end module multistate_precondition_tool_class

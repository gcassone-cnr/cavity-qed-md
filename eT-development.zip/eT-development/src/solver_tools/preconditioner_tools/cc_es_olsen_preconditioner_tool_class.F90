

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_es_olsen_preconditioner_tool_class

   !!
   !! CC ES Olsen preconditioner tool
   !! Written by Eirik Kjoenstad and Sarai D. Folkestad, 2020 and Apr 2023
   !!
   !! Preconditions eigenvalue equation residuals according to the multimodel
   !! Olsen algorithm described in J. Chem. Phys. 153, 014104 (2020).
   !!

   use parameters
   use ccs_class, only: ccs
   use memory_manager_class, only: mem
   use multistate_precondition_tool_class, only: multistate_precondition_tool
   use global_out, only: output
   use iteration_timings_class, only: iteration_timings
   use abstract_projection_tool_class, only: abstract_projection_tool

   implicit none

   type, extends(multistate_precondition_tool) :: cc_es_olsen_preconditioner_tool

      character(len=:), allocatable, private :: left_or_right
      class(abstract_projection_tool), allocatable, private :: projector
      logical, private :: records_in_memory
      class(ccs), pointer, private :: wf
      class(iteration_timings), allocatable, private :: timer

   contains

      procedure, public :: precondition => precondition_cc_es_olsen_preconditioner_tool

      procedure, public :: initialize => initialize_cc_es_olsen_preconditioner_tool

      procedure, private :: calculate_frequencies_rhs_and_residual_norms
      procedure, private :: create_davidson_solver
      procedure, private :: precondition_residuals

   end type cc_es_olsen_preconditioner_tool


   interface cc_es_olsen_preconditioner_tool

      procedure :: new_cc_es_olsen_preconditioner_tool

   end interface cc_es_olsen_preconditioner_tool


contains


   function new_cc_es_olsen_preconditioner_tool(wf, &
                                                n_parameters, &
                                                left_or_right, &
                                                projector, &
                                                records_in_memory) result(this)
      !!
      !! Written by Eirik Kjoenstad, Apr 2023
      !!
      implicit none

      type(cc_es_olsen_preconditioner_tool) :: this

      class(ccs), target :: wf
      integer, intent(in) :: n_parameters
      character(len=*), intent(in) :: left_or_right
      class(abstract_projection_tool), intent(in) :: projector
      logical, intent(in) :: records_in_memory

      this%n_parameters = n_parameters
      this%wf => wf
      this%left_or_right = trim(left_or_right)
      this%projector = projector
      this%records_in_memory = records_in_memory

   end function new_cc_es_olsen_preconditioner_tool


   subroutine initialize_cc_es_olsen_preconditioner_tool(this)
      !!
      !! Written by Eirik Kjoenstad, Apr 2023
      !!
      use warning_suppressor
      use citation_printer_class, only: eT_citations

      implicit none

      class(cc_es_olsen_preconditioner_tool) :: this

      this%timer = iteration_timings('Olsen microiterations cycle', 'n')
      call eT_citations%add('Multimodel Newton algorithm')

   end subroutine initialize_cc_es_olsen_preconditioner_tool


   subroutine calculate_frequencies_rhs_and_residual_norms(this, &
                                                           n_vectors_to_precondition, &
                                                           n_vectors, &
                                                           state_index, &
                                                           X, &
                                                           R, &
                                                           frequencies, &
                                                           olsen_frequencies, &
                                                           RHS, &
                                                           residual_norms)
      !!
      !! Written by Eirik Kjoenstad, Apr 2023
      !!
      !! Olsen equations:
      !!
      !!    (A - omega_k) Y_k = R_k
      !!    (A - omega_k) W_k = X_k * norm(R_k)
      !!
      !! The Y equations forms the first (n_vectors_to_precondition) columns
      !! The W equations from the following (n_vectors_to_precondition) columns
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(cc_es_olsen_preconditioner_tool) :: this

      integer, intent(in) :: n_vectors_to_precondition
      integer, intent(in) :: n_vectors

      integer, dimension(n_vectors_to_precondition), intent(in) :: state_index

      real(dp), dimension(n_vectors), intent(in) :: frequencies

      real(dp), dimension(this%n_parameters, n_vectors), intent(in) :: X
      real(dp), dimension(this%n_parameters, n_vectors), intent(inout) :: R

      real(dp), dimension(2 * n_vectors_to_precondition), intent(out) :: olsen_frequencies

      real(dp), dimension(this%n_parameters, 2 * n_vectors_to_precondition), intent(out) :: RHS

      real(dp), dimension(n_vectors_to_precondition), intent(out) :: residual_norms

      integer :: vector, state

      do vector = 1, n_vectors_to_precondition

         state = state_index(vector)

         call dcopy(this%n_parameters, &
                    R(:, state), &
                    1, &
                    RHS(:, vector), &
                    1)

         call dcopy(this%n_parameters, &
                    X(:, state), &
                    1, &
                    RHS(:, n_vectors_to_precondition + vector), &
                    1)

         residual_norms(vector) = get_l2_norm(RHS(:, vector), this%n_parameters)

         call dscal(this%n_parameters, &
                    residual_norms(vector), &
                    RHS(:, n_vectors_to_precondition + vector), &
                    1)

         olsen_frequencies(vector) = frequencies(state)
         olsen_frequencies(n_vectors_to_precondition + vector) = frequencies(state)

      end do

   end subroutine calculate_frequencies_rhs_and_residual_norms


   subroutine create_davidson_solver(this, &
                                     solver, &
                                     olsen_threshold, &
                                     n_vectors_to_precondition, &
                                     olsen_vectors, &
                                     olsen_frequencies, &
                                     RHS)
      !!
      !! Written by Eirik Kjoenstad, Apr 2023
      !!
      !! Creates the solver used to solve the linear Olsen equations for Y and W
      !!
      use file_linear_equation_storage_tool_class, only: file_linear_equation_storage_tool
      use vector_copy_getter_class, only: vector_copy_getter
      use linear_davidson_multiple_solutions_print_tool_class, &
         only: linear_davidson_multiple_solutions_print_tool

      use approximate_cc_jacobian_transformation_class, only: approximate_cc_jacobian_transformation
      use linear_davidson_solver_class, only: linear_davidson_solver
      use cc_jacobian_preconditioner_getter_class, only: cc_jacobian_preconditioner_getter

      use stream_file_class, only: stream_file
      use state_descriptor_class, only: state_descriptor
      use transformation_class, only: transformation

      use convergence_tool_class, only: convergence_tool
      use vector_getter_class, only: vector_getter
      use preconditioned_rhs_class, only: preconditioned_rhs

      implicit none

      class(cc_es_olsen_preconditioner_tool) :: this

      class(linear_davidson_solver), allocatable, intent(out) :: solver

      real(dp), intent(in) :: olsen_threshold

      integer, intent(in) :: n_vectors_to_precondition

      type(stream_file), dimension(2 * n_vectors_to_precondition), intent(inout) :: olsen_vectors

      real(dp), dimension(2 * n_vectors_to_precondition), intent(in) :: olsen_frequencies

      real(dp), dimension(this%n_parameters, 2 * n_vectors_to_precondition), intent(in), target :: RHS

      class(file_linear_equation_storage_tool), allocatable :: storer
      class(vector_copy_getter), allocatable :: rhs_getter
      class(cc_jacobian_preconditioner_getter), allocatable :: preconditioner_getter
      class(linear_davidson_multiple_solutions_print_tool), allocatable :: printer
      class(vector_getter), allocatable :: start_vector
      type(convergence_tool), allocatable :: convergence_checker
      class(transformation), allocatable :: transformer

      printer = linear_davidson_multiple_solutions_print_tool(print_level='n')

      transformer = approximate_cc_jacobian_transformation(this%wf, &
                                                           state_descriptor(left_or_right= &
                                                              this%left_or_right, cvs=.false., ip=.false., &
                                                              rm_core=.false., ea=.false., &
                                                              spin_symmetry='singlet'))

      storer = file_linear_equation_storage_tool(n_parameters=this%n_parameters, &
                                                 n_solutions=2 * n_vectors_to_precondition, &
                                                 files=olsen_vectors)

      preconditioner_getter = cc_jacobian_preconditioner_getter(this%wf, this%n_parameters)

      rhs_getter = vector_copy_getter(n_parameters=this%n_parameters, &
                                      n_vectors=2 * n_vectors_to_precondition, &
                                      vectors=RHS)

      convergence_checker = convergence_tool(olsen_threshold)

      start_vector = preconditioned_rhs(this%n_parameters, &
                                        2 * n_vectors_to_precondition, &
                                        rhs_getter, &
                                        preconditioner_getter, &
                                        2 * n_vectors_to_precondition, &
                                        olsen_frequencies)

      solver = linear_davidson_solver(transformer=transformer, &
                                      convergence_checker=convergence_checker, &
                                      storer=storer, &
                                      preconditioner_getter=preconditioner_getter, &
                                      rhs_getter=rhs_getter, &
                                      printer=printer, &
                                      projector=this%projector, &
                                      n_parameters=this%n_parameters, &
                                      n_rhs=2 * n_vectors_to_precondition, &
                                      n_frequencies=2 * n_vectors_to_precondition, &
                                      max_iterations=100 * 2 * n_vectors_to_precondition, &
                                      frequencies=olsen_frequencies, &
                                      linear_dependence_threshold=min(1.0d-11, olsen_threshold), &
                                      reduced_space_in_memory=this%records_in_memory, &
                                      max_reduced_dimension=max(100, 10 * n_vectors_to_precondition), &
                                      start_vector=start_vector)

   end subroutine create_davidson_solver


   subroutine precondition_residuals(this, &
                                     R, &
                                     X, &
                                     RHS, &
                                     state_index, &
                                     n_vectors_to_precondition, &
                                     n_vectors)
      !!
      !! Written by Eirik Kjoenstad, Apr 2023
      !!
      !! Assumes the Y and W Olsen solutions are in RHS & calculates:
      !!
      !!    R_k = Y_k - beta_k W_k
      !!
      implicit none

      class(cc_es_olsen_preconditioner_tool) :: this

      integer, intent(in) :: n_vectors_to_precondition, n_vectors

      real(dp), dimension(this%n_parameters, n_vectors), intent(inout) :: R

      real(dp), dimension(this%n_parameters, n_vectors), intent(in) :: X

      ! Contains Olsen vectors (Y,W)
      real(dp), dimension(this%n_parameters, 2 * n_vectors_to_precondition), intent(in) :: RHS

      integer, dimension(n_vectors_to_precondition), intent(in) :: state_index

      real(dp) :: XTY, XTW, beta, ddot

      integer :: vector, state

      do vector = 1, n_vectors_to_precondition

         state = state_index(vector)

         ! beta = X^T Y / X^T W
         XTY = ddot(this%n_parameters, &
                    X(:, state), &
                    1, &
                    RHS(:, vector), &  ! Y
                    1)

         XTW = ddot(this%n_parameters, &
                    X(:, state), &
                    1, &
                    RHS(:, n_vectors_to_precondition + vector), &  ! W
                    1)

         beta = XTY / XTW

         ! R = Y - beta * W

         call dcopy(this%n_parameters, &
                    RHS(:, vector), &  ! Y
                    1, &
                    R(:, state), &
                    1)

         call daxpy(this%n_parameters, &
                    - beta, &
                    RHS(:, n_vectors_to_precondition + vector), &  ! W
                    1, &
                    R(:, state), &
                    1)

         call this%projector%project(R(:, state))

      end do

   end subroutine precondition_residuals


   subroutine precondition_cc_es_olsen_preconditioner_tool(this, &
                                                           X, &
                                                           R, &
                                                           frequencies, &
                                                           state_index, &
                                                           n_vectors_to_precondition, &
                                                           n_vectors)
      !!
      !! Written by Eirik Kjoenstad, Apr 2023
      !!
      !! Calculates the preconditioned residual vector as:
      !!
      !!    R_k = Y_k - beta_k W_k
      !!
      !! where Y_k and W_k are given by solving the Olsen equations
      !!
      !!    (A - omega_k) Y_k = R_k
      !!    (A - omega_k) W_k = X_k * norm(R_k)
      !!
      !! The Y equations forms the first (n_vectors_to_precondition) columns of right-hand-side (RHS).
      !! The W equations from the following (n_vectors_to_precondition) columns of RHS.
      !!
      !! The constant beta_k is evaluated as:
      !!
      !!    beta_k = X_k^T Y_k / X_k^T W_k
      !!
      !! Here and above, k is the iteration number, X_k is the current solution vector,
      !! and R_k is the residual on entry and the preconditioned residual on exit.
      !!
      use linear_davidson_solver_class, only: linear_davidson_solver
      use stream_file_class, only: stream_file

      implicit none

      class(cc_es_olsen_preconditioner_tool) :: this

      integer, intent(in) :: n_vectors_to_precondition, n_vectors

      integer, dimension(n_vectors_to_precondition), intent(in) :: state_index

      real(dp), dimension(n_vectors), intent(in) :: frequencies

      real(dp), dimension(this%n_parameters, n_vectors), intent(in) :: X
      real(dp), dimension(this%n_parameters, n_vectors), intent(inout) :: R

      real(dp), dimension(:, :), allocatable, target :: RHS
      real(dp), dimension(2 * n_vectors_to_precondition) :: olsen_frequencies
      real(dp), dimension(:), allocatable :: residual_norms

      type(stream_file), dimension(:), allocatable :: olsen_vectors

      class(linear_davidson_solver), allocatable :: solver

      real(dp) :: olsen_threshold
      integer :: k
      character(len=200) :: file_name

      call this%timer%turn_on()

      call output%mute()

      call mem%alloc(RHS, this%n_parameters, 2 * n_vectors_to_precondition)
      call mem%alloc(residual_norms, n_vectors_to_precondition)

      call this%calculate_frequencies_rhs_and_residual_norms(n_vectors_to_precondition, &
                                                             n_vectors, &
                                                             state_index, &
                                                             X, &
                                                             R, &
                                                             frequencies, &
                                                             olsen_frequencies, &
                                                             RHS, &
                                                             residual_norms)

      olsen_threshold = 1.0d-1 * minval(residual_norms)
      call mem%dealloc(residual_norms)

      allocate(olsen_vectors(2 * n_vectors_to_precondition))

      do k = 1, 2 * n_vectors_to_precondition

         write(file_name, '(a, i3.3)')'olsen_vector_', k
         olsen_vectors(k) = stream_file(trim(file_name))

      end do

      call this%create_davidson_solver(solver, &
                                       olsen_threshold, &
                                       n_vectors_to_precondition, &
                                       olsen_vectors, &
                                       olsen_frequencies, &
                                       RHS)

      call solver%run()
      call solver%cleanup()


      ! Read solutions into RHS to save storage space
      do k = 1, 2 * n_vectors_to_precondition

         call olsen_vectors(k)%open_('rewind')
         call olsen_vectors(k)%read_(RHS(:, k), this%n_parameters)
         call olsen_vectors(k)%close_("delete")

      end do

      deallocate(olsen_vectors)

      call this%precondition_residuals(R, &
                                       X, &
                                       RHS, &
                                       state_index, &
                                       n_vectors_to_precondition, &
                                       n_vectors)

      call mem%dealloc(RHS)

      call output%unmute()

      call this%timer%turn_off()

   end subroutine precondition_cc_es_olsen_preconditioner_tool


end module cc_es_olsen_preconditioner_tool_class

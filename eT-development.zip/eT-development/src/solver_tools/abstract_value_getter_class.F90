

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module abstract_value_getter_class

   !!
   !! Abstract value getter tool class module
   !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
   !!

   use kinds

   implicit none

   type, abstract :: abstract_value_getter

   contains

      procedure(get), deferred, public :: get

   end type abstract_value_getter


   abstract interface

      function get(this) result(value_)
         !!
         !! Written by Sarai D. Folkestad and Regina Matveeva, Sept 2021
         !!
         import dp
         import abstract_value_getter

         implicit none

         class(abstract_value_getter), intent(in) :: this
         real(dp) :: value_

      end function get

   end interface


end module abstract_value_getter_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module vector_getter_class

   !!
   !! Vector getter class module
   !! Written by Rosario R. Riso and Alexander C. Paul, Oct 2022
   !!
   !! Defines interface for vector getter
   !!

   implicit none

   type, abstract :: vector_getter

      integer :: n_parameters, n_vectors

   contains

      procedure(get_vector_getter), deferred, public :: get

   end type vector_getter

   abstract interface

      subroutine get_vector_getter(this, vectors)

         use kinds
         import vector_getter

         implicit none

         class(vector_getter), intent(inout) :: this
         real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      end subroutine get_vector_getter

   end interface

end module vector_getter_class

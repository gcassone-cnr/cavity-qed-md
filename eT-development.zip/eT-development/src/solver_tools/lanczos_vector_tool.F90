

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module lanczos_vector_tool_class

   !!
   !! CC Lanczos vector tool class module
   !! Written by Andreas S. Skeidsvoll, 2023
   !!
   !! Contains memory array and storer used for storing the Lanczos vectors in
   !! the band Lanczos method, and routines for manipulating these vectors.
   !!

   use parameters, only: dp
   use memory_manager_class, only: mem
   use record_storer_class, only: record_storer

   implicit none

   type :: lanczos_vector_tool

      character :: V_or_W
      integer :: n_parameters, max_deflations, remaining_deflations, band_length, &
                 index_first_candidate_in_band
      integer, dimension(:), allocatable :: deflation_locations

      real(dp), dimension(:, :), allocatable :: vector_band
      class(record_storer), allocatable :: vector_storer

   contains

      procedure, public :: initialize => initialize_lanczos_vector_tool
      procedure, public :: cleanup => cleanup_lanczos_vector_tool

      procedure, public :: deflate_vector_band

      procedure, public :: shift_vector_band_indices_down_by_one

   end type lanczos_vector_tool

   interface lanczos_vector_tool

      procedure :: new_lanczos_vector_tool

   end interface lanczos_vector_tool

contains

   function new_lanczos_vector_tool(n_parameters, &
                                    V_or_W, &
                                    max_deflations, &
                                    max_deflations_other_side, &
                                    max_iterations, &
                                    records_in_memory) result(this)
      !!
      !! Written by Andreas S. Skeidsvoll, 2023
      !!
      implicit none

      integer, intent(in) :: n_parameters, max_iterations, max_deflations, max_deflations_other_side
      character, intent(in) :: V_or_W
      logical, intent(in) :: records_in_memory

      type(lanczos_vector_tool) :: this

      this%n_parameters = n_parameters
      this%V_or_W = V_or_W

      this%max_deflations = max_deflations
      this%remaining_deflations = max_deflations

      this%band_length = max_deflations_other_side + 1 + max_deflations
      this%index_first_candidate_in_band = max_deflations_other_side + 1

      this%vector_storer = record_storer('band_lanczos_' // this%V_or_W, &
                                         this%n_parameters, &
                                         max_iterations, &
                                         records_in_memory)

   end function new_lanczos_vector_tool


   subroutine initialize_lanczos_vector_tool(this, starting_vectors)
      !!
      !! Written by Andreas S. Skeidsvoll, 2023
      !!
      implicit none

      class(lanczos_vector_tool), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%max_deflations), intent(in) :: starting_vectors

      call this%vector_storer%initialize()

      call mem%alloc(this%vector_band, this%n_parameters, this%band_length, set_zero=.true.)

      call dcopy(this%n_parameters * this%max_deflations, &
                 starting_vectors, &
                 1, &
                 this%vector_band(:, this%index_first_candidate_in_band + 1:this%band_length), &
                 1)  ! TODO: have to look at this

      call mem%alloc(this%deflation_locations, this%max_deflations, set_zero=.true.)

   end subroutine initialize_lanczos_vector_tool


   subroutine cleanup_lanczos_vector_tool(this)
      !!
      !! Written by Andreas S. Skeidsvoll, 2023
      !!
      implicit none

      class(lanczos_vector_tool), intent(inout) :: this

      call this%vector_storer%finalize()

      call mem%dealloc(this%vector_band)
      call mem%dealloc(this%deflation_locations)

   end subroutine cleanup_lanczos_vector_tool


   subroutine deflate_vector_band(this, iteration, no_remaining_deflations)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      implicit none

      class(lanczos_vector_tool), intent(inout) :: this

      integer, intent(in) :: iteration
      logical, intent(out) :: no_remaining_deflations

      integer :: deflation_index

      real(dp), dimension(:), allocatable :: temp

      deflation_index = this%max_deflations - this%remaining_deflations + 1

      ! Store deflated vector in temp

      call mem%alloc(temp, this%n_parameters)

      call dcopy(this%n_parameters, &
                 this%vector_band(:, this%index_first_candidate_in_band), &
                 1, &
                 temp, &
                 1)

      this%deflation_locations(deflation_index) = iteration - this%remaining_deflations

      this%remaining_deflations = this%remaining_deflations - 1

      if (this%remaining_deflations == 0) then

         no_remaining_deflations = .true.

      else

         no_remaining_deflations = .false.

         ! Shift candidate vectors down by one

         call this%shift_vector_band_indices_down_by_one(this%index_first_candidate_in_band, &
                                                         this%index_first_candidate_in_band &
                                                            + this%remaining_deflations)

         ! The deflated vector is now stored in vector_band(last+1-deflation_index) and the
         ! corresponding other side vector in other_vector_band(deflation_index). These columns of
         ! the vector bands have now been freed, and will not be changed from now on.

         call dcopy(this%n_parameters, &
                    temp, &
                    1, &
                    this%vector_band(:, this%band_length + 1 - deflation_index), &
                    1)

      end if

      call mem%dealloc(temp)

   end subroutine deflate_vector_band


   subroutine shift_vector_band_indices_down_by_one(this, first, last)
      !!
      !! Written by Torsha Moitra, Andreas S. Skeidsvoll, 2021-2023
      !!
      !! Shifts each of the the band vectors
      !!
      !!    vector_band(:,first+1:last)
      !!
      !! down by one, to
      !!
      !!    vector_band(:,first:last-1)
      !!
      implicit none

      class(lanczos_vector_tool), intent(inout) :: this

      integer, intent(in) :: first, last

      integer :: k

      do k = first, last - 1

         call dcopy(this%n_parameters, this%vector_band(:, k + 1), 1, this%vector_band(:, k), 1)

      end do

   end subroutine shift_vector_band_indices_down_by_one


end module lanczos_vector_tool_class

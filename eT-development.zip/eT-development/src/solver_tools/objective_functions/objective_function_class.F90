

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module objective_function_class

   !!
   !! Objective Function
   !! Written by Eirik F. Kjoenstad, 2021
   !!
   !! Class that represents a function, where one can evaluate function values
   !! (and values of derivatives) given set of specifiable parameters
   !!

   use kinds, only: dp
   use global_out, only: output
   use memory_manager_class, only: mem
   use output_file_class, only: output_file

   implicit none

   type, abstract :: objective_function

      real(dp) :: step_size
      character(len=:), allocatable :: gradient_method

      type(output_file) :: optimization_iterations_file

      integer :: n_parameters

   contains

      procedure(get_parameters), deferred, public :: get_parameters
      procedure(set_parameters), deferred, public :: set_parameters
      procedure(get), deferred, public :: get
      procedure(analytical_gradient), deferred, public :: analytical_gradient
      procedure(initialize), deferred, public :: initialize
      procedure, public :: get_gradient

      procedure, private :: numerical_gradient_forward_difference
      procedure, private :: numerical_gradient_central_difference

   end type objective_function


   abstract interface

      function get_parameters(this) result(x)

         import :: objective_function, dp

         implicit none

         class(objective_function), intent(in) :: this

         real(dp), dimension(this%n_parameters) :: x

      end function get_parameters


      subroutine set_parameters(this, x)

         import :: objective_function, dp

         implicit none

         class(objective_function), intent(inout) :: this

         real(dp), dimension(this%n_parameters), intent(in) :: x

      end subroutine set_parameters


      function get(this) result(energy)

         import :: objective_function, dp

         implicit none

         class(objective_function), intent(inout) :: this

         real(dp) :: energy

      end function get


      subroutine analytical_gradient(this, g)

         import :: objective_function, dp

         implicit none

         class(objective_function), intent(inout) :: this

         real(dp), dimension(this%n_parameters), intent(out) :: g

      end subroutine analytical_gradient


      subroutine initialize(this)

         import :: objective_function

         implicit none

         class(objective_function), intent(inout) :: this

      end subroutine initialize

   end interface

contains


   subroutine numerical_gradient_forward_difference(this, g, h)
      !!
      !! Written by Jan Haakon M. Trabski, Feb 2022
      !!
      !! g = (f(x+h) - f(x)) / h
      !!

      implicit none

      class(objective_function), intent(inout) :: this
      real(dp), dimension(this%n_parameters), intent(out) :: g
      real(dp), intent(in) :: h

      real(dp), dimension(:), allocatable :: x, x0
      real(dp) :: E0, E
      integer :: i

      call mem%alloc(x, this%n_parameters)
      call mem%alloc(x0, this%n_parameters)

      E0 = this%get()

      ! Get parameters (current geometry), x_0 is updated from last iteration.

      x0 = this%get_parameters()

      ! Calculating numerical gradient for each position

      call output%mute()
      call this%optimization_iterations_file%mute()

      do i = 1, this%n_parameters

         call dcopy(this%n_parameters, x0, 1, x, 1)
         x(i) = x(i) + h
         call this%set_parameters(x)
         E = this%get()
         g(i) = (E - E0) / h

      end do

      call output%unmute()
      call this%optimization_iterations_file%unmute()

      call this%set_parameters(x0)

      call mem%dealloc(x)
      call mem%dealloc(x0)

   end subroutine numerical_gradient_forward_difference


   subroutine numerical_gradient_central_difference(this, g, h)
      !!
      !! Written by Jan Haakon M. Trabski, March 2022
      !!
      !! g = (f(x-h) - f(x+h)) / 2h
      !!

      implicit none

      class(objective_function), intent(inout) :: this
      real(dp), dimension(this%n_parameters), intent(out) :: g
      real(dp), intent(in) :: h

      real(dp), dimension(:), allocatable :: x_p, x_n, x0
      real(dp) :: E_p, E_n
      integer :: i

      call mem%alloc(x_n, this%n_parameters)
      call mem%alloc(x_p, this%n_parameters)
      call mem%alloc(x0, this%n_parameters)

      x0 = this%get_parameters()

      ! Calculating numerical gradient for each position

      call output%mute()
      call this%optimization_iterations_file%mute()

      do i = 1, this%n_parameters

         call dcopy(this%n_parameters, x0, 1, x_p, 1)
         x_p(i) = x_p(i) + h
         call dcopy(this%n_parameters, x0, 1, x_n, 1)
         x_n(i) = x_n(i) - h

         call this%set_parameters(x_n)
         E_n = this%get()

         call this%set_parameters(x_p)
         E_p = this%get()

         g(i) = (E_p - E_n) / (2 * h)

      end do

      call output%unmute()
      call this%optimization_iterations_file%unmute()

      call this%set_parameters(x0)

      call mem%dealloc(x_n)
      call mem%dealloc(x_p)
      call mem%dealloc(x0)

   end subroutine numerical_gradient_central_difference


   function get_gradient(this) result(g)
      !!
      !! Written by Eirik F. Kjoenstad, 2021 and 2023
      !!
      implicit none

      class(objective_function), intent(inout) :: this

      real(dp), dimension(this%n_parameters) :: g

      if (trim(this%gradient_method) == "analytical") then

         call this%analytical_gradient(g)

      else if (trim(this%gradient_method) == "forward difference") then

         call this%numerical_gradient_forward_difference(g, this%step_size)

      else if (trim(this%gradient_method) == "central difference") then

         call this%numerical_gradient_central_difference(g, this%step_size)

      else

         call output%error_msg('Could not recognize gradient method in get_gradient')

      end if

   end function get_gradient


end module objective_function_class

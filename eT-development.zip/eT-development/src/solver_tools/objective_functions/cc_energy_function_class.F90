

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_energy_function_class

   !!
   !! CC energy function
   !! Written by Eirik F. Kjoenstad, 2021
   !!

   use kinds
   use hf_class, only: hf
   use ccs_class, only: ccs
   use objective_function_class, only: objective_function
   use output_file_class, only: output_file

   implicit none

   type, extends(objective_function), abstract :: cc_energy_function

      class(ccs), pointer, public :: wf
      class(hf), pointer, public :: ref_wf

      logical, public :: first_iteration

   contains

      procedure :: get_parameters => get_parameters_cc_energy_function

      procedure :: set_parameters => set_parameters_cc_energy_function

      procedure(update_wavefunction), deferred :: update_wavefunction

      procedure :: initialize => initialize_cc_energy_function

   end type cc_energy_function


   abstract interface

      subroutine update_wavefunction(this)

         import :: cc_energy_function

         implicit none

         class(cc_energy_function) :: this

      end subroutine update_wavefunction

   end interface


contains


   function get_parameters_cc_energy_function(this) result(x)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(cc_energy_function), intent(in) :: this

      real(dp), dimension(this%n_parameters) :: x

      real(dp), dimension(3, this%wf%n_atomic_centers) :: geometry

      geometry = this%wf%get_molecular_geometry()

      call dcopy(this%n_parameters, geometry, 1, x, 1)

   end function get_parameters_cc_energy_function


   subroutine set_parameters_cc_energy_function(this, x)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(cc_energy_function), intent(inout) :: this

      real(dp), dimension(this%n_parameters), intent(in) :: x

      call this%wf%set_geometry(x, 'bohr')
      call this%ref_wf%set_geometry(x, 'bohr')

      call this%wf%ao%print_centers('angstrom')
      call this%wf%ao%print_centers('bohr')

      call this%wf%ao%append_geometry_to_xyz(this%optimization_iterations_file)

      call this%update_wavefunction()

   end subroutine set_parameters_cc_energy_function


   subroutine initialize_cc_energy_function(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(cc_energy_function), intent(inout) :: this

      call this%update_wavefunction()

      this%optimization_iterations_file = output_file("eT.optimization_iterations.xyz")
      call this%optimization_iterations_file%open_()

      call this%wf%ao%append_geometry_to_xyz(this%optimization_iterations_file)

   end subroutine initialize_cc_energy_function


end module cc_energy_function_class

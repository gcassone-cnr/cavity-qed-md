

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_es_energy_function_class

   !!
   !! CC ES energy function
   !! Written by Eirik F. Kjoenstad, 2021
   !!

   use kinds
   use hf_class, only: hf
   use ccs_class, only: ccs
   use cc_energy_function_class, only: cc_energy_function

   implicit none

   type, extends(cc_energy_function) :: cc_es_energy_function

      integer, private :: state

      integer, private :: n_states

   contains

      procedure :: get => get_cc_es_energy_function

      procedure :: update_wavefunction => update_wavefunction_cc_es_energy_function

      procedure :: analytical_gradient => analytical_gradient_cc_es_energy_function

   end type cc_es_energy_function


   interface cc_es_energy_function

      procedure :: new_cc_es_energy_function

   end interface cc_es_energy_function


contains


   function new_cc_es_energy_function(wf, &
                                      ref_wf, &
                                      state, &
                                      gradient_method, &
                                      step_size, &
                                      first_iteration) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      type(cc_es_energy_function) :: this

      class(hf), target :: ref_wf
      class(ccs), target :: wf

      integer, intent(in) :: state

      character(len=*), intent(in) :: gradient_method
      real(dp), intent(in) :: step_size

      logical, intent(in), optional :: first_iteration

      this%wf => wf
      this%ref_wf => ref_wf

      this%state = state

      this%n_parameters = 3 * wf%n_atomic_centers

      this%first_iteration = .true.
      if (present(first_iteration)) this%first_iteration = first_iteration

      allocate(this%gradient_method, source = gradient_method)
      this%step_size = step_size

   end function new_cc_es_energy_function


   function get_cc_es_energy_function(this) result(energy)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(cc_es_energy_function), intent(inout) :: this

      real(dp) :: energy

      energy = this%wf%energy + this%wf%R_es_states%read_energy(this%state)

   end function get_cc_es_energy_function


   subroutine update_wavefunction_cc_es_energy_function(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      use hf_gs_engine_class, only: hf_gs_engine
      use eri_approximator_task_class, only: eri_approximator_task
      use cc_amplitudes_task_class, only: cc_amplitudes_task
      use cc_es_amplitudes_task_class, only: cc_es_amplitudes_task
      use biorthonormalization_task_class, only: biorthonormalization_task
      use global_in, only: input
      use state_descriptor_class, only: state_descriptor, es_type
      use cc_es_states_handler_class, only: cc_es_states_handler
      use memory_manager_class, only: mem

      implicit none

      class(cc_es_energy_function) :: this

      class(hf_gs_engine), allocatable :: hf_engine

      type(eri_approximator_task) :: eri_approximator
      type(cc_amplitudes_task), allocatable :: ground_state_amplitudes
      type(cc_es_amplitudes_task), allocatable :: excited_state_amplitudes
      type(biorthonormalization_task), allocatable :: biorthonormalization

      type(state_descriptor), allocatable :: descriptor
      type(es_type), dimension(:), allocatable :: types

      integer :: i, n
      integer, dimension(:), allocatable :: n_states
      logical :: restart

      if (.not. this%first_iteration) then

         hf_engine = hf_gs_engine()
         call hf_engine%ignite(this%ref_wf)

         call this%wf%cleanup()
         call this%wf%initialize_from_hf(this%ref_wf)

      end if

      call eri_approximator%execute(this%wf)

      ground_state_amplitudes = cc_amplitudes_task()
      call ground_state_amplitudes%execute(this%wf)

      if (.not. this%first_iteration) then
         deallocate(this%wf%R_es_states)  ! Make a reset routine
         this%wf%R_es_states = cc_es_states_handler('right')
      end if

      n = input%get_n_es_types()
      allocate(types(n))
      call mem%alloc(n_states, n)

      call input%get_es_types(n, types)

      call input%get_n_es_states(n, n_states, 'singlet')

      do i = 1, n

         descriptor = state_descriptor('right', types(i), 'singlet')

         restart = .false.
         excited_state_amplitudes = cc_es_amplitudes_task(descriptor, restart, n_states(n))
         call excited_state_amplitudes%execute(this%wf)

         deallocate(excited_state_amplitudes)
         deallocate(descriptor)

         if (this%gradient_method == "analytical") then

            if (.not. this%first_iteration) then
               deallocate(this%wf%L_es_states)  ! Make a reset routine
               this%wf%L_es_states = cc_es_states_handler('left')
            end if

            descriptor = state_descriptor('left', types(i), 'singlet')

            restart = .false.
            excited_state_amplitudes = cc_es_amplitudes_task(descriptor, restart, n_states(n))
            call excited_state_amplitudes%execute(this%wf)

         end if

      end do

      if (this%gradient_method == "analytical") then

         biorthonormalization = biorthonormalization_task()
         call biorthonormalization%execute(this%wf)

      end if

      this%n_states = this%wf%R_es_states%n_total

      if (this%first_iteration) this%first_iteration = .false.
      call mem%dealloc(n_states)

   end subroutine update_wavefunction_cc_es_energy_function


   subroutine analytical_gradient_cc_es_energy_function(this, g)
      !!
      !! Written by Eirik F. Kjoenstad, June 2023
      !!
      implicit none

      class(cc_es_energy_function), intent(inout) :: this

      real(dp), dimension(this%n_parameters), intent(out) :: g

      call this%wf%initialize_density_intermediates(this%n_states)
      call this%wf%prepare_for_molecular_gradients()

      call this%wf%calculate_molecular_gradient(g, this%state)

      call this%wf%destruct_density_intermediates()
      call this%wf%finalize_for_molecular_gradients()

   end subroutine analytical_gradient_cc_es_energy_function


end module cc_es_energy_function_class

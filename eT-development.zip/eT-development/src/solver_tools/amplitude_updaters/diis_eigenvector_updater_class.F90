

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module diis_eigenvector_updater_class

   !!
   !! DIIS eigenvector updater class module
   !! Written by Alexander C. Paul, 2022
   !!
   !! Parameter updater to solve the eigenvalue problem
   !!
   !!    A R = omega R   or   L^T A = omega L^T.
   !!
   !! using the direct inversion of the iterative subspace (DIIS) algorithm.
   !! See Pulay, P. Convergence acceleration of iterative sequences.
   !! The case of SCF iteration. Chem. Phys. Lett. 1980, 73, 393-398.
   !! This algorithm combines estimates for the parameters and the errors
   !! and finds a least-squares solution to the error being zero
   !! (see diis_tool for more details).
   !!
   !! The update estimates used in DIIS are the following. Assuming we
   !! are solving for a vector R, the update estimate is
   !!
   !!    R_mu <- R_mu - Residual_mu/(epsilon_mu - omega),
   !!
   !! where Residual = A R - omega R and omega = R^T A R. (R is normalized.)
   !!
   !! This solver can handle the non-linear eigenvalue problems as for example
   !! in folded CC2 and CC3 excited state equations.
   !!
   !!    A(omega) R = omega R   or    L^T A(omega) = omega L^T.
   !!
   !! In this case this tool is only used to update the parameters while
   !! the eigenvalues (omega) are updated in the solver.
   !!
   !! Literature for DIIS/CC2: C. Hattig and F. Weigend,
   !! J. Chem. Phys. 113, 5154 (2000).
   !!
   !! Note/warning for usage: if poor starting guesses for L and R,
   !! are used this solver often finds duplicate roots and may in some
   !! cases not converge.
   !!

   use eigenvector_updater_class, only: eigenvector_updater

   use parameters
   use diis_tool_class, only: diis_tool
   use precondition_tool_class, only: precondition_tool
   use vector_getter_class, only: vector_getter

   implicit none

   type, extends(eigenvector_updater) :: diis_eigenvector_updater

      class(diis_tool), dimension(:), allocatable, private :: diis
      class(precondition_tool), allocatable, private :: preconditioner
      class(vector_getter), allocatable, private :: precondition_getter

   contains

      procedure :: initialize => initialize_diis_eigenvector_updater
      procedure :: update => update_diis_eigenvector_updater
      procedure :: finalize => finalize_diis_eigenvector_updater


   end type diis_eigenvector_updater


   interface diis_eigenvector_updater

      procedure :: new_diis_eigenvector_updater

   end interface diis_eigenvector_updater


contains


   function new_diis_eigenvector_updater(diis_tools, &
                                         precondition_getter, &
                                         n_parameters, &
                                         n_solutions) result(this)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      implicit none

      type(diis_eigenvector_updater) :: this

      integer, intent(in) :: n_parameters, n_solutions

      class(diis_tool), dimension(n_solutions), intent(in) :: diis_tools
      class(vector_getter), intent(in) :: precondition_getter

      this%n_parameters = n_parameters
      this%n_solutions = n_solutions

      this%precondition_getter = precondition_getter

      allocate(this%diis(this%n_solutions), source = diis_tools)

   end function new_diis_eigenvector_updater


   subroutine initialize_diis_eigenvector_updater(this)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      use memory_manager_class, only: mem

      implicit none

      class(diis_eigenvector_updater), intent(inout) :: this

      integer :: solution
      real(dp), dimension(:), allocatable :: preconditioner_vector

      do solution = 1, this%n_solutions
         call this%diis(solution)%initialize()
      end do

      call mem%alloc(preconditioner_vector, this%n_parameters)
      call this%precondition_getter%get(preconditioner_vector)

      this%preconditioner = precondition_tool(this%n_parameters)
      call this%preconditioner%initialize_and_set_precondition_vector(preconditioner_vector)

      call mem%dealloc(preconditioner_vector)

   end subroutine initialize_diis_eigenvector_updater


   subroutine update_diis_eigenvector_updater(this, &
                                              parameters, &
                                              residuals, &
                                              frequencies, &
                                              converged)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      !! Perform DIIS extrapolation to the optimal next guess for the trial,
      !! then normalize it to avoid accumulating norm in the trial
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(diis_eigenvector_updater), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: parameters
      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: residuals
      real(dp), dimension(this%n_solutions), intent(in) :: frequencies
      logical, dimension(this%n_solutions), intent(in) :: converged

      integer :: solution
      real(dp) :: norm

      do solution = 1, this%n_solutions

         if (converged(solution)) cycle

         call this%preconditioner%do_(residuals(:, solution), &
                                      shift=frequencies(solution), &
                                      prefactor=- one)

         call daxpy(this%n_parameters, &
                    one, &
                    residuals(:, solution), &
                    1, &
                    parameters(:, solution), &
                    1)

         call this%diis(solution)%update(residuals(:, solution), parameters(:, solution))

         norm = get_l2_norm(parameters(:, solution), this%n_parameters)
         call dscal(this%n_parameters, one / norm, parameters(:, solution), 1)

      end do

   end subroutine update_diis_eigenvector_updater


   subroutine finalize_diis_eigenvector_updater(this)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      implicit none

      class(diis_eigenvector_updater), intent(inout) :: this

      integer :: solution

      do solution = 1, this%n_solutions

         call this%diis(solution)%finalize()

      end do

      call this%preconditioner%destruct_precondition_vector()
      deallocate(this%diis)

   end subroutine finalize_diis_eigenvector_updater


end module diis_eigenvector_updater_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module newton_raphson_updater_class
   !!
   !! Newton-Raphson updater class module
   !! Written by Eirik F. Kjoenstad, 2020
   !!
   !! Updates the amplitudes according to a Newton-Raphson estimate,
   !!
   !!    amplitudes_mu = amplitudes_mu - (A^-1)_mu,nu residual_nu,
   !!
   !! where A is the Jacobian matrix.
   !!
   use parameters
   use amplitude_updater_class, only: amplitude_updater
   use ccs_class, only: ccs
   use transformation_class, only: transformation

   implicit none

   type, extends(amplitude_updater) :: newton_raphson_updater

      real(dp), private :: relative_threshold
      logical, private :: records_in_memory
      integer, private :: max_dim_red
      integer, private :: max_iterations

      character(len=1), private :: print_level

      class(transformation), allocatable :: transformer

   contains

      procedure :: calculate_update => calculate_update_newton_raphson_updater

   end type newton_raphson_updater


   interface newton_raphson_updater

      procedure :: new_newton_raphson_updater

   end interface newton_raphson_updater


contains


   function new_newton_raphson_updater(n_amplitudes, &
                                       scale_amplitudes, &
                                       scale_residual, &
                                       relative_threshold, &
                                       records_in_memory, &
                                       max_iterations, &
                                       transformer) result(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !!
      !! scale_amplitudes / scale_residual: if true, scales the diagonal of the double
      !!                                    amplitudes by a factor of two
      !! relative_threshold:                convergence threshold relative to residual norm
      !! records_in_memory:                 in Davidson, place trials/transforms in memory;
      !!                                    otherwise, they are on disk
      !! max_iterations:                    error if reached without convergence
      !! transformer:                       transformation to use;
      !!                                    see transformation_class and descendants.
      !!
      implicit none

      integer, intent(in) :: n_amplitudes, max_iterations

      logical, intent(in) :: records_in_memory, scale_amplitudes, scale_residual

      real(dp), intent(in) :: relative_threshold

      class(transformation), intent(in) :: transformer

      type(newton_raphson_updater) :: this

      this%n_amplitudes = n_amplitudes
      this%scale_amplitudes = scale_amplitudes
      this%scale_residual = scale_residual
      this%relative_threshold = relative_threshold
      this%records_in_memory = records_in_memory
      this%max_dim_red = 50
      this%max_iterations = max_iterations
      this%transformer = transformer
      this%print_level = 'v'

   end function new_newton_raphson_updater


   subroutine calculate_update_newton_raphson_updater(this, wf, residual, update)
      !!
      !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2018-2020
      !!
      !! Solves the equation A (update) = - (residual) for the update vector.
      !!

      use timings_class, only: timings
      use array_utilities, only: get_l2_norm
      use linear_davidson_solver_class, only: linear_davidson_solver
      use vector_copy_getter_class, only: vector_copy_getter
      use null_projection_tool_class, only: null_projection_tool
      use cc_jacobian_preconditioner_getter_class, only: cc_jacobian_preconditioner_getter
      use null_linear_storage_tool_class, only: null_linear_storage_tool
      use linear_davidson_single_solution_print_tool_class, only: linear_davidson_single_solution_print_tool
      use convergence_tool_class, only: convergence_tool
      use vector_getter_class, only: vector_getter
      use preconditioned_rhs_class, only: preconditioned_rhs

      implicit none

      class(newton_raphson_updater), intent(inout) :: this

      class(ccs), intent(inout) :: wf

      real(dp), dimension(this%n_amplitudes), intent(inout) :: residual
      real(dp), dimension(this%n_amplitudes), intent(inout) :: update

      class(null_linear_storage_tool), allocatable :: storer
      class(vector_copy_getter), allocatable :: rhs_getter
      class(vector_getter), allocatable :: start_vector
      class(linear_davidson_solver), allocatable :: solver
      class(cc_jacobian_preconditioner_getter), allocatable :: preconditioner_getter
      class(null_projection_tool), allocatable :: projector
      class(linear_davidson_single_solution_print_tool), allocatable :: printer
      type(convergence_tool), allocatable :: convergence_checker

      real(dp) :: residual_threshold, linear_dependence_threshold
      real(dp), dimension(1) :: frequencies

      type(timings), allocatable :: timer

      timer = timings('Newton-Raphson total update time', pl='n')
      call timer%turn_on()

      call wf%construct_fock(task='es')

      residual_threshold = get_l2_norm(residual, this%n_amplitudes) * this%relative_threshold

      printer = linear_davidson_single_solution_print_tool(print_level='v')

      storer = null_linear_storage_tool()

      preconditioner_getter = cc_jacobian_preconditioner_getter(wf, this%n_amplitudes)
      rhs_getter = vector_copy_getter(this%n_amplitudes, 1, residual)
      projector = null_projection_tool(this%n_amplitudes)

      convergence_checker = convergence_tool(residual_threshold)

      linear_dependence_threshold = min(1.0d-11, residual_threshold)

      frequencies = zero
      start_vector = preconditioned_rhs(this%n_amplitudes, &
                                        1, &
                                        rhs_getter, &
                                        preconditioner_getter, &
                                        1, &
                                        frequencies)

      solver = linear_davidson_solver(transformer=this%transformer, &
                                      convergence_checker=convergence_checker, &
                                      storer=storer, &
                                      preconditioner_getter=preconditioner_getter, &
                                      rhs_getter=rhs_getter, &
                                      printer=printer, &
                                      projector=projector, &
                                      n_parameters=this%n_amplitudes, &
                                      n_rhs=1, &
                                      n_frequencies=1, &
                                      max_iterations=this%max_iterations, &
                                      frequencies=frequencies, &
                                      linear_dependence_threshold=linear_dependence_threshold, &
                                      reduced_space_in_memory=this%records_in_memory, &
                                      max_reduced_dimension=this%max_dim_red, &
                                      start_vector=start_vector, &
                                      skip_convergence_summary=.true., &
                                      skip_banner=.true.)

      call solver%run()
      call solver%get_solution(update, 1)
      call solver%cleanup()

      call dscal(this%n_amplitudes, - one, update, 1)

      call timer%turn_off()

   end subroutine calculate_update_newton_raphson_updater


end module newton_raphson_updater_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module nonlinear_davidson_eigenvector_updater_class

   !!
   !! Non-linear davidson eigenvector updater class module
   !! Written by Eirik F. Kjoenstad, Alexander C. Paul, 2019-2022
   !!
   !! Based in part on the original Davidson solver written by Sarai D. Folkestad
   !! and Eirik F. Kjoenstad, 2018-2019
   !!
   !! Solves the eigenvalue problem
   !!
   !!    A(omega) R = omega R   or   L^T A(omega) = omega L^T.
   !!
   !! for a set of start vectors R/L for a given omega using the davidson algorithm.
   !!
   !! This is used to solver for the eigenvectors of the coupled cluster Jacobian
   !! for the folded CCn methods where the Jacobian depends on the excitation energy.
   !! This tool is used to update the eigenvectors while the eigenvalues
   !! are updated in some macro iteration.
   !!
   !! The algorithm implemented here is described by C. Hattig and F. Weigend,
   !! J. Chem. Phys. 113, 5154 (2000).
   !!

   use parameters
   use eigenvector_updater_class, only: eigenvector_updater
   use global_out, only: output
   use abstract_projection_tool_class, only: abstract_projection_tool
   use frequency_dependent_transformation_class, only: frequency_dependent_transformation

   use record_storer_class, only: record_storer
   use reduced_matrix_maker_class, only: reduced_matrix_maker
   use reduced_overlap_maker_class, only: reduced_overlap_maker
   use reduced_space_class, only: reduced_space
   use full_space_vector_maker_class, only: full_space_vector_maker
   use multistate_precondition_tool_class, only: multistate_precondition_tool


   implicit none

   type, extends(eigenvector_updater) :: nonlinear_davidson_eigenvector_updater

      type(full_space_vector_maker), private :: full_space_vector_maker_
      class(abstract_projection_tool), allocatable, private :: projector
      class(frequency_dependent_transformation), allocatable, private :: transformer

      class(reduced_space), allocatable, private :: trials
      class(record_storer), allocatable, private :: transforms
      class(reduced_matrix_maker), allocatable, private :: A_red
      class(reduced_overlap_maker), allocatable, private :: S_red
      class(multistate_precondition_tool), allocatable, private :: preconditioner

      real(dp), private :: threshold, relative_threshold
      integer, private :: max_iterations

   contains

      procedure :: initialize => initialize_nonlinear_davidson_eigenvector_updater
      procedure :: update => update_nonlinear_davidson_eigenvector_updater
      procedure :: finalize => finalize_nonlinear_davidson_eigenvector_updater

      procedure, private :: get_largest_residual_norm
      procedure, private :: test_convergence_and_add_trials
      procedure, private :: print_iteration


   end type nonlinear_davidson_eigenvector_updater


   interface nonlinear_davidson_eigenvector_updater

      procedure :: new_nonlinear_davidson_eigenvector_updater

   end interface nonlinear_davidson_eigenvector_updater


contains


   function new_nonlinear_davidson_eigenvector_updater(transformer, &
                                                       preconditioner, &
                                                       projector, &
                                                       n_parameters, &
                                                       n_solutions, &
                                                       threshold, &
                                                       relative_threshold, &
                                                       max_iterations, &
                                                       max_reduced_dimension, &
                                                       linear_dependence_threshold, &
                                                       records_in_memory) result(this)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      implicit none

      type(nonlinear_davidson_eigenvector_updater) :: this

      class(frequency_dependent_transformation), intent(in) :: transformer
      class(abstract_projection_tool), intent(in) :: projector
      class(multistate_precondition_tool), intent(in) :: preconditioner

      logical, intent(in) :: records_in_memory

      integer, intent(in) :: n_parameters, n_solutions, max_iterations, max_reduced_dimension
      real(dp), intent(in) :: threshold, relative_threshold, linear_dependence_threshold

      integer :: corrected_max_reduced_dimension

      this%n_parameters = n_parameters
      this%n_solutions = n_solutions

      this%threshold = threshold
      this%relative_threshold = relative_threshold

      this%max_iterations = max_iterations

      allocate(this%transformer, source = transformer)
      allocate(this%projector, source = projector)

      this%preconditioner = preconditioner

      corrected_max_reduced_dimension = min(max_reduced_dimension, this%n_parameters)

      this%trials = reduced_space('eigen_davidson_trials_updater', &
                                  this%n_parameters, &
                                  corrected_max_reduced_dimension, &
                                  records_in_memory, &
                                  n_orthonormalizations=2, &
                                  linear_dependence_threshold=linear_dependence_threshold)


      this%transforms = record_storer('eigen_davidson_transforms_updater', &
                                      this%n_parameters, &
                                      corrected_max_reduced_dimension, &
                                      records_in_memory)

      this%A_red = reduced_matrix_maker()
      this%S_red = reduced_overlap_maker()

   end function new_nonlinear_davidson_eigenvector_updater


   subroutine initialize_nonlinear_davidson_eigenvector_updater(this)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      implicit none

      class(nonlinear_davidson_eigenvector_updater), intent(inout) :: this

      call this%preconditioner%initialize()

   end subroutine initialize_nonlinear_davidson_eigenvector_updater


   subroutine update_nonlinear_davidson_eigenvector_updater(this, &
                                                            parameters, &
                                                            residuals, &
                                                            frequencies, &
                                                            converged)
      !!
      !! Written by Eirik F. Kjoenstad, Alexander C. Paul, 2019-2022
      !!
      !! Solve the eigenvalue problem defined by the transformation tool
      !! and the given frequencies using the davidson algorithm.
      !! This algorithm is slightly modified compared to an eigen davidson
      !! because we need to keep track of the eigenvector a trial belongs to
      !! since the eigenvalue problem is different for each eigenvector.
      !!
      use warning_suppressor, only: do_nothing
      use timings_class, only: timings
      use memory_manager_class, only: mem
      use array_utilities, only: invert
      use lapack_wrappers, only: diagonalize_non_symmetric

      implicit none

      class(nonlinear_davidson_eigenvector_updater), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: parameters
      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: residuals
      real(dp), dimension(this%n_solutions), intent(in) :: frequencies
      logical, dimension(this%n_solutions), intent(in) :: converged

      real(dp), dimension(:), allocatable :: trial
      real(dp), dimension(:), allocatable :: transform

      real(dp), dimension(:), allocatable :: amplitude_norms, residual_norms
      logical, dimension(:), allocatable :: converged_

      integer :: corresponding_solution  ! solution that corresponds to trial
      integer, dimension(:), allocatable :: trial_to_solution  ! map from trial to corresponding solution

      complex(dp), dimension(:), allocatable :: omega
      real(dp), dimension(:, :), allocatable :: A_red_, S_red_inv, X_red

      real(dp) :: local_threshold, max_residual, lindep_threshold
      integer :: i, iteration, n_transformations

      character(len=40) :: timer_name
      type(timings) :: iteration_timer, timer

      integer :: first, last

      call do_nothing(converged)

      call this%trials%initialize()
      call this%transforms%initialize()

      timer = timings('Non-linear davidson total update time', pl='n')

      call output%printf('n', 'Starting on microiterations', fs='(/t6,a)')

      ! The residual threshold in the microiterations is taken to be proportional to the maximum
      ! residual norm in the current macroiteration or the final residual threshold

      max_residual = this%get_largest_residual_norm(residuals)
      local_threshold = max(half * this%threshold, this%relative_threshold * max_residual)
      lindep_threshold = min(1.0d-11, local_threshold)

      call this%trials%set_linear_dependence_threshold(lindep_threshold)

      call mem%alloc(trial, this%n_parameters)
      call mem%alloc(trial_to_solution, this%n_solutions)

      do i = 1, this%n_solutions

         call this%trials%copy_record_in(parameters(:, i), i)
         trial_to_solution(i) = i

         call dcopy(this%n_parameters, residuals(:, i), 1, trial, 1)
         call daxpy(this%n_parameters, frequencies(i), parameters(:, i), 1, trial, 1)

         call this%transforms%copy_record_in(trial, i)

      end do

      ! Initialize quantities used in the loop
      ! and enter the iterative micro iterations Davidson loop

      call mem%alloc(transform, this%n_parameters)
      call mem%alloc(converged_, this%n_solutions, set_to=.false.)
      call mem%alloc(amplitude_norms, this%n_solutions, set_zero=.true.)
      call mem%alloc(residual_norms, this%n_solutions, set_zero=.true.)

      iteration = 0
      n_transformations = 0

      do while (.not. all(converged_) .and. iteration <= this%max_iterations)

         iteration = iteration + 1

         write(timer_name, '(a,i0)')'Non-linear Davidson: micro iteration ', iteration
         iteration_timer = timings(trim(timer_name), pl="n")
         call iteration_timer%turn_on()

         call mem%alloc(omega, this%trials%n_written_records)

         call this%A_red%construct(this%trials, this%transforms)
         call this%S_red%construct(this%trials)

         call mem%alloc(X_red, this%trials%n_written_records, this%trials%n_written_records)
         call mem%alloc(S_red_inv, this%trials%n_written_records, this%trials%n_written_records)
         call mem%alloc(A_red_, this%trials%n_written_records, this%trials%n_written_records)
         call invert(S_red_inv, this%S_red%matrix, this%trials%n_written_records)

         ! To solve A X = w S X, we transform the system to (S^-1 A) X = w X
         ! by redefining the A matrix as S^-1 A.

         call dgemm('N', &
                    'N', &
                    this%trials%n_written_records, &
                    this%trials%n_written_records, &
                    this%trials%n_written_records, &
                    one, &
                    S_red_inv, &
                    this%trials%n_written_records, &
                    this%A_red%matrix, &
                    this%trials%n_written_records, &
                    zero, &
                    A_red_, &
                    this%trials%n_written_records)

         call mem%dealloc(S_red_inv)
         call diagonalize_non_symmetric(this%trials%n_written_records, A_red_, X_red, omega)
         call mem%dealloc(A_red_)

         call this%test_convergence_and_add_trials(parameters, &
                                                   amplitude_norms, &
                                                   residual_norms, &
                                                   converged_, &
                                                   trial_to_solution, &
                                                   local_threshold, &
                                                   lindep_threshold, &
                                                   omega, &
                                                   X_red)

         call this%print_iteration(iteration, residual_norms, omega)

         if (.not. all(converged_)) then

            ! Reduced space preparations

            ! Transform new orthonormalized trial vectors
            first = this%transforms%n_written_records + 1
            last = this%trials%n_written_records

            do i = first, last

               n_transformations = n_transformations + 1

               call this%trials%copy_record_out(trial, i)

               ! From which solution residual did this trial vector originate?
               ! We use that solution's energy in the Jacobian transformation of the trial

               corresponding_solution = trial_to_solution(i - first + 1)

               call this%transformer%set_frequency(frequencies(corresponding_solution))
               call this%transformer%transform(trial, transform)

               call this%projector%project(transform)

               call this%transforms%copy_record_in(transform, i)

            end do

         end if
         call mem%dealloc(omega)
         call mem%dealloc(X_red)

         call iteration_timer%turn_off()
         call iteration_timer%reset()

      end do  ! End of iterative loop!

      ! Note: the full space solutions are not orthonormal in general because the metric
      !       is not equal to the identity matrix:

      ! x^T x = sum_ij x_i b_i^T b_j x_j = x_red^T S_red x_red,   x_red^T x_red = 1.

      ! Hence, we have to normalize the converged solutions.
      ! (This is also why we divide by the norm of X when testing convergence above.)

      do i = 1, this%n_solutions

         call dscal(this%n_parameters, one / amplitude_norms(i), parameters(:, i), 1)

      end do

      call output%printf('n', &
                         'Number of micro iterations: (i0)', &
                         ints=[iteration], &
                         fs='(/t6,a)')

      call output%printf('n', &
                         'Number of transformations:  (i0)', &
                         ints=[n_transformations], &
                         fs='(t6,a/)')

      if (.not. all(converged_)) then

         call output%error_msg( &
                 'Unable to converge equations in the given maximum number of micro iterations. Try to&
                 & increase the value.' &
              )

      end if

      call mem%dealloc(trial)
      call mem%dealloc(transform)
      call mem%dealloc(amplitude_norms)
      call mem%dealloc(residual_norms)
      call mem%dealloc(trial_to_solution)
      call mem%dealloc(converged_)

      call this%A_red%reset()
      call this%S_red%reset()

      call this%trials%finalize()
      call this%transforms%finalize()

   end subroutine update_nonlinear_davidson_eigenvector_updater


   function get_largest_residual_norm(this, residuals) result(largest_norm)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(nonlinear_davidson_eigenvector_updater), intent(in) :: this
      real(dp), dimension(this%n_parameters, this%n_solutions), intent(in) :: residuals

      integer :: solution
      real(dp) :: norm, largest_norm

      largest_norm = zero

      do solution = 1, this%n_solutions

         norm = get_l2_norm(residuals(:, solution), this%n_parameters)
         largest_norm = max(largest_norm, norm)

      end do

   end function get_largest_residual_norm


   subroutine test_convergence_and_add_trials(this, &
                                              parameters, &
                                              amplitude_norms, &
                                              residual_norms, &
                                              converged_, &
                                              trial_to_solution, &
                                              local_threshold, &
                                              lindep_threshold, &
                                              omega, &
                                              X_red)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      !! - Get residual and solution
      !! - Test convergence
      !! - Add new trial if needed and residual norm is greater
      !!   than linear dependence threshold
      !!
      use array_utilities, only: get_l2_norm
      use eigenvector_residual_class, only: eigenvector_residual
      use memory_manager_class, only: mem
      use array_utilities, only: extract_columns

      implicit none

      class(nonlinear_davidson_eigenvector_updater), intent(inout) :: this

      real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: parameters
      real(dp), dimension(this%n_solutions), intent(inout) :: amplitude_norms, residual_norms
      complex(dp), dimension(this%n_solutions), intent(inout) :: omega
      logical, dimension(this%n_solutions), intent(inout) :: converged_
      integer, dimension(this%n_solutions), intent(inout) :: trial_to_solution
      real(dp), dimension(this%trials%n_written_records), intent(inout) :: X_red

      class(eigenvector_residual), allocatable :: residual_calculator

      real(dp), intent(in) :: local_threshold, lindep_threshold

      integer :: trial, solution, n_solutions_to_construct, n_new_trials

      real(dp), dimension(:, :), allocatable :: R
      real(dp), dimension(:, :), allocatable :: X

      logical, dimension(:), allocatable :: add_residual_as_trial

      trial = 0

      n_solutions_to_construct = min(this%n_solutions + 1, this%trials%n_written_records)

      ! To make residuals for complex solutions, we potentially need an extra solution vector
      call mem%alloc(X, this%n_parameters, n_solutions_to_construct)
      call mem%alloc(R, this%n_parameters, this%n_solutions)

      call this%full_space_vector_maker_%construct_full_space_vector(this%trials, &
                                                                     n_solutions_to_construct, &
                                                                     this%trials%n_written_records, &
                                                                     X_red, &
                                                                     X)

      call this%full_space_vector_maker_%construct_full_space_vector(this%transforms, &
                                                                     this%n_solutions, &
                                                                     this%trials%n_written_records, &
                                                                     X_red, &
                                                                     R)

      residual_calculator = eigenvector_residual(this%n_parameters, this%n_solutions)
      call residual_calculator%construct(R, X, omega)
      call dcopy(this%n_parameters * this%n_solutions, X, 1, parameters, 1)

      do solution = 1, this%n_solutions

         amplitude_norms(solution) = get_l2_norm(X(:, solution), this%n_parameters)
         residual_norms(solution) = get_l2_norm(R(:, solution), this%n_parameters) / amplitude_norms(solution)

         converged_(solution) = residual_norms(solution) <= local_threshold

         if (converged_(solution)) cycle

         if (residual_norms(solution) <= lindep_threshold) then

            call output%warning_msg( &
                    'Residual norm for root (i0) smaller than linear ' // &
                       'dependence threshold, but energy' // &
                       'threshold has not yet been met. No new trial ' // 'added for this root.', &
                    ints=[solution], &
                    fs='(/t6,a)' &
                 )

         else

            trial = trial + 1

            call this%projector%project(R(:, solution))

            trial_to_solution(trial) = solution

         end if

      end do

      call mem%alloc(add_residual_as_trial, this%n_solutions)
      add_residual_as_trial = (.not. converged_) .and. residual_norms > lindep_threshold

      n_new_trials = count(add_residual_as_trial)

      if (this%trials%n_written_records + n_new_trials >= this%trials%get_max_reduced_dimension()) then

         call this%trials%reset_written_records()
         call this%transforms%reset_written_records()
         call this%A_red%reset()
         call this%S_red%reset()

         call this%trials%orthonormalize_and_add_vectors(this%n_solutions, X)

         do solution = 1, this%n_solutions

            trial_to_solution(solution) = solution

         end do

      else

         if (n_new_trials > 0) then

            call this%preconditioner%precondition(X, &
                                                  R, &
                                                  real(omega, kind=dp), &
                                                  trial_to_solution, &
                                                  n_new_trials, &
                                                  this%n_solutions)

            call extract_columns(this%n_parameters, this%n_solutions, R, add_residual_as_trial)
            call this%trials%orthonormalize_and_add_vectors(n_new_trials, R)

         end if

      end if

      call mem%dealloc(add_residual_as_trial)

      call mem%dealloc(X)
      call mem%dealloc(R)

   end subroutine test_convergence_and_add_trials


   subroutine print_iteration(this, iteration, residual_norms, omega)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      implicit none

      class(nonlinear_davidson_eigenvector_updater), intent(in) :: this

      integer, intent(in) :: iteration
      real(dp), dimension(this%n_solutions) :: residual_norms
      complex(dp), dimension(this%n_solutions) :: omega

      integer :: solution, separator_length = 68

      call output%printf('v', 'Micro iteration: (i0)', ints=[iteration], fs='(/t6,a)')

      call output%printf('v', &
                         'Reduced space dimension: (i0)', &
                         ints=[this%trials%n_written_records], &
                         fs='(t6,a)')

      call output%printf('v', &
                         'Root     Eigenvalue (Re)        Eigenvalue (Im)      Residual norm', &
                         fs='(/t6,a)')

      call output%print_separator('v', separator_length, '-', fs='(t6,a)')

      do solution = 1, this%n_solutions

         call output%printf('v', &
                            '(i4)   (f16.12)       (f16.12)           (e11.4)', &
                            ints=[solution], &
                            fs='(t6,a)', &
                            reals=[real(omega(solution)), aimag(omega(solution)), residual_norms(solution)])

      end do

      call output%print_separator('v', separator_length, '-', fs='(t6,a)')

   end subroutine print_iteration


   subroutine finalize_nonlinear_davidson_eigenvector_updater(this)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      implicit none

      class(nonlinear_davidson_eigenvector_updater), intent(inout) :: this

      deallocate(this%transformer)
      deallocate(this%projector)

      call this%A_red%deallocate_matrix()
      call this%S_red%deallocate_matrix()

   end subroutine finalize_nonlinear_davidson_eigenvector_updater


end module nonlinear_davidson_eigenvector_updater_class

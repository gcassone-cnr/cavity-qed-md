

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module eigenvector_updater_class

   !!
   !! Eigenvector updater class module
   !! Written by Alexander C. Paul, 2022
   !!

   use kinds

   implicit none

   type, abstract :: eigenvector_updater

      integer :: n_parameters, n_solutions

   contains

      procedure(update), deferred :: update
      procedure(initialize), deferred :: initialize
      procedure(finalize), deferred :: finalize


   end type eigenvector_updater


   abstract interface

      subroutine update(this, parameters, residuals, frequencies, converged)
         !!
         !! Written by Alexander C. Paul, 2022
         !!
         !! Calculates updated parameters
         !!
         import eigenvector_updater, dp

         implicit none

         class(eigenvector_updater), intent(inout) :: this

         real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: parameters
         real(dp), dimension(this%n_parameters, this%n_solutions), intent(inout) :: residuals
         real(dp), dimension(this%n_solutions), intent(in) :: frequencies
         logical, dimension(this%n_solutions), intent(in) :: converged

      end subroutine update


      subroutine initialize(this)

         import eigenvector_updater

         implicit none

         class(eigenvector_updater), intent(inout) :: this

      end subroutine initialize


      subroutine finalize(this)

         import eigenvector_updater

         implicit none

         class(eigenvector_updater), intent(inout) :: this

      end subroutine finalize


   end interface


end module eigenvector_updater_class

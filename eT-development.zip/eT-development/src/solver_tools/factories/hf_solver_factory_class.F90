

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_solver_factory_class

   !!
   !! HF solver factory class
   !! Written by Sarai D. Folkestad, May 2021
   !!


   use kinds
   use global_out, only: output
   use hf_class, only: hf

   use abstract_solver_class, only: abstract_solver
   use abstract_value_getter_class, only: abstract_value_getter
   use convergence_tool_class, only: convergence_tool

   implicit none

   type :: hf_solver_factory

      integer :: max_iterations
      character(len=200) :: acceleration_type, algorithm
      type(convergence_tool) :: convergence_checker

      class(abstract_value_getter), allocatable :: energy_getter

   contains

      procedure, public :: create => create_hf_solver_factory

      procedure, private :: read_settings
      procedure, private :: create_common_solver_components
      procedure, private :: create_scf_solver
      procedure, private :: create_sc_scf_solver
      procedure, private :: create_level_shifted_newton_raphson_solver

   end type hf_solver_factory

   interface hf_solver_factory

      procedure :: new_hf_solver_factory

   end interface hf_solver_factory

contains


   function new_hf_solver_factory(max_iterations, &
                                  energy_threshold, &
                                  algorithm) result(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      type(hf_solver_factory) :: this

      integer, intent(in), optional :: max_iterations
      real(dp), intent(in), optional :: energy_threshold
      character(len=*), intent(in), optional :: algorithm

      call this%read_settings()

      if (present(max_iterations)) this%max_iterations = max_iterations

      if (present(energy_threshold)) call this%convergence_checker%set_energy_threshold(energy_threshold)

      if (present(algorithm)) this%algorithm = algorithm

      this%acceleration_type = 'none'
      if (trim(this%algorithm) == 'scf-diis' .or. trim(this%algorithm) == 'mo-scf-diis') then

         this%acceleration_type = 'diis'

      end if

   end function new_hf_solver_factory


   subroutine create_hf_solver_factory(this, wf, solver, skip)
      !!
      !! Written by Sarai D. Folkestad, 2020
      !!
      implicit none

      class(hf_solver_factory), intent(inout) :: this
      class(hf), intent(inout) :: wf
      class(abstract_solver), allocatable, intent(out) :: solver

      logical, intent(in) :: skip

      call this%create_common_solver_components(wf)

      if (trim(this%algorithm) == 'scf-diis' .or. trim(this%algorithm) == 'scf' .or. &
          trim(this%algorithm) == 'mo-scf-diis') then

         if (trim(wf%name_) == 'sc-qed-rhf') then

            call this%create_sc_scf_solver(wf, solver, skip)

         else

            call this%create_scf_solver(wf, solver, skip)

         end if

      elseif (trim(this%algorithm) == 'level-shift-newton-raphson') then

         call this%create_level_shifted_newton_raphson_solver(wf, solver)

      end if

   end subroutine create_hf_solver_factory


   subroutine read_settings(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      use global_in, only: input

      implicit none

      class(hf_solver_factory), intent(inout) :: this

      real(dp) :: energy_threshold

      this%convergence_checker = convergence_tool(1.0d-7, 1.0d-7, energy_convergence=.false.)

      if (input%is_keyword_present('energy threshold', 'solver scf')) then

         call input%get_keyword('energy threshold', &
                                'solver scf', &
                                energy_threshold)

         call this%convergence_checker%set_energy_threshold(energy_threshold)

      end if

      this%max_iterations = 100

      call input%get_keyword('max iterations', &
                             'solver scf', &
                             this%max_iterations)

      this%algorithm = 'scf-diis'
      call input%get_keyword('algorithm', 'solver scf', this%algorithm)

      if (trim(this%algorithm) /= 'scf-diis' .and. trim(this%algorithm) /= 'scf' .and. &
          trim(this%algorithm) /= 'mo-scf-diis' .and. &
          trim(this%algorithm) /= 'level-shift-newton-raphson') then

         call output%error_msg('did not recognize SCF algorithm: (a0)', chars=[this%algorithm])

      end if

   end subroutine read_settings


   subroutine create_common_solver_components(this, wf)
      !!
      !! Written by Alexander C. Paul and Rosario R. Riso, Nov 2022
      !!
      use hf_energy_getter_class, only: hf_energy_getter

      implicit none

      class(hf_solver_factory), intent(inout) :: this
      class(hf), intent(in) :: wf

      call this%convergence_checker%set_residual_threshold(wf%gradient_threshold)

      this%energy_getter = hf_energy_getter(wf)

   end subroutine create_common_solver_components


   subroutine create_scf_solver(this, wf, solver, skip)
      !!
      !! Written by Alexander C. Paul and Rosario R. Riso, Nov 2022
      !!
      use hf_orbitals_updater_class, only: hf_orbitals_updater
      use accelerator_factory_class, only: accelerator_factory
      use accelerator_tool_class, only: accelerator_tool
      use hf_gradient_getter_class, only: hf_gradient_getter
      use hf_parameter_getter_class, only: hf_parameter_getter
      use scf_solver_class, only: scf_solver
      use scf_print_tool_class, only: scf_print_tool

      implicit none

      class(hf_solver_factory), intent(inout) :: this
      class(hf), intent(inout) :: wf
      class(abstract_solver), allocatable, intent(out) :: solver

      logical, intent(in) :: skip

      class(hf_gradient_getter), allocatable :: gradient_getter
      class(hf_parameter_getter), allocatable :: parameter_getter
      class(hf_orbitals_updater), allocatable :: parameter_updater
      class(accelerator_tool), allocatable :: accelerator
      class(scf_print_tool), allocatable :: printer
      type(accelerator_factory), allocatable :: accelerator_creator

      integer :: n_parameters, gradient_dimension

      call this%convergence_checker%set_residual_threshold(wf%gradient_threshold)

      parameter_getter = hf_parameter_getter(wf)
      gradient_getter = hf_gradient_getter(wf)
      parameter_updater = hf_orbitals_updater(wf)

      printer = scf_print_tool(trim(this%acceleration_type))

      n_parameters = wf%packed_parameter_dimension * wf%n_densities
      gradient_dimension = wf%packed_gradient_dimension * wf%n_densities

      accelerator_creator = accelerator_factory('solver scf')

      call accelerator_creator%create(this%acceleration_type, &
                                      n_parameters, &
                                      gradient_dimension, &
                                      accelerator)

      solver = scf_solver(parameter_updater=parameter_updater, &
                          accelerator=accelerator, &
                          convergence_checker=this%convergence_checker, &
                          parameter_getter=parameter_getter, &
                          residual_getter=gradient_getter, &
                          objective_getter=this%energy_getter, &
                          printer=printer, &
                          skip=skip, &
                          n_parameters=n_parameters, &
                          residual_dimension=gradient_dimension, &
                          max_iterations=this%max_iterations)

   end subroutine create_scf_solver


   subroutine create_sc_scf_solver(this, wf, solver, skip)
      !!
      !! Written by Alexander C. Paul and Rosario R. Riso, Nov 2022
      !!
      use sc_orbitals_and_eta_updater_class, only: sc_orbitals_and_eta_updater
      use accelerator_factory_class, only: accelerator_factory
      use accelerator_tool_class, only: accelerator_tool
      use hf_gradient_getter_class, only: hf_gradient_getter
      use hf_parameter_getter_class, only: hf_parameter_getter
      use scf_solver_class, only: scf_solver
      use scf_print_tool_class, only: scf_print_tool

      implicit none

      class(hf_solver_factory), intent(inout) :: this
      class(hf), intent(inout) :: wf
      class(abstract_solver), allocatable, intent(out) :: solver

      logical, intent(in) :: skip

      class(hf_gradient_getter), allocatable :: gradient_getter
      class(hf_parameter_getter), allocatable :: parameter_getter
      class(sc_orbitals_and_eta_updater), allocatable :: parameter_updater
      class(accelerator_tool), allocatable :: accelerator
      class(scf_print_tool), allocatable :: printer
      type(accelerator_factory), allocatable :: accelerator_creator

      integer :: n_parameters, gradient_dimension

      call this%convergence_checker%set_residual_threshold(wf%gradient_threshold)

      parameter_getter = hf_parameter_getter(wf)
      gradient_getter = hf_gradient_getter(wf)
      parameter_updater = sc_orbitals_and_eta_updater(wf)

      printer = scf_print_tool(trim(this%acceleration_type))

      n_parameters = wf%packed_parameter_dimension * wf%n_densities
      gradient_dimension = wf%packed_gradient_dimension * wf%n_densities

      accelerator_creator = accelerator_factory('solver scf')

      call accelerator_creator%create(this%acceleration_type, &
                                      n_parameters, &
                                      gradient_dimension, &
                                      accelerator)

      solver = scf_solver(parameter_updater=parameter_updater, &
                          accelerator=accelerator, &
                          convergence_checker=this%convergence_checker, &
                          parameter_getter=parameter_getter, &
                          residual_getter=gradient_getter, &
                          objective_getter=this%energy_getter, &
                          printer=printer, &
                          skip=skip, &
                          n_parameters=n_parameters, &
                          residual_dimension=gradient_dimension, &
                          max_iterations=this%max_iterations)

   end subroutine create_sc_scf_solver


   subroutine create_level_shifted_newton_raphson_solver(this, wf, solver)
      !!
      !! Written by Alexander C. Paul and Rosario R. Riso, Nov 2022
      !!
      use global_in, only: input

      use hf_hessian_transformation_class, only: hf_hessian_transformation
      use hf_hessian_preconditioner_getter_class, only: hf_hessian_preconditioner_getter
      use hf_orbital_rotation_parameters_tool_class, only: hf_orbital_rotation_parameters_tool
      use hf_redundant_rotation_projection_tool_class, only: hf_redundant_rotation_projection_tool
      use vector_getter_class, only: vector_getter
      use trust_region_solver_class, only: trust_region_solver
      use trust_region_print_tool_class, only: trust_region_print_tool
      use hf_kappa_gradient_getter_class, only: hf_kappa_gradient_getter

      implicit none

      class(hf_solver_factory), intent(inout) :: this
      class(hf), intent(inout) :: wf
      class(abstract_solver), allocatable, intent(out) :: solver

      class(hf_hessian_transformation), allocatable :: transformer
      class(hf_hessian_preconditioner_getter), allocatable :: preconditioner_getter
      class(hf_orbital_rotation_parameters_tool), allocatable :: parameters
      class(vector_getter), allocatable :: gradient_getter
      class(hf_redundant_rotation_projection_tool), allocatable :: projector
      class(trust_region_print_tool), allocatable :: printer

      if (input%is_embedding_on()) then

         call output%error_msg('(a0) algorithm with embedding is not supported ', &
                               chars=[trim(this%algorithm)])

      end if

      if (trim(wf%name_) /= 'rhf' .and. trim(wf%name_) /= 'dft') then

         call output%error_msg(trim(this%algorithm) // ' algorithm not supported for (a0) wave function', &
                               chars=[trim(wf%name_)])

      end if

      parameters = hf_orbital_rotation_parameters_tool(wf)
      gradient_getter = hf_kappa_gradient_getter(wf)
      transformer = hf_hessian_transformation(wf)
      preconditioner_getter = hf_hessian_preconditioner_getter(wf)
      printer = trust_region_print_tool(this%max_iterations)
      projector = hf_redundant_rotation_projection_tool(wf)

      call wf%prepare_for_level_shifted_newton_raphson()

      solver = trust_region_solver(this%convergence_checker, &
                                   parameters, &
                                   gradient_getter, &
                                   this%energy_getter, &
                                   transformer, &
                                   preconditioner_getter, &
                                   printer, &
                                   projector, &
                                   this%max_iterations, &
                                   wf%packed_gradient_dimension)

   end subroutine create_level_shifted_newton_raphson_solver


end module hf_solver_factory_class

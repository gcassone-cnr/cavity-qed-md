
! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module hf_magnetic_properties_solver_factory_class

   !!
   !! HF magnetic properties solver factory class
   !! Written by Alberto Barlini, Feb 2023
   !!

   use parameters
   use vector_getter_class, only: vector_getter
   use hf_class, only: hf

   implicit none

   type :: hf_magnetic_properties_solver_factory

      integer :: max_iterations, max_reduced_dimension
      real(dp) :: residual_threshold
      logical :: records_in_memory, restart

   contains

      procedure, public :: create => create_hf_magnetic_properties_solver_factory

      procedure, private :: read_settings

   end type hf_magnetic_properties_solver_factory

contains


   subroutine create_hf_magnetic_properties_solver_factory(this, wf, solver)
      !!
      !! Written by A. Barlini, June 2022
      !!
      !! Initializes the Davidson solver with the correct instances of the following types:
      !!
      !!    - Solver tool (linear_davidson)
      !!    - Transformation tool
      !!    - RHS of a linear equation tool
      !!    - Storage tool
      !!    - Start vector tool
      !!    - Preconditioner tool
      !!
      !! for the determination of HF magnetic first-order response
      !!
      use hf_magnetic_properties_transformation_class, only: hf_magnetic_properties_transformation
      use hf_magnetic_properties_linear_equation_storage_tool_class, &
         only: hf_magnetic_properties_linear_equation_storage_tool
      use linear_davidson_solver_class, only: linear_davidson_solver
      use hf_magnetic_properties_rhs_tool_class, only: hf_magnetic_properties_rhs_tool
      use hf_magnetic_properties_start_vector_tool_class, only: hf_magnetic_properties_start_vector_tool
      use hf_magnetic_properties_preconditioner_getter_class, &
         only: hf_magnetic_properties_preconditioner_getter
      use linear_davidson_single_solution_print_tool_class, only: linear_davidson_single_solution_print_tool
      use null_projection_tool_class, only: null_projection_tool
      use convergence_tool_class, only: convergence_tool

      implicit none

      class(hf_magnetic_properties_solver_factory), intent(inout) :: this
      class(hf), intent(in) :: wf
      class(linear_davidson_solver), allocatable, intent(out) :: solver

      class(hf_magnetic_properties_transformation), allocatable :: transformer
      class(hf_magnetic_properties_linear_equation_storage_tool), allocatable :: storer
      class(hf_magnetic_properties_rhs_tool), allocatable :: rhs_getter
      class(hf_magnetic_properties_start_vector_tool), allocatable :: start_vector
      class(vector_getter), allocatable :: preconditioner_getter
      class(null_projection_tool), allocatable :: projector
      class(linear_davidson_single_solution_print_tool), allocatable :: printer
      type(convergence_tool), allocatable :: convergence_checker

      real(dp) :: lindep_threshold
      real(dp), dimension(1) :: frequencies

      call this%read_settings()

      lindep_threshold = min(1.0d-11, 0.1d0 * this%residual_threshold)

      printer = linear_davidson_single_solution_print_tool(print_level='n')

      start_vector = hf_magnetic_properties_start_vector_tool(wf, restart=this%restart)
      transformer = hf_magnetic_properties_transformation(wf)
      storer = hf_magnetic_properties_linear_equation_storage_tool(wf)
      preconditioner_getter = hf_magnetic_properties_preconditioner_getter(wf)
      rhs_getter = hf_magnetic_properties_rhs_tool(wf)
      projector = null_projection_tool(wf%n_v * wf%n_o * 3)

      convergence_checker = convergence_tool(this%residual_threshold)

      frequencies = zero

      solver = linear_davidson_solver(transformer=transformer, &
                                      convergence_checker=convergence_checker, &
                                      storer=storer, &
                                      preconditioner_getter=preconditioner_getter, &
                                      rhs_getter=rhs_getter, &
                                      printer=printer, &
                                      projector=projector, &
                                      n_parameters=wf%n_v * wf%n_o * 3, &
                                      n_rhs=1, &
                                      n_frequencies=1, &
                                      max_iterations=this%max_iterations, &
                                      frequencies=frequencies, &
                                      linear_dependence_threshold=lindep_threshold, &
                                      reduced_space_in_memory=.false., &
                                      max_reduced_dimension=this%max_reduced_dimension, &
                                      start_vector=start_vector)


   end subroutine create_hf_magnetic_properties_solver_factory


   subroutine read_settings(this)
      !!
      !! Written by Alberto Barlini, July 2022
      !!
      use global_in, only: input
      !!
      implicit none

      class(hf_magnetic_properties_solver_factory), intent(inout) :: this

      this%max_reduced_dimension = 50
      this%max_iterations = 100
      this%residual_threshold = 1.0d-6
      this%records_in_memory = .true.
      this%restart = .false.

      call input%get_keyword('max reduced dimension', 'solver hf response', this%max_reduced_dimension)
      call input%get_keyword('max iterations', 'solver hf response', this%max_iterations)
      call input%get_keyword('residual threshold', 'solver hf response', this%residual_threshold)
      call input%place_records_in_memory('solver hf response', this%records_in_memory)

      this%restart = input%is_keyword_present('restart', 'solver hf response') .or. &
                     input%is_keyword_present('restart', 'do')

   end subroutine read_settings

end module hf_magnetic_properties_solver_factory_class

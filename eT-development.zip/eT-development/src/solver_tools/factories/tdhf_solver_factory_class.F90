

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module tdhf_solver_factory_class

   !!
   !! TDHF solver factory class
   !! Written by Sarai D. Folkestad, May 2021
   !!


   use kinds
   use global_out, only: output
   use transformation_class, only: transformation
   use eigen_storage_tool_class, only: eigen_storage_tool
   use hf_class, only: hf
   use convergence_tool_class, only: convergence_tool
   use eigen_davidson_solver_class, only: eigen_davidson_solver
   use start_vector_tool_class, only: start_vector_tool
   use tdhf_start_vector_tool_class, only: tdhf_start_vector_tool
   use vector_getter_class, only: vector_getter

   implicit none

   type :: tdhf_solver_factory

      integer :: n_states, max_dim_red, max_iterations
      real(dp) :: energy_threshold, residual_threshold
      logical :: records_in_memory, energy_convergence, restart

   contains

      procedure, public :: create => create_tdhf_solver_factory

      procedure, private :: read_settings

      procedure, private, nopass :: create_rpa
      procedure, private, nopass :: create_tamm_dancoff

   end type tdhf_solver_factory

contains


   subroutine create_tdhf_solver_factory(this, wf, solver, tamm_dancoff)
      !!
      !! Written by Sarai D. Folkestad, 2020
      !!
      !! Initializes the davidson solver with the correct instances of the following types:
      !!
      !!    - Solver tool (eigen_davidson)
      !!    - Convergence tool
      !!    - Transformation tool,
      !!    - Storage tool
      !!    - Start vector tool
      !!    - Preconditioner getter tool
      !!
      !! for the determination of TDHF (RPA or Tamm-Dancoff)
      !! excitation energies.
      !!
      use null_projection_tool_class, only: null_projection_tool
      use diagonal_eigen_preconditioner_tool_class, only: diagonal_eigen_preconditioner_tool

      implicit none

      class(tdhf_solver_factory), intent(inout) :: this
      class(hf), intent(in) :: wf
      class(eigen_davidson_solver), allocatable, intent(out) :: solver

      logical, intent(in) :: tamm_dancoff

      class(convergence_tool), allocatable :: convergence_checker
      class(transformation), allocatable :: transformer
      class(eigen_storage_tool), allocatable :: storer
      class(start_vector_tool), allocatable :: start_vector
      class(vector_getter), allocatable :: preconditioner_getter
      class(null_projection_tool), allocatable :: projector
      class(diagonal_eigen_preconditioner_tool), allocatable :: preconditioner

      real(dp) :: lindep_threshold

      call this%read_settings()

      convergence_checker = convergence_tool(energy_threshold=this%energy_threshold, &
                                             residual_threshold=this%residual_threshold, &
                                             energy_convergence=this%energy_convergence)

      start_vector = tdhf_start_vector_tool(wf, restart=this%restart)
      projector = null_projection_tool(wf%n_o * wf%n_v)

      if (tamm_dancoff) then

         call output%printf('m', 'Tamm-Dancoff approximations (CIS/CCS) enabled!', ffs='(/t3, a)')

         call this%create_tamm_dancoff(wf, transformer, storer, preconditioner_getter)

      else

         call this%create_rpa(wf, transformer, storer, preconditioner_getter)

      end if

      preconditioner = diagonal_eigen_preconditioner_tool(preconditioner_getter)

      lindep_threshold = min(1.0d-11, 0.1d0 * this%residual_threshold)

      solver = eigen_davidson_solver(transformer=transformer, &
                                     convergence_checker=convergence_checker, &
                                     storer=storer, &
                                     start_vector=start_vector, &
                                     preconditioner=preconditioner, &
                                     projector=projector, &
                                     n_solutions=this%n_states, &
                                     n_parameters=wf%n_tdhf_parameters, &
                                     max_reduced_dimension=this%max_dim_red, &
                                     max_iterations=this%max_iterations, &
                                     reduced_space_in_memory=.true., &
                                     linear_dependence_threshold=lindep_threshold)

   end subroutine create_tdhf_solver_factory


   subroutine create_rpa(wf, transformer, storer, preconditioner_getter)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      use rpa_transformation_class, only: rpa_transformation
      use rpa_eigen_storage_tool_class, only: rpa_eigen_storage_tool
      use rpa_preconditioner_getter_class, only: rpa_preconditioner_getter

      implicit none

      class(transformation), allocatable, intent(inout) :: transformer
      class(eigen_storage_tool), allocatable, intent(inout) :: storer
      class(hf), intent(in) :: wf
      class(vector_getter), allocatable, intent(inout) :: preconditioner_getter

      transformer = rpa_transformation(wf)
      storer = rpa_eigen_storage_tool(wf)
      preconditioner_getter = rpa_preconditioner_getter(wf)

   end subroutine create_rpa


   subroutine create_tamm_dancoff(wf, transformer, storer, preconditioner_getter)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      use tamm_dancoff_transformation_class, only: tamm_dancoff_transformation
      use tamm_dancoff_eigen_storage_tool_class, only: tamm_dancoff_eigen_storage_tool
      use tamm_dancoff_preconditioner_getter_class, only: tamm_dancoff_preconditioner_getter

      implicit none

      class(transformation), allocatable, intent(inout) :: transformer
      class(eigen_storage_tool), allocatable, intent(inout) :: storer
      class(hf), intent(in) :: wf
      class(vector_getter), allocatable, intent(inout) :: preconditioner_getter

      transformer = tamm_dancoff_transformation(wf)
      storer = tamm_dancoff_eigen_storage_tool(wf)
      preconditioner_getter = tamm_dancoff_preconditioner_getter(wf)

   end subroutine create_tamm_dancoff


   subroutine read_settings(this)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!

      use global_in, only: input

      implicit none

      class(tdhf_solver_factory), intent(inout) :: this

      character(len=200) :: storage, section_name

      ! Defaults

      this%n_states = 0
      this%max_dim_red = 50
      this%max_iterations = 100
      this%energy_threshold = 1.0d-3
      this%residual_threshold = 1.0d-3
      this%energy_convergence = .false.
      this%records_in_memory = .true.
      this%restart = .false.

      if (input%is_section_present('solver scf es') .and. input%is_section_present('solver hf es')) &
         call output%error_msg('The keyword sections ''solver scf es'' and ''solver hf es'' are conflicting.')

      section_name = 'solver scf es'
      if (input%is_section_present('solver hf es')) section_name = 'solver hf es'

      call input%get_keyword('singlet states', trim(section_name), this%n_states)
      if (this%n_states == 0) call output%error_msg('cannot solve for 0 TDHF eigenstates')

      call input%get_keyword('max reduced dimension', trim(section_name), this%max_dim_red)
      call input%get_keyword('max iterations', trim(section_name), this%max_iterations)

      call input%get_keyword('residual threshold', trim(section_name), this%residual_threshold)

      if (input%is_keyword_present('energy threshold', trim(section_name))) then

         call input%get_keyword('energy threshold', trim(section_name), this%energy_threshold)
         this%energy_convergence = .true.

      end if

      storage = 'memory'
      call input%get_keyword('storage', trim(section_name), storage)
      if (trim(storage) == 'disk') this%records_in_memory = .false.

      this%restart = input%is_keyword_present('restart', trim(section_name)) .or. &
                     input%is_keyword_present('restart', 'do')

   end subroutine read_settings


end module tdhf_solver_factory_class

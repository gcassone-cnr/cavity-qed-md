

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_es_start_vector_factory_class

   !!
   !! CC es start vector factory class
   !! Written by Alexander C. Paul, May 2022
   !!

   use kinds
   use global_out, only: output
   use ccs_class, only: ccs
   use state_descriptor_class, only: state_descriptor

   implicit none

   type :: cc_es_start_vector_factory

      type(state_descriptor) :: descriptor
      integer :: n_states
      logical :: restart

   contains

      procedure, public :: create => create_cc_es_start_vector_factory

   end type cc_es_start_vector_factory


   interface cc_es_start_vector_factory

      procedure :: new_cc_es_start_vector_factory

   end interface


contains


   function new_cc_es_start_vector_factory(descriptor, n_states, restart) result(this)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      implicit none

      type(state_descriptor) :: descriptor
      logical, intent(in) :: restart
      integer :: n_states

      type(cc_es_start_vector_factory) :: this

      this%descriptor = descriptor
      this%n_states = n_states
      this%restart = restart

   end function new_cc_es_start_vector_factory


   subroutine create_cc_es_start_vector_factory(this, wf, tool)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, 2020-2022
      !!
      use global_in, only: input

      use start_vector_tool_class, only: start_vector_tool
      use es_ip_start_vector_tool_class, only: es_ip_start_vector_tool
      use es_cvs_start_vector_tool_class, only: es_cvs_start_vector_tool
      use es_manual_start_vector_tool_class, only: es_manual_start_vector_tool
      use es_valence_start_vector_tool_class, only: es_valence_start_vector_tool
      use es_cvs_ip_start_vector_tool_class, only: es_cvs_ip_start_vector_tool
      use es_restart_vector_tool_class, only: es_restart_vector_tool
      use triplet_es_valence_start_vector_tool_class, only: triplet_es_valence_start_vector_tool
      use es_ea_start_vector_tool_class, only: es_ea_start_vector_tool

      implicit none

      class(cc_es_start_vector_factory), intent(in) :: this
      class(ccs), intent(in) :: wf

      class(start_vector_tool), allocatable :: tool, default_start_vector_tool

      select case (this%descriptor%get_es_type())

         case ('valence')

            if (this%descriptor%get_spin_symmetry() == 'singlet') &
               default_start_vector_tool = es_valence_start_vector_tool(wf, this%descriptor, this%n_states)

            if (this%descriptor%get_spin_symmetry() == 'triplet') &
               default_start_vector_tool = triplet_es_valence_start_vector_tool(wf, &
                                                                                this%descriptor, &
                                                                                this%n_states)

         case ('core')

            default_start_vector_tool = es_cvs_start_vector_tool(wf, this%descriptor, this%n_states)

         case ('electron attachment')

            default_start_vector_tool = es_ea_start_vector_tool(wf, this%descriptor, this%n_states)

         case ('ionize')

            default_start_vector_tool = es_ip_start_vector_tool(wf, this%descriptor, this%n_states)

         case ('remove core')

            default_start_vector_tool = es_valence_start_vector_tool(wf, this%descriptor, this%n_states)

         case ('core ionize')

            default_start_vector_tool = es_cvs_ip_start_vector_tool(wf, this%descriptor, this%n_states)

         case default

            call output%error_msg( &
                    'could not recognize excited state type in cc_es_start_vector_factory' &
                 )

      end select

      if (input%is_keyword_present('state guesses', 'solver cc es')) then

         default_start_vector_tool = es_manual_start_vector_tool(wf, this%descriptor, this%n_states)

      end if

      if (this%restart) then

         tool = es_restart_vector_tool(wf, &
                                       default_start_vector_tool, &
                                       this%descriptor, &
                                       this%n_states)

      else

         tool = default_start_vector_tool

      end if

   end subroutine create_cc_es_start_vector_factory


end module cc_es_start_vector_factory_class

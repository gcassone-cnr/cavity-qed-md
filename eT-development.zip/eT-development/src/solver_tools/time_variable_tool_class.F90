

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module time_variable_tool_class

   !!
   !! Time variable tool class module
   !! Written by Andreas S. Skeidsvoll, Apr 2021
   !!

   use parameters
   use global_in, only: input
   use global_out, only: output
   use memory_manager_class, only: mem

   implicit none

   type :: time_variable_tool

      logical :: last_step, restart
      integer :: steps_between_output, n_step_reductions, current_step_reduction, step_reduction_factor
      real(dp) :: max_step_size, min_step_size, initial, final_, current, next, restart_time

      integer, dimension(:), allocatable :: step_counts

   contains

      procedure :: initialize => initialize_time_variable_tool
      procedure :: cleanup => cleanup_time_variable_tool

      procedure :: output_at_current => output_at_current_time_variable_tool
      procedure :: count_step => count_step_time_variable_tool
      procedure :: uncount_step => uncount_step_time_variable_tool
      procedure :: update_current => update_current_time_variable_tool

      procedure :: calculate_next => calculate_next_time_variable_tool
      procedure :: check_if_last_step => check_if_last_step_time_variable_tool

      procedure :: read_settings => read_settings_time_variable_tool
      procedure :: print_settings => print_settings_time_variable_tool

      procedure :: reduce_step_size => reduce_step_size_time_variable_tool
      procedure :: try_increasing_step_size => try_increasing_step_size_time_variable_tool

   end type time_variable_tool


   interface time_variable_tool

      procedure :: new_time_variable_tool

   end interface time_variable_tool


contains


   function new_time_variable_tool() result(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2021
      !!
      implicit none

      type(time_variable_tool) :: this

      this%steps_between_output = 1
      this%max_step_size = zero
      this%min_step_size = 1.0e-10_dp
      this%step_reduction_factor = 2

      this%n_step_reductions = 1
      this%current_step_reduction = 1

      this%last_step = .false.
      this%restart = .false.

      call this%read_settings()

      this%current = this%initial
      if (this%restart) then
         this%current = this%restart_time
      end if

   end function new_time_variable_tool


   subroutine initialize_time_variable_tool(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Jan 2023
      !!
      implicit none

      class(time_variable_tool) :: this

      call mem%alloc(this%step_counts, this%n_step_reductions, set_zero=.true.)

   end subroutine initialize_time_variable_tool


   subroutine cleanup_time_variable_tool(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Jan 2023
      !!
      implicit none

      class(time_variable_tool) :: this

      call mem%dealloc(this%step_counts)

   end subroutine cleanup_time_variable_tool


   function output_at_current_time_variable_tool(this) result(write_output)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2021
      !!
      implicit none

      logical :: write_output

      class(time_variable_tool) :: this
      integer :: i

      write_output = .false.

      if (modulo(this%step_counts(1), this%steps_between_output) == 0) then

         write_output = .true.

         do i = 2, this%n_step_reductions

            if (this%step_counts(i) /= 0) write_output = .false.

         end do
      end if

   end function output_at_current_time_variable_tool


   subroutine calculate_next_time_variable_tool(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2021
      !!
      !! Calculate the next time value
      !!
      implicit none

      class(time_variable_tool) :: this

      integer :: i

      if (this%restart) then
         this%next = this%restart_time
      else
         this%next = this%initial
      end if

      do i = 1, this%n_step_reductions

         this%next = this%next + real(this%step_counts(i), dp) &
                     * this%max_step_size * real(this%step_reduction_factor, dp)**(1 - i)

      end do

      call this%check_if_last_step()

   end subroutine calculate_next_time_variable_tool


   subroutine check_if_last_step_time_variable_tool(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2021
      !!
      !! Check if the next time value passes the final time, adjust it to the
      !! final time if it does
      !!
      implicit none

      class(time_variable_tool) :: this

      if ((this%max_step_size > zero) .and. (this%next >= this%final_) .or. &
          (this%max_step_size < zero) .and. (this%next <= this%final_)) then

         this%last_step = .true.
         this%next = this%final_

      elseif (abs(this%max_step_size / &
              real(this%step_reduction_factor**(this%n_step_reductions - 1), dp)) < this%min_step_size) then

         this%last_step = .true.
         call output%warning_msg('encountered a divergence; time step smaller than threshold.')

      else

         this%last_step = .false.

      end if

   end subroutine check_if_last_step_time_variable_tool


   subroutine count_step_time_variable_tool(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2021
      !!
      implicit none

      class(time_variable_tool) :: this

      integer :: i

      this%step_counts(this%current_step_reduction) = this%step_counts(this%current_step_reduction) + 1

      do i = this%current_step_reduction, 2, - 1

         if (this%step_counts(i) >= this%step_reduction_factor) then

            this%step_counts(i) = this%step_counts(i) - this%step_reduction_factor
            this%step_counts(i - 1) = this%step_counts(i - 1) + 1

         end if
      end do

   end subroutine count_step_time_variable_tool


   subroutine uncount_step_time_variable_tool(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2021
      !!
      implicit none

      class(time_variable_tool) :: this

      integer :: i

      this%step_counts(this%current_step_reduction) = this%step_counts(this%current_step_reduction) - 1

      do i = this%current_step_reduction, 2, - 1

         if (this%step_counts(i) < 0) then

            this%step_counts(i) = this%step_counts(i) + this%step_reduction_factor
            this%step_counts(i - 1) = this%step_counts(i - 1) - 1

         end if

      end do

   end subroutine uncount_step_time_variable_tool


   subroutine reduce_step_size_time_variable_tool(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2021
      !!
      implicit none

      class(time_variable_tool) :: this

      integer, dimension(:), allocatable :: temp

      call this%uncount_step()
      this%current_step_reduction = this%current_step_reduction + 1

      ! In case the dimension of step_counts has to be increased by 1

      if (this%current_step_reduction == this%n_step_reductions + 1) then

         call mem%alloc(temp, this%n_step_reductions)
         temp = this%step_counts

         call mem%dealloc(this%step_counts)
         call mem%alloc(this%step_counts, this%n_step_reductions + 1)
         this%step_counts(1:this%n_step_reductions) = temp
         this%step_counts(this%n_step_reductions + 1) = 0

         call mem%dealloc(temp)

         this%n_step_reductions = this%n_step_reductions + 1

      end if

      call this%count_step()

   end subroutine reduce_step_size_time_variable_tool


   subroutine try_increasing_step_size_time_variable_tool(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2021
      !!
      implicit none

      class(time_variable_tool) :: this

      if (this%current_step_reduction > 1 .and. this%step_counts(this%current_step_reduction) == 0) &
         this%current_step_reduction = this%current_step_reduction - 1

   end subroutine try_increasing_step_size_time_variable_tool


   subroutine update_current_time_variable_tool(this)
      !!
      !! Written by Andreas S. Skeidsvoll, Apr 2021
      !!
      implicit none

      class(time_variable_tool) :: this

      this%current = this%next

   end subroutine update_current_time_variable_tool


   subroutine read_settings_time_variable_tool(this)
      !!
      !! Written by Andreas Skeidsvoll, Feb 2019
      !!
      !! Read the settings related to the time variable.
      !!
      !! Settings:
      !!
      !! initial time:          the time variable starts from this time
      !! final time:            the time variable stops when reaching this time
      !! time step:             the size of time steps
      !! steps between output:  how many time steps should pass between each time
      !!                        properties are written to file
      !!
      implicit none

      class(time_variable_tool) :: this

      call input%get_required_keyword('initial time', 'solver cc propagation', this%initial)
      call input%get_required_keyword('final time', 'solver cc propagation', this%final_)
      call input%get_required_keyword('time step', 'solver cc propagation', this%max_step_size)

      if (input%is_keyword_present('restart', 'solver cc propagation') .or. &
          input%is_keyword_present('restart', 'do')) &
         this%restart = .true.

      if (this%restart) &
         call input%get_required_keyword('restart time', 'solver cc propagation', this%restart_time)

      call input%get_keyword('steps between output', &
                             'solver cc propagation', &
                             this%steps_between_output)

      call input%get_keyword('step reduction factor', &
                             'solver cc propagation', &
                             this%step_reduction_factor)

      ! Check that the time step is consistent with the propagation direction.

      if ((this%max_step_size > zero) .and. (this%final_ - this%initial < zero)) &
         call output%error_msg('Time steps should be negative for backward propagation.')

      if ((this%max_step_size < zero) .and. (this%final_ - this%initial > zero)) &
         call output%error_msg('Time steps should be positive for forward propagation.')

      ! Check that propagation time is finite and nonzero

      if ((this%max_step_size == zero) .or. (this%final_ - this%initial == zero)) this%last_step = .true.

   end subroutine read_settings_time_variable_tool


   subroutine print_settings_time_variable_tool(this)
      !!
      !! Written by Andreas Skeidsvoll, Oct 2018
      !!
      !! Print the settings of the solver related to the time variable.
      !!
      implicit none

      class(time_variable_tool) :: this

      call output%printf('m', '- Propagation settings:', fs='(/t3,a)')

      call output%printf('m', 'Initial time: (f10.4) au', reals=[this%initial], fs='(/t6,a)')
      if (this%restart) &
         call output%printf('m', 'Restart time: (f10.4) au', reals=[this%restart_time], fs='(t6,a)')
      call output%printf('m', 'Final time:   (f10.4) au', reals=[this%final_], fs='(t6,a)')
      call output%printf('m', 'Time step:    (f10.4) au', reals=[this%max_step_size], fs='(t6,a/)')

   end subroutine print_settings_time_variable_tool


end module time_variable_tool_class

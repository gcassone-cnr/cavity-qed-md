

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module fci_preconditioner_getter_class

   !!
   !! FCI preconditioner getter class module
   !! Written by Enrico Ronca, 2022
   !!

   use parameters
   use vector_getter_class, only: vector_getter
   use fci_class, only: fci

   implicit none

   type, extends(vector_getter) :: fci_preconditioner_getter

      class(fci), pointer, private :: wf

   contains

      procedure, public :: get => get_fci_preconditioner_getter

   end type fci_preconditioner_getter

   interface fci_preconditioner_getter

      procedure :: new_fci_preconditioner_getter

   end interface fci_preconditioner_getter

contains

   function new_fci_preconditioner_getter(wf) result(this)
      !!
      !! Written by Enrico Ronca, 2022
      !!
      implicit none

      class(fci), intent(in), target :: wf
      type(fci_preconditioner_getter) :: this

      this%wf => wf
      this%n_parameters = wf%n_parameters
      this%n_vectors = 1

   end function new_fci_preconditioner_getter


   subroutine get_fci_preconditioner_getter(this, vectors)
      !!
      !! Written by Sarai D. Folkestad, May 2021
      !!
      implicit none

      class(fci_preconditioner_getter), intent(inout) :: this
      real(dp), dimension(this%n_parameters, this%n_vectors), intent(out) :: vectors

      call this%wf%construct_h_diagonal(vectors)

   end subroutine get_fci_preconditioner_getter

end module fci_preconditioner_getter_class

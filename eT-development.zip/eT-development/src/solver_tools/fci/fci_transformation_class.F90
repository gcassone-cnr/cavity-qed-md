

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module fci_transformation_class

   !!
   !! FCI transformation class
   !! Written by Enrico Ronca, 2022
   !!

   use kinds

   use fci_class, only: fci
   use transformation_class, only: transformation

   implicit none

   type, extends(transformation) :: fci_transformation

      class(fci), pointer, private :: wf

   contains

      procedure, public :: transform => transform_fci
      procedure, public :: initialize => initialize_fci

   end type fci_transformation

   interface fci_transformation

      procedure :: new_fci_transformation

   end interface fci_transformation

contains

   function new_fci_transformation(wf) result(this)
      !!
      !! Written by Enrico Ronca, 2022
      !!
      implicit none

      class(fci), intent(in), target :: wf
      type(fci_transformation) :: this

      this%wf => wf
      this%n_parameters = wf%n_parameters

   end function new_fci_transformation


   subroutine transform_fci(this, trial, transform)
      !!
      !! Written by Enrico Ronca, 2022
      !!
      implicit none

      class(fci_transformation), intent(in) :: this
      real(dp), dimension(this%n_parameters) :: trial, transform

      call this%wf%hamiltonian_transformation_no_spin_symmetry(trial, &
                                                               transform, &
                                                               this%wf%effective_2e_hamiltonian, &
                                                               .false.)

   end subroutine transform_fci


   subroutine initialize_fci(this)
      !!
      !! Written by Enrico Ronca, 2022
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(fci_transformation), intent(in) :: this

      call do_nothing(this)

   end subroutine initialize_fci


end module fci_transformation_class

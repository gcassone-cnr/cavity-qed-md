

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cpp_print_tool_class

   !!
   !! CPP Davidson print tool class module
   !! Written by Regina Matveeva,
   !! A.K. Schnack Petersen and T. Moitra, 2021-2024
   !!

   use kinds
   use global_out, only: output

   implicit none

   type :: cpp_print_tool

      character(len=1) :: print_level

   contains

      procedure, public, nopass :: print_banner => print_banner_cpp_print_tool

      procedure, public :: print_iteration_header => print_iteration_header_cpp_print_tool
      procedure, public :: print_iteration_footer => print_iteration_footer_cpp_print_tool
      procedure, public :: print_iteration => print_iteration_cpp_print_tool

   end type cpp_print_tool

contains



   function new_cpp_print_tool(print_level) result(this)
      !!
      !! Written by Regina Matveeva, 2022
      !!
      implicit none

      type(cpp_print_tool) :: this

      character(len=1), intent(in) :: print_level

      this%print_level = print_level

   end function new_cpp_print_tool


   subroutine print_iteration_header_cpp_print_tool(this)
      !!
      !! Written by Regina Matveeva, Dec 2021
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(cpp_print_tool), intent(in) :: this

      call do_nothing(this)

   end subroutine print_iteration_header_cpp_print_tool


   subroutine print_iteration_footer_cpp_print_tool(this)
      !!
      !! Written by Regina Matveeva, Dec 2021
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(cpp_print_tool), intent(in) :: this

      call do_nothing(this)

   end subroutine print_iteration_footer_cpp_print_tool


   subroutine print_iteration_cpp_print_tool(this, &
                                             n_solutions, &
                                             residual_norm, &
                                             iteration, &
                                             frequencies, &
                                             dim_red)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      use kinds
      use global_out, only: output

      implicit none

      class(cpp_print_tool), intent(in) :: this

      integer, intent(in) :: n_solutions, iteration, dim_red
      real(dp), dimension(n_solutions), intent(in) :: residual_norm, frequencies

      integer :: i


      call output%printf(this%print_level, &
                         'Iteration:               (i4)', &
                         ints=[iteration], &
                         fs='(/t3,a)')

      call output%printf(this%print_level, &
                         'Reduced space dimension: (i4)', &
                         ints=[dim_red])

      call output%printf(this%print_level, ' Frequency      Residual norm', fs='(/t3,a)')
      call output%print_separator(this%print_level, 30, '-')

      do i = 1, n_solutions

         call output%printf(this%print_level, &
                            '(e11.4)   (e15.4)', &
                            reals=[frequencies(i), residual_norm(i)])

      end do

      call output%print_separator('n', 30, '-')

   end subroutine print_iteration_cpp_print_tool


   subroutine print_banner_cpp_print_tool()
      !!
      !! Written by Regina Matveeva, T. Moitra and A.K. Schnack-Petersen 2020
      !!
      implicit none

      character(len=100) :: name_
      character(len=500) :: description

      name_ = 'CPP linear equations solver'

      description = &
         'A complex polarization propagator (CPP) solver that solves damped' // &
         ' response linear equations.' // ' The implemented equations can be found in e.g.' // &
         ' Kauczor et al., J. Chem. Phys., 139, 211102 (2013)'

      call output%printf('m', ' - ' // trim(name_), fs='(/t3,a)')
      call output%print_separator('m', len_trim(name_) + 6, '-')

      call output%printf('m', description, ffs='(/t3,a)', fs='(t3,a)')

   end subroutine print_banner_cpp_print_tool


end module cpp_print_tool_class

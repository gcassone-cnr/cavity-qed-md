

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_es_storage_tool_class

   !!
   !! CC es storage tool class module
   !! Written by Sarai D. Folkestad, Feb 2022
   !!

   use parameters, only: dp
   use eigen_storage_tool_class, only: eigen_storage_tool
   use state_descriptor_class, only: state_descriptor
   use cc_es_states_class, only: cc_es_states
   use ccs_class, only: ccs

   implicit none

   type, extends(eigen_storage_tool) :: cc_es_storage_tool

      class(cc_es_states), allocatable :: states
      class(ccs), pointer :: wf

   contains

      procedure, public :: store => store_cc_es_storage_tool


   end type cc_es_storage_tool

   interface cc_es_storage_tool

      procedure :: new_cc_es_storage_tool

   end interface cc_es_storage_tool

contains

   function new_cc_es_storage_tool(n_states, wf, descriptor) result(this)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      type(cc_es_storage_tool) :: this
      type(state_descriptor) :: descriptor
      integer, intent(in) :: n_states
      class(ccs), target :: wf

      this%wf => wf
      this%states = cc_es_states(n_states, wf%get_n_es_parameters(descriptor), descriptor)

   end function new_cc_es_storage_tool


   subroutine store_cc_es_storage_tool(this, eigenvalue, eigenvector, I)
      !!
      !! Written by Sarai D. Folkestad, Feb 2022
      !!
      implicit none

      class(cc_es_storage_tool), intent(inout) :: this
      integer, intent(in) :: I
      real(dp), dimension(this%n_parameters), intent(in) :: eigenvector
      real(dp), intent(in) :: eigenvalue

      call this%states%es_storers(I)%save_(eigenvector, eigenvalue)

   end subroutine store_cc_es_storage_tool


end module cc_es_storage_tool_class

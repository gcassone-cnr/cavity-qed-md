

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module folded_cc_jacobian_transformation_class

   !!
   !! Folded CC Jacobian transformation class
   !! Written by Regina Matveeva, Sept 2021
   !!

   use kinds, only: dp

   use ccs_class, only: ccs
   use state_descriptor_class, only: state_descriptor
   use frequency_dependent_transformation_class, only: frequency_dependent_transformation

   implicit none

   type, extends(frequency_dependent_transformation) :: folded_cc_jacobian_transformation

      class(ccs), pointer, private :: wf
      class(state_descriptor), allocatable, private :: descriptor
      real(dp), private :: frequency

   contains

      procedure, public :: initialize => initialize_folded_cc_jacobian_transformation
      procedure, public :: transform => transform_folded_cc_jacobian_transformation
      procedure, public :: set_frequency => set_frequency_folded_cc_jacobian_transformation

   end type folded_cc_jacobian_transformation

   interface folded_cc_jacobian_transformation

      procedure :: new_folded_cc_jacobian_transformation

   end interface folded_cc_jacobian_transformation

contains

   function new_folded_cc_jacobian_transformation(wf, descriptor) result(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(ccs), intent(in), target :: wf
      type(state_descriptor), intent(in) :: descriptor

      type(folded_cc_jacobian_transformation) :: this

      this%wf => wf

      this%n_parameters = wf%n_es_amplitudes
      this%descriptor = descriptor

   end function new_folded_cc_jacobian_transformation


   subroutine set_frequency_folded_cc_jacobian_transformation(this, frequency)
      !!
      !! Written by Alexander C. Paul, Jan 2023
      !!
      implicit none

      class(folded_cc_jacobian_transformation), intent(inout) :: this
      real(dp), intent(in) :: frequency

      this%frequency = frequency

   end subroutine set_frequency_folded_cc_jacobian_transformation


   subroutine transform_folded_cc_jacobian_transformation(this, trial, transform)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(folded_cc_jacobian_transformation), intent(in) :: this
      real(dp), dimension(this%n_parameters) :: trial, transform

      call this%wf%construct_Jacobian_transform(trial, transform, this%descriptor, this%frequency)

   end subroutine transform_folded_cc_jacobian_transformation


   subroutine initialize_folded_cc_jacobian_transformation(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(folded_cc_jacobian_transformation), intent(in) :: this

      call this%wf%prepare_for_jacobians(this%descriptor)

   end subroutine initialize_folded_cc_jacobian_transformation


end module folded_cc_jacobian_transformation_class

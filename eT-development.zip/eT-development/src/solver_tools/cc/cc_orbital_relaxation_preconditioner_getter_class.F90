

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_orbital_relaxation_preconditioner_getter_class

   !!
   !! CC orbital relaxation preconditioner getter class module
   !! Written by Eirik Kjoenstad and Anna Kristina Schnack-Petersen, Dec 2022
   !!

   use parameters
   use vector_getter_class, only: vector_getter
   use ccs_class, only: ccs

   implicit none

   type, extends(vector_getter) :: cc_orbital_relaxation_preconditioner_getter

      class(ccs), pointer, private :: wf

   contains

      procedure, public :: get => get_cc_orbital_relaxation_preconditioner_getter

   end type cc_orbital_relaxation_preconditioner_getter


   interface cc_orbital_relaxation_preconditioner_getter

      procedure :: new_cc_orbital_relaxation_preconditioner_getter

   end interface cc_orbital_relaxation_preconditioner_getter


contains

   function new_cc_orbital_relaxation_preconditioner_getter(wf) result(this)
      !!
      !! Written by Eirik Kjoenstad and Anna Kristina Schnack-Petersen, Dec 2022
      !!
      implicit none

      class(ccs), intent(in), target :: wf
      type(cc_orbital_relaxation_preconditioner_getter) :: this

      this%wf => wf

   end function new_cc_orbital_relaxation_preconditioner_getter


   subroutine get_cc_orbital_relaxation_preconditioner_getter(this, vectors)
      !!
      !! Written by Eirik Kjoenstad and Anna Kristina Schnack-Petersen, Dec 2022
      !!
      use array_initialization, only: zero_array

      implicit none

      class(cc_orbital_relaxation_preconditioner_getter), intent(inout) :: this

      real(dp), dimension(this%wf%n_v, this%wf%n_o), intent(out) :: vectors

      integer :: a, i, J
      real(dp), dimension(:, :, :), pointer :: L_J_vo, L_J_oo, L_J_vv

      call zero_array(vectors, this%wf%n_v * this%wf%n_o)

      call this%wf%L_mo%load_block(L_J_vv, this%wf%n_o + 1, this%wf%n_mo, this%wf%n_o + 1, this%wf%n_mo)
      call this%wf%L_mo%load_block(L_J_vo, this%wf%n_o + 1, this%wf%n_mo, 1, this%wf%n_o)
      call this%wf%L_mo%load_block(L_J_oo, 1, this%wf%n_o, 1, this%wf%n_o)

      !$omp parallel do private(a,i,J) collapse(2)
      do i = 1, this%wf%n_o
         do a = 1, this%wf%n_v

            vectors(a, i) = vectors(a, i) &
                            + two &
                            * (this%wf%orbital_energies(this%wf%n_o + a) - this%wf%orbital_energies(i))

            do J = 1, this%wf%eri_t1%n_J

               vectors(a, i) = vectors(a, i) &
                               + two * (three * L_J_vo(J, a, i)**2 - L_J_vv(J, a, a) * L_J_oo(J, i, i))

            end do
         end do
      end do
      !$omp end parallel do

      call this%wf%L_mo%offload_block(this%wf%n_o + 1, this%wf%n_mo, this%wf%n_o + 1, this%wf%n_mo)
      call this%wf%L_mo%offload_block(this%wf%n_o + 1, this%wf%n_mo, 1, this%wf%n_o)
      call this%wf%L_mo%offload_block(1, this%wf%n_o, 1, this%wf%n_o)

   end subroutine get_cc_orbital_relaxation_preconditioner_getter


end module cc_orbital_relaxation_preconditioner_getter_class

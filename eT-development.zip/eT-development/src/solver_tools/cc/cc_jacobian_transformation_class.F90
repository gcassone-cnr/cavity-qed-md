

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_jacobian_transformation_class

   !!
   !! Coupled Cluster Jacobian transformation class
   !! Written by Regina Matveeva, Sept 2021
   !!
   !! Based on abstract_jacobian_transformer_class by Eirik F. Kjoenstad, 2021

   use global_out, only: output
   use kinds

   use ccs_class, only: ccs
   use transformation_class, only: transformation
   use state_descriptor_class, only: state_descriptor

   implicit none

   type, extends(transformation) :: cc_jacobian_transformation

      type(state_descriptor) :: descriptor
      class(ccs), pointer, private :: wf

   contains

      procedure, public :: initialize => initialize_cc_jacobian
      procedure, public :: transform => transform_cc_jacobian

   end type cc_jacobian_transformation

   interface cc_jacobian_transformation

      procedure :: new_cc_jacobian_transformation
      procedure :: new_cc_jacobian_transformation_side

   end interface cc_jacobian_transformation

contains

   function new_cc_jacobian_transformation(wf, descriptor) result(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(ccs), intent(in), target :: wf
      type(state_descriptor) :: descriptor
      type(cc_jacobian_transformation) :: this

      this%wf => wf
      this%descriptor = descriptor
      this%n_parameters = wf%get_n_es_parameters(this%descriptor)


   end function new_cc_jacobian_transformation


   function new_cc_jacobian_transformation_side(wf, left_or_right) result(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(ccs), intent(in), target :: wf
      character(len=*), intent(in) :: left_or_right
      type(cc_jacobian_transformation) :: this

      this%wf => wf
      this%descriptor = state_descriptor(left_or_right=trim(left_or_right), &
                                         cvs=.false., &
                                         ip=.false., &
                                         rm_core=.false., &
                                         ea=.false., &
                                         spin_symmetry='singlet')

      this%n_parameters = wf%get_n_es_parameters(this%descriptor)


   end function new_cc_jacobian_transformation_side


   subroutine transform_cc_jacobian(this, trial, transform)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(cc_jacobian_transformation), intent(in) :: this
      real(dp), dimension(this%n_parameters) :: trial, transform

      if (trim(this%descriptor%get_spin_symmetry()) == 'singlet') then

         if (trim(this%descriptor%get_left_or_right()) == 'left') then

            call this%wf%jacobian_transpose_transformation(trial, transform)

         elseif (trim(this%descriptor%get_left_or_right()) == 'right') then

            call this%wf%jacobian_transformation(trial, transform)

         end if

      else if (trim(this%descriptor%get_spin_symmetry()) == 'triplet') then

         if (trim(this%descriptor%get_left_or_right()) == 'left') then

            call this%wf%triplet_jacobian_transpose_transformation(trial, transform)

         elseif (trim(this%descriptor%get_left_or_right()) == 'right') then

            call this%wf%triplet_jacobian_transformation(trial, transform)

         end if
      else

         call output%error_msg('Could not recognize spin symmetry in cc_jacobian_transformer')

      end if

   end subroutine transform_cc_jacobian


   subroutine initialize_cc_jacobian(this)
      !!
      !! Written by Regina Matveeva, Sept 2021
      !!
      implicit none

      class(cc_jacobian_transformation), intent(in) :: this

      call this%wf%prepare_for_jacobians(this%descriptor)

   end subroutine initialize_cc_jacobian


end module cc_jacobian_transformation_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc_hartree_fock_hessian_transformation_class

   !!
   !! Coupled Cluster Hartree-Fock Hessian transformation class
   !! Written by Eirik Kjoenstad and Anna Kristina Schnack-Petersen, Dec 2022
   !!

   use kinds

   use ccs_class, only: ccs
   use transformation_class, only: transformation

   implicit none

   type, extends(transformation) :: cc_hartree_fock_hessian_transformation

      class(ccs), pointer, private :: wf

   contains

      procedure, public :: initialize => initialize_cc_hartree_fock_hessian
      procedure, public :: transform => transform_cc_hartree_fock_hessian

   end type cc_hartree_fock_hessian_transformation

   interface cc_hartree_fock_hessian_transformation

      procedure :: new_cc_hartree_fock_hessian_transformation

   end interface cc_hartree_fock_hessian_transformation

contains

   function new_cc_hartree_fock_hessian_transformation(wf, n_parameters) result(this)
      !!
      !! Written by Eirik Kjoenstad and Anna Kristina Schnack-Petersen, Dec 2022
      !!
      implicit none

      class(ccs), intent(in), target :: wf
      integer, intent(in) :: n_parameters
      type(cc_hartree_fock_hessian_transformation) :: this

      this%wf => wf
      this%n_parameters = n_parameters

   end function new_cc_hartree_fock_hessian_transformation


   subroutine transform_cc_hartree_fock_hessian(this, trial, transform)
      !!
      !! Written by Eirik Kjoenstad and Anna Kristina Schnack-Petersen, Dec 2022
      !!
      implicit none

      class(cc_hartree_fock_hessian_transformation), intent(in) :: this
      real(dp), dimension(this%n_parameters) :: trial, transform

      call this%wf%hartree_fock_hessian_transformation(trial, transform)

   end subroutine transform_cc_hartree_fock_hessian


   subroutine initialize_cc_hartree_fock_hessian(this)
      !!
      !! Written by Eirik Kjoenstad and Anna Kristina Schnack-Petersen, Dec 2022
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(cc_hartree_fock_hessian_transformation), intent(in) :: this

      call do_nothing(this)

   end subroutine initialize_cc_hartree_fock_hessian


end module cc_hartree_fock_hessian_transformation_class

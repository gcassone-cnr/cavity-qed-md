

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module approximate_cc_jacobian_transformation_class

   !!
   !! Approximate CC Jacobian transformation
   !! Written by Eirik F. Kjoenstad, 2021
   !!
   !! Wrapper object for calling the most accurate
   !! approximation of the full Jacobian transformation
   !! that scales less steeply than the full transformation
   !! (e.g., the CCSD transformation in the case of CC3).
   !!

   use kinds, only: dp
   use ccs_class, only: ccs
   use state_descriptor_class, only: state_descriptor
   use transformation_class, only: transformation

   implicit none

   type, extends(transformation) :: approximate_cc_jacobian_transformation

      class(ccs), pointer, private :: wf
      type(state_descriptor), allocatable, private :: descriptor

   contains

      procedure, public :: initialize => initialize_cc_jacobian
      procedure, public :: transform => transform_cc_jacobian

   end type approximate_cc_jacobian_transformation

   interface approximate_cc_jacobian_transformation

      procedure :: new_approximate_cc_jacobian_transformation

   end interface approximate_cc_jacobian_transformation

contains


   function new_approximate_cc_jacobian_transformation(wf, descriptor) result(this)
      !!
      !! Written by Alexander C. Paul, Jan 2023
      !!
      implicit none

      class(ccs), intent(in), target :: wf
      type(state_descriptor), intent(in) :: descriptor

      type(approximate_cc_jacobian_transformation) :: this

      this%wf => wf
      this%descriptor = descriptor

   end function new_approximate_cc_jacobian_transformation


   subroutine transform_cc_jacobian(this, trial, transform)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      use parameters
      implicit none

      class(approximate_cc_jacobian_transformation), intent(in) :: this
      real(dp), dimension(this%n_parameters) :: trial, transform

      call this%wf%approximate_Jacobian_transform(trial, transform, this%descriptor, energy=zero)


   end subroutine transform_cc_jacobian


   subroutine initialize_cc_jacobian(this)
      !!
      !! Written by Eirik F. Kjoenstad, 2021
      !!
      implicit none

      class(approximate_cc_jacobian_transformation), intent(in) :: this

      call this%wf%prepare_for_approximate_Jacobians(this%descriptor)

   end subroutine initialize_cc_jacobian


end module approximate_cc_jacobian_transformation_class



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cpp_precondition_tool_class

   !!
   !! CPP Precondition tool class
   !! Written by Anna Kristina Schnack-Petersen, Dec 2022
   !!
   !! Vectors can be preconditioned by X as follows:
   !!
   !!    Initialization:
   !!
   !!       precondition_tool = precondition_tool(dim_X, left_or_right_transformation)
   !!
   !! Class is based on, precondition class by Eirik F. Kjoenstad.
   !!

   use parameters
   use precondition_tool_class, only: precondition_tool

   implicit none

   type, extends(precondition_tool) :: cpp_precondition_tool

      real(dp) :: sign_
      real(dp) :: damping

   contains

      procedure :: do_ => do_cpp_precondition_tool
      procedure :: initialize_and_set_precondition_vector => &
                   initialize_and_set_precondition_vector_cpp_precondition_tool
      procedure :: destruct_precondition_vector => destruct_precondition_vector_cpp_precondition_tool

   end type cpp_precondition_tool


   interface cpp_precondition_tool

      procedure :: new_cpp_precondition_tool

   end interface cpp_precondition_tool


contains


   pure function new_cpp_precondition_tool(dim_, sign_, damping) result(tool)
      !!
      !! Written by Eirik F. Kjoenstad, 2019
      !!
      implicit none

      type(cpp_precondition_tool) :: tool

      integer, intent(in) :: dim_
      integer, intent(in) :: sign_
      real(dp), intent(in) :: damping

      tool%dim_ = dim_
      tool%sign_ = real(sign_, kind=dp)
      tool%damping = damping

   end function new_cpp_precondition_tool


   subroutine do_cpp_precondition_tool(tool, R, shift, prefactor)
      !!
      !! Written by A. K. Schnack-Petersen and T. Moitra, 2020
      !!
      !! prefactor: Optional real number. Default is one.
      !!
      use memory_manager_class, only: mem

      implicit none

      class(cpp_precondition_tool), intent(in) :: tool
      real(dp), dimension(*), intent(inout) :: R
      real(dp), intent(in), optional :: shift
      real(dp), intent(in), optional :: prefactor
      real(dp) :: local_prefactor
      real(dp) :: denominator

      real(dp), dimension(:), allocatable, target :: R_new

      integer :: i, n

      local_prefactor = one
      if (present(prefactor)) local_prefactor = prefactor

      call mem%alloc(R_new, 2 * tool%dim_)

      n = tool%dim_
      !$omp parallel do private(i, denominator)
      do i = 1, n

         denominator = (tool%preconditioner(i) - tool%sign_ * shift)**2 + tool%damping**2

         R_new(i) = &
                    local_prefactor / denominator &
                    * ((tool%preconditioner(i) - tool%sign_ * shift) * R(i) &
                    + tool%sign_ * tool%damping * R(i + n))

         R_new(i + n) = &
                        local_prefactor / denominator &
                        * (tool%sign_ * tool%damping * R(i) &
                        - (tool%preconditioner(i) - tool%sign_ * shift) * R(i + n))

      end do
      !$omp end parallel do

      call dcopy(2 * tool%dim_, R_new, 1, R, 1)

      call mem%dealloc(R_new)

   end subroutine do_cpp_precondition_tool


   subroutine destruct_precondition_vector_cpp_precondition_tool(tool)
      !!
      !! Written by Eirik F. Kjoenstad, 2019
      !!
      use memory_manager_class, only: mem

      implicit none

      class(cpp_precondition_tool), intent(inout) :: tool

      if (allocated(tool%preconditioner)) call mem%dealloc(tool%preconditioner)

   end subroutine destruct_precondition_vector_cpp_precondition_tool


   subroutine initialize_and_set_precondition_vector_cpp_precondition_tool(tool, preconditioner)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      use memory_manager_class, only: mem

      implicit none

      class(cpp_precondition_tool), intent(inout) :: tool
      real(dp), dimension(tool%dim_), intent(in) :: preconditioner

      call mem%alloc(tool%preconditioner, tool%dim_)
      call dcopy(tool%dim_, preconditioner, 1, tool%preconditioner, 1)

   end subroutine initialize_and_set_precondition_vector_cpp_precondition_tool


end module cpp_precondition_tool_class

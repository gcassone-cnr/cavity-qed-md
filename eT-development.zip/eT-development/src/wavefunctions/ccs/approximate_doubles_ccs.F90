

! eT - a coupled cluster program
! Copyright (C) 2016-2024 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


submodule (ccs_class) approximate_doubles_ccs

   implicit none

contains


   module subroutine approximate_double_excitation_vectors_ccs(wf, R_ai, omega, file_)
      !!
      !! Written by Sarai D. Folkestad, 2019-2022
      !!
      !! Approximate double excitation vectors:
      !!
      !!    R_aibj = 1/(1 + delta_aibj) * (P_ai,bj(sum_c R_ci g_bjac
      !!                                   - sum_k R_bk g_kjai))/(-eps_aibj + omega^CCS)
      !!           = 1/(1 + delta_aibj) * X_aibj/(-eps_aibj + omega^CCS)
      !!
      !! Used for CNTOs from CCS.
      !!
      !! For further information see Baudin, P. and Kristensen, K., J. Chem. Phys. 2017, 146, 214114
      !!
      !! Note: Renormalizes R_ai !
      !! Note: Integrals are in MO basis not T1 basis
      !!
      use array_initialization, only: copy_and_scale

      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_v, wf%n_o), intent(inout) :: R_ai

      real(dp), intent(in) :: omega


      type(direct_stream_file), intent(inout) :: file_  ! record length o^2v

      type(direct_stream_file), allocatable :: intermediate_file, reordered_intermediate_file

      integer :: i, a

      real(dp) :: ddot, squared_norm, norm

      real(dp), dimension(:, :, :, :), allocatable :: X_ibja, R_ibja, X_jaib

      type(batching_index) :: batch_a

      integer :: current_a_batch
      integer :: req0, req1

      intermediate_file = direct_stream_file('intermediate_approximate_doubles', wf%n_v * wf%n_o**2)
      call wf%intermediate_approximate_doubles(R_ai, omega, intermediate_file)

      reordered_intermediate_file = direct_stream_file('reordered_intermediate_approximate_doubles', &
                                                       wf%n_v * wf%n_o**2)

      call wf%get_reordered_intermediate_approximate_doubles(intermediate_file, reordered_intermediate_file)

      req0 = 0
      req1 = 3 * wf%n_o**2 * wf%n_v

      batch_a = batching_index(wf%n_v)

      call mem%batch_setup(batch_a, &
                           req0, &
                           req1, &
                           tag='approximate_double_excitation_vectors')

      squared_norm = ddot(wf%n_t1, R_ai, 1, R_ai, 1)

      call file_%open_()

      do current_a_batch = 1, batch_a%num_batches

         call batch_a%determine_limits(current_a_batch)

         call mem%alloc(X_jaib, wf%n_o, wf%n_v, wf%n_o, batch_a%length)
         call mem%alloc(X_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%length)

         call intermediate_file%open_()
         call intermediate_file%read_(X_ibja, batch_a%first, batch_a%get_last())
         call intermediate_file%close_()

         call reordered_intermediate_file%open_()
         call reordered_intermediate_file%read_(X_jaib, batch_a%first, batch_a%get_last())
         call reordered_intermediate_file%close_()

         call mem%alloc(R_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%length)

         call copy_and_scale(one, X_ibja, R_ibja, wf%n_o**2 * wf%n_v * batch_a%length)
         call daxpy(wf%n_o**2 * wf%n_v * batch_a%length, one, X_jaib, 1, R_ibja, 1)

         call mem%dealloc(X_jaib)
         call mem%dealloc(X_ibja)

         do a = 1, batch_a%length
            do i = 1, wf%n_o
               R_ibja(i, a + batch_a%first - 1, i, a) = half * R_ibja(i, a + batch_a%first - 1, i, a)
            end do
         end do

         ! Compute contribution to norm of packed vector
         squared_norm = squared_norm + half * ddot(wf%n_o**2 * wf%n_v * batch_a%length, R_ibja, 1, R_ibja, 1)
         do a = 1, batch_a%length
            do i = 1, wf%n_o
               squared_norm = squared_norm + half * R_ibja(i, a + batch_a%first - 1, i, a)**2
            end do
         end do

         call file_%write_(R_ibja, batch_a%first, batch_a%get_last())

         call mem%dealloc(R_ibja)
      end do

      call file_%close_()

      call mem%batch_finalize()

      norm = sqrt(squared_norm)
      call dscal(wf%n_o * wf%n_v, one / norm, R_ai, 1)
      call wf%scale_approximate_doubles(norm, file_)

   end subroutine approximate_double_excitation_vectors_ccs


   module subroutine approximate_double_excitation_vectors_triplet_ccs(wf, R_ai, omega, file_p, file_m)
      !!
      !! Written by Sarai D. Folkestad, Nov 2022
      !!
      !! Note: Renormalizes R_ai !
      !! Note: Integrals are in MO basis not T1 basis
      !!
      use direct_stream_file_class, only: direct_stream_file

      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_v, wf%n_o), intent(inout) :: R_ai

      real(dp), intent(in) :: omega

      type(direct_stream_file), intent(inout) :: file_p, file_m  ! record length o^2v

      type(direct_stream_file), allocatable :: intermediate_file, reordered_intermediate_file

      real(dp) :: norm

      intermediate_file = direct_stream_file('intermediate_approximate_doubles', wf%n_v * wf%n_o**2)
      call wf%intermediate_approximate_doubles(R_ai, omega, intermediate_file)

      reordered_intermediate_file = direct_stream_file('reordered_intermediate_approximate_doubles', &
                                                       wf%n_v * wf%n_o**2)

      call wf%get_reordered_intermediate_approximate_doubles(intermediate_file, reordered_intermediate_file)

      call wf%approximate_double_triplet_p(file_p, intermediate_file, reordered_intermediate_file)
      call wf%approximate_double_triplet_m(file_m, intermediate_file, reordered_intermediate_file)

      call wf%get_norm_approximate_doubles_triplet(R_ai, file_p, file_m, norm)

      call dscal(wf%n_o * wf%n_v, one / norm, R_ai, 1)
      call wf%scale_approximate_doubles(norm, file_p)
      call wf%scale_approximate_doubles(norm, file_m)

   end subroutine approximate_double_excitation_vectors_triplet_ccs


   module subroutine scale_approximate_doubles_ccs(wf, norm, file_)
      !!
      !! Written by Sarai D. Folkestad, Nov 2022
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), intent(in) :: norm


      type(direct_stream_file), intent(inout) :: file_  ! record length o^2v

      real(dp), dimension(:, :, :, :), allocatable :: R_ibja

      type(batching_index) :: batch_a

      integer :: current_a_batch
      integer :: req0, req1

      req0 = 0
      req1 = wf%n_o**2 * wf%n_v

      batch_a = batching_index(wf%n_v)

      call mem%batch_setup(batch_a, &
                           req0, &
                           req1, &
                           tag='scale_approximate_doubles')

      call file_%open_()

      call mem%alloc(R_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%max_length)

      do current_a_batch = 1, batch_a%num_batches

         call batch_a%determine_limits(current_a_batch)

         call file_%read_(R_ibja, batch_a%first, batch_a%get_last())

         call dscal(wf%n_o**2 * wf%n_v * batch_a%length, one / norm, R_ibja, 1)

         call file_%write_(R_ibja, batch_a%first, batch_a%get_last())

      end do

      call mem%dealloc(R_ibja)

      call file_%close_()

      call mem%batch_finalize()

   end subroutine scale_approximate_doubles_ccs


   module subroutine get_reordered_intermediate_approximate_doubles_ccs(wf, file_in, file_out)
      !!
      !! Written by Sarai D. Folkestad, Nov 2022
      !!
      implicit none

      class(ccs), intent(inout) :: wf
      type(direct_stream_file), intent(inout) :: file_in  ! record length o^2v
      type(direct_stream_file), intent(inout) :: file_out  ! record length o^2v

      type(batching_index) :: batch_a, batch_b

      real(dp), dimension(:, :, :, :), allocatable :: X_ibja, X_jaib

      integer :: current_a_batch, current_b_batch
      integer :: req0, req1_a, req1_b, req2
      integer :: a, i, b, j

      req0 = 0
      req1_a = wf%n_o**2 * wf%n_v

      req1_b = req1_a
      req2 = 0

      batch_a = batching_index(wf%n_v)
      batch_b = batching_index(wf%n_v)

      call mem%batch_setup(batch_a, &
                           batch_b, &
                           req0, &
                           req1_a, &
                           req1_b, &
                           req2, &
                           tag='get_reordered_intermediate_approximate_doubles_ccs')

      call mem%alloc(X_jaib, wf%n_o, wf%n_v, wf%n_o, batch_b%max_length)
      call mem%alloc(X_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%max_length)

      call file_in%open_()
      call file_out%open_()

      do current_b_batch = 1, batch_b%num_batches

         call batch_b%determine_limits(current_b_batch)

         do current_a_batch = 1, batch_a%num_batches

            call batch_a%determine_limits(current_a_batch)

            call file_in%read_(X_ibja, batch_a%first, batch_a%get_last())

            do a = 1, batch_a%length
               do i = 1, wf%n_o
                  do b = 1, batch_b%length
                     do j = 1, wf%n_o
                        X_jaib(j, a + batch_a%first - 1, i, b) = X_ibja(i, b + batch_b%first - 1, j, a)
                     end do
                  end do
               end do
            end do

         end do  ! a batch

         call file_out%write_(X_jaib, batch_b%first, batch_b%get_last())

      end do  ! b batch

      call file_in%close_()
      call file_out%close_()

      call mem%dealloc(X_jaib)
      call mem%dealloc(X_ibja)

      call mem%batch_finalize()

   end subroutine get_reordered_intermediate_approximate_doubles_ccs


   module subroutine intermediate_approximate_doubles_ccs(wf, R_ai, omega, file_)
      !!
      !! Written by Sarai D. Folkestad, Nov 2022
      !!
      !! Computes the intermediate for approximate double excitation vectors:
      !!
      !!    R_aibj = (sum_c R_ci g_bjac - sum_k R_ak g_kibj))/(-eps_aibj + omega^CCS)
      !!
      !! Used for CNTOs from CCS.
      !!
      !! For further information see Baudin, P. and Kristensen, K., J. Chem. Phys. 2017, 146, 214114
      !!
      use reordering_r, only: sort_to_132

      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_v, wf%n_o), intent(inout) :: R_ai

      real(dp), intent(in) :: omega

      type(batching_index) :: batch_a

      type(direct_stream_file), intent(inout) :: file_  ! record length o^2v

      real(dp), dimension(:, :, :), allocatable :: L_Jbj, L_Jik, L_Jac
      real(dp), dimension(:, :, :), allocatable :: X_Jai, X_Jia

      real(dp), dimension(:, :, :, :), allocatable :: Y_aibj, X_ibja

      integer :: current_a_batch
      integer :: req0, req1
      integer :: a, i, b, j

      real(dp), dimension(:), allocatable :: eps_o, eps_v

      call mem%alloc(eps_o, wf%n_o)
      call dcopy(wf%n_o, wf%orbital_energies(1:wf%n_o), 1, eps_o, 1)

      call mem%alloc(eps_v, wf%n_v)
      call dcopy(wf%n_v, wf%orbital_energies(wf%n_o + 1:wf%n_mo), 1, eps_v, 1)

      call mem%alloc(L_Jik, wf%eri_t1%n_J, wf%n_o, wf%n_o)
      call wf%L_mo%get(L_Jik, 1, wf%n_o, 1, wf%n_o)

      call mem%alloc(L_Jbj, wf%eri_t1%n_J, wf%n_v, wf%n_o)
      call wf%L_mo%get(L_Jbj, 1 + wf%n_o, wf%n_mo, 1, wf%n_o)

      req0 = 0
      req1 = wf%n_o * wf%eri_t1%n_J + wf%n_v * wf%eri_t1%n_J + 2 * wf%n_o**2 * wf%n_v

      batch_a = batching_index(wf%n_v)

      call mem%batch_setup(batch_a, &
                           req0, &
                           req1, &
                           tag='intermediate_approximate_doubles_ccs')

      call file_%open_()

      do current_a_batch = 1, batch_a%num_batches

         call batch_a%determine_limits(current_a_batch)

         call mem%alloc(X_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%length)

         call mem%alloc(X_Jia, wf%eri_t1%n_J, wf%n_o, batch_a%length)

         call dgemm('N', &
                    'T', &
                    wf%n_o * wf%eri_t1%n_J, &
                    batch_a%length, &
                    wf%n_o, &
                    - one, &
                    L_Jik, &
                    wf%n_o * wf%eri_t1%n_J, &
                    R_ai(batch_a%first, 1), &  ! R_ak
                    wf%n_v, &
                    zero, &
                    X_Jia, &
                    wf%n_o * wf%eri_t1%n_J)

         call mem%alloc(X_Jai, wf%eri_t1%n_J, batch_a%length, wf%n_o)
         call sort_to_132(X_Jia, X_Jai, wf%eri_t1%n_J, wf%n_o, batch_a%length)
         call mem%dealloc(X_Jia)

         call mem%alloc(L_Jac, wf%eri_t1%n_J, batch_a%length, wf%n_v)

         call wf%L_mo%get(L_Jac, &
                          batch_a%first + wf%n_o, &
                          batch_a%get_last() + wf%n_o, &
                          1 + wf%n_o, &
                          wf%n_mo)

         ! X_ai_J = sum_c R_ci L_ac_J

         call dgemm('N', &
                    'N', &
                    batch_a%length * wf%eri_t1%n_J, &
                    wf%n_o, &
                    wf%n_v, &
                    one, &
                    L_Jac, &  ! L_Ja_c
                    batch_a%length * wf%eri_t1%n_J, &
                    R_ai, &  ! R_c_i
                    wf%n_v, &
                    one, &
                    X_Jai, &
                    batch_a%length * wf%eri_t1%n_J)

         call mem%dealloc(L_Jac)


         call mem%alloc(Y_aibj, batch_a%length, wf%n_o, wf%n_v, wf%n_o)

         call dgemm('T', &
                    'N', &
                    batch_a%length * wf%n_o, &
                    wf%n_v * wf%n_o, &
                    wf%eri_t1%n_J, &
                    one, &
                    X_Jai, &  ! X_J_ai
                    wf%eri_t1%n_J, &
                    L_Jbj, &
                    wf%eri_t1%n_J, &
                    zero, &
                    Y_aibj, &
                    batch_a%length * wf%n_o)

         !$omp parallel do private(a, i, b, j)
         do i = 1, wf%n_o
            do a = 1, batch_a%length
               do j = 1, wf%n_o
                  do b = 1, wf%n_v

                     X_ibja(i, b, j, a) = Y_aibj(a, i, b, j) / &
                                          (- eps_v(batch_a%first - 1 + a) - eps_v(b) + eps_o(i) + eps_o(j) &
                                          + omega)

                  end do
               end do
            end do
         end do
         !$omp end parallel do

         call mem%dealloc(Y_aibj)

         call file_%write_(X_ibja, batch_a%first, batch_a%get_last())

         call mem%dealloc(X_Jai)
         call mem%dealloc(X_ibja)

      end do  ! a batch

      call file_%close_()

      call mem%batch_finalize()

      call mem%dealloc(L_Jbj)
      call mem%dealloc(L_Jik)
      call mem%dealloc(eps_o)
      call mem%dealloc(eps_v)

   end subroutine intermediate_approximate_doubles_ccs


   module subroutine approximate_double_triplet_p_ccs(wf, &
                                                      file_, &
                                                      intermediate_file, &
                                                      reordered_intermediate_file)
      !!
      !! Written by Sarai D. Folkestad, 2019-2022
      !!
      !! Approximate double excitation vectors:
      !!
      !!    R^+_aibj = 1/2 P_ai,bj (X_aibj - X_ajbi)
      !!
      !!    X_aibj = (sum_c R_ci g_bjac - sum_k R_bk g_kjai)/(-eps_aibj + omega^CCS)
      !!
      !! Used for CNTOs from CCS.
      !!
      !! Note should be renormalized after this routine is called
      !!
      use batching_index_class, only: batching_index
      use reordering_r, only: add_3214_to_1234
      use direct_stream_file_class, only: direct_stream_file
      use array_initialization, only: copy_and_scale

      implicit none

      class(ccs), intent(inout) :: wf

      type(direct_stream_file), intent(inout) :: file_  ! record length o^2v

      type(direct_stream_file), intent(inout) :: intermediate_file, reordered_intermediate_file

      real(dp), dimension(:, :, :, :), allocatable :: X_ibja, R_ibja, X_jaib

      type(batching_index) :: batch_a

      integer :: current_a_batch
      integer :: req0, req1

      req0 = 0
      req1 = 3 * wf%n_o**2 * wf%n_v

      batch_a = batching_index(wf%n_v)

      call mem%batch_setup(batch_a, &
                           req0, &
                           req1, &
                           tag='approximate_double_excitation_vectors')

      do current_a_batch = 1, batch_a%num_batches

         call batch_a%determine_limits(current_a_batch)

         call mem%alloc(X_jaib, wf%n_o, wf%n_v, wf%n_o, batch_a%length)
         call mem%alloc(X_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%length)

         call intermediate_file%open_()
         call intermediate_file%read_(X_ibja, batch_a%first, batch_a%get_last())
         call intermediate_file%close_()

         call reordered_intermediate_file%open_()
         call reordered_intermediate_file%read_(X_jaib, batch_a%first, batch_a%get_last())
         call reordered_intermediate_file%close_()

         call mem%alloc(R_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%length)

         call copy_and_scale(one, X_ibja, R_ibja, wf%n_o**2 * wf%n_v * batch_a%length)
         call add_3214_to_1234(- one, X_ibja, R_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%length)

         call daxpy(wf%n_o**2 * wf%n_v * batch_a%length, one, X_jaib, 1, R_ibja, 1)
         call add_3214_to_1234(- one, X_jaib, R_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%length)

         call mem%dealloc(X_jaib)
         call mem%dealloc(X_ibja)

         call dscal(wf%n_o**2 * wf%n_v * batch_a%length, half, R_ibja, 1)

         call file_%open_()
         call file_%write_(R_ibja, batch_a%first, batch_a%get_last())
         call file_%close_()

         call mem%dealloc(R_ibja)
      end do

      call mem%batch_finalize()

   end subroutine approximate_double_triplet_p_ccs


   module subroutine approximate_double_triplet_m_ccs(wf, &
                                                      file_, &
                                                      intermediate_file, &
                                                      reordered_intermediate_file)
      !!
      !! Written by Sarai D. Folkestad, 2019-2022
      !!
      !! Approximate double excitation vectors:
      !!
      !!    R^-_aibj = 1/2 (X_aibj - X_bjai)
      !!
      !!    X_aibj = (sum_c R_ci g_bjac - sum_k R_bk g_kjai)/(-eps_aibj + omega^CCS)
      !!
      !! Used for CNTOs from CCS.
      !!
      !! Note should be renormalized after this routine is called
      !!
      use batching_index_class, only: batching_index
      use direct_stream_file_class, only: direct_stream_file
      use array_initialization, only: copy_and_scale

      implicit none

      class(ccs), intent(inout) :: wf

      type(direct_stream_file), intent(inout) :: file_  ! record length o^2v

      type(direct_stream_file), intent(inout) :: intermediate_file, reordered_intermediate_file

      real(dp), dimension(:, :, :, :), allocatable :: X_ibja, R_ibja, X_jaib

      type(batching_index) :: batch_a

      integer :: current_a_batch
      integer :: req0, req1

      req0 = 0
      req1 = 3 * wf%n_o**2 * wf%n_v

      batch_a = batching_index(wf%n_v)

      call mem%batch_setup(batch_a, &
                           req0, &
                           req1, &
                           tag='approximate_double_excitation_vectors')

      do current_a_batch = 1, batch_a%num_batches

         call batch_a%determine_limits(current_a_batch)

         call mem%alloc(X_jaib, wf%n_o, wf%n_v, wf%n_o, batch_a%length)
         call mem%alloc(X_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%length)

         call intermediate_file%open_()
         call intermediate_file%read_(X_ibja, batch_a%first, batch_a%get_last())
         call intermediate_file%close_()

         call reordered_intermediate_file%open_()
         call reordered_intermediate_file%read_(X_jaib, batch_a%first, batch_a%get_last())
         call reordered_intermediate_file%close_()

         call mem%alloc(R_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%length)

         call copy_and_scale(- one, X_ibja, R_ibja, wf%n_o**2 * wf%n_v * batch_a%length)
         call daxpy(wf%n_o**2 * wf%n_v * batch_a%length, one, X_jaib, 1, R_ibja, 1)

         call mem%dealloc(X_jaib)
         call mem%dealloc(X_ibja)

         call dscal(wf%n_o**2 * wf%n_v * batch_a%length, half, R_ibja, 1)

         call file_%open_()
         call file_%write_(R_ibja, batch_a%first, batch_a%get_last())
         call file_%close_()

         call mem%dealloc(R_ibja)
      end do

      call mem%batch_finalize()

   end subroutine approximate_double_triplet_m_ccs


   module subroutine get_norm_approximate_doubles_triplet_ccs(wf, R_ai, file_p, file_m, norm)
      !!
      !! Written by Sarai D. Folkestad, 2019-2022
      !!
      !! Approximate double excitation vectors:
      !!
      !! Used for CNTOs from CCS.
      !!
      !! Note should be renormalized after this routine is called
      !!
      use batching_index_class, only: batching_index
      use direct_stream_file_class, only: direct_stream_file

      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), intent(out) :: norm

      type(direct_stream_file), intent(inout) :: file_p, file_m  ! record length o^2v
      real(dp), dimension(wf%n_v, wf%n_o), intent(inout) :: R_ai

      real(dp) :: ddot, squared_norm

      real(dp), dimension(:, :, :, :), allocatable :: R_m_ibja, R_p_ibja

      type(batching_index) :: batch_a

      integer :: current_a_batch
      integer :: req0, req1

      req0 = 0
      req1 = 2 * wf%n_o**2 * wf%n_v

      batch_a = batching_index(wf%n_v)

      squared_norm = ddot(wf%n_t1, R_ai, 1, R_ai, 1)

      call mem%batch_setup(batch_a, &
                           req0, &
                           req1, &
                           tag='approximate_double_excitation_vectors')

      do current_a_batch = 1, batch_a%num_batches

         call batch_a%determine_limits(current_a_batch)

         call mem%alloc(R_m_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%length)
         call mem%alloc(R_p_ibja, wf%n_o, wf%n_v, wf%n_o, batch_a%length)

         call file_p%open_()
         call file_p%read_(R_p_ibja, batch_a%first, batch_a%get_last())
         call file_p%close_()

         call file_m%open_()
         call file_m%read_(R_m_ibja, batch_a%first, batch_a%get_last())
         call file_m%close_()

         squared_norm = squared_norm + half * ddot(wf%n_o**2 * wf%n_v * batch_a%length, &
                                                   R_m_ibja, &
                                                   1, &
                                                   R_m_ibja, &
                                                   1)

         squared_norm = squared_norm + quarter * ddot(wf%n_o**2 * wf%n_v * batch_a%length, &
                                                      R_p_ibja, &
                                                      1, &
                                                      R_p_ibja, &
                                                      1)

         call mem%dealloc(R_m_ibja)
         call mem%dealloc(R_p_ibja)

      end do

      norm = sqrt(squared_norm)

      call mem%batch_finalize()

   end subroutine get_norm_approximate_doubles_triplet_ccs


end submodule approximate_doubles_ccs

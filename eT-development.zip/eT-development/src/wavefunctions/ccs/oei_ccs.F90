

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


submodule (ccs_class) oei_ccs

   !!
   !! One-electron integrals submodule
   !!
   !! Submodule containing routines that can be used to
   !! construct t1-transformed one-electron integrals.
   !!

   implicit none


contains


   module subroutine get_mo_oei_ccs(wf, &
                                    oei_type, &
                                    oei, &
                                    screening)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Calculates and saves the T1-transformed one-electron integrals specified
      !! by 'oei_type' in the array 'oei'.
      !!
      !! Arguments:
      !!
      !!    oei:      (n_mo x n_mo x n_components)-array where integrals are placed
      !!    oei_type: (string) which integral to calculate,
      !!              see get_n_oei_components_abstract_oei_library for available integrals
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(*), intent(out), target :: oei

      logical, intent(in), optional :: screening

      real(dp), dimension(:, :, :), pointer :: oei_p

      real(dp), dimension(:, :, :), allocatable :: oei_ao

      integer :: n_components, k

      n_components = wf%ao%get_n_oei_components(oei_type)

      call mem%alloc(oei_ao, wf%ao%n, wf%ao%n, n_components)

      call wf%ao_oei%get_oei(oei_type, oei_ao, screening)

      oei_p(1:wf%n_mo, 1:wf%n_mo, 1:n_components) => oei(1:wf%n_mo**2 * n_components)

      do k = 1, n_components

         call wf%mo_transform(oei_ao(:, :, k), oei_p(:, :, k))

      end do

      call mem%dealloc(oei_ao)

   end subroutine get_mo_oei_ccs


   module subroutine get_mo_oei_ccs_complex(wf, &
                                            oei_type, &
                                            oei, &
                                            screening)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Calculates and saves the T1-transformed one-electron integrals specified
      !! by 'oei_type' in the array 'oei'.
      !!
      !! Arguments:
      !!
      !!    oei:      (n_mo x n_mo x n_components)-array where integrals are placed
      !!    oei_type: (string) which integral to calculate
      !!
      !! Valid values of 'oei_type' are:
      !!
      !!    - 'hamiltonian'  One-electron Hamiltonian (h)  n_components = 1
      !!    - 'overlap'      AO overlap (S)                n_components = 1
      !!    - 'dipole'       Dipole moment (mu)            n_components = 3 (mu_x, mu_y, mu_z)
      !!    - 'quadrupole'   Quadrupole moment (q)         n_components = 6 (q_xx, q_xy, q_xz,
      !!                                                                     q_yy, q_yz, q_zz)
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      character(len=*), intent(in) :: oei_type

      complex(dp), dimension(*), intent(out), target :: oei

      logical, intent(in), optional :: screening

      complex(dp), dimension(:, :, :), pointer :: oei_p

      real(dp), dimension(:, :), allocatable :: oei_mo  ! MO integrals for a given component

      real(dp), dimension(:, :, :), allocatable :: oei_ao

      integer :: n_components, k

      ! Determine number of components of the OEI

      n_components = wf%ao%get_n_oei_components(oei_type)

      ! Allocate and calculate the AO integrals

      call mem%alloc(oei_ao, wf%ao%n, wf%ao%n, n_components)

      call wf%ao_oei%get_oei(oei_type, oei_ao, screening)

      ! Transform the AO integrals to the T1-transformed basis

      oei_p(1:wf%n_mo, 1:wf%n_mo, 1:n_components) => oei(1:wf%n_mo**2 * n_components)

      call mem%alloc(oei_mo, wf%n_mo, wf%n_mo)

      do k = 1, n_components

         call wf%mo_transform(oei_ao(:, :, k), oei_mo)

         oei_p(:, :, k) = cmplx(oei_mo, zero, dp)

      end do

      call mem%dealloc(oei_mo)
      call mem%dealloc(oei_ao)

   end subroutine get_mo_oei_ccs_complex


   module subroutine get_t1_oei_ccs(wf, &
                                    oei_type, &
                                    oei, &
                                    screening)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Calculates and saves the T1-transformed one-electron integrals specified
      !! by 'oei_type' in the array 'oei'.
      !!
      !! Arguments:
      !!
      !!    oei:      (n_mo x n_mo x n_components)-array where integrals are placed
      !!    oei_type: (string) which integral to calculate,
      !!              see get_n_oei_components_abstract_oei_library for available integrals
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      character(len=*), intent(in) :: oei_type

      real(dp), dimension(*), intent(out), target :: oei

      logical, intent(in), optional :: screening

      real(dp), dimension(:, :, :), pointer :: oei_p

      integer :: n_components, k

      call wf%get_mo_oei(oei_type, oei, screening)

      n_components = wf%ao%get_n_oei_components(oei_type)

      oei_p(1:wf%n_mo, 1:wf%n_mo, 1:n_components) => oei(1:wf%n_mo**2 * n_components)

      do k = 1, n_components

         call wf%t1_transform(oei_p(:, :, k))

      end do

   end subroutine get_t1_oei_ccs


   module subroutine get_t1_oei_ccs_complex(wf, &
                                            oei_type, &
                                            oei, &
                                            screening)
      !!
      !! Written by Eirik F. Kjoenstad, 2020
      !!
      !! Calculates and saves the T1-transformed one-electron integrals specified
      !! by 'oei_type' in the array 'oei'.
      !!
      !! Arguments:
      !!
      !!    oei:      (n_mo x n_mo x n_components)-array where integrals are placed
      !!    oei_type: (string) which integral to calculate
      !!
      !! Valid values of 'oei_type' are:
      !!
      !!    - 'hamiltonian'  One-electron Hamiltonian (h)  n_components = 1
      !!    - 'overlap'      AO overlap (S)                n_components = 1
      !!    - 'dipole'       Dipole moment (mu)            n_components = 3 (mu_x, mu_y, mu_z)
      !!    - 'quadrupole'   Quadrupole moment (q)         n_components = 6 (q_xx, q_xy, q_xz,
      !!                                                                     q_yy, q_yz, q_zz)
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      character(len=*), intent(in) :: oei_type

      complex(dp), dimension(*), intent(out), target :: oei

      logical, intent(in), optional :: screening

      complex(dp), dimension(:, :, :), pointer :: oei_p

      integer :: n_components, k

      call wf%get_mo_oei_complex(oei_type, oei, screening)

      n_components = wf%ao%get_n_oei_components(oei_type)

      oei_p(1:wf%n_mo, 1:wf%n_mo, 1:n_components) => oei(1:wf%n_mo**2 * n_components)

      do k = 1, n_components

         call wf%t1_transform_complex(oei_p(:, :, k))

      end do

   end subroutine get_t1_oei_ccs_complex


   module subroutine get_mo_overlap_1der_ccs(wf, s_rsqk)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_mo, wf%n_mo, 3, wf%n_atomic_centers), intent(out) :: s_rsqk

      real(dp), dimension(:, :, :, :), allocatable :: s_wxqk

      integer :: q, k

      call mem%alloc(s_wxqk, wf%ao%n, wf%ao%n, 3, wf%n_atomic_centers)

      call wf%ao%get_oei_1der('overlap', S_wxqk)

      do q = 1, 3
         do k = 1, wf%n_atomic_centers

            call wf%mo_transform(s_wxqk(:, :, q, k), s_rsqk(:, :, q, k))

         end do
      end do

      call mem%dealloc(s_wxqk)

   end subroutine get_mo_overlap_1der_ccs


   module subroutine get_mo_h_1der_ccs(wf, h_rsqk)
      !!
      !! Written by Eirik F. Kjoenstad, 2023
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_mo, wf%n_mo, 3, wf%n_atomic_centers), intent(out) :: h_rsqk

      real(dp), dimension(:, :, :, :), allocatable :: h_wxqk, h_wxqk_nuc

      integer :: q, k

      call mem%alloc(h_wxqk, wf%ao%n, wf%ao%n, 3, wf%n_atomic_centers)

      call wf%ao%get_oei_1der('kinetic', h_wxqk)

      call mem%alloc(h_wxqk_nuc, wf%ao%n, wf%ao%n, 3, wf%n_atomic_centers)

      call wf%ao%get_oei_1der('nuclear', h_wxqk_nuc)

      call daxpy(wf%ao%n**2 * 3 * wf%n_atomic_centers, one, h_wxqk_nuc, 1, h_wxqk, 1)

      call mem%dealloc(h_wxqk_nuc)

      do q = 1, 3
         do k = 1, wf%n_atomic_centers

            call wf%mo_transform(h_wxqk(:, :, q, k), h_rsqk(:, :, q, k))

         end do
      end do

      call mem%dealloc(h_wxqk)

   end subroutine get_mo_h_1der_ccs


end submodule oei_ccs



! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


submodule (ccs_class) initialize_destruct_ccs

   !!
   !! Initialize destruct submodule
   !!
   !! Gathers routines that initialize and destruct the CCS type-bound variables.
   !!

   implicit none


contains


   module subroutine initialize_amplitudes_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Sep 2018
      !!
      !! Allocates the amplitudes. This routine must be overwritten in
      !! descendants which have more amplitudes.
      !!
      implicit none

      class(ccs) :: wf

      call wf%initialize_t1()

   end subroutine initialize_amplitudes_ccs


   module subroutine destruct_amplitudes_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Sep 2018
      !!
      !! Deallocates the amplitudes. This routine must be overwritten in
      !! descendants which have more amplitudes.
      !!
      implicit none

      class(ccs) :: wf

      call wf%destruct_t1()

   end subroutine destruct_amplitudes_ccs


   module subroutine initialize_t1_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (.not. allocated(wf%t1)) call mem%alloc(wf%t1, wf%n_v, wf%n_o)

   end subroutine initialize_t1_ccs


   module subroutine destruct_t1_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (allocated(wf%t1)) call mem%dealloc(wf%t1)

   end subroutine destruct_t1_ccs


   module subroutine initialize_multipliers_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Sep 2018
      !!
      !! Allocates the multipliers. This routine must be overwritten in
      !! descendants which have more multipliers.
      !!
      implicit none

      class(ccs) :: wf

      call wf%initialize_t1bar()

   end subroutine initialize_multipliers_ccs


   module subroutine destruct_multipliers_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Sep 2018
      !!
      !! Deallocates the multipliers. This routine must be overwritten in
      !! descendants which have more multipliers.
      !!
      implicit none

      class(ccs) :: wf

      call wf%destruct_t1bar()

   end subroutine destruct_multipliers_ccs


   module subroutine initialize_t1bar_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (.not. allocated(wf%t1bar)) call mem%alloc(wf%t1bar, wf%n_v, wf%n_o)

   end subroutine initialize_t1bar_ccs


   module subroutine destruct_t1bar_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (allocated(wf%t1bar)) call mem%dealloc(wf%t1bar)

   end subroutine destruct_t1bar_ccs


   module subroutine initialize_fock_ij_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (.not. allocated(wf%fock_ij)) call mem%alloc(wf%fock_ij, wf%n_o, wf%n_o)

   end subroutine initialize_fock_ij_ccs


   module subroutine destruct_fock_ij_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (allocated(wf%fock_ij)) call mem%dealloc(wf%fock_ij)

   end subroutine destruct_fock_ij_ccs


   module subroutine initialize_fock_ia_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (.not. allocated(wf%fock_ia)) call mem%alloc(wf%fock_ia, wf%n_o, wf%n_v)

   end subroutine initialize_fock_ia_ccs


   module subroutine destruct_fock_ia_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (allocated(wf%fock_ia)) call mem%dealloc(wf%fock_ia)

   end subroutine destruct_fock_ia_ccs


   module subroutine initialize_fock_ai_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (.not. allocated(wf%fock_ai)) call mem%alloc(wf%fock_ai, wf%n_v, wf%n_o)

   end subroutine initialize_fock_ai_ccs


   module subroutine destruct_fock_ai_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (allocated(wf%fock_ai)) call mem%dealloc(wf%fock_ai)

   end subroutine destruct_fock_ai_ccs


   module subroutine initialize_fock_ab_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (.not. allocated(wf%fock_ab)) call mem%alloc(wf%fock_ab, wf%n_v, wf%n_v)

   end subroutine initialize_fock_ab_ccs


   module subroutine destruct_fock_ab_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs) :: wf

      if (allocated(wf%fock_ab)) call mem%dealloc(wf%fock_ab)

   end subroutine destruct_fock_ab_ccs


   module subroutine initialize_gs_density_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad, Apr 2019
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      call mem%alloc(wf%density, wf%n_mo, wf%n_mo)

   end subroutine initialize_gs_density_ccs


   module subroutine destruct_gs_density_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad, Apr 2019
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      if (allocated(wf%density)) call mem%dealloc(wf%density)

   end subroutine destruct_gs_density_ccs


   module subroutine initialize_core_MOs_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, September 2018
      !!
      implicit none

      class(ccs) :: wf

      if (.not. allocated(wf%core_MOs)) call mem%alloc(wf%core_MOs, wf%n_core_MOs)

   end subroutine initialize_core_MOs_ccs


   module subroutine destruct_core_MOs_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, September 2018
      !!
      implicit none

      class(ccs) :: wf

      if (allocated(wf%core_MOs)) call mem%dealloc(wf%core_MOs)

   end subroutine destruct_core_MOs_ccs


   module subroutine initialize_fock_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad, Sep 2019
      !!
      !! Initializes all Fock matrix blocks
      !!
      implicit none

      class(ccs) :: wf

      call wf%initialize_fock_ij()
      call wf%initialize_fock_ia()
      call wf%initialize_fock_ai()
      call wf%initialize_fock_ab()

   end subroutine initialize_fock_ccs


   module subroutine destruct_fock_ccs(wf)
      !!
      !! Written by Alexander C. Paul, Dec 2019
      !!
      !! Destructs all Fock matrix blocks
      !!
      implicit none

      class(ccs) :: wf

      call wf%destruct_fock_ij()
      call wf%destruct_fock_ia()
      call wf%destruct_fock_ai()
      call wf%destruct_fock_ab()

   end subroutine destruct_fock_ccs


   module subroutine initialize_density_intermediates_ccs(wf, n_es_states)
      !!
      !! Written by Alexander C. Paul and Sarai D. Folkestad, Apr 2020
      !!
      implicit none

      class(ccs), intent(inout) :: wf
      integer, intent(in) :: n_es_states

      call mem%alloc(wf%r0, n_es_states)

   end subroutine initialize_density_intermediates_ccs


   module subroutine destruct_density_intermediates_ccs(wf)
      !!
      !! Written by Alexander C. Paul and Sarai D. Folkestad, Apr 2020
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      if (allocated(wf%r0)) call mem%dealloc(wf%r0)

   end subroutine destruct_density_intermediates_ccs


   module subroutine initialize_density_storer(wf, n_es_states)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      implicit none

      class(ccs), intent(inout) :: wf
      integer, intent(in) :: n_es_states

      wf%density_storage = density_storer("cc_densities", &
                                          wf%n_mo**2, &
                                          n_es_states + 1, &
                                          records_in_mem=.false.)

      call wf%density_storage%initialize()

   end subroutine initialize_density_storer


   module subroutine destruct_density_storer(wf)
      !!
      !! Written by Alexander C. Paul, 2022
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      if (allocated(wf%density_storage)) then
         call wf%density_storage%finalize()
         deallocate(wf%density_storage)
      end if

   end subroutine destruct_density_storer


   module subroutine initialize_dyson_files(wf)
      !!
      !! Written by Alexander C. Paul, Jan 2023
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      wf%right_dyson_file = stream_file("left_dyson_coefficients")
      wf%left_dyson_file = stream_file("right_dyson_coefficients")

   end subroutine initialize_dyson_files



end submodule initialize_destruct_ccs

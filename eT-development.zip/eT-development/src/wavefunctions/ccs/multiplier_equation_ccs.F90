

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


submodule (ccs_class) multiplier_equation_ccs

   !!
   !! Multiplier equation submodule
   !!
   !! Routines for calculation of the multiplier equation,
   !!
   !!    t-bar^T A + eta = 0,
   !!
   !! where t-bar is the multiplier vector, and
   !!
   !!    A_mu,nu = < mu |exp(-T) [H, tau_nu] exp(T) | R >
   !!    eta_mu  = < R |exp(-T) [H, tau_mu] exp(T) | R >.
   !!

   implicit none


contains


   module subroutine prepare_for_multiplier_equation_ccs(wf)
      !!
      !! Written by Alexander C. Paul, July 2019
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      ! For now, do nothing.

      call output%printf('v', &
                         '- No preparations for the ' // trim(wf%name_) // ' multiplier equation.', &
                         fs='(/t3,a)')

   end subroutine prepare_for_multiplier_equation_ccs


   module subroutine construct_multiplier_equation_ccs(wf, equation)
      !!
      !! Written by Eirik F. Kjoenstad, Oct 2018
      !!
      !! Constructs
      !!
      !!    t-bar^T A + eta,
      !!
      !! and places the result in 'equation'.
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_gs_amplitudes), intent(inout) :: equation

      real(dp), dimension(:), allocatable :: eta

      ! Copy the multipliers, eta = t-bar

      call mem%alloc(eta, wf%n_gs_amplitudes)
      call wf%get_multipliers(eta)

      ! Transform the multipliers by A^T, eq. = t-bar^T A

      call wf%jacobian_transpose_transformation(eta, equation)

      ! Add eta, eq. = t-bar^T A + eta

      call wf%construct_eta(eta)

      call daxpy(wf%n_gs_amplitudes, one, eta, 1, equation, 1)

      call mem%dealloc(eta)

   end subroutine construct_multiplier_equation_ccs


   module subroutine construct_eta_ccs(wf, eta)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, June 2017
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_gs_amplitudes), intent(inout) :: eta

      integer :: i, a, ai

      !$omp parallel do private(a, i, ai)
      do i = 1, wf%n_o
         do a = 1, wf%n_v

            ai = wf%n_v * (i - 1) + a
            eta(ai) = two * (wf%fock_ia(i, a))

         end do
      end do
      !$omp end parallel do

   end subroutine construct_eta_ccs


   module subroutine get_initial_cc_multipliers_ccs(wf, c, restart)
      !!
      !!
      !! Written by Regina Matveeva, Sep 2021
      !!
      implicit none

      class(ccs) :: wf

      real(dp), dimension(wf%n_gs_amplitudes) :: c

      logical :: restart

      call wf%set_initial_multipliers_guess(restart)

      call wf%get_multipliers(c)

   end subroutine get_initial_cc_multipliers_ccs


   module subroutine cc_multipliers_summary_ccs(wf)
      !!
      !! Written by Regina Matveeva, Sep 2021
      !!
      !! Prints the dominant amplitudes in the amplitude vector
      !!
      implicit none

      class(ccs) :: wf

      real(dp), dimension(:), allocatable :: multipliers

      call output%printf('n', '- CC multipliers solver summary:', fs='(/t3,a)')

      call mem%alloc(multipliers, wf%n_gs_amplitudes)

      call wf%get_multipliers(multipliers)

      call wf%print_dominant_x_amplitudes_singlet(multipliers, 'tbar')

      call mem%dealloc(multipliers)

      call wf%calculate_and_print_variational_energy()

   end subroutine cc_multipliers_summary_ccs


end submodule multiplier_equation_ccs

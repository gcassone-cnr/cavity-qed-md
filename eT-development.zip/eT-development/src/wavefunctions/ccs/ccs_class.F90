

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module ccs_class

   !!
   !! Coupled cluster singles (ccs) class module
   !! Written by Eirik F. Kjoenstad and Sarai D. Folkestad, 2018
   !!

   use parameters

   use wavefunction_class, only: wavefunction

   use global_in, only: input
   use global_out, only: output
   use timings_class, only: timings
   use memory_manager_class, only: mem

   use stream_file_class, only: stream_file
   use output_file_class, only: output_file
   use direct_stream_file_class, only: direct_stream_file
   use amplitude_file_storer_class, only: amplitude_file_storer

   use density_storer_class, only: density_storer

   use state_descriptor_class, only: state_descriptor

   use range_class, only: range_

   use ao_oei_getter_class, only: ao_oei_getter
   use ao_eri_getter_class, only: ao_eri_getter
   use abstract_eri_cholesky_class, only: abstract_eri_cholesky
   use abstract_eri_cholesky_c_class, only: abstract_eri_cholesky_c
   use eri_adapter_class, only: eri_adapter
   use eri_adapter_c_class, only: eri_adapter_c

   ! Need these here to avoid intel segfault
   use eri_memory_tool_c_class, only: eri_memory_tool_c
   use eri_tool_c_class, only: eri_tool_c
   use eri_cholesky_disk_c_class, only: eri_cholesky_disk_c
   use eri_cholesky_memory_c_class, only: eri_cholesky_memory_c

   use cholesky_basis_class, only: cholesky_basis_

   use cc_gradient_densities_class, only: cc_gradient_densities

   use cc_es_states_handler_class, only: cc_es_states_handler

   use array_utilities, only: zdotu_

   use batching_index_class, only: batching_index


   implicit none

   type, extends(wavefunction) :: ccs

      real(dp) :: hf_energy
      real(dp) :: correlation_energy
      complex(dp) :: correlation_energy_complex

      integer :: n_gs_amplitudes
      integer :: n_es_amplitudes
      integer :: n_triplet_amplitudes
      integer :: n_t1


      integer :: n_o_bath, n_v_bath

      integer :: n_core_MOs

      logical :: need_g_abcd

      type(cc_es_states_handler), allocatable :: L_es_states, R_es_states

      type(amplitude_file_storer) :: t_storer, tbar_storer, omega_storer

      type(density_storer), allocatable :: density_storage
      type(stream_file), allocatable :: right_dyson_file, left_dyson_file

      type(eri_adapter), allocatable :: eri_t1
      type(eri_adapter_c), allocatable :: eri_t1_c

      class(abstract_eri_cholesky), allocatable :: L_mo
      class(abstract_eri_cholesky), allocatable :: L_t1

      class(abstract_eri_cholesky_c), allocatable :: L_mo_c
      class(abstract_eri_cholesky_c), allocatable :: L_t1_c

      class(cholesky_basis_), allocatable :: cholesky

      complex(dp) :: hf_energy_complex

      real(dp), dimension(:), allocatable :: t_response

      real(dp), dimension(:, :), allocatable :: t1
      complex(dp), dimension(:, :), allocatable :: t1_complex

      real(dp), dimension(:, :), allocatable :: t1bar
      complex(dp), dimension(:, :), allocatable :: t1bar_complex

      real(dp), dimension(:, :), allocatable :: fock_ij
      complex(dp), dimension(:, :), allocatable :: fock_ij_complex

      real(dp), dimension(:, :), allocatable :: fock_ia
      complex(dp), dimension(:, :), allocatable :: fock_ia_complex

      real(dp), dimension(:, :), allocatable :: fock_ai
      complex(dp), dimension(:, :), allocatable :: fock_ai_complex

      real(dp), dimension(:, :), allocatable :: fock_ab
      complex(dp), dimension(:, :), allocatable :: fock_ab_complex

      real(dp), dimension(:, :), allocatable :: density
      complex(dp), dimension(:, :), allocatable :: density_complex

      real(dp), dimension(:), allocatable :: r0
      complex(dp), dimension(:), allocatable :: r0_complex

      integer, dimension(:), allocatable :: core_MOs

      class(cc_gradient_densities), allocatable :: gradient_densities

   contains

      procedure :: print_banner => print_banner_ccs
      procedure :: print_amplitude_info => print_amplitude_info_ccs

      ! Initialization/destruction procedures

      procedure :: initialize_amplitudes => initialize_amplitudes_ccs
      procedure :: initialize_amplitudes_complex => initialize_amplitudes_ccs_complex

      procedure :: destruct_amplitudes => destruct_amplitudes_ccs
      procedure :: destruct_amplitudes_complex => destruct_amplitudes_ccs_complex

      procedure :: initialize_multipliers => initialize_multipliers_ccs
      procedure :: initialize_multipliers_complex => initialize_multipliers_ccs_complex

      procedure :: destruct_multipliers => destruct_multipliers_ccs
      procedure :: destruct_multipliers_complex => destruct_multipliers_ccs_complex

      procedure :: initialize_fock => initialize_fock_ccs
      procedure :: initialize_fock_complex => initialize_fock_ccs_complex

      procedure :: destruct_fock => destruct_fock_ccs
      procedure :: destruct_fock_complex => destruct_fock_ccs_complex

      procedure :: initialize_fock_ij => initialize_fock_ij_ccs
      procedure :: initialize_fock_ij_complex => initialize_fock_ij_ccs_complex

      procedure :: destruct_fock_ij => destruct_fock_ij_ccs
      procedure :: destruct_fock_ij_complex => destruct_fock_ij_ccs_complex

      procedure :: initialize_fock_ia => initialize_fock_ia_ccs
      procedure :: initialize_fock_ia_complex => initialize_fock_ia_ccs_complex

      procedure :: destruct_fock_ia => destruct_fock_ia_ccs
      procedure :: destruct_fock_ia_complex => destruct_fock_ia_ccs_complex

      procedure :: initialize_fock_ai => initialize_fock_ai_ccs
      procedure :: initialize_fock_ai_complex => initialize_fock_ai_ccs_complex

      procedure :: destruct_fock_ai => destruct_fock_ai_ccs
      procedure :: destruct_fock_ai_complex => destruct_fock_ai_ccs_complex

      procedure :: initialize_fock_ab => initialize_fock_ab_ccs
      procedure :: initialize_fock_ab_complex => initialize_fock_ab_ccs_complex

      procedure :: destruct_fock_ab => destruct_fock_ab_ccs
      procedure :: destruct_fock_ab_complex => destruct_fock_ab_ccs_complex

      procedure :: initialize_t1 => initialize_t1_ccs
      procedure :: initialize_t1_complex => initialize_t1_ccs_complex

      procedure :: destruct_t1 => destruct_t1_ccs
      procedure :: destruct_t1_complex => destruct_t1_ccs_complex

      procedure :: initialize_t1bar => initialize_t1bar_ccs
      procedure :: initialize_t1bar_complex => initialize_t1bar_ccs_complex

      procedure :: destruct_t1bar => destruct_t1bar_ccs
      procedure :: destruct_t1bar_complex => destruct_t1bar_ccs_complex

      procedure :: initialize_gs_density => initialize_gs_density_ccs
      procedure :: initialize_gs_density_complex => initialize_gs_density_ccs_complex

      procedure :: destruct_gs_density => destruct_gs_density_ccs
      procedure :: destruct_gs_density_complex => destruct_gs_density_ccs_complex

      procedure :: initialize_density_intermediates => initialize_density_intermediates_ccs
      procedure :: destruct_density_intermediates => destruct_density_intermediates_ccs

      procedure :: initialize_core_MOs => initialize_core_MOs_ccs
      procedure :: destruct_core_MOs => destruct_core_MOs_ccs

      procedure :: initialize_density_storer
      procedure :: destruct_density_storer

      ! Read settings

      procedure :: read_settings => read_settings_ccs
      procedure :: read_cvs_settings
      procedure :: read_rm_core_settings

      ! File handling procedures

      procedure :: initialize_ground_state_files => initialize_ground_state_files_ccs

      procedure :: save_amplitudes => save_amplitudes_ccs

      procedure :: read_amplitudes => read_amplitudes_ccs

      procedure :: save_multipliers => save_multipliers_ccs

      procedure :: read_multipliers => read_multipliers_ccs

      procedure :: save_omega => save_omega_ccs

      procedure :: read_omega => read_omega_ccs


      procedure :: save_tbar_intermediates => save_tbar_intermediates_ccs

      procedure :: get_density_for_plotting => get_density_for_plotting_ccs

      ! Print summaries

      procedure :: print_gs_summary => print_gs_summary_ccs
      procedure :: print_es_summary => print_es_summary_ccs
      procedure :: print_singles_diagnostics => print_singles_diagnostics_ccs

      ! Set/get procedures

      procedure :: set_amplitudes => set_amplitudes_ccs
      procedure :: set_amplitudes_complex => set_amplitudes_ccs_complex

      procedure :: get_amplitudes => get_amplitudes_ccs
      procedure :: get_amplitudes_complex => get_amplitudes_ccs_complex

      procedure :: set_multipliers => set_multipliers_ccs
      procedure :: set_multipliers_complex => set_multipliers_ccs_complex

      procedure :: get_multipliers => get_multipliers_ccs
      procedure :: get_multipliers_complex => get_multipliers_ccs_complex

      procedure :: get_full_multipliers => get_multipliers_ccs

      ! Procedures related to the Fock matrix

      procedure :: construct_fock => construct_fock_ccs
      procedure :: construct_fock_complex => construct_fock_ccs_complex

      procedure :: add_frozen_fock_terms => add_frozen_fock_terms_ccs
      procedure :: add_frozen_fock_terms_complex => add_frozen_fock_terms_ccs_complex

      procedure :: add_t1_fock_length_dipole_term => add_t1_fock_length_dipole_term_ccs
      procedure :: add_t1_fock_length_dipole_term_complex => add_t1_fock_length_dipole_term_ccs_complex

      procedure :: construct_fock_ai_t1 => construct_fock_ai_t1_ccs
      procedure :: construct_fock_ia_t1 => construct_fock_ia_t1_ccs
      procedure :: construct_fock_ij_t1 => construct_fock_ij_t1_ccs
      procedure :: construct_fock_ab_t1 => construct_fock_ab_t1_ccs

      procedure :: construct_fock_ai_t1_complex => construct_fock_ai_t1_ccs_complex
      procedure :: construct_fock_ia_t1_complex => construct_fock_ia_t1_ccs_complex
      procedure :: construct_fock_ij_t1_complex => construct_fock_ij_t1_ccs_complex
      procedure :: construct_fock_ab_t1_complex => construct_fock_ab_t1_ccs_complex

      ! Procedures related to the omega vector

      procedure :: construct_omega => construct_omega_ccs
      procedure :: construct_omega_complex => construct_omega_ccs_complex

      procedure :: omega_ccs_a1 => omega_ccs_a1_ccs
      procedure :: omega_ccs_a1_complex => omega_ccs_a1_ccs_complex

      ! Routines related to the F transformation

      procedure :: F_transformation => F_transformation_ccs
      procedure :: F_x_transformation => F_x_transformation_ccs
      procedure :: F_x_mu_transformation => F_x_mu_transformation_ccs

      procedure :: F_transformation_ccs_a1_0 => F_transformation_ccs_a1_0_ccs
      procedure :: F_transformation_ccs_a1_1 => F_transformation_ccs_a1_1_ccs
      procedure :: F_transformation_ccs_b1_1 => F_transformation_ccs_b1_1_ccs
      procedure :: F_transformation_ccs_c1_1 => F_transformation_ccs_c1_1_ccs

      ! Procedures related to the multiplier equation vector

      procedure :: construct_multiplier_equation => construct_multiplier_equation_ccs
      procedure :: construct_multiplier_equation_complex => construct_multiplier_equation_ccs_complex

      procedure :: construct_eta => construct_eta_ccs
      procedure :: construct_eta_complex => construct_eta_ccs_complex

      ! Procedures related to the multiplier solver

      procedure :: get_initial_cc_multipliers => get_initial_cc_multipliers_ccs
      procedure :: cc_multipliers_summary => cc_multipliers_summary_ccs

      ! Procedures related to the Jacobian transformation

      procedure :: construct_Jacobian_transform => construct_Jacobian_transform_ccs
      procedure :: construct_triplet_jacobian_transform => construct_triplet_jacobian_transform_ccs

      procedure :: prepare_for_Jacobians => prepare_for_Jacobians_ccs

      procedure :: prepare_for_approximate_Jacobians => prepare_for_approximate_Jacobians_ccs

      procedure :: approximate_Jacobian_transform => approximate_Jacobian_transform_ccs

      procedure :: jacobian_transformation => jacobian_transformation_ccs
      procedure :: jacobian_ccs_b1 => jacobian_ccs_b1_ccs

      procedure :: jacobian_transformation_oei => jacobian_transformation_oei_ccs
      procedure :: jacobian_ccs_a1_oei => jacobian_ccs_a1_oei_ccs


      ! Procedures related to the Jacobian transpose transformation

      procedure :: jacobian_transpose_transformation => jacobian_transpose_transformation_ccs
      procedure :: jacobian_transpose_transformation_complex => jacobian_transpose_transformation_ccs_complex

      procedure :: jacobian_transpose_ccs_b1 => jacobian_transpose_ccs_b1_ccs
      procedure :: jacobian_transpose_ccs_b1_complex => jacobian_transpose_ccs_b1_ccs_complex

      procedure :: jacobian_transpose_transformation_oei => jacobian_transpose_transformation_oei_ccs
      procedure :: jacobian_transpose_transformation_oei_complex => &
                   jacobian_transpose_transformation_oei_ccs_complex

      procedure :: jacobian_transpose_ccs_a1_oei => jacobian_transpose_ccs_a1_oei_ccs
      procedure :: jacobian_transpose_ccs_a1_oei_complex => jacobian_transpose_ccs_a1_oei_ccs_complex

      ! Procedures related to properties

      procedure :: calculate_expectation_value => calculate_expectation_value_ccs
      procedure :: calculate_expectation_value_complex => calculate_expectation_value_ccs_complex

      procedure :: calculate_energy => calculate_energy_ccs
      procedure :: calculate_energy_complex => calculate_energy_ccs_complex

      procedure :: calculate_and_print_variational_energy => calculate_and_print_variational_energy_ccs

      procedure :: calculate_energy_omega_term => calculate_energy_omega_term_ccs
      procedure :: calculate_energy_omega_term_complex => calculate_energy_omega_term_ccs_complex
      procedure :: calculate_energy_length_dipole_term_complex => &
                   calculate_energy_length_dipole_term_ccs_complex

      procedure :: construct_eom_densities
      procedure :: compute_eom_operator_matrix

      procedure :: construct_gs_density => construct_gs_density_ccs
      procedure :: construct_gs_density_complex => construct_gs_density_ccs_complex
      procedure :: mu_ref_density_terms => mu_ref_density_terms_ccs
      procedure :: mu_ref_density_terms_complex => mu_ref_density_terms_ccs_complex

      procedure :: construct_left_transition_density => construct_left_transition_density_ccs

      procedure :: construct_right_transition_density => construct_right_transition_density_ccs

      procedure :: construct_es_density => construct_es_density_ccs

      procedure :: construct_es_density_for_state => construct_es_density_for_state_ccs

      procedure :: construct_es_density_from_state_indices => construct_es_density_from_state_indices_ccs

      procedure :: mu_nu_density_terms => mu_nu_density_terms_ccs

      procedure :: density_ccs_ref_ref_oo => density_ccs_ref_ref_oo_ccs
      procedure :: density_ccs_ref_ref_oo_complex => density_ccs_ref_ref_oo_ccs_complex

      procedure :: density_ccs_mu_ref_vo => density_ccs_mu_ref_vo_ccs
      procedure :: density_ccs_mu_ref_vo_complex => density_ccs_mu_ref_vo_ccs_complex

      procedure :: density_ccs_ref_mu_ov => density_ccs_ref_mu_ov_ccs
      procedure :: density_ccs_mu_nu_oo => density_ccs_mu_nu_oo_ccs
      procedure :: density_ccs_mu_nu_vv => density_ccs_mu_nu_vv_ccs

      procedure :: density_mu_mu_oo => density_mu_mu_oo_ccs
      procedure :: density_mu_ref => density_mu_ref_ccs

      procedure :: get_electronic_dipole => get_electronic_dipole_ccs
      procedure :: get_electronic_quadrupole => get_electronic_quadrupole_ccs
      procedure :: get_electronic_transition_dipole => get_electronic_dipole_ccs
      procedure :: get_electronic_transition_quadrupole => get_electronic_quadrupole_ccs

      procedure :: construct_etaX => construct_etaX_ccs
      procedure :: etaX_ref => etaX_ref_ccs
      procedure :: construct_eom_etaX => construct_eom_etaX_ccs
      procedure :: construct_xiX => construct_xiX_ccs
      procedure :: xiX_ccs_a1 => xiX_ccs_a1_ccs
      procedure :: minus_xiX_tbar_transformation => minus_xiX_tbar_transformation_ccs
      procedure :: minus_xiX_tbar_transpose_transformation => minus_xiX_tbar_transpose_transformation_ccs
      procedure :: excitation_operator_transformation => excitation_operator_transformation_ccs
      procedure :: excitation_operator_transpose_transformation => &
                   excitation_operator_transpose_transformation_ccs
      procedure :: calculate_lr_transition_strength => calculate_lr_transition_strength_ccs

      procedure :: jacobianX_eom_transformation => jacobianX_eom_transformation_ccs
      procedure :: jacobianX_eom_transpose_transformation => jacobianX_eom_transpose_transformation_ccs

      procedure :: construct_molecular_gradient => construct_molecular_gradient_ccs
      procedure :: calculate_and_print_occupation_numbers => calculate_and_print_occupation_numbers_ccs

      ! Routines related to post-processing excited states

      procedure :: biorthonormalize_L_and_R => biorthonormalize_L_and_R_ccs
      procedure :: remove_parallel_states => remove_parallel_states_ccs

      ! One-electron integrals

      procedure :: t1_transform => t1_transform_ccs
      procedure :: t1_transform_complex => t1_transform_ccs_complex

      procedure :: add_t1_terms => add_t1_terms_ccs
      procedure :: add_t1_terms_complex => add_t1_terms_ccs_complex
      procedure :: add_t1_terms_and_transform => add_t1_terms_and_transform_ccs
      procedure :: add_t1_terms_and_transform_complex => add_t1_terms_and_transform_ccs_complex

      ! One-electron integrals

      procedure :: get_mo_oei => get_mo_oei_ccs
      procedure :: get_mo_oei_complex => get_mo_oei_ccs_complex

      procedure :: get_t1_oei => get_t1_oei_ccs
      procedure :: get_t1_oei_complex => get_t1_oei_ccs_complex

      procedure :: get_mo_overlap_1der => get_mo_overlap_1der_ccs
      procedure :: get_mo_h_1der => get_mo_h_1der_ccs

      ! Preparation procedures

      procedure :: prepare_for_jacobian => prepare_for_jacobian_ccs

      procedure :: prepare_for_jacobian_transpose => prepare_for_jacobian_transpose_ccs
      procedure :: prepare_for_jacobian_transpose_complex => prepare_for_jacobian_transpose_ccs_complex

      procedure :: prepare_for_jacobian_transpose_oei => prepare_for_jacobian_transpose_oei_ccs

      procedure :: prepare_for_multiplier_equation => prepare_for_multiplier_equation_ccs
      procedure :: prepare_for_multiplier_equation_complex => prepare_for_multiplier_equation_ccs_complex

      procedure :: prepare_for_properties => prepare_for_properties_ccs
      procedure :: prepare_for_properties_complex => prepare_for_properties_ccs_complex

      procedure :: approximate_double_excitation_vectors => approximate_double_excitation_vectors_ccs
      procedure :: intermediate_approximate_doubles => intermediate_approximate_doubles_ccs
      procedure :: get_reordered_intermediate_approximate_doubles => &
                   get_reordered_intermediate_approximate_doubles_ccs
      procedure :: scale_approximate_doubles => scale_approximate_doubles_ccs

      procedure :: approximate_double_excitation_vectors_triplet => &
                   approximate_double_excitation_vectors_triplet_ccs
      procedure :: approximate_double_triplet_p => approximate_double_triplet_p_ccs
      procedure :: approximate_double_triplet_m => approximate_double_triplet_m_ccs
      procedure :: get_norm_approximate_doubles_triplet => get_norm_approximate_doubles_triplet_ccs

      ! MO preparations

      procedure :: mo_preparations => mo_preparations_ccs
      procedure :: construct_MO_screening_for_cd => construct_MO_screening_for_cd_ccs

      procedure :: integral_preparations => integral_preparations_ccs
      procedure :: integral_preparations_complex => integral_preparations_ccs_complex

      ! Core-valence separation procedures

      procedure :: cvs_projection => cvs_projection_ccs
      procedure :: set_cvs_start_indices => set_cvs_start_indices_ccs

      procedure :: rm_core_projection => rm_core_projection_ccs

      ! Other procedures

      procedure :: cleanup => cleanup_ccs
      procedure :: general_cleanup
      procedure :: general_cc_preparations => general_cc_preparations_ccs

      procedure :: set_variables_from_hf => set_variables_from_hf_ccs
      procedure :: set_variables_from_cc => set_variables_from_cc_ccs
      procedure :: set_variables_from_template_wf => set_variables_from_template_wf_ccs

      procedure :: set_initial_amplitudes_guess => set_initial_amplitudes_guess_ccs
      procedure :: set_initial_multipliers_guess => set_initial_multipliers_guess_ccs
      procedure :: set_ea_start_indices => set_ea_start_indices_ccs
      procedure :: set_ip_start_indices => set_ip_start_indices_ccs
      procedure :: set_cvs_ip_start_indices => set_cvs_ip_start_indices_ccs
      procedure :: ea_projection => ea_projection_ccs
      procedure :: ip_projection => ip_projection_ccs
      procedure :: cvs_ip_projection => cvs_ip_projection_ccs

      procedure :: scale_amplitudes => scale_amplitudes_ccs

      procedure :: print_dominant_x_amplitudes_singlet => print_dominant_x_amplitudes_ccs
      procedure :: print_dominant_amplitudes => print_dominant_amplitudes_ccs
      procedure :: print_dominant_x_amplitudes_triplet => print_dominant_x_amplitudes_ccs

      procedure :: print_dominant_x1

      procedure :: is_ip => is_ip_ccs
      procedure :: is_ea => is_ea_ccs
      procedure :: make_bath_orbital => make_bath_orbital_ccs

      ! Procedures related to time dependency

      procedure :: make_complex => make_complex_ccs
      procedure :: make_ccs_complex => make_ccs_complex_ccs

      procedure :: cleanup_complex => cleanup_complex_ccs
      procedure :: cleanup_ccs_complex => cleanup_ccs_complex_ccs

      procedure, private :: complexify_cholesky_vectors

      procedure :: construct_complex_time_derivative => construct_complex_time_derivative_ccs

      procedure :: construct_complex_time_derivative_amplitudes => &
                   construct_complex_time_derivative_amplitudes_ccs
      procedure :: construct_complex_time_derivative_multipliers => &
                   construct_complex_time_derivative_multipliers_ccs

      procedure :: hartree_fock_hessian_transformation => hartree_fock_hessian_transformation_ccs
      procedure :: calculate_molecular_gradient => calculate_molecular_gradient_ccs

      procedure, public :: calculate_derivative_coupling => calculate_derivative_coupling_ccs

      ! Initialize wavefunction

      procedure :: initialize_from_hf => initialize_from_hf_ccs
      procedure :: initialize_from_cc => initialize_from_cc_ccs
      procedure :: set_parameter_dimensions => set_parameter_dimensions_ccs

      procedure :: construct_ntos => construct_ntos_ccs
      procedure :: construct_ntos_or_cntos => construct_ntos_or_cntos_ccs

      procedure :: construct_t1_cholesky => construct_t1_cholesky_ccs
      procedure :: construct_t1_cholesky_complex => construct_t1_cholesky_ccs_complex

      procedure :: construct_cholesky_t1_oo => construct_cholesky_t1_oo_ccs
      procedure :: construct_cholesky_t1_oo_complex => construct_cholesky_t1_oo_ccs_complex

      procedure :: construct_cholesky_t1_vo => construct_cholesky_t1_vo_ccs
      procedure :: construct_cholesky_t1_vo_complex => construct_cholesky_t1_vo_ccs_complex

      procedure :: construct_cholesky_t1_vv => construct_cholesky_t1_vv_ccs
      procedure :: construct_cholesky_t1_vv_complex => construct_cholesky_t1_vv_ccs_complex

      procedure, private :: integral_factory
      procedure, private :: integral_factory_complex
      procedure, private :: cholesky_factory
      procedure, private :: cholesky_factory_complex

      procedure :: prepare_for_triplet_jacobian => prepare_for_triplet_jacobian_ccs
      procedure :: triplet_jacobian_transformation => triplet_jacobian_transformation_ccs
      procedure :: triplet_jacobian_s_s_a => triplet_jacobian_s_s_a_ccs
      procedure :: triplet_jacobian_transpose_s_s_a => triplet_jacobian_transpose_s_s_a_ccs

      procedure :: prepare_for_triplet_jacobian_transpose => prepare_for_triplet_jacobian_transpose_ccs
      procedure :: triplet_jacobian_transpose_transformation => triplet_jacobian_transpose_transformation_ccs

      procedure :: get_triplet_preconditioner => get_triplet_preconditioner_ccs


      procedure :: calculate_and_print_variational_es_energies => &
                   calculate_and_print_variational_es_energies_ccs

      procedure, public :: prepare_for_molecular_gradients => prepare_for_molecular_gradients_ccs

      procedure, private :: compute_r0_from_eta => compute_r0_from_eta_ccs

      procedure, public :: finalize_for_molecular_gradients => finalize_for_molecular_gradients_ccs

      procedure :: construct_dyson_orbitals => construct_dyson_orbitals_ccs
      procedure :: construct_left_dyson_orbital_wo_t1 => construct_left_dyson_orbital_wo_t1_ccs
      procedure :: construct_right_dyson_orbital_wo_t1 => construct_right_dyson_orbital_wo_t1_ccs
      procedure :: add_t1_terms_to_right_dyson_orbital
      procedure :: add_t1_terms_to_left_dyson_orbital
      procedure :: get_dyson_orbitals_for_plotting
      procedure :: initialize_dyson_files
      procedure :: write_dyson_orbitals
      procedure :: print_dyson_coefficients

      procedure :: construct_subspace_jacobian => construct_subspace_jacobian_ccs
      procedure :: diagonalize_subspace_jacobian => diagonalize_subspace_jacobian_ccs
      procedure :: construct_and_save_subspace_hamiltonian => construct_and_save_subspace_hamiltonian_ccs

      procedure :: transform_excited_state_vectors => transform_excited_state_vectors_ccs

      procedure :: get_n_es_parameters
      procedure :: add_es_states
      procedure :: restart_from_opposite_side => restart_from_opposite_side_ccs

      procedure :: restart_es_from_other_model => restart_es_from_other_model_ccs

      procedure :: check_and_get_restart_vector => check_and_get_restart_vector_ccs

      procedure :: prepare_for_excited_states

      procedure :: L_R_overlap => L_R_overlap_ccs

      procedure :: get_es_states

   end type ccs

   interface ccs

      procedure :: new_ccs

   end interface ccs


   interface

      include "approximate_doubles_ccs_interface.F90"
      include "file_handling_ccs_interface.F90"
      include "initialize_destruct_ccs_interface.F90"
      include "set_get_ccs_interface.F90"
      include "omega_ccs_interface.F90"
      include "multiplier_equation_ccs_interface.F90"
      include "F_ccs_interface.F90"
      include "jacobian_ccs_interface.F90"
      include "jacobian_transpose_ccs_interface.F90"
      include "mean_value_ccs_interface.F90"
      include "response_ccs_interface.F90"
      include "oei_ccs_interface.F90"
      include "t1_ccs_interface.F90"
      include "fock_ccs_interface.F90"
      include "triplet_jacobian_ccs_interface.F90"
      include "triplet_jacobian_transpose_ccs_interface.F90"

      include "complex_ccs_interface.F90"

      include "generated_complex_files/fock_ccs_complex_interface.F90"
      include "generated_complex_files/initialize_destruct_ccs_complex_interface.F90"
      include "generated_complex_files/jacobian_transpose_ccs_complex_interface.F90"
      include "generated_complex_files/multiplier_equation_ccs_complex_interface.F90"
      include "generated_complex_files/omega_ccs_complex_interface.F90"
      include "generated_complex_files/set_get_ccs_complex_interface.F90"
      include "generated_complex_files/t1_ccs_complex_interface.F90"
      include "generated_complex_files/mean_value_ccs_complex_interface.F90"

   end interface

contains


   subroutine construct_es_density_from_state_indices_ccs(wf, D, m, n, reference_term)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      !! Constructs the EOM ES one-particle (transitio) density matrix between states m and n.
      !!
      !! reference_term: Choose whether to include the reference term of the right EOM state.
      !! Default: true.
      !!
      use array_initialization, only: zero_array

      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_mo, wf%n_mo), intent(out) :: D

      integer, intent(in) :: m, n

      logical, intent(in), optional :: reference_term

      real(dp), dimension(:), allocatable :: R, L
      real(dp), dimension(:, :), allocatable :: LTDM

      logical :: calculate_reference_term

      calculate_reference_term = .true.
      if (present(reference_term)) calculate_reference_term = reference_term

      call mem%alloc(L, wf%n_es_amplitudes)
      call mem%alloc(R, wf%n_es_amplitudes)

      call wf%L_es_states%read_(m, L)
      call wf%R_es_states%read_(n, R)

      call mem%alloc(LTDM, wf%n_mo, wf%n_mo, set_zero=.true.)

      if (calculate_reference_term) then

         call wf%construct_left_transition_density(LTDM, &
                                                   m, &
                                                   L, &
                                                   wf%L_es_states%get_descriptor(m))

      end if

      call zero_array(D, wf%n_mo**2)

      call wf%construct_es_density(D, &
                                   m, &
                                   L, &
                                   n, &
                                   R, &
                                   LTDM, &
                                   wf%L_es_states%get_descriptor(m), &
                                   wf%R_es_states%get_descriptor(n))

      call mem%dealloc(LTDM)

      call mem%dealloc(L)
      call mem%dealloc(R)

   end subroutine construct_es_density_from_state_indices_ccs


   function new_ccs() result(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      type(ccs) :: wf

      wf%name_ = 'ccs'
      wf%need_g_abcd = .false.

   end function new_ccs


   subroutine initialize_from_hf_ccs(wf, template_wf, embedding)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      use hf_class, only: hf
      use density_environment_class, only: density_environment

      implicit none

      class(ccs), intent(inout) :: wf

      class(hf), intent(in) :: template_wf
      type(density_environment), target, optional :: embedding

      call wf%set_variables_from_hf(template_wf, embedding)
      call wf%general_cc_preparations()
      call wf%set_parameter_dimensions()
      call wf%initialize_fock()
      call wf%print_banner()
      call wf%print_amplitude_info()

   end subroutine initialize_from_hf_ccs


   subroutine initialize_from_cc_ccs(wf, template_wf, embedding)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      use density_environment_class, only: density_environment
      implicit none

      class(ccs), intent(inout) :: wf
      class(ccs), intent(in) :: template_wf
      type(density_environment), target, optional :: embedding

      call wf%set_variables_from_cc(template_wf, embedding)
      call wf%general_cc_preparations()
      call wf%set_parameter_dimensions()
      call wf%initialize_fock()
      call wf%print_banner()
      call wf%print_amplitude_info()

   end subroutine initialize_from_cc_ccs


   subroutine set_parameter_dimensions_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      wf%n_t1 = wf%n_o * wf%n_v
      wf%n_gs_amplitudes = wf%n_t1
      wf%n_es_amplitudes = wf%n_t1
      wf%n_triplet_amplitudes = wf%n_t1

   end subroutine set_parameter_dimensions_ccs


   subroutine general_cc_preparations_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      use qed_ao_eri_getter_class, only: qed_ao_eri_getter

      implicit none

      class(ccs) :: wf

      call wf%read_settings()

      call wf%make_bath_orbital()

      if (input%is_keyword_present('cbo', 'boson')) then
         wf%ao_eri = qed_ao_eri_getter(wf%ao)
      else
         wf%ao_eri = ao_eri_getter(wf%ao)
      end if

      wf%ao_oei = ao_oei_getter(wf%ao)

      wf%L_es_states = cc_es_states_handler('left')
      wf%R_es_states = cc_es_states_handler('right')

   end subroutine general_cc_preparations_ccs


   subroutine print_banner_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad, Dec 2019
      !!
      use string_utilities, only: convert_to_uppercase

      implicit none

      class(ccs), intent(in) :: wf
      character(len=100) :: string

      string = ':: ' // trim(convert_to_uppercase(wf%name_)) // ' wavefunction'
      call output%printf('m', trim(string), fs='(//t3,a)')
      call output%print_separator('m', len_trim(string), '=')

      if (wf%n_o_bath > 0) then

         call output%printf('m', &
                            'Occupied bath orbital(s):         (i0)', &
                            ints=[wf%n_o_bath], &
                            fs='(/t6, a)')

      end if

      if (wf%n_v_bath > 0) then

         call output%printf('m', &
                            'Virtual bath orbital(s):         (i0)', &
                            ints=[wf%n_v_bath], &
                            fs='(/t6, a)')

      end if

      call output%printf('m', &
                         ' - Number of orbitals:', &
                         fs='(/t3,a)')

      call output%printf('m', &
                         'Occupied orbitals:    (i0)', &
                         ints=[wf%n_o], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Virtual orbitals:     (i0)', &
                         ints=[wf%n_v], &
                         fs='(t6,a)')

      call output%printf('m', &
                         'Molecular orbitals:   (i0)', &
                         ints=[wf%n_mo], &
                         fs='(t6,a)')

      call output%printf('m', &
                         'Atomic orbitals:      (i0)', &
                         ints=[wf%ao%n], &
                         fs='(t6,a)')

   end subroutine print_banner_ccs


   subroutine print_amplitude_info_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad, Dec 2019
      !!
      implicit none

      class(ccs), intent(in) :: wf

      call output%printf('m', ' - Number of ground state amplitudes:', fs='(/t3,a)')

      call output%printf('m', &
                         'Single excitation amplitudes:  (i0)', &
                         ints=[wf%n_t1], &
                         fs='(/t6,a)')

   end subroutine print_amplitude_info_ccs


   subroutine set_variables_from_hf_ccs(wf, template_wf, embedding)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      !! Transfers the wavefunction variables needed to start a
      !! CC calculation from either an HF of a CC wavefunction
      !!
      use hf_class, only: hf
      use density_environment_class, only: density_environment

      implicit none

      class(ccs) :: wf
      class(hf), intent(in) :: template_wf
      type(density_environment), target, optional :: embedding

      call wf%set_variables_from_template_wf(template_wf, embedding)
      wf%hf_energy = template_wf%energy

   end subroutine set_variables_from_hf_ccs


   subroutine set_variables_from_cc_ccs(wf, template_wf, embedding)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      !! Transfers the wavefunction variables needed to start a
      !! CC calculation from either an HF of a CC wavefunction
      !!
      use density_environment_class, only: density_environment
      implicit none

      class(ccs) :: wf
      class(ccs), intent(in) :: template_wf
      type(density_environment), target, optional :: embedding

      call wf%set_variables_from_template_wf(template_wf, embedding)
      wf%hf_energy = template_wf%hf_energy

   end subroutine set_variables_from_cc_ccs


   subroutine set_variables_from_template_wf_ccs(wf, template_wf, embedding)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      use density_environment_class, only: density_environment
      use wavefunction_class, only: wavefunction
      implicit none

      class(ccs) :: wf
      class(wavefunction), intent(in) :: template_wf
      type(density_environment), target, optional :: embedding

      call wf%prepare_ao_tool(template=template_wf%ao)
      call wf%prepare_embedding()

      wf%n_o = template_wf%n_o
      wf%n_v = template_wf%n_v

      if (wf%n_v == 0) then

         call output%error_msg( &
                 'Number of virtual orbitals is zero. Cannot run post-HF methods' &
              )

      end if

      wf%ao%n = template_wf%ao%n
      wf%n_mo = template_wf%n_mo

      ! Set orbital coefficients and energies

      call wf%initialize_orbital_coefficients()
      call wf%initialize_orbital_energies()

      call dcopy(wf%n_mo, template_wf%orbital_energies, 1, wf%orbital_energies, 1)
      call dcopy(wf%ao%n * wf%n_mo, template_wf%orbital_coefficients, 1, wf%orbital_coefficients, 1)

      ! Handle changes in the number of MOs as a result of special methods

      wf%embedded = .false.

      if (present(embedding)) then

         wf%embedded = .true.
         wf%frozen_density_embedding => embedding

      end if

   end subroutine set_variables_from_template_wf_ccs


   subroutine cleanup_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad and
      !! Alexander C. Paul , 2018
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      call wf%general_cleanup()

   end subroutine cleanup_ccs


   subroutine general_cleanup(wf)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad and
      !! Alexander C. Paul , 2018
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      call wf%destruct_amplitudes()
      call wf%destruct_multipliers()
      call wf%destruct_fock()
      call wf%destruct_orbital_coefficients()
      call wf%destruct_orbital_energies()
      call wf%destruct_gs_density()

      call wf%destruct_core_MOs()

      call wf%destruct_density_storer()

      call wf%ao_eri%cleanup()
      deallocate(wf%ao)

      if (allocated(wf%t_response)) call mem%dealloc(wf%t_response)

      if (allocated(wf%L_t1)) call wf%L_t1%remove_observer('eri t1')

      ! To avoid memory leaks with intel, explicit deallocations
      if (allocated(wf%eri_t1)) deallocate(wf%eri_t1)
      if (allocated(wf%L_mo)) deallocate(wf%L_mo)
      if (allocated(wf%L_t1)) deallocate(wf%L_t1)

      if (allocated(wf%cholesky)) then
         deallocate(wf%cholesky)
      end if

      call output%printf('v', &
                         '- Cleaning up ' // trim(wf%name_) // ' wavefunction', &
                         fs='(/t3,a)')

   end subroutine general_cleanup


   subroutine read_settings_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad, Aug 2019
      !!
      !! Reads the cc-section of the input file
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      wf%n_o_bath = 0
      wf%n_v_bath = 0

      if (input%is_keyword_present('electron attachment', 'solver cc es')) then
         wf%n_o_bath = 1
      end if

      if (input%is_keyword_present('ionization', 'solver cc es')) then
         wf%n_v_bath = 1
      end if

   end subroutine read_settings_ccs


   subroutine set_initial_amplitudes_guess_ccs(wf, restart)
      !!
      !! Written by Sarai D. Folkestad, Eirik F. Kjoenstad, Alexander C. Paul , 2018-2020
      !!
      use array_initialization, only: zero_array

      implicit none

      class(ccs), intent(inout) :: wf
      logical, intent(in) :: restart

      logical :: try_to_restart

      try_to_restart = restart .and. wf%t_storer%file_exists()

      if (try_to_restart) then

         call output%printf('m', &
                            'Requested restart. Reading in solution from file.', &
                            fs='(/t3,a)')

         call wf%read_amplitudes()
         call wf%construct_t1_cholesky(wf%t1, wf%L_mo, wf%L_t1)

      else

         call zero_array(wf%t1, wf%n_t1)

      end if

   end subroutine set_initial_amplitudes_guess_ccs


   subroutine set_initial_multipliers_guess_ccs(wf, restart)
      !!
      !! Written by Alexander C. Paul , Oct 2020
      !!
      use array_initialization, only: copy_and_scale

      implicit none

      class(ccs), intent(inout) :: wf

      logical, intent(in) :: restart
      logical :: try_to_restart

      try_to_restart = restart .and. wf%tbar_storer%file_exists()

      if (try_to_restart) then

         call output%printf('m', &
                            'Requested restart. Reading multipliers from file.', &
                            fs='(/t3,a)')

         call wf%read_multipliers()

      else

         call copy_and_scale(one, wf%t1, wf%t1bar, wf%n_t1)

      end if

   end subroutine set_initial_multipliers_guess_ccs


   subroutine construct_Jacobian_transform_ccs(wf, X, R, descriptor, energy)
      !!
      !! Written by Eirik F. Kjoenstad, Rolf H. Myhre, Alexander C. Paul, Dec 2018-2022
      !!
      !! Constructs R = AX or R = A^T X
      !!
      !! Wrapper for Jacobian transformations
      !!
      !! X: On input contains the vector to transform,
      !!
      !! R: On output contains the transformed vector
      !!
      use warning_suppressor, only: do_nothing
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_es_amplitudes), intent(in) :: X
      real(dp), dimension(wf%n_es_amplitudes), intent(out) :: R
      type(state_descriptor), intent(in) :: descriptor
      real(dp), intent(in) :: energy

      character(len=:), allocatable :: left_or_right

      call do_nothing(energy)

      left_or_right = descriptor%get_left_or_right()

      if (left_or_right == "right") then

         call wf%jacobian_transformation(X, R)  ! X <- AX

      else if (left_or_right == 'left') then

         call wf%jacobian_transpose_transformation(X, R)  ! X <- XA

      else

         call output%error_msg('Neither left nor right in construct_Jacobian_transform')

      end if

   end subroutine construct_Jacobian_transform_ccs


   subroutine prepare_for_excited_states(wf, descriptor)
      !!
      !! Written by Alexander C. Paul, May 2022
      !!
      !! Set number of excited states and read es settings
      !!
      use state_descriptor_class, only: state_descriptor
      implicit none

      class(ccs), intent(inout) :: wf
      type(state_descriptor), intent(in) :: descriptor

      if (descriptor%is_cvs()) call wf%read_cvs_settings()
      if (descriptor%is_core_removed()) call wf%read_rm_core_settings()

   end subroutine prepare_for_excited_states


   subroutine construct_triplet_jacobian_transform_ccs(wf, left_or_right, X, R)
      !!
      !! Written by Eirik F. Kjoenstad, Rolf H. Myhre, 2018-2019
      !!
      !! Constructs R = AX or R = A^T X
      !!
      !! Removed calculation of residual, this is now done in the solver
      !!
      !! Wrapper for Jacobian transformations
      !!
      !! left_or_right: string that should be 'left' or 'right',
      !!                determines if Jacobian or Jacobian transpose is called
      !!
      !! X: On input contains the vector to transform,
      !!
      !! R: On output contains the transformed vector
      !!
      !! w: Excitation energy. Only used for debug prints for CCS, CCSD etc.
      !!    but is passed to the effective_jacobian_transform for lowmem_CC2 and CC3
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      character(len=*), intent(in) :: left_or_right

      real(dp), dimension(wf%n_triplet_amplitudes), intent(in) :: X
      real(dp), dimension(wf%n_triplet_amplitudes), intent(out) :: R


      ! Compute the transformed matrix
      if (left_or_right == "right") then

         call wf%triplet_jacobian_transformation(X, R)  ! X <- AX

      elseif (left_or_right == 'left') then

         call wf%triplet_jacobian_transpose_transformation(X, R)  ! X <- XA

      else

         call output%error_msg('Neither left nor right in construct_Jacobian_transform')

      end if

   end subroutine construct_triplet_jacobian_transform_ccs


   subroutine prepare_for_jacobians_ccs(wf, descriptor)
      !!
      !! Written by Eirik F. Kjoenstad, Mar 2021
      !!
      !! Wrapper for preparations to left and right Jacobian transformations.
      !!
      !! left_or_right: 'left', 'right', or 'both'
      !!                (prepares for A^T, A, or both A^T and A)
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      type(state_descriptor), intent(in) :: descriptor


      if (trim(descriptor%get_spin_symmetry()) == 'singlet') then

         if (trim(descriptor%get_left_or_right()) == 'right') then

            call wf%prepare_for_jacobian()

         else if (trim(descriptor%get_left_or_right()) == 'left') then

            call wf%prepare_for_jacobian_transpose()

         else

            call output%error_msg('Could not recognize "left_or_right" in prepare_for_Jacobians_ccs.')

         end if

      else if (trim(descriptor%get_spin_symmetry()) == 'triplet') then

         if (trim(descriptor%get_left_or_right()) == 'right') then

            call wf%prepare_for_triplet_jacobian()

         else if (trim(descriptor%get_left_or_right()) == 'left') then

            call wf%prepare_for_triplet_jacobian_transpose()

         else

            call output%error_msg('Could not recognize "left_or_right" in prepare_for_Jacobians_ccs.')

         end if

      end if

   end subroutine prepare_for_Jacobians_ccs


   subroutine approximate_Jacobian_transform_ccs(wf, X, R, descriptor, energy)
      !!
      !! Written by Eirik F. Kjoenstad, Mar 2021
      !!
      !! Wrapper for a lower-level Jacobian transformation that is the best approximation
      !! with a lower computational scaling.
      !!
      use array_initialization, only: zero_array
      use warning_suppressor, only: do_nothing

      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_es_amplitudes), intent(in) :: X
      real(dp), dimension(wf%n_es_amplitudes), intent(out) :: R
      type(state_descriptor), intent(in) :: descriptor
      real(dp), intent(in) :: energy

      call output%error_msg('Approximate Jacobian transformation for (a0) has not yet been implemented.', &
                            chars=[trim(wf%name_)])

      call do_nothing(X)
      call do_nothing(descriptor)
      call do_nothing(energy)
      call zero_array(R, wf%n_t1)

   end subroutine approximate_Jacobian_transform_ccs


   subroutine prepare_for_approximate_Jacobians_ccs(wf, descriptor)
      !!
      !! Written by Eirik F. Kjoenstad, Mar 2021
      !!
      !! Wrapper for preparations to a lower-level Jacobian transformation that is
      !! the best approximation with a lower computational scaling.
      !!
      !! left_or_right: 'left', 'right', or 'both'
      !!                (prepares for A^T, A, or both A^T and A)
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(ccs), intent(inout) :: wf
      type(state_descriptor), intent(in) :: descriptor

      call output%error_msg( &
              'Approximate Jacobian transformation for this CC method  has not yet been implemented. (Error&
              & due to call to prepare  for this transformation.)' &
           )

      call do_nothing(wf)
      call do_nothing(descriptor)

   end subroutine prepare_for_approximate_Jacobians_ccs


   subroutine cvs_projection_ccs(wf, vector, n_cores, core_MOs)
      !!
      !! Written by Sarai D. Folkestad, Oct 2018
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_es_amplitudes), intent(inout) :: vector

      integer, intent(in) :: n_cores

      integer, dimension(n_cores), intent(in) :: core_MOs

      integer :: i, a, ai

      do i = 1, wf%n_o

         if (any(core_MOs == i)) cycle

         do a = 1, wf%n_v

            ai = wf%n_v * (i - 1) + a
            vector(ai) = zero

         end do
      end do

   end subroutine cvs_projection_ccs


   subroutine rm_core_projection_ccs(wf, vector, n_cores, core_MOs)
      !!
      !! Written by Sarai D. Folkestad, Oct 2018
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_es_amplitudes), intent(inout) :: vector

      integer, intent(in) :: n_cores

      integer, dimension(n_cores), intent(in) :: core_MOs

      integer :: i, a, ai, core

      !$omp parallel do private(core, i, a, ai)
      do core = 1, n_cores
         do a = 1, wf%n_v

            i = core_MOs(core)
            ai = wf%n_v * (i - 1) + a
            vector(ai) = zero

         end do
      end do
      !$omp end parallel do

   end subroutine rm_core_projection_ccs


   subroutine print_dominant_amplitudes_ccs(wf)
      !!
      !! Written by Eirik F. Kjoenstad, Dec 2018
      !!
      !! Prints the dominant amplitudes in the cluster amplitude vector.
      !!
      implicit none

      class(ccs), intent(in) :: wf

      call wf%print_dominant_x1(wf%t1, 't')

   end subroutine print_dominant_amplitudes_ccs


   subroutine print_dominant_x_amplitudes_ccs(wf, x, tag)
      !!
      !! Written by Eirik F. Kjoenstad, Dec 2018
      !!
      !! Prints the dominant amplitudes in the amplitude vector x.
      !!
      !! tag specified the printed label for the vector, e.g. tag = "t" for
      !! the cluster amplitudes.
      !!
      implicit none

      class(ccs), intent(in) :: wf

      real(dp), dimension(wf%n_gs_amplitudes), intent(in) :: x

      character(len=*) :: tag

      call wf%print_dominant_x1(x(1:wf%n_t1), tag)

   end subroutine print_dominant_x_amplitudes_ccs


   subroutine print_dominant_x1(wf, x1, tag)
      !!
      !! Written by Eirik F. Kjoenstad, Dec 2018
      !!
      !! Prints the 10 most dominant single amplitudes,
      !! or sorts them if there are fewer than ten of them.
      !!
      !! tag specified the printed label for the vector, e.g. tag = "t" for
      !! the cluster amplitudes.
      !!
      use array_utilities, only: get_n_highest
      use index_invert, only: invert_compound_index

      implicit none

      class(ccs), intent(in) :: wf

      real(dp), dimension(wf%n_t1), intent(in) :: x1
      character(len=*), intent(in) :: tag

      real(dp), dimension(:), allocatable :: abs_x1

      integer, dimension(:), allocatable :: dominant_indices
      real(dp), dimension(:), allocatable :: dominant_values

      integer :: n_elements, elm, i, a

      ! Sort according to largest contributions

      call mem%alloc(abs_x1, wf%n_t1)
      abs_x1 = abs(x1)

      n_elements = 10
      if (n_elements > wf%n_t1) n_elements = wf%n_t1

      call mem%alloc(dominant_indices, n_elements)
      call mem%alloc(dominant_values, n_elements)

      dominant_indices = 0
      dominant_values = zero
      call get_n_highest(n_elements, wf%n_t1, abs_x1, dominant_values, dominant_indices)

      ! Print largest contributions

      call output%printf('m', 'Largest single amplitudes:', fs='(/t6,a)')
      call output%print_separator('m', 35, '-', fs='(t6,a)')
      call output%printf('m', 'a       i         (a0)(a,i)', fs='(t9,a)', chars=[tag])
      call output%print_separator('m', 35, '-', fs='(t6,a)')

      do elm = 1, n_elements

         call invert_compound_index(dominant_indices(elm), a, i, wf%n_v, wf%n_o)

         call output%printf('m', &
                            '(i4)    (i3)   (f19.12)', &
                            ints=[a, i], &
                            reals=[x1(dominant_indices(elm))], &
                            fs='(t6,a)')

      end do

      call output%print_separator('m', 36, '-', fs='(t6,a)')

      call mem%dealloc(dominant_indices)
      call mem%dealloc(dominant_values)
      call mem%dealloc(abs_x1)

   end subroutine print_dominant_x1


   subroutine set_cvs_start_indices_ccs(wf, start_indices, n_states)
      !!
      !! Written by Alexander C. Paul, Aug 2023
      !!
      use array_utilities, only: quicksort_with_index_ascending

      implicit none

      class(ccs), intent(in) :: wf
      integer, intent(in) :: n_states

      integer, dimension(n_states), intent(out) :: start_indices

      real(dp), dimension(:), allocatable :: orbital_differences
      integer, dimension(:), allocatable :: indices, index_list

      integer :: i, core, a, counter, max_core_states

      max_core_states = wf%n_core_MOs * wf%n_v

      if (n_states > max_core_states) then

         call output%error_msg('The number of core excited states cannot exceed: (i0).', &
                               ints=[max_core_states])

      end if

      call mem%alloc(orbital_differences, max_core_states)
      call mem%alloc(indices, max_core_states)
      call mem%alloc(index_list, max_core_states)

      counter = 0
      do core = wf%n_core_MOs, 1, - 1
         do a = 1, wf%n_v

            counter = counter + 1

            i = wf%core_MOs(core)

            orbital_differences(counter) = wf%orbital_energies(wf%n_o + a) - wf%orbital_energies(i)
            indices(counter) = wf%n_v * (i - 1) + a

         end do
      end do

      call quicksort_with_index_ascending(orbital_differences, index_list, max_core_states)

      do i = 1, n_states
         start_indices(i) = indices(index_list(i))
      end do

      call mem%dealloc(orbital_differences)
      call mem%dealloc(indices)
      call mem%dealloc(index_list)

   end subroutine set_cvs_start_indices_ccs


   subroutine scale_amplitudes_ccs(wf, t)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Apr 2019
      !!
      !! Scales t to conform with the convention used in the wavefunction:
      !!
      !!    t1 <- t1
      !!    t2_aiai <- two * t2_aiai
      !!    ...
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(ccs), intent(in) :: wf

      real(dp), dimension(wf%n_gs_amplitudes), intent(inout) :: t

      call do_nothing(t)

   end subroutine scale_amplitudes_ccs


   pure function is_ip_ccs(wf) result(ip)
      !!
      !! Written by Marcus T. Lexander, Sarai D. Folkestad
      !!

      implicit none

      class(ccs), intent(in) :: wf

      logical :: ip

      ip = (wf%n_v_bath > 0)

   end function is_ip_ccs


   pure function is_ea_ccs(wf) result(ea)
      !!
      !! Written by Marcus T. Lexander, Sarai D. Folkestad
      !!

      implicit none

      class(ccs), intent(in) :: wf

      logical :: ea

      ea = (wf%n_o_bath > 0)

   end function is_ea_ccs


   subroutine make_bath_orbital_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad
      !!
      !! Makes bath orbital with all corresponding integrals set to zero
      !!
      !! Modified by Marcus T. Lexander and Ylva Os to allow for occupied bath orbitals, 2024
      !!
      use array_initialization, only: copy_and_scale

      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(:, :), allocatable :: orbital_coefficients_copy
      real(dp), dimension(:), allocatable :: orbital_energies_copy

      if (wf%n_o_bath == 0 .and. wf%n_v_bath == 0) return

      call mem%alloc(orbital_coefficients_copy, wf%ao%n, wf%n_mo)

      call copy_and_scale(one, wf%orbital_coefficients, orbital_coefficients_copy, wf%n_mo * wf%ao%n)

      call wf%destruct_orbital_coefficients()

      call mem%alloc(wf%orbital_coefficients, &
                     wf%ao%n, &
                     wf%n_mo + wf%n_o_bath + wf%n_v_bath, &
                     set_zero=.true.)

      call dcopy(wf%n_o * wf%ao%n, orbital_coefficients_copy, 1, wf%orbital_coefficients, 1)

      call dcopy(wf%n_v * wf%ao%n, &
                 orbital_coefficients_copy(:, wf%n_o + 1), &
                 1, &
                 wf%orbital_coefficients(:, wf%n_o + wf%n_o_bath + 1), &
                 1)

      call mem%dealloc(orbital_coefficients_copy)

      call mem%alloc(orbital_energies_copy, wf%n_mo)

      call copy_and_scale(one, wf%orbital_energies, orbital_energies_copy, wf%n_mo)

      call wf%destruct_orbital_energies()
      call mem%alloc(wf%orbital_energies, wf%n_mo + wf%n_o_bath + wf%n_v_bath, set_zero=.true.)

      call dcopy(wf%n_o, orbital_energies_copy, 1, wf%orbital_energies, 1)

      call dcopy(wf%n_v, &
                 orbital_energies_copy(wf%n_o + 1), &
                 1, &
                 wf%orbital_energies(wf%n_o + wf%n_o_bath + 1), &
                 1)

      call mem%dealloc(orbital_energies_copy)

      wf%n_mo = wf%n_mo + wf%n_o_bath + wf%n_v_bath
      wf%n_o = wf%n_o + wf%n_o_bath
      wf%n_v = wf%n_v + wf%n_v_bath

   end subroutine make_bath_orbital_ccs


   subroutine set_ea_start_indices_ccs(wf, start_indices, n_states)
      !!
      !! Written by Marcus T. Lexander, Ylva Os, 2024
      !!
      !! Sets EA start indices for trial vectors
      !! to the excitations from the bath orbital (last occupied orbital)
      !! to the lowest virtual orbitals.
      !!
      implicit none

      class(ccs), intent(in) :: wf
      integer, intent(in) :: n_states

      integer, dimension(n_states), intent(out) :: start_indices

      integer :: A

      do A = 1, n_states

         start_indices(A) = (wf%n_o - 1) * wf%n_v + A

      end do

   end subroutine set_ea_start_indices_ccs


   subroutine set_ip_start_indices_ccs(wf, start_indices, n_states)
      !!
      !! Written by Sarai D. Folkestad, Aug 2019
      !!
      !! Sets IP start indices for trial vectors
      !! from the orbital energies of the
      !! occupied. (Koopmans)
      !!
      implicit none

      class(ccs), intent(in) :: wf
      integer, intent(in) :: n_states

      integer, dimension(n_states), intent(out) :: start_indices

      integer :: I

      do I = 1, n_states

         start_indices(I) = (wf%n_o - I) * wf%n_v + wf%n_v

      end do

   end subroutine set_ip_start_indices_ccs


   subroutine set_cvs_ip_start_indices_ccs(wf, start_indices, n_states)
      !!
      !! Written by Alexander C. Paul, Feb 2021
      !!
      use array_utilities, only: quicksort_with_index_ascending

      implicit none

      class(ccs), intent(in) :: wf
      integer, intent(in) :: n_states

      integer, dimension(n_states), intent(out) :: start_indices

      real(dp), dimension(:), allocatable :: orbital_differences
      integer, dimension(:), allocatable :: indices, index_list

      integer :: i, core

      if (n_states > wf%n_core_MOs) then

         call output%error_msg( &
                 'The number of core ionized states cannot exceed the number of core orbitals.' &
              )

      end if

      call mem%alloc(orbital_differences, wf%n_core_MOs)
      call mem%alloc(indices, wf%n_core_MOs)
      call mem%alloc(index_list, wf%n_core_MOs)

      do core = 1, wf%n_core_MOs

         i = wf%core_MOs(core)

         orbital_differences(i) = wf%orbital_energies(wf%n_mo) - wf%orbital_energies(i)
         indices(i) = wf%n_v * i

      end do

      call quicksort_with_index_ascending(orbital_differences, index_list, wf%n_core_MOs)

      do i = 1, n_states
         start_indices(i) = indices(index_list(i))
      end do

      call mem%dealloc(orbital_differences)
      call mem%dealloc(indices)
      call mem%dealloc(index_list)

   end subroutine set_cvs_ip_start_indices_ccs


   subroutine ea_projection_ccs(wf, vector)
      !!
      !! Written by Marcus T. Lexander, Ylva Os, 2024
      !!
      !! Only excitations out of the last occupied orbital
      !! (the bath orbital) are allowed.
      !!
      implicit none

      class(ccs), intent(in) :: wf

      real(dp), dimension(wf%n_es_amplitudes), intent(inout) :: vector

      integer :: A, I, AI

      !$omp parallel do private(I, A, AI)
      do I = 1, wf%n_o - wf%n_o_bath
         do A = 1, wf%n_v

            AI = wf%n_v * (I - 1) + A
            vector(AI) = zero

         end do
      end do
      !$omp end parallel do

   end subroutine ea_projection_ccs


   subroutine ip_projection_ccs(wf, vector)
      !!
      !! Written by Sarai D. Folkestad, Aug 2019
      !!
      !! Only excitations into the last virtual orbital
      !! (the bath orbital) are allowed.
      !!
      implicit none

      class(ccs), intent(in) :: wf

      real(dp), dimension(wf%n_es_amplitudes), intent(inout) :: vector

      integer :: A, I, AI

      !$omp parallel do private(I, A, AI)
      do I = 1, wf%n_o
         do A = 1, wf%n_v - wf%n_v_bath

            AI = wf%n_v * (I - 1) + A
            vector(AI) = zero

         end do
      end do
      !$omp end parallel do

   end subroutine ip_projection_ccs


   subroutine cvs_ip_projection_ccs(wf, vector)
      !!
      !! Written by Alexander C. Paul, Feb 2021
      !!
      !! NB: The bath orbital is the last virtual orbital by definition
      !!
      implicit none

      class(ccs), intent(in) :: wf

      real(dp), dimension(wf%n_es_amplitudes), intent(inout) :: vector

      integer :: i, a, ai
      logical :: is_i_core_orbital, is_a_bath_orbital

      do i = 1, wf%n_o

         is_i_core_orbital = any(wf%core_MOs == i)

         do a = 1, wf%n_v

            is_a_bath_orbital = (a > wf%n_v - wf%n_v_bath)

            if (.not. (is_i_core_orbital .and. is_a_bath_orbital)) then
               ai = wf%n_v * (i - 1) + a
               vector(ai) = zero
            end if

         end do
      end do

   end subroutine cvs_ip_projection_ccs


   subroutine read_cvs_settings(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Aug 2018
      !!
      implicit none

      class(ccs) :: wf

      if (input%is_keyword_present('core index', 'solver cc es')) then

         ! Determine the number of core MOs

         wf%n_core_MOs = input%get_n_elements_for_keyword('core index', 'solver cc es')

         call wf%initialize_core_MOs()
         call input%get_array_for_keyword('core index', 'solver cc es', wf%n_core_MOs, wf%core_MOs)

      ! Ensure input compatibility within major v2
      else if (input%is_keyword_present('core excitation', 'solver cc es')) then

         wf%n_core_MOs = input%get_n_elements_for_keyword('core excitation', 'solver cc es')

         call wf%initialize_core_MOs()
         call input%get_array_for_keyword('core excitation', 'solver cc es', wf%n_core_MOs, wf%core_MOs)

      else

         call output%error_msg('found no specified core MOs in input for CVS calculation')

      end if


      if (wf%embedded) &
         call output%warning_msg( &
                 "Core excitations and frozen orbitals are requested. Make sure the remaining core orbitals&
                 & have the correct character." &
              )

   end subroutine read_cvs_settings


   subroutine read_rm_core_settings(wf)
      !!
      !! Written by Sarai D. Folkestad, 2021
      !!
      implicit none

      class(ccs) :: wf

      if (input%is_keyword_present('core index', 'solver cc es')) then

         ! Determine the number of core MOs

         wf%n_core_MOs = input%get_n_elements_for_keyword('core index', 'solver cc es')

         call wf%initialize_core_MOs()
         call input%get_array_for_keyword('core index', 'solver cc es', wf%n_core_MOs, wf%core_MOs)

      ! Ensure input compatibility within major v2
      else if (input%is_keyword_present('remove core', 'solver cc es')) then

         wf%n_core_MOs = input%get_n_elements_for_keyword('remove core', 'solver cc es')

         call wf%initialize_core_MOs()
         call input%get_array_for_keyword('remove core', 'solver cc es', wf%n_core_MOs, wf%core_MOs)

      else

         call output%error_msg('found no specified core MOs to remove!')

      end if


      if (wf%embedded) &
         call output%warning_msg( &
                 "Remove core excitations and frozen orbitals are requested. Make sure the remaining core&
                 & orbitals have the correct character." &
              )

   end subroutine read_rm_core_settings


   subroutine integral_preparations_ccs(wf, n_J)
      !!
      !! Written by Sarai D. Folkestad, Sep 2019
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      integer, intent(in) :: n_J

      call output%printf('m', '- Settings for integral handling:', fs='(/t3,a)')

      call wf%cholesky_factory(n_J)
      call wf%integral_factory()

   end subroutine integral_preparations_ccs


   subroutine cholesky_factory(wf, n_J)
      !!
      !! Written by Sarai D. Folkestad, Sep 2021
      !!
      use eri_cholesky_disk_class, only: eri_cholesky_disk
      use eri_cholesky_memory_class, only: eri_cholesky_memory

      implicit none

      class(ccs), intent(inout) :: wf

      integer, intent(in) :: n_J

      character(len=200) :: cholesky_storage

      logical :: has_room_for_cholesky
      logical :: cholesky_in_memory

      has_room_for_cholesky = 2 * n_J * wf%n_mo**2 * dp < mem%get_available() / 5

      cholesky_storage = 'memory'
      call input%get_keyword('cholesky storage', 'integrals', cholesky_storage)

      if (trim(cholesky_storage) /= 'memory' .and. trim(cholesky_storage) /= 'disk') &
         call output%error_msg('illegal value for cholesky storage: (a0)', chars=[trim(cholesky_storage)])

      cholesky_in_memory = trim(cholesky_storage) == 'memory' .and. has_room_for_cholesky

      if (cholesky_in_memory) then
         wf%L_t1 = eri_cholesky_memory()
         wf%L_mo = eri_cholesky_memory()
      else
         wf%L_t1 = eri_cholesky_disk('T1')
         wf%L_mo = eri_cholesky_disk('MO')
      end if

      call wf%L_mo%initialize(n_J, 2, [wf%n_o, wf%n_v])
      call wf%L_t1%initialize(n_J, 2, [wf%n_o, wf%n_v])

      call output%printf('m', &
                         'Cholesky vectors in memory: (l0)', &
                         logs=[cholesky_in_memory], &
                         fs='(/t6,a)')

   end subroutine cholesky_factory


   subroutine integral_factory(wf)
      !!
      !! Written by Sarai D. Folkestad, Sep 2021
      !!
      use eri_memory_tool_class, only: eri_memory_tool
      use eri_tool_class, only: eri_tool

      implicit none

      class(ccs), intent(inout) :: wf

      character(len=200) :: integral_storage

      logical :: has_room_for_eri

      logical :: try_to_place_eri_in_memory, eri_in_memory

      integral_storage = 'memory'
      call input%get_keyword('eri storage', 'integrals', integral_storage)

      if (trim(integral_storage) /= 'memory' .and. trim(integral_storage) /= 'none') &
         call output%error_msg('illegal value for eri storage: (a0)', chars=[trim(integral_storage)])

      try_to_place_eri_in_memory = (integral_storage == 'memory' .and. wf%need_g_abcd)

      has_room_for_eri = wf%n_mo**4 * dp < mem%get_available() / 5

      eri_in_memory = try_to_place_eri_in_memory .and. has_room_for_eri

      if (eri_in_memory) then
         wf%eri_t1 = eri_adapter(eri_memory_tool(wf%L_t1), wf%n_o, wf%n_v)
      else
         wf%eri_t1 = eri_adapter(eri_tool(wf%L_t1), wf%n_o, wf%n_v)
      end if

      call wf%L_t1%add_observer('eri t1', wf%eri_t1%eri)

      call output%printf('m', &
                         'ERI matrix in memory:       (l0)', &
                         logs=[eri_in_memory], &
                         fs='(t6,a)')

   end subroutine integral_factory


   subroutine mo_preparations_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad, Sep 2019
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(ccs), intent(inout) :: wf

      call do_nothing(wf)

   end subroutine mo_preparations_ccs


   subroutine biorthonormalize_L_and_R_ccs(wf, energy_threshold, residual_threshold)
      !!
      !! Written by Alexander C. Paul, Bendik Stoea Sannes, Jacob Pedersen,
      !! , and Sarai D. Folkestad, 2019-2024
      !!
      !! For that:
      !!    - check if left and right excitation energies are consistent
      !!    - check for degenerate states
      !!    - check for and discard parallel states
      !!    - If degeneracies are present: biorthonormalize using Gram-Schmidt
      !!      following Kohaupt, L., Rocky Mountain J. Math., 44, 1265, (2014)
      !!    - Normalize and write to file
      !!
      use array_utilities, only: gram_schmidt_biorthonormalization, get_equal_to_threshold
      use array_initialization, only: set_logicals
      use state_descriptor_class, only: state_descriptor

      implicit none

      class(ccs) :: wf

      real(dp), intent(in) :: energy_threshold, residual_threshold

      real(dp), dimension(:, :), allocatable :: R, L

      logical, dimension(:), allocatable :: degenerate, degenerate_L, degenerate_R, biorthonormalized

      real(dp) :: LT_R

      integer, dimension(:), allocatable :: degenerate_states

      integer :: state, current_state, counter
      integer :: n_degeneracy, n_degeneracy_L, n_degeneracy_R

      type(timings) :: timer

      real(dp), dimension(:), allocatable :: energy_L, energy_R

      integer :: n_states, n_amplitudes

      type(state_descriptor), allocatable :: descriptor

      timer = timings('Biorthonormalization of left and right states', pl='n')
      call timer%turn_on()

      call output%printf('v', &
                         'Biorthonormalization of left and right excited state vectors', &
                         fs='(/t3,a)')

      n_states = wf%L_es_states%n_total

      call mem%alloc(energy_L, n_states)
      call mem%alloc(energy_R, n_states)

      call wf%L_es_states%read_energies(energy_L)
      call wf%R_es_states%read_energies(energy_R)

      ! Prepare logicals to keep track of which states have already been
      ! biorthonormalized and which states are degenerate to the current_state

      call mem%alloc(biorthonormalized, n_states, set_to=.false.)

      call mem%alloc(degenerate, n_states)
      call mem%alloc(degenerate_L, n_states)
      call mem%alloc(degenerate_R, n_states)

      ! Loop through states look for degeneracies and
      ! biorthonormalize degenerate states

      do current_state = 1, n_states

         n_amplitudes = wf%L_es_states%get_n_amplitudes(current_state)
         descriptor = wf%L_es_states%get_descriptor(current_state)

         ! Keep track of which states have already been biorthonormalized
         if (biorthonormalized(current_state)) cycle

         ! Reset array indicating degenerate states
         call set_logicals(degenerate, n_states, .false.)

         if (abs(energy_L(current_state) - energy_R(current_state)) > 2 * energy_threshold) then

            ! Roots might be ordered incorrectly, or diffferent roots were found for left and right

            call output%warning_msg('Eigenvector (i0) is not left-right consistent to threshold (e9.3).', &
                                    ints=[current_state], &
                                    reals=[2 * energy_threshold], &
                                    fs='(/t6,a)')

            call output%printf('m', &
                               'Energies (left, right): (f19.12) (f19.12)', &
                               reals=[energy_L(current_state), energy_R(current_state)], &
                               fs='(t12,a)')

            call output%printf('m', &
                               'Biorthonormalization might lead to an error', &
                               fs='(t12,a)')

         end if

         ! Check for degeneracies in both left and right excitation energies
         degenerate_L = get_equal_to_threshold(energy_L, n_states, current_state, 2 * energy_threshold)
         degenerate_R = get_equal_to_threshold(energy_R, n_states, current_state, 2 * energy_threshold)

         ! In case of different degree of degeneracy between left and right,
         ! continue with the highest degree of degeneracy

         n_degeneracy_L = count(degenerate_L)
         n_degeneracy_R = count(degenerate_R)

         n_degeneracy = max(n_degeneracy_L, n_degeneracy_R)

         degenerate = (degenerate_L .or. degenerate_R)


         if (n_degeneracy_L /= n_degeneracy_R) then

            call output%warning_msg( &
                    'Different degree of degeneracy in the left excited states compared to the right excited&
                    & state' &
                 )

         end if

         call output%printf('v', &
                            'Degree of degeneracy: (i0)', &
                            ints=[n_degeneracy], &
                            fs='(/t6,a)')

         ! Read in degenerate states L/R
         ! States 1 to current_state have already been biorthonormalized

         call mem%alloc(R, n_amplitudes, n_degeneracy)
         call mem%alloc(L, n_amplitudes, n_degeneracy)

         call mem%alloc(degenerate_states, n_degeneracy)

         counter = 0

         do state = 1, n_states

            if (.not. degenerate(state)) cycle

            counter = counter + 1

            ! save state number of the degenerate states
            degenerate_states(counter) = state

            ! This state won't be biorthonormalized again
            biorthonormalized(state) = .true.

            call wf%L_es_states%read_(state, L(:, counter))
            call wf%R_es_states%read_(state, R(:, counter))

         end do

         if (n_degeneracy > 1) then

            call output%printf('n', 'Found states that are close in energy:', fs='(/t6,a)')
            call output%print_separator('n', 38, '-', fs='(t6,a)')
            call output%printf('n', 'State     Excitation Energy', fs='(t6,a)')

            do state = 1, n_degeneracy

               call output%printf('n', &
                                  ' (i2)     (f19.12)', &
                                  ints=[degenerate_states(state)], &
                                  reals=[energy_R(degenerate_states(state))], &
                                  fs='(t6,a)')

            end do

         end if

         ! :: Biorthonormalize states ::
         ! -----------------------------

         call gram_schmidt_biorthonormalization(L, &
                                                R, &
                                                n_amplitudes, &
                                                n_degeneracy, &
                                                residual_threshold)

         ! We binormalize again to include the doubles/triples contributions
         ! in low-memory CC2 and CC3.

         do state = 1, n_degeneracy


            LT_R = wf%L_R_overlap(L(:, state), &
                                  R(:, state), &
                                  descriptor, &
                                  energy_L(current_state))

            call dscal(n_amplitudes, one / LT_R, L(:, state), 1)

         end do

         counter = 0

         do state = 1, n_states

            ! Only save the states that we currently consider
            if (.not. degenerate(state)) cycle

            counter = counter + 1

            call wf%L_es_states%save_(state, L(:, counter))
            call wf%R_es_states%save_(state, R(:, counter))

         end do

         call mem%dealloc(degenerate_states)
         call mem%dealloc(R)
         call mem%dealloc(L)

      end do

      call mem%dealloc(biorthonormalized)

      call wf%L_es_states%read_energies(energy_L)
      call wf%R_es_states%read_energies(energy_R)

      call mem%dealloc(degenerate)
      call mem%dealloc(degenerate_L)
      call mem%dealloc(degenerate_R)
      call mem%dealloc(energy_L)
      call mem%dealloc(energy_R)

      call timer%turn_off()

   end subroutine biorthonormalize_L_and_R_ccs


   subroutine print_gs_summary_ccs(wf)
      !!
      !! Written by Eirik F. Kjoenstad, Dec 2018
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      call output%printf('m', '- Ground state summary:', fs='(/t3,a)')

      call output%printf('m', &
                         'Final ground state energy (a.u.): (f18.12)', &
                         reals=[wf%energy], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Correlation energy (a.u.):        (f18.12)', &
                         reals=[wf%correlation_energy], &
                         fs='(/t6,a)')

      call wf%print_dominant_amplitudes()

   end subroutine print_gs_summary_ccs


   subroutine print_es_summary_ccs(wf, descriptor)
      !!
      !! Written by Sarai Dery Folkestad, Oct 2022
      !!
      use string_utilities, only: convert_to_uppercase
      use state_descriptor_class, only: state_descriptor

      implicit none

      class(ccs), intent(inout), target :: wf
      type(state_descriptor), intent(in) :: descriptor

      integer :: n_states, n_amplitudes

      character(len=50) :: left_or_right
      character(len=1) :: left_or_right_character

      integer :: I

      real(dp), dimension(:, :), allocatable :: X
      real(dp), dimension(:), allocatable :: energies

      type(cc_es_states_handler), allocatable :: es_handler

      call output%printf('m', '- Summary for excited state calculation:', fs='(/t3,a)')

      call output%printf('m', &
                         'Excited state type:   (a0)', &
                         chars=[trim(descriptor%get_es_type())], &
                         fs='(/t6,a)')

      call output%printf('m', &
                         'Spin symmetry:        (a0)', &
                         chars=[trim(descriptor%get_spin_symmetry())], &
                         fs='(t6,a)')

      left_or_right = trim(descriptor%get_left_or_right())
      left_or_right_character = trim(convert_to_uppercase(left_or_right(1:1)))

      es_handler = wf%get_es_states(descriptor)

      n_states = es_handler%n_total
      n_amplitudes = wf%get_n_es_parameters(descriptor)

      call mem%alloc(X, n_amplitudes, n_states)
      call mem%alloc(energies, n_states)

      do I = 1, n_states
         call es_handler%read_(I, X(:, I), energies(I))
      end do

      call output%printf('n', '- Excitation vector amplitudes:', fs='(/t3,a)')

      do I = 1, n_states

         call output%printf('n', 'Electronic state nr. (i0)', ints=[I], fs='(/t6,a)')

         call output%printf('n', &
                            'Energy (Hartree):             (f19.12)', &
                            reals=[energies(I)], &
                            fs='(/t6,a)')

         call wf%print_singles_diagnostics(X(:, I), n_amplitudes, left_or_right_character)

         if (trim(descriptor%get_spin_symmetry()) == 'singlet') then

            call wf%print_dominant_x_amplitudes_singlet(X(:, I), left_or_right_character)

         elseif (trim(descriptor%get_spin_symmetry()) == 'triplet') then

            call wf%print_dominant_x_amplitudes_triplet(X(:, I), left_or_right_character)

         end if

      end do

      call output%printf('m', &
                         '- ' // trim(convert_to_uppercase(wf%name_)) // ' excitation energies:', &
                         fs='(/t3,a)')

      call output%printf('m', 'Excitation energy', fs='(/t39,a)')
      call output%print_separator('m', 42, '-', fs='(t27,a)')
      call output%printf('m', ' State                (Hartree)             (eV)', fs='(t6,a)')
      call output%print_separator('m', 63, '-', fs='(t6,a)')

      do I = 1, n_states

         call output%printf('m', &
                            '(i4)             (f19.12)   (f19.12)', &
                            ints=[I], &
                            reals=[energies(I), energies(I) * Hartree_to_eV], &
                            fs='(t6,a)')

      end do

      call output%print_separator('m', 63, '-', fs='(t6,a)')

      call output%printf('m', &
                         'eV/Hartree (CODATA 2014): (f11.8)', &
                         reals=[Hartree_to_eV], &
                         fs='(t6,a)')


      call mem%dealloc(X)
      call mem%dealloc(energies)

   end subroutine print_es_summary_ccs


   subroutine calculate_and_print_variational_es_energies_ccs(wf)
      !!
      !! Written by Marcus T. Lexander, 2025
      !!
      use string_utilities, only: convert_to_uppercase

      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(:), allocatable :: L, R, rho

      real(dp) :: energy

      integer :: state, n_states, n_amplitudes

      real(dp), external :: ddot

      type(state_descriptor), allocatable :: descriptor

      call output%printf('m', '- Computing excitation energies using left and right vectors', fs='(/t3,a)')
      call output%printf('m', '(E = L^T A R):')

      call output%printf('m', &
                         '- ' // trim(convert_to_uppercase(wf%name_)) // ' excitation energies:', &
                         fs='(/t3,a)')

      call output%printf('m', 'Excitation energy', fs='(/t39,a)')
      call output%print_separator('m', 42, '-', fs='(t27,a)')
      call output%printf('m', ' State                (Hartree)             (eV)', fs='(t6,a)')
      call output%print_separator('m', 63, '-', fs='(t6,a)')

      n_states = wf%R_es_states%n_total
      do state = 1, n_states

         descriptor = wf%R_es_states%get_descriptor(state)
         n_amplitudes = wf%get_n_es_parameters(descriptor)

         call mem%alloc(L, n_amplitudes)
         call mem%alloc(R, n_amplitudes)
         call mem%alloc(rho, n_amplitudes)

         call wf%L_es_states%read_(state, L)
         call wf%R_es_states%read_(state, R)

         call wf%jacobian_transformation(R, rho)

         energy = ddot(n_amplitudes, L, 1, rho, 1)

         call output%printf('m', &
                            '(i4)             (f19.12)   (f19.12)', &
                            ints=[state], &
                            reals=[energy, energy * Hartree_to_eV], &
                            fs='(t6,a)')

         call mem%dealloc(L)
         call mem%dealloc(R)
         call mem%dealloc(rho)
      end do

      call output%print_separator('m', 63, '-', fs='(t6,a)')

      call output%printf('m', &
                         'eV/Hartree (CODATA 2014): (f11.8)', &
                         reals=[Hartree_to_eV], &
                         fs='(t6,a)')

   end subroutine calculate_and_print_variational_es_energies_ccs


   subroutine print_singles_diagnostics_ccs(wf, X, n_amplitudes, label)
      !!
      !! Written by Eirik F. Kjoenstad, Dec 2018
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(ccs), intent(in) :: wf

      character(len=1), intent(in) :: label
      integer, intent(in) :: n_amplitudes

      real(dp), dimension(n_amplitudes), intent(in) :: X

      real(dp) :: get_X1_diagnostics

      get_X1_diagnostics = get_l2_norm(X(1:wf%n_t1), wf%n_t1) / get_l2_norm(X(1:n_amplitudes), n_amplitudes)

      call output%printf('n', &
                         'Fraction singles (|(a0)1|/|(a0)|):  (f19.12)', &
                         reals=[get_X1_diagnostics], &
                         chars=[label, label], &
                         fs='(t6,a)')

   end subroutine print_singles_diagnostics_ccs


   subroutine construct_MO_screening_for_cd_ccs(wf, screening_vector)
      !!
      !! Written by Sarai D. Folkestad, Feb 2020
      !!
      !! Constructs the screening vector
      !!
      !!    v_x = max_p(C_xp^2)
      !!
      !!    screening_vector(x,y) = v_x * v_y
      !!
      !! which is used to target accuracy in MO integrals
      !! rather than the AO integrals in the decomposition
      !! of the ERIs
      !!
      !! See J. Chem. Phys. 150, 194112 (2019) for further
      !! details
      !!
      use array_initialization, only: zero_array

      implicit none

      class(ccs), intent(in) :: wf
      real(dp), dimension(wf%ao%n, wf%ao%n), intent(out) :: screening_vector

      integer :: x, p, y

      real(dp), dimension(:), allocatable :: v

      call mem%alloc(v, wf%ao%n)
      call zero_array(v, wf%ao%n)

      !$omp parallel do private(x, p)
      do x = 1, wf%ao%n
         do p = 1, wf%n_mo

            if (wf%orbital_coefficients(x, p)**2 > v(x)) v(x) = wf%orbital_coefficients(x, p)**2

         end do

      end do
      !$omp end parallel do

      !$omp parallel do private(x, y)
      do x = 1, wf%ao%n
         do y = 1, wf%ao%n

            screening_vector(x, y) = v(x) * v(y)

         end do
      end do
      !$omp end parallel do

      call mem%dealloc(v)

   end subroutine construct_MO_screening_for_cd_ccs


   subroutine construct_ntos_ccs(wf, ntos, k, n_sig_v, n_sig_o, handler, threshold)
      !!
      !! Written by Sarai D. Folkestad, May 2020
      !!
      !! 'ntos' : array to store NTO orbital coefficients
      !!
      !! 'k' : which excited state to construct NTOs for
      !!
      !! 'n_sig_v' and 'n_sig_o' : The number of significant occupied and virtuals
      !!
      !! 'left_or_right' : excited state vector type
      !!
      !!  Constructs the M and N matrices
      !!
      !!    M_ij += sum_a R_ai R_aj
      !!    N_ab += sum_i R_ai R_bi
      !!
      !! and diagonalizes them.
      !! The NTOs are then constructed and stored in 'ntos'
      !!
      !! This constitutes a singular value decomposition
      !! of the excitation vectors.
      !!
      !!    N = RR^T = V D1 V^T
      !!    M = R^TR = U D2 U^T
      !!
      !! If a threshold is given, the significant occupied and virtual
      !! orbitals (n_o and n_v)
      !! are determined by considering the
      !! eigenvalues of M and N, using the criterion
      !!
      !!    1 - sum_i e_i < threshold,
      !!
      !! where the eigenvalues are ordered from largest to smallest.
      ! Otherwise n_sig_o = n_sig_v = 1.

      use nto_tool_class, only: nto_tool

      implicit none

      class(ccs) :: wf

      real(dp), dimension(wf%ao%n, wf%n_mo), intent(out) :: ntos
      type(cc_es_states_handler), intent(inout) :: handler

      real(dp), intent(in) :: threshold

      integer, intent(in) :: k
      integer, intent(out) :: n_sig_v, n_sig_o

      type(nto_tool), allocatable :: orbital_tool
      integer :: n_amplitudes
      real(dp), dimension(:), allocatable :: X

      call output%printf('n', &
                         '- Constructing NTOs for state (i0)', &
                         ints=[k], &
                         ffs='(/t3,a)')

      n_amplitudes = wf%get_n_es_parameters(handler%get_descriptor(k))
      call mem%alloc(X, n_amplitudes)

      call handler%read_(k, X)

      orbital_tool = nto_tool(wf%n_o, wf%n_v, wf%ao%n, wf%n_t1)

      call orbital_tool%initialize()

      call orbital_tool%add_excited_state(X(1:wf%n_t1))

      call orbital_tool%transform_orbitals(wf%orbital_coefficients, ntos)

      call orbital_tool%get_n_active_orbitals(n_sig_o, n_sig_v, threshold)

      call orbital_tool%cleanup

      call mem%dealloc(X)

   end subroutine construct_ntos_ccs


   subroutine construct_ntos_or_cntos_ccs(wf, &
                                          orbitals, &
                                          k, &
                                          n_sig_v, &
                                          n_sig_o, &
                                          handler, &
                                          type_, &
                                          threshold)
      !!
      !! Written by Sarai D. Folkestad, May 2020
      !!
      !! Wrapper to construct either NTOs or CNTOs
      !!
      !! orbitals : NTOs/CNTOs
      !!
      !! n_sig_o, n_sig_v : number of occupied and virtual NTOs/CNTOs
      !!
      !! left_or_right : use left or right excitation vectors
      !!
      !! type_ : 'ntos' or 'cntos'
      !!
      !! threshold : threshold to determine n_sig_o and n_sig_v
      !!
      implicit none

      class(ccs) :: wf

      real(dp), dimension(wf%ao%n, wf%n_mo), intent(out) :: orbitals

      real(dp), intent(in) :: threshold

      integer, intent(in) :: k
      integer, intent(out) :: n_sig_v, n_sig_o
      type(cc_es_states_handler), intent(inout) :: handler
      character(len=*), intent(in) :: type_

      if (trim(type_) == 'nto') then

         call wf%construct_ntos(orbitals, k, n_sig_v, n_sig_o, handler, threshold)

      else if (trim(type_) == 'cnto') then

         call output%error_msg('Cannot plot CNTOs for ' // trim(wf%name_))

      end if

   end subroutine construct_ntos_or_cntos_ccs


   subroutine cholesky_factory_complex(wf, n_J)
      !!
      !! Written by Sarai D. Folkestad, Sep 2021
      !!
      !  NOTE:
      !  This routine is placed here for gcc-8 compatibility,
      !  should be moved to complex_ccs submodule when gcc-8 is no longer supported.

      implicit none

      class(ccs), intent(inout) :: wf

      integer, intent(in) :: n_J

      character(len=200) :: cholesky_storage

      logical :: has_room_for_cholesky
      logical :: cholesky_in_memory

      has_room_for_cholesky = 2 * n_J * wf%n_mo**2 * (2 * dp) < mem%get_available() / 5

      cholesky_storage = 'memory'
      call input%get_keyword('cholesky storage', 'integrals', cholesky_storage)

      if (trim(cholesky_storage) /= 'memory' .and. trim(cholesky_storage) /= 'disk') &
         call output%error_msg('illegal value for cholesky storage')

      cholesky_in_memory = trim(cholesky_storage) == 'memory' .and. has_room_for_cholesky

      if (cholesky_in_memory) then
         wf%L_t1_c = eri_cholesky_memory_c()
         wf%L_mo_c = eri_cholesky_memory_c()
      else
         wf%L_t1_c = eri_cholesky_disk_c('T1_complex')
         wf%L_mo_c = eri_cholesky_disk_c('MO_complex')
      end if

      call wf%L_mo_c%initialize(n_J, 2, [wf%n_o, wf%n_v])
      call wf%L_t1_c%initialize(n_J, 2, [wf%n_o, wf%n_v])

      call output%printf('m', &
                         'Cholesky vectors in memory: (l0)', &
                         logs=[cholesky_in_memory], &
                         fs='(/t6,a)')

   end subroutine cholesky_factory_complex


   subroutine prepare_for_molecular_gradients_ccs(wf)
      !!
      !! Written by Eirik F. Kjoenstad and Anna-Kristina Schnack-Petersen, 2020
      !!
      use ao_eri_1der_getter_class, only: ao_eri_1der_getter
      implicit none

      class(ccs) :: wf

      wf%gradient_densities = cc_gradient_densities(wf%n_o, wf%n_v, wf%eri_t1%n_J)
      call wf%gradient_densities%initialize()

      call wf%compute_r0_from_eta()

      wf%ao_eri_1der = ao_eri_1der_getter(wf%ao)

   end subroutine prepare_for_molecular_gradients_ccs


   subroutine compute_r0_from_eta_ccs(wf)
      !!
      !! Written by Eirik F. Kjoenstad, 2024
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(:), allocatable :: eta, R

      integer :: k

      real(dp) :: energy_R, ddot

      call mem%alloc(eta, wf%n_es_amplitudes)
      call wf%construct_eta(eta)

      call mem%alloc(R, wf%n_es_amplitudes)

      do k = 1, wf%R_es_states%n_total

         call wf%R_es_states%read_(k, R, energy_R)
         wf%r0(k) = ddot(wf%n_es_amplitudes, eta, 1, R, 1) / energy_R

      end do

      call mem%dealloc(eta)
      call mem%dealloc(R)

   end subroutine compute_r0_from_eta_ccs


   subroutine finalize_for_molecular_gradients_ccs(wf)
      !!
      !! Written by Eirik F. Kjoenstad and Anna-Kristina Schnack-Petersen, 2020
      !!
      implicit none

      class(ccs) :: wf

      call wf%destruct_density_intermediates()
      call wf%destruct_gs_density()

      deallocate(wf%gradient_densities)

      call wf%ao_eri_1der%cleanup()

   end subroutine finalize_for_molecular_gradients_ccs


   subroutine construct_molecular_gradient_ccs(wf, E_qk)
      !!
      !! Written by Marcus T. Lexander, 2023
      !!
      implicit none

      class(ccs), intent(inout) :: wf
      real(dp), dimension(3, wf%n_atomic_centers), intent(out) :: E_qk

      call wf%prepare_for_molecular_gradients()

      call wf%calculate_molecular_gradient(E_qk, state=0)

      call wf%finalize_for_molecular_gradients()

   end subroutine construct_molecular_gradient_ccs


   subroutine get_triplet_preconditioner_ccs(wf, preconditioner)
      !!
      !! Written by Sarai D. Folkestad, 2022
      !!
      implicit none

      class(ccs), intent(in) :: wf
      real(dp), dimension(wf%n_triplet_amplitudes), intent(inout) :: preconditioner

      call wf%get_orbital_differences(preconditioner, wf%n_t1)

   end subroutine get_triplet_preconditioner_ccs


   subroutine hartree_fock_hessian_transformation_ccs(wf, kappa_vo, sigma_vo)
      !!
      !! Written by Anna Kristina Schnack-Petersen and Eirik F. Kjoenstad,Feb 2021
      !!
      !! Routine to construct sigma_pq = sum_rs A_pqrs*kappa_rs (only for vo block)
      !!                               = 2*(e_p-e_q)kappa_pq
      !!                                + sum_rs 8*g_pqrs*kappa_rs - 2*g_prqs*kappa_rs
      !!                                - 2*g_psqr*kappa_rs
      !!
      !! For vo block:
      !!              sigma_ai = 2*(e_a-e_i)kappa_ai
      !!                        + sum_bj(8*g_aibj-2*g_abij -2*g_ajib)kappa_bj
      !!
      !!
      use array_initialization, only: zero_array
      use reordering_r, only: sort_to_213, sort_to_132

      implicit none

      class(ccs) :: wf

      real(dp), dimension(wf%n_v, wf%n_o), intent(in) :: kappa_vo
      real(dp), dimension(wf%n_v, wf%n_o), intent(out) :: sigma_vo

      real(dp), dimension(:), allocatable :: Lkappa_J
      real(dp), dimension(:, :, :), allocatable :: Lkappa_J_aj, Lkappa_aJj
      real(dp), dimension(:, :, :), allocatable :: L_Jji, Lkappa_Jij
      integer :: a, i

      real(dp), dimension(:, :, :), pointer :: L_J_oo
      real(dp), dimension(:, :, :), pointer :: L_J_ov
      real(dp), dimension(:, :, :), pointer :: L_J_vo
      real(dp), dimension(:, :, :), pointer :: L_J_vv

      call zero_array(sigma_vo, wf%n_v * wf%n_o)

      call wf%L_mo%load_block(L_J_vv, wf%n_o + 1, wf%n_mo, wf%n_o + 1, wf%n_mo)
      call wf%L_mo%load_block(L_J_vo, wf%n_o + 1, wf%n_mo, 1, wf%n_o)
      call wf%L_mo%load_block(L_J_oo, 1, wf%n_o, 1, wf%n_o)
      call wf%L_mo%load_block(L_J_ov, 1, wf%n_o, wf%n_o + 1, wf%n_mo)

      !$omp parallel do private(i,a)
      do i = 1, wf%n_o
         do a = 1, wf%n_v

            sigma_vo(a, i) = 2 * (wf%orbital_energies(wf%n_o + a) - wf%orbital_energies(i)) * kappa_vo(a, i)

         end do
      end do
      !$omp end parallel do

      ! Get second term g_aibj = L_J_ai*L_J_bj*kappa_bj

      ! Get L_J_bj*kappa_bj = Lkappa_J

      call mem%alloc(Lkappa_J, wf%eri_t1%n_J)

      call dgemm('N', &
                 'N', &
                 wf%eri_t1%n_J, &
                 1, &
                 wf%n_v * wf%n_o, &
                 eight, &
                 L_J_vo, &
                 wf%eri_t1%n_J, &
                 kappa_vo, &
                 wf%n_v * wf%n_o, &
                 zero, &
                 Lkappa_J, &
                 wf%eri_t1%n_J)

      ! Get Lkappa_J*L_J_ai = sigma_ai

      call dgemm('N', &
                 'N', &
                 1, &
                 wf%n_v * wf%n_o, &
                 wf%eri_t1%n_J, &
                 one, &
                 Lkappa_J, &
                 1, &
                 L_J_vo, &
                 wf%eri_t1%n_J, &
                 one, &
                 sigma_vo, &
                 1)

      call mem%dealloc(Lkappa_J)

      ! Add third term g_abij*kappa_bj=L_J_ab*L_J_ij*kappa_bj

      ! Get L_J_ab*kappa_bj = Lkappa_J_aj

      call mem%alloc(Lkappa_J_aj, wf%eri_t1%n_J, wf%n_v, wf%n_o)

      call dgemm('N', &
                 'N', &
                 wf%eri_t1%n_J * wf%n_v, &
                 wf%n_o, &
                 wf%n_v, &
                 - two, &
                 L_J_vv, &
                 wf%eri_t1%n_J * wf%n_v, &
                 kappa_vo, &
                 wf%n_v, &
                 zero, &
                 Lkappa_J_aj, &
                 wf%eri_t1%n_J * wf%n_v)

      ! Resort Lkappa_J_aj to Lkappa_a_Jj and L_J_ij to L_J_ji

      call mem%alloc(Lkappa_aJj, wf%n_v, wf%eri_t1%n_J, wf%n_o)
      call sort_to_213(Lkappa_J_aj, Lkappa_aJj, wf%eri_t1%n_J, wf%n_v, wf%n_o)
      call mem%dealloc(Lkappa_J_aj)

      call mem%alloc(L_Jji, wf%eri_t1%n_J, wf%n_o, wf%n_o)
      call sort_to_132(L_J_oo, L_Jji, wf%eri_t1%n_J, wf%n_o, wf%n_o)

      ! Get Lkappa_a_Jj*L_Jj_i = sigma_ai

      call dgemm('N', &
                 'N', &
                 wf%n_v, &
                 wf%n_o, &
                 wf%eri_t1%n_J * wf%n_o, &
                 one, &
                 Lkappa_aJj, &
                 wf%n_v, &
                 L_Jji, &
                 wf%eri_t1%n_J * wf%n_o, &
                 one, &
                 sigma_vo, &
                 wf%n_v)

      ! Add fourth term g_ajib*kappa_bj=L_J_aj*L_J_ib*kappa_bj

      ! Get L_J_ib*kappa_bj=Lkappa_J_ij

      call mem%alloc(Lkappa_Jij, wf%eri_t1%n_J, wf%n_o, wf%n_o)

      call dgemm('N', &
                 'N', &
                 wf%eri_t1%n_J * wf%n_o, &
                 wf%n_o, &
                 wf%n_v, &
                 - two, &
                 L_J_ov, &
                 wf%eri_t1%n_J * wf%n_o, &
                 kappa_vo, &
                 wf%n_v, &
                 zero, &
                 Lkappa_Jij, &
                 wf%eri_t1%n_J * wf%n_o)

      ! Reorder Lkappa_Jij to Lkappa_Jji (saved in L_Jji) and L_J_aj to L_aJj (in
      ! Lkappa_aJj)

      call sort_to_132(Lkappa_Jij, L_Jji, wf%eri_t1%n_J, wf%n_o, wf%n_o)

      call mem%dealloc(Lkappa_Jij)

      call sort_to_213(L_J_vo, Lkappa_aJj, wf%eri_t1%n_J, wf%n_v, wf%n_o)

      ! Get L_aJj*Lkappa_Jji = sigma_ai

      call dgemm('N', &
                 'N', &
                 wf%n_v, &
                 wf%n_o, &
                 wf%eri_t1%n_J * wf%n_o, &
                 one, &
                 Lkappa_aJj, &  ! L_aJj saved here
                 wf%n_v, &
                 L_Jji, &  ! Lkappa_Jji saved here
                 wf%eri_t1%n_J * wf%n_o, &
                 one, &
                 sigma_vo, &
                 wf%n_v)

      call mem%dealloc(Lkappa_aJj)
      call mem%dealloc(L_Jji)

      call wf%L_mo%offload_block(wf%n_o + 1, wf%n_mo, wf%n_o + 1, wf%n_mo)
      call wf%L_mo%offload_block(wf%n_o + 1, wf%n_mo, 1, wf%n_o)
      call wf%L_mo%offload_block(1, wf%n_o, 1, wf%n_o)
      call wf%L_mo%offload_block(1, wf%n_o, wf%n_o + 1, wf%n_mo)

   end subroutine hartree_fock_hessian_transformation_ccs


   subroutine construct_subspace_jacobian_ccs(wf, A, S, n_states)
      !!
      !! Written by Alexander C. Paul and Andreas S. Skeidsvoll, Sep 2020
      !!
      !! Computes the EOM Jacobian elements in the basis of EOM states
      !!
      !!    A_m,n = sum_mu,nu L_m,mu A_mu,nu R_nu,n
      !!
      !!  and the corresponding overlap matrix
      !!
      !!    S_m,n = < L_m | R_n >.
      !!
      use state_descriptor_class, only: state_descriptor

      implicit none

      class(ccs), intent(inout) :: wf
      integer, intent(in) :: n_states

      real(dp), dimension(n_states, n_states), intent(out) :: A, S

      real(dp), dimension(:), allocatable :: R, AR, L

      real(dp), external :: ddot
      real(dp) :: energy

      type(state_descriptor), allocatable :: descriptor

      integer :: state_l, state_r

      call mem%alloc(R, wf%n_es_amplitudes)
      call mem%alloc(AR, wf%n_es_amplitudes)
      call mem%alloc(L, wf%n_es_amplitudes)

      do state_r = 1, n_states

         call wf%R_es_states%read_(state_r, R, energy)

         descriptor = wf%R_es_states%get_descriptor(state_r)
         call wf%construct_Jacobian_transform(R, AR, descriptor, energy)

         do state_l = 1, n_states

            call wf%L_es_states%read_(state_l, L)

            S(state_l, state_r) = wf%L_R_overlap(L, R, descriptor, energy)
            A(state_l, state_r) = wf%L_R_overlap(L, AR, descriptor, energy)

         end do
      end do

      call mem%dealloc(L)
      call mem%dealloc(R)
      call mem%dealloc(AR)

   end subroutine construct_subspace_jacobian_ccs


   subroutine diagonalize_subspace_jacobian_ccs(wf, n_states)
      !!
      !! Written by Alexander C. Paul, Sarai D. Folkestad,
      !! Andreas S. Skeidsvoll, 2020
      !!
      !! The Jacobian expressed in the basis of the excited states is not
      !! necessarily diagonal, since the eigenvectors are only approximate
      !! eigenvectors of the Jacobian. This can for instance be the case when sets
      !! of excited states are combined. This routine diagonalizes the subspace
      !! Jacobian by solving the generalized eigenvalue problem
      !!
      !!    A = S omega,
      !!
      !! where A is the Jacobian and S the overlap matrix in the reduced basis of
      !! the excited states.
      !!
      use array_utilities, only: generalized_diagonalization_asymmetric

      implicit none

      class(ccs), intent(inout) :: wf
      integer, intent(in) :: n_states

      real(dp), dimension(:, :), allocatable :: A, S, left_subspace_eigenvectors, right_subspace_eigenvectors

      real(dp), dimension(:), allocatable :: eigenvalues_real, eigenvalues_imag

      integer :: p, q

      call mem%alloc(A, n_states, n_states)
      call mem%alloc(S, n_states, n_states)

      call wf%construct_subspace_jacobian(A, S, n_states)

      call mem%alloc(eigenvalues_real, n_states)
      call mem%alloc(eigenvalues_imag, n_states)

      call mem%alloc(left_subspace_eigenvectors, n_states, n_states)
      call mem%alloc(right_subspace_eigenvectors, n_states, n_states)

      call generalized_diagonalization_asymmetric(A, &
                                                  S, &
                                                  n_states, &
                                                  eigenvalues_real, &
                                                  eigenvalues_imag, &
                                                  left_subspace_eigenvectors, &
                                                  right_subspace_eigenvectors)


      call mem%dealloc(A)
      call mem%dealloc(S)

      ! Print debug information about ordered states

      do q = 1, n_states

         call output%printf('debug', &
                            'Eigenvalue - Re:(f20.12)    Im:(f20.12)', &
                            reals=[eigenvalues_real(q), eigenvalues_imag(q)], &
                            fs='(/t3,a)')

         call output%printf('debug', 'Left Eigenvector      Right Eigenvector')
         call output%print_separator('debug', 39, '-')

         do p = 1, n_states

            call output%printf('debug', &
                               '(f16.10)      (f17.10)', &
                               reals=[left_subspace_eigenvectors(p, q), right_subspace_eigenvectors(p, q)])

         end do

         call output%print_separator('debug', 39, '-')

      end do


      call wf%transform_excited_state_vectors(left_subspace_eigenvectors, &
                                              right_subspace_eigenvectors, &
                                              n_states, &
                                              eigenvalues_real)


      call mem%dealloc(eigenvalues_imag)
      call mem%dealloc(eigenvalues_real)


      call mem%dealloc(left_subspace_eigenvectors)
      call mem%dealloc(right_subspace_eigenvectors)

   end subroutine diagonalize_subspace_jacobian_ccs


   subroutine transform_excited_state_vectors_ccs(wf, &
                                                  left_vector_transformations, &
                                                  right_vector_transformations, &
                                                  n_states, &
                                                  energies)
      !!
      !! Written by Alexander C. Paul, Sarai D. Folkestad,
      !! Andreas S. Skeidsvoll, 2020
      !!
      !! Transforms the excited state vectors using the transformation matrices
      !! left_vector_transformations and right_vector_transformations.
      !!

      implicit none

      class(ccs), intent(inout) :: wf
      integer, intent(in) :: n_states
      real(dp), dimension(n_states, n_states), intent(in) :: left_vector_transformations, &
                                                             right_vector_transformations
      real(dp), dimension(n_states), intent(in) :: energies

      call wf%L_es_states%transform(left_vector_transformations, energies)
      call wf%R_es_states%transform(right_vector_transformations, energies)

   end subroutine transform_excited_state_vectors_ccs


   subroutine construct_and_save_subspace_hamiltonian_ccs(wf, n_states)
      !!
      !! Written by Andreas S. Skeidsvoll, Aug 2020
      !!
      !! Computes the EOM Hamiltonian elements
      !!
      !! GS:
      !!    < Lambda| H |CC > = < HF| H |CC > + sum_mu tbar_mu < mu| e^-T H |CC >
      !!                      = E_CC
      !! n-0:
      !!    < L| H |CC > = sum_mu L_mu < mu| e^-T H |CC >
      !!                 = 0
      !! 0-n:
      !!    < Lambda| H |R > = r_0 E_0 + sum_nu eta_nu R_nu
      !!                       + sum_nu (sum_mu tbar_mu A_mu,nu + tbar_nu E_0) R_nu
      !!                     = 0
      !!
      !! m-n:
      !!    < L| H |R > = sum_nu (sum_mu L_mu A_mu,nu + L_nu E_0) R_nu
      !!
      !! and saves the matrix to file.
      !!
      use stream_file_class, only: stream_file

      implicit none

      class(ccs), intent(inout) :: wf
      integer, intent(in) :: n_states

      real(dp), dimension(:, :), allocatable :: jacobian_elements, overlap_elements, hamiltonian_elements

      integer :: n

      type(stream_file) :: hamiltonian_matrix_file

      call mem%alloc(jacobian_elements, n_states, n_states)
      call mem%alloc(overlap_elements, n_states, n_states)

      call wf%construct_subspace_jacobian(jacobian_elements, overlap_elements, n_states)

      call mem%dealloc(overlap_elements)

      call mem%alloc(hamiltonian_elements, n_states + 1, n_states + 1, set_zero=.true.)
      hamiltonian_elements(2:n_states + 1, 2:n_states + 1) = jacobian_elements

      call mem%dealloc(jacobian_elements)

      ! Add < HF| H |CC > to matrix diagonal

      !$omp parallel do private(n)
      do n = 1, n_states + 1

         hamiltonian_elements(n, n) = hamiltonian_elements(n, n) + wf%energy

      end do
      !$omp end parallel do

      hamiltonian_matrix_file = stream_file('cc_eom_hamiltonian_matrix')

      call hamiltonian_matrix_file%open_('rewind')
      call hamiltonian_matrix_file%write_(n_states + 1)
      call hamiltonian_matrix_file%write_(hamiltonian_elements, (n_states + 1)**2)
      call hamiltonian_matrix_file%close_('keep')

      call mem%dealloc(hamiltonian_elements)

   end subroutine construct_and_save_subspace_hamiltonian_ccs


   pure function get_n_es_parameters(wf, descriptor) result(n_es_amplitudes)
      !!
      !! Written by Sarai D. Folkestad, 2024
      !!
      implicit none

      class(ccs), intent(in) :: wf
      type(state_descriptor), intent(in) :: descriptor
      integer :: n_es_amplitudes

      n_es_amplitudes = - 1
      if (trim(descriptor%get_spin_symmetry()) == 'singlet') then
         n_es_amplitudes = wf%n_es_amplitudes
      else if (trim(descriptor%get_spin_symmetry()) == 'triplet') then
         n_es_amplitudes = wf%n_triplet_amplitudes
      end if

   end function get_n_es_parameters


   subroutine add_es_states(wf, descriptor, n_states)
      !!
      !! Written by Sarai D. Folkestad, 2024
      !!
      implicit none
      class(ccs), intent(inout) :: wf

      type(state_descriptor), intent(in) :: descriptor
      integer, intent(in) :: n_states

      if (descriptor%get_left_or_right() == 'left') then

         call wf%L_es_states%add(descriptor, n_states, wf%get_n_es_parameters(descriptor))

      else if (descriptor%get_left_or_right() == 'right') then

         call wf%R_es_states%add(descriptor, n_states, wf%get_n_es_parameters(descriptor))

      else

         call output%error_msg('Did not recognize sidedness of excited states!')

      end if

   end subroutine add_es_states


   function L_R_overlap_ccs(wf, L, R, descriptor, energy) result(L_R_overlap)
      !!
      !! Written by Alexander C. Paul, Aug 2019
      !!
      !! Computes L^T * R for full space L and R (singles, doubles, triples)
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_es_amplitudes), intent(in) :: L
      real(dp), dimension(wf%n_es_amplitudes), intent(in) :: R
      real(dp), intent(in) :: energy
      type(state_descriptor), intent(in) :: descriptor

      real(dp) :: ddot, L_R_overlap

      call do_nothing(energy)
      call do_nothing(descriptor)

      L_R_overlap = ddot(wf%n_es_amplitudes, L, 1, R, 1)

   end function L_R_overlap_ccs


   function get_es_states(wf, descriptor) result(es_handler)
      !!
      !! Written by Sarai D. Folkestad, 2024
      !!
      implicit none

      class(ccs), intent(in) :: wf
      type(state_descriptor), intent(in) :: descriptor
      type(cc_es_states_handler) :: es_handler

      if (trim(descriptor%get_left_or_right()) == 'left') then

         es_handler = wf%L_es_states%get_states_of_es_type(descriptor)

      else

         es_handler = wf%R_es_states%get_states_of_es_type(descriptor)

      end if

   end function get_es_states


   subroutine calculate_and_print_occupation_numbers_ccs(wf, density)
      !!
      !! Written by Federico Rossi, Sep 2025
      !!
      !! Computes the occupation numbers in coupled cluster
      !! diagonalizing the density matrix:
      !!    D_pq = < Lambda| E_pq |CC >
      !!
      !! and the symmetrized version
      !!    0.5 * (D_pq + D_qp)
      !!
      !! Information on the density antisymmetry is provided following
      !! https://doi.org/10.1021/acs.jpclett.5c00885
      !!
      use array_utilities, only: diagonalize_symmetric, get_l2_norm
      use lapack_wrappers, only: diagonalize_non_symmetric
      use reordering_r, only: symmetric_sum, antisymmetric_sum

      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_mo, wf%n_mo), intent(in) :: density

      real(dp), dimension(:, :), allocatable :: eigvecs
      complex(dp), dimension(:), allocatable :: eigvals
      real(dp), dimension(:), allocatable :: real_eigvals
      integer, dimension(2) :: indices
      integer :: first, last, i
      real(dp) :: d_diagnostic

      call output%printf('m', 'Occupation numbers (unsymmetrized density):', fs='(/t6,a)')
      call output%print_separator('m', 43, '=', fs='(t6,a)')

      call input%get_array_for_keyword('occupation numbers', 'cc mean value', 2, indices)

      first = indices(1)
      last = indices(2)

      if (first < 1) then

         first = 1

         call output%warning_msg( &
                 'Invalid initial orbital indicator (i0). It will be automatically set to 1.', &
                 ints=[indices(1)], &
                 fs='(t6,a)' &
              )

      end if

      if (last > wf%n_mo) then

         last = wf%n_mo

         call output%warning_msg( &
                 'Invalid last orbital indicator (i0). It will be automatically set to (i0).', &
                 ints=[indices(2), wf%n_mo], &
                 fs='(t6,a)' &
              )

      end if

      call mem%alloc(eigvecs, wf%n_mo, wf%n_mo)
      call mem%alloc(eigvals, wf%n_mo)

      call diagonalize_non_symmetric(wf%n_mo, density, eigvecs, eigvals)

      call output%printf('m', '   n      Real             Imaginary', fs='(/t6,a)')
      call output%print_separator('m', 42, '-', fs='(t6,a)')

      do i = first, last

         call output%printf('m', &
                            '(i4)    (c14.10)', &
                            ints=[i], &
                            complexs=[eigvals(wf%n_mo - i + 1)], &
                            fs='(t6,a)')

      end do

      call output%print_separator('m', 42, '-', fs='(t6,a)')

      call mem%dealloc(eigvals)
      call mem%alloc(real_eigvals, wf%n_mo)

      call output%printf('m', 'Occupation numbers (symmetrized density):', fs='(/t6,a)')
      call output%print_separator('m', 41, '=', fs='(t6,a)')

      call dcopy(wf%n_mo**2, density, 1, eigvecs, 1)
      call dscal(wf%n_mo**2, half, eigvecs, 1)
      call symmetric_sum(eigvecs, wf%n_mo)
      call diagonalize_symmetric(eigvecs, wf%n_mo, real_eigvals)

      call output%printf('m', '   n      Real', fs='(/t6,a)')
      call output%print_separator('m', 24, '-', fs='(t6,a)')

      do i = first, last

         call output%printf('m', &
                            '(i4)    (f14.10)', &
                            ints=[i], &
                            reals=[real_eigvals(wf%n_mo - i + 1)], &
                            fs='(t6,a)')

      end do

      call output%print_separator('m', 24, '-', fs='(t6,a)')

      call dcopy(wf%n_mo**2, density, 1, eigvecs, 1)
      call antisymmetric_sum(eigvecs, wf%n_mo)

      d_diagnostic = get_l2_norm(eigvecs, wf%n_mo**2) / sqrt(real(wf%ao%get_n_electrons(), kind=dp))

      call output%printf('m', 'Density Antisymmetry Diagnostic: (f14.10)', reals=[d_diagnostic], fs='(/t6,a)')

      call mem%dealloc(eigvecs)
      call mem%dealloc(real_eigvals)

   end subroutine calculate_and_print_occupation_numbers_ccs


end module ccs_class

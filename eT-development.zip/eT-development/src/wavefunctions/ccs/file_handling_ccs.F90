

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.

submodule (ccs_class) file_handling_ccs

   !!
   !! File handling submodule
   !!
   !! Gathers routines that save wavefunction parameters to file,
   !! and reads them from file, plus other routines related to the
   !! handling of the files that belong to the wavefunction.
   !!

   implicit none


contains


   module subroutine initialize_ground_state_files_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Mar 2019
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      wf%t_storer = amplitude_file_storer('t', wf%n_gs_amplitudes)
      wf%tbar_storer = amplitude_file_storer('tbar', wf%n_gs_amplitudes)
      wf%omega_storer = amplitude_file_storer('omega', wf%n_gs_amplitudes)

   end subroutine initialize_ground_state_files_ccs


   module subroutine save_amplitudes_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Alexander C. Paul, 2017-2022
      !!
      !! File format: energy n_t1, t1
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(:), allocatable :: t

      call mem%alloc(t, wf%n_gs_amplitudes)

      call wf%get_amplitudes(t)
      call wf%t_storer%save_(t, wf%energy)

      call mem%dealloc(t)

   end subroutine save_amplitudes_ccs


   module subroutine read_amplitudes_ccs(wf, read_n)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Alexander C. Paul, 2017-2022
      !!
      !! read_n: optionally returns the number of amplitudes read.
      !!         This is especially useful e.g. in CCSD to provide a start guess
      !!         for the doubles if only singles were found on file.
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      integer, intent(out), optional :: read_n

      real(dp), dimension(:), allocatable :: t
      real(dp) :: energy

      call mem%alloc(t, wf%n_gs_amplitudes)

      call wf%t_storer%read_(t, energy, read_n)
      call wf%set_amplitudes(t)

      call mem%dealloc(t)

   end subroutine read_amplitudes_ccs


   module subroutine save_multipliers_ccs(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Alexander C. Paul, 2017-2022
      !!
      !! File format: energy n_t1, t1bar
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(:), allocatable :: tbar

      call mem%alloc(tbar, wf%n_gs_amplitudes)

      call wf%get_multipliers(tbar)
      call wf%tbar_storer%save_(tbar, wf%energy)

      call mem%dealloc(tbar)

   end subroutine save_multipliers_ccs


   module subroutine read_multipliers_ccs(wf, read_n)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Alexander C. Paul, 2017-2022
      !!
      !! read_n: optionally returns the number of multipliers read.
      !!         This is especially useful e.g. in CCSD to provide a start guess
      !!         for the doubles if only singles were found on file.
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      integer, intent(out), optional :: read_n

      real(dp), dimension(:), allocatable :: tbar
      real(dp) :: energy

      call mem%alloc(tbar, wf%n_gs_amplitudes)

      call wf%tbar_storer%read_(tbar, energy, read_n)
      call wf%set_multipliers(tbar)

      call mem%dealloc(tbar)

   end subroutine read_multipliers_ccs


   module subroutine save_omega_ccs(wf, omega)
      !!
      !! Written by Marcus T. Lexander 2025
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_gs_amplitudes), intent(in) :: omega

      call wf%omega_storer%save_(omega, wf%energy)

   end subroutine save_omega_ccs


   module subroutine read_omega_ccs(wf, omega, read_n)
      !!
      !! Written by Marcus T. Lexander 2025
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      integer, intent(out), optional :: read_n

      real(dp), dimension(wf%n_gs_amplitudes), intent(out) :: omega
      real(dp) :: energy

      call wf%omega_storer%read_(omega, energy, read_n)

   end subroutine read_omega_ccs


   module subroutine check_and_get_restart_vector_ccs(wf, vector, energy, i, descriptor, found)
      !!
      !! Written by Sarai D. Folkestad, 2024
      !!
      use string_utilities, only: flip_left_or_right
      use state_descriptor_class, only: state_descriptor
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%n_es_amplitudes), intent(inout) :: vector
      real(dp), intent(out) :: energy
      logical, intent(out) :: found

      integer, intent(in) :: i
      type(state_descriptor), intent(in) :: descriptor

      character(len=:), allocatable :: file_name, flipped_left_or_right, left_or_right
      integer :: n_read, n_amplitudes

      type(amplitude_file_storer), allocatable :: storer
      type(state_descriptor), allocatable :: descriptor_flip_left_or_right

      found = .false.

      n_amplitudes = wf%get_n_es_parameters(descriptor)
      left_or_right = descriptor%get_left_or_right()

      file_name = trim(descriptor%get_file_name(i))
      storer = amplitude_file_storer(file_name, n_amplitudes)

      if (storer%file_exists()) then

         found = .true.
         call storer%read_(vector, energy, n_read)
         if (n_read /= n_amplitudes) &
            call wf%restart_es_from_other_model(vector, n_amplitudes, n_read, energy, left_or_right)
      else

         deallocate(storer)

         flipped_left_or_right = trim(flip_left_or_right(left_or_right))
         descriptor_flip_left_or_right = state_descriptor(flipped_left_or_right, &
                                                          descriptor%is_cvs(), &
                                                          descriptor%is_ionized(), &
                                                          descriptor%is_core_removed(), &
                                                          descriptor%is_electron_attached(), &
                                                          descriptor%get_spin_symmetry())

         file_name = trim(descriptor_flip_left_or_right%get_file_name(i))
         storer = amplitude_file_storer(file_name, n_amplitudes)

         if (storer%file_exists()) then

            found = .true.
            call storer%read_(vector, energy, n_read)
            call wf%restart_from_opposite_side(vector, left_or_right, n_read)
            if (n_read /= n_amplitudes) &
               call wf%restart_es_from_other_model(vector, n_amplitudes, n_read, energy, left_or_right)

         end if
      end if

      ! Check if possible to restart left from right or the other way around.
      ! Determine the opposite of left_or_right
      flipped_left_or_right = trim(flip_left_or_right(left_or_right))
      descriptor_flip_left_or_right = state_descriptor(flipped_left_or_right, &
                                                       descriptor%is_cvs(), &
                                                       descriptor%is_ionized(), &
                                                       descriptor%is_core_removed(), &
                                                       descriptor%is_electron_attached(), &
                                                       descriptor%get_spin_symmetry())

      call output%printf('n', &
                         'Restarting ' // trim(left_or_right) // ' vector (i0) from file (a0).', &
                         ints=[i], &
                         chars=[trim(file_name)], &
                         fs='(t6,a)')


   end subroutine check_and_get_restart_vector_ccs


   module subroutine restart_from_opposite_side_ccs(wf, &
                                                    vector, &
                                                    left_or_right, &
                                                    n_amplitudes)
      !!
      !! Written by Alexander C. Paul and Sarai D. Folkestad, 2020-2024
      !!
      !! Gets start vector and energy from storer and
      !! handles the basis transformations according to:
      !!
      !! restart from "right" to "left"
      !! L^a_i = 2R^a_i
      !!
      !! restart from "left" to "right"
      !! R^a_i = 1/2 L^a_i
      !!

      use warning_suppressor, only: do_nothing

      implicit none

      class(ccs), intent(in) :: wf
      integer, intent(in) :: n_amplitudes

      real(dp), dimension(n_amplitudes), intent(inout) :: vector

      character(len=*), intent(in) :: left_or_right

      call do_nothing(wf)

      if (left_or_right == 'right') then  ! restarting from left

         call dscal(n_amplitudes, half, vector, 1)

      else if (left_or_right == 'left') then  ! restarting from right

         call dscal(n_amplitudes, two, vector, 1)

      else

         call output%error_msg('Did not recognize left_or_right in restart')

      end if


   end subroutine restart_from_opposite_side_ccs


   module subroutine restart_es_from_other_model_ccs(wf, vector, n_amplitudes, n_read, energy, left_or_right)
      !!
      !! Written by Sarai D. Folkestad, 2024
      !!

      use warning_suppressor, only: do_nothing

      implicit none

      class(ccs), intent(in) :: wf
      integer, intent(in) :: n_amplitudes, n_read

      real(dp), dimension(n_amplitudes), intent(inout) :: vector

      character(len=*), intent(in) :: left_or_right

      real(dp), intent(in) :: energy

      call do_nothing(n_read)
      call do_nothing(n_amplitudes)
      call do_nothing(left_or_right)
      call do_nothing(vector)
      call do_nothing(wf)
      call do_nothing(energy)

   end subroutine restart_es_from_other_model_ccs


   module subroutine save_tbar_intermediates_ccs(wf)
      !!
      !! Written by Alexander C. Paul, Aug 2019
      !!
      use warning_suppressor, only: do_nothing

      implicit none

      class(ccs) :: wf

      ! Suppress unused variable compiler warning for wf
      call do_nothing(wf)

   end subroutine save_tbar_intermediates_ccs


   module subroutine remove_parallel_states_ccs(wf, threshold)
      !!
      !! Written by Alexander C. Paul, Sep 2020
      !!
      !! Find parallel left and right vectors and remove them
      !! from the corresponding files and wf variables.
      !!
      !! NB: This routine may only be called once during the execution of eT,
      !!     otherwise n_singlet_states is reduced twice.
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), intent(in) :: threshold

      call wf%L_es_states%remove_parallel_states(threshold)
      call wf%R_es_states%remove_parallel_states(threshold)

   end subroutine remove_parallel_states_ccs


   module subroutine get_density_for_plotting_ccs(wf, &
                                                  c_D_ct, &
                                                  density, &
                                                  state_l, &
                                                  state_r, &
                                                  density_found)
      !!
      !! Written by Alexander C. Paul, May 2021
      !!
      implicit none

      class(ccs), intent(inout) :: wf

      real(dp), dimension(wf%ao%n, wf%ao%n), intent(out) :: c_D_ct
      real(dp), dimension(wf%n_mo, wf%n_mo), intent(out) :: density
      integer, intent(in) :: state_l, state_r

      logical, intent(out) :: density_found

      density_found = .false.

      if (wf%density_storage%is_density_stored(state_l, state_r)) then

         call wf%density_storage%copy_density_out(density, state_l, state_r)

         density_found = .true.
         call wf%add_t1_terms_and_transform(density, c_D_ct)

      end if

   end subroutine get_density_for_plotting_ccs


   module subroutine write_dyson_orbitals(wf, left_dyson, right_dyson, n_states)
      !!
      !! Written by Alexander C. Paul, May 2021
      !!
      !! Write formatted output file for Dyson orbitals in the format:
      !! # "Label" Dyson orbital "state"
      !! #MO, Dyson coefficient
      !!

      implicit none

      class(ccs), intent(inout) :: wf
      integer, intent(in) :: n_states

      real(dp), dimension(wf%n_mo, n_states), intent(in) :: left_dyson
      real(dp), dimension(wf%n_mo, n_states), intent(in) :: right_dyson

      type(output_file), allocatable :: dyson_output_file
      integer :: n

      dyson_output_file = output_file('eT.dyson_orbitals.out')
      call dyson_output_file%open_()

      call dyson_output_file%printf('m', &
                                    '# MO, Dyson coefficients', &
                                    fs='(t1,a)')

      do n = 1, n_states

         call wf%print_dyson_coefficients(dyson_output_file, left_dyson(:, n), "left", n)

         call dyson_output_file%printf('m', '#', fs='(t1,a)')

         call wf%print_dyson_coefficients(dyson_output_file, right_dyson(:, n), "right", n)

         call dyson_output_file%printf('m', '#', fs='(t1,a)')

      end do

      call dyson_output_file%close_()

      call wf%left_dyson_file%open_()
      call wf%left_dyson_file%write_(left_dyson, wf%n_mo * n_states, 1)
      call wf%left_dyson_file%close_()

      call wf%right_dyson_file%open_()
      call wf%right_dyson_file%write_(right_dyson, wf%n_mo * n_states, 1)
      call wf%right_dyson_file%close_()

   end subroutine write_dyson_orbitals


   module subroutine print_dyson_coefficients(wf, out_file, coefficients, left_or_right, n)
      !!
      !! Written by Alexander C. Paul, Jan 2023
      !!
      use array_utilities, only: get_l2_norm

      implicit none

      class(ccs), intent(in) :: wf

      class(output_file), intent(inout) :: out_file
      real(dp), dimension(wf%n_mo), intent(in) :: coefficients
      character(len=*), intent(in) :: left_or_right
      integer, intent(in) :: n

      integer :: p
      real(dp) :: l2_norm

      l2_norm = get_l2_norm(coefficients, wf%n_mo)

      call out_file%printf('m', &
                           '# (a0) Dyson orbital (i0), Norm: (f15.12)', &
                           ints=[n], &
                           reals=[l2_norm], &
                           chars=[left_or_right], &
                           fs='(t1,a)')

      ! Exclude coefficient for bath orbital, as it is always 0

      do p = 1, wf%n_mo - 1

         call out_file%printf('m', &
                              '(i4), (f15.12)', &
                              ints=[p], &
                              fs='(t1,a)', &
                              reals=[coefficients(p)])

      end do

   end subroutine print_dyson_coefficients


   module subroutine get_dyson_orbitals_for_plotting(wf, &
                                                     ao_dyson_orbitals, &
                                                     labels, &
                                                     dyson_file, &
                                                     left_or_right, &
                                                     n_states)
      !!
      !! Written by Alexander C. Paul, May 2021
      !!
      implicit none

      class(ccs), intent(in) :: wf

      integer, intent(in) :: n_states
      real(dp), dimension(wf%ao%n, n_states), intent(out) :: ao_dyson_orbitals
      character(len=200), dimension(n_states), intent(out) :: labels
      type(stream_file), intent(inout) :: dyson_file
      character(len=*), intent(in) :: left_or_right

      real(dp), dimension(:, :), allocatable :: dyson_orbitals
      integer :: p

      call mem%alloc(dyson_orbitals, wf%n_mo, n_states)

      call dyson_file%open_()
      call dyson_file%read_(dyson_orbitals, wf%n_mo * n_states)
      call dyson_file%close_()

      do p = 1, n_states

         call wf%transform_one_electron_state_to_ao(dyson_orbitals(:, p), ao_dyson_orbitals(:, p))
         write(labels(p), '(a, a, i3.3)') trim(left_or_right), '_dyson_', p

      end do

      call mem%dealloc(dyson_orbitals)

   end subroutine get_dyson_orbitals_for_plotting


end submodule file_handling_ccs

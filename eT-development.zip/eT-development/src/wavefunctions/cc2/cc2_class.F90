

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


module cc2_class

   !!
   !! Coupled cluster singles and perturbative doubles (CC2) class module
   !! Written by Eirik F. Kjoenstad, Sarai D. Folkestad, 2018
   !!

   use doubles_class, only: doubles

   use parameters
   use global_out, only: output
   use timings_class, only: timings
   use memory_manager_class, only: mem

   implicit none

   type, extends(doubles) :: cc2

   contains

      ! Ground state

      procedure :: construct_fock => construct_fock_cc2

      procedure :: construct_omega => construct_omega_cc2

      procedure :: calculate_energy => calculate_energy_cc2

      ! Amplitudes and multipliers

      procedure :: construct_t2 => construct_t2_cc2

      procedure :: construct_u_aibj => construct_u_aibj_cc2

      procedure :: construct_t2bar => construct_t2bar_cc2

      procedure :: get_es_amplitude_block_sizes => get_es_amplitude_block_sizes_cc2

      ! Jacobian

      procedure :: prepare_for_jacobian => prepare_for_jacobian_cc2

      procedure :: jacobian_doubles_b2_fock => jacobian_doubles_b2_fock_cc2

      ! Jacobian transpose

      procedure :: prepare_for_jacobian_transpose => prepare_for_jacobian_transpose_cc2

      procedure :: jacobian_transpose_transformation => jacobian_transpose_transformation_cc2

      ! Multiplier equation

      procedure :: prepare_for_multiplier_equation => prepare_for_multiplier_equation_cc2
      procedure :: construct_multiplier_equation => construct_multiplier_equation_cc2
      procedure :: cc_multipliers_summary => cc_multipliers_summary_cc2

      ! Initialize and destruct

      procedure :: initialize_amplitudes => initialize_amplitudes_cc2
      procedure :: destruct_amplitudes => destruct_amplitudes_cc2
      procedure :: destruct_multipliers => destruct_multipliers_cc2

      ! Properties

      procedure :: prepare_for_properties => prepare_for_properties_cc2

      ! Initialize wavefunction

      procedure :: set_parameter_dimensions => set_parameter_dimensions_cc2

      ! Triplet

      procedure :: triplet_jacobian_d_d_a => triplet_jacobian_d_d_a_cc2
      procedure :: prepare_for_triplet_jacobian => prepare_for_triplet_jacobian_cc2
      procedure :: triplet_jacobian_transformation => triplet_jacobian_transformation_cc2
      procedure :: prepare_for_triplet_jacobian_transpose => prepare_for_triplet_jacobian_transpose_cc2
      procedure :: triplet_jacobian_transpose_transformation => triplet_jacobian_transpose_transformation_cc2

   end type cc2

   interface cc2

      procedure :: new_cc2

   end interface cc2

   interface

      include "initialize_destruct_cc2_interface.F90"
      include "omega_cc2_interface.F90"
      include "multiplier_equation_cc2_interface.F90"
      include "jacobian_cc2_interface.F90"
      include "triplet_jacobian_cc2_interface.F90"
      include "jacobian_transpose_cc2_interface.F90"
      include "triplet_jacobian_transpose_cc2_interface.F90"
      include "mean_value_cc2_interface.F90"
      include "fock_cc2_interface.F90"

   end interface


contains


   function new_cc2() result(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      type(cc2) :: wf

      wf%name_ = 'cc2'
      wf%need_g_abcd = .false.

   end function new_cc2


   subroutine set_parameter_dimensions_cc2(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, 2018
      !!
      implicit none

      class(cc2), intent(inout) :: wf

      wf%n_t1 = wf%n_o * wf%n_v
      wf%n_t2 = wf%n_t1 * (wf%n_t1 + 1) / 2
      wf%n_gs_amplitudes = wf%n_t1
      wf%n_es_amplitudes = wf%n_t1 + wf%n_t2

      wf%n_triplet_amplitudes = wf%n_t1 + wf%n_t1 * (wf%n_t1 - 1) / 2 &
                                + (wf%n_o * (wf%n_o - 1) / 2) * (wf%n_v * (wf%n_v - 1) / 2)

   end subroutine set_parameter_dimensions_cc2


   subroutine construct_t2_cc2(wf)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Jan 2019
      !!
      !! Construct
      !!
      !!    t_aibj = - g_aibj/epsilon_aibj
      !!
      !! where
      !!
      !!    epsilon_aibj = epsilon_a - epsilon_i + epsilon_b - epsilon_j
      !!
      !! and epsilon_r is the r'th orbital energy.
      !!
      use reordering_r, only: packin

      implicit none

      class(cc2), intent(inout) :: wf

      real(dp), dimension(:, :, :, :), allocatable :: t_aibj

      call mem%alloc(t_aibj, wf%n_v, wf%n_o, wf%n_v, wf%n_o)

      call wf%eri_t1%get('vovo', t_aibj)

      call wf%divide_doubles_by_orbital_differences(t_aibj)

      call packin(wf%t2, t_aibj, wf%n_t1)

      call mem%dealloc(t_aibj)

   end subroutine construct_t2_cc2


   subroutine construct_t2bar_cc2(wf, t2bar)
      !!
      !! Written by Sarai D. Folkestad, May, 2019
      !!
      use array_initialization, only: zero_array
      use reordering_r, only: symmetric_sum, add_2143_to_1234, add_2341_to_1234

      implicit none

      class(cc2) :: wf
      real(dp), dimension(wf%n_v, wf%n_o, wf%n_v, wf%n_o), intent(out) :: t2bar

      real(dp), dimension(:, :, :, :), allocatable :: g_iajb

      call zero_array(t2bar, (wf%n_v * wf%n_o)**2)

      ! t2bar = sum_ai tbar_ai A_ai,aibj

      call wf%jacobian_transpose_doubles_a2_oei(t2bar, wf%t1bar, wf%fock_ia)
      call wf%jacobian_transpose_doubles_a2(t2bar, wf%t1bar)
      call symmetric_sum(t2bar, wf%n_t1)

      call mem%alloc(g_iajb, wf%n_o, wf%n_v, wf%n_o, wf%n_v)
      call wf%eri_t1%get('ovov', g_iajb)

      ! t2bar += eta_aibj

      call add_2143_to_1234(four, g_iajb, t2bar, wf%n_v, wf%n_o, wf%n_v, wf%n_o)
      call add_2341_to_1234(- two, g_iajb, t2bar, wf%n_v, wf%n_o, wf%n_v, wf%n_o)

      call mem%dealloc(g_iajb)

      ! t2bar = t2bar/(-epsilon_aibj)

      call wf%divide_doubles_by_orbital_differences(t2bar)

   end subroutine construct_t2bar_cc2


   subroutine construct_u_aibj_cc2(wf, u_aibj)
      !!
      !! Written by Sarai D. Folkestad and Eirik F. Kjoenstad, Jan 2019
      !!
      !! Construct
      !!
      !!    u_aibj = 2t_aibj - t_ajbi
      !!
      !! with
      !!
      !!    t_aibj = - g_aibj/epsilon_aibj
      !!
      !! where
      !!
      !!    epsilon_aibj = epsilon_a - epsilon_i + epsilon_b - epsilon_j
      !!
      !! and epsilon_r is the r'th orbital energy.
      !!
      implicit none

      class(cc2), intent(inout) :: wf

      real(dp), dimension(wf%n_v, wf%n_o, wf%n_v, wf%n_o), intent(out) :: u_aibj
      real(dp), dimension(:, :, :, :), allocatable :: g_aibj

      integer :: a, i, b, j
      real(dp) :: eps

      type(timings) :: timer

      timer = timings('Construct u_aibj CC2')
      call timer%turn_on()

      call mem%alloc(g_aibj, wf%n_v, wf%n_o, wf%n_v, wf%n_o)

      call wf%eri_t1%get('vovo', g_aibj)

      !$omp parallel do private(a, i, b, j, eps)
      do j = 1, wf%n_o
         do b = 1, wf%n_v
            do i = 1, wf%n_o
               do a = 1, wf%n_v

                  eps = wf%orbital_energies(i) + wf%orbital_energies(j) - wf%orbital_energies(wf%n_o + a) &
                        - wf%orbital_energies(wf%n_o + b)

                  u_aibj(a, i, b, j) = (two * g_aibj(a, i, b, j) - g_aibj(a, j, b, i)) / eps

               end do
            end do
         end do
      end do
      !$omp end parallel do

      call mem%dealloc(g_aibj)

      call timer%turn_off()

   end subroutine construct_u_aibj_cc2


   subroutine get_es_amplitude_block_sizes_cc2(wf, amplitude_block_sizes)
      !!
      !! Written by Alexander C. Paul, June 2022
      !!
      implicit none

      class(cc2), intent(in) :: wf
      integer, dimension(:), allocatable, intent(out) :: amplitude_block_sizes

      amplitude_block_sizes = [wf%n_t1, wf%n_t2]

   end subroutine get_es_amplitude_block_sizes_cc2


   subroutine cc_multipliers_summary_cc2(wf)
      !!
      !! Written by Eirik F. Kjoenstad, 2025
      !!
      use memory_manager_class, only: mem
      use reordering_r, only: packin

      implicit none

      class(cc2) :: wf

      real(dp), dimension(:), allocatable :: multipliers
      real(dp), dimension(:, :, :, :), allocatable :: t2bar

      call output%printf('n', '- CC multipliers solver summary:', fs='(/t3,a)')

      call mem%alloc(multipliers, wf%n_t1 + wf%n_t2)

      call dcopy(wf%n_t1, wf%t1bar, 1, multipliers(1:wf%n_t1), 1)

      call mem%alloc(t2bar, wf%n_v, wf%n_o, wf%n_v, wf%n_o)
      call wf%construct_t2bar(t2bar)

      call packin(multipliers(wf%n_t1 + 1:), t2bar, wf%n_t1)

      call mem%dealloc(t2bar)

      call wf%print_dominant_x_amplitudes_singlet(multipliers, 'tbar')

      call mem%dealloc(multipliers)

      call wf%calculate_and_print_variational_energy()

   end subroutine cc_multipliers_summary_cc2


end module cc2_class

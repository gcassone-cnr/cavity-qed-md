

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


submodule (cc2_class) jacobian_transpose_cc2

   !!
   !! Jacobian transpose submodule
   !!
   !! Routines for the linear transform of trial
   !! vectors by the transpose of the Jacobian matrix
   !!
   !! sigma_i = A^T * c_i,
   !!
   !! where
   !!
   !! A_mu,nu = < mu |exp(-T) [H, tau_nu] exp(T) | R >.
   !!
   !!

   implicit none


contains


   module subroutine prepare_for_jacobian_transpose_cc2(wf)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, Feb 2019
      !!
      !! Modified by Tor S. Haugland, Oct 2019
      !!
      !! Removed construction of wf%u as it is constructed in the ground state.
      !!
      implicit none

      class(cc2), intent(inout) :: wf

      type(timings), allocatable :: timer

      real(dp), dimension(:, :, :, :), allocatable :: u_aibj

      timer = timings('Prepare for Jacobian transpose CC2', pl='normal')
      call timer%turn_on()

      call mem%alloc(u_aibj, wf%n_v, wf%n_o, wf%n_v, wf%n_o)
      call wf%construct_u_aibj(u_aibj)

      call wf%save_jacobian_transpose_a1_intermediates(u_aibj)

      call mem%dealloc(u_aibj)

      call timer%turn_off()

   end subroutine prepare_for_jacobian_transpose_cc2


   module subroutine jacobian_transpose_transformation_cc2(wf, b, sigma)
      !!
      !! Written by Sarai D. Folkestad and Alexander C. Paul, Feb 2019
      !!
      !! Calculates the transpose Jacobian transformation, i.e., the transformation
      !! by the transpose of the Jacobian matrix
      !!
      !!    A_mu,nu = < mu | exp(-T) [H, tau_nu] exp(T) | R >.
      !!
      !! The transformation is performed as sigma^T = c^T A, where c is the vector
      !! sent to the routine.
      !!
      use array_initialization, only: zero_array
      use reordering_r, only: squareup, symmetric_sum, packin

      implicit none

      class(cc2), intent(inout) :: wf

      real(dp), dimension(wf%n_t1 + wf%n_t2), intent(in) :: b
      real(dp), dimension(wf%n_t1 + wf%n_t2), intent(out) :: sigma

      real(dp), dimension(:, :, :, :), allocatable :: b_aibj

      real(dp), dimension(:, :, :, :), allocatable :: sigma_aibj, u_aibj

      type(timings), allocatable :: timer

      timer = timings('Jacobian transpose CC2', pl='normal')
      call timer%turn_on()

      call zero_array(sigma, wf%n_t1 + wf%n_t2)

      ! :: CCS contributions to the singles b vector ::

      call wf%ccs%jacobian_transpose_transformation(b(1:wf%n_t1), sigma(1:wf%n_t1))

      ! :: CC2 contributions to the transformed singles vector ::

      call mem%alloc(u_aibj, wf%n_v, wf%n_o, wf%n_v, wf%n_o)
      call wf%construct_u_aibj(u_aibj)

      call wf%jacobian_transpose_doubles_a1(sigma(1:wf%n_t1), b(1:wf%n_t1), u_aibj)

      call mem%dealloc(u_aibj)

      call mem%alloc(b_aibj, wf%n_v, wf%n_o, wf%n_v, wf%n_o)

      call squareup(b(wf%n_t1 + 1:), b_aibj, wf%n_t1)

      call wf%jacobian_transpose_doubles_b1(sigma(1:wf%n_t1), b_aibj)

      ! :: CC2 contributions to the transformed doubles vector ::

      call mem%alloc(sigma_aibj, wf%n_v, wf%n_o, wf%n_v, wf%n_o, set_zero=.true.)

      ! Contributions from singles vector b

      call wf%jacobian_transpose_doubles_a2_oei(sigma_aibj, b(1:wf%n_t1), wf%fock_ia)
      call wf%jacobian_transpose_doubles_a2(sigma_aibj, b(1:wf%n_t1))

      call wf%jacobian_doubles_b2_fock(sigma_aibj, b_aibj)
      call symmetric_sum(sigma_aibj, wf%n_t1)

      call mem%dealloc(b_aibj)

      ! Overwrite the incoming doubles b vector & pack in

      call packin(sigma(wf%n_t1 + 1:), sigma_aibj, wf%n_t1)

      call mem%dealloc(sigma_aibj)

      call timer%turn_off()

   end subroutine jacobian_transpose_transformation_cc2


end submodule jacobian_transpose_cc2

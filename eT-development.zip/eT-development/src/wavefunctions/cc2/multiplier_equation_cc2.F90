

! eT - a coupled cluster program
! Copyright (C) 2016-2026 the authors of eT

! eT is free software: you can redistribute it and/or modify
! it under the terms of the GNU General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.

! eT is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
! GNU General Public License for more details.

! You should have received a copy of the GNU General Public License
! along with this program. If not, see <https://www.gnu.org/licenses/>.


submodule (cc2_class) multiplier_equation_cc2

   !!
   !! Multiplier equation
   !!
   !! Routines for calculation of the multiplier equation,
   !!
   !!    t-bar^T A + eta = 0,
   !!
   !! where t-bar is the multiplier vector, and
   !!
   !!    A_mu,nu = < mu | exp(-T) [H, tau_nu] exp(T) | R >
   !!    eta_mu  = < R | exp(-T) [H, tau_mu] exp(T) | R >.
   !!

   implicit none


contains


   module subroutine prepare_for_multiplier_equation_cc2(wf)
      !!
      !! Written by Tor S. Haugland, Oct 2019
      !!
      !! Based on prepare_for_multiplier_equation_cc3 by Alex Paul
      !!
      implicit none

      class(cc2), intent(inout) :: wf

      type(timings) :: prep_timer

      prep_timer = timings("Prepare for multiplier equation", pl='normal')
      call prep_timer%turn_on()

      call output%printf('v', &
                         'Preparing for (a0) multiplier equations', &
                         chars=[trim(wf%name_)], &
                         fs='(/t3,a)')

      call wf%prepare_for_jacobian_transpose()

      call prep_timer%turn_off()

   end subroutine prepare_for_multiplier_equation_cc2


   module subroutine construct_multiplier_equation_cc2(wf, equation)
      !!
      !! Written by Sarai D. Folkestad, Feb 2019
      !!
      !! Constructs
      !!
      !!    t-bar^T A + eta,
      !!
      !! and places the result in 'equation'.
      !!
      !! Solves analytically for tbar_aibj
      !!
      !!    tbar_aibj = - (eta_aibj + sum_ai tbar_ai A_ai,aibj)/epsilon_aibj
      !!
      !! where
      !!
      !!    eta_aibj = 2 L_iajb
      !!
      !! and uses this to set up 'equation'
      !!
      !!    eta_ai + sum_bj tbar_bj A_bj,ai + sum_bjck tbar_bjck A_{bjck,ai}
      !!
      use array_initialization, only: zero_array

      implicit none

      class(cc2), intent(inout) :: wf

      real(dp), dimension(wf%n_gs_amplitudes), intent(inout) :: equation

      real(dp), dimension(:), allocatable :: eta
      real(dp), dimension(:, :, :, :), allocatable :: t2bar, u_aibj

      call zero_array(equation, wf%n_gs_amplitudes)

      call wf%ccs%jacobian_transpose_transformation(wf%t1bar, equation)

      call mem%alloc(u_aibj, wf%n_v, wf%n_o, wf%n_v, wf%n_o)
      call wf%construct_u_aibj(u_aibj)

      call wf%jacobian_transpose_doubles_a1(equation, wf%t1bar, u_aibj)

      call mem%dealloc(u_aibj)

      call mem%alloc(t2bar, wf%n_v, wf%n_o, wf%n_v, wf%n_o)
      call wf%construct_t2bar(t2bar)

      call wf%jacobian_transpose_doubles_b1(equation, t2bar)

      call mem%dealloc(t2bar)

      ! Add eta, equation = t-bar^T A + eta

      call mem%alloc(eta, wf%n_gs_amplitudes)
      call wf%construct_eta(eta)

      call daxpy(wf%n_gs_amplitudes, one, eta, 1, equation, 1)

      call mem%dealloc(eta)

   end subroutine construct_multiplier_equation_cc2


end submodule multiplier_equation_cc2

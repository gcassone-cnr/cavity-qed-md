# Contributing to eT

Thanks for your interest in contributing to **eT**! We welcome bug reports, feature requests, documentation improvements, and code contributions.

## Quick links
- Issue tracker: https://gitlab.com/eT-program/eT/-/issues
- Merge requests: https://gitlab.com/eT-program/eT/-/merge_requests

## Communication / getting help
- For **bugs** and **feature requests**: open an [issue](https://gitlab.com/eT-program/eT/-/issues)
- For **help with usage**: [contact support](mailto:support@etprogram.org)

## What we accept
- Bug fixes
- New features / methods
- Performance improvements
- Tests (unit + integration)
- Documentation improvements

## Reporting bugs
Open an [issue](https://gitlab.com/eT-program/eT/-/issues) and please provide:
- eT version / commit SHA
- OS + architecture
- Compiler (and version)
- CMake version
- Build options (OpenMP/BLAS/LAPACK/etc.)
- Input file / minimal reproducer
- Expected vs actual behavior
- Full error output / stack trace

Note that eT version, commit SHA, compiler, build options are typically visible in the output file. If you provide an example output, then there is no need to specify this information in the issue itself.

## Development workflow
- Our git workflow is **Gitflow**:
  - Feature branches are merged into **development**.
  - When **development** is merged into **master**, the merged features become part of a **minor** release. This happens regularly.
  - Bugfixes to **master** constitute a **patch** release. Patches are incorporated back into **development** once accepted into **master**.
  - A **major** release is less frequent and is accompanied by significant changes in functionality and can change the API (e.g., input).
- Versioning follows **SemVer** and is controlled in `src/various/parameters.F90`
- To contribute, please create your own **fork** of the repository and create a **merge request** from your fork/branch into this repository.

## Coding guidelines
We strive to ensure that the code is easy to understand and extend, and our main principles are:
1. **Write self-documenting code**. *Carefully choose routine and variable names to make the code readable, reducing the need for comments in the code; bad comments often explain bad routine/variable names and is therefore duplication (see 7.)*
2. **Favor long and descriptive names over abbreviated names**.
3. **Write short routines with descriptive names**.
4. **Never merge untested code**.
5. **Always follow the formatting conventions of the codebase**.
6. **Create classes with a small set of public routines with hidden implementation details**.
7. **Don't repeat yourself** / **avoid duplication**. *"Every piece of knowledge must have a single, unambiguous, authoritative representation within a system"* (Pragmatic Programmer)

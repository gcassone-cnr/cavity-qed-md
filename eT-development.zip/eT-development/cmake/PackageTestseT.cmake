#
#
#   eT - a coupled cluster program
#   Copyright (C) 2016-2026 the authors of eT
#
#   eT is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   eT is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program. If not, see <https://www.gnu.org/licenses/>.
#
#

# Test erifies that an installed eT can be consumed by a separate CMake project
# using only find_package(eT) and target_link_libraries(... eT::eT).
add_test(
   NAME eT_package_consumer
   COMMAND ${CMAKE_COMMAND}
      -DET_SOURCE_DIR=${CMAKE_SOURCE_DIR}
      -DET_BINARY_DIR=${CMAKE_BINARY_DIR}
      -DET_TEST_ROOT=${CMAKE_BINARY_DIR}/package_tests/eT_package_consumer
      -DET_INSTALL_CMAKEDIR=${eT_INSTALL_CMAKEDIR}
      -DET_CONSUMER_SOURCE_DIR=${CMAKE_SOURCE_DIR}/tests/package/eT_library_consumer
      -DET_CMAKE_GENERATOR=${CMAKE_GENERATOR}
      -DET_BUILD_CONFIG=$<CONFIG>
      -DET_CMAKE_BUILD_TYPE=${CMAKE_BUILD_TYPE}
      -DET_CMAKE_MAKE_PROGRAM=${CMAKE_MAKE_PROGRAM}
      -DET_Fortran_COMPILER=${CMAKE_Fortran_COMPILER}
      -DET_C_COMPILER=${CMAKE_C_COMPILER}
      -P ${CMAKE_SOURCE_DIR}/cmake/eTPackageConsumerTest.cmake)

set_tests_properties(eT_package_consumer PROPERTIES
   LABELS "eT;unit-test;package"
   TIMEOUT 1200)

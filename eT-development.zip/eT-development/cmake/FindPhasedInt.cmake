#
#
#   eT - a coupled cluster program
#   Copyright (C) 2016-2026 the authors of eT
#
#   eT is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   eT is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program. If not, see <https://www.gnu.org/licenses/>.
#
#

# Where to look for phasedint
set(_PHASEDINT_NORMAL_SEARCH
   /usr/local/phasedint
   /usr/opt/local/phasedint)

# Save location if set in environment
set(PHASEDINT_ENV $ENV{PHASEDINT_ROOT})

# Look for phasedint in user specified path
if(PHASEDINT_ROOT)
   message(STATUS "PhasedInt will be searched for based on PHASEDINT_ROOT=${PHASEDINT_ROOT}")
   find_library(PhasedInt_LIBRARY
                NAMES libphasedint.a
                PATHS ${PHASEDINT_ROOT} NO_DEFAULT_PATH
                PATH_SUFFIXES lib lib64)
   set(PhasedInt_INCLUDE_DIR ${PHASEDINT_ROOT}/include)
   include_directories(${PhasedInt_INCLUDE_DIR})

# Else look in environment path
elseif(PHASEDINT_ENV)
   message(STATUS "PhasedInt will be searched for based on PHASEDINT_ROOT=${PHASEDINT_ENV}")
   find_library(PhasedInt_LIBRARY
                NAMES libphasedint.a
                PATHS ${PHASEDINT_ENV} NO_DEFAULT_PATH
                PATH_SUFFIXES lib lib64)
   set(PhasedInt_INCLUDE_DIR ${PHASEDINT_ENV}/include)
   include_directories(${PhasedInt_INCLUDE_DIR})

# Else look in standard paths
else()
   message(STATUS "PhasedInt will be searched for based on default path ${_PHASEDINT_NORMAL_SEARCH}")
   foreach(search ${_PHASEDINT_NORMAL_SEARCH})
      find_library(PhasedInt_LIBRARY
                   NAMES libphasedint.a
                   PATHS ${search})
      if(PhasedInt_LIBRARY)
         set(PhasedInt_INCLUDE_DIR ${search}/include)
      endif()
      include_directories(${PhasedInt_INCLUDE_DIR})

   endforeach()
endif()

# Let the module handle the variables
include(FindPackageHandleStandardArgs)
FIND_PACKAGE_HANDLE_STANDARD_ARGS(PhasedInt
                                  FOUND_VAR PhasedInt_FOUND
                                  REQUIRED_VARS PhasedInt_LIBRARY)

# Let projects that import eT link only to eT::eT.  If eT was built with
# PhasedInt, eT::eT names PhasedInt::phasedint as one of its dependencies; this
# imported target tells CMake where that PhasedInt library and its headers are.
if(PhasedInt_FOUND AND NOT TARGET PhasedInt::phasedint)
   add_library(PhasedInt::phasedint UNKNOWN IMPORTED)
   set_target_properties(PhasedInt::phasedint PROPERTIES
      IMPORTED_LOCATION "${PhasedInt_LIBRARY}")
   if(PhasedInt_INCLUDE_DIR)
      set_target_properties(PhasedInt::phasedint PROPERTIES
         INTERFACE_INCLUDE_DIRECTORIES "${PhasedInt_INCLUDE_DIR}")
   endif()
endif()

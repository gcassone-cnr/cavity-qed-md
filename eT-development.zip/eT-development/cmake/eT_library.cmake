add_library(eT_library
   ${eT_fortran_sources}
   ${eT_libint_fortran_sources} ${eT_libint_CXX_sources}
   ${eT_libcint_fortran_sources}
   ${eT_phasedint_fortran_sources})

# Alias makes eT::eT available within this build.
add_library(eT::eT ALIAS eT_library)

# Fortran module files are part of eT's public interface.
# A program using an eT module needs the matching .mod/.smod files from the
# build that produced the library.
set(eT_Fortran_MODULE_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/modules)
file(MAKE_DIRECTORY ${eT_Fortran_MODULE_DIRECTORY})

set_target_properties(eT_library PROPERTIES
   EXPORT_NAME eT
   Fortran_MODULE_DIRECTORY ${eT_Fortran_MODULE_DIRECTORY})

# Supress ranlib no symbols warning for modules with no subroutines
if(APPLE)
   SET(CMAKE_C_ARCHIVE_CREATE   "<CMAKE_AR> Scr <TARGET> <LINK_FLAGS> <OBJECTS>")
   SET(CMAKE_CXX_ARCHIVE_CREATE "<CMAKE_AR> Scr <TARGET> <LINK_FLAGS> <OBJECTS>")
   SET(CMAKE_C_ARCHIVE_FINISH   "<CMAKE_RANLIB> -no_warning_for_no_symbols -c <TARGET>")
   SET(CMAKE_CXX_ARCHIVE_FINISH "<CMAKE_RANLIB> -no_warning_for_no_symbols -c <TARGET>")
endif(APPLE)

# Everything in this list is part of eT's link interface.  This is what lets an
# external project write only target_link_libraries(my_program PRIVATE eT::eT)
# instead of manually repeating BLAS/LAPACK, integral libraries, OpenMP, and
# other libraries eT was configured with.
set(eT_public_libraries
   ${lapackblas_libraries}
   ${EXTRA_LINKER_FLAGS}
   get_compilation_info)

if(USE_LIBINT)
   if(TARGET Libint2::libint2)
      list(APPEND eT_public_libraries Libint2::libint2)
   else()
      list(APPEND eT_public_libraries ${Libint2_LIBRARY})
   endif()
endif()

if(USE_LIBCINT)
   if(TARGET Libcint::libcint)
      list(APPEND eT_public_libraries Libcint::libcint)
   else()
      list(APPEND eT_public_libraries ${Libcint_LIBRARY})
   endif()
endif()

if(USE_PHASEDINT)
   if(TARGET PhasedInt::phasedint)
      list(APPEND eT_public_libraries PhasedInt::phasedint)
   else()
      list(APPEND eT_public_libraries ${PhasedInt_LIBRARY})
   endif()
endif()

if(LibXC_FOUND)
   if(TARGET Libxc::xcf03 AND TARGET Libxc::xc)
      list(APPEND eT_public_libraries Libxc::xcf03 Libxc::xc)
   else()
      list(APPEND eT_public_libraries ${LibXC_LIBRARY})
   endif()
endif()

if(ENABLE_PCMSOLVER)
   list(APPEND eT_public_libraries ${PCMSolver_LIBRARY})
endif()

if(eT_HAS_OPENMP_TARGETS)
   # Only export the Fortran OpenMP target.  Some downstream projects use eT
   # from Fortran-only CMake projects, where OpenMP::OpenMP_CXX is not created.
   list(APPEND eT_public_libraries OpenMP::OpenMP_Fortran)
endif()

# Link library to Lapack, Libint, and PCMSolver
target_link_libraries(eT_library PUBLIC ${eT_public_libraries})

# BUILD_INTERFACE paths are used when another target in this CMake build links
# to eT_library.  INSTALL_INTERFACE is written to eTTargets.cmake and is used
# after "cmake --install" by projects that call find_package(eT).
target_include_directories(eT_library PUBLIC
   $<BUILD_INTERFACE:${CMAKE_CURRENT_BINARY_DIR}>
   $<BUILD_INTERFACE:${eT_Fortran_MODULE_DIRECTORY}>
   $<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}/eT/modules>)

if(ENABLE_64BIT_INTEGERS)
   # External Fortran code that uses eT modules must use the same default
   # integer size as eT.  Restrict the flags by compiler so the installed target
   # remains usable across GNU/Intel compilers.
   target_compile_options(eT_library INTERFACE
      $<$<COMPILE_LANG_AND_ID:Fortran,GNU>:-fdefault-integer-8>
      $<$<COMPILE_LANG_AND_ID:Fortran,Intel>:-i8>
      $<$<COMPILE_LANG_AND_ID:Fortran,IntelLLVM>:-i8>)
endif()

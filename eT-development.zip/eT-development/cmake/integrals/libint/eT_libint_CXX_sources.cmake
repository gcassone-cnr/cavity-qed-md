#
#
#   eT - a coupled cluster program
#   Copyright (C) 2016-2026 the authors of eT
#
#   eT is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   eT is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program. If not, see <https://www.gnu.org/licenses/>.
#
#
set(eT_libint_CXX_sources
   src/integrals/libint/extract_integrals.cpp
   src/integrals/libint/libint_initialization.cpp
   src/integrals/libint/atom_init.cpp
   src/integrals/libint/oei.cpp
   src/integrals/libint/eri.cpp
   src/integrals/libint/ri_basis.cpp
)

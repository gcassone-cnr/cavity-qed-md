#
#
#   eT - a coupled cluster program
#   Copyright (C) 2016-2026 the authors of eT
#
#   eT is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   eT is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program. If not, see <https://www.gnu.org/licenses/>.
#
#
set(eT_phasedint_fortran_sources
   src/integrals/phasedint/phasedint_tool_class.F90
   src/integrals/phasedint/phasedint_oei_library_class.F90
   src/integrals/phasedint/phasedint_eri_library_class.F90
)

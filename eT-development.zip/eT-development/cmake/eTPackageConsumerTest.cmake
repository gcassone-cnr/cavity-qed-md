#
#
#   eT - a coupled cluster program
#   Copyright (C) 2016-2026 the authors of eT
#
#   eT is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   eT is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program. If not, see <https://www.gnu.org/licenses/>.
#
#

function(run_command description)
   execute_process(
      COMMAND ${ARGN}
      RESULT_VARIABLE command_result
      OUTPUT_VARIABLE command_output
      ERROR_VARIABLE command_error
      COMMAND_ECHO STDOUT)

   if(NOT command_result EQUAL 0)
      message(STATUS "${command_output}")
      message(STATUS "${command_error}")
      message(FATAL_ERROR "${description} failed with exit code ${command_result}")
   endif()
endfunction()

set(install_prefix "${ET_TEST_ROOT}/install")
set(consumer_build_dir "${ET_TEST_ROOT}/consumer-build")

# Start from a clean temporary prefix.  The directory is removed again after a
# successful test so GitLab does not upload a duplicate eT install inside the
# build/ artifact.
file(REMOVE_RECURSE "${ET_TEST_ROOT}")
file(MAKE_DIRECTORY "${ET_TEST_ROOT}")

# Build eT first so "cmake --install" has fresh library and module files.
set(eT_build_command
   "${CMAKE_COMMAND}"
   --build "${ET_BINARY_DIR}"
   --target eT)

if(ET_BUILD_CONFIG)
   list(APPEND eT_build_command --config "${ET_BUILD_CONFIG}")
endif()

run_command("Building eT for package test" ${eT_build_command})

# Install eT to a prefix as a user would before pointing an
# external project at -DeT_DIR=<prefix>/lib/cmake/eT.
set(eT_install_command
   "${CMAKE_COMMAND}"
   --install "${ET_BINARY_DIR}"
   --prefix "${install_prefix}")

if(ET_BUILD_CONFIG)
   list(APPEND eT_install_command --config "${ET_BUILD_CONFIG}")
endif()

run_command("Installing eT for package test" ${eT_install_command})

# Configure a separate project from tests/package/eT_library_consumer.  Passing
# compilers/generator keeps the project aligned with this eT build.
set(consumer_configure_command
   "${CMAKE_COMMAND}"
   -S "${ET_CONSUMER_SOURCE_DIR}"
   -B "${consumer_build_dir}"
   -G "${ET_CMAKE_GENERATOR}"
   "-DeT_DIR=${install_prefix}/${ET_INSTALL_CMAKEDIR}"
   "-DCMAKE_Fortran_COMPILER=${ET_Fortran_COMPILER}"
   "-DCMAKE_C_COMPILER=${ET_C_COMPILER}")

if(ET_CMAKE_BUILD_TYPE)
   list(APPEND consumer_configure_command "-DCMAKE_BUILD_TYPE=${ET_CMAKE_BUILD_TYPE}")
endif()

if(ET_CMAKE_MAKE_PROGRAM)
   list(APPEND consumer_configure_command "-DCMAKE_MAKE_PROGRAM=${ET_CMAKE_MAKE_PROGRAM}")
endif()

run_command("Configuring eT package consumer" ${consumer_configure_command})

set(consumer_build_command
   "${CMAKE_COMMAND}"
   --build "${consumer_build_dir}")

if(ET_BUILD_CONFIG)
   list(APPEND consumer_build_command --config "${ET_BUILD_CONFIG}")
endif()

run_command("Building eT package consumer" ${consumer_build_command})

# Keep the test directory on failure for debugging, but remove it on success so
# CI artifacts do not include a second copy of installed eT modules/libraries.
file(REMOVE_RECURSE "${ET_TEST_ROOT}")

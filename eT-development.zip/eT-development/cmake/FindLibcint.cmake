#
#
#   eT - a coupled cluster program
#   Copyright (C) 2016-2026 the authors of eT
#
#   eT is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   eT is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program. If not, see <https://www.gnu.org/licenses/>.
#
#

# Where to look for Libcint
set(_LIBCINT_NORMAL_SEARCH
   /usr/local/lib/
   /usr/lib/
   /lib/
   /lib64/
   /usr/opt/local/libcint)

# Save location if set in environment
set(LIBCINT_ENV $ENV{LIBCINT_ROOT})

# Look for libcint in user specified path
if(LIBCINT_ROOT)
   message(STATUS "Libcint will be searched for based on LIBCINT_ROOT=${LIBCINT_ROOT}")
   find_library(Libcint_LIBRARY
                NAMES libcint.a libcint.so
                PATHS ${LIBCINT_ROOT} NO_DEFAULT_PATH
                PATH_SUFFIXES lib lib64)

# Else look in environment path
elseif(LIBCINT_ENV)
   message(STATUS "Libcint will be searched for based on LIBCINT_ROOT=${LIBCINT_ENV}")
   find_library(Libcint_LIBRARY
                NAMES libcint.a libcint.so
                PATHS ${LIBCINT_ENV} NO_DEFAULT_PATH
                PATH_SUFFIXES lib lib64)

# Else look in standard paths
else()
   message(STATUS "Libcint will be searched for based on default path ${_LIBCINT_NORMAL_SEARCH}")
   foreach(search ${_LIBCINT_NORMAL_SEARCH})
      find_library(Libcint_LIBRARY
                  NAMES libcint.a libcint.so
                  PATHS ${search} NO_DEFAULT_PATH
                  PATH_SUFFIXES lib lib64)
   endforeach()
endif()

# Let the module handle the variables
include(FindPackageHandleStandardArgs)
FIND_PACKAGE_HANDLE_STANDARD_ARGS(Libcint
      FOUND_VAR Libcint_FOUND
      REQUIRED_VARS Libcint_LIBRARY)

# Let projects that import eT link only to eT::eT.  If eT was built with
# Libcint, eT::eT names Libcint::libcint as one of its dependencies; this
# imported target tells CMake where that Libcint library is.
if(Libcint_FOUND AND NOT TARGET Libcint::libcint)
   add_library(Libcint::libcint UNKNOWN IMPORTED)
   set_target_properties(Libcint::libcint PROPERTIES
      IMPORTED_LOCATION "${Libcint_LIBRARY}")
endif()

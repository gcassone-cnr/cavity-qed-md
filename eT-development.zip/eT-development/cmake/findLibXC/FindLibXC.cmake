# Try to find Libxc
# Exchange-Correlation functional library
#
# If successful, will define the required variables
# LibXC_FOUND - true if Libxc was found
# LibXC_INCLUDE_DIR - Containing xc_f03_lib_m.mod
# LibXC_LIBRARY - Location of libxc.a and libxcf03.a
#
# Copyright (c) 2019 Marco Scavino
# Distributed under the GNU Lesser General Public License 3.

#Where to look for Libxc

set(_LIBXC_NORMAL_SEARCH
  "/usr/local"
  "/usr/local/libxc"
  "/usr/opt/local/libxc"
  "/usr"
)

set(LIBXC_ENV $ENV{LIBXC_ROOT})

if(LIBXC_ENV)
  set(LIBXC_ROOT ${LIBXC_ENV})
endif()

if(LIBXC_ROOT)
   message("-- LibXC will be searched for based on LIBXC_ROOT=" ${LIBXC_ROOT})
else()
   set(LIBXC_ROOT ${_LIBXC_NORMAL_SEARCH})
   message("-- LibXC will be searched for based on default path ${_LIBXC_NORMAL_SEARCH}")
endif()

# Use the find_package macro to search in some possible paths

find_package(Libxc
  CONFIG
  PATHS ${LIBXC_ROOT} #${_LIBXC_NORMAL_SEARCH}
  NO_DEFAULT_PATH
  QUIET
)

if(Libxc_FOUND)
   get_target_property(LibXC_INCLUDE_DIRS Libxc::xc INTERFACE_INCLUDE_DIRECTORIES)
   get_target_property(LibXC_XC_LOCATION Libxc::xc LOCATION)
   get_target_property(LibXC_XCF03_LOCATION Libxc::xcf03 LOCATION)
   set(LibXC_LIBRARY ${LibXC_XCF03_LOCATION} ${LibXC_XC_LOCATION})

   add_compile_definitions(LIBXC_MAJOR=${Libxc_VERSION_MAJOR})
   add_compile_definitions(LIBXC_MINOR=${Libxc_VERSION_MINOR})
endif()

# Let the module handle the variables
include(FindPackageHandleStandardArgs)
FIND_PACKAGE_HANDLE_STANDARD_ARGS(LibXC
   FOUND_VAR
      LibXC_FOUND
   REQUIRED_VARS
      LibXC_LIBRARY
      LibXC_INCLUDE_DIRS
)

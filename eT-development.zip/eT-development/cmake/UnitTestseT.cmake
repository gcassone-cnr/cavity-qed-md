#
#
#   eT - a coupled cluster program
#   Copyright (C) 2016-2026 the authors of eT
#
#   eT is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   eT is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program. If not, see <https://www.gnu.org/licenses/>.
#
#  Based on the cmake/TestseT.cmake file of the public
#   Dalton program (LGPL v2.1)
#
#  Copied and modified for eT by Rolf H. Myhre, Feb 2019
#

#

macro(add_eT_unittest _name _labels)

   set(PARAM_1_ARGS "WILL_FAIL")

   cmake_parse_arguments(UTEST "${PARAM_0_ARGS}" "${PARAM_1_ARGS}" "${PARAM_N_ARGS}" ${ARGN})

   set(_will_fail FALSE)

   if(${UTEST_WILL_FAIL})
      set(_will_fail ${UTEST_WILL_FAIL})
   endif()

   set (filename unit_${_name})

   set(ZERO_ARGS "")
   set(ONE_ARGS "WILL_FAIL")
   set(MULTI_ARGS "")

   cmake_parse_arguments(UNITTEST "${ZERO_ARGS}" "${ONE_ARGS}" "${MULTI_ARGS}" ${ARGN})

   configure_file(${CMAKE_SOURCE_DIR}/unit_tests/${filename}.pf
                  ${CMAKE_BINARY_DIR}/${filename}.pf
                  COPYONLY)

   add_pfunit_ctest (${filename}
      TEST_SOURCES ${CMAKE_BINARY_DIR}/${filename}.pf
      LINK_LIBRARIES eT_library ${lapackblas_libraries} ${Libint2_LIBRARY} ${PCMSolver_LIBRARY} ${EXTRA_LINKER_FLAGS} get_compilation_info
   )

   # add "unit-test" as a label for all unit tests
   string(CONCAT labels "${_labels}" "; unit-test")

   set_tests_properties(${filename} PROPERTIES LABELS "${labels}")
   set_tests_properties(${filename} PROPERTIES WILL_FAIL "${UNITTEST_WILL_FAIL}")

   # Run each test in its own directory to avoid parallel conflicts (e.g. eT.out)
   file(MAKE_DIRECTORY ${CMAKE_BINARY_DIR}/unit_tests/${filename})
   set_tests_properties(${filename} PROPERTIES
      WORKING_DIRECTORY ${CMAKE_BINARY_DIR}/unit_tests/${filename}
      ENVIRONMENT "AO_BASIS_PATH=${CMAKE_BINARY_DIR}"
   )

endmacro()

# If the test will thrown an error, with a return value non-zero as with "error stop", "output%error_msg" or stop 1,
# set up the WILL_FAIL flag to TRUE

add_eT_unittest(warning_suppressor      "dummy; warning-suppression")
#
add_eT_unittest(angular_momentum        "angular-momentum")
add_eT_unittest(cart_angular_momentum_7 "angular-momentum" WILL_FAIL TRUE)
#
add_eT_unittest(tools                   "tools")
add_eT_unittest(memory                  "memory" WILL_FAIL TRUE)

add_eT_unittest(z_matrix                "z-matrix" WILL_FAIL TRUE)

add_eT_unittest(hf_gs "no-input-file")
add_eT_unittest(ccsd_gs "no-input-file")

add_eT_unittest(config_section_keyword "keywords")
add_eT_unittest(config_overwrites_keyword "keywords")
add_eT_unittest(config_alias_updates_keyword_immediately "keywords")
add_eT_unittest(config_alias_updates_geometry_immediately "keywords")
add_eT_unittest(config_invalid_section  "keywords" WILL_FAIL TRUE)
add_eT_unittest(config_invalid_keyword  "keywords" WILL_FAIL TRUE)
add_eT_unittest(config_keyword_sanity "keywords")
add_eT_unittest(config_keyword_sanity_invalid "keywords" WILL_FAIL TRUE)
add_eT_unittest(subblock_reordering "subblock_reordering")
